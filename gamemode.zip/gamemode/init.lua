AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

-- Item icons (clients download these).
for _, name in ipairs({ "bandage", "splint", "painkillers", "ifak", "medkit",
	"surgical", "mre", "repair", "fuel" }) do
	resource.AddFile("materials/milbase/ui/items/" .. name .. ".png")
end

-- F4 menu icons (Battlefront-II UI), bundled in content/ and sent to clients
-- so the menu works without any separate workshop addon.
for _, path in ipairs({
	"menu/f4/bfui/avatar.png",
	"menu/f4/bfui/money.png",
	"menu/f4/bfui/power.png",
	"menu/f4/bfui/e11.png",
	"menu/f4/bfui/paint-board-and-brush.png",
	"menu/f4/bfui/creditcard.png",
	"menu/f4/bfui/keyboard.png",
	"menu/f4/bfui/cogwheel.png",
	"menu/f4/icons/home/home_icons_timed_achievement.png",
	"hud/player/overhead/icon/medic.png",
}) do
	resource.AddFile("materials/astolfo/ui/" .. path)
end

-- Generated BF2 UI kit (outlines, brackets, glows) - see core/cl_ui.lua bf2 table.
for _, name in ipairs({ "bracket_tl", "bracket_tr", "bracket_bl", "bracket_br",
	"diamond", "diamond_hollow", "hex", "hex_hollow", "chevron", "glow_radial",
	"grad_sheen", "panel_grad", "scanlines", "accent_bar", "underline_glow",
	"chamfer_frame",
	-- menu-specific: empty-slot silhouettes, grid cell, frames, rarity gem
	"slot_head", "slot_armor", "slot_backpack", "slot_holster", "slot_primary",
	"grid_cell", "item_frame", "card_frame", "slot_frame", "rarity_gem",
	-- crate tier icons + star pip
	"crate_tier1", "crate_tier2", "crate_tier3", "crate_tier4", "star" }) do
	resource.AddFile("materials/milbase/ui/bf2/" .. name .. ".png")
end

-- Kraken content the UI references (Bebas Neue / D-DIN fonts, BF2 scoreboard /
-- KIA / low-ammo art, squad UI sounds), bundled in content/ so the intended
-- typography and art load without relying on the workshop addon mounting.
for _, path in ipairs({
	"resource/fonts/bebasneue.ttf",
	"resource/fonts/bebasneue-regular.ttf",
	"resource/fonts/d-din.ttf",
	"resource/fonts/d-din-bold.ttf",
	"materials/kraken/bf2scoreboard/scoreboard.png",
	"materials/kraken/bf2hud/killed.png",
	"materials/kraken/bf2hud/ammo_low.png",
	"sound/kraken/squads/ping.wav",
	"sound/kraken/squads/radial_hover.wav",
	"sound/kraken/squads/radial_select.wav",
}) do
	resource.AddFile(path)
end

include("shared.lua")

-- Workshop content packs (fonts, UI art, sounds) players should download.
for _, id in ipairs(MilBase.Config.WorkshopContent or {}) do
	resource.AddWorkshop(id)
end
