--[[
	MilBase - a milsim roleplay base gamemode.
	Helix-style immersion, DarkRP-style simplicity.

	Server owners: you should only ever need to touch the files in config/.
	Developers: drop new features into modules/ and they load automatically.
]]

GM.Name = "StarWarsRP"
GM.Author = "MilBase"
GM.Website = ""

DeriveGamemode("sandbox")

MilBase = MilBase or {}
MilBase.Config = MilBase.Config or {}

-- Includes a file based on its prefix: sv_ (server), cl_ (client), sh_ (shared).
function MilBase.Include(path)
	local fileName = string.GetFileFromFilename(path)
	local prefix = string.sub(fileName, 1, 3)

	if prefix == "sv_" then
		if SERVER then include(path) end
	elseif prefix == "cl_" then
		if SERVER then AddCSLuaFile(path) else include(path) end
	else -- sh_ or anything else is shared
		if SERVER then AddCSLuaFile(path) end
		include(path)
	end
end

-- Includes every lua file in a directory (relative to the gamemode/ folder).
function MilBase.IncludeDir(dir)
	local folder = (GM or GAMEMODE).FolderName or "starwarsrp"
	local files = file.Find(folder .. "/gamemode/" .. dir .. "/*.lua", "LUA")

	for _, f in ipairs(files) do
		MilBase.Include(dir .. "/" .. f)
	end
end

-- Load order matters: settings first, then core systems, then the faction
-- config (which uses the core API), then drop-in modules.
MilBase.Include("config/sh_config.lua")
MilBase.Include("config/sh_galaxy.lua")
MilBase.Include("config/sh_living_universe.lua")
MilBase.Include("config/sh_naval_operations.lua")
MilBase.Include("config/sh_smuggling_inspections.lua")
MilBase.Include("config/sh_prison.lua")
MilBase.Include("config/sv_galaxy.lua")
MilBase.Include("config/sh_massif.lua")
MilBase.Include("config/sh_juggernaut.lua")
MilBase.Include("config/sh_jetpack.lua")
MilBase.Include("config/sh_tether.lua")

-- Unified database layer (SQLite by default, MySQL when configured). Must
-- load before any core system or module that persists data.
MilBase.Include("core/sv_database.lua")

MilBase.Include("core/sh_util.lua")
MilBase.Include("core/sh_arccw_support.lua")
MilBase.Include("core/sh_factions.lua")
MilBase.Include("core/sh_items.lua")
MilBase.Include("core/sh_commands.lua")
MilBase.Include("core/sh_actions.lua")
MilBase.Include("core/sh_certs.lua")
MilBase.Include("core/sh_languages.lua")
MilBase.Include("core/sh_species.lua")
MilBase.Include("core/sh_staff.lua")
MilBase.Include("core/sh_events.lua")
MilBase.Include("core/sh_starcards.lua")
MilBase.Include("core/sh_crates.lua")
MilBase.Include("core/sv_data.lua")
MilBase.Include("core/sv_inventory.lua")
MilBase.Include("core/sv_arccw_support.lua")
MilBase.Include("core/sv_progression.lua")
MilBase.Include("core/sv_player.lua")
MilBase.Include("core/sv_chat.lua")
MilBase.Include("core/sv_menu.lua")
MilBase.Include("core/sv_stamina.lua")
MilBase.Include("core/cl_ui.lua")
MilBase.Include("core/cl_hud.lua")
MilBase.Include("core/cl_inventory.lua")
MilBase.Include("core/cl_menu.lua")
MilBase.Include("core/cl_scoreboard.lua")

MilBase.Include("config/sh_factions.lua")
MilBase.Include("config/sh_items.lua")
MilBase.Include("config/sh_certs.lua")
MilBase.Include("config/sh_languages.lua")
MilBase.Include("config/sh_species.lua")
MilBase.Include("config/sh_staff.lua")
MilBase.Include("config/sh_events.lua")
MilBase.Include("config/sh_eventenemies.lua")
MilBase.Include("config/sh_comms.lua")
MilBase.Include("config/sh_starcards.lua")
MilBase.Include("config/sh_crates.lua")
MilBase.Include("config/sh_lscs.lua")

-- Explicit gameplay modules that need to be available immediately.
-- The generic IncludeDir below also sees this file, but the module has its
-- own loaded guard so this stays safe while making startup deterministic.
MilBase.Include("modules/sv_cinematic_dialogue.lua")
MilBase.Include("modules/cl_cinematic_dialogue.lua")
MilBase.Include("modules/sh_sw_infil.lua")
MilBase.Include("modules/sh_lscs.lua")
MilBase.Include("modules/sh_lscs_advanced.lua")
MilBase.Include("modules/sh_galaxy.lua")
MilBase.Include("modules/sv_galaxy.lua")
MilBase.Include("modules/cl_galaxy.lua")
MilBase.Include("modules/sh_galaxy_expansion.lua")
MilBase.Include("modules/sv_galaxy_expansion.lua")
MilBase.Include("modules/cl_galaxy_expansion.lua")
MilBase.Include("modules/sh_living_universe.lua")
MilBase.Include("modules/sh_galaxy_combat.lua")
MilBase.Include("modules/sv_galaxy_combat.lua")
MilBase.Include("modules/cl_galaxy_combat.lua")
-- Loaded after combat so permanent-vessel damage and casualty hooks can
-- observe the final shield/hull result.
MilBase.Include("modules/sv_living_universe.lua")
MilBase.Include("modules/sv_performance.lua")
MilBase.Include("modules/sh_naval_operations.lua")
MilBase.Include("modules/sv_naval_operations.lua")
MilBase.Include("modules/cl_naval_operations.lua")
MilBase.Include("modules/sh_fleet_logistics.lua")
MilBase.Include("modules/sv_fleet_logistics.lua")
MilBase.Include("modules/cl_fleet_logistics.lua")

-- Prison modules have a strict dependency order. The shared API must exist
-- before the client datapad builder and server implementation initialise.
-- Their loaded guards keep the later generic module pass safe.
MilBase.Include("modules/sh_prison.lua")
MilBase.Include("modules/sv_prison.lua")
MilBase.Include("modules/cl_prison.lua")
MilBase.Include("modules/sv_prison_upgrade.lua")
MilBase.Include("modules/cl_prison_upgrade.lua")

MilBase.IncludeDir("modules")
