--[[
	Staff rank system.

	Ranks are defined in config/sh_staff.lua with a level (higher = more
	authority) and an optional engine usergroup mapping ("admin" /
	"superadmin") so the gamemode's IsAdmin() checks work automatically.

	Setting ranks:
	  Chat:    /setstaff <player> <rank id>     (staff level 4+)
	  Console: mb_setstaff <name|steamid64|steamid> <rank id>
	           Works from the SERVER CONSOLE (or listen-server host) with
	           no restrictions - that's how you make the first Owner:
	              mb_setstaff "Danny" owner
	           Offline players can be set by SteamID.
	  Use rank id "user" to remove a staff rank.

	NOTE: if you run ULX or another admin mod that manages usergroups,
	let it own the groups and set MilBase ranks to match.
]]

MilBase.StaffRanks = MilBase.StaffRanks or {}
MilBase.StaffOrder = MilBase.StaffOrder or {}

function MilBase.RegisterStaffRank(id, data)
	data.id = id
	data.name = data.name or id
	data.level = data.level or 1
	data.color = data.color or Color(180, 180, 180)

	if not MilBase.StaffRanks[id] then
		table.insert(MilBase.StaffOrder, id)
	end
	MilBase.StaffRanks[id] = data
	return data
end

local PLAYER = FindMetaTable("Player")

-- Returns the staff rank table, or nil for regular users.
function PLAYER:MBStaffRank()
	return MilBase.StaffRanks[self:GetNWString("mb_staff", "")]
end

function PLAYER:MBStaffLevel()
	local rank = self:MBStaffRank()
	return rank and rank.level or 0
end

if not SERVER then return end

--------------------------------------------------------------------------
-- Server: persistence and assignment
--------------------------------------------------------------------------

-- `rank` is reserved in MySQL 8.0, so it's backticked.
MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_staff (
	steamid VARCHAR(32) PRIMARY KEY,
	`rank` VARCHAR(64)
)]])

local function applyStaff(ply, id)
	local def = id and MilBase.StaffRanks[id] or nil
	ply:SetNWString("mb_staff", def and def.id or "")

	-- Map onto engine usergroups so IsAdmin()/IsSuperAdmin() work.
	if def and def.usergroup then
		ply:SetUserGroup(def.usergroup)
	elseif ply:GetUserGroup() == "admin" or ply:GetUserGroup() == "superadmin" then
		ply:SetUserGroup("user")
	end
end

-- id = nil/"user" removes the rank. actor = who did it (nil = console).
function MilBase.SetStaffRank(steamID64, id, actor)
	if id == "user" or id == "none" or id == "" then id = nil end
	if id and not MilBase.StaffRanks[id] then
		return false, "Unknown staff rank. Valid: user, " .. table.concat(MilBase.StaffOrder, ", ")
	end

	if id then
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_staff (steamid, `rank`) VALUES (%s, %s)",
			MilBase.SQLStr(steamID64), MilBase.SQLStr(id)))
	else
		MilBase.DB.Run(string.format(
			"DELETE FROM frontier_staff WHERE steamid = %s",
			MilBase.SQLStr(steamID64)))
	end

	-- Apply live if they're online.
	for _, ply in ipairs(player.GetAll()) do
		if ply:SteamID64() == steamID64 then
			applyStaff(ply, id)

			local label = id and MilBase.StaffRanks[id].name or "a regular user"
			MilBase.ChatMsg(nil, Color(200, 160, 80), "[STAFF] ", color_white,
				ply:MBName() .. " is now " .. label
				.. (IsValid(actor) and (" (by " .. actor:MBName() .. ")") or "") .. ".")
			break
		end
	end

	return true
end

hook.Add("PlayerInitialSpawn", "MilBase.LoadStaff", function(ply)
	MilBase.DB.Query(string.format(
		"SELECT `rank` FROM frontier_staff WHERE steamid = %s",
		MilBase.SQLStr(ply:SteamID64())), function(rows)
		if not IsValid(ply) then return end
		local row = rows[1]
		applyStaff(ply, row and row.rank or nil)
	end)
end)

--------------------------------------------------------------------------
-- Commands
--------------------------------------------------------------------------

-- Staff level required to manage staff ranks in game.
local MANAGE_LEVEL = 4

-- Shared permission logic. Console and the listen-server host bypass.
local function trySetStaff(actor, targetSID, targetPly, rankID)
	local unlimited = not IsValid(actor) or actor:IsListenServerHost()
	local actorLevel = unlimited and math.huge or actor:MBStaffLevel()

	if actorLevel < MANAGE_LEVEL then
		return false, "You need staff level " .. MANAGE_LEVEL .. "+ to manage staff ranks."
	end

	local def = MilBase.StaffRanks[rankID]
	if def and def.level >= actorLevel then
		return false, "You can only assign ranks below your own."
	end
	if IsValid(targetPly) and targetPly:MBStaffLevel() >= actorLevel then
		return false, "That person's staff rank is equal to or above yours."
	end

	return MilBase.SetStaffRank(targetSID, rankID, IsValid(actor) and actor or nil)
end

MilBase.RegisterChatCommand("setstaff", {
	help = "Set a staff rank: /setstaff <player> <rank id or 'user'> (staff level 4+)",
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end

		local ok, err = trySetStaff(ply, target:SteamID64(), target, string.lower(args[2] or "user"))
		if not ok then MilBase.Notify(ply, err) end
	end,
})

local function resolveSteamID64(str)
	if not str then return end
	if string.match(str, "^%d+$") and #str == 17 then return str end
	if string.match(str, "^STEAM_%d:%d:%d+$") then return util.SteamIDTo64(str) end
end

concommand.Add("mb_setstaff", function(ply, _, args)
	local function reply(text)
		if IsValid(ply) then MilBase.Notify(ply, text) else MsgN("[MilBase] " .. text) end
	end

	local ident = args[1]
	local rankID = string.lower(args[2] or "user")

	local target = MilBase.FindPlayer(ident or "")
	local sid = IsValid(target) and target:SteamID64() or resolveSteamID64(ident)

	if not sid then
		reply("Usage: mb_setstaff <name|steamid64|steamid> <rank id>. Ranks: user, "
			.. table.concat(MilBase.StaffOrder, ", "))
		return
	end

	local ok, err = trySetStaff(ply, sid, target, rankID)
	reply(ok and ("Staff rank updated (" .. sid .. " -> " .. rankID .. ").") or err)
end)
