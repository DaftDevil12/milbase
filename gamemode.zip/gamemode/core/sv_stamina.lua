-- Stamina: sprinting drains it; when empty you slow to walk speed until it recovers.

local cfg = MilBase.Config
local TICK = 0.2
local nextTick = 0

hook.Add("Think", "MilBase.Stamina", function()
	if not cfg.StaminaEnabled then return end
	if CurTime() < nextTick then return end
	nextTick = CurTime() + TICK

	for _, ply in ipairs(player.GetAll()) do
		if not ply:Alive() then continue end

		local stamina = ply:GetNWFloat("mb_stamina", 100)
		local sprinting = ply:KeyDown(IN_SPEED)
			and ply:GetVelocity():Length2DSqr() > 100
			and ply:OnGround()

		if sprinting and not ply.mb_exhausted then
			stamina = math.max(0, stamina - cfg.StaminaDrain * TICK)
		else
			local regen = cfg.StaminaRegen
			-- A destroyed stomach halves stamina recovery (see medical module).
			if ply:GetNWInt("mb_limb_stomach", 1) <= 0 then
				regen = regen * 0.5
			end
			stamina = math.min(100, stamina + regen * TICK)
		end

		if stamina <= 0 and not ply.mb_exhausted then
			ply.mb_exhausted = true
			MilBase.UpdateMoveSpeed(ply)
		elseif ply.mb_exhausted and stamina >= 25 then
			ply.mb_exhausted = false
			MilBase.UpdateMoveSpeed(ply)
		end

		ply:SetNWFloat("mb_stamina", stamina)
	end
end)

-- Jumping is tiring.
hook.Add("KeyPress", "MilBase.JumpStamina", function(ply, key)
	if not cfg.StaminaEnabled or key ~= IN_JUMP then return end
	if not ply:Alive() or not ply:OnGround() then return end

	ply:SetNWFloat("mb_stamina",
		math.max(0, ply:GetNWFloat("mb_stamina", 100) - cfg.JumpStaminaCost))
end)
