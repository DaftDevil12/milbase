--[[
	The F4 menu: fullscreen, blurred, Helix-style.
	Tabs: ROSTER (regiments & character), INVENTORY, CERTIFICATIONS, HELP.
]]

local cfg = MilBase.Config

local menuPanel
local menuMode -- "main" (F4) or "staff" (F2)

-- Tabs that belong in the STAFF menu (F2) instead of the main F4 menu.
-- Modules can add to this; each still respects its own visible() gate.
MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {
	["STAFF"] = true, ["LOGS"] = true, ["MODEL RULES"] = true,
	["BIO-LAB"] = true, ["KEYCARDS"] = true,
}

local function closeMenu()
	if IsValid(menuPanel) then menuPanel:Remove() end
	menuPanel = nil
	menuMode = nil
end

function MilBase.CloseMenu()
	closeMenu()
end

--------------------------------------------------------------------------
-- Tab registry: modules can add their own menu tabs.
-- build(contentPanel, ctx).
--------------------------------------------------------------------------

MilBase.MenuTabs = MilBase.MenuTabs or {}

-- visible(lp) is optional; when given, the tab only shows if it returns true.
function MilBase.AddMenuTab(name, order, build, visible)
	for _, tab in ipairs(MilBase.MenuTabs) do
		if tab.name == name then -- re-registration (autorefresh)
			tab.order, tab.build, tab.visible = order, build, visible
			return
		end
	end

	table.insert(MilBase.MenuTabs, { name = name, order = order, build = build, visible = visible })
	table.sort(MilBase.MenuTabs, function(a, b) return a.order < b.order end)
end

--------------------------------------------------------------------------
-- Styling helpers
--------------------------------------------------------------------------

local function flatButton(parent, label, accent)
	local btn = vgui.Create("DButton", parent)
	btn:SetText("")
	btn.mb_label = label
	btn.Paint = function(self, w, h)
		local ui = MilBase.UI
		local col = ui.raised
		if not self:IsEnabled() then
			col = Color(255, 255, 255, 3)
		elseif self:IsHovered() then
			col = accent and Color(accent.r, accent.g, accent.b, 60) or ui.hover
		end

		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = col })
		if self:IsEnabled() and self:IsHovered() then
			MilBase.DrawBrackets(2, 2, w - 4, h - 4, accent or MilBase.UI.accent)
		end

		draw.SimpleText(self.mb_label, "MB.Small", w / 2, h / 2,
			self:IsEnabled() and ui.text or ui.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return btn
end

local function darkEntry(parent)
	local entry = vgui.Create("DTextEntry", parent)
	entry:SetFont("MB.Small")
	entry.Paint = function(self, w, h)
		local ui = MilBase.UI
		surface.SetDrawColor(0, 0, 0, 160)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and Color(255, 255, 255, 60) or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.dim, ui.text)
	end
	return entry
end

--------------------------------------------------------------------------
-- ROSTER tab
--------------------------------------------------------------------------

local function buildRoster(content)
	local ui = MilBase.UI
	local ply = LocalPlayer()

	-- Character name
	local nameRow = vgui.Create("DPanel", content)
	nameRow:Dock(TOP)
	nameRow:SetTall(66)
	nameRow:DockMargin(0, 0, 0, 14)
	nameRow.Paint = function(self, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("PERSONAL NAME", "MB.Tiny", 14, 10, ui.dim)
	end

	local nameEntry = darkEntry(nameRow)
	nameEntry:SetSize(280, 28)
	nameEntry:SetPos(14, 30)
	nameEntry:SetText(ply.MBRawName and ply:MBRawName() or ply:MBName())

	local nameBtn = flatButton(nameRow, "APPLY")
	nameBtn:SetSize(90, 28)
	nameBtn:SetPos(304, 30)
	nameBtn.DoClick = function()
		net.Start("MilBase_SetName")
			net.WriteString(nameEntry:GetValue())
		net.SendToServer()
	end

	-- Faction list (left) + details (right)
	local list = vgui.Create("DScrollPanel", content)
	list:Dock(LEFT)
	list:SetWide(280)

	local details = vgui.Create("DPanel", content)
	details:Dock(FILL)
	details:DockMargin(14, 0, 0, 0)
	details.Paint = function(self, w, h) MilBase.PaintPanel(w, h) end

	local function showFaction(faction)
		details:Clear()

		local header = vgui.Create("DPanel", details)
		header:Dock(TOP)
		header:SetTall(72)
		header.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 8,
				color = Color(0, 0, 0, 120),
				accent = faction.color,
			})

			local tx = 18
			local logo = MilBase.GetUIMat(faction.logo)
			if logo then
				surface.SetDrawColor(255, 255, 255, 230)
				surface.SetMaterial(logo)
				surface.DrawTexturedRect(14, h / 2 - 26, 52, 52)
				tx = 76
			end

			draw.SimpleText(string.upper(faction.name), "MB.Big", tx, 8, faction.color)
			draw.SimpleText(faction.description or "", "MB.Tiny", tx, 46, ui.dim)
			draw.SimpleText(#team.GetPlayers(faction.teamIndex) .. " DEPLOYED", "MB.Small",
				w - 16, 14, ui.dim, TEXT_ALIGN_RIGHT)
		end

		-- Roles are assigned, not chosen.
		local note = vgui.Create("DPanel", details)
		note:Dock(BOTTOM)
		note:SetTall(40)
		note:DockMargin(12, 10, 12, 12)
		note.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 8,
				color = Color(0, 0, 0, 120),
				accent = faction.color,
			})
			local text = faction.id == ply:MBFactionID()
				and "YOUR CURRENT ASSIGNMENT"
				or "ASSIGNMENT BY OFFICERS AND COMMAND — speak to your chain of command"
			draw.SimpleText(text, "MB.Small", 14, h / 2, ui.dim,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local mdl = vgui.Create("DModelPanel", details)
		mdl:Dock(LEFT)
		mdl:SetWide(230)
		mdl:DockMargin(12, 12, 0, 10)
		mdl:SetModel(faction.models[1] or "models/player/group01/male_02.mdl")
		mdl:SetFOV(38)
		local head = mdl.Entity:LookupBone("ValveBiped.Bip01_Head1")
		local eyePos = head and mdl.Entity:GetBonePosition(head) or Vector(0, 0, 60)
		mdl:SetLookAt(eyePos - Vector(0, 0, 28))
		mdl:SetCamPos(eyePos + Vector(52, 18, -14))
		function mdl:LayoutEntity() end

		local ranks = vgui.Create("DScrollPanel", details)
		ranks:Dock(FILL)
		ranks:DockMargin(12, 12, 12, 10)

		local rankHeader = vgui.Create("DLabel", ranks)
		rankHeader:Dock(TOP)
		rankHeader:SetFont("MB.Tiny")
		rankHeader:SetText("RANK STRUCTURE        ★ can promote      ✚ medic")
		rankHeader:SetTextColor(ui.dim)
		rankHeader:DockMargin(2, 0, 0, 8)

		for i, rank in ipairs(faction.ranks) do
			local row = vgui.Create("DPanel", ranks)
			row:Dock(TOP)
			row:SetTall(28)
			row:DockMargin(0, 0, 0, 4)
			row.Paint = function(self, w, h)
				surface.SetDrawColor(255, 255, 255, 6)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(i, "MB.Tiny", 10, h / 2, ui.faint,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local suffix = (rank.canPromote and "  ★" or "") .. (rank.medic and "  ✚" or "")
				draw.SimpleText(rank.name .. suffix, "MB.Small", 34, h / 2, ui.text,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if rank.salary then
					draw.SimpleText(cfg.CurrencySymbol .. rank.salary .. " / payday", "MB.Tiny",
						w - 10, h / 2, ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
		end

		-- Who's deployed right now
		local online = team.GetPlayers(faction.teamIndex)

		local memberHeader = vgui.Create("DLabel", ranks)
		memberHeader:Dock(TOP)
		memberHeader:SetFont("MB.Tiny")
		memberHeader:SetText("DEPLOYED PERSONNEL — " .. #online .. " ONLINE")
		memberHeader:SetTextColor(ui.dim)
		memberHeader:DockMargin(2, 14, 0, 6)

		for _, member in ipairs(online) do
			local row = vgui.Create("DPanel", ranks)
			row:Dock(TOP)
			row:SetTall(24)
			row:DockMargin(0, 0, 0, 3)
			row.Paint = function(self, w, h)
				if not IsValid(member) then return end
				surface.SetDrawColor(255, 255, 255, 5)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(member:MBName(), "MB.Small", 10, h / 2, ui.text,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				local mRank = member:MBRank()
				draw.SimpleText(string.upper(mRank and mRank.name or ""), "MB.Tiny",
					w - 10, h / 2, faction.color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
	end

	local firstFaction
	for _, id in ipairs(MilBase.FactionOrder) do
		local faction = MilBase.GetFaction(id)
		firstFaction = firstFaction or faction

		local btn = vgui.Create("DButton", list)
		btn:Dock(TOP)
		btn:SetTall(56)
		btn:DockMargin(0, 0, 8, 6)
		btn:SetText("")
		btn.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 8,
				color = self:IsHovered() and ui.hover or ui.panel,
				accent = faction.color,
			})
			if self:IsHovered() then
				MilBase.DrawBrackets(2, 2, w - 4, h - 4, faction.color, 8)
			end
			draw.SimpleText(faction.name, "MB.Med", 16, 8, ui.text)

			local sub = #faction.ranks .. " RANKS   •   "
				.. #team.GetPlayers(faction.teamIndex) .. " ONLINE"
			if faction.id == LocalPlayer():MBFactionID() then sub = sub .. "   •   CURRENT" end
			draw.SimpleText(sub, "MB.Tiny", 16, 33, ui.dim)
		end
		btn.DoClick = function() showFaction(faction) end
	end

	showFaction(MilBase.GetFaction(ply:MBFactionID()) or firstFaction)
end

--------------------------------------------------------------------------
-- HELP tab
--------------------------------------------------------------------------

local function buildHelp(content)
	local ui = MilBase.UI
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local function heading(text)
		local lbl = vgui.Create("DLabel", scroll)
		lbl:Dock(TOP)
		lbl:SetFont("MB.Med")
		lbl:SetText(text)
		lbl:SetTextColor(ui.text)
		lbl:DockMargin(2, 10, 0, 6)
		lbl:SizeToContents()
	end

	local function line(left, right)
		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(24)
		row:DockMargin(0, 0, 8, 2)
		row.Paint = function(self, w, h)
			surface.SetDrawColor(255, 255, 255, 5)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(left, "MB.Small", 10, h / 2, ui.text,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(right, "MB.Tiny", 200, h / 2, ui.dim,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	heading("CONTROLS")
	line("F4 / F1", "Open this menu")
	line("ALT", "Lower / raise your weapon (you can't fire while lowered)")
	line("E (hold)", "Stabilize a wounded soldier / pick up dropped items")
	line("R", "Rotate an item while dragging it in the inventory")
	line("SPACE", "Give up while wounded / respawn when dead")

	heading("CHAT COMMANDS")
	line("@ <message>", "Alert online staff about a player or situation")
	for name, cmd in SortedPairs(MilBase.Commands) do
		if MilBase.HiddenCommands and MilBase.HiddenCommands[name] then continue end
		line("/" .. name, cmd.help or "")
	end
end

--------------------------------------------------------------------------
-- CERTIFICATIONS tab
--------------------------------------------------------------------------

local function buildCerts(content)
	local ui = MilBase.UI
	local ply = LocalPlayer()

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local intro = vgui.Create("DLabel", scroll)
	intro:Dock(TOP)
	intro:SetFont("MB.Tiny")
	intro:SetText("Certifications are granted by officers and admins:  /certify <player> <cert id>")
	intro:SetTextColor(ui.dim)
	intro:DockMargin(2, 0, 0, 10)
	intro:SizeToContents()

	for _, id in ipairs(MilBase.CertOrder) do
		local cert = MilBase.Certs[id]
		local held = ply:MBHasPersistentCert(id) or ply:MBHasTemporaryCert(id)
		local owned = ply:MBHasCert(id)
		local restricted = held and not owned

		local card = vgui.Create("DPanel", scroll)
		card:Dock(TOP)
		card:SetTall(74)
		card:DockMargin(0, 0, 8, 8)
		card.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 8,
				accent = owned and ui.ok or nil,
			})

			local tx = 16
			local icon = MilBase.GetUIMat(cert.icon)
			if icon then
				surface.SetDrawColor(255, 255, 255, owned and 235 or 120)
				surface.SetMaterial(icon)
				surface.DrawTexturedRect(12, h / 2 - 24, 48, 48)
				tx = 70
			end

			draw.SimpleText(cert.name, "MB.Med", tx, 8, ui.text)
			local status = owned and "CERTIFIED ✓" or (restricted and "FACTION RESTRICTED" or "NOT CERTIFIED")
			draw.SimpleText(status, "MB.Small", w - 14, 10,
				owned and ui.ok or (restricted and ui.warn or ui.faint), TEXT_ALIGN_RIGHT)
			draw.SimpleText(cert.desc, "MB.Tiny", tx, 32, ui.dim)
			draw.SimpleText(string.upper(MilBase.CertGrantsText(cert)), "MB.Tiny", tx, 51, ui.warn)
			draw.SimpleText("id: " .. id, "MB.Tiny", w - 14, h - 20, ui.faint, TEXT_ALIGN_RIGHT)
		end
	end
end

--------------------------------------------------------------------------
-- Base tabs (modules register theirs with MilBase.AddMenuTab too)
--------------------------------------------------------------------------

MilBase.AddMenuTab("ROSTER", 10, buildRoster)

MilBase.AddMenuTab("GEAR", 20, function(content)
	local inv = MilBase.CreateGearPanel(content)
	inv:Dock(FILL)
end)

MilBase.AddMenuTab("CERTIFICATIONS", 25, buildCerts)

MilBase.AddMenuTab("HELP", 90, buildHelp)

--------------------------------------------------------------------------
-- The menu itself
--------------------------------------------------------------------------

local function buildMenu(staffMode, preferredTab)
	staffMode = staffMode == true
	local mode = staffMode and "staff" or "main"

	if IsValid(menuPanel) then -- toggles; switches if the other menu is open
		local wasSame = menuMode == mode
		closeMenu()
		if wasSame then return end
	end
	menuMode = mode

	local ui = MilBase.UI
	local ply = LocalPlayer()

	local margin = math.floor(ScrW() * 0.055)
	local TABS_Y, DIV_Y = 74, 114
	local BAR_H = 44

	-- DFrame (not a bare DPanel) so popup keyboard focus works reliably -
	-- otherwise DTextEntry boxes in the tabs never accept typing. Its default
	-- chrome (title bar / close button / drag) is stripped; frame.Paint below
	-- draws everything, so it still looks like a flat fullscreen panel.
	local frame = vgui.Create("DFrame")
	menuPanel = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(true)

	-- BF2-style header: resource counter top-left, identity top-right,
	-- a horizontal tab bar, and a divider; plus a bottom status strip.
	frame.Paint = function(self, w, h)
		-- Scoreboard starfield backdrop under a 60% black scrim (153/255).
		-- Lower the scrim alpha if you want the stars more visible.
		if not MilBase.DrawIcon(ui.art.scoreboard, 0, 0, w, h) then
			MilBase.DrawBlur(self, 6)
		end
		surface.SetDrawColor(0, 0, 0, 153)
		surface.DrawRect(0, 0, w, h)

		local faction = ply:MBFaction()
		local rank = ply:MBRank()
		local accent = faction and faction.color or ui.accent

		-- Top-left: game title + battlepoints-style resource counter. The
		-- BF2 credits icon replaces the diamond glyph (diamond is the fallback
		-- when the content addon isn't mounted).
		draw.SimpleText(staffMode and "STAFF COMMAND" or "PERSONNEL", "MB.Med", margin, 26, ui.text)
		if not MilBase.DrawIcon(ui.art.money, margin, 50, 16, 16, ui.accent) then
			MilBase.DrawDiamond(margin + 8, 58, 6, ui.accent)
		end
		draw.SimpleText(ply:MBMoney(), "MB.Small", margin + 24, 58, ui.text,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.upper(cfg.CurrencyName or "credits"), "MB.Tiny",
			margin + 24 + 46, 59, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		-- Top-right: soldier identity with a framed BF2 avatar.
		local avSize = 48
		local avX, avY = w - margin - avSize, 16
		local textR = avX - 12
		MilBase.DrawPanelBF2(avX, avY, avSize, avSize, {
			cut = 6, color = Color(0, 0, 0, 150), accent = accent })
		MilBase.DrawIcon(ui.art.avatar, avX + 8, avY + 7, avSize - 16, avSize - 16, ui.text)
		MilBase.DrawIcon(ui.art.bf2.frame, avX, avY, avSize, avSize, accent)

		draw.SimpleText(ply:MBName(), "MB.Med", textR, 22, ui.text, TEXT_ALIGN_RIGHT)
		draw.SimpleText(string.upper((rank and rank.name or "")
			.. (faction and ("  •  " .. faction.name) or "")), "MB.Tiny",
			textR, 48, accent, TEXT_ALIGN_RIGHT)

		-- Divider under the tab bar (dim line + a bright accent lead-in).
		surface.SetDrawColor(255, 255, 255, 22)
		surface.DrawRect(margin, DIV_Y, w - margin * 2, 1)
		surface.SetDrawColor(accent)
		surface.DrawRect(margin, DIV_Y - 1, 70, 2)

		-- Bottom status strip.
		surface.SetDrawColor(0, 0, 0, 170)
		surface.DrawRect(0, h - BAR_H, w, BAR_H)
		surface.SetDrawColor(255, 198, 60, 60)
		surface.DrawRect(0, h - BAR_H, w, 1)
		MilBase.DrawIcon(ui.art.bf2.hex, margin, h - BAR_H / 2 - 5, 10, 10, ui.accent)
		draw.SimpleText(string.upper(GetHostName() ~= "" and GetHostName() or "MILBASE"),
			"MB.Tiny", margin + 18, h - BAR_H / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	frame.Think = function(self)
		if gui.IsGameUIVisible() then -- ESC closes the menu, not the game
			gui.HideGameUI()
			closeMenu()
		end
	end

	local tabs = {}
	for _, tab in ipairs(MilBase.MenuTabs) do
		local isStaffTab = MilBase.StaffMenuTabs[tab.name] or false
		if isStaffTab == staffMode and (not tab.visible or tab.visible(ply)) then
			tabs[#tabs + 1] = tab
		end
	end
	local ctx = {}

	local content = vgui.Create("DPanel", frame)
	content:SetPos(margin, DIV_Y + 18)
	content:SetSize(ScrW() - margin * 2, ScrH() - DIV_Y - 18 - BAR_H - 12)
	content.Paint = nil

	local activeTab
	local function setTab(tab)
		activeTab = tab.name
		content:Clear()
		tab.build(content, ctx)
	end

	-- Horizontal tab bar (BF2 nav).
	local tabBar = vgui.Create("DHorizontalScroller", frame)
	tabBar:SetPos(margin, TABS_Y)
	tabBar:SetSize(ScrW() - margin * 2, 34)
	tabBar:SetOverlap(-16)
	tabBar:SetUseLiveDrag(true)
	tabBar.Paint = nil
	for _, arrow in ipairs({ tabBar.btnLeft, tabBar.btnRight }) do
		if IsValid(arrow) then
			arrow:SetText("")
			arrow.Paint = function(self, w, h)
				if not self:IsVisible() then return end
				MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
					color = self:IsHovered() and ui.hover or Color(0, 0, 0, 150),
					accent = ui.accent })
				draw.SimpleText(self == tabBar.btnLeft and "<" or ">", "MB.Small",
					w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	surface.SetFont("MB.Tab")
	for _, tab in ipairs(tabs) do
		local icon = ui.art.menuTabIcons[tab.name] or ui.art.menuTabIconDefault
		local iconSize = 20
		local tw = surface.GetTextSize(tab.name) + 30 + iconSize + 8

		local btn = vgui.Create("DButton")
		btn:SetWide(tw)
		btn:SetTall(34)
		btn:SetText("")
		btn.Paint = function(self, w, h)
			local active = activeTab == tab.name
			local col = (active or self:IsHovered()) and ui.text or ui.dim

			-- Icon left, label after it; centered label when no icon mounted.
			local drew = MilBase.DrawIcon(icon, 4, (h - iconSize) / 2,
				iconSize, iconSize, col)
			draw.SimpleText(tab.name, "MB.Tab",
				drew and (4 + iconSize + 6) or (w / 2), h / 2 - 1, col,
				drew and TEXT_ALIGN_LEFT or TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			if active then
				-- Glowing underline art (falls back to the flat bar + ticks).
				if not MilBase.DrawIcon(ui.art.bf2.underline, 0, h - 14, w, 14) then
					surface.SetDrawColor(ui.accent)
					surface.DrawRect(4, h - 3, w - 8, 3)
					surface.DrawRect(0, h - 9, 2, 9)
					surface.DrawRect(w - 2, h - 9, 2, 9)
				end
			elseif self:IsHovered() then
				surface.SetDrawColor(255, 198, 60, 90)
				surface.DrawRect(4, h - 3, w - 8, 2)
			end
		end
		btn.DoClick = function()
			MilBase.PlayUISound("select")
			setTab(tab)
		end
		tabBar:AddPanel(btn)
	end

	local close = vgui.Create("DButton", frame)
	close:SetText("")
	close:SetSize(150, BAR_H)
	close:SetPos(ScrW() - margin - 150, ScrH() - BAR_H)
	close.Paint = function(self, w, h)
		local col = self:IsHovered() and ui.text or ui.dim
		surface.SetFont("MB.Small")
		local tw = surface.GetTextSize("CLOSE  [ESC]")
		draw.SimpleText("CLOSE  [ESC]", "MB.Small", w, h / 2, col,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		MilBase.DrawIcon(ui.art.close, w - tw - 24, h / 2 - 8, 16, 16, col)
	end
	close.DoClick = closeMenu

	local initialTab = tabs[1]
	if preferredTab then
		for _, tab in ipairs(tabs) do
			if tab.name == preferredTab then initialTab = tab break end
		end
	end
	if initialTab then
		setTab(initialTab)
	elseif staffMode then
		local empty = vgui.Create("DLabel", content)
		empty:Dock(FILL)
		empty:SetFont("MB.Med")
		empty:SetContentAlignment(5)
		empty:SetTextColor(ui.dim)
		empty:SetText("No staff tools available to you.")
	end
end

function MilBase.OpenMenu(preferredTab) buildMenu(false, preferredTab) end
function MilBase.OpenStaffMenu(preferredTab) buildMenu(true, preferredTab) end

net.Receive("MilBase_OpenMenu", function()
	MilBase.OpenMenu()
end)

net.Receive("MilBase_OpenStaffMenu", function()
	MilBase.OpenStaffMenu()
end)
