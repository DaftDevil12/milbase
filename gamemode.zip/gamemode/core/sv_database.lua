--[[
	MilBase unified database layer.

	Everything in MilBase persists through this one API. By default it uses
	GMod's built-in SQLite (garrysmod/sv.db) - zero setup. If
	cfg.Database.Enabled is true AND the MySQLOO binary module is installed,
	it uses your MySQL / MariaDB server instead. If MySQL can't connect it
	falls back to SQLite so the server always runs.

	Public API (server):
	  MilBase.DB.Query(sql, onData, onError)  -- async; onData(rows|{})
	  MilBase.DB.Run(sql)                     -- fire-and-forget write
	  MilBase.SQLStr(value)                   -- escaped + quoted literal
	  MilBase.DB.IsMySQL()  /  MilBase.DB.Mode()

	IMPORTANT: MySQL work is deliberately processed in FIFO order. Gamemode
	modules create their tables during startup and players can connect while
	those migrations are still running. Starting every queued MySQLOO query at
	once allows a SELECT to overtake its CREATE TABLE and leaves character-load
	callbacks waiting forever. Serial execution preserves migration order while
	keeping the public API asynchronous.
]]

MilBase.DB = MilBase.DB or {}

local cfg = (MilBase.Config and MilBase.Config.Database) or {}

local mode = "sqlite" -- "sqlite" | "mysql"
local db              -- mysqloo Database object
local connected = false
local queue = {}      -- FIFO entries issued before/after connection
local active = false
local readyPending = false

local function log(msg, col)
	MsgC(col or Color(120, 200, 255), "[MilBase DB] ", color_white, msg .. "\n")
end

local function safeCallback(label, fn, ...)
	if not fn then return end
	local ok, err = pcall(fn, ...)
	if not ok then
		log(label .. " callback error: " .. tostring(err), Color(255, 90, 80))
	end
end

--------------------------------------------------------------------------
-- Backend selection
--------------------------------------------------------------------------

if cfg.Enabled then
	if pcall(require, "mysqloo") and mysqloo then
		mode = "mysql"
	else
		log("cfg.Database.Enabled is set but the MySQLOO module isn't installed.", Color(255, 170, 70))
		log("Download gmsv_mysqloo for your OS/branch and drop it in garrysmod/lua/bin/:", Color(255, 170, 70))
		log("  https://github.com/FredyH/MySQLOO/releases", Color(255, 170, 70))
		log("Falling back to SQLite for now.", Color(255, 170, 70))
	end
end

function MilBase.DB.Mode() return mode end
function MilBase.DB.IsMySQL() return mode == "mysql" end
function MilBase.DB.IsConnected() return mode ~= "mysql" or connected end
function MilBase.DB.QueueDepth() return #queue + (active and 1 or 0) end

--------------------------------------------------------------------------
-- Escaping: an escaped, QUOTED string literal for the active backend
--------------------------------------------------------------------------

function MilBase.SQLStr(value)
	if value == nil then return "NULL" end
	value = tostring(value)
	if mode == "mysql" and db and connected then
		return "'" .. db:escape(value) .. "'"
	end
	return sql.SQLStr(value) -- SQLite-style quoting is valid for queued MySQL literals too.
end

--------------------------------------------------------------------------
-- Ordered MySQL scheduler
--------------------------------------------------------------------------

local pumpMySQL

local function maybeSignalReady()
	if not readyPending or active or #queue > 0 then return end
	readyPending = false
	hook.Run("MilBase.DBReady")
end

pumpMySQL = function()
	if mode ~= "mysql" or not connected or active then return end
	if #queue == 0 then
		maybeSignalReady()
		return
	end

	local item = table.remove(queue, 1)
	active = true
	local query = db:query(item.sql)

	query.onSuccess = function(qobj, data)
		if item.kind == "insert" then
			local id = qobj.lastInsert and qobj:lastInsert() or nil
			safeCallback("insert", item.onDone, id)
		else
			safeCallback("query", item.onData, data or {})
		end
		active = false
		pumpMySQL()
	end

	query.onError = function(_, err)
		local prefix = item.kind == "insert" and "insert error: " or "query error: "
		log(prefix .. tostring(err) .. "\n  " .. tostring(item.sql), Color(255, 90, 80))
		if item.kind == "insert" then
			safeCallback("insert error", item.onDone, nil)
		else
			safeCallback("query error", item.onError, err)
		end
		active = false
		pumpMySQL()
	end

	local ok, err = pcall(function() query:start() end)
	if not ok then
		log("query start error: " .. tostring(err) .. "\n  " .. tostring(item.sql), Color(255, 90, 80))
		if item.kind == "insert" then
			safeCallback("insert start error", item.onDone, nil)
		else
			safeCallback("query start error", item.onError, err)
		end
		active = false
		pumpMySQL()
	end
end

local function enqueue(item)
	queue[#queue + 1] = item
	pumpMySQL()
end

--------------------------------------------------------------------------
-- Query
--------------------------------------------------------------------------

function MilBase.DB.Query(q, onData, onError)
	if mode == "mysql" then
		enqueue({ kind = "query", sql = q, onData = onData, onError = onError })
		return
	end

	-- SQLite is synchronous; deliver through the same callback contract.
	local res = sql.Query(q)
	if res == false then
		local err = sql.LastError()
		log("query error: " .. tostring(err) .. "\n  " .. tostring(q), Color(255, 90, 80))
		safeCallback("query error", onError, err)
	else
		safeCallback("query", onData, res or {})
	end
end

function MilBase.DB.Run(q)
	MilBase.DB.Query(q, nil, nil)
end

-- Cross-dialect auto-increment PRIMARY KEY column definition.
function MilBase.DB.AutoIncPK()
	return mode == "mysql" and "INTEGER PRIMARY KEY AUTO_INCREMENT"
		or "INTEGER PRIMARY KEY AUTOINCREMENT"
end

-- INSERT that returns the new auto-increment id via onDone(id). Handles the
-- MySQL (query:lastInsert()) vs SQLite (last_insert_rowid()) difference.
function MilBase.DB.Insert(q, onDone)
	if mode == "mysql" then
		enqueue({ kind = "insert", sql = q, onDone = onDone })
		return
	end

	local res = sql.Query(q)
	if res == false then
		log("insert error: " .. tostring(sql.LastError()) .. "\n  " .. tostring(q), Color(255, 90, 80))
		safeCallback("insert error", onDone, nil)
	else
		safeCallback("insert", onDone, tonumber(sql.QueryValue("SELECT last_insert_rowid()")))
	end
end

--------------------------------------------------------------------------
-- Connect (MySQL) / announce (SQLite)
--------------------------------------------------------------------------

local function drainQueueToSQLite()
	local pending = queue
	queue = {}
	active = false
	for _, item in ipairs(pending) do
		if item.kind == "insert" then
			MilBase.DB.Insert(item.sql, item.onDone)
		else
			MilBase.DB.Query(item.sql, item.onData, item.onError)
		end
	end
end

if mode == "mysql" then
	db = mysqloo.connect(cfg.Host or "127.0.0.1", cfg.User or "root",
		cfg.Pass or "", cfg.Name or "milbase", cfg.Port or 3306)

	db.onConnected = function()
		connected = true
		readyPending = true
		log("Connected to MySQL " .. (cfg.Host or "127.0.0.1") .. ":" .. (cfg.Port or 3306)
			.. "  (database '" .. (cfg.Name or "milbase") .. "')", Color(120, 230, 140))

		-- Queue the round-trip behind startup migrations. DBReady is emitted only
		-- after this initial FIFO has drained, so dependent modules see a schema
		-- that actually exists rather than merely an open socket.
		MilBase.DB.Query("CREATE TABLE IF NOT EXISTS milbase_dbtest "
			.. "(id INTEGER PRIMARY KEY AUTO_INCREMENT, boot TEXT)", function()
			MilBase.DB.Query("INSERT INTO milbase_dbtest (boot) VALUES ("
				.. MilBase.SQLStr(os.date("%Y-%m-%d %H:%M:%S")) .. ")", function()
				MilBase.DB.Query("SELECT COUNT(*) AS n FROM milbase_dbtest", function(rows)
					local n = rows[1] and rows[1].n or "?"
					log("self-test OK - milbase_dbtest now has " .. n .. " row(s).", Color(120, 230, 140))
				end)
			end)
		end)
		pumpMySQL()
	end

	db.onConnectionFailed = function(_, err)
		connected = false
		mode = "sqlite" -- keep the server running
		readyPending = false
		log("MySQL connection FAILED: " .. tostring(err), Color(255, 90, 80))
		log("Falling back to SQLite. Check cfg.Database in config/sh_config.lua.", Color(255, 170, 70))
		drainQueueToSQLite()
		hook.Run("MilBase.DBReady")
	end

	db:connect()

	-- MySQLOO 8 needs manual polling; MySQLOO 9 polls itself (no :poll).
	if db.poll then
		hook.Add("Think", "MilBase.DBPoll", function() db:poll() end)
	end

	-- Keepalive so the connection isn't dropped by MySQL's wait_timeout.
	timer.Create("MilBase.DBKeepAlive", 120, 0, function()
		if db and connected and db.ping then db:ping() end
	end)
else
	log("Using SQLite (garrysmod/sv.db). Set cfg.Database.Enabled = true + install "
		.. "MySQLOO to use your MySQL server.")
	timer.Simple(0, function() hook.Run("MilBase.DBReady") end)
end
