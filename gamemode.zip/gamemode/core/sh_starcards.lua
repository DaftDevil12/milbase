--[[
	Battlefront-style Star Card registry. File definitions and staff-created
	database cards share the same safe fields; file cards may additionally keep
	a server-only apply(ply) callback.
]]

MilBase.StarCards = MilBase.StarCards or {}
MilBase.StarCardOrder = MilBase.StarCardOrder or {}

MilBase.CardRarity = {
	common    = { name = "Common",    color = Color(170, 175, 180) },
	rare      = { name = "Rare",      color = Color(90, 160, 230) },
	epic      = { name = "Epic",      color = Color(170, 110, 220) },
	legendary = { name = "Legendary", color = Color(255, 198, 60) },
}

local function orderContains(id)
	for _, current in ipairs(MilBase.StarCardOrder) do if current == id then return true end end
	return false
end

function MilBase.RegisterStarCard(id, source)
	id = string.lower(string.Trim(tostring(id or "")))
	assert(id ~= "", "Star Card id is required")
	local data = table.Copy(source or {})
	data.id = id
	data.name = tostring(data.name or id)
	data.desc = tostring(data.desc or "")
	data.rarity = MilBase.CardRarity[data.rarity] and data.rarity or "common"
	data.health = math.max(0, math.floor(tonumber(data.health) or 0))
	data.armor = math.max(0, math.floor(tonumber(data.armor) or 0))
	data.loadout = istable(data.loadout) and data.loadout or {}
	data.issue = MilBase.CopyCountMap(data.issue, 1000)
	data.attachments = MilBase.CopyCountMap(data.attachments, 1000)
	if not orderContains(id) then table.insert(MilBase.StarCardOrder, id) end
	MilBase.StarCards[id] = data
	return data
end

function MilBase.RemoveStarCard(id)
	id = string.lower(string.Trim(tostring(id or "")))
	if not MilBase.StarCards[id] then return false end
	MilBase.StarCards[id] = nil
	for index = #MilBase.StarCardOrder, 1, -1 do
		if MilBase.StarCardOrder[index] == id then table.remove(MilBase.StarCardOrder, index) end
	end
	return true
end

function MilBase.GetStarCard(id)
	return MilBase.StarCards[id]
end

function MilBase.CardAvailable(ply, card)
	if not card then return false end
	if card.faction and card.faction ~= "" and ply:MBFactionID() ~= card.faction then return false end
	if card.cert and card.cert ~= "" and not ply:MBHasCert(card.cert) then return false end
	return true
end

function MilBase.CardGrantsText(card)
	local parts = {}
	if (card.health or 0) > 0 then parts[#parts + 1] = "+" .. card.health .. " health" end
	if (card.armor or 0) > 0 then parts[#parts + 1] = "+" .. card.armor .. " armor" end
	for _, class in ipairs(card.loadout or {}) do
		parts[#parts + 1] = MilBase.WeaponDisplayName(class)
	end
	for id, amount in pairs(card.issue or {}) do
		local item = MilBase.Items and MilBase.Items[id]
		parts[#parts + 1] = (item and item.name or id) .. " x" .. amount
	end
	for id, amount in pairs(card.attachments or {}) do
		parts[#parts + 1] = MilBase.ArcCWAttachmentName(id) .. " x" .. amount
	end
	if card.grantsText and card.grantsText ~= "" then parts[#parts + 1] = card.grantsText end
	return table.concat(parts, "  •  ")
end
