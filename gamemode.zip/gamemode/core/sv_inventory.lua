--[[
	Server-authoritative inventory: the STASH grid, the equipped BACKPACK
	grid, and EQUIPMENT slots (head / armor / backpack).

	Equipped armor grants armor points and can swap the playermodel or
	apply bodygroups (see config/sh_items.lua). Backpacks add a second
	grid; they must be emptied before unequipping.
]]

local cfg = MilBase.Config

util.AddNetworkString("MilBase_InvSync")
util.AddNetworkString("MilBase_InvMove")
util.AddNetworkString("MilBase_InvUse")
util.AddNetworkString("MilBase_InvDrop")
util.AddNetworkString("MilBase_InvEquip")
util.AddNetworkString("MilBase_InvUnequip")

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_inventories (
	steamid VARCHAR(32) PRIMARY KEY,
	data TEXT
)]])

local function newInv()
	return { w = cfg.InventoryWidth, h = cfg.InventoryHeight, items = {}, equip = {} }
end

function MilBase.GetInventory(ply)
	ply.mb_inv = ply.mb_inv or newInv()
	return ply.mb_inv
end

function MilBase.SaveInventory(ply)
	if MilBase.StoreJetpackItemState then MilBase.StoreJetpackItemState(ply) end
	-- While the player is an event enemy their live inventory is a throwaway
	-- scratch container; the real one is stashed in mb_realInv and is what we
	-- persist, so staff-issued event gear never touches their character.
	local inv = ply.mb_realInv or ply.mb_inv
	if not inv then return end -- only set once the async load completed
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_inventories (steamid, data) VALUES (%s, %s)",
		MilBase.SQLStr(ply:MBCharacterKey()),
		MilBase.SQLStr(util.TableToJSON(inv))
	))
end

--------------------------------------------------------------------------
-- Event-enemy scratch inventory
--
-- When a player becomes a playable event enemy they get an empty, throwaway
-- inventory so staff can issue them event-only gear. The real character's
-- inventory is stashed (and still persisted) until they revert.
--------------------------------------------------------------------------

function MilBase.EnterEventInventory(ply)
	if ply.mb_realInv then return end -- already using a scratch inventory
	ply.mb_realInv = MilBase.GetInventory(ply) -- ensures the real inv exists
	ply.mb_realInvUID = ply.mb_invUID or 0
	ply.mb_inv = newInv()
	ply.mb_invUID = 0
	MilBase.SyncInventory(ply)
end

function MilBase.ExitEventInventory(ply)
	if not ply.mb_realInv then return end
	ply.mb_inv = ply.mb_realInv
	ply.mb_invUID = ply.mb_realInvUID or 0
	ply.mb_realInv = nil
	ply.mb_realInvUID = nil
	MilBase.SyncInventory(ply)
end

function MilBase.SyncInventory(ply)
	net.Start("MilBase_InvSync")
		net.WriteString(util.TableToJSON(MilBase.GetInventory(ply)))
	net.Send(ply)
end

function MilBase.MarkInvDirty(ply)
	MilBase.SaveInventory(ply)
	MilBase.SyncInventory(ply)
end

function MilBase.LoadInventory(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	MilBase.DB.Query(string.format(
		"SELECT data FROM frontier_inventories WHERE steamid = %s",
		MilBase.SQLStr(key)), function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		local row = rows[1]

		local isNew = row == nil
		ply.mb_inv = (row and util.JSONToTable(row.data)) or newInv()

		local inv = ply.mb_inv
		inv.w = cfg.InventoryWidth
		inv.h = cfg.InventoryHeight
		inv.items = inv.items or {}
		inv.equip = inv.equip or {}

		-- Drop equipment whose definitions no longer exist; rebuild the
		-- backpack grid dims from the equipped backpack.
		for slot, it in pairs(inv.equip) do
			if not MilBase.Items[it.id] then inv.equip[slot] = nil end
		end
		local pack = inv.equip.backpack and MilBase.Items[inv.equip.backpack.id]
		if pack and pack.storage then
			inv.pack = inv.pack or { items = {} }
			inv.pack.w = pack.storage.w
			inv.pack.h = pack.storage.h
			inv.pack.items = inv.pack.items or {}
		else
			inv.pack = nil
		end

		-- Recover the uid counter across every container.
		ply.mb_invUID = 0
		for _, it in ipairs(inv.items) do
			ply.mb_invUID = math.max(ply.mb_invUID, it.uid or 0)
		end
		for _, it in ipairs(inv.pack and inv.pack.items or {}) do
			ply.mb_invUID = math.max(ply.mb_invUID, it.uid or 0)
		end
		for _, it in pairs(inv.equip) do
			ply.mb_invUID = math.max(ply.mb_invUID, it.uid or 0)
		end

		if isNew then
			for id, amount in pairs(cfg.StarterItems or {}) do
				MilBase.GiveItem(ply, id, amount)
			end
		end

		MilBase.SyncInventory(ply)
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "inv") end
	end, function()
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		ply.mb_inv = newInv()
		ply.mb_invUID = 0
		MilBase.SyncInventory(ply)
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "inv") end
	end)
end

--------------------------------------------------------------------------
-- Container helpers
--------------------------------------------------------------------------

local function getContainer(inv, id)
	if id == "pack" then return inv.pack end
	return inv
end

-- Finds an item by uid in stash or backpack. Returns item, container,
-- index, containerID.
function MilBase.InvFindAny(inv, uid)
	local item, index = MilBase.InvFind(inv, uid)
	if item then return item, inv, index, "stash" end

	if inv.pack then
		item, index = MilBase.InvFind(inv.pack, uid)
		if item then return item, inv.pack, index, "pack" end
	end
end

local function findEquipped(inv, uid)
	for slot, it in pairs(inv.equip or {}) do
		if it.uid == uid then return it, slot end
	end
end

--------------------------------------------------------------------------
-- Item API
--------------------------------------------------------------------------

function MilBase.GiveItem(ply, id, amount, charges)
	local def = MilBase.Items[id]
	if not def then return 0 end

	amount = amount or 1
	local inv = MilBase.GetInventory(ply)
	local given = 0

	local containers = { inv }
	if inv.pack then table.insert(containers, inv.pack) end

	if def.stack > 1 then
		for _, container in ipairs(containers) do
			for _, it in ipairs(container.items) do
				if amount <= 0 then break end
				if it.id == id and it.amount < def.stack then
					local add = math.min(def.stack - it.amount, amount)
					it.amount = it.amount + add
					amount = amount - add
					given = given + add
				end
			end
		end
	end

	for _, container in ipairs(containers) do
		while amount > 0 do
			local x, y, rot = MilBase.InvFindFreeSlot(container, def)
			if not x then break end

			local put = math.min(def.stack, amount)
			ply.mb_invUID = (ply.mb_invUID or 0) + 1
			table.insert(container.items, {
				uid = ply.mb_invUID, id = id, x = x, y = y, rot = rot or false,
				amount = put, charges = charges or def.charges,
			})
			amount = amount - put
			given = given + put
		end
	end

	if given > 0 then MilBase.MarkInvDirty(ply) end
	return given
end

-- Adds one exact, non-stacking item instance while preserving custom fields.
-- Used by reusable equipment such as jetpacks when picked back up after a drop.
function MilBase.GiveItemInstance(ply, source)
	if not istable(source) then return 0 end
	local def = MilBase.Items[source.id]
	if not def then return 0 end

	local inv = MilBase.GetInventory(ply)
	local containers = { inv }
	if inv.pack then containers[#containers + 1] = inv.pack end

	for _, container in ipairs(containers) do
		local x, y, rot = MilBase.InvFindFreeSlot(container, def)
		if x then
			ply.mb_invUID = (ply.mb_invUID or 0) + 1
			local item = table.Copy(source)
			item.uid = ply.mb_invUID
			item.x, item.y, item.rot = x, y, rot or false
			item.amount = math.max(1, math.floor(tonumber(item.amount) or 1))
			table.insert(container.items, item)
			MilBase.MarkInvDirty(ply)
			return item.amount
		end
	end

	return 0
end

-- Counts across stash, backpack AND equipped (so standard-issue top-ups
-- don't duplicate worn armor).
function MilBase.CountItem(ply, id)
	local inv = MilBase.GetInventory(ply)
	local total = 0

	for _, it in ipairs(inv.items) do
		if it.id == id then total = total + it.amount end
	end
	for _, it in ipairs(inv.pack and inv.pack.items or {}) do
		if it.id == id then total = total + it.amount end
	end
	for _, it in pairs(inv.equip or {}) do
		if it.id == id then total = total + (it.amount or 1) end
	end

	return total
end

function MilBase.RemoveItemUID(ply, uid, amount)
	local inv = MilBase.GetInventory(ply)
	local item, container, index = MilBase.InvFindAny(inv, uid)
	if not item then return end

	if amount and item.amount > amount then
		item.amount = item.amount - amount
	else
		table.remove(container.items, index)
	end
	MilBase.MarkInvDirty(ply)
end

function MilBase.TakeItem(ply, id, amount)
	local inv = MilBase.GetInventory(ply)
	local removed = 0
local infiniteMedical = {
    bandage = true,
    splint = true,
    ifak = true,
    surgical_kit = true,
}

if infiniteMedical[id] and ply:GetNWBool("IsMedic") then
    return amount
end
	local containers = { inv }
	if inv.pack then table.insert(containers, inv.pack) end

	for _, container in ipairs(containers) do
		for i = #container.items, 1, -1 do
			if removed >= amount then break end
			local it = container.items[i]
			if it.id == id then
				local take = math.min(it.amount, amount - removed)
				it.amount = it.amount - take
				removed = removed + take
				if it.amount <= 0 then table.remove(container.items, i) end
			end
		end
	end

	if removed > 0 then MilBase.MarkInvDirty(ply) end
	return removed
end

function MilBase.TopUpIssue(ply)
	if not ply.mb_inv then return end

	local faction = ply:MBFaction()
	local rank = ply:MBRank()

	local issue = {}
	for id, n in pairs((faction and faction.issue) or {}) do
		issue[id] = math.max(issue[id] or 0, n)
	end
	for id, n in pairs((rank and rank.issue) or {}) do
		issue[id] = math.max(issue[id] or 0, n)
	end
	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[certID]
		for id, n in pairs((cert and cert.issue) or {}) do
			issue[id] = math.max(issue[id] or 0, n)
		end
	end
	-- Equipped star cards can issue items too.
	if MilBase.StarCardIssue then MilBase.StarCardIssue(ply, issue) end

	for id, n in pairs(issue) do
		local missing = n - MilBase.CountItem(ply, id)
		if missing > 0 then MilBase.GiveItem(ply, id, missing) end
	end
end

--------------------------------------------------------------------------
-- Equipment: armor points, model swaps, bodygroups, backpack grid
--------------------------------------------------------------------------

function MilBase.ApplyEquipment(ply)
	if not ply:Alive() then return end
	local inv = MilBase.GetInventory(ply)

	-- Armor points
	local armor = 0
	for _, it in pairs(inv.equip or {}) do
		local def = MilBase.Items[it.id]
		if def and def.armor then armor = armor + def.armor end
	end
	ply:SetArmor(math.min(armor, math.max(0, tonumber(cfg.ArmorMaximum) or 255)))

	-- Model override
	local model = MilBase.GetPlayerModel(ply)
	for _, it in pairs(inv.equip or {}) do
		local def = MilBase.Items[it.id]
		if def and def.playerModel then model = def.playerModel end
	end
	if ply:GetModel() ~= model then
		ply:SetModel(model)
		ply:SetupHands()
	end

	-- Bodygroups: reset, then the player's own (unlock-checked) choices, then
	-- equipped gear overrides its own slots (armor wins).
	for i = 0, ply:GetNumBodyGroups() - 1 do
		ply:SetBodygroup(i, 0)
	end
	if MilBase.ApplyAppearance then MilBase.ApplyAppearance(ply) end
	for _, it in pairs(inv.equip or {}) do
		local def = MilBase.Items[it.id]
		for index, value in pairs((def and def.bodygroups) or {}) do
			ply:SetBodygroup(tonumber(index) or 0, tonumber(value) or 0)
		end
	end

	-- Flag a worn helmet (the CCTV system exposes a helmet cam when set).
	ply:SetNWBool("mb_helmet", (inv.equip and inv.equip.head) ~= nil)

	-- Optional equipment modules can synchronize their runtime state from a
	-- persistent inventory slot here. The jetpack uses this on equip, spawn,
	-- character load and manual unequip.
	if MilBase.SyncJetpackEquipment then
		MilBase.SyncJetpackEquipment(ply, inv.equip and inv.equip.jetpack or nil)
	end
end

-- Returns the equipped item to a grid. false if there's no room.
function MilBase.StowEquipped(ply, slot)
	local inv = MilBase.GetInventory(ply)
	local item = inv.equip[slot]
	if not item then return true end

	local def = MilBase.Items[item.id]
	if not def then
		inv.equip[slot] = nil
		return true
	end

	if slot == "backpack" and inv.pack and #inv.pack.items > 0 then
		MilBase.Notify(ply, "Empty your backpack first.")
		return false
	end

	local containers = { inv }
	if inv.pack and slot ~= "backpack" then table.insert(containers, inv.pack) end

	for _, container in ipairs(containers) do
		local x, y, rot = MilBase.InvFindFreeSlot(container, def)
		if x then
			item.x, item.y, item.rot = x, y, rot or false
			table.insert(container.items, item)
			inv.equip[slot] = nil
			if slot == "backpack" then inv.pack = nil end
			return true
		end
	end

	MilBase.Notify(ply, "No room in your gear to stow that.")
	return false
end

net.Receive("MilBase_InvEquip", function(_, ply)
	local uid = net.ReadUInt(16)
	if not ply:Alive() or ply:GetNWBool("mb_cuffed", false) then return end

	local inv = MilBase.GetInventory(ply)
	local item, container, index = MilBase.InvFindAny(inv, uid)
	local def = item and MilBase.Items[item.id]
	if not def or not def.slot then return end

	if def.canEquip then
		local ok, reason = def.canEquip(ply, item)
		if ok == false then
			MilBase.Notify(ply, reason or "That item cannot be equipped right now.")
			MilBase.SyncInventory(ply)
			return
		end
	end

	-- Anything in the slot goes back to the grid first.
	if inv.equip[def.slot] and not MilBase.StowEquipped(ply, def.slot) then
		MilBase.SyncInventory(ply)
		return
	end

	table.remove(container.items, index)
	item.x, item.y, item.rot = nil, nil, false
	inv.equip[def.slot] = item

	if def.slot == "backpack" and def.storage then
		inv.pack = { w = def.storage.w, h = def.storage.h, items = {} }
	end

	MilBase.ApplyEquipment(ply)
	MilBase.MarkInvDirty(ply)
	ply:EmitSound("npc/combine_soldier/gear" .. math.random(3, 6) .. ".wav", 60)
end)

function MilBase.UnequipEquipmentSlot(ply, slot)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	local inv = MilBase.GetInventory(ply)
	local item = inv.equip and inv.equip[slot]
	if not item then return false end
	local def = MilBase.Items[item.id]

	if def and def.canUnequip then
		local ok, reason = def.canUnequip(ply, item)
		if ok == false then
			MilBase.Notify(ply, reason or "That item cannot be removed right now.")
			return false
		end
	end

	if slot == "jetpack" and MilBase.StoreJetpackItemState then
		MilBase.StoreJetpackItemState(ply)
	end

	if not MilBase.StowEquipped(ply, slot) then return false end
	MilBase.ApplyEquipment(ply)
	MilBase.MarkInvDirty(ply)
	return true
end

net.Receive("MilBase_InvUnequip", function(_, ply)
	local slot = net.ReadString()
	if not ply:Alive() or ply:GetNWBool("mb_cuffed", false) then return end

	local inv = MilBase.GetInventory(ply)
	if not inv.equip[slot] then return end

	MilBase.UnequipEquipmentSlot(ply, slot)
end)

--------------------------------------------------------------------------
-- Net handlers: move / use / drop
--------------------------------------------------------------------------

net.Receive("MilBase_InvMove", function(_, ply)
	local uid = net.ReadUInt(16)
	local destID = net.ReadString()
	local x = net.ReadUInt(8)
	local y = net.ReadUInt(8)
	local rot = net.ReadBool()

	local inv = MilBase.GetInventory(ply)
	local item, srcContainer, srcIndex = MilBase.InvFindAny(inv, uid)
	local def = item and MilBase.Items[item.id]
	local dest = getContainer(inv, destID)

	if not def or not dest then
		MilBase.SyncInventory(ply)
		return
	end
	if def.w == def.h then rot = false end

	local ok, blockers = MilBase.InvCanPlace(dest, def, x, y, rot, uid)

	if ok then
		table.remove(srcContainer.items, srcIndex)
		item.x, item.y, item.rot = x, y, rot
		table.insert(dest.items, item)
		MilBase.MarkInvDirty(ply)
	elseif #blockers == 1 and blockers[1].id == item.id and def.stack > 1 then
		local target = blockers[1]
		local moved = math.min(def.stack - target.amount, item.amount)
		if moved > 0 then
			target.amount = target.amount + moved
			item.amount = item.amount - moved
			if item.amount <= 0 then
				table.remove(srcContainer.items, srcIndex)
			end
		end
		MilBase.MarkInvDirty(ply)
	else
		MilBase.SyncInventory(ply)
	end
end)

net.Receive("MilBase_InvUse", function(_, ply)
	local uid = net.ReadUInt(16)
	local limb = net.ReadString()
	local hasTarget = net.ReadBool()
	local patient = hasTarget and net.ReadEntity() or nil

	if not ply:Alive() then return end
	if ply:GetNWBool("mb_wounded", false) then
		MilBase.Notify(ply, "You are too badly hurt to do that.")
		return
	end
	if ply:GetNWBool("mb_cuffed", false) then
		MilBase.Notify(ply, "You are restrained.")
		return
	end

	local item = MilBase.InvFindAny(MilBase.GetInventory(ply), uid)
	local def = item and MilBase.Items[item.id]
	if not def then return end

	if def.cert and not ply:MBHasCert(def.cert) then
		local cert = MilBase.Certs[def.cert]
		MilBase.Notify(ply, "Requires certification: " .. (cert and cert.name or def.cert))
		return
	end

	if def.type == "medical" and MilBase.UseMedicalItem then
		MilBase.UseMedicalItem(ply, item, limb ~= "" and limb or nil, patient)
	elseif def.type == "engineering" and MilBase.UseEngineeringItem then
		MilBase.UseEngineeringItem(ply, item)
	elseif def.onUse then
		if def.onUse(ply, item) ~= false then
			MilBase.RemoveItemUID(ply, uid, 1)
		end
	end
end)

net.Receive("MilBase_InvDrop", function(_, ply)
	local uid = net.ReadUInt(16)
	if not ply:Alive() then return end

	local item = MilBase.InvFindAny(MilBase.GetInventory(ply), uid)
	local def = item and MilBase.Items[item.id]
	if not def then return end

	if MilBase.Config.QuartermasterPreventArmorDrops ~= false
		and def.slot == "armor"
		and MilBase.QuartermasterIsManagedItem
		and MilBase.QuartermasterIsManagedItem(item.id) then
		MilBase.Notify(ply, "Standard-issue armor cannot be dropped. Visit the Quartermaster to exchange it.")
		return
	end

	local ent = ents.Create("mb_item")
	if not IsValid(ent) then return end

	ent:SetItemID(item.id)
	ent:SetAmount(item.amount)
	ent.mb_charges = item.charges
	if def.jetpack then ent.mb_itemState = table.Copy(item) end
	ent:SetPos(ply:EyePos() + ply:GetAimVector() * 25)
	ent:Spawn()

	local phys = ent:GetPhysicsObject()
	if IsValid(phys) then
		phys:SetVelocity(ply:GetAimVector() * 120)
	end

	MilBase.RemoveItemUID(ply, uid) -- whole stack
end)

--------------------------------------------------------------------------
-- Lifecycle
--------------------------------------------------------------------------

hook.Add("PlayerInitialSpawn", "MilBase.LoadInventory", function(ply)
	MilBase.LoadInventory(ply)
end)

hook.Add("PlayerDisconnected", "MilBase.SaveInventory", function(ply)
	MilBase.SaveInventory(ply)
end)

hook.Add("ShutDown", "MilBase.SaveAllInventories", function()
	for _, ply in ipairs(player.GetAll()) do
		MilBase.SaveInventory(ply)
	end
end)

local giveItemCommand = {
	help = "(Admin) Give an item: /giveitem <player> <item name> [amount]",
	adminOnly = true,
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		local itemQuery = string.Trim(table.concat(args, " ", 2))
		local amount = 1

		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end

		local trailingAmount = string.match(itemQuery, "%s+(%d+)%s*$")
		if trailingAmount then
			amount = math.Clamp(math.floor(tonumber(trailingAmount) or 1), 1, 1000)
			itemQuery = string.Trim(string.sub(itemQuery, 1, #itemQuery - #trailingAmount))
		end

		local id, def, err, matches = MilBase.FindItemByName(itemQuery)
		if not id then
			if err == "ambiguous" and matches then
				local names = {}
				for i, match in ipairs(matches) do
					if i > 8 then break end
					names[#names + 1] = match.def.name or match.id
				end
				MilBase.Notify(ply, "Multiple items match that name: " .. table.concat(names, ", "))
			else
				MilBase.Notify(ply, "Unknown item name: " .. itemQuery)
			end
			return
		end

		local given = MilBase.GiveItem(target, id, amount)
		MilBase.Notify(ply, "Gave " .. given .. "x " .. def.name
			.. " to " .. target:MBName() .. (given < amount and " (inventory full)" or ""))
	end,
}

MilBase.RegisterChatCommand("giveitem", table.Copy(giveItemCommand))
MilBase.RegisterChatCommand("giveitems", table.Copy(giveItemCommand))
