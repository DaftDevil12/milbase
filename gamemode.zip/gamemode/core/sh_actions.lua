--[[
	Interaction registries (core, so any module can register actions
	regardless of module load order). The behavior lives in modules:
	  - modules/sh_interactions.lua  (C + right-click / scoreboard menu)
	  - modules/sh_quickinteract.lua (hold-E scroll menu, target players/vehicles)
	  - modules/sh_selfmenu.lua      (hold-G scroll menu, actions on yourself)
	If those modules are removed, registrations are harmless no-ops.
]]

--------------------------------------------------------------------------
-- Context menu actions (C + right-click a player, or scoreboard click)
--------------------------------------------------------------------------

MilBase.PlayerActions = MilBase.PlayerActions or {}
MilBase.PlayerActionOrder = MilBase.PlayerActionOrder or {}

function MilBase.RegisterPlayerAction(id, data)
	data.id = id
	data.name = data.name or id
	data.order = data.order or 50

	if not MilBase.PlayerActions[id] then
		table.insert(MilBase.PlayerActionOrder, id)
	end
	MilBase.PlayerActions[id] = data

	table.sort(MilBase.PlayerActionOrder, function(a, b)
		return MilBase.PlayerActions[a].order < MilBase.PlayerActions[b].order
	end)
end

--------------------------------------------------------------------------
-- Quick interactions (hold E, scroll, release; vehicle = true for LVS)
--------------------------------------------------------------------------

MilBase.QuickInteractions = MilBase.QuickInteractions or {}
MilBase.QuickOrder = MilBase.QuickOrder or {}

function MilBase.RegisterQuickInteraction(id, data)
	data.id = id
	data.order = data.order or 50

	if not MilBase.QuickInteractions[id] then
		table.insert(MilBase.QuickOrder, id)
	end
	MilBase.QuickInteractions[id] = data

	table.sort(MilBase.QuickOrder, function(a, b)
		return MilBase.QuickInteractions[a].order < MilBase.QuickInteractions[b].order
	end)
end

--------------------------------------------------------------------------
-- Self actions (hold G, scroll, release - actions on yourself)
--   { name, order, visible(lp), run(ply) [server], client(lp) [client] }
--------------------------------------------------------------------------

MilBase.SelfActions = MilBase.SelfActions or {}
MilBase.SelfOrder = MilBase.SelfOrder or {}

function MilBase.RegisterSelfAction(id, data)
	data.id = id
	data.order = data.order or 50

	if not MilBase.SelfActions[id] then
		table.insert(MilBase.SelfOrder, id)
	end
	MilBase.SelfActions[id] = data

	table.sort(MilBase.SelfOrder, function(a, b)
		return MilBase.SelfActions[a].order < MilBase.SelfActions[b].order
	end)
end
