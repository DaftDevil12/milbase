--[[
	Progression backend: unlocked star cards, the equipped loadout, XP,
	and boosters. Persisted in SQLite. Drives the LOADOUT and CRATES tabs.
]]

local cfg = MilBase.Config

util.AddNetworkString("MilBase_Unlocks")
util.AddNetworkString("MilBase_EquipCard")
util.AddNetworkString("MilBase_OpenCrate")
util.AddNetworkString("MilBase_CrateResult")

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_unlocks (
	steamid VARCHAR(32), card VARCHAR(64), PRIMARY KEY (steamid, card)
)]])
MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_progress (
	steamid VARCHAR(32) PRIMARY KEY, xp INTEGER, equipped TEXT,
	booster_mult REAL, booster_expires INTEGER
)]])

--------------------------------------------------------------------------
-- Load / save
--------------------------------------------------------------------------

local function syncUnlocks(ply)
	net.Start("MilBase_Unlocks")
		net.WriteTable(ply.mb_unlocked or {})
	net.Send(ply)
end

local function pushEquipped(ply)
	ply:SetNWString("mb_equipped", table.concat(ply.mb_equipped or {}, ","))
end

function MilBase.LoadProgress(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	local sid = MilBase.SQLStr(key)
	local finished = false

	local function defaults()
		if finished or not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		finished = true
		ply.mb_unlocked = ply.mb_unlocked or {}
		ply.mb_equipped = {}
		ply:SetNWInt("mb_xp", 0)
		ply:SetNWFloat("mb_booster_mult", 1)
		ply:SetNWInt("mb_booster_expires", 0)
		pushEquipped(ply)
		syncUnlocks(ply)
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "progress") end
	end

	MilBase.DB.Query("SELECT card FROM frontier_unlocks WHERE steamid = " .. sid, function(unlockRows)
		if finished or not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		ply.mb_unlocked = {}
		for _, r in ipairs(unlockRows or {}) do ply.mb_unlocked[r.card] = true end

		MilBase.DB.Query("SELECT * FROM frontier_progress WHERE steamid = " .. sid, function(progRows)
			if finished or not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			finished = true
			local row = progRows[1]
			ply.mb_equipped = {}
			if row then
				for id in string.gmatch(row.equipped or "", "([^,]+)") do
					ply.mb_equipped[#ply.mb_equipped + 1] = id
				end
				ply:SetNWInt("mb_xp", tonumber(row.xp) or 0)
				ply:SetNWFloat("mb_booster_mult", tonumber(row.booster_mult) or 1)
				ply:SetNWInt("mb_booster_expires", tonumber(row.booster_expires) or 0)
			else
				ply:SetNWInt("mb_xp", 0)
				ply:SetNWFloat("mb_booster_mult", 1)
				ply:SetNWInt("mb_booster_expires", 0)
			end

			pushEquipped(ply)
			syncUnlocks(ply)
			if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "progress") end
		end, defaults)
	end, defaults)
end

function MilBase.SaveProgress(ply)
	if not ply.mb_equipped then return end -- only set once the async load completed
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_progress (steamid, xp, equipped, booster_mult, booster_expires) VALUES (%s, %d, %s, %f, %d)",
		MilBase.SQLStr(ply:MBCharacterKey()), ply:GetNWInt("mb_xp", 0),
		MilBase.SQLStr(table.concat(ply.mb_equipped, ",")),
		ply:GetNWFloat("mb_booster_mult", 1), ply:GetNWInt("mb_booster_expires", 0)))
end

hook.Add("PlayerInitialSpawn", "MilBase.LoadProgress", function(ply)
	MilBase.LoadProgress(ply)
end)
hook.Add("PlayerDisconnected", "MilBase.SaveProgress", function(ply)
	MilBase.SaveProgress(ply)
end)

--------------------------------------------------------------------------
-- Unlocks
--------------------------------------------------------------------------

function MilBase.IsCardUnlocked(ply, id)
	return (ply.mb_unlocked or {})[id] == true
end

function MilBase.UnlockCard(ply, id, silent)
	if not MilBase.GetStarCard(id) then return false end
	if MilBase.IsCardUnlocked(ply, id) then return false end

	ply.mb_unlocked = ply.mb_unlocked or {}
	ply.mb_unlocked[id] = true
	MilBase.DB.Run(string.format("REPLACE INTO frontier_unlocks (steamid, card) VALUES (%s, %s)",
		MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(id)))
	syncUnlocks(ply)

	if not silent then
		MilBase.Notify(ply, "Star Card unlocked: " .. MilBase.GetStarCard(id).name)
	end
	return true
end

-- A locked card this player could actually use (for crate "card" rolls).
local function randomLockedCard(ply, pool)
	local candidates = {}
	for _, id in ipairs(pool or MilBase.StarCardOrder) do
		local card = MilBase.GetStarCard(id)
		if card and not MilBase.IsCardUnlocked(ply, id) and MilBase.CardAvailable(ply, card) then
			candidates[#candidates + 1] = id
		end
	end
	if #candidates == 0 then return nil end
	return candidates[math.random(#candidates)]
end

--------------------------------------------------------------------------
-- Equipped loadout
--------------------------------------------------------------------------

function MilBase.GetEquippedCards(ply)
	return ply.mb_equipped or {}
end

net.Receive("MilBase_EquipCard", function(_, ply)
	local slot = net.ReadUInt(4)
	local id = net.ReadString()
	local slots = cfg.StarCardSlots or 3
	if slot < 1 or slot > slots then return end

	ply.mb_equipped = ply.mb_equipped or {}

	if id == "" then
		ply.mb_equipped[slot] = nil
	else
		local card = MilBase.GetStarCard(id)
		if not card or not MilBase.IsCardUnlocked(ply, id) or not MilBase.CardAvailable(ply, card) then
			return
		end
		-- No duplicates across slots.
		for s, cid in pairs(ply.mb_equipped) do
			if cid == id and s ~= slot then ply.mb_equipped[s] = nil end
		end
		ply.mb_equipped[slot] = id
	end

	-- Compact to a dense array preserving slot order.
	local dense = {}
	for s = 1, slots do dense[#dense + 1] = ply.mb_equipped[s] end
	ply.mb_equipped = dense

	pushEquipped(ply)
	MilBase.SaveProgress(ply)
	if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end
end)

--------------------------------------------------------------------------
-- Applying cards (health / loadout / issue / custom) - called by the
-- spawn pipeline in sv_player / sv_inventory / sh_certs.
--------------------------------------------------------------------------

local function equippedCards(ply)
	local out = {}
	for _, id in ipairs(ply.mb_equipped or {}) do
		local card = MilBase.GetStarCard(id)
		if card and MilBase.CardAvailable(ply, card) then out[#out + 1] = card end
	end
	return out
end

function MilBase.StarCardHealth(ply)
	local hp = 0
	for _, card in ipairs(equippedCards(ply)) do hp = hp + (card.health or 0) end
	return hp
end

function MilBase.StarCardLoadout(ply)
	local out = {}
	for _, card in ipairs(equippedCards(ply)) do
		for _, class in ipairs(card.loadout or {}) do out[#out + 1] = class end
	end
	return out
end

function MilBase.StarCardIssue(ply, into)
	for _, card in ipairs(equippedCards(ply)) do
		for id, n in pairs(card.issue or {}) do
			into[id] = math.max(into[id] or 0, n)
		end
	end
	return into
end

function MilBase.StarCardAttachments(ply, into)
	into = into or {}
	for _, card in ipairs(equippedCards(ply)) do
		for id, amount in pairs(card.attachments or {}) do
			id = MilBase.ArcCWCanonicalAttachment(id)
			into[id] = math.max(into[id] or 0, amount)
		end
	end
	return into
end

function MilBase.ApplyStarCards(ply)
	for _, card in ipairs(equippedCards(ply)) do
		if (card.armor or 0) > 0 then
			ply:SetArmor(math.min(255, ply:Armor() + card.armor))
		end
		if card.apply then card.apply(ply) end
	end
end

--------------------------------------------------------------------------
-- XP & boosters
--------------------------------------------------------------------------

function MilBase.GetBoosterMult(ply)
	if ply:GetNWInt("mb_booster_expires", 0) > os.time() then
		return ply:GetNWFloat("mb_booster_mult", 1)
	end
	return 1
end

function MilBase.GrantBooster(ply, mult, seconds)
	ply:SetNWFloat("mb_booster_mult", mult)
	ply:SetNWInt("mb_booster_expires", os.time() + seconds)
	MilBase.SaveProgress(ply)
	MilBase.Notify(ply, string.format("Booster active: x%.2g for %d min.", mult, math.floor(seconds / 60)))
end

function MilBase.AwardXP(ply, base)
	local amt = math.floor(base * MilBase.GetBoosterMult(ply))
	ply:SetNWInt("mb_xp", ply:GetNWInt("mb_xp", 0) + amt)
	return amt
end

function MilBase.AwardCredits(ply, base)
	local amt = math.floor(base * MilBase.GetBoosterMult(ply))
	ply:MBAddMoney(amt)
	return amt
end

--------------------------------------------------------------------------
-- Crates
--------------------------------------------------------------------------

local function grantReward(ply, entry)
	if entry.type == "card" then
		local id = randomLockedCard(ply, entry.pool)
		if id then
			MilBase.UnlockCard(ply, id, true)
			return { type = "card", id = id }
		end
		-- Nothing left to unlock: fall back to credits.
		MilBase.AwardCredits(ply, entry.fallback or 100)
		return { type = "credits", amount = entry.fallback or 100 }

	elseif entry.type == "item" then
		MilBase.GiveItem(ply, entry.id, entry.amount or 1)
		return { type = "item", id = entry.id, amount = entry.amount or 1 }

	elseif entry.type == "attachment" then
		if MilBase.GrantArcCWAttachment and MilBase.GrantArcCWAttachment(ply, entry.id, entry.amount or 1) then
			return { type = "attachment", id = entry.id, amount = entry.amount or 1 }
		end

	elseif entry.type == "weapon" then
		if MilBase.GrantWeaponUnlock and MilBase.GrantWeaponUnlock(ply, entry.id) then
			return { type = "weapon", id = entry.id }
		end
		local fallback = math.max(0, math.floor(tonumber(entry.fallback) or 250))
		MilBase.AwardCredits(ply, fallback)
		return { type = "credits", amount = fallback }

	elseif entry.type == "credits" then
		local amount = math.random(entry.min or 50, entry.max or 150)
		MilBase.AwardCredits(ply, amount)
		return { type = "credits", amount = amount }

	elseif entry.type == "booster" then
		MilBase.GrantBooster(ply, entry.mult or 1.5, entry.duration or 3600)
		return { type = "booster", mult = entry.mult or 1.5, duration = entry.duration or 3600 }
	end
end

net.Receive("MilBase_OpenCrate", function(_, ply)
	local id = net.ReadString()
	local crate = MilBase.GetCrate(id)
	if not crate then return end
	if (ply.mb_nextCrate or 0) > CurTime() then return end
	ply.mb_nextCrate = CurTime() + 0.5

	-- Pay the cost (credits and/or a crate item).
	if crate.item then
		if MilBase.CountItem(ply, crate.item) < 1 then
			MilBase.Notify(ply, "You need a " .. (MilBase.Items[crate.item] and MilBase.Items[crate.item].name or crate.item) .. ".")
			return
		end
	end
	if (crate.cost or 0) > 0 and ply:MBMoney() < crate.cost then
		MilBase.Notify(ply, "Not enough " .. (cfg.CurrencyName or "credits") .. ".")
		return
	end

	if crate.item then MilBase.TakeItem(ply, crate.item, 1) end
	if (crate.cost or 0) > 0 then ply:MBSetMoney(ply:MBMoney() - crate.cost) end

	local results = {}
	for _ = 1, crate.rewards or 1 do
		local entry = MilBase.RollLoot(crate.loot)
		if entry then
			local r = grantReward(ply, entry)
			if r then results[#results + 1] = r end
		end
	end

	net.Start("MilBase_CrateResult")
		net.WriteString(id)
		net.WriteTable(results)
	net.Send(ply)
end)

--------------------------------------------------------------------------
-- Admin commands
--------------------------------------------------------------------------

MilBase.RegisterChatCommand("givecard", {
	help = "(Admin) Unlock a star card: /givecard <player> <card id|all>",
	adminOnly = true,
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		if not IsValid(target) then MilBase.Notify(ply, "Player not found.") return end

		local id = string.lower(args[2] or "")
		if id == "all" then
			local n = 0
			for _, cid in ipairs(MilBase.StarCardOrder) do
				if MilBase.UnlockCard(target, cid, true) then n = n + 1 end
			end
			MilBase.Notify(ply, "Unlocked " .. n .. " cards for " .. target:MBName() .. ".")
		elseif MilBase.GetStarCard(id) then
			MilBase.Notify(ply, MilBase.UnlockCard(target, id)
				and ("Unlocked " .. MilBase.GetStarCard(id).name .. ".") or "Already unlocked.")
		else
			MilBase.Notify(ply, "Unknown card. Valid: all, " .. table.concat(MilBase.StarCardOrder, ", "))
		end
	end,
})

MilBase.RegisterChatCommand("givecredits", {
	help = "(Admin) Give credits: /givecredits <player> <amount>",
	adminOnly = true,
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		local amount = tonumber(args[2])
		if not IsValid(target) or not amount then
			MilBase.Notify(ply, "Usage: /givecredits <player> <amount>")
			return
		end
		target:MBAddMoney(math.floor(amount))
		MilBase.Notify(ply, "Gave " .. math.floor(amount) .. " to " .. target:MBName() .. ".")
	end,
})
