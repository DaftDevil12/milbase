-- Shared, certification-backed language registry.
--
-- Gameplay systems can register a language once and then use the same
-- comprehension and nearby-translator rules for NPC dialogue.
MilBase.Languages = MilBase.Languages or {}
MilBase.LanguageOrder = MilBase.LanguageOrder or {}

local function cleanID(value)
	local id = string.lower(string.Trim(tostring(value or "")))
	id = string.gsub(id, "[^%w_%-]", "_")
	id = string.gsub(id, "_+", "_")
	return string.sub(id, 1, 48)
end

function MilBase.RegisterLanguage(id, data)
	id = cleanID(id)
	assert(id ~= "", "Language id is required")
	data = table.Copy(data or {})
	data.id = id
	data.name = tostring(data.name or id)
	data.certification = cleanID(data.certification)
	data.untranslated = tostring(data.untranslated or "[Unintelligible speech]")

	if not MilBase.Languages[id] then
		MilBase.LanguageOrder[#MilBase.LanguageOrder + 1] = id
	end
	MilBase.Languages[id] = data
	return data
end

function MilBase.GetLanguage(id)
	return MilBase.Languages[cleanID(id)]
		or MilBase.Languages.basic
end

local PLAYER = FindMetaTable("Player")

function PLAYER:MBUnderstandsLanguage(id)
	local language = MilBase.GetLanguage(id)
	if not language then return false end
	if language.certification == "" then return true end
	return self.MBHasCert and self:MBHasCert(language.certification) or false
end

-- A translator must be alive, certified, and close enough to both people to
-- hear the exchange. The listener is excluded because direct comprehension is
-- checked before this function is called.
function MilBase.FindLanguageTranslator(listener, languageID, speakerPosition, radius)
	if not SERVER or not IsValid(listener) or not listener:IsPlayer() then return nil end
	local language = MilBase.GetLanguage(languageID)
	if not language or language.certification == "" then return nil end
	if not isvector(speakerPosition) then return nil end
	radius = math.max(64, tonumber(radius) or 320)
	local radiusSquared = radius * radius

	local candidates = {}
	for _, candidate in ipairs(player.GetHumans()) do
		if candidate ~= listener and candidate:Alive()
		and candidate.MBUnderstandsLanguage
		and candidate:MBUnderstandsLanguage(languageID)
		and candidate:GetPos():DistToSqr(listener:GetPos()) <= radiusSquared
		and candidate:GetPos():DistToSqr(speakerPosition) <= radiusSquared then
			candidates[#candidates + 1] = candidate
		end
	end
	table.sort(candidates, function(a, b)
		return a:GetPos():DistToSqr(speakerPosition)
			< b:GetPos():DistToSqr(speakerPosition)
	end)
	return candidates[1]
end

function MilBase.ResolveLanguageForListener(listener, languageID, speakerPosition, radius)
	local language = MilBase.GetLanguage(languageID)
	if not language then return false, nil end
	if IsValid(listener) and listener.MBUnderstandsLanguage
	and listener:MBUnderstandsLanguage(language.id) then
		return true, nil
	end
	local translator = MilBase.FindLanguageTranslator(
		listener, language.id, speakerPosition, radius)
	return IsValid(translator), translator
end

function MilBase.LanguageQualificationText(languageID)
	local language = MilBase.GetLanguage(languageID)
	if not language then return "Unknown language" end
	if language.certification == "" then return "No certification required" end
	local cert = MilBase.Certs and MilBase.Certs[language.certification]
	return cert and cert.name or language.certification
end
