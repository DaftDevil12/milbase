-- Faction registry. Factions are teams with ranks and loadouts;
-- players are assigned to them by officers/admins (/setfaction).
--
-- Factions normally come from config/sh_factions.lua. Runtime systems such as
-- the staff faction editor use ApplyFaction/RemoveFaction so definitions can be
-- updated without duplicating order entries or changing an existing team id.

MilBase.Factions = MilBase.Factions or {}
MilBase.FactionByTeam = MilBase.FactionByTeam or {}
MilBase.FactionOrder = MilBase.FactionOrder or {}
MilBase.FreeFactionTeamIndices = MilBase.FreeFactionTeamIndices or {}

local function factionColor(value)
	if IsColor and IsColor(value) then
		return Color(value.r, value.g, value.b, value.a or 255)
	end
	if istable(value) then
		return Color(
			math.Clamp(math.floor(tonumber(value.r or value[1]) or 255), 0, 255),
			math.Clamp(math.floor(tonumber(value.g or value[2]) or 255), 0, 255),
			math.Clamp(math.floor(tonumber(value.b or value[3]) or 255), 0, 255),
			math.Clamp(math.floor(tonumber(value.a or value[4]) or 255), 0, 255)
		)
	end
	return Color(255, 255, 255)
end

local function nextFreeTeamIndex()
	local recycled
	for index in pairs(MilBase.FreeFactionTeamIndices) do
		if not recycled or index < recycled then recycled = index end
	end
	if recycled then
		MilBase.FreeFactionTeamIndices[recycled] = nil
		return recycled
	end

	local highest = 0
	for index in pairs(MilBase.FactionByTeam) do
		highest = math.max(highest, tonumber(index) or 0)
	end
	for _, faction in pairs(MilBase.Factions) do
		highest = math.max(highest, tonumber(faction.teamIndex) or 0)
	end
	local candidate = highest + 1
	while MilBase.FactionByTeam[candidate] or (team.Valid and team.Valid(candidate)) do
		candidate = candidate + 1
	end
	return candidate
end

local function orderContains(id)
	for _, existing in ipairs(MilBase.FactionOrder) do
		if existing == id then return true end
	end
	return false
end

-- Applies either a new faction or an update. Existing factions retain their
-- team index unless an authoritative teamIndex is supplied (used by net sync).
function MilBase.ApplyFaction(id, source, teamIndex)
	assert(isstring(id), "Faction id must be a string")
	assert(istable(source), "Faction '" .. id .. "' data must be a table")
	assert(istable(source.ranks) and #source.ranks > 0,
		"Faction '" .. id .. "' needs at least one rank")

	local previous = MilBase.Factions[id]
	local data = table.Copy(source)

	data.id = id
	data.name = tostring(data.name or id)
	data.color = factionColor(data.color)
	data.models = istable(data.models) and data.models or {}
	if #data.models < 1 then
		data.models = { "models/player/group01/male_02.mdl" }
	end
	data.loadout = istable(data.loadout) and data.loadout or {}
	data.issue = istable(data.issue) and data.issue or {}
	data.attachments = MilBase.CopyCountMap(data.attachments, 1000)
	for _, rank in ipairs(data.ranks) do
		-- Empty per-rank override lists must behave like nil. An empty models
		-- table is truthy in Lua and would otherwise suppress faction models.
		if istable(rank.models) and #rank.models < 1 then rank.models = nil end
		if istable(rank.loadout) and #rank.loadout < 1 then rank.loadout = nil end
		if istable(rank.issue) and table.Count(rank.issue) < 1 then rank.issue = nil end
		rank.attachments = MilBase.CopyCountMap(rank.attachments, 1000)
		if table.Count(rank.attachments) < 1 then rank.attachments = nil end
	end
	data.jedi = data.jedi == true
	data.forceSensitive = data.forceSensitive == true
	data.medic = data.medic == true
	data.police = data.police == true

	local resolvedTeam = tonumber(teamIndex)
		or (previous and tonumber(previous.teamIndex))
		or tonumber(data.teamIndex)
		or nextFreeTeamIndex()
	resolvedTeam = math.max(1, math.floor(resolvedTeam))
	data.teamIndex = resolvedTeam
	MilBase.FreeFactionTeamIndices[resolvedTeam] = nil

	if previous and previous.teamIndex ~= resolvedTeam then
		MilBase.FactionByTeam[previous.teamIndex] = nil
		MilBase.FreeFactionTeamIndices[previous.teamIndex] = true
	end

	MilBase.Factions[id] = data
	MilBase.FactionByTeam[resolvedTeam] = data
	if not orderContains(id) then
		table.insert(MilBase.FactionOrder, id)
	end

	team.SetUp(resolvedTeam, data.name, data.color)
	return data
end

function MilBase.RegisterFaction(id, data)
	return MilBase.ApplyFaction(id, data)
end

-- Removes a runtime-created faction. Config factions should normally be reset
-- to their file definition rather than removed outright.
function MilBase.RemoveFaction(id)
	local faction = MilBase.Factions[id]
	if not faction then return false end

	MilBase.Factions[id] = nil
	MilBase.FactionByTeam[faction.teamIndex] = nil
	MilBase.FreeFactionTeamIndices[faction.teamIndex] = true
	for i = #MilBase.FactionOrder, 1, -1 do
		if MilBase.FactionOrder[i] == id then
			table.remove(MilBase.FactionOrder, i)
		end
	end

	-- Garry's Mod teams cannot truly be deleted. Rename the now-unused slot so
	-- stale UI references never masquerade as the removed faction.
	team.SetUp(faction.teamIndex, "Unused Faction", Color(80, 80, 80))
	return true
end

function MilBase.GetFaction(id)
	return MilBase.Factions[id]
end

-- Force access is a faction capability. Factions must opt in explicitly with
-- `jedi = true`; names, models, staff rank, and LSCS inventory never imply it.
function MilBase.IsJediFaction(faction)
	if isstring(faction) then faction = MilBase.GetFaction(faction) end
	return istable(faction) and faction.jedi == true
end

local PLAYER = FindMetaTable("Player")

function PLAYER:MBIsJedi()
	return MilBase.IsJediFaction(self:MBFaction())
end

function PLAYER:MBIsForceSensitive()
	local faction = self:MBFaction()
	return self:MBIsJedi() or (faction and faction.forceSensitive == true)
		or self:GetNWBool("mb_lscs_force_sensitive", false)
end

function PLAYER:MBJediLevel()
	if not self:MBIsJedi() then return 0 end
	local rank = self:MBRank()
	return math.Clamp(math.floor(tonumber(rank and rank.jediLevel) or self:MBRankIndex()), 1, 5)
end

function PLAYER:MBJediTitle()
	local levels = ((MilBase.Config.LSCS or {}).JediLevels or {})
	return levels[self:MBJediLevel()] or (self:MBRank() and self:MBRank().name) or "Jedi"
end

-- The model a player should use, honoring per-rank overrides.
-- Deterministic per player so models don't reroll every respawn.
function MilBase.GetPlayerModel(ply)
	-- Event enemies use their class model instead of their faction model.
	if MilBase.EventEnemyModel then
		local m = MilBase.EventEnemyModel(ply)
		if m then return m end
	end

	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local models = (rank and rank.models) or (faction and faction.models) or {}
	if #models < 1 then models = { "models/player/group01/male_02.mdl" } end

	local index = (tonumber(util.CRC(ply:SteamID())) % #models) + 1
	return models[index]
end
