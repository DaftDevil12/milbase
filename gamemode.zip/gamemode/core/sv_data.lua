-- Player persistence via the unified MilBase.DB layer (SQLite or MySQL).

-- `rank` is a reserved word in MySQL 8.0 (window function), so it's backticked.
MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_players (
	steamid VARCHAR(32) PRIMARY KEY,
	name TEXT,
	faction VARCHAR(64),
	`rank` INTEGER,
	money INTEGER
)]])

--------------------------------------------------------------------------
-- Load coordination
--
-- With MySQL, loads are ASYNCHRONOUS, so a player can technically spawn
-- before their data arrives. Each of the three core loaders (data /
-- inventory / progress) reports in here; once all three are done we mark
-- the player fully loaded, and if they already spawned we rebuild their
-- character. With SQLite the loads finish synchronously during
-- PlayerInitialSpawn (before the first spawn), so nothing extra happens.
--------------------------------------------------------------------------

function MilBase.MarkLoaded(ply, which)
	if not IsValid(ply) then return end
	ply.mb_loadState = ply.mb_loadState or {}
	ply.mb_loadState[which] = true

	local s = ply.mb_loadState
	if not (s.data and s.inv and s.progress and s.certs and s.arccw) then return end
	if ply.mb_fullyLoaded then return end
	ply.mb_fullyLoaded = true

	-- Rebuild the character if they spawned before their data loaded.
	if ply:Alive() then
		local isEnemy = MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)
		ply:SetTeam(isEnemy and MilBase.EventEnemyTeam or ply:MBFaction().teamIndex)
		ply:StripWeapons()
		hook.Run("PlayerLoadout", ply)
		if MilBase.ApplyEquipment then MilBase.ApplyEquipment(ply) end
	end

	hook.Run("MilBase.PlayerLoaded", ply)
end

--------------------------------------------------------------------------
-- Load / save
--------------------------------------------------------------------------

function MilBase.LoadPlayer(ply)
	local cfg = MilBase.Config
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	local sid = MilBase.SQLStr(key)

	MilBase.DB.Query("SELECT * FROM frontier_players WHERE steamid = " .. sid, function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		local row = rows[1]
		local isNew = row == nil

		local name = row and row.name or ""
		local factionID = row and row.faction or cfg.DefaultFaction
		local rank = row and tonumber(row.rank) or 1
		local money = row and tonumber(row.money) or cfg.StartingMoney

		-- The config may have changed since they last played; validate.
		local faction = MilBase.GetFaction(factionID)
		if not faction then
			factionID = cfg.DefaultFaction
			faction = MilBase.GetFaction(factionID)
			rank = 1
		end
		rank = math.Clamp(rank, 1, #faction.ranks)

		ply:SetNWString("mb_name", name)
		ply:SetNWString("mb_faction", factionID)
		ply:SetNWInt("mb_rank", rank)
		ply:SetNWInt("mb_money", money)

		ply.mb_dataLoaded = true
		ply.mb_dataLoadError = nil
		if isNew then MilBase.SavePlayer(ply) end
		MilBase.MarkLoaded(ply, "data")
	end, function(err)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		-- Fail open for gameplay, but keep mb_dataLoaded false so defaults can
		-- never overwrite a real character after a temporary database failure.
		ply:SetNWString("mb_name", "")
		ply:SetNWString("mb_faction", cfg.DefaultFaction)
		ply:SetNWInt("mb_rank", 1)
		ply:SetNWInt("mb_money", cfg.StartingMoney)
		ply.mb_dataLoaded = false
		ply.mb_dataLoadError = tostring(err or "database error")
		MilBase.MarkLoaded(ply, "data")
	end)
end

function MilBase.SavePlayer(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	-- Never overwrite stored data with defaults before the load finished.
	if not ply.mb_dataLoaded then return end

	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_players (steamid, name, faction, `rank`, money) VALUES (%s, %s, %s, %d, %d)",
		MilBase.SQLStr(ply:MBCharacterKey()),
		MilBase.SQLStr(ply:GetNWString("mb_name", "")),
		MilBase.SQLStr(ply:MBFactionID()),
		ply:MBRankIndex(),
		ply:MBMoney()
	))
end

hook.Add("PlayerDisconnected", "MilBase.SaveOnLeave", function(ply)
	MilBase.SavePlayer(ply)
end)

hook.Add("ShutDown", "MilBase.SaveAll", function()
	for _, ply in ipairs(player.GetAll()) do
		MilBase.SavePlayer(ply)
	end
end)
