--[[
	EFT-style gear screen (the GEAR tab).

	Left: your character with weapon slots (ON SLING / ON BACK / HOLSTER)
	and equipment slots (HEADWEAR / BODY ARMOR / BACKPACK). Middle: the
	backpack grid when one is worn. Right: the STASH grid + drop zone.

	Grid controls: drag to move (works between stash and backpack),
	R rotates while dragging, drag onto a matching stack to merge,
	double-click or right-click to use, right-click -> Equip for gear.
]]

local cfg = MilBase.Config

MilBase.LocalInv = MilBase.LocalInv or { w = 10, h = 6, items = {}, equip = {} }

local iconCache = {}
local function getItemIcon(path)
	iconCache[path] = iconCache[path] or Material(path, "smooth")
	return iconCache[path]
end

net.Receive("MilBase_InvSync", function()
	MilBase.LocalInv = util.JSONToTable(net.ReadString()) or MilBase.LocalInv
	MilBase.LocalInv.equip = MilBase.LocalInv.equip or {}
	if IsValid(MilBase.InvPanel) then
		MilBase.InvPanel:Rebuild()
	end
end)

--------------------------------------------------------------------------
-- Net senders
--------------------------------------------------------------------------

local function sendMove(uid, containerID, x, y, rot)
	net.Start("MilBase_InvMove")
		net.WriteUInt(uid, 16)
		net.WriteString(containerID)
		net.WriteUInt(x, 8)
		net.WriteUInt(y, 8)
		net.WriteBool(rot)
	net.SendToServer()
end

function MilBase.InvUse(uid, limb, target)
	net.Start("MilBase_InvUse")
		net.WriteUInt(uid, 16)
		net.WriteString(limb or "")
		net.WriteBool(IsValid(target))
		if IsValid(target) then
			net.WriteEntity(target)
		end
	net.SendToServer()
end

function MilBase.InvDropItem(uid)
	net.Start("MilBase_InvDrop")
		net.WriteUInt(uid, 16)
	net.SendToServer()
end

local function sendEquip(uid)
	net.Start("MilBase_InvEquip")
		net.WriteUInt(uid, 16)
	net.SendToServer()
end

local function sendUnequip(slot)
	net.Start("MilBase_InvUnequip")
		net.WriteString(slot)
	net.SendToServer()
end

local sendUse = MilBase.InvUse
local sendDrop = MilBase.InvDropItem

--------------------------------------------------------------------------
-- Shared drag state (items drag between the stash and backpack grids)
--------------------------------------------------------------------------

local drag       -- { uid, def, item, rot }
local liveGrids  -- containerID -> grid panel
local dropZone

local function containerData(id)
	if id == "pack" then return MilBase.LocalInv.pack end
	return MilBase.LocalInv
end

local function cursorGrid()
	for id, grid in pairs(liveGrids or {}) do
		if IsValid(grid) then
			local mx, my = grid:ScreenToLocal(gui.MouseX(), gui.MouseY())
			if mx >= 0 and my >= 0 and mx <= grid:GetWide() and my <= grid:GetTall() then
				return grid
			end
		end
	end
end

local function overDropZone()
	if not IsValid(dropZone) then return false end
	local mx, my = dropZone:ScreenToLocal(gui.MouseX(), gui.MouseY())
	return mx >= 0 and my >= 0 and mx <= dropZone:GetWide() and my <= dropZone:GetTall()
end

--------------------------------------------------------------------------
-- One grid (stash or backpack)
--------------------------------------------------------------------------

local CELL = math.max(40, math.floor(ScrH() / 21))

local function ghostCell(grid)
	local data = containerData(grid.containerID)
	local mx, my = grid:ScreenToLocal(gui.MouseX(), gui.MouseY())
	local w, h = MilBase.ItemDims(drag.def, drag.rot)

	local cx = math.floor(mx / CELL) + 1 - math.floor((w - 1) / 2)
	local cy = math.floor(my / CELL) + 1 - math.floor((h - 1) / 2)

	return math.Clamp(cx, 1, math.max(1, data.w - w + 1)),
		math.Clamp(cy, 1, math.max(1, data.h - h + 1))
end

local function createGrid(parent, containerID)
	local grid = vgui.Create("DPanel", parent)
	grid.containerID = containerID
	liveGrids[containerID] = grid

	local data = containerData(containerID)
	grid:SetSize(data.w * CELL + 1, data.h * CELL + 1)

	grid.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 160)
		surface.DrawRect(0, 0, w, h)

		local d = containerData(self.containerID)
		if not d then return end

		-- Tarkov-style cell tiles (fallback: 1px gridlines).
		local cellMat = MilBase.GetUIMat(MilBase.UI.art.bf2.gridCell)
		if cellMat then
			surface.SetDrawColor(255, 198, 60, 55)
			surface.SetMaterial(cellMat)
			for cx = 0, d.w - 1 do
				for cy = 0, d.h - 1 do
					surface.DrawTexturedRect(cx * CELL, cy * CELL, CELL, CELL)
				end
			end
		else
			surface.SetDrawColor(255, 198, 60, 14)
			for x = 0, d.w do surface.DrawRect(x * CELL, 0, 1, h) end
			for y = 0, d.h do surface.DrawRect(0, y * CELL, w, 1) end
		end
	end

	grid.PaintOver = function(self, w, h)
		if not drag then return end
		if cursorGrid() ~= self then return end

		local d = containerData(self.containerID)
		if not d then return end

		local cx, cy = ghostCell(self)
		local iw, ih = MilBase.ItemDims(drag.def, drag.rot)
		local ok, blockers = MilBase.InvCanPlace(d, drag.def, cx, cy, drag.rot, drag.uid)

		local col = Color(220, 80, 70, 70)
		if ok then
			col = Color(150, 205, 125, 70)
		elseif #blockers == 1 and blockers[1].id == drag.item.id and drag.def.stack > 1 then
			col = Color(255, 198, 60, 70) -- merge
		end

		surface.SetDrawColor(col)
		surface.DrawRect((cx - 1) * CELL + 1, (cy - 1) * CELL + 1, iw * CELL - 1, ih * CELL - 1)
	end

	grid.Think = function(self)
		if drag and input.IsKeyDown(KEY_R) then
			if not self.mb_rHeld and drag.def.w ~= drag.def.h then
				drag.rot = not drag.rot
			end
			self.mb_rHeld = true
		else
			self.mb_rHeld = false
		end
	end

	local data2 = containerData(containerID)
	for _, it in ipairs(data2.items) do
		local def = MilBase.Items[it.id]
		if def then
			local iw, ih = MilBase.ItemDims(def, it.rot)

			local p = vgui.Create("DPanel", grid)
			p:SetPos((it.x - 1) * CELL + 2, (it.y - 1) * CELL + 2)
			p:SetSize(iw * CELL - 3, ih * CELL - 3)
			p:SetTooltip(def.name .. "\n" .. def.desc)

			p.Paint = function(self, w, h)
				surface.SetDrawColor(0, 0, 0, 150)
				surface.DrawRect(0, 0, w, h)
				MilBase.DrawIcon(MilBase.UI.art.bf2.panel, 0, 0, w, h)
				surface.SetDrawColor(255, 198, 60, self:IsHovered() and 90 or 40)
				surface.DrawOutlinedRect(0, 0, w, h)
				if self:IsHovered() and not drag then
					surface.SetDrawColor(255, 198, 60, 16)
						surface.DrawRect(0, 0, w, h)
				end

				if def.icon then
					local size = math.min(w, h) - 8
					surface.SetDrawColor(255, 255, 255, 235)
					surface.SetMaterial(getItemIcon(def.icon))
					surface.DrawTexturedRect(math.floor((w - size) / 2),
						math.floor((h - size) / 2), size, size)
				end
			end

			if not def.icon then
				local icon = vgui.Create("SpawnIcon", p)
				icon:SetModel(def.model)
				icon:SetMouseInputEnabled(false)
				icon:SetKeyboardInputEnabled(false)

				p.PerformLayout = function(self, w, h)
					local size = math.min(w, h)
					icon:SetSize(size, size)
					icon:SetPos(math.floor((w - size) / 2), math.floor((h - size) / 2))
				end
			end

			p.PaintOver = function(self, w, h)
				if drag and drag.uid == it.uid then
					surface.SetDrawColor(0, 0, 0, 160)
					surface.DrawRect(0, 0, w, h)
				end

				if (it.amount or 1) > 1 then
					draw.SimpleText(it.amount, "MB.Small", w - 4, h - 2,
						MilBase.UI.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
				end

				if it.charges and def.charges then
					local frac = math.Clamp(it.charges / def.charges, 0, 1)
					surface.SetDrawColor(0, 0, 0, 180)
					surface.DrawRect(3, h - 6, w - 6, 3)
					surface.SetDrawColor(MilBase.UI.ok)
					surface.DrawRect(3, h - 6, math.floor((w - 6) * frac), 3)
				end
			end

			p.OnMousePressed = function(self, code)
				if code == MOUSE_LEFT then
					if (self.mb_lastClick or 0) > SysTime() - 0.25 then
						sendUse(it.uid, def.med and MilBase.SelectedLimb or nil)
						return
					end
					self.mb_lastClick = SysTime()

					drag = { uid = it.uid, def = def, item = it, rot = it.rot or false }
					self:MouseCapture(true)
				elseif code == MOUSE_RIGHT then
					local menu = DermaMenu()

					if def.slot then
						menu:AddOption("Equip", function()
							sendEquip(it.uid)
						end):SetIcon("icon16/user_suit.png")
					end

					if def.med then
						local selected = MilBase.SelectedLimb
						local label = "Use"
						if selected and MilBase.Limbs then
							for _, l in ipairs(MilBase.Limbs) do
								if l.id == selected then
									label = "Use on " .. l.name
									break
								end
							end
						end
						menu:AddOption(label, function()
							sendUse(it.uid, selected)
						end):SetIcon("icon16/heart.png")

						if MilBase.Limbs then
							local sub = menu:AddSubMenu("Use on body part")
							for _, l in ipairs(MilBase.Limbs) do
								sub:AddOption(l.name, function()
									sendUse(it.uid, l.id)
								end)
							end
						end

						local canTreatOthers = false
						for _, certID in ipairs(LocalPlayer():MBCertList()) do
							local cert = MilBase.Certs[certID]
							if cert and cert.medicOthers then
								canTreatOthers = true
								break
							end
						end
						if canTreatOthers then
							menu:AddOption("Treat aimed soldier", function()
								local aimed = LocalPlayer():GetEyeTrace().Entity
								if IsValid(aimed) and aimed:IsPlayer() then
									sendUse(it.uid, nil, aimed)
								end
							end):SetIcon("icon16/user_go.png")
						end
					elseif def.onUse or def.eng then
						menu:AddOption("Use", function() sendUse(it.uid) end):SetIcon("icon16/tick.png")
					end

					menu:AddOption("Drop", function() sendDrop(it.uid) end):SetIcon("icon16/arrow_down.png")
					menu:Open()
				end
			end

			p.OnMouseReleased = function(self, code)
				if code ~= MOUSE_LEFT or not drag then return end
				self:MouseCapture(false)

				if overDropZone() then
					sendDrop(drag.uid)
				else
					local target = cursorGrid()
					if target then
						local cx, cy = ghostCell(target)
						if target.containerID ~= containerID
						or cx ~= it.x or cy ~= it.y or drag.rot ~= (it.rot or false) then
							sendMove(drag.uid, target.containerID, cx, cy, drag.rot)
						end
					end
				end
				drag = nil
			end
		end
	end

	return grid
end

--------------------------------------------------------------------------
-- Equipment slots (left column)
--------------------------------------------------------------------------

local GEAR_SLOTS = {
	-- pos: L1/L2 left column, R1/R2/R3 right column, W1/W2 wide bottom bars.
	{ id = "head",     label = "HEADWEAR",   pos = "L1" },
	{ id = "armor",    label = "BODY ARMOR", pos = "L2" },
	{ id = "holster",  label = "HOLSTER",  weapon = "secondary", index = 1, pos = "R1" },
	{ id = "backpack", label = "BACKPACK",   pos = "R2" },
	{ id = "jetpack",  label = "JETPACK",    pos = "R3" },
	{ id = "sling1",   label = "ON SLING", weapon = "primary", index = 1, wide = true, pos = "W1" },
	{ id = "sling2",   label = "ON BACK",  weapon = "primary", index = 2, wide = true, pos = "W2" },
}

-- Client mirror of the server categorization.
local function weaponSlotType(wep)
	local class = wep:GetClass()
	if cfg.SlotExemptWeapons[class] then return nil end
	if cfg.SecondaryWeapons[class] then return "secondary" end

	local holdType = wep.GetHoldType and wep:GetHoldType()
	if holdType == "pistol" or holdType == "revolver" then return "secondary" end
	if wep:GetMaxClip1() <= 0 then return nil end

	return "primary"
end

local function carriedWeapons(slotType)
	local out = {}
	for _, wep in ipairs(LocalPlayer():GetWeapons()) do
		if IsValid(wep) and weaponSlotType(wep) == slotType then
			table.insert(out, wep)
		end
	end
	return out
end

-- One EFT-style slot: a labelled box with a centered icon. Equipment
-- slots show the item icon; weapon slots show the weapon name.
local function createSlotBox(parent, slot)
	local ui = MilBase.UI

	local box = vgui.Create("DButton", parent)
	box:SetText("")
	box.slot = slot

	box.Paint = function(self, w, h)
		local filled, def, wep
		if slot.weapon then
			wep = carriedWeapons(slot.weapon)[slot.index]
			filled = IsValid(wep)
		else
			local eq = MilBase.LocalInv.equip[slot.id]
			def = eq and MilBase.Items[eq.id]
			filled = def ~= nil
		end

		local b = MilBase.UI.art.bf2

		-- Box: dark fill, thin gold border (brighter when filled).
		surface.SetDrawColor(0, 0, 0, 165)
		surface.DrawRect(0, 0, w, h)
		if filled and self:IsHovered() then
			surface.SetDrawColor(255, 198, 60, 20)
			surface.DrawRect(0, 0, w, h)
		end

		-- Empty slots show a silhouette of what goes there.
		if not filled then
			local ph = ({ head = b.slotHead, armor = b.slotArmor,
				backpack = b.slotBackpack, jetpack = b.slotBackpack, holster = b.slotHolster,
				sling1 = b.slotPrimary, sling2 = b.slotPrimary })[slot.id]
			local ps = math.min(w, h) - 14
			MilBase.DrawIcon(ph, (w - ps) / 2, (h - ps) / 2, ps, ps, Color(255, 198, 60, 32))
		end

		-- Border: framed art w/ corner brackets (fallback: thin outline).
		if not MilBase.DrawIcon(b.slotFrame, 0, 0, w, h,
			Color(255, 198, 60, filled and 110 or 45)) then
			surface.SetDrawColor(255, 198, 60, filled and 75 or 24)
			surface.DrawOutlinedRect(0, 0, w, h)
		end

		-- Label, top-left corner.
		draw.SimpleText(slot.label, "MB.Tiny", 6, 5, filled and ui.dim or ui.faint,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		if slot.wide then
			-- Wide primary bar: weapon name on the left.
			if filled then
				local name = language.GetPhrase(wep:GetPrintName() or wep:GetClass())
				draw.SimpleText(string.upper(name), "MB.Small", 8, h - 7,
					ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			else
				draw.SimpleText("EMPTY", "MB.Tiny", 8, h - 7,
					ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			end
		elseif slot.weapon then
			-- Square holster: weapon name centered.
			draw.SimpleText(filled
				and string.upper(language.GetPhrase(wep:GetPrintName() or wep:GetClass()))
				or "EMPTY", "MB.Tiny", w / 2, h / 2 + 8,
				filled and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			-- Equipment: big centered icon (or EMPTY).
			if def and def.icon then
				local s = math.min(w, h) - 20
				surface.SetDrawColor(255, 255, 255, 235)
				surface.SetMaterial(getItemIcon(def.icon))
				surface.DrawTexturedRect((w - s) / 2, (h - s) / 2, s, s)
			elseif not filled then
				draw.SimpleText("EMPTY", "MB.Tiny", w / 2, h / 2 + 8,
					ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end

	box.DoClick = function()
		if slot.weapon then
			-- Drop the weapon in this slot to free the carry slot.
			local w = carriedWeapons(slot.weapon)[slot.index]
			if IsValid(w) then
				net.Start("MilBase_DropSlot")
					net.WriteEntity(w)
				net.SendToServer()
			end
			return
		end
		if MilBase.LocalInv.equip[slot.id] then
			sendUnequip(slot.id)
		end
	end
	box:SetTooltip(slot.weapon and "Click to drop this weapon" or "Click to unequip")

	return box
end

--------------------------------------------------------------------------
-- The gear screen
--------------------------------------------------------------------------

function MilBase.CreateGearPanel(parent)
	local ui = MilBase.UI

	local root = vgui.Create("DPanel", parent)
	root.Paint = nil

	function root:Rebuild()
		drag = nil
		liveGrids = {}
		self:Clear()

		local lp = LocalPlayer()

		-- LEFT: character silhouette with equipment slots arranged around
		-- it (EFT layout): helmet/armor left, holster/backpack right,
		-- primaries as wide bars along the bottom.
		local left = vgui.Create("DPanel", self)
		left:Dock(LEFT)
		left:SetWide(340)
		left.Paint = function(s, w, h) MilBase.PaintPanel(w, h) end

		local mdl = vgui.Create("DModelPanel", left)
		mdl:SetModel(lp:GetModel())
		mdl:SetFOV(42)
		mdl:SetCamPos(Vector(78, 0, 40))
		mdl:SetLookAt(Vector(0, 0, 38))
		mdl:SetMouseInputEnabled(false)
		function mdl:LayoutEntity(ent)
			ent:SetAngles(Angle(0, 0, 0))
		end
		if IsValid(mdl.Entity) then
			mdl.Entity:SetSkin(lp:GetSkin() or 0)
			for i = 0, lp:GetNumBodyGroups() - 1 do
				mdl.Entity:SetBodygroup(i, lp:GetBodygroup(i))
			end
		end

		local boxes = {}
		for _, slot in ipairs(GEAR_SLOTS) do
			boxes[slot.pos] = createSlotBox(left, slot)
		end

		left.PerformLayout = function(self, w, h)
			local m, boxW, boxH = 10, 100, 58
			local rightX = w - m - boxW
			local top = 12

			if boxes.L1 then boxes.L1:SetPos(m, top); boxes.L1:SetSize(boxW, boxH) end
			if boxes.L2 then boxes.L2:SetPos(m, top + boxH + 8); boxes.L2:SetSize(boxW, boxH) end
			if boxes.R1 then boxes.R1:SetPos(rightX, top); boxes.R1:SetSize(boxW, boxH) end
			if boxes.R2 then boxes.R2:SetPos(rightX, top + boxH + 8); boxes.R2:SetSize(boxW, boxH) end
			if boxes.R3 then boxes.R3:SetPos(rightX, top + (boxH + 8) * 2); boxes.R3:SetSize(boxW, boxH) end

			local wideH = 46
			local wideY2 = h - 12 - wideH
			local wideY1 = wideY2 - wideH - 6
			if boxes.W1 then boxes.W1:SetPos(m, wideY1); boxes.W1:SetSize(w - m * 2, wideH) end
			if boxes.W2 then boxes.W2:SetPos(m, wideY2); boxes.W2:SetSize(w - m * 2, wideH) end

			-- Character model fills the gap between the columns.
			local mx = m + boxW + 4
			mdl:SetPos(mx, top + 4)
			mdl:SetSize(w - mx * 2, wideY1 - top - 14)
		end

		-- MIDDLE: backpack grid (when worn)
		local mid = vgui.Create("DPanel", self)
		mid:Dock(LEFT)
		mid.Paint = nil

		if MilBase.LocalInv.pack then
			local pack = MilBase.LocalInv.pack
			mid:SetWide(pack.w * CELL + 30)

			local label = vgui.Create("DLabel", mid)
			label:Dock(TOP)
			label:DockMargin(14, 0, 0, 4)
			label:SetFont("MB.Tab")
			label:SetText("BACKPACK")
			label:SetTextColor(ui.accent)
			label:SizeToContents()

			local grid = createGrid(mid, "pack")
			grid:SetPos(14, 36)
		else
			mid:SetWide(150)
			local hint = vgui.Create("DLabel", mid)
			hint:Dock(TOP)
			hint:DockMargin(14, 40, 0, 0)
			hint:SetFont("MB.Tiny")
			hint:SetText("No backpack worn.\nEquip one for extra\nstorage.")
			hint:SetTextColor(ui.faint)
			hint:SetTall(60)
		end

		-- RIGHT: stash + drop zone
		local right = vgui.Create("DPanel", self)
		right:Dock(FILL)
		right.Paint = nil

		local stashLabel = vgui.Create("DLabel", right)
		stashLabel:Dock(TOP)
		stashLabel:DockMargin(14, 0, 0, 4)
		stashLabel:SetFont("MB.Tab")
		stashLabel:SetText("STASH")
		stashLabel:SetTextColor(ui.accent)
		stashLabel:SizeToContents()

		local grid = createGrid(right, "stash")
		grid:SetPos(14, 36)

		-- DROP bar sits below the stash grid (full width).
		dropZone = vgui.Create("DPanel", right)
		dropZone:SetSize(MilBase.LocalInv.w * CELL + 1, 40)
		dropZone:SetPos(14, 36 + MilBase.LocalInv.h * CELL + 12)
		dropZone.Paint = function(s, w, h)
			local hot = drag ~= nil and overDropZone()
			surface.SetDrawColor(hot and Color(225, 85, 85, 60) or Color(0, 0, 0, 130))
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(hot and ui.danger or Color(255, 198, 60, 30))
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(hot and "RELEASE TO DROP" or "DROP  —  drag an item here",
				"MB.Small", w / 2, h / 2, hot and ui.text or ui.dim,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	root:Rebuild()
	MilBase.InvPanel = root
	return root
end

-- Back-compat: anything that asked for the plain inventory gets the
-- gear screen now.
MilBase.CreateInventoryPanel = MilBase.CreateGearPanel
