--[[
	Event system core: the shared registry and permissions for MilBase's
	built-in event tool (an RTS-style commander view for event staff).

	Event staff enter a top-down control camera to spawn enemies, order
	their movement/stance (attack / defend / patrol), and drive LVS
	aircraft (gun runs, flight paths). See:
	  config/sh_events.lua   - spawn catalogue & permission level
	  modules/sv_events.lua  - server: spawning, orders, AI, cleanup
	  modules/cl_events.lua  - client: camera, selection, command UI
]]

MilBase.EventSpawns = MilBase.EventSpawns or {}
MilBase.EventSpawnOrder = MilBase.EventSpawnOrder or {}

-- Register a spawnable for the event tool.
--   kind  = "npc" (any NPC class) or "lvs" (an LVS vehicle class)
--   class = entity class to spawn
--   name / category = how it's grouped in the palette
--   ai    = for lvs: start with autopilot enabled (default true)
function MilBase.RegisterEventSpawn(id, data)
	data.id = id
	data.name = data.name or id
	data.category = data.category or "Misc"
	data.kind = data.kind or "npc"
	if data.ai == nil then data.ai = true end

	if not MilBase.EventSpawns[id] then
		table.insert(MilBase.EventSpawnOrder, id)
	end
	MilBase.EventSpawns[id] = data
	return data
end

--------------------------------------------------------------------------
-- Event-enemy classes: playable enemy roles staff can offer to players
-- (defined in config/sh_eventenemies.lua, driven by modules/sh_eventenemies).
--------------------------------------------------------------------------

MilBase.EventEnemyClasses = MilBase.EventEnemyClasses or {}
MilBase.EventEnemyOrder = MilBase.EventEnemyOrder or {}

-- Register a playable event-enemy class.
--   name    = display name
--   models  = a model string or list of models
--   health  = spawn health          armor = spawn armor (optional)
--   weapons = weapon classes to give   speed = walk/run speed (optional)
--   lives   = lives before they revert (falls back to EventEnemyLives)
function MilBase.RegisterEventEnemy(id, data)
	data.id = id
	data.name = data.name or id
	data.enabled = data.enabled ~= false
	data.models = data.models or data.model or { "models/player/combine_soldier.mdl" }
	if isstring(data.models) then data.models = { data.models } end
	data.weapons = data.weapons or {}
	data.health = tonumber(data.health) or 100
	data.armor = tonumber(data.armor) or 0
	data.speed = tonumber(data.speed) or nil
	data.lives = tonumber(data.lives) or nil
	data.limit = tonumber(data.limit) or 0
	data.source = data.source or "config"
	if not MilBase.EventEnemyClasses[id] then
		table.insert(MilBase.EventEnemyOrder, id)
	end
	MilBase.EventEnemyClasses[id] = data
	return data
end

-- Who may use the event tool: staff at/above the configured level, or
-- anyone an admin. (Staff ranks live in config/sh_staff.lua.)
function MilBase.CanRunEvents(ply)
	if not IsValid(ply) then return false end
	if ply:IsSuperAdmin() then return true end

	local level = MilBase.Config.EventStaffLevel or 3
	return ply:MBStaffLevel() >= level
end

--------------------------------------------------------------------------
-- Auto-detection: pull every spawnmenu NPC and every LVS vehicle into
-- the palette automatically, grouped by their own spawnmenu categories.
-- Manual RegisterEventSpawn entries (config) take priority and are kept.
--------------------------------------------------------------------------

-- Walk an entity's base chain to see if it's an LVS vehicle.
local function isLVSClass(class)
	local seen = {}
	local cur = class
	while cur and not seen[cur] do
		seen[cur] = true
		if string.sub(cur, 1, 8) == "lvs_base" then return true end
		local stored = scripted_ents.GetStored(cur)
		cur = stored and stored.t and stored.t.Base
	end
	return false
end

function MilBase.AutoDetectSpawns()
	if MilBase.Config.EventAutoDetect == false then return end

	-- Classes already registered (by config) stay as they are. Effects,
	-- props and RP entities have no `.class`, so skip those.
	local have = {}
	for _, def in pairs(MilBase.EventSpawns) do
		if def.class then have[def.class] = true end
	end

	-- NPCs from the spawnmenu list (gives us Name / Category / Weapons).
	for class, t in pairs(list.Get("NPC")) do
		if not have[class] then
			MilBase.RegisterEventSpawn(class, {
				name = t.Name or class,
				category = t.Category or "NPCs",
				kind = "npc",
				class = class,
				-- Arm them with their default spawnmenu weapon so they fight.
				weapon = (istable(t.Weapons) and t.Weapons[1]) or nil,
			})
			have[class] = true
		end
	end

	-- LVS vehicles from the scripted-entity list.
	for class, sent in pairs(scripted_ents.GetList()) do
		local et = sent.t
		if et and et.Spawnable and not have[class] and isLVSClass(class) then
			MilBase.RegisterEventSpawn(class, {
				name = et.PrintName or class,
				category = et.Category or "LVS Vehicles",
				kind = "lvs",
				class = class,
				ai = true,
			})
			have[class] = true
		end
	end
end

-- Lists are populated by the time entities are ready.
hook.Add("InitPostEntity", "MilBase.EventAutoDetect", function()
	MilBase.AutoDetectSpawns()
end)

-- Late joiners / late-mounted addons on the client: refresh once more.
if CLIENT then
	hook.Add("OnGamemodeLoaded", "MilBase.EventAutoDetect", function()
		MilBase.AutoDetectSpawns()
	end)
end
