-- In-character ranged chat (Helix-style) and command dispatch.

local cfg = MilBase.Config

-- Sends raw colored text to everyone within `range` of `speaker`.
function MilBase.TalkRanged(speaker, range, ...)
	local receivers = {}
	local pos = speaker:GetPos()

	for _, ply in ipairs(player.GetAll()) do
		if range <= 0 or ply:GetPos():DistToSqr(pos) <= range * range then
			table.insert(receivers, ply)
		end
	end

	MilBase.ChatMsg(receivers, ...)
end

-- Standard in-character speech: "[Sergeant] John Doe: message"
function MilBase.SpeakIC(speaker, text, range, prefix)
	local faction = speaker:MBFaction()
	local rank = speaker:MBRank()

	local langID = speaker.MBEventLanguage and speaker:MBEventLanguage() or ""
	if langID ~= "" and langID ~= "basic" then
		local langObj = MilBase.GetLanguage and MilBase.GetLanguage(langID)
		local untranslated = langObj and langObj.untranslated or "[Unintelligible species speech]"

		local pos = speaker:GetPos()
		range = range or cfg.TalkRange or 300

		for _, listener in ipairs(player.GetAll()) do
			if range <= 0 or listener:GetPos():DistToSqr(pos) <= range * range then
				local understands = MilBase.ResolveLanguageForListener
					and MilBase.ResolveLanguageForListener(listener, langID, pos, range)

				if understands then
					MilBase.ChatMsg(listener,
						faction.color, "[" .. (rank and rank.name or faction.name) .. "] ",
						color_white, speaker:MBName(),
						Color(90, 205, 145), " [" .. string.upper(langID) .. " SUBTITLES]",
						Color(220, 220, 220), ": " .. (prefix or "") .. text)
				else
					MilBase.ChatMsg(listener,
						faction.color, "[" .. (rank and rank.name or faction.name) .. "] ",
						color_white, speaker:MBName(),
						Color(235, 95, 75), " [" .. string.upper(langID) .. "]",
						Color(200, 200, 200), ": " .. (prefix or "") .. untranslated)
				end
			end
		end
		return
	end

	MilBase.TalkRanged(speaker, range,
		faction.color, "[" .. (rank and rank.name or faction.name) .. "] ",
		color_white, speaker:MBName(),
		Color(220, 220, 220), ": " .. (prefix or "") .. text)
end

function GM:PlayerSay(ply, text)
	text = string.Trim(text)
	if text == "" then return "" end

	-- Messages beginning with the configured report prefix are staff alerts.
	-- Handle these before normal RP chat so the report text is never broadcast.
	local reportPrefix = tostring(cfg.ReportPrefix or "@")
	if reportPrefix ~= "" and string.sub(text, 1, #reportPrefix) == reportPrefix then
		local reportText = string.Trim(string.sub(text, #reportPrefix + 1))
		if MilBase.FileReport then
			MilBase.FileReport(ply, reportText)
		else
			MilBase.Notify(ply, "The staff alert system is not available yet.")
		end
		return ""
	end

	-- "//" is shorthand for /ooc
	if string.sub(text, 1, 2) == "//" then
		text = "/ooc " .. string.Trim(string.sub(text, 3))
	end

	if string.sub(text, 1, 1) == "/" then
		MilBase.HandleCommand(ply, text)
		return ""
	end

	-- Dead players can't speak in character.
	if not ply:Alive() then
		MilBase.Notify(ply, "You are dead. Use /ooc to talk out of character.")
		return ""
	end

	-- Plain chat is local IC; comms go through channel commands (/reg, /command,
	-- /enemy, ...) or the chatbox comms tabs.
	MilBase.SpeakIC(ply, text, cfg.TalkRange)
	return ""
end
