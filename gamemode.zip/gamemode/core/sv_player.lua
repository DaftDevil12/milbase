-- Player lifecycle: spawning, models, loadouts, movement, death, voice.

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Faction / rank / name mutation (single source of truth)
--------------------------------------------------------------------------

function MilBase.SetFaction(ply, factionID, rank, actor)
	local faction = MilBase.GetFaction(factionID)
	if not faction then return end
	local oldFactionID = ply:MBFactionID()
	local oldRank = ply:MBRankIndex()
	local newRank = math.Clamp(rank or 1, 1, #faction.ranks)

	ply:SetNWString("mb_faction", factionID)
	ply:SetNWInt("mb_rank", newRank)
	MilBase.SavePlayer(ply)
	if oldFactionID ~= factionID then
		hook.Run("MilBase.FactionChanged", ply, oldFactionID, factionID, actor)
	elseif oldRank ~= newRank then
		hook.Run("MilBase.RankChanged", ply, oldRank, newRank, actor)
	end

	if MilBase.QuartermasterReconcileGear and cfg.QuartermasterCleanupOnRoleChange ~= false and ply.mb_inv then
		MilBase.QuartermasterReconcileGear(ply, false)
	end
	if MilBase.QuartermasterUpdateArmorObjective then
		MilBase.QuartermasterUpdateArmorObjective(ply, "faction")
	end
	if MilBase.SpawnSelectorValidateChoice then
		MilBase.SpawnSelectorValidateChoice(ply, false)
	end
	if MilBase.SpawnSelectorMaybeOpen then
		MilBase.SpawnSelectorMaybeOpen(ply)
	end

	if ply:Alive() then ply:Spawn() end
end

function MilBase.SetRank(ply, rankIndex, actor)
	local faction = ply:MBFaction()
	if not faction then return end
	local oldRank = ply:MBRankIndex()
	local newRank = math.Clamp(rankIndex, 1, #faction.ranks)
	ply:SetNWInt("mb_rank", newRank)
	MilBase.SavePlayer(ply)
	if oldRank ~= newRank then
		hook.Run("MilBase.RankChanged", ply, oldRank, newRank, actor)
	end

	if MilBase.QuartermasterReconcileGear and cfg.QuartermasterCleanupOnRoleChange ~= false and ply.mb_inv then
		MilBase.QuartermasterReconcileGear(ply, false)
	end
	if MilBase.QuartermasterUpdateArmorObjective then
		MilBase.QuartermasterUpdateArmorObjective(ply, "rank")
	end
	if MilBase.SpawnSelectorValidateChoice then
		MilBase.SpawnSelectorValidateChoice(ply, false)
	end
	if MilBase.SpawnSelectorMaybeOpen then
		MilBase.SpawnSelectorMaybeOpen(ply)
	end

	if ply:Alive() then ply:Spawn() end
end

function MilBase.SetRPName(ply, name)
	name = MilBase.NamingCleanBaseName and MilBase.NamingCleanBaseName(name) or string.Trim(name or "")
	if #name < 3 or #name > 32 then
		MilBase.Notify(ply, "Personal names must be between 3 and 32 characters.")
		return false
	end

	ply:SetNWString("mb_name", name)
	MilBase.SavePlayer(ply)
	MilBase.Notify(ply, "You are now known as " .. ply:MBName() .. ".")
	return true
end

--------------------------------------------------------------------------
-- Movement speed authority
-- All states that affect speed (exhaustion, limping, wounded) funnel
-- through here so they compose instead of overwriting each other.
--------------------------------------------------------------------------

function MilBase.UpdateMoveSpeed(ply)
	local walk, run = cfg.WalkSpeed, cfg.RunSpeed

	if ply:GetNWBool("mb_wounded", false) then
		walk, run = 25, 25
	else
		if ply.mb_limping then
			walk = math.floor(walk * 0.6)
			run = walk
		end
		if ply.mb_exhausted then
			run = walk
		end
		if ply:GetNWBool("mb_cuffed", false) then
			walk = math.min(walk, math.floor(cfg.WalkSpeed * 0.7))
			run = walk
		end
	end

	ply:SetWalkSpeed(walk)
	ply:SetRunSpeed(run)
end

--------------------------------------------------------------------------
-- Weapon dropping
--------------------------------------------------------------------------

local noDrop = {
	weapon_physgun = true,
	gmod_tool = true,
	gmod_camera = true,
	weapon_fists = true,
	weapon_lscs = true, -- LSCS persists the saber build as inventory parts
}

-- Drops a weapon into the world with a cleanup timer. Returns true if
-- something was dropped.
function MilBase.DropWeapon(ply, wep)
	if not IsValid(wep) or noDrop[wep:GetClass()] then return false end

	ply:DropWeapon(wep)

	timer.Simple(120, function()
		if IsValid(wep) and not IsValid(wep:GetOwner()) then
			wep:Remove()
		end
	end)
	return true
end

function MilBase.DropActiveWeapon(ply)
	if not cfg.DropWeaponOnDeath then return end
	MilBase.DropWeapon(ply, ply:GetActiveWeapon())
end

-- Manually drop your held weapon (frees a carry slot).
MilBase.RegisterChatCommand("drop", {
	help = "Drop the weapon you're holding (frees a carry slot).",
	func = function(ply)
		if not ply:Alive() or ply:GetNWBool("mb_cuffed", false) then return end

		local wep = ply:GetActiveWeapon()
		local name = IsValid(wep) and (wep:GetPrintName() or wep:GetClass()) or ""
		if MilBase.DropWeapon(ply, wep) then
			MilBase.Notify(ply, "You drop your weapon.")
			MilBase.TalkRanged(ply, cfg.TalkRange, Color(190, 170, 220),
				"** " .. ply:MBName() .. " drops a " .. name)
		else
			MilBase.Notify(ply, "You can't drop that.")
		end
	end,
})

-- Drop a specific weapon by clicking its slot on the GEAR screen.
util.AddNetworkString("MilBase_DropSlot")
net.Receive("MilBase_DropSlot", function(_, ply)
	if not ply:Alive() or ply:GetNWBool("mb_cuffed", false) then return end

	local wep = net.ReadEntity()
	if not IsValid(wep) or wep:GetOwner() ~= ply then return end

	if MilBase.DropWeapon(ply, wep) then
		MilBase.Notify(ply, "You drop your weapon.")
	end
end)

--------------------------------------------------------------------------
-- Spawning
--------------------------------------------------------------------------

function GM:PlayerInitialSpawn(ply)
	self.BaseClass.PlayerInitialSpawn(self, ply)
	MilBase.LoadPlayer(ply)
end

function GM:PlayerSpawn(ply)
	local isEnemy = MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)
	ply:SetTeam(isEnemy and MilBase.EventEnemyTeam or ply:MBFaction().teamIndex)

	if MilBase.SpawnSelectorShouldHoldSpawn and MilBase.SpawnSelectorShouldHoldSpawn(ply) then
		self.BaseClass.PlayerSpawn(self, ply)
		MilBase.SpawnSelectorHoldSpawn(ply)
		return
	end

	self.BaseClass.PlayerSpawn(self, ply)

	ply:SetNWBool("mb_wounded", false)
	ply.mb_exhausted = false
	ply.mb_limping = false
	ply:SetJumpPower(200)
	ply:SetNWFloat("mb_stamina", 100)
	MilBase.UpdateMoveSpeed(ply)

	-- Certifications can raise max health (event enemies use class health).
	local maxHP = MilBase.CalcMaxHealth(ply)
	ply:SetMaxHealth(maxHP)
	ply:SetHealth(maxHP)

	if isEnemy then
		-- Event enemies get class armor / speed / spawn point instead of
		-- faction issue gear, star cards, etc.
		if MilBase.ApplyEventEnemyExtras then MilBase.ApplyEventEnemyExtras(ply) end
		return
	end

	-- Resupply to standard issue (faction/rank/cert `issue` tables).
	MilBase.TopUpIssue(ply)

	-- Equipped gear: armor points, model swaps, bodygroups, backpack.
	MilBase.ApplyEquipment(ply)

	-- Equipped star cards' custom effects.
	if MilBase.ApplyStarCards then MilBase.ApplyStarCards(ply) end
end

function GM:PlayerSetModel(ply)
	ply:SetModel(MilBase.GetPlayerModel(ply))
	ply:SetupHands()
end

function GM:PlayerLoadout(ply)
	ply:StripWeapons()
	ply:StripAmmo()

	-- Event enemies get their class weapons instead of faction issue.
	if MilBase.EventEnemyLoadout and MilBase.EventEnemyLoadout(ply) then
		return true
	end

	local faction = ply:MBFaction()
	local rank = ply:MBRank()

	local weapons = {}
	table.Add(weapons, cfg.DefaultLoadout)
	table.Add(weapons, faction.loadout)
	if rank and rank.loadout then table.Add(weapons, rank.loadout) end

	-- Certification weapons
	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[certID]
		if cert and cert.loadout then table.Add(weapons, cert.loadout) end
	end

	-- Equipped star card weapons
	if MilBase.StarCardLoadout then
		table.Add(weapons, MilBase.StarCardLoadout(ply))
	end

	-- Permanent weapon rewards unlocked from crates.
	if MilBase.CrateWeaponLoadout then
		table.Add(weapons, MilBase.CrateWeaponLoadout(ply))
	end

	local autoSelect = weapons[#weapons] or "weapon_fists"

	-- Admins keep their sandbox tools.
	if ply:IsAdmin() then
		table.Add(weapons, { "weapon_physgun", "gmod_tool", "gmod_camera" })
	end

	-- Issued loadouts bypass the weapon carry-slot limits.
	ply.mb_giveLoadout = true
	for _, class in ipairs(weapons) do
		ply:Give(class)
	end
	ply.mb_giveLoadout = false

	-- Spare magazines for every loadout weapon.
	for _, wep in ipairs(ply:GetWeapons()) do
		local ammoType = wep:GetPrimaryAmmoType()
		local clipSize = wep:GetMaxClip1()
		if ammoType >= 0 and clipSize > 0 then
			ply:GiveAmmo(clipSize * cfg.SpareMagazines, ammoType, true)
		end
	end

	ply:SelectWeapon(autoSelect)
	return true
end

--------------------------------------------------------------------------
-- Weapon carry slots (EFT style: 2 primaries + 1 secondary)
--------------------------------------------------------------------------

-- "primary" / "secondary" / nil (exempt: melee, grenades, tools).
function MilBase.WeaponSlotType(wep)
	local class = isstring(wep) and wep or wep:GetClass()
	if cfg.SlotExemptWeapons[class] then return nil end

	if cfg.SecondaryWeapons[class] then return "secondary" end

	local holdType
	if not isstring(wep) and wep.GetHoldType then
		holdType = wep:GetHoldType()
	end
	if holdType == "pistol" or holdType == "revolver" then return "secondary" end

	-- No magazine = melee/grenade/tool: exempt.
	if not isstring(wep) and wep:GetMaxClip1() <= 0 then return nil end

	return "primary"
end

hook.Add("PlayerCanPickupWeapon", "MilBase.WeaponSlots", function(ply, wep)
	if ply.mb_giveLoadout then return end

	local slotType = MilBase.WeaponSlotType(wep)
	if not slotType then return end

	local carried = 0
	for _, owned in ipairs(ply:GetWeapons()) do
		if MilBase.WeaponSlotType(owned) == slotType then
			carried = carried + 1
		end
	end

	local limit = slotType == "primary" and (cfg.PrimarySlots or 2)
		or (cfg.SecondarySlots or 1)

	if carried >= limit then
		if (ply.mb_slotNotify or 0) < CurTime() then
			ply.mb_slotNotify = CurTime() + 2
			MilBase.Notify(ply, "Your " .. slotType .. " weapon slots are full ("
				.. limit .. "). Drop one first.")
		end
		return false
	end
end)

--------------------------------------------------------------------------
-- Death & respawning
--------------------------------------------------------------------------

function GM:PlayerDeath(ply, inflictor, attacker)
	ply:SetNWFloat("mb_deathtime", CurTime())
	ply:SetNWBool("mb_wounded", false)
	MilBase.DropActiveWeapon(ply)

	-- Event enemies lose a life; they revert to their unit when out.
	if MilBase.OnEventEnemyDeath then MilBase.OnEventEnemyDeath(ply) end
end

function GM:PlayerDeathThink(ply)
	local deathTime = ply:GetNWFloat("mb_deathtime", 0)
	if CurTime() < deathTime + cfg.RespawnTime then return false end

	if MilBase.SpawnSelectorDeathThink and MilBase.SpawnSelectorDeathThink(ply) then
		return false
	end

	if ply:KeyPressed(IN_ATTACK) or ply:KeyPressed(IN_JUMP) or ply:KeyPressed(IN_ATTACK2) then
		ply:Spawn()
	end
	return false
end

function GM:GetFallDamage(ply, speed)
	if cfg.RealisticFallDamage then
		-- HL2DM "realistic" scaling: lethal around terminal velocity.
		return math.max(0, (speed - 526.5) * (100 / 396))
	end
	return 10
end

--------------------------------------------------------------------------
-- Voice: proximity based, 3D
--------------------------------------------------------------------------

function GM:PlayerCanHearPlayersVoice(listener, talker)
	-- Radio: if the talker is on a comm channel, hearing is decided by the
	-- channel (private, non-3D). nil = fall through to proximity.
	if MilBase.VoiceCanHear then
		local hear, threeD = MilBase.VoiceCanHear(listener, talker)
		if hear ~= nil then return hear, threeD end
	end

	if cfg.VoiceRange <= 0 then return true, false end
	return listener:GetPos():DistToSqr(talker:GetPos()) < cfg.VoiceRange * cfg.VoiceRange, true
end

--------------------------------------------------------------------------
-- Sandbox restrictions
--------------------------------------------------------------------------

function GM:PlayerNoClip(ply, desired)
	if not desired then return true end
	-- Event staff in the game-master build mode can always fly.
	return ply:IsAdmin() or ply:GetNWBool("mb_eventmode", false)
end

local restrictedHooks = {
	"PlayerSpawnProp", "PlayerSpawnSENT", "PlayerSpawnSWEP", "PlayerGiveSWEP",
	"PlayerSpawnEffect", "PlayerSpawnNPC", "PlayerSpawnRagdoll", "PlayerSpawnVehicle",
	"CanTool", "CanProperty",
}

for _, hookName in ipairs(restrictedHooks) do
	local restrictedHook = hookName
	hook.Add(restrictedHook, "MilBase.SandboxRestrict", function(ply, class)
		-- Event staff in game-master mode get full sandbox tools.
		if IsValid(ply) and ply:GetNWBool("mb_eventmode", false) then return end
		-- LSCS crafts its saber through PlayerGiveSWEP. Permit only that exact
		-- internal give for an authorised player with a complete equipped build;
		-- the spawn menu and every other sandbox SWEP remain staff-only.
		if restrictedHook == "PlayerGiveSWEP" and class == "weapon_lscs"
		and cfg.LSCS and cfg.LSCS.Enabled ~= false
		and ply.MBLSCSAccess and ply:MBLSCSAccess()
		and ply.lscsIsValid and ply:lscsIsValid() then
			return true
		end
		if cfg.SandboxAdminOnly and IsValid(ply) and not ply:IsAdmin() then
			return false
		end
	end)
end
