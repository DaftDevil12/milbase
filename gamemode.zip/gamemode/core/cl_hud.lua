--[[
	MilBase HUD, black & gold: identity card + vitals bottom-left (with
	injury badges above), ammo bottom-right, battlefront content-pack art
	(KIA marker, low-ammo warning), aim-to-identify nameplates with a
	health pip, and the KIA respawn screen.
]]

local cfg = MilBase.Config
local ui = MilBase.UI

local COL_HP = Color(255, 198, 60)     -- golden yellow
local COL_ARMOR = Color(205, 202, 190) -- silver
local COL_STAM = Color(190, 152, 70)   -- dark gold

local SHADOW = Color(0, 0, 0, 200)

local hiddenElements = {
	CHudHealth = true,
	CHudBattery = true,
	CHudAmmo = true,
	CHudSecondaryAmmo = true,
}

hook.Add("HUDShouldDraw", "MilBase.HideDefaultHUD", function(name)
	if hiddenElements[name] then return false end
end)

--------------------------------------------------------------------------
-- Vitals card (bottom left)
--------------------------------------------------------------------------

local function statRow(x, y, w, label, value, frac, color)
	draw.SimpleText(label, "MB.Tiny", x, y, ui.dim)
	draw.SimpleText(value, "MB.Tiny", x + w, y, ui.text, TEXT_ALIGN_RIGHT)
	MilBase.DrawBar(x, y + 15, w, 5, frac, color)
end

local function drawStatusBadges(ply, x, y, w)
	local badges = {}

	if ply:GetNWBool("mb_bleeding", false) then
		table.insert(badges, { text = "BLEEDING", color = ui.danger })
	end
	if ply:GetNWBool("mb_fractured", false) then
		table.insert(badges, { text = "FRACTURED LEG", color = ui.warn })
	end
	local pk = ply:GetNWFloat("mb_painkillers", 0) - CurTime()
	if pk > 0 then
		table.insert(badges, { text = "PAINKILLERS " .. math.ceil(pk) .. "s", color = ui.ok })
	end
	if ply:GetNWBool("mb_cuffed", false) then
		table.insert(badges, { text = "RESTRAINED", color = ui.warn })
	end
	if ply:GetNWBool("mb_infected", false) then
		table.insert(badges, { text = "INFECTED", color = Color(160, 120, 205) })
	end
	if ply:GetNWBool("mb_sealed", false) then
		table.insert(badges, { text = "SUIT SEALED", color = Color(110, 190, 220) })
	end
	if ply:GetNWBool("mb_zerog", false) then
		table.insert(badges, { text = "ZERO GRAVITY", color = Color(120, 200, 255) })
	elseif MilBase.PlayerInZeroG and MilBase.PlayerInZeroG(ply)
	and ply:GetNWBool("mb_magboots_on", false) then
		table.insert(badges, { text = "MAG-BOOTS ENGAGED", color = ui.ok })
	end

	for i, badge in ipairs(badges) do
		local by = y - i * 24
		MilBase.DrawPanelBF2(x, by, w, 20, { cut = 5, accent = badge.color })
		draw.SimpleText(badge.text, "MB.Tiny", x + 12, by + 10, badge.color,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

local function drawVitals(ply)
	local faction = ply:MBFaction()
	local rank = ply:MBRank()

	local rows = 1 -- health
	if ply:Armor() > 0 then rows = rows + 1 end
	if cfg.StaminaEnabled then rows = rows + 1 end

	local w = 300
	local h = 58 + rows * 26
	local defaultY = ScrH() - h - 20

	local x, y = 20, defaultY
	if MilBase.GetHUDPosition then
		x, y = MilBase.GetHUDPosition("vitals", 20, defaultY)
	end

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, accent = faction and faction.color or ui.accent })

	-- Identity
	draw.SimpleText(ply:MBName(), "MB.Med", x + 16, y + 9, ui.text)
	local title = (rank and rank.name or "")
		.. (faction and ("  •  " .. faction.name) or "")
	draw.SimpleText(string.upper(title), "MB.Tiny", x + 16, y + 32,
		faction and faction.color or ui.dim)
	draw.SimpleText(cfg.CurrencySymbol .. " " .. ply:MBMoney(), "MB.Small",
		x + w - 14, y + 11, ui.accent, TEXT_ALIGN_RIGHT)

	-- Vitals
	local rowX, rowW = x + 16, w - 32
	local rowY = y + 52

	local hpFrac = ply:Health() / math.max(ply:GetMaxHealth(), 1)
	statRow(rowX, rowY, rowW, "HEALTH", ply:Health(), hpFrac,
		hpFrac <= 0.3 and ui.danger or COL_HP)
	rowY = rowY + 26

	if ply:Armor() > 0 then
		statRow(rowX, rowY, rowW, "ARMOR", ply:Armor(), ply:Armor() / 100, COL_ARMOR)
		rowY = rowY + 26
	end

	if cfg.StaminaEnabled then
		local stamina = ply:GetNWFloat("mb_stamina", 100)
		statRow(rowX, rowY, rowW, "STAMINA", math.floor(stamina), stamina / 100, COL_STAM)
	end

	local badgeX, badgeY = x, y - 6
	if MilBase.GetHUDPosition then
		badgeX, badgeY = MilBase.GetHUDPosition("status_badges", x, y - 6)
	end
	drawStatusBadges(ply, badgeX, badgeY, 160)
end

--------------------------------------------------------------------------
-- Ammo (bottom right)
--------------------------------------------------------------------------

local function safeWeaponCall(wep, method, ...)
	if not (IsValid(wep) and isfunction(wep[method])) then return nil end
	local ok, value, extra = pcall(wep[method], wep, ...)
	if not ok then return nil end
	return value, extra
end

local function arcCWWeapon(wep)
	if not IsValid(wep) then return false end
	if wep.ArcCW == true then return true end
	return isstring(wep.Base) and string.find(string.lower(wep.Base), "arccw", 1, true) ~= nil
end

local function ammoTypeName(ammoType)
	if not isstring(ammoType) or ammoType == "" or ammoType == "none" then return "" end
	local translated = language.GetPhrase(ammoType .. "_ammo")
	if translated == ammoType .. "_ammo" then translated = language.GetPhrase(ammoType) end
	if translated == ammoType then return string.upper(ammoType) end
	return string.upper(translated)
end

local function buildAmmoData(ply, wep)
	if arcCWWeapon(wep) and cfg.ArcCWHUDEnabled ~= false and isfunction(wep.GetHUDData) then
		local ok, raw = pcall(wep.GetHUDData, wep)
		if ok and istable(raw) then
			local capacity = tonumber(safeWeaponCall(wep, "GetCapacity")) or tonumber(wep:GetMaxClip1()) or 0
			local clipNumber = tonumber(raw.clip)
			local inUBGL = safeWeaponCall(wep, "GetInUBGL") == true
			local jammed = safeWeaponCall(wep, "GetMalfunctionJam") == true
			return {
				arccw = true,
				clip = raw.clip,
				clip_number = clipNumber,
				reserve = raw.ammo,
				capacity = math.max(0, capacity),
				mode = tostring(raw.mode or ""),
				ammo_type = ammoTypeName(raw.ammotype),
				heat_enabled = raw.heat_enabled == true,
				heat = tonumber(raw.heat_level or 0) or 0,
				heat_max = math.max(0, tonumber(raw.heat_maxlevel or 0) or 0),
				heat_locked = raw.heat_locked == true,
				jammed = jammed,
				ubgl = raw.clip2 ~= nil and {
					active = inUBGL,
					clip = raw.clip2,
					reserve = raw.ammo2,
					ammo_type = ammoTypeName(raw.ammotype2),
				} or nil,
			}
		end
	end

	local maxClip = wep:GetMaxClip1()
	if maxClip <= 0 then return nil end
	return {
		arccw = false,
		clip = wep:Clip1(),
		clip_number = wep:Clip1(),
		reserve = ply:GetAmmoCount(wep:GetPrimaryAmmoType()),
		capacity = math.max(maxClip, 1),
	}
end

local function drawAmmo(ply)
	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) then return end
	local data = buildAmmoData(ply, wep)
	if not data then return end

	local clipNumber = tonumber(data.clip_number)
	local low = clipNumber ~= nil and data.capacity > 0
		and clipNumber <= math.max(1, math.floor(data.capacity * 0.25))
	local accent = data.jammed and ui.danger
		or (data.heat_locked and ui.danger)
		or (low and ui.danger or ui.accent)

	local w = data.arccw and 250 or 180
	local h = data.arccw and 92 or 58
	local defaultX, defaultY = ScrW() - w - 20, ScrH() - h - 20
	local x, y = defaultX, defaultY
	if MilBase.GetHUDPosition then
		x, y = MilBase.GetHUDPosition("ammo", defaultX, defaultY)
	end
	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, accent = accent })

	if low or data.jammed or data.heat_locked then
		local warn = MilBase.GetUIMat(ui.art.ammoLow)
		if warn then
			local pulse = 140 + 90 * math.sin(RealTime() * 6)
			surface.SetDrawColor(220, 80, 70, pulse)
			surface.SetMaterial(warn)
			surface.DrawTexturedRect(x + 10, y + 13, 24, 24)
		end
	end

	local clipText = tostring(data.clip == nil and "-" or data.clip)
	local reserveText = tostring(data.reserve == nil and "-" or data.reserve)
	local ammoColor = clipNumber == 0 and ui.danger or ui.text
	draw.SimpleText(clipText, "MB.Big", x + w / 2 - 8, y + 19,
		ammoColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	draw.SimpleText("/ " .. reserveText, "MB.Small", x + w / 2 - 2, y + 22,
		ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	if data.arccw then
		local status = ""
		local statusColor = ui.dim
		if data.jammed then
			status, statusColor = "JAMMED", ui.danger
		elseif data.heat_enabled and data.heat_max > 0 then
			local heatPercent = math.floor(math.Clamp(data.heat / data.heat_max, 0, 1) * 100)
			status = "HEAT " .. heatPercent .. "%"
			statusColor = data.heat_locked and ui.danger or (heatPercent >= 75 and ui.warn or ui.dim)
		end

		if cfg.ArcCWHUDShowFiremode ~= false and data.mode ~= "" then
			draw.SimpleText(string.upper(data.mode), "MB.Tiny", x + 14, y + 45, ui.text)
		end
		if cfg.ArcCWHUDShowAmmoType ~= false and data.ammo_type ~= "" then
			draw.SimpleText(data.ammo_type, "MB.Tiny", x + w - 14, y + 45, ui.faint, TEXT_ALIGN_RIGHT)
		end
		if status ~= "" and cfg.ArcCWHUDShowHeat ~= false then
			draw.SimpleText(status, "MB.Tiny", x + w - 14, y + 61, statusColor, TEXT_ALIGN_RIGHT)
		end
		if data.heat_enabled and data.heat_max > 0 and cfg.ArcCWHUDShowHeat ~= false then
			MilBase.DrawBar(x + 14, y + 65, w - 28, 5,
				math.Clamp(data.heat / data.heat_max, 0, 1), statusColor)
		end
		if data.ubgl and cfg.ArcCWHUDShowUnderbarrel ~= false then
			local ubglColor = data.ubgl.active and ui.accent or ui.faint
			local ubglText = "UBGL " .. tostring(data.ubgl.clip or "-") .. " / " .. tostring(data.ubgl.reserve or "-")
			draw.SimpleText(ubglText, "MB.Tiny", x + 14, y + 61, ubglColor)
		end
	end

	local wepName = language.GetPhrase(wep:GetPrintName() or wep:GetClass())
	draw.SimpleText(string.upper(wepName), "MB.Tiny", x + w / 2, y + h - 12,
		ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
--------------------------------------------------------------------------
-- Daily orders tracker (top right)
--------------------------------------------------------------------------

local function dailyResetText(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds or 0) or 0))
	local hours = math.floor(seconds / 3600)
	local minutes = math.floor((seconds % 3600) / 60)
	return string.format("%02d:%02d", hours, minutes)
end

local function drawDailyQuestTracker()
	if cfg.DailyQuestHUDTracker == false or cfg.DailyQuestsEnabled == false then return end
	local state = MilBase.DailyQuests and MilBase.DailyQuests.ClientState
	if not istable(state) or not state.loaded or not istable(state.quests) or #state.quests == 0 then return end

	local rows = {}
	for _, quest in ipairs(state.quests) do
		if not quest.claimed then rows[#rows + 1] = quest end
	end
	if #rows == 0 then return end
	table.sort(rows, function(a, b)
		if (a.complete == true) ~= (b.complete == true) then return a.complete == true end
		return tostring(a.name or "") < tostring(b.name or "")
	end)

	local maxRows = math.Clamp(math.floor(tonumber(cfg.DailyQuestHUDMaxRows or 3) or 3), 1, 5)
	local count = math.min(#rows, maxRows)
	local w, headerH, rowH = 310, 40, 47
	local h = headerH + count * rowH + 8
	local defaultX = ScrW() - w - 20
	local defaultY = 20
	if cfg.DefconHUDEnabled ~= false and cfg.DefconHUDPosition == "top_right" then defaultY = 116 end

	local x, y = defaultX, defaultY
	if MilBase.GetHUDPosition then
		x, y = MilBase.GetHUDPosition("daily_quests", defaultX, defaultY)
	end

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 9, accent = ui.accent })
	draw.SimpleText("DAILY ORDERS", "MB.Small", x + 14, y + 11, ui.text)
	local elapsed = RealTime() - tonumber(state.received_at or RealTime())
	local remaining = math.max(0, (tonumber(state.reset_in or 0) or 0) - elapsed)
	draw.SimpleText("RESET " .. dailyResetText(remaining), "MB.Tiny", x + w - 14, y + 14, ui.faint, TEXT_ALIGN_RIGHT)

	for index = 1, count do
		local quest = rows[index]
		local qy = y + headerH + (index - 1) * rowH
		local target = math.max(1, tonumber(quest.target or 1) or 1)
		local progress = math.Clamp(tonumber(quest.progress or 0) or 0, 0, target)
		local complete = quest.complete == true or progress >= target
		local color = IsColor(quest.color) and quest.color or ui.accent
		if complete then color = ui.ok end
		draw.SimpleText(string.upper(quest.name or "ORDER"), "MB.Tiny", x + 14, qy + 5, color)
		draw.SimpleText(complete and "CLAIM" or (math.floor(progress) .. "/" .. math.floor(target)), "MB.Tiny",
			x + w - 14, qy + 5, complete and ui.ok or ui.text, TEXT_ALIGN_RIGHT)
		MilBase.DrawBar(x + 14, qy + 25, w - 28, 5, progress / target, color)
	end
end

--------------------------------------------------------------------------
-- Recognition: aim at soldiers (or dropped items) to identify them
--------------------------------------------------------------------------

local ID_RANGE_SQR = 350 * 350

local function drawTargetID(ply)
	local tr = ply:GetEyeTrace()
	local target = tr.Entity
	if not IsValid(target) then return end
	if target:GetPos():DistToSqr(ply:GetPos()) > ID_RANGE_SQR then return end

	if target:IsPlayer() and target:Alive() then
		local faction = target:MBFaction()
		local rank = target:MBRank()
		local head = target:GetPos() + Vector(0, 0, target:OBBMaxs().z + 12)
		local screen = head:ToScreen()
		if not screen.visible then return end

		draw.SimpleTextOutlined(target:MBName(), "MB.Small", screen.x, screen.y - 16,
			ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, SHADOW)
		draw.SimpleTextOutlined(string.upper(rank and rank.name or ""), "MB.Tiny",
			screen.x, screen.y, faction and faction.color or ui.dim,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, SHADOW)

		-- Nameplate health pip
		MilBase.DrawBar(screen.x - 40, screen.y + 10, 80, 4,
			target:Health() / math.max(target:GetMaxHealth(), 1), COL_HP)

		if target:GetNWBool("mb_wounded", false) then
			draw.SimpleTextOutlined("WOUNDED — HOLD [E] TO STABILIZE", "MB.Small",
				screen.x, screen.y + 26, ui.danger,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, SHADOW)
		end

	elseif target:GetClass() == "mb_item" then
		local def = MilBase.Items[target:GetItemID()]
		if not def then return end

		local screen = (target:GetPos() + Vector(0, 0, 12)):ToScreen()
		if not screen.visible then return end

		local label = def.name
		if target:GetAmount() > 1 then label = label .. " x" .. target:GetAmount() end

		draw.SimpleTextOutlined(label, "MB.Small", screen.x, screen.y - 10,
			ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, SHADOW)
		draw.SimpleTextOutlined("[E] TAKE", "MB.Tiny", screen.x, screen.y + 6,
			ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, SHADOW)
	end
end

--------------------------------------------------------------------------
-- Death screen
--------------------------------------------------------------------------

local function drawDeathScreen(ply)
	surface.SetDrawColor(8, 2, 2, 190)
	surface.DrawRect(0, 0, ScrW(), ScrH())

	-- KIA marker from the content pack.
	local marker = MilBase.GetUIMat(ui.art.killed)
	if marker then
		surface.SetDrawColor(220, 80, 70, 230)
		surface.SetMaterial(marker)
		surface.DrawTexturedRect(ScrW() / 2 - 56, ScrH() / 2 - 176, 112, 112)
	end

	draw.SimpleText("K.I.A.", "MB.Huge", ScrW() / 2, ScrH() / 2 - 40,
		Color(220, 80, 70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	local remaining = (ply:GetNWFloat("mb_deathtime", 0) + cfg.RespawnTime) - CurTime()
	local text = remaining > 0
		and ("RESPAWN AVAILABLE IN " .. math.ceil(remaining) .. "s")
		or "PRESS SPACE TO RESPAWN"

	draw.SimpleText(text, "MB.Tab", ScrW() / 2, ScrH() / 2 + 22,
		ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

hook.Add("HUDPaint", "MilBase.HUD", function()
	if MilBase.InEventView() then return end
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	if not ply:Alive() then
		drawDeathScreen(ply)
		return
	end

	-- In an LVS vehicle the cockpit HUD takes those corners; only keep
	-- the aim-to-identify nameplates.
	if MilBase.InVehicleHUD() then
		drawTargetID(ply)
		return
	end

	drawDailyQuestTracker()
	drawVitals(ply)
	drawAmmo(ply)
	drawTargetID(ply)
end)
