--[[
	ArcCW integration helpers shared by factions, certifications, crates and
	star cards. Faction/cert attachment tables are issued entitlements; crate
	rewards are stored as character-specific owned attachments and weapons by
	core/sv_arccw_support.lua.
]]

local function trim(value)
	return string.Trim(tostring(value or ""))
end

function MilBase.CopyCountMap(source, maxAmount)
	local out = {}
	if not istable(source) then return out end
	for id, amount in pairs(source) do
		if isnumber(id) and isstring(amount) then id, amount = amount, 1 end
		id = trim(id)
		amount = math.floor(tonumber(amount) or 0)
		if id ~= "" and amount > 0 then
			out[id] = math.Clamp(amount, 1, maxAmount or 1000)
		end
	end
	return out
end

function MilBase.ArcCWCanonicalAttachment(id)
	id = trim(id)
	if id == "" then return "" end
	local registry = ArcCW and ArcCW.AttachmentTable
	local definition = registry and registry[id]
	if definition and definition.InvAtt then return tostring(definition.InvAtt) end
	return id
end

function MilBase.ArcCWAttachmentName(id)
	id = trim(id)
	local definition = ArcCW and ArcCW.AttachmentTable and ArcCW.AttachmentTable[id]
	return definition and tostring(definition.PrintName or definition.AbbrevName or id) or id
end

function MilBase.WeaponDisplayName(class)
	class = trim(class)
	local definition = weapons and weapons.GetStored and weapons.GetStored(class)
	return definition and tostring(definition.PrintName or class) or class
end

local function mergeEntitlement(into, source)
	for id, amount in pairs(MilBase.CopyCountMap(source, 1000)) do
		id = MilBase.ArcCWCanonicalAttachment(id)
		if id ~= "" then into[id] = math.max(into[id] or 0, amount) end
	end
end

function MilBase.ArcCWAttachmentEntitlements(ply)
	local out = {}
	if not IsValid(ply) then return out end
	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	mergeEntitlement(out, faction and faction.attachments)
	mergeEntitlement(out, rank and rank.attachments)
	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs and MilBase.Certs[certID]
		mergeEntitlement(out, cert and cert.attachments)
	end
	if MilBase.StarCardAttachments then MilBase.StarCardAttachments(ply, out) end
	return out
end

function MilBase.IsStunWeapon(wep)
	if not IsValid(wep) then return false end
	local class = string.lower(wep:GetClass())
	if string.find(class, "stun", 1, true) then return true end
	if wep.IsStun or wep.StunMode then return true end
	if wep.Attachments then
		for _, att in pairs(wep.Attachments) do
			if att.Installed and string.find(string.lower(tostring(att.Installed)), "stun", 1, true) then
				return true
			end
		end
	end
	return false
end

if SERVER then
	function MilBase.ApplyStunEffect(target, attacker)
		if not IsValid(target) or (not target:IsNPC() and not target:IsPlayer()) then return end

		local ed = EffectData()
		ed:SetEntity(target)
		ed:SetOrigin(target:WorldSpaceCenter())
		ed:SetMagnitude(2)
		ed:SetScale(2)
		util.Effect("TeslaHitBoxes", ed, true, true)
		util.Effect("StunstickImpact", ed, true, true)

		target:EmitSound("ambient/energy/zap" .. math.random(1, 3) .. ".wav", 75, math.random(95, 105))

		local P = MilBase.Prison
		if P and P.IsPrisonerEntity and P.IsPrisonerEntity(target) then
			target.mb_prisonStuckAttempts = 0
			target.mb_isStunned = true
			target.mb_stunnedUntil = CurTime() + 5

			if target.SelectPrisonActivity then
				target:SelectPrisonActivity("kneel", true)
			end

			if IsValid(attacker) and attacker:IsPlayer() then
				local record = P.GetRecord and P.GetRecord(target:GetPrisonerID())
				if record then
					record.status = "escorting"
					record.escortSteamID = attacker:SteamID64()
					record.escortAssistSteamID = ""
					if P.UpdateNetwork then P.UpdateNetwork(record) end
					if MilBase.Notify then
						MilBase.Notify(attacker, "Detainee stunned & re-secured in escort custody.", "ok")
					end
				end
			end
		elseif target:IsPlayer() then
			target:SetWalkSpeed(50)
			target:SetRunSpeed(50)
			timer.Simple(5, function()
				if IsValid(target) then
					target:SetWalkSpeed(200)
					target:SetRunSpeed(240)
				end
			end)
		end
	end

	hook.Add("EntityTakeDamage", "MilBase.StunWeaponDetection", function(target, dmg)
		local attacker = dmg:GetAttacker()
		local wep = dmg:GetInflictor()
		if IsValid(attacker) and attacker:IsPlayer() and (not IsValid(wep) or not wep:IsWeapon()) then
			wep = attacker:GetActiveWeapon()
		end

		if IsValid(wep) and MilBase.IsStunWeapon(wep) then
			MilBase.ApplyStunEffect(target, attacker)
		end
	end)
end

if CLIENT then
	local function contains(value, query)
		return query == "" or string.find(string.lower(tostring(value or "")), query, 1, true) ~= nil
	end

	concommand.Add("mb_arccw_attachment_list", function(_, _, args)
		local query = string.lower(string.Trim(table.concat(args or {}, " ")))
		if not (ArcCW and istable(ArcCW.AttachmentTable)) then
			MsgC(Color(255, 120, 90), "[MilBase] ArcCW attachment registry is unavailable.\n")
			return
		end
		MsgC(Color(100, 190, 255), "[MilBase] ArcCW attachment ids", color_white,
			query ~= "" and (" matching '" .. query .. "'") or "", ":\n")
		local count = 0
		for id, definition in SortedPairs(ArcCW.AttachmentTable) do
			local name = tostring(definition.PrintName or definition.AbbrevName or id)
			if contains(id, query) or contains(name, query) then
				MsgC(Color(255, 205, 90), tostring(id), color_white, "  -  ", name, "\n")
				count = count + 1
			end
		end
		MsgC(color_white, "[MilBase] ", tostring(count), " attachment(s) listed.\n")
	end)

	concommand.Add("mb_weapon_class_list", function(_, _, args)
		local query = string.lower(string.Trim(table.concat(args or {}, " ")))
		MsgC(Color(100, 190, 255), "[MilBase] weapon classes",
			color_white, query ~= "" and (" matching '" .. query .. "'") or "", ":\n")
		local rows = {}
		for _, definition in ipairs(weapons.GetList() or {}) do
			local class = tostring(definition.ClassName or "")
			local name = tostring(definition.PrintName or class)
			if class ~= "" and (contains(class, query) or contains(name, query)) then
				rows[class] = name
			end
		end
		for class, name in SortedPairs(rows) do
			MsgC(Color(255, 205, 90), class, color_white, "  -  ", name, "\n")
		end
		MsgC(color_white, "[MilBase] ", tostring(table.Count(rows)), " weapon class(es) listed.\n")
	end)
end
