--[[
	Chat command system. Register a command from anywhere:

	MilBase.RegisterChatCommand("salute", {
		help = "Salute a superior officer.",
		func = function(ply, args, rawText) ... end, -- runs SERVERSIDE
	})
]]

MilBase.Commands = MilBase.Commands or {}

function MilBase.RegisterChatCommand(name, data)
	data.name = string.lower(name)
	data.help = data.help or ""
	MilBase.Commands[data.name] = data
end

if SERVER then
	-- Called from PlayerSay for any message starting with "/".
	function MilBase.HandleCommand(ply, text)
		local args = string.Explode(" ", string.Trim(string.sub(text, 2)))
		local cmdName = string.lower(table.remove(args, 1) or "")
		local cmd = MilBase.Commands[cmdName]

		if not cmd then
			MilBase.Notify(ply, "Unknown command: /" .. cmdName)
			return
		end

		if cmd.adminOnly and not ply:IsAdmin() then
			MilBase.Notify(ply, "You don't have permission to use /" .. cmdName)
			return
		end

		local rawText = string.Trim(string.sub(text, #cmdName + 3))
		cmd.func(ply, args, rawText)
	end

	-- Can `actor` promote/demote/certify `target`?
	-- Admins always can; otherwise requires same faction, a rank with
	-- canPromote, and outranking the target.
	function MilBase.CanManage(actor, target)
		if actor:IsAdmin() then return true end
		if actor:MBFactionID() ~= target:MBFactionID() then return false end

		local rank = actor:MBRank()
		if not rank or not rank.canPromote then return false end

		return actor:MBRankIndex() > target:MBRankIndex()
	end
end

--------------------------------------------------------------------------
-- Roleplay chat commands
--------------------------------------------------------------------------

local COL_ACTION = Color(190, 170, 220)
local COL_OOC = Color(160, 160, 160)
local COL_RADIO = Color(120, 200, 140)
local COL_PM = Color(220, 160, 220)
local COL_ROLL = Color(255, 198, 60)
local COL_ROLL_RESULT = Color(115, 225, 145)

-- Stop /me from being used to imitate a server-generated numeric roll while
-- leaving ordinary actions such as "rolls up their sleeves" untouched.
local function claimsNumericRoll(text)
	local lower = string.lower(string.Trim(text or ""))
	return string.match(lower, "^rolls?%s+.*%d") ~= nil
		or string.match(lower, "^rolled%s+.*%d") ~= nil
end

MilBase.RegisterChatCommand("me", {
	help = "Describe an action, e.g. /me salutes.",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		if claimsNumericRoll(rawText) then
			MilBase.Notify(ply, "Numeric dice results must use /roll.")
			return
		end
		MilBase.TalkRanged(ply, MilBase.Config.TalkRange,
			COL_ACTION, "** " .. ply:MBName() .. " " .. rawText)
	end,
})

MilBase.RegisterChatCommand("it", {
	help = "Describe the environment, e.g. /it the alarm blares.",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		MilBase.TalkRanged(ply, MilBase.Config.TalkRange, COL_ACTION, "** " .. rawText)
	end,
})

MilBase.RegisterChatCommand("roll", {
	help = "Generate a verified server roll between 1 and 100.",
	func = function(ply)
		local result = math.random(1, 100)
		MilBase.TalkRanged(ply, MilBase.Config.TalkRange,
			COL_ROLL, "[VERIFIED ROLL] ",
			color_white, ply:MBName(),
			Color(210, 215, 225), " rolled ",
			COL_ROLL_RESULT, tostring(result),
			Color(170, 175, 185), " / 100")
	end,
})

MilBase.RegisterChatCommand("w", {
	help = "Whisper to players right next to you.",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		MilBase.SpeakIC(ply, rawText, MilBase.Config.WhisperRange, "(whispers) ")
	end,
})

MilBase.RegisterChatCommand("y", {
	help = "Yell so distant players can hear you.",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		MilBase.SpeakIC(ply, rawText, MilBase.Config.YellRange, "(yells) ")
	end,
})

MilBase.RegisterChatCommand("r", {
	help = "Radio your faction, e.g. /r contact at the front gate.",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		if not ply:Alive() then
			MilBase.Notify(ply, "You can't use the radio while dead.")
			return
		end

		local faction = ply:MBFaction()
		local receivers = {}
		for _, other in ipairs(player.GetAll()) do
			if other:MBFactionID() == ply:MBFactionID() then
				table.insert(receivers, other)
			end
		end

		MilBase.ChatMsg(receivers,
			COL_RADIO, "[RADIO] ", faction.color, ply:MBFullTitle(),
			color_white, ": " .. rawText)
	end,
})

MilBase.RegisterChatCommand("ooc", {
	help = "Global out-of-character chat (// also works).",
	func = function(ply, args, rawText)
		if rawText == "" then return end
		if not MilBase.Config.OOCEnabled then
			MilBase.Notify(ply, "OOC chat is disabled.")
			return
		end
		MilBase.ChatMsg(nil, COL_OOC, "[OOC] ", color_white, ply:Nick(),
			COL_OOC, ": " .. rawText)
	end,
})

MilBase.RegisterChatCommand("pm", {
	help = "Private message: /pm <player> <message>",
	func = function(ply, args, rawText)
		local targetName = table.remove(args, 1)
		local msg = table.concat(args, " ")
		local target = MilBase.FindPlayer(targetName)

		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end
		if msg == "" then return end

		MilBase.ChatMsg(target, COL_PM, "[PM from " .. ply:MBName() .. "] ", color_white, msg)
		MilBase.ChatMsg(ply, COL_PM, "[PM to " .. target:MBName() .. "] ", color_white, msg)
	end,
})

--------------------------------------------------------------------------
-- Character commands
--------------------------------------------------------------------------

MilBase.RegisterChatCommand("name", {
	help = "Set your personal name: /name Bob (prefix/rank/number are automatic)",
	func = function(ply, args, rawText)
		MilBase.SetRPName(ply, rawText)
	end,
})

--------------------------------------------------------------------------
-- Promotion / management commands
--------------------------------------------------------------------------

-- Promote/demote by entity (used by commands and the interaction menu).
function MilBase.ChangeRank(ply, target, delta)
	if not MilBase.CanManage(ply, target) then
		MilBase.Notify(ply, "You can't manage that soldier.")
		return
	end

	local faction = target:MBFaction()
	local newRank = math.Clamp(target:MBRankIndex() + delta, 1, #faction.ranks)
	if newRank == target:MBRankIndex() then
		MilBase.Notify(ply, "No rank change possible.")
		return
	end

	MilBase.SetRank(target, newRank, ply)
	local verb = delta > 0 and "promoted" or "demoted"
	MilBase.ChatMsg(nil, faction.color, "[" .. faction.name .. "] ", color_white,
		target:MBName() .. " has been " .. verb .. " to " .. faction.ranks[newRank].name
		.. " by " .. ply:MBName() .. ".")
end

local function changeRank(ply, targetName, delta)
	local target = MilBase.FindPlayer(targetName)
	if not IsValid(target) then
		MilBase.Notify(ply, "Player not found.")
		return
	end
	MilBase.ChangeRank(ply, target, delta)
end

MilBase.RegisterChatCommand("promote", {
	help = "Promote a soldier one rank: /promote <name>",
	func = function(ply, args) changeRank(ply, args[1], 1) end,
})

MilBase.RegisterChatCommand("demote", {
	help = "Demote a soldier one rank: /demote <name>",
	func = function(ply, args) changeRank(ply, args[1], -1) end,
})

MilBase.RegisterChatCommand("setrank", {
	help = "(Admin) Set a player's rank: /setrank <name> <rank number or name>",
	adminOnly = true,
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end

		local faction = target:MBFaction()
		local wanted = table.concat(args, " ", 2)
		local rankIndex = tonumber(wanted)

		if not rankIndex then
			for i, rank in ipairs(faction.ranks) do
				if string.find(string.lower(rank.name), string.lower(wanted), 1, true) then
					rankIndex = i
					break
				end
			end
		end

		if not rankIndex or not faction.ranks[rankIndex] then
			MilBase.Notify(ply, "Invalid rank for " .. faction.name .. ".")
			return
		end

		MilBase.SetRank(target, rankIndex, ply)
		MilBase.Notify(ply, target:MBName() .. " is now " .. faction.ranks[rankIndex].name .. ".")
	end,
})

-- Assign by entity (used by /setfaction and the interaction menu).
-- Officers recruit from the default faction into their own regiment, or
-- discharge their own lower-ranked soldiers; admins assign anyone.
function MilBase.TryAssignFaction(ply, target, faction)
	if not ply:IsAdmin() then
		local rank = ply:MBRank()
		local isOfficer = rank and rank.canPromote
		local defaultID = MilBase.Config.DefaultFaction

		local recruiting = faction.id == ply:MBFactionID()
			and target:MBFactionID() == defaultID
		local discharging = faction.id == defaultID
			and target:MBFactionID() == ply:MBFactionID()
			and ply:MBRankIndex() > target:MBRankIndex()

		if not isOfficer or not (recruiting or discharging) then
			MilBase.Notify(ply, "Officers can recruit from the "
				.. ((MilBase.GetFaction(defaultID) or {}).name or "recruits")
				.. " into their own regiment, or discharge their own soldiers.")
			return false
		end
	end

	MilBase.SetFaction(target, faction.id, nil, ply)
	MilBase.ChatMsg(nil, faction.color, "[" .. faction.name .. "] ", color_white,
		target:MBName() .. " has been assigned to " .. faction.name
		.. " by " .. ply:MBName() .. ".")
	MilBase.Notify(target, "You have been assigned to " .. faction.name .. ".")
	return true
end

MilBase.RegisterChatCommand("setfaction", {
	help = "Assign a player to a regiment: /setfaction <name> <faction id>. Officers recruit from the "
		.. "default faction into their own regiment (or discharge their soldiers back); admins assign anyone.",
	func = function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		local faction = MilBase.GetFaction(args[2] or "")

		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end
		if not faction then
			MilBase.Notify(ply, "Unknown faction id. Valid: " .. table.concat(MilBase.FactionOrder, ", "))
			return
		end

		MilBase.TryAssignFaction(ply, target, faction)
	end,
})
