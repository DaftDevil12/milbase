--[[
	Item registry and grid-inventory math (shared).

	Items are defined in config/sh_items.lua with MilBase.RegisterItem.
	Inventories are Tarkov-style grids: every item occupies w x h cells
	and can be rotated. The placement math lives here so both the server
	(authority) and the client (drag ghost preview) use identical rules.

	An inventory table looks like:
	  { w = 10, h = 6, items = { {uid, id, x, y, rot, amount, charges}, ... } }
]]

MilBase.Items = MilBase.Items or {}

function MilBase.RegisterItem(id, data)
	data.id = id
	data.name = data.name or id
	data.desc = data.desc or ""
	data.w = data.w or 1
	data.h = data.h or 1
	data.stack = data.stack or 1
	data.model = data.model or "models/props_junk/cardboard_box004a.mdl"

	MilBase.Items[id] = data
	return data
end



-- Finds an item by its displayed Name first (case-insensitive). A unique partial
-- name also works, so staff tools can use "Field Med" instead of the internal id.
-- Internal-id lookup is kept as a fallback for existing commands/configs.
function MilBase.FindItemByName(query)
	local needle = string.lower(string.Trim(tostring(query or "")))
	if needle == "" then return nil, nil, "empty" end

	for id, def in pairs(MilBase.Items) do
		if string.lower(string.Trim(def.name or id)) == needle then
			return id, def
		end
	end

	-- Backwards compatibility: old /giveitem usage passed item ids.
	for id, def in pairs(MilBase.Items) do
		if string.lower(string.Trim(id)) == needle then
			return id, def
		end
	end

	local matches = {}
	for id, def in pairs(MilBase.Items) do
		local name = string.lower(string.Trim(def.name or id))
		if string.find(name, needle, 1, true) then
			matches[#matches + 1] = { id = id, def = def }
		end
	end

	if #matches == 1 then
		return matches[1].id, matches[1].def
	end
	if #matches > 1 then
		return nil, nil, "ambiguous", matches
	end

	return nil, nil, "notfound"
end

function MilBase.SortedItemsByName()
	local list = {}
	for id, def in pairs(MilBase.Items or {}) do
		list[#list + 1] = { id = id, def = def, name = def.name or id }
	end
	table.sort(list, function(a, b)
		return string.lower(a.name) < string.lower(b.name)
	end)
	return list
end

-- Effective footprint, accounting for rotation.
function MilBase.ItemDims(def, rot)
	if rot then return def.h, def.w end
	return def.w, def.h
end

function MilBase.InvFind(inv, uid)
	for i, it in ipairs(inv.items) do
		if it.uid == uid then return it, i end
	end
end

-- Can `def` be placed at (x, y)? Returns ok plus any blocking items
-- (a single same-id blocker means the server may merge stacks).
function MilBase.InvCanPlace(inv, def, x, y, rot, ignoreUID)
	local w, h = MilBase.ItemDims(def, rot)
	if x < 1 or y < 1 or x + w - 1 > inv.w or y + h - 1 > inv.h then
		return false, {}
	end

	local blockers = {}
	for _, it in ipairs(inv.items) do
		if it.uid ~= ignoreUID then
			local idef = MilBase.Items[it.id]
			if idef then
				local iw, ih = MilBase.ItemDims(idef, it.rot)
				if x < it.x + iw and it.x < x + w and y < it.y + ih and it.y < y + h then
					table.insert(blockers, it)
				end
			end
		end
	end

	return #blockers == 0, blockers
end

-- First open position for an item, trying both orientations.
function MilBase.InvFindFreeSlot(inv, def)
	local rotations = (def.w == def.h) and { false } or { false, true }

	for _, rot in ipairs(rotations) do
		local w, h = MilBase.ItemDims(def, rot)
		for y = 1, inv.h - h + 1 do
			for x = 1, inv.w - w + 1 do
				if MilBase.InvCanPlace(inv, def, x, y, rot) then
					return x, y, rot
				end
			end
		end
	end
end
