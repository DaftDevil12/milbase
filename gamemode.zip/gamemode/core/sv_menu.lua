-- Server side of the F4 personnel menu. Roles are assigned by officers
-- and admins (/setfaction, /promote) - there is no self-service joining.

util.AddNetworkString("MilBase_OpenMenu")
util.AddNetworkString("MilBase_OpenStaffMenu")
util.AddNetworkString("MilBase_SetName")

-- F4 opens the personnel menu.
function GM:ShowSpare2(ply)
	MilBase.SendMenuData(ply)
end

-- F1 too, for new players who don't know the binds yet.
function GM:ShowHelp(ply)
	MilBase.SendMenuData(ply)
end

-- F2 opens the staff menu (staff, admins, or event staff).
function GM:ShowTeam(ply)
	if not IsValid(ply) then return end
	local allowed = ply:MBStaffLevel() > 0 or ply:IsAdmin()
		or (MilBase.CanRunEvents and MilBase.CanRunEvents(ply))
	if allowed then
		net.Start("MilBase_OpenStaffMenu")
		net.Send(ply)
	end
end

function MilBase.SendMenuData(ply)
	net.Start("MilBase_OpenMenu")
	net.Send(ply)
end

net.Receive("MilBase_SetName", function(_, ply)
	MilBase.SetRPName(ply, net.ReadString())
end)
