-- Shared species registry. Species is the authority for an NPC's native
-- language; models and language are never rolled independently.
MilBase.Species = MilBase.Species or {}
MilBase.SpeciesOrder = MilBase.SpeciesOrder or {}

local function cleanID(value)
	local id = string.lower(string.Trim(tostring(value or "")))
	id = string.gsub(id, "[^%w_%-]", "_")
	id = string.gsub(id, "_+", "_")
	return string.sub(id, 1, 48)
end

local function lower(value)
	return string.lower(tostring(value or ""))
end

function MilBase.RegisterSpecies(id, data)
	id = cleanID(id)
	assert(id ~= "", "Species id is required")
	data = table.Copy(data or {})
	data.id = id
	data.name = tostring(data.name or id)
	data.nativeLanguage = cleanID(data.nativeLanguage or "basic")
	data.models = data.models or {}
	data.names = data.names or {}
	if not MilBase.Species[id] then
		MilBase.SpeciesOrder[#MilBase.SpeciesOrder + 1] = id
	end
	MilBase.Species[id] = data
	return data
end

function MilBase.GetSpecies(id)
	return MilBase.Species[cleanID(id)] or MilBase.Species.human
end

local function hasAllTokens(value, tokens)
	value = lower(value)
	for _, token in ipairs(tokens or {}) do
		if not string.find(value, lower(token), 1, true) then return false end
	end
	return true
end

local function hasRejectedToken(value, tokens)
	value = lower(value)
	for _, token in ipairs(tokens or {}) do
		if string.find(value, lower(token), 1, true) then return true end
	end
	return false
end

local function modelMatches(row, alias, path)
	alias, path = lower(alias), lower(path)
	if row.path and path == lower(row.path) then return true end
	if row.alias and alias == lower(row.alias) then return true end
	for _, exact in ipairs(row.aliases or {}) do
		if alias == lower(exact) then return true end
	end
	local combined = alias .. " " .. path
	if hasRejectedToken(combined, row.rejectTokens) then return false end
	if row.tokens and hasAllTokens(combined, row.tokens) then return true end
	return false
end

function MilBase.SpeciesForModel(modelOrAlias)
	local wanted = lower(modelOrAlias)
	if wanted == "" then return MilBase.GetSpecies("human") end
	for _, speciesID in ipairs(MilBase.SpeciesOrder or {}) do
		local species = MilBase.Species[speciesID]
		for _, purposeRows in pairs(species.models or {}) do
			for _, row in ipairs(purposeRows or {}) do
				if modelMatches(row, wanted, wanted) then return species end
			end
		end
	end
	if string.find(wanted, "twilek", 1, true)
	or string.find(wanted, "twi_lek", 1, true) then return MilBase.GetSpecies("twilek") end
	if string.find(wanted, "togruta", 1, true) then return MilBase.GetSpecies("togruta") end
	if string.find(wanted, "zabrak", 1, true) then return MilBase.GetSpecies("zabrak") end
	if (string.find(wanted, "wookie", 1, true) or string.find(wanted, "wook", 1, true))
	and string.find(wanted, "wild", 1, true)
	and not hasRejectedToken(wanted, { "trooper", "41st", "kwehs", "server manager" }) then
		return MilBase.GetSpecies("wookiee")
	end
	-- Stock human models remain a valid and explicit Basic-speaking fallback.
	if string.find(wanted, "human", 1, true)
	or string.find(wanted, "group01", 1, true)
	or string.find(wanted, "group02", 1, true)
	or string.find(wanted, "group03", 1, true) then
		return MilBase.GetSpecies("human")
	end
	return MilBase.GetSpecies("human")
end

if SERVER then
	local modelCache
	local modelCacheUntil = 0

	local function registeredModels()
		if modelCache and CurTime() < modelCacheUntil then return modelCache end
		modelCache, modelCacheUntil = {}, CurTime() + 30
		if player_manager and player_manager.AllValidModels then
			for alias, path in pairs(player_manager.AllValidModels() or {}) do
				path = tostring(path or "")
				if path ~= "" and util.IsValidModel(path) then
					modelCache[#modelCache + 1] = {
						alias = lower(alias),
						path = path,
					}
				end
			end
		end
		return modelCache
	end

	function MilBase.ResolveSpeciesModel(speciesID, purpose)
		local species = MilBase.GetSpecies(speciesID)
		if not species then return nil end
		purpose = cleanID(purpose or "crew")
		local rows = species.models[purpose] or species.models.crew or {}
		local available = {}
		for _, row in ipairs(rows) do
			if row.path and util.IsValidModel(row.path) then
				available[#available + 1] = {
					path = row.path,
					alias = row.alias or "",
					weight = tonumber(row.weight) or 1,
				}
			else
				for _, registered in ipairs(registeredModels()) do
					if modelMatches(row, registered.alias, registered.path) then
						available[#available + 1] = {
							path = registered.path,
							alias = registered.alias,
							weight = tonumber(row.weight) or 1,
						}
					end
				end
			end
		end
		if #available == 0 then return nil end
		local total = 0
		for _, row in ipairs(available) do total = total + math.max(0, row.weight) end
		local pick = math.Rand(0, math.max(1, total))
		for _, row in ipairs(available) do
			pick = pick - math.max(0, row.weight)
			if pick <= 0 then return row.path, row.alias end
		end
		return available[#available].path, available[#available].alias
	end

	function MilBase.ChooseSpeciesProfile(purpose, configuredWeights)
		local available, total = {}, 0
		for _, speciesID in ipairs(MilBase.SpeciesOrder or {}) do
			local species = MilBase.Species[speciesID]
			local model, alias = MilBase.ResolveSpeciesModel(speciesID, purpose)
			local weight = tonumber((configuredWeights or {})[speciesID])
				or tonumber(species.weights and species.weights[purpose]) or 0
			if model and weight > 0 then
				total = total + weight
				available[#available + 1] = {
					species = species,
					model = model,
					alias = alias,
					weight = weight,
				}
			end
		end
		if #available == 0 then
			local human = MilBase.GetSpecies("human")
			return {
				species = human,
				model = (MilBase.ResolveSpeciesModel("human", purpose))
					or "models/Humans/Group03/male_07.mdl",
				alias = "",
				weight = 1,
			}
		end
		local pick = math.Rand(0, total)
		for _, profile in ipairs(available) do
			pick = pick - profile.weight
			if pick <= 0 then return profile end
		end
		return available[#available]
	end
end

function MilBase.SpeciesName(speciesID)
	local species = MilBase.GetSpecies(speciesID)
	return species and species.name or "Human"
end

function MilBase.SpeciesNativeLanguage(speciesID)
	local species = MilBase.GetSpecies(speciesID)
	return species and species.nativeLanguage or "basic"
end

function MilBase.RandomSpeciesName(speciesID)
	local species = MilBase.GetSpecies(speciesID)
	local first = species and species.names and species.names.first or {}
	local last = species and species.names and species.names.last or {}
	local given = first[math.random(1, math.max(1, #first))]
	local family = last[math.random(1, math.max(1, #last))]
	if given and family then return given .. " " .. family end
	if given then return given end
	return "Civilian " .. math.random(100, 999)
end
