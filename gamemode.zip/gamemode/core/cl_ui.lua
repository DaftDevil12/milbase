-- Battlefront-style UI foundation: typography, palette, blur, and the
-- BF2 draw kit. Every other client file draws with these so the whole
-- gamemode has one consistent look.

MilBase.UI = {
	bg      = Color(6, 6, 7, 240),       -- fullscreen menu backdrop (black)
	panel   = Color(10, 10, 11, 215),    -- HUD / menu panels (near-black)
	raised  = Color(255, 198, 60, 10),   -- subtle raised surface
	hover   = Color(255, 198, 60, 25),
	outline = Color(255, 198, 60, 50),   -- thin golden edge
	accent  = Color(255, 198, 60),       -- golden yellow
	text    = Color(240, 238, 230),
	dim     = Color(170, 162, 140),
	faint   = Color(112, 106, 92),
	ok      = Color(150, 205, 125),
	warn    = Color(255, 198, 60),
	danger  = Color(220, 80, 70),
}

-- Typography from the content pack (see cfg.WorkshopContent): Bebas Neue
-- for display faces (the Battlefront look), D-DIN for body text. If a
-- client doesn't have the content mounted, the engine falls back to a
-- default font - readable, just plainer.
surface.CreateFont("MB.Title", { font = "Bebas Neue", size = 52, weight = 400 })
surface.CreateFont("MB.Tab",   { font = "Bebas Neue", size = 27, weight = 400 })
surface.CreateFont("MB.Huge",  { font = "Bebas Neue", size = 72, weight = 400 })
surface.CreateFont("MB.Big",   { font = "Bebas Neue", size = 33, weight = 400 })
surface.CreateFont("MB.Med",   { font = "D-DIN", size = 20, weight = 600 })
surface.CreateFont("MB.Small", { font = "D-DIN", size = 16, weight = 700 })
surface.CreateFont("MB.Tiny",  { font = "D-DIN", size = 14, weight = 400 })
surface.CreateFont("MB.Num",      { font = "Bebas Neue", size = 48, weight = 400 })
surface.CreateFont("MB.NumSmall", { font = "Bebas Neue", size = 27, weight = 400 })

--------------------------------------------------------------------------
-- Content-pack art & sounds, all with graceful fallbacks
--------------------------------------------------------------------------

-- Base path for the astolfo Battlefront-II UI content addon. Everything the
-- F4 menu draws lives under here; change this one line if the addon ever
-- mounts under a different folder.
MilBase.UI.assetBase = "astolfo/ui/"

function MilBase.Asset(rel)
	return MilBase.UI.assetBase .. rel
end

local A = MilBase.Asset

MilBase.UI.art = {
	-- F4 menu header icons (astolfo BF2 content, bundled in content/)
	avatar = A("menu/f4/bfui/avatar.png"),
	money  = A("menu/f4/bfui/money.png"),
	close  = A("menu/f4/bfui/power.png"),

	-- HUD / scoreboard (Kraken content pack - untouched this pass)
	scoreboard = "kraken/bf2scoreboard/scoreboard.png",
	killed     = "kraken/bf2hud/killed.png",
	ammoLow    = "kraken/bf2hud/ammo_low.png",

	-- F4 tab icons, keyed by tab name (fallback: menuTabIconDefault).
	menuTabIcons = {
		["ROSTER"]         = A("menu/f4/bfui/avatar.png"),
		["CHARACTERS"]      = A("menu/f4/bfui/avatar.png"),
		["GEAR"]           = A("menu/f4/bfui/e11.png"),
		["STAR CARDS"]     = A("menu/f4/bfui/paint-board-and-brush.png"),
		["HEALTH"]         = A("hud/player/overhead/icon/medic.png"),
		["CERTIFICATIONS"] = A("menu/f4/icons/home/home_icons_timed_achievement.png"),
		["DAILY ORDERS"]    = A("menu/f4/icons/home/home_icons_timed_achievement.png"),
		["CRATES"]         = A("menu/f4/bfui/creditcard.png"),
		["HELP"]           = A("menu/f4/bfui/keyboard.png"),
	},
	menuTabIconDefault = A("menu/f4/bfui/cogwheel.png"),

	-- Generated BF2 UI kit (gamemode-bundled in content/materials/milbase/ui/bf2).
	-- White masks unless noted - tint with the color you pass to MilBase.DrawIcon.
	bf2 = {
		bracketTL     = "milbase/ui/bf2/bracket_tl.png",
		bracketTR     = "milbase/ui/bf2/bracket_tr.png",
		bracketBL     = "milbase/ui/bf2/bracket_bl.png",
		bracketBR     = "milbase/ui/bf2/bracket_br.png",
		diamond       = "milbase/ui/bf2/diamond.png",
		diamondHollow = "milbase/ui/bf2/diamond_hollow.png",
		hex           = "milbase/ui/bf2/hex.png",
		hexHollow     = "milbase/ui/bf2/hex_hollow.png",
		chevron       = "milbase/ui/bf2/chevron.png",
		glow          = "milbase/ui/bf2/glow_radial.png",
		sheen         = "milbase/ui/bf2/grad_sheen.png",   -- vertical top gloss
		panel         = "milbase/ui/bf2/panel_grad.png",   -- dark card fill (leave untinted)
		scanlines     = "milbase/ui/bf2/scanlines.png",    -- tileable holo lines
		accentBar     = "milbase/ui/bf2/accent_bar.png",   -- gold, pre-colored
		underline     = "milbase/ui/bf2/underline_glow.png", -- gold, pre-colored
		frame         = "milbase/ui/bf2/chamfer_frame.png",  -- corner-cut outline (TL/BR)

		-- Menu-specific pieces. Empty-slot silhouettes are watermarks for the
		-- GEAR tab's equipment slots (draw faint, e.g. ui.faint @ ~50 alpha).
		slotHead      = "milbase/ui/bf2/slot_head.png",     -- HEADWEAR
		slotArmor     = "milbase/ui/bf2/slot_armor.png",    -- BODY ARMOR
		slotBackpack  = "milbase/ui/bf2/slot_backpack.png", -- BACKPACK
		slotHolster   = "milbase/ui/bf2/slot_holster.png",  -- HOLSTER (pistol)
		slotPrimary   = "milbase/ui/bf2/slot_primary.png",  -- ON SLING / ON BACK (rifle)
		gridCell      = "milbase/ui/bf2/grid_cell.png",     -- tileable Tarkov cell
		itemFrame     = "milbase/ui/bf2/item_frame.png",    -- inventory item outline
		cardFrame     = "milbase/ui/bf2/card_frame.png",    -- star-card frame (tint to rarity)
		slotFrame     = "milbase/ui/bf2/slot_frame.png",    -- gear slot w/ corner brackets
		rarityGem     = "milbase/ui/bf2/rarity_gem.png",    -- rarity indicator (tint to rarity)

		-- Crate tier icons (line-art, tint to a tier color). Index by tier 1-4
		-- via crateTiers, or reference directly. star = tier pip.
		crateTiers = {
			[1] = "milbase/ui/bf2/crate_tier1.png",  -- supply box
			[2] = "milbase/ui/bf2/crate_tier2.png",  -- footlocker
			[3] = "milbase/ui/bf2/crate_tier3.png",  -- armored octagon
			[4] = "milbase/ui/bf2/crate_tier4.png",  -- legendary hex vault
		},
		star = "milbase/ui/bf2/star.png",
	},
}

MilBase.UI.sounds = {
	notify = { file = "kraken/squads/ping.wav", fallback = "buttons/button15.wav" },
	hover = { file = "kraken/squads/radial_hover.wav", fallback = "ui/buttonrollover.wav" },
	select = { file = "kraken/squads/radial_select.wav", fallback = "ui/buttonclickrelease.wav" },
}

-- True while the local player is in the event commander view - the
-- in-world HUD (vitals, ammo, compass, squad, etc.) hides itself then.
function MilBase.InEventView()
	local lp = LocalPlayer()
	return IsValid(lp) and lp:GetNWBool("mb_eventmode", false)
end

-- True while sitting in an LVS vehicle with the cockpit HUD on - the
-- on-foot vitals/ammo card hides so it doesn't overlap the vehicle HUD.
function MilBase.InVehicleHUD()
	if MilBase.Config.LVSHudEnabled == false then return false end
	local lp = LocalPlayer()
	return IsValid(lp) and lp.lvsGetVehicle ~= nil and IsValid(lp:lvsGetVehicle())
end

local matCache = {}

-- Returns a Material, or nil when the texture isn't mounted.
function MilBase.GetUIMat(path)
	if not path then return nil end

	if matCache[path] == nil then
		matCache[path] = Material(path, "smooth")
	end

	local mat = matCache[path]
	if mat:IsError() then return nil end
	return mat
end

local soundExists = {}

function MilBase.PlayUISound(id)
	local def = MilBase.UI.sounds[id]
	if not def then return end

	if soundExists[def.file] == nil then
		soundExists[def.file] = file.Exists("sound/" .. def.file, "GAME")
	end

	surface.PlaySound(soundExists[def.file] and def.file or def.fallback)
end

-- Fullscreen/panel backdrop: content-pack art with a readability overlay,
-- or the classic blur + dark fill when the content isn't mounted.
function MilBase.PaintBackdrop(panel, w, h, artPath, overlayAlpha)
	local art = MilBase.GetUIMat(artPath or MilBase.UI.art.menuBackground)

	if art then
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(art)
		surface.DrawTexturedRect(0, 0, w, h)
		surface.SetDrawColor(8, 9, 11, overlayAlpha or 150)
		surface.DrawRect(0, 0, w, h)
	else
		MilBase.DrawBlur(panel, 4)
		surface.SetDrawColor(MilBase.UI.bg)
		surface.DrawRect(0, 0, w, h)
	end
end

local blur = Material("pp/blurscreen")

-- Blurs whatever is behind `panel` (the Helix menu backdrop effect).
function MilBase.DrawBlur(panel, amount)
	local x, y = panel:LocalToScreen(0, 0)

	surface.SetMaterial(blur)
	surface.SetDrawColor(255, 255, 255)

	for i = 1, 3 do
		blur:SetFloat("$blur", (i / 3) * (amount or 6))
		blur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
end

--------------------------------------------------------------------------
-- The Battlefront style kit: chamfered panels, bright-edged bars,
-- selection brackets. Everything in the gamemode draws through these.
--------------------------------------------------------------------------

-- Chamfered (corner-cut) panel: BF2 cuts the top-left and bottom-right.
-- opts: color, cut, outline (false disables), outlineColor, accent (left strip).
function MilBase.DrawPanelBF2(x, y, w, h, opts)
	opts = opts or {}
	local cut = math.min(opts.cut or 8, math.floor(math.min(w, h) / 3))

	local poly = {
		{ x = x + cut, y = y },
		{ x = x + w, y = y },
		{ x = x + w, y = y + h - cut },
		{ x = x + w - cut, y = y + h },
		{ x = x, y = y + h },
		{ x = x, y = y + cut },
	}

	draw.NoTexture()
	surface.SetDrawColor(opts.color or MilBase.UI.panel)
	surface.DrawPoly(poly)

	if opts.outline ~= false then
		surface.SetDrawColor(opts.outlineColor or MilBase.UI.outline)
		for i = 1, #poly do
			local a = poly[i]
			local b = poly[i % #poly + 1]
			surface.DrawLine(a.x, a.y, b.x, b.y)
		end
	end

	if opts.accent then
		surface.SetDrawColor(opts.accent)
		surface.DrawRect(x, y + cut, 3, h - cut - 1)
	end
end

-- BF2 selection brackets: bright corner ticks around a rect. Uses the
-- generated bracket art when mounted, otherwise draws them procedurally.
function MilBase.DrawBrackets(x, y, w, h, color, len)
	len = len or 8
	color = color or MilBase.UI.accent

	local b = MilBase.UI.art.bf2
	if MilBase.GetUIMat(b.bracketTL) then
		local s = math.Round(len * 2.2)
		MilBase.DrawIcon(b.bracketTL, x, y, s, s, color)
		MilBase.DrawIcon(b.bracketTR, x + w - s, y, s, s, color)
		MilBase.DrawIcon(b.bracketBL, x, y + h - s, s, s, color)
		MilBase.DrawIcon(b.bracketBR, x + w - s, y + h - s, s, s, color)
		return
	end

	surface.SetDrawColor(color)
	surface.DrawRect(x, y, len, 2)
	surface.DrawRect(x, y, 2, len)
	surface.DrawRect(x + w - len, y, len, 2)
	surface.DrawRect(x + w - 2, y, 2, len)
	surface.DrawRect(x, y + h - 2, len, 2)
	surface.DrawRect(x, y + h - len, 2, len)
	surface.DrawRect(x + w - len, y + h - 2, len, 2)
	surface.DrawRect(x + w - 2, y + h - len, 2, len)
end

-- Dark panel with the BF2 chamfer (same signature as before, so every
-- caller in the gamemode inherits the style).
function MilBase.PaintPanel(w, h, accent)
	MilBase.DrawPanelBF2(0, 0, w, h, { accent = accent })
	-- Faint top sheen for a bit of depth (no-op without the asset).
	MilBase.DrawIcon(MilBase.UI.art.bf2.sheen, 1, 1, w - 2, math.min(h, 46))
end

-- Skewed parallelogram (the BF2017 in-game HUD lean).
function MilBase.DrawSkewQuad(x, y, w, h, color, skew)
	skew = skew or math.floor(h * 0.55)

	draw.NoTexture()
	surface.SetDrawColor(color)
	surface.DrawPoly({
		{ x = x + skew, y = y },
		{ x = x + w + skew, y = y },
		{ x = x + w, y = y + h },
		{ x = x, y = y + h },
	})
end

-- BF2017 skewed stat bar: dark backing, bright fill with a hot leading
-- edge, optional segment ticks.
function MilBase.DrawSkewBar(x, y, w, h, frac, color, opts)
	opts = opts or {}
	local skew = opts.skew or math.floor(h * 0.55)
	frac = math.Clamp(frac, 0, 1)

	MilBase.DrawSkewQuad(x, y, w, h, opts.back or Color(0, 0, 0, 170), skew)

	local fill = math.floor(w * frac)
	if fill > 1 then
		MilBase.DrawSkewQuad(x, y, fill, h, color, skew)
		MilBase.DrawSkewQuad(x + math.max(0, fill - 2), y, 2, h,
			Color(255, 255, 255, 150), skew)
	end

	if opts.segments then
		surface.SetDrawColor(0, 0, 0, 130)
		for i = 1, opts.segments - 1 do
			local tx = x + math.floor(w * i / opts.segments)
			surface.DrawLine(tx + skew, y, tx, y + h - 1)
		end
	end

	if opts.outline ~= false then
		surface.SetDrawColor(255, 255, 255, 35)
		surface.DrawLine(x + skew, y, x + w + skew, y)
		surface.DrawLine(x + w + skew, y, x + w, y + h)
		surface.DrawLine(x + w, y + h, x, y + h)
		surface.DrawLine(x, y + h, x + skew, y)
	end
end

-- BF2 diamond marker (battlepoints glyph, squadmate markers). Uses the
-- generated diamond art when mounted, otherwise draws it procedurally.
function MilBase.DrawDiamond(cx, cy, r, color, hollow)
	local b = MilBase.UI.art.bf2
	if MilBase.DrawIcon(hollow and b.diamondHollow or b.diamond,
		cx - r, cy - r, r * 2, r * 2, color) then return end

	draw.NoTexture()
	surface.SetDrawColor(color)

	if hollow then
		surface.DrawLine(cx, cy - r, cx + r, cy)
		surface.DrawLine(cx + r, cy, cx, cy + r)
		surface.DrawLine(cx, cy + r, cx - r, cy)
		surface.DrawLine(cx - r, cy, cx, cy - r)
	else
		surface.DrawPoly({
			{ x = cx, y = cy - r },
			{ x = cx + r, y = cy },
			{ x = cx, y = cy + r },
			{ x = cx - r, y = cy },
		})
	end
end

-- Draws a UI material tinted `color` into the rect. Returns true if it drew,
-- or false (drawing nothing) when the texture isn't mounted - callers can
-- fall back to a text-only layout so the menu still works without the addon.
function MilBase.DrawIcon(matPath, x, y, w, h, color)
	local mat = MilBase.GetUIMat(matPath)
	if not mat then return false end

	surface.SetDrawColor(color or color_white)
	surface.SetMaterial(mat)
	surface.DrawTexturedRect(x, y, w, h)
	return true
end

-- BF2 stat bar: dark backing, thin outline, bright leading edge.
function MilBase.DrawBar(x, y, w, h, frac, color)
	surface.SetDrawColor(0, 0, 0, 160)
	surface.DrawRect(x, y, w, h)
	surface.SetDrawColor(255, 255, 255, 22)
	surface.DrawOutlinedRect(x, y, w, h)

	local fill = math.floor((w - 2) * math.Clamp(frac, 0, 1))
	if fill > 0 then
		surface.SetDrawColor(color)
		surface.DrawRect(x + 1, y + 1, fill, h - 2)
		surface.SetDrawColor(255, 255, 255, 110)
		surface.DrawRect(x + math.max(1, fill - 1), y + 1, 2, h - 2)
	end
end
