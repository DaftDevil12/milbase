-- Character-specific ArcCW attachment inventory and permanent crate weapons.

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_arccw_attachments (
	steamid VARCHAR(32), attachment VARCHAR(128), amount INTEGER,
	PRIMARY KEY (steamid, attachment)
)]])
MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_weapon_unlocks (
	steamid VARCHAR(32), weapon VARCHAR(128), PRIMARY KEY (steamid, weapon)
)]])

local function arcReady()
	return ArcCW and istable(ArcCW.AttachmentTable)
		and isfunction(ArcCW.PlayerSendAttInv)
end

local function countInstalled(ply)
	local out = {}
	for _, wep in ipairs(ply:GetWeapons()) do
		if IsValid(wep) and wep.ArcCW and istable(wep.Attachments) then
			for _, slot in pairs(wep.Attachments) do
				if istable(slot) and isstring(slot.Installed) and slot.Installed ~= "" then
					local id = MilBase.ArcCWCanonicalAttachment(slot.Installed)
					out[id] = (out[id] or 0) + 1
				end
			end
		end
	end
	return out
end

local function currentAttachmentTotals(ply)
	local out = {}
	for id, amount in pairs(istable(ply.ArcCW_AttInv) and ply.ArcCW_AttInv or {}) do
		id = MilBase.ArcCWCanonicalAttachment(id)
		out[id] = (out[id] or 0) + math.max(0, math.floor(tonumber(amount) or 0))
	end
	for id, amount in pairs(countInstalled(ply)) do out[id] = (out[id] or 0) + amount end
	return out
end

function MilBase.SaveArcCWAssets(ply)
	if not IsValid(ply) or not ply.mb_arccwAssetsLoaded then return end
	local owned = table.Copy(ply.mb_arccwOwnedAttachments or {})
	if arcReady() and ply.mb_arccwInventorySynced and ply:Alive() then
		local previous = owned
		owned = {}
		-- Keep rewards whose supplying addon is temporarily unavailable.
		for id, amount in pairs(previous) do
			if not ArcCW.AttachmentTable[id] then owned[id] = amount end
		end
		local entitlement = ply.mb_arccwLastEntitlement or MilBase.ArcCWAttachmentEntitlements(ply)
		for id, total in pairs(currentAttachmentTotals(ply)) do
			local amount = math.max(0, total - (entitlement[id] or 0))
			if amount > 0 then owned[id] = amount end
		end
		ply.mb_arccwOwnedAttachments = owned
	end

	local key = MilBase.SQLStr(ply:MBCharacterKey())
	local kept = {}
	for id, amount in pairs(owned) do
		kept[#kept + 1] = MilBase.SQLStr(id)
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_arccw_attachments (steamid, attachment, amount) VALUES (%s, %s, %d)",
			key, MilBase.SQLStr(id), math.max(1, math.floor(tonumber(amount) or 1))))
	end
	local stale = "DELETE FROM frontier_arccw_attachments WHERE steamid = " .. key
	if #kept > 0 then stale = stale .. " AND attachment NOT IN (" .. table.concat(kept, ",") .. ")" end
	MilBase.DB.Run(stale)
end

function MilBase.SyncArcCWAttachments(ply)
	if not IsValid(ply) or not ply.mb_arccwAssetsLoaded or not arcReady() then return false end
	local totals = {}
	for id, amount in pairs(ply.mb_arccwOwnedAttachments or {}) do
		id = MilBase.ArcCWCanonicalAttachment(id)
		if ArcCW.AttachmentTable[id] then totals[id] = math.max(totals[id] or 0, amount) end
	end
	local entitlement = MilBase.ArcCWAttachmentEntitlements(ply)
	for id, amount in pairs(entitlement) do
		if ArcCW.AttachmentTable[id] then totals[id] = (totals[id] or 0) + amount end
	end
	local installed = countInstalled(ply)
	local desired = {}
	for id, amount in pairs(totals) do
		local free = math.max(0, amount - (installed[id] or 0))
		if free > 0 then desired[id] = free end
	end
	ply.ArcCW_AttInv = desired
	ply.mb_arccwLastEntitlement = table.Copy(entitlement)
	ply.mb_arccwInventorySynced = true
	ArcCW:PlayerSendAttInv(ply)
	return true
end

function MilBase.RefreshArcCWEntitlements(ply)
	if not IsValid(ply) then return end
	MilBase.SaveArcCWAssets(ply)
	timer.Simple(0.1, function()
		if IsValid(ply) then MilBase.SyncArcCWAttachments(ply) end
	end)
end

function MilBase.LoadArcCWAssets(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	local quoted = MilBase.SQLStr(key)
	ply.mb_arccwAssetsLoaded = false
	ply.mb_arccwInventorySynced = false
	ply.mb_arccwLastEntitlement = nil
	ply.mb_arccwOwnedAttachments = {}
	ply.mb_weaponUnlocks = {}

	local finished = false
	local function finish()
		if finished or not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		finished = true
		ply.mb_arccwAssetsLoaded = true
		MilBase.SyncArcCWAttachments(ply)
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "arccw") end
	end

	local function loadWeapons()
		MilBase.DB.Query("SELECT weapon FROM frontier_weapon_unlocks WHERE steamid = " .. quoted, function(weaponRows)
			if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			for _, row in ipairs(weaponRows or {}) do
				local class = string.Trim(tostring(row.weapon or ""))
				if class ~= "" then ply.mb_weaponUnlocks[class] = true end
			end
			finish()
		end, finish)
	end

	MilBase.DB.Query("SELECT attachment, amount FROM frontier_arccw_attachments WHERE steamid = " .. quoted, function(attRows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		for _, row in ipairs(attRows or {}) do
			local id = MilBase.ArcCWCanonicalAttachment(row.attachment)
			local amount = math.max(0, math.floor(tonumber(row.amount) or 0))
			if id ~= "" and amount > 0 then ply.mb_arccwOwnedAttachments[id] = amount end
		end
		loadWeapons()
	end, function()
		if MilBase.CharacterLoadStillCurrent(ply, key, token) then loadWeapons() end
	end)
end

function MilBase.GrantArcCWAttachment(ply, id, amount)
	if not IsValid(ply) then return false end
	id = MilBase.ArcCWCanonicalAttachment(id)
	amount = math.Clamp(math.floor(tonumber(amount) or 1), 1, 1000)
	if id == "" then return false end
	ply.mb_arccwOwnedAttachments = ply.mb_arccwOwnedAttachments or {}
	ply.mb_arccwOwnedAttachments[id] = (ply.mb_arccwOwnedAttachments[id] or 0) + amount
	ply.mb_arccwAssetsLoaded = true
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_arccw_attachments (steamid, attachment, amount) VALUES (%s, %s, %d)",
		MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(id), ply.mb_arccwOwnedAttachments[id]))
	MilBase.SyncArcCWAttachments(ply)
	return true
end

function MilBase.GrantWeaponUnlock(ply, class)
	if not IsValid(ply) then return false end
	class = string.Trim(tostring(class or ""))
	if class == "" then return false end
	ply.mb_weaponUnlocks = ply.mb_weaponUnlocks or {}
	if ply.mb_weaponUnlocks[class] then return false end
	ply.mb_weaponUnlocks[class] = true
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_weapon_unlocks (steamid, weapon) VALUES (%s, %s)",
		MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(class)))
	if ply:Alive() then ply:Give(class) end
	return true
end

function MilBase.CrateWeaponLoadout(ply)
	local out = {}
	for class in SortedPairs(ply.mb_weaponUnlocks or {}) do out[#out + 1] = class end
	return out
end

hook.Add("PlayerInitialSpawn", "MilBase.LoadArcCWAssets", function(ply)
	-- Character-slot hooks initialise the active key during the same event.
	timer.Simple(0, function() if IsValid(ply) then MilBase.LoadArcCWAssets(ply) end end)
end)
hook.Add("PlayerSpawn", "MilBase.SyncArcCWAttachments", function(ply, transition)
	if transition then return end
	-- ArcCW may clear its inventory during PlayerSpawn. Never persist that
	-- temporary empty state before MilBase has restored the character assets.
	ply.mb_arccwInventorySynced = false
	timer.Simple(0.35, function() if IsValid(ply) then MilBase.SyncArcCWAttachments(ply) end end)
end)
hook.Add("MilBase.PlayerLoaded", "MilBase.SyncArcCWAttachmentsAfterLoad", function(ply)
	timer.Simple(0.1, function() if IsValid(ply) then MilBase.SyncArcCWAttachments(ply) end end)
end)
hook.Add("PlayerDisconnected", "MilBase.SaveArcCWAssets", function(ply)
	MilBase.SaveArcCWAssets(ply)
end)
hook.Add("ShutDown", "MilBase.SaveAllArcCWAssets", function()
	for _, ply in ipairs(player.GetAll()) do MilBase.SaveArcCWAssets(ply) end
end)
timer.Create("MilBase.SaveArcCWAssets", 15, 0, function()
	for _, ply in ipairs(player.GetAll()) do MilBase.SaveArcCWAssets(ply) end
end)

-- Supports servers that hot-load/reload ArcCW after players have joined.
timer.Create("MilBase.ArcCWDeferredSync", 2, 0, function()
	if not arcReady() then return end
	for _, ply in ipairs(player.GetAll()) do
		if ply.mb_arccwAssetsLoaded and not ply.mb_arccwInventorySynced then
			MilBase.SyncArcCWAttachments(ply)
		end
	end
end)
