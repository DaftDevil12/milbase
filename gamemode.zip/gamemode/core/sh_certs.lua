--[[
	Certification system.

	Certs are qualifications granted to individual soldiers by officers
	or admins (/certify, /decertify). They persist in SQLite and grant:
	  health        - extra max health
	  loadout       - extra weapons every spawn
	  issue         - extra standard-issue items every spawn
	  attachments   - ArcCW attachment entitlements (id = amount)
	  armor         - optional Quartermaster armor item override
	  medic         - counts as a medic (faster stabilizing)
	  medicOthers   - may use meds on other soldiers
	  medEfficiency - healing multiplier (1.5 = 50% more effective)
	  medSpeed      - first aid time multiplier (0.75 = 25% faster)
	  factions      - optional faction-id set; persistent cert is inactive outside it
	Items can require a cert with `cert = "<id>"` in their definition.

	Define certs in config/sh_certs.lua.
]]

MilBase.Certs = MilBase.Certs or {}
MilBase.CertOrder = MilBase.CertOrder or {}

local function normaliseFactionLocks(value)
	if not istable(value) then return nil end
	local out = {}
	for key, enabled in pairs(value) do
		local id = isnumber(key) and tostring(enabled or "") or tostring(key or "")
		if isnumber(key) or enabled == true or enabled == 1 then
			id = string.lower(string.Trim(id))
			if id ~= "" then out[id] = true end
		end
	end
	return table.IsEmpty(out) and nil or out
end

function MilBase.RegisterCertification(id, data)
	id = string.lower(string.Trim(tostring(id or "")))
	assert(id ~= "", "Certification id is required")
	data = table.Copy(data or {})
	data.id = id
	data.name = data.name or id
	data.desc = data.desc or ""
	data.attachments = MilBase.CopyCountMap(data.attachments, 1000)
	data.armor = string.lower(string.Trim(tostring(data.armor or "")))
	if data.armor == "" then data.armor = nil end
	data.factions = normaliseFactionLocks(data.factions)

	if not MilBase.Certs[id] then
		table.insert(MilBase.CertOrder, id)
	end
	MilBase.Certs[id] = data
	return data
end

function MilBase.RemoveCertification(id)
	id = string.lower(string.Trim(tostring(id or "")))
	if not MilBase.Certs[id] then return false end
	MilBase.Certs[id] = nil
	for index = #MilBase.CertOrder, 1, -1 do
		if MilBase.CertOrder[index] == id then table.remove(MilBase.CertOrder, index) end
	end
	return true
end

function MilBase.CertAllowedForFaction(cert, faction)
	if isstring(cert) then cert = MilBase.Certs[cert] end
	if not istable(cert) then return false end
	if not istable(cert.factions) or table.IsEmpty(cert.factions) then return true end
	local factionID = isstring(faction) and faction
		or (istable(faction) and faction.id)
		or (IsValid(faction) and faction.MBFactionID and faction:MBFactionID())
	return factionID ~= nil and cert.factions[string.lower(tostring(factionID))] == true
end

local PLAYER = FindMetaTable("Player")

local function certListFromNW(ply, key)
	local out = {}
	for id in string.gmatch(ply:GetNWString(key, ""), "([^,]+)") do
		out[#out + 1] = id
	end
	return out
end

-- Certifications saved to the character database.
function PLAYER:MBPersistentCertList()
	return certListFromNW(self, "mb_certs")
end

-- Certifications granted only for the current event-enemy role. These are
-- networked so every shared cert check behaves consistently, but never saved.
function PLAYER:MBTemporaryCertList()
	return certListFromNW(self, "mb_temp_certs")
end

-- Gameplay systems should use the combined list. Persistent management below
-- deliberately uses MBPersistentCertList so temporary event permissions can
-- never be written into or removed from the character database by accident.
function PLAYER:MBCertList()
	local out, seen = {}, {}
	for _, id in ipairs(self:MBPersistentCertList()) do
		local cert = MilBase.Certs[id]
		if cert and MilBase.CertAllowedForFaction(cert, self) and not seen[id] then
			out[#out + 1] = id
			seen[id] = true
		end
	end
	-- Event-enemy certifications intentionally bypass faction locks: they are
	-- explicit temporary class grants and are never written to the character.
	for _, id in ipairs(self:MBTemporaryCertList()) do
		if MilBase.Certs[id] and not seen[id] then
			out[#out + 1] = id
			seen[id] = true
		end
	end
	return out
end

function PLAYER:MBHasPersistentCert(id)
	return string.find("," .. self:GetNWString("mb_certs", "") .. ",",
		"," .. id .. ",", 1, true) ~= nil
end

function PLAYER:MBHasTemporaryCert(id)
	return string.find("," .. self:GetNWString("mb_temp_certs", "") .. ",",
		"," .. id .. ",", 1, true) ~= nil
end

function PLAYER:MBHasCert(id)
	if self:MBHasTemporaryCert(id) then return true end
	return self:MBHasPersistentCert(id)
		and MilBase.CertAllowedForFaction(MilBase.Certs[id], self)
end

-- Human-readable summary of what a cert grants (for the menu).
function MilBase.CertGrantsText(cert)
	local parts = {}

	if (cert.health or 0) > 0 then
		table.insert(parts, "+" .. cert.health .. " max health")
	end
	for _, class in ipairs(cert.loadout or {}) do
		table.insert(parts, string.upper(string.gsub(class, "^weapon_", "")))
	end
	for id, n in pairs(cert.issue or {}) do
		local item = MilBase.Items and MilBase.Items[id]
		table.insert(parts, (item and item.name or id) .. " x" .. n)
	end
	for id, n in pairs(cert.attachments or {}) do
		table.insert(parts, MilBase.ArcCWAttachmentName(id) .. " x" .. n)
	end
	if cert.armor then
		local armor = MilBase.Items and MilBase.Items[cert.armor]
		table.insert(parts, "armor override: " .. ((armor and armor.name) or cert.armor))
	end
	if cert.medic then table.insert(parts, "medic duties") end
	if cert.medicOthers then table.insert(parts, "treat other soldiers") end
	if (cert.medEfficiency or 1) > 1 then table.insert(parts, "more effective meds") end
	if (cert.medSpeed or 1) < 1 then table.insert(parts, "faster first aid") end
	if istable(cert.factions) and not table.IsEmpty(cert.factions) then
		local names = {}
		for id in pairs(cert.factions) do
			local faction = MilBase.GetFaction and MilBase.GetFaction(id)
			names[#names + 1] = faction and faction.name or id
		end
		table.sort(names)
		table.insert(parts, "factions: " .. table.concat(names, ", "))
	end

	return table.concat(parts, "  •  ")
end

if not SERVER then return end

--------------------------------------------------------------------------
-- Server: persistence and granting
--------------------------------------------------------------------------

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_certs (
	steamid VARCHAR(32),
	cert VARCHAR(64),
	PRIMARY KEY (steamid, cert)
)]])

local function syncCerts(ply, list)
	ply:SetNWString("mb_certs", table.concat(list, ","))
end

function MilBase.SetTemporaryCertifications(ply, ids)
	if not IsValid(ply) then return end
	local clean, seen = {}, {}
	for _, id in ipairs(istable(ids) and ids or {}) do
		id = string.lower(string.Trim(tostring(id or "")))
		if MilBase.Certs[id] and not seen[id] then
			clean[#clean + 1] = id
			seen[id] = true
		end
	end
	ply:SetNWString("mb_temp_certs", table.concat(clean, ","))

	if ply:Alive() then
		local hp = MilBase.CalcMaxHealth(ply)
		ply:SetMaxHealth(hp)
		if ply:Health() > hp then ply:SetHealth(hp) end
	end
	if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end
end

function MilBase.LoadCerts(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	MilBase.DB.Query(string.format(
		"SELECT cert FROM frontier_certs WHERE steamid = %s",
		MilBase.SQLStr(key)), function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end

		local list = {}
		for _, row in ipairs(rows) do
			if MilBase.Certs[row.cert] then table.insert(list, row.cert) end
		end
		syncCerts(ply, list)

		if ply:Alive() then ply:SetMaxHealth(MilBase.CalcMaxHealth(ply)) end
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "certs") end
	end, function()
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		syncCerts(ply, {})
		if ply:Alive() then ply:SetMaxHealth(MilBase.CalcMaxHealth(ply)) end
		if MilBase.MarkLoaded then MilBase.MarkLoaded(ply, "certs") end
	end)
end

function MilBase.CalcMaxHealth(ply)
	-- Event enemies use their class health, not their cert-boosted health.
	if MilBase.EventEnemyHealth then
		local ehp = MilBase.EventEnemyHealth(ply)
		if ehp then return ehp end
	end

	local hp = 300
	for _, id in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[id]
		if cert and cert.health then hp = hp + cert.health end
	end
	-- Equipped star cards can add health too.
	if MilBase.StarCardHealth then hp = hp + MilBase.StarCardHealth(ply) end
	return hp
end

function MilBase.GrantCert(ply, id)
	local cert = MilBase.Certs[id]
	if not cert or ply:MBHasPersistentCert(id) then return false end
	if not MilBase.CertAllowedForFaction(cert, ply) then return false, "faction" end

	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_certs (steamid, cert) VALUES (%s, %s)",
		MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(id)))

	local list = ply:MBPersistentCertList()
	table.insert(list, id)
	syncCerts(ply, list)

	-- Extra health applies immediately; equipment on next spawn/resupply.
	if ply:Alive() then
		local hp = MilBase.CalcMaxHealth(ply)
		ply:SetMaxHealth(hp)
	end

	if MilBase.QuartermasterReconcileGear and MilBase.Config.QuartermasterCleanupOnRoleChange ~= false and ply.mb_inv then
		MilBase.QuartermasterReconcileGear(ply, false)
	end
	if MilBase.QuartermasterUpdateArmorObjective then
		MilBase.QuartermasterUpdateArmorObjective(ply, "cert")
	end
	if MilBase.SpawnSelectorValidateChoice then
		MilBase.SpawnSelectorValidateChoice(ply, false)
	end
	if MilBase.SpawnSelectorMaybeOpen then
		MilBase.SpawnSelectorMaybeOpen(ply)
	end
	if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end

	return true
end

function MilBase.RevokeCert(ply, id)
	if not ply:MBHasPersistentCert(id) then return false end

	MilBase.DB.Run(string.format(
		"DELETE FROM frontier_certs WHERE steamid = %s AND cert = %s",
		MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(id)))

	local list = {}
	for _, cid in ipairs(ply:MBPersistentCertList()) do
		if cid ~= id then table.insert(list, cid) end
	end
	syncCerts(ply, list)

	if ply:Alive() then
		local hp = MilBase.CalcMaxHealth(ply)
		ply:SetMaxHealth(hp)
		if ply:Health() > hp then ply:SetHealth(hp) end
	end

	if MilBase.QuartermasterReconcileGear and MilBase.Config.QuartermasterCleanupOnRoleChange ~= false and ply.mb_inv then
		MilBase.QuartermasterReconcileGear(ply, false)
	end
	if MilBase.QuartermasterUpdateArmorObjective then
		MilBase.QuartermasterUpdateArmorObjective(ply, "cert")
	end
	if MilBase.SpawnSelectorValidateChoice then
		MilBase.SpawnSelectorValidateChoice(ply, false)
	end
	if MilBase.SpawnSelectorMaybeOpen then
		MilBase.SpawnSelectorMaybeOpen(ply)
	end
	if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end

	return true
end

hook.Add("PlayerInitialSpawn", "MilBase.LoadCerts", function(ply)
	MilBase.LoadCerts(ply)
end)

--------------------------------------------------------------------------
-- Commands
--------------------------------------------------------------------------

-- Grant/revoke by entity (used by commands and the interaction menu).
function MilBase.SetCertification(ply, target, id, grant)
	if not MilBase.Certs[id] then
		MilBase.Notify(ply, "Unknown certification. Valid: "
			.. table.concat(MilBase.CertOrder, ", "))
		return
	end
	if not ply:IsAdmin() and not MilBase.CanManage(ply, target) then
		MilBase.Notify(ply, "Only admins or your superiors can manage certifications.")
		return
	end

	local cert = MilBase.Certs[id]
	if grant then
		local granted, reason = MilBase.GrantCert(target, id)
		if granted then
			MilBase.ChatMsg(nil, Color(115, 190, 115), "[CERTIFICATION] ", color_white,
				target:MBName() .. " is now a certified " .. cert.name
				.. " (" .. ply:MBName() .. ").")
			MilBase.Notify(target, "Equipment from your new certification arrives on your next resupply.")
		elseif reason == "faction" then
			MilBase.Notify(ply, cert.name .. " is not available to " .. target:MBFaction().name .. ".", "warn")
		else
			MilBase.Notify(ply, target:MBName() .. " already holds that certification.")
		end
	else
		if target:MBHasTemporaryCert(id) and not target:MBHasPersistentCert(id) then
			MilBase.Notify(ply, cert.name .. " is temporary and is controlled by the active event-enemy class.")
			return
		end
		if MilBase.RevokeCert(target, id) then
			MilBase.Notify(ply, "Revoked " .. cert.name .. " from " .. target:MBName() .. ".")
			MilBase.Notify(target, "Your " .. cert.name .. " certification was revoked by " .. ply:MBName() .. ".")
		else
			MilBase.Notify(ply, target:MBName() .. " doesn't hold that certification.")
		end
	end
end

local function certCommand(grant)
	return function(ply, args)
		local target = MilBase.FindPlayer(args[1])
		if not IsValid(target) then
			MilBase.Notify(ply, "Player not found.")
			return
		end
		MilBase.SetCertification(ply, target, string.lower(args[2] or ""), grant)
	end
end

MilBase.RegisterChatCommand("certify", {
	help = "Grant a certification: /certify <player> <cert id> (officers/admin)",
	func = certCommand(true),
})

MilBase.RegisterChatCommand("decertify", {
	help = "Revoke a certification: /decertify <player> <cert id> (officers/admin)",
	func = certCommand(false),
})
