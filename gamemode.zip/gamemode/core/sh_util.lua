-- Shared utilities and player accessors.

local PLAYER = FindMetaTable("Player")

-- Character slots use the original SteamID64 key for slot 1, preserving every
-- existing server database, and append a compact suffix for additional lives.
-- Account-wide systems (staff rank, bans, reports) should continue using
-- SteamID64 directly; character-bound systems should use MBCharacterKey().
function MilBase.CharacterStorageID(steamID64, slot)
	steamID64 = tostring(steamID64 or "")
	slot = math.Clamp(math.floor(tonumber(slot) or 1), 1,
		math.max(1, math.floor(tonumber(MilBase.Config.CharacterSlots) or 2)))
	return slot == 1 and steamID64 or (steamID64 .. ":" .. slot)
end

function PLAYER:MBCharacterSlot()
	return math.Clamp(self:GetNWInt("mb_character_slot", 1), 1,
		math.max(1, math.floor(tonumber(MilBase.Config.CharacterSlots) or 2)))
end

function PLAYER:MBCharacterKey(slot)
	return MilBase.CharacterStorageID(self:SteamID64(), slot or self:MBCharacterSlot())
end

-- Some legacy modules historically keyed their table by SteamID rather than
-- SteamID64. Keep that exact slot-1 key so those rows also migrate in place.
function PLAYER:MBCharacterSteamIDKey(slot)
	return MilBase.CharacterStorageID(self:SteamID(), slot or self:MBCharacterSlot())
end

function PLAYER:MBCharacterLoadToken()
	return self.mb_characterLoadToken or 1
end

function MilBase.CharacterLoadStillCurrent(ply, key, token)
	return IsValid(ply) and ply:MBCharacterKey() == key
		and ply:MBCharacterLoadToken() == (token or ply:MBCharacterLoadToken())
end

-- The player's roleplay name (falls back to Steam name).
-- When the naming module is enabled this is generated as:
--   FACTION RANK [MEDIC] NUMBER NAME
function PLAYER:MBName()
	local ecName = self:GetNWString("mb_ec_name", "")
	if ecName ~= "" then return ecName end
	local name = self:GetNWString("mb_name", "")
	if MilBase.FormatRPName then
		return MilBase.FormatRPName(self, name)
	end
	return name ~= "" and name or self:Nick()
end

-- The personal name only, without faction/rank/clone-number prefixes.
function PLAYER:MBRawName()
	local ecName = self:GetNWString("mb_ec_name", "")
	if ecName ~= "" then return ecName end
	local name = self:GetNWString("mb_name", "")
	if MilBase.NamingCleanBaseName then name = MilBase.NamingCleanBaseName(name) end
	return name ~= "" and name or self:Nick()
end

function PLAYER:MBFactionID()
	return self:GetNWString("mb_faction", MilBase.Config.DefaultFaction)
end

function PLAYER:MBFaction()
	return MilBase.GetFaction(self:MBFactionID())
		or MilBase.GetFaction(MilBase.Config.DefaultFaction)
end

function PLAYER:MBRankIndex()
	return self:GetNWInt("mb_rank", 1)
end

function PLAYER:MBRank()
	local faction = self:MBFaction()
	if not faction then return nil end
	return faction.ranks[math.Clamp(self:MBRankIndex(), 1, #faction.ranks)]
end

function PLAYER:MBMoney()
	return self:GetNWInt("mb_money", 0)
end

-- "Sergeant John Doe" - used by chat and the HUD.
-- With automatic Star Wars naming enabled, MBName already contains the
-- faction/rank/number title, so avoid prefixing the rank twice.
function PLAYER:MBFullTitle()
	if MilBase.Config and MilBase.Config.NamingEnabled and MilBase.FormatRPName then
		return self:MBName()
	end
	local rank = self:MBRank()
	return (rank and rank.name .. " " or "") .. self:MBName()
end

-- Finds a player by (partial) RP name or Steam name, case-insensitive.
function MilBase.FindPlayer(name)
	if not name or name == "" then return nil end
	name = string.lower(name)

	for _, ply in ipairs(player.GetAll()) do
		local raw = ply.MBRawName and ply:MBRawName() or ""
		local number = ply.MBCloneNumber and ply:MBCloneNumber() or ply:GetNWString("mb_clone_number", "")
		if string.find(string.lower(ply:MBName()), name, 1, true)
		or string.find(string.lower(raw), name, 1, true)
		or (number ~= "" and string.find(string.lower(number), name, 1, true))
		or string.find(string.lower(ply:Nick()), name, 1, true) then
			return ply
		end
	end
end

if SERVER then
	util.AddNetworkString("MilBase_Notify")
	util.AddNetworkString("MilBase_ChatMsg")

	-- Small toast + console message. Optional kind: "ok"/"warn"/"danger".
	function MilBase.Notify(ply, text, kind)
		net.Start("MilBase_Notify")
			net.WriteString(text)
			net.WriteString(kind or "")
		net.Send(ply)
	end

	-- Sends a colored chat message. Accepts Colors and strings, like chat.AddText.
	-- target: a player, table of players, or nil for everyone.
	function MilBase.ChatMsg(target, ...)
		net.Start("MilBase_ChatMsg")
			net.WriteTable({ ... })
		if target then net.Send(target) else net.Broadcast() end
	end

	function PLAYER:MBSetMoney(amount)
		self:SetNWInt("mb_money", math.max(0, math.floor(amount)))
		MilBase.SavePlayer(self)
	end

	function PLAYER:MBAddMoney(amount)
		self:MBSetMoney(self:MBMoney() + amount)
	end
else
	-- Client-side notify so shared/client code can call MilBase.Notify too.
	-- Accepts (text) or (anything, text) to mirror the server signature.
	function MilBase.Notify(a, b)
		local text = b or a
		if not isstring(text) then return end
		notification.AddLegacy(text, NOTIFY_GENERIC, 4)
		surface.PlaySound("buttons/button10.wav")
	end

	net.Receive("MilBase_Notify", function()
		local text = net.ReadString()
		notification.AddLegacy(text, NOTIFY_GENERIC, 5)
		if MilBase.PlayUISound then
			MilBase.PlayUISound("notify")
		else
			surface.PlaySound("buttons/button15.wav")
		end
	end)

	net.Receive("MilBase_ChatMsg", function()
		local args = net.ReadTable()
		-- Colors arrive as plain tables; convert them back.
		for i, v in ipairs(args) do
			if istable(v) and v.r and v.g and v.b then
				args[i] = Color(v.r, v.g, v.b, v.a or 255)
			end
		end
		chat.AddText(unpack(args))
	end)
end
