--[[
	Full-screen scoreboard (TAB): server header, a column table with combat
	stats (Event Enemy kills, Player kills, NPC kills, Deaths, Ping, K/D),
	grouped by faction, plus a "MY STATS" bar for the local player at the
	bottom - similar layout to a DarkRP-style scoreboard.

	K/D here is PvE-focused: (Event Enemy kills + NPC kills) / Deaths.
	Player-vs-player kills get their own column instead.
]]

local board

-- Column layout: label, width (px), and a getter(member) -> string.
local function buildColumns(ui)
	return {
		{ label = "RANK",         width = 190, align = TEXT_ALIGN_LEFT,
			get = function(m)
				local rank = m:MBRank()
				return rank and rank.name or "Unassigned"
			end },
		{ label = "EE KILLS",     width = 90,  align = TEXT_ALIGN_CENTER,
			
			get = function(m) return tostring(MilBase.SBNPCKills(m)) end },
		{ label = "PLAYER KILLS", width = 100, align = TEXT_ALIGN_CENTER,
			get = function(m) return tostring(MilBase.SBPlayerKills(m)) end },
		{ label = "NPC KILLS",    width = 90,  align = TEXT_ALIGN_CENTER,
			get = function(m) return tostring(MilBase.SBEventKills(m)) end },
		{ label = "DEATHS",       width = 80,  align = TEXT_ALIGN_CENTER,
			get = function(m) return tostring(MilBase.SBDeaths(m)) end },
		{ label = "K/D",          width = 80,  align = TEXT_ALIGN_CENTER,
			get = function(m) return string.format("%.2f", MilBase.SBKDRatio(m)) end },
		{ label = "PING",         width = 70,  align = TEXT_ALIGN_RIGHT,
			get = function(m) return tostring(m:Ping()) end },
	}
end

function GM:ScoreboardShow()
	if IsValid(board) then board:Remove() end

	local ui = MilBase.UI
	local columns = buildColumns(ui)

	board = vgui.Create("DPanel")
	board:SetSize(ScrW(), ScrH())
	board:SetPos(0, 0)
	board.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h, ui.art.scoreboard, 130)
	end

	--------------------------------------------------------------------
	-- Header
	--------------------------------------------------------------------

	local header = vgui.Create("DPanel", board)
	header:Dock(TOP); header:SetTall(96); header.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 140)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 198, 60, 150)
		surface.DrawRect(0, h - 2, w, 2)

		draw.SimpleText("STAR WARS ROLEPLAY", "MB.Tiny", w / 2, 18, ui.dim,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(GetHostName() ~= "" and GetHostName() or "MilBase", "MB.Big",
			w / 2, 46, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(#player.GetAll() .. " / " .. game.MaxPlayers(), "MB.Small",
			w / 2, 76, ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	--------------------------------------------------------------------
	-- Column header row
	--------------------------------------------------------------------

	local colHeader = vgui.Create("DPanel", board)
	colHeader:Dock(TOP); colHeader:SetTall(30); colHeader:DockMargin(24, 8, 24, 4)
	colHeader.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 90)
		surface.DrawRect(0, 0, w, h)

		draw.SimpleText("PLAYER", "MB.Tiny", 74, h / 2, ui.faint,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		local x = w - 24
		for i = #columns, 1, -1 do
			local col = columns[i]
			local tx = col.align == TEXT_ALIGN_RIGHT and x
				or col.align == TEXT_ALIGN_CENTER and (x - col.width / 2)
				or (x - col.width)
			draw.SimpleText(col.label, "MB.Tiny", tx, h / 2, ui.faint, col.align, TEXT_ALIGN_CENTER)
			x = x - col.width
		end
	end

	--------------------------------------------------------------------
	-- Player rows, grouped by faction
	--------------------------------------------------------------------

	local scroll = vgui.Create("DScrollPanel", board)
	scroll:Dock(FILL)
	scroll:DockMargin(24, 0, 24, 8)

	for _, factionID in ipairs(MilBase.FactionOrder) do
		local faction = MilBase.GetFaction(factionID)
		local members = team.GetPlayers(faction.teamIndex)

		if #members > 0 then
			table.sort(members, function(a, b)
				return a:MBRankIndex() > b:MBRankIndex()
			end)

			-- Solid faction color band.
			local band = vgui.Create("DPanel", scroll)
			band:Dock(TOP)
			band:SetTall(26)
			band.Paint = function(self, w, h)
				surface.SetDrawColor(faction.color)
				surface.DrawRect(0, 0, w, h)

				local tx = 8
				local logo = MilBase.GetUIMat(faction.logo)
				if logo then
					surface.SetDrawColor(255, 255, 255, 235)
					surface.SetMaterial(logo)
					surface.DrawTexturedRect(6, h / 2 - 9, 18, 18)
					tx = 30
				end

				draw.SimpleTextOutlined(string.upper(faction.name), "MB.Small",
					tx, h / 2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER,
					1, Color(0, 0, 0, 150))
				draw.SimpleTextOutlined(tostring(#members), "MB.Small",
					w - 8, h / 2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER,
					1, Color(0, 0, 0, 150))
			end

			for _, member in ipairs(members) do
				local row = vgui.Create("DButton", scroll)
				row:Dock(TOP)
				row:SetTall(48)
				row:DockMargin(0, 0, 0, 1)
				row:SetText("")

				local portrait = vgui.Create("SpawnIcon", row)
				portrait:SetSize(48, 48)
				portrait:SetPos(0, 0)
				portrait:SetModel(member:GetModel())
				portrait:SetMouseInputEnabled(false)
				portrait:SetKeyboardInputEnabled(false)

				row.Paint = function(self, w, h)
					if not IsValid(member) then return end

					local isMe = member == LocalPlayer()
					surface.SetDrawColor(self:IsHovered() and Color(255, 198, 60, 22)
						or (isMe and Color(255, 198, 60, 12) or Color(0, 0, 0, 70)))
					surface.DrawRect(0, 0, w, h)
					if self:IsHovered() then
						MilBase.DrawBrackets(2, 2, w - 4, h - 4, MilBase.UI.accent, 6)
					end

					draw.SimpleText(member:MBName(), "MB.Small", 58, h / 2,
						isMe and Color(255, 235, 170) or ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

					local staff = member:MBStaffRank()
					if staff then
						draw.SimpleText(string.upper(staff.name), "MB.Tiny", 58, h - 8,
							staff.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
					end

					local x = w - 24
					for i = #columns, 1, -1 do
						local col = columns[i]
						local ok, value = pcall(col.get, member)
						local tx = col.align == TEXT_ALIGN_RIGHT and x
							or col.align == TEXT_ALIGN_CENTER and (x - col.width / 2)
							or (x - col.width)
						draw.SimpleText(ok and value or "-", "MB.Small",
							tx, h / 2, ui.text, col.align, TEXT_ALIGN_CENTER)
						x = x - col.width
					end
				end

				row.DoClick = function()
					if IsValid(member) and MilBase.OpenPlayerMenu then
						MilBase.OpenPlayerMenu(member)
					end
				end
			end
		end
	end

	--------------------------------------------------------------------
	-- "MY STATS" bottom bar
	--------------------------------------------------------------------

	local me = LocalPlayer()
	local footer = vgui.Create("DPanel", board)
	footer:Dock(BOTTOM); footer:SetTall(64); footer:DockMargin(24, 0, 24, 16)
	footer.Paint = function(self, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = ui.accent })

		draw.SimpleText("MY STATS", "MB.Med", 20, h / 2, ui.accent,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if not IsValid(me) then return end

		local stats = {
			{ "EE KILLS",     MilBase.SBEventKills(me) },
			{ "PLAYER KILLS", MilBase.SBPlayerKills(me) },
			{ "NPC KILLS",    MilBase.SBNPCKills(me) },
			{ "DEATHS",       MilBase.SBDeaths(me) },
			{ "K/D",          string.format("%.2f", MilBase.SBKDRatio(me)) },
			{ "PING",         me:Ping() },
		}

		local blockW = (w - 220) / #stats
		local x = 200
		for _, s in ipairs(stats) do
			draw.SimpleText(tostring(s[2]), "MB.Big", x + blockW / 2, h / 2 - 8, ui.text,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(s[1], "MB.Tiny", x + blockW / 2, h / 2 + 16, ui.faint,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			x = x + blockW
		end
	end

	board:MakePopup()
	board:SetKeyboardInputEnabled(false)
	return true
end

function GM:ScoreboardHide()
	if IsValid(board) then
		board:Remove()
		board = nil
	end
	CloseDermaMenus()
end