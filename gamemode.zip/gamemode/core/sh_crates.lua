--[[
	Crate registry. Crates roll rewards from a weighted loot table when opened.
	Supported reward types: card, item, attachment, weapon, credits, booster.
	Definitions can come from config/sh_crates.lua or the staff crate editor.
]]

MilBase.Crates = MilBase.Crates or {}
MilBase.CrateOrder = MilBase.CrateOrder or {}

local function orderContains(id)
	for _, current in ipairs(MilBase.CrateOrder) do if current == id then return true end end
	return false
end

function MilBase.RegisterCrate(id, source)
	id = string.lower(string.Trim(tostring(id or "")))
	assert(id ~= "", "Crate id is required")
	local data = table.Copy(source or {})
	data.id = id
	data.name = tostring(data.name or id)
	data.tier = math.Clamp(math.floor(tonumber(data.tier) or 1), 1, 4)
	data.cost = math.max(0, math.floor(tonumber(data.cost) or 0))
	data.rewards = math.Clamp(math.floor(tonumber(data.rewards) or 1), 1, 16)
	data.loot = istable(data.loot) and data.loot or {}
	if not orderContains(id) then table.insert(MilBase.CrateOrder, id) end
	MilBase.Crates[id] = data
	return data
end

function MilBase.RemoveCrate(id)
	id = string.lower(string.Trim(tostring(id or "")))
	if not MilBase.Crates[id] then return false end
	MilBase.Crates[id] = nil
	for index = #MilBase.CrateOrder, 1, -1 do
		if MilBase.CrateOrder[index] == id then table.remove(MilBase.CrateOrder, index) end
	end
	return true
end

function MilBase.GetCrate(id)
	return MilBase.Crates[id]
end

function MilBase.RollLoot(loot)
	local total = 0
	for _, entry in ipairs(loot or {}) do total = total + math.max(0, tonumber(entry.weight) or 1) end
	if total <= 0 then return nil end
	local roll = math.random() * total
	for _, entry in ipairs(loot or {}) do
		roll = roll - math.max(0, tonumber(entry.weight) or 1)
		if roll <= 0 then return entry end
	end
	return loot and loot[#loot] or nil
end
