--[[
	Comms / radio system config.

	Players hold [H] to pick a comm channel; their voice AND typed chat then go
	out on that channel to everyone allowed to hear it (see modules/sh_comms.lua).

	Channels: Local (proximity), Command, Regimental, Training, ATC, Joint Ops,
	and Event Enemy. High Command hears every channel and can speak on any.

	This file only defines the ROLE predicates + toggles. Adjust them to match
	your rank/cert setup:
	  - High Command: give your top ranks `highCommand = true` in the faction
	    config, or grant a "high_command" certification.
	  - Pilots: grant a "pilot" certification, or set `pilot = true` on a rank.
	  - Spec Ops (can jam Event-Enemy comms): grant a "specops" certification.
]]

local cfg = MilBase.Config

cfg.CommsEnabled = true

-- Jammer: blocks radio comms in a radius (or map-wide). Event enemies & staff
-- jam friendly comms; Spec Ops jam Event-Enemy comms. Local proximity voice is
-- never jammed.
cfg.CommsJammerEnabled = true
cfg.CommsJammerRadius   = 3500 -- default jamming radius (units)

-- Encrypted comms: how long a Relay hack lets High Command read the encrypted
-- channel before the frequency changes and they lose access.
cfg.EncryptedDecryptTime = 90

-- Radio SFX: short sounds played locally for push-to-talk feedback and when a
-- radio transmission you can hear begins. Set any to "" to disable, or point
-- them at your own (e.g. BF2) radio sound files.
cfg.RadioSFX = {
	txOn  = "buttons/blip1.wav",    -- you key up (start transmitting)
	txOff = "buttons/blip2.wav",    -- you release the key
	rx    = "buttons/button17.wav", -- a radio talker you can hear starts
}
-- Push-to-talk key and radio receive volume are per-player client settings
-- (mb_radio_key / mb_radio_volume), set in the F4 COMMS tab. Channel muting is
-- also client-owned (F4 COMMS tab or hold-[H] then [R]) and synced to the
-- server so it applies to both voice and chat.

--------------------------------------------------------------------------
-- Role predicates (both realms). IsValid-guarded and cert/rank-flag based.
--------------------------------------------------------------------------

-- NOTE: comms roles are purely IN-CHARACTER (rank flag / cert) - being a staff
-- admin does NOT grant channel access, so staff play their real rank. Mark your
-- top ranks with `highCommand = true` in config/sh_factions.lua (or grant a
-- "high_command" cert) to designate High Command.
function MilBase.CommsIsHighCommand(ply)
	if not IsValid(ply) then return false end
	local rank = ply:MBRank()
	return (rank and rank.highCommand == true) or ply:MBHasCert("high_command")
end

function MilBase.CommsIsOfficer(ply)
	if not IsValid(ply) then return false end
	local rank = ply:MBRank()
	return (rank and rank.canPromote == true) or MilBase.CommsIsHighCommand(ply)
end

function MilBase.CommsIsPilot(ply)
	if not IsValid(ply) then return false end
	local rank = ply:MBRank()
	return ply:MBHasCert("pilot") or (rank and rank.pilot == true) or MilBase.CommsIsHighCommand(ply)
end

-- Staff who can eavesdrop on / decrypt the (encrypted) Hostile Net.
function MilBase.CommsIsStaff(ply)
	if not IsValid(ply) then return false end
	return ply:IsAdmin() or (ply.MBStaffLevel and ply:MBStaffLevel() > 0)
end

-- Who may deploy a comms jammer.
function MilBase.CommsCanJam(ply)
	if not IsValid(ply) then return false end
	if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then
		local class = MilBase.EventEnemyClassOf and MilBase.EventEnemyClassOf(ply)
		return class ~= nil and class.jammer ~= false
	end
	if ply:GetNWBool("mb_eventmode", false) then return true end          -- game master
	if ply:GetNWBool("mb_staffmode", false) then return true end          -- staff mode
	if ply:GetNWBool("mb_cloaked", false) then return true end            -- cloaked
	return ply:MBHasCert("specops")                                       -- spec ops
end
