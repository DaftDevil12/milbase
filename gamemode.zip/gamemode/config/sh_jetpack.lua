--[[
	MilBase jetpack configuration.
	
	This is a standalone gameplay system. It does not create or modify a
	certification; use the admin test command until it is linked to a cert.
]]

local cfg = MilBase.Config

cfg.Jetpack = cfg.Jetpack or {
	Enabled = true,

	-- Controls.
	WheelKey = KEY_G or 17,
	DoubleTapJumpWindow = 0.34,
	BoostKey = IN_SPEED,

	-- Fuel and thermal management.
	FuelMax = 100,
	FuelMinimumToIgnite = 10,
	FuelDrainIdleFlight = 2.5,
	FuelDrainLift = 13,
	FuelDrainHover = 10,
	FuelDrainDirectional = 3,
	FuelRegenGrounded = 22,
	FuelRegenAirborne = 0,
	FuelRegenDelay = 1.25,
	HeatMax = 100,
	HeatLiftPerSecond = 13,
	HeatHoverPerSecond = 9,
	HeatDirectionalPerSecond = 3,
	HeatCoolPerSecond = 20,
	HeatVentPerSecond = 48,
	OverheatRecovery = 38,
	VentDuration = 2.5,

	-- Thrust physics. Values are Source units / second.
	FlightSpeed = 300,
	RiseSpeed = 265,
	DescendSpeed = 235,
	EmergencyDescentSpeed = 115,
	HorizontalAcceleration = 680,
	VerticalAcceleration = 760,
	HoverDamping = 8,
	GroundLaunchSpeed = 185,
	MaximumHorizontalSpeed = 520,
	MaximumRiseSpeed = 330,
	MaximumFallSpeed = 620,

	-- Directional boost. Press Sprint while airborne and ignited.
	BoostFuelCost = 22,
	BoostHeat = 26,
	BoostCooldown = 2.25,
	BoostSpeed = 540,
	BoostUpwardSpeed = 75,
	BoostTraceDistance = 92,

	-- Assisted landings. Fall protection is only granted while the jetpack is
	-- ignited, functional, not overheated, and has enough fuel to arrest the fall.
	AssistedLanding = true,
	LandingMinimumSpeed = 360,
	LandingFuelCost = 12,
	LandingHeat = 8,

	-- Optional pack integrity. Damage to the rear or explosive damage harms the
	-- pack without reducing the incoming player damage.
	IntegrityEnabled = true,
	IntegrityMax = 100,
	RearDamageDot = -0.2,
	RearDamageScale = 0.32,
	ExplosionDamageScale = 0.55,
	RepairTime = 5,
	RepairAmount = 55,
	RepairChargeCost = 35,
	RequireRepairKit = true,
	RepairRange = 125,

	-- Flight weapon handling. The weapon itself is not replaced or rewritten.
	AirborneWeaponSpread = 0.014,
	BoostBlocksFiring = true,

	-- Compatibility restrictions.
	DisableInZeroG = true,
	DisableWhileWounded = true,
	DisableWhileCuffed = true,
	DisableWhileJailed = true,
	DisableInVehicle = true,
	MutuallyExclusiveWithJuggernaut = true,

	-- Persistent MilBase inventory item. It equips into its own JETPACK slot,
	-- separate from storage backpacks. The world model is only used for the
	-- inventory icon / dropped item until a dedicated jetpack model is supplied.
	InventoryItemID = "jetpack_jt12",
	InventoryItemName = "JT-12 Jetpack",
	InventoryItemDescription = "A reusable thrust pack with fuel, heat and integrity systems. Equip it in the JETPACK gear slot.",
	InventoryItemWidth = 2,
	InventoryItemHeight = 3,
	InventoryItemModel = "models/props_c17/canister01a.mdl",
	InventoryItemIcon = "armorstore/ui/backpack_universal.png",

	-- Optional cosmetic backpack model. Leave blank until a desired model path
	-- is supplied; exhaust effects still render without it.
	BackModel = "",
	BackModelScale = 1,
	BackBone = "ValveBiped.Bip01_Spine2",
	BackOffset = Vector(-8, 0, -3),
	BackAngle = Angle(0, 90, 90),
	ThrusterOffsetLeft = Vector(-10, -8, 43),
	ThrusterOffsetRight = Vector(-10, 8, 43),

	LogActions = true,
}
