--[[
	Faction (regiment) definitions.

	This is the file you edit to turn MilBase into StarWarsRP, HaloRP,
	MilitaryRP, etc. Each faction is one MilBase.RegisterFaction call -
	as simple as DarkRP.createJob, but with built-in ranks, assignment,
	promotions, and per-rank loadouts/salaries.

	Players do NOT pick factions themselves: everyone starts in the
	default faction (recruits) and is assigned by officers or admins
	with /setfaction, then promoted with /promote.

	Faction fields:
	  name         - display name
	  color        - faction color (chat tags, HUD, menu)
	  logo         - optional emblem material shown on the roster and
	                 scoreboard (hidden automatically if not mounted)
	  description  - shown in the F4 menu
	  models       - table of playermodels (picked per-player, per-rank override allowed)
	  loadout      - weapons every member gets
	  medic        - if true, all members stabilize the wounded faster
	  police       - if true, members can cuff and drag soldiers
	  issue        - standard-issue items (see config/sh_items.lua), e.g.
	                 issue = { bandage = 2, painkillers = 1 }. Players are
	                 resupplied UP TO these counts every spawn.
	  ranks        - ordered lowest -> highest. Per-rank fields:
	                   name, salary, loadout (extra weapons), models (override),
	                   canPromote (officer: can use /promote, /demote, /setfaction, /certify),
	                   medic (this rank stabilizes the wounded faster),
	                   issue (extra standard-issue items for this rank)

	The example factions below use only base HL2 assets so the gamemode works
	with zero addons. Swap the model paths and weapon classes for your content
	pack (TFA/ArcCW/CW2 weapon classes drop straight in).
]]

MilBase.RegisterFaction("Cadets", {
	name = "Cadets",
	logo = "kraken/bf2f4/neutral.png",
	color = Color(255, 255, 255),
	description = "Fresh arrivals awaiting assignment to a regiment.",
	models = {
		"models/player/okfellow/clone_cadet.mdl",
	},
	loadout = {},
	issue = { bandage = 1 },
	ranks = {
		{ name = "Cadet", salary = 1 },
	},
})

MilBase.RegisterFaction("ct", {
	name = "Unassigned Clone Troopers",
	logo = "kraken/bf2f4/republic.png",
	color = Color(255, 255, 255),
	description = "Newly Trained Cadets. Frontline riflemen Deployed straight from Kamino.",
	models = {
		"models/player/clone cadet/clonecadet.mdl",
	},
	loadout = { "arccw_cgi_k_dc15s", "arccw_cgi_k_dc15a", "arccw_cgi_k_dc17"},
	issue = {},
	ranks = {
	-- Enlisted
        { name = "Private",               salary = 25 },
        { name = "Private First Class",   salary = 30 },
        { name = "Lance Corporal",            salary = 35 },

    --[[ NCOs
        { name = "Corporal",              salary = 40 },
        { name = "Sergeant",              salary = 50, canPromote = true },
        { name = "Staff Sergeant",        salary = 60, canPromote = true },
        { name = "Master Sergeant",       salary = 80, canPromote = true },
        { name = "Sergeant Major",        salary = 100, canPromote = true },

      -- Officers  
		{ name = "Second Lieutenant", salary = 80, canPromote = true },
        { name = "Lieutenant",         salary = 90, canPromote = true },
        { name = "Captain",            salary = 100, canPromote = true },
        { name = "Major",              salary = 120, canPromote = true },
        { name = "Commander",          salary = 145, canPromote = true },
        { name = "Senior Commander",   salary = 170, canPromote = true },
        { name = "Marshal Commander",  salary = 200, canPromote = true }, ]]-- Disabled Ranks for CTs
	},
})

MilBase.RegisterFaction("501st", {
	name = "501st Legion",
	logo = "milbase/ui/regiments/501st.png",
	color = Color(0, 140, 255),
	description = "The Backbone Infantry frontline fighters.",
	models = {
   "models/player/clone cadet/clonecadet.mdl",
	},
	loadout = { "weapon_pistol" },
	issue = {"arccw_cgi_k_dlt16", "arccw_cgi_k_dc15s"},
	ranks = {

	-- Enlisted
        { name = "Private",               salary = 25 },
        { name = "Private First Class",   salary = 30 },
        { name = "Lance Corporal",            salary = 35 },

    -- NCOs
        { name = "Corporal",              salary = 40 },
        { name = "Sergeant",              salary = 50, canPromote = true },
        { name = "Staff Sergeant",        salary = 60, canPromote = true },
        { name = "Master Sergeant",       salary = 80, canPromote = true },
        { name = "Sergeant Major",        salary = 100, canPromote = true },

      -- Officers  
		{ name = "Second Lieutenant", salary = 80, canPromote = true },
        { name = "Lieutenant",         salary = 90, canPromote = true },
        { name = "Captain",            salary = 100, canPromote = true },
        { name = "Major",              salary = 120, canPromote = true },
        { name = "Commander",          salary = 145, canPromote = true },
        { name = "Senior Commander",   salary = 170, canPromote = true },
        { name = "Marshal Commander",  salary = 200, canPromote = true },
	},
})
MilBase.RegisterFaction("212th", {
	name = "212th Attack Battalion",
	logo = "kraken/bf2f4/republic.png",
	color = Color(201, 127, 52),
	description = "Heavy vehicle and anti-tank regiment. Specializes in armored warfare, vehicle support, and the destruction of enemy armor.",
	models = {
		"models/player/clone cadet/clonecadet.mdl",
	},
	loadout = {"arccw_cgi_k_dc15a", "arccw_cgi_k_rps6"},
	issue = {
		bandage = 2,
		ammo_pistol = 1,
	},
	ranks = {
		-- Enlisted
		{ name = "Private",             salary = 25 },
		{ name = "Private First Class", salary = 30 },
		{ name = "Lance Corporal",      salary = 35 },

		-- NCOs
		{ name = "Corporal",            salary = 40 },
		{ name = "Sergeant",            salary = 50, canPromote = true },
		{ name = "Staff Sergeant",      salary = 60, canPromote = true },
		{ name = "Master Sergeant",     salary = 80, canPromote = true },
		{ name = "Sergeant Major",      salary = 100, canPromote = true },

		-- Officers
		{ name = "Second Lieutenant",   salary = 80, canPromote = true },
		{ name = "Lieutenant",          salary = 90, canPromote = true },
		{ name = "Captain",             salary = 100, canPromote = true },
		{ name = "Major",               salary = 120, canPromote = true },
		{ name = "Commander",           salary = 145, canPromote = true },
		{ name = "Senior Commander",    salary = 170, canPromote = true },
		{ name = "Marshal Commander",   salary = 200, canPromote = true },
	},
})

MilBase.RegisterFaction("41st", {
	name = "41st Recon Forces",
	logo = "kraken/bf2f4/republic.png",
	color = Color(92, 156, 92),
	description = "Specialized reconnaissance and scouting battalion. Experts in long-range patrols, intelligence gathering, and Sniper Warfare",
	models = {
		"models/player/clone cadet/clonecadet.mdl",
	},
	loadout = {"arccw_k_valken38", "arccw_cgi_k_dc15s"},
	issue = {},
	ranks = {
		-- Enlisted
		{ name = "Private",             salary = 25 },
		{ name = "Private First Class", salary = 30 },
		{ name = "Lance Corporal",      salary = 35 },

		-- NCOs
		{ name = "Corporal",            salary = 40 },
		{ name = "Sergeant",            salary = 50, canPromote = true },
		{ name = "Staff Sergeant",      salary = 60, canPromote = true },
		{ name = "Master Sergeant",     salary = 80, canPromote = true },
		{ name = "Sergeant Major",      salary = 100, canPromote = true },

		-- Officers
		{ name = "Second Lieutenant",   salary = 80, canPromote = true },
		{ name = "Lieutenant",          salary = 90, canPromote = true },
		{ name = "Captain",             salary = 100, canPromote = true },
		{ name = "Major",               salary = 120, canPromote = true },
		{ name = "Commander",           salary = 145, canPromote = true },
		{ name = "Senior Commander",    salary = 170, canPromote = true },
		{ name = "Marshal Commander",   salary = 200, canPromote = true },
	},
})

MilBase.RegisterFaction("104th", {
	name = "104th Wolfpack Battalion",
	logo = "milbase/ui/regiments/104th.jpg",
	color = Color(120, 120, 120),
	description = "Engineering and battlefield support regiment. Specializes in fortifications, repairs, logistics, and recovery operations under combat conditions.",
	police = false,
	models = {
		"models/player/clone cadet/clonecadet.mdl",
	},
	loadout = {"arccw_cgi_k_dc15s", "arccw_cgi_k_dp23",},
	issue = {
		bandage = 2,
		ammo_pistol = 1,
	},
	ranks = {
		-- Enlisted
		{ name = "Private",             salary = 25 },
		{ name = "Private First Class", salary = 30 },
		{ name = "Lance Corporal",      salary = 35 },

		-- NCOs
		{ name = "Corporal",            salary = 40 },
		{ name = "Sergeant",            salary = 50, canPromote = true },
		{ name = "Staff Sergeant",      salary = 60, canPromote = true },
		{ name = "Master Sergeant",     salary = 80, canPromote = true },
		{ name = "Sergeant Major",      salary = 100, canPromote = true },

		-- Officers
		{ name = "Second Lieutenant",   salary = 80, canPromote = true },
		{ name = "Lieutenant",          salary = 90, canPromote = true },
		{ name = "Captain",             salary = 100, canPromote = true },
		{ name = "Major",               salary = 120, canPromote = true },
		{ name = "Commander",           salary = 145, canPromote = true },
		{ name = "Senior Commander",    salary = 170, canPromote = true },
		{ name = "Marshal Commander",   salary = 200, canPromote = true },
	},
})

MilBase.RegisterFaction("cg", {
	name = "Coruscant Guard",
	logo = "kraken/bf2f4/empire.png",
	color = Color(70, 110, 180),
	description = "Base security and discipline enforcement. By assignment only.",
	police = true, -- can cuff and drag soldiers (hold E on a player)
	models = {
		"models/player/clone cadet/clonecadet.mdl",
	},
	loadout = {"arccw_cgi_k_dc15s_stun", "arccw_cgi_k_dc15a_stun"},
	issue = {},
	ranks = {
	-- Enlisted
        { name = "Private",               salary = 25 },
        { name = "Private First Class",   salary = 30 },
        { name = "Lance Corporal",            salary = 35 },

    -- NCOs
        { name = "Corporal",              salary = 40 },
        { name = "Sergeant",              salary = 50, canPromote = true },
        { name = "Staff Sergeant",        salary = 60, canPromote = true },
        { name = "Master Sergeant",       salary = 80, canPromote = true },
        { name = "Sergeant Major",        salary = 100, canPromote = true },

      -- Officers  
		{ name = "Second Lieutenant", salary = 80, canPromote = true },
        { name = "Lieutenant",         salary = 90, canPromote = true },
        { name = "Captain",            salary = 100, canPromote = true },
        { name = "Major",              salary = 120, canPromote = true },
        { name = "Commander",          salary = 145, canPromote = true },
        { name = "Senior Commander",   salary = 170, canPromote = true },
        { name = "Marshal Commander",  salary = 200, canPromote = true },
	},
})

--[[
MilBase.RegisterFaction("rc", {
	name = "Republic Commandos",
	logo = "kraken/bf2f4/republic.png",
	color = Color(40, 40, 40),
	description = "Elite special forces unit. Conducts high-risk infiltration, assassination, sabotage, and reconnaissance operations behind enemy lines.",
	police = false,
	models = {
		"models/player/police.mdl",
	},
	loadout = {
		"weapon_ar2",
		"weapon_pistol",
	},
	issue = {
		bandage = 3,
		ifak = 1,
		ammo_pistol = 1,
	},
	ranks = {
		-- Enlisted / Operatives
		{ name = "Initiate",           salary = 40 },
		{ name = "Commando Trainee",   salary = 50 },
		{ name = "Commando",           salary = 70 },

		-- Squad Roles
		{ name = "Squad Marksman",     salary = 85, canPromote = true },
		{ name = "Squad Engineer",     salary = 90, canPromote = true },
		{ name = "Squad Medic",        salary = 95, canPromote = true },
		{ name = "Squad Leader",       salary = 110, canPromote = true },

		-- Command Structure
		{ name = "Elite Commando",     salary = 130, canPromote = true },
		{ name = "Commando Captain",   salary = 150, canPromote = true },
		{ name = "Delta Commander",    salary = 180, canPromote = true },
		{ name = "Null Commander",     salary = 200, canPromote = true },
		{ name = "Republic Commando Colonel", salary = 230, canPromote = true },
	},
})
--]]

MilBase.RegisterFaction("Navy", {
	name = "Republic Navy",
	logo = "kraken/bf2f4/jediorder.png",
	color = Color(180, 60, 60),
	description = "Base leadership. High Command.",
	police = true,
	models = {
		"models/navy/gnavycrewman.mdl",
	},
	loadout = {"arccw_cgi_k_dc17_stun",},
	issue = { bandage = 2, ifak = 1 },
	ranks = {
    -- Enlisted
      { name = "Crewman Recruit",      salary = 20 },
      { name = "Crewman",              salary = 25 },
      { name = "Senior Crewman",       salary = 30 },
      { name = "Petty Officer",        salary = 40 },

    -- NCOs
      { name = "Chief Petty Officer",        salary = 50, canPromote = true },
      { name = "Senior Chief Petty Officer", salary = 60, canPromote = true },
      { name = "Master Chief Petty Officer", salary = 75, canPromote = true },

    -- Officers
      { name = "Ensign",               salary = 90, canPromote = true },
      { name = "Lieutenant",           salary = 105, canPromote = true },
      { name = "Lieutenant Commander", salary = 120, canPromote = true },
      { name = "Commander",            salary = 140, canPromote = true },
      { name = "Captain",              salary = 165, canPromote = true },
      { name = "Commodore",            salary = 190, canPromote = true },
      { name = "Rear Admiral",         salary = 220, canPromote = true },
      { name = "Vice Admiral",         salary = 250, canPromote = true },
      { name = "Admiral",              salary = 300, canPromote = true },
   },
})

MilBase.RegisterFaction("jedi", {
	name = "Jedi Order",
	logo = "kraken/bf2f4/jediorder.png",
	color = Color(205, 180, 105),
	description = "Force-sensitive peacekeepers trained in lightsaber combat, diplomacy, and service to the Republic.",
	jedi = true,
	forceSensitive = true,
	police = false,
	models = {
		-- Safe base-game fallbacks. Replace these with your Jedi model pack paths.
		"models/player/group01/male_07.mdl",
		"models/player/group01/female_06.mdl",
	},
	loadout = {},
	issue = { bandage = 2, ifak = 1 },
	ranks = {
		{ name = "Jedi Initiate", jediLevel = 1, salary = 25 },
		{ name = "Jedi Padawan",  jediLevel = 2, salary = 40 },
		{ name = "Jedi Knight",   jediLevel = 3, salary = 75 },
		{ name = "Jedi Master",   jediLevel = 4, salary = 120, canPromote = true },
		{ name = "Jedi Council",  jediLevel = 5, salary = 175, canPromote = true },
	},
})
