-- Naval Operations configuration. This joins the bridge, engineering,
-- logistics and Galaxy Director into one persistent ship state.
local cfg = MilBase.Config

cfg.NavalOperations = cfg.NavalOperations or {}
local naval = cfg.NavalOperations

naval.Enabled = naval.Enabled ~= false
naval.StateBroadcastInterval = naval.StateBroadcastInterval or 1.25
naval.StateSaveDelay = naval.StateSaveDelay or 2
naval.MaximumContacts = naval.MaximumContacts or 48
naval.LogLimit = naval.LogLimit or 24
naval.CommandStaffLevel = naval.CommandStaffLevel or 3

-- Bridge consoles are Navy workstations. Staff retain the placement/removal
-- commands, but do not receive an operational bypass while playing outside
-- the Republic Navy.
naval.ConsoleFactionIDs = naval.ConsoleFactionIDs or {
	Navy = true,
	navy = true,
}
naval.ConsoleFactionNames = naval.ConsoleFactionNames or {
	["Republic Navy"] = true,
}
naval.ConsoleUseRange = naval.ConsoleUseRange or 700
naval.CommandMinimumRankIndex = naval.CommandMinimumRankIndex or 8
naval.ConsoleActionCooldown = naval.ConsoleActionCooldown or 0.3
naval.FleetConsoleModel = naval.FleetConsoleModel
	or "models/lordtrilobite/starwars/isd/imp_console_medium02.mdl"
naval.FleetConsoleUseRange = naval.FleetConsoleUseRange or 240

-- The CIC is a model-free 3D2D projector placed on an existing map screen.
-- 1024x620 pixels at 0.135 is roughly 138x84 map units.
naval.ScreenScale = naval.ScreenScale or 0.135
naval.ScreenMinimumScale = naval.ScreenMinimumScale or 0.025
naval.ScreenMaximumScale = naval.ScreenMaximumScale or 0.4
naval.ScreenSurfaceOffset = naval.ScreenSurfaceOffset or 0.45
naval.ScreenSelectionRadius = naval.ScreenSelectionRadius or 260
-- Screens restored by both the naval database and a prop-persistence addon can
-- overlap exactly. These tolerances identify only effectively identical panels.
naval.ScreenDuplicatePositionTolerance = naval.ScreenDuplicatePositionTolerance or 6
naval.ScreenDuplicateAngleTolerance = naval.ScreenDuplicateAngleTolerance or 3

-- The power console is another model-free projector. Place it over a suitable
-- map prop with /navalpowerconsole and press E on the projected display.
naval.PowerConsoleScale = naval.PowerConsoleScale or 0.105
naval.PowerConsoleMinimumScale = naval.PowerConsoleMinimumScale or 0.025
naval.PowerConsoleMaximumScale = naval.PowerConsoleMaximumScale or 0.3
naval.PowerConsoleSurfaceOffset = naval.PowerConsoleSurfaceOffset or 0.55
naval.PowerConsoleUseRange = naval.PowerConsoleUseRange or 700
naval.PowerCapacity = naval.PowerCapacity or 100
naval.PowerSystemMaximum = naval.PowerSystemMaximum or 60
naval.PowerLifeSupportMinimum = naval.PowerLifeSupportMinimum or 8
naval.PowerChangeCooldown = naval.PowerChangeCooldown or 0.5

-- CIC navigation, IFF and controlled-space configuration.
naval.InterceptSpeed = naval.InterceptSpeed or 120
naval.InterceptMaximumSeconds = naval.InterceptMaximumSeconds or 600
naval.IFFChallengeCooldown = naval.IFFChallengeCooldown or 2
naval.TransponderModes = naval.TransponderModes or {
	active = {
		label = "REPUBLIC AUTHENTICATED",
		description = "Broadcast the flagship's Republic naval identity.",
	},
	low_emission = {
		label = "LOW EMISSION",
		description = "Reduce routine emissions while retaining encrypted naval identification.",
	},
	emergency = {
		label = "EMERGENCY BEACON",
		description = "Broadcast priority Republic identification and distress telemetry.",
	},
}
naval.RestrictedZonesEnabled = naval.RestrictedZonesEnabled ~= false
naval.RestrictedZoneMaximum = naval.RestrictedZoneMaximum or 8
naval.RestrictedZoneMinimumRadius = naval.RestrictedZoneMinimumRadius or 0.15
naval.RestrictedZoneMaximumRadius = naval.RestrictedZoneMaximumRadius or 1
naval.RestrictedZoneDefaultRadius = naval.RestrictedZoneDefaultRadius or 0.65
naval.RestrictedZoneCheckInterval = naval.RestrictedZoneCheckInterval or 2
naval.RestrictedZoneWarningSeconds = naval.RestrictedZoneWarningSeconds or 7
naval.RestrictedZoneCivilianCompliance = naval.RestrictedZoneCivilianCompliance or 0.9
naval.RestrictedZonePirateCompliance = naval.RestrictedZonePirateCompliance or 0.4
naval.RestrictedZoneDepartureSpeed = naval.RestrictedZoneDepartureSpeed or 82
naval.RestrictedZoneDurations = naval.RestrictedZoneDurations or {
	{ id = "15m", label = "15 MINUTES", seconds = 900 },
	{ id = "30m", label = "30 MINUTES", seconds = 1800 },
	{ id = "60m", label = "60 MINUTES", seconds = 3600 },
	{ id = "permanent", label = "PERMANENT", seconds = 0 },
}

naval.ResourceMaximums = naval.ResourceMaximums or {
	funding = 250000,
	supplies = 12000,
	fuel = 10000,
	munitions = 8000,
	medical = 4000,
	repair = 6000,
}
naval.InitialResources = naval.InitialResources or {
	funding = 85000,
	supplies = 5000,
	fuel = 4200,
	munitions = 3200,
	medical = 1600,
	repair = 2400,
}

-- Persistent Republic support fleet. Ships bought here remain part of the
-- campaign, follow the player Venator between systems, and may be detached on
-- real-time supply runs. Model candidates are checked at runtime so missing
-- workshop content falls back to the normal Republic capital model.
naval.FleetEnabled = naval.FleetEnabled ~= false
naval.FleetMaximumShips = naval.FleetMaximumShips or 6
naval.FleetMissionMinimumSeconds = naval.FleetMissionMinimumSeconds or 480
naval.FleetMissionMaximumSeconds = naval.FleetMissionMaximumSeconds or 2400
naval.FleetMissionSecondsPerUniverseUnit = naval.FleetMissionSecondsPerUniverseUnit or 0.22
-- Version 3 moves existing fleets out to the protected formation perimeter.
-- Increment this only when a future formation layout requires another
-- one-time migration of existing saved fleets.
naval.FleetFormationLayoutVersion = naval.FleetFormationLayoutVersion or 3
naval.FleetDefaultFormation = naval.FleetDefaultFormation or "close_escort"
naval.FleetDefaultFormationRange = naval.FleetDefaultFormationRange or 24
naval.FleetFormationMinimumRange = naval.FleetFormationMinimumRange or 18
naval.FleetFormationMaximumRange = naval.FleetFormationMaximumRange or 72
-- No owned support vessel may settle inside this protected radius around the
-- player flagship. The larger of the fixed distance, skybox fraction, or ship
-- hull clearance is used so capital ships remain safely separated on every map.
naval.FleetFormationMinimumFlagshipDistance = naval.FleetFormationMinimumFlagshipDistance or 360
naval.FleetFormationMinimumFlagshipDistanceFraction = naval.FleetFormationMinimumFlagshipDistanceFraction or 0.24
naval.FleetFormationFlagshipHullClearance = naval.FleetFormationFlagshipHullClearance or 180
naval.FleetFormationShipSeparationScale = naval.FleetFormationShipSeparationScale or 1.35
-- Fleet visuals are already simulated in the flagship's local skybox. Using
-- the SWU universe heading here rotates them twice and leaves them broadside
-- whenever the player ship's stored galactic yaw is near 90 degrees.
naval.FleetFormationLocalHeadingYaw = naval.FleetFormationLocalHeadingYaw or 0
naval.FleetFormationManeuverSpeed = naval.FleetFormationManeuverSpeed or 120
-- The maneuver speed above remains a hard ceiling. These class limits keep
-- large ships inside their real turn and braking envelopes while changing
-- formation instead of letting them orbit a slot they cannot capture.
naval.FleetFormationRoleSpeeds = naval.FleetFormationRoleSpeeds or {
	default = 50,
	republic = 58,
	republic_flagship = 38,
}
naval.FleetFormationPositionGain = naval.FleetFormationPositionGain or 0.38
naval.FleetFormationDeadband = naval.FleetFormationDeadband or 10
naval.FleetFormationArrivalRadiusScale = naval.FleetFormationArrivalRadiusScale or 0.08
naval.FleetFormationMaximumArrivalRadius = naval.FleetFormationMaximumArrivalRadius or 32
naval.FleetFormationBrakeSafety = naval.FleetFormationBrakeSafety or 0.82
naval.FleetFormationTurnMinimumThrottle = naval.FleetFormationTurnMinimumThrottle or 0.12
naval.FleetFormationShipClearance = naval.FleetFormationShipClearance or 80
naval.FleetFormationAvoidanceRangeScale = naval.FleetFormationAvoidanceRangeScale or 1.8
naval.FleetFormationArrivalStagger = naval.FleetFormationArrivalStagger or 0.45
naval.FleetFormationEntrySpacing = naval.FleetFormationEntrySpacing or 620
naval.FleetFormationEntryHeightStep = naval.FleetFormationEntryHeightStep or 140
naval.FleetSalvageApproachSpeed = naval.FleetSalvageApproachSpeed or 105
naval.FleetSalvageWorkSeconds = naval.FleetSalvageWorkSeconds or 38
naval.FleetSalvageWreckLifetime = naval.FleetSalvageWreckLifetime or 900
naval.FleetSalvageFundingMinimum = naval.FleetSalvageFundingMinimum or 1800
naval.FleetSalvageFundingMaximum = naval.FleetSalvageFundingMaximum or 6200
naval.FleetSalvageScrapMinimum = naval.FleetSalvageScrapMinimum or 18
naval.FleetSalvageScrapMaximum = naval.FleetSalvageScrapMaximum or 65
naval.FleetSalvageCapitalMultiplier = naval.FleetSalvageCapitalMultiplier or 1.8
naval.FleetFormationOrder = naval.FleetFormationOrder or {
	"close_escort", "vee", "line", "column", "echelon_left", "echelon_right", "diamond",
}
naval.FleetFormations = naval.FleetFormations or {
	close_escort = {
		label = "CLOSE ESCORT",
		description = "Ships take tight parallel stations immediately off both sides of the flagship.",
	},
	vee = {
		label = "V FORMATION",
		description = "Balanced combat formation with escorts spread behind both sides of the flagship.",
	},
	line = {
		label = "LINE ABREAST",
		description = "All fleet ships form a broad line for maximum visible fire coverage.",
	},
	column = {
		label = "LINE ASTERN",
		description = "Ships form a single trailing column for narrow approach lanes.",
	},
	echelon_left = {
		label = "LEFT ECHELON",
		description = "A diagonal formation extending behind the flagship's port side.",
	},
	echelon_right = {
		label = "RIGHT ECHELON",
		description = "A diagonal formation extending behind the flagship's starboard side.",
	},
	diamond = {
		label = "DEFENSIVE DIAMOND",
		description = "A compact layered screen intended to protect the flagship from several directions.",
	},
}
naval.PlanetSupplyCooldown = naval.PlanetSupplyCooldown or 1800
naval.PlanetSupplyOpinionMinimum = naval.PlanetSupplyOpinionMinimum or 50
naval.FleetPurchaseWorlds = naval.FleetPurchaseWorlds or {
	coruscant = true,
	kuat = true,
	kamino = true,
}
naval.RepublicSupplyWorlds = naval.RepublicSupplyWorlds or {
	coruscant = true,
	kuat = true,
	kamino = true,
	naboo = true,
	["ord mantell"] = true,
}
naval.PlanetSupplyGrant = naval.PlanetSupplyGrant or {
	supplies = 520,
	fuel = 300,
	munitions = 260,
	medical = 90,
	repair = 220,
}
naval.FleetShipDefinitions = naval.FleetShipDefinitions or {
	acclamator = {
		label = "Acclamator-class Assault Ship",
		shortLabel = "ACCLAMATOR",
		role = "republic_flagship",
		maxOwned = 3,
		hull = 10500,
		cost = {
			funding = 75000, supplies = 650, fuel = 300, repair = 350,
		},
		models = {
			"models/salty/acclamator-class.mdl",
			"models/lordtrilobite/starwars/props/acclamator_128.mdl",
			"models/kingpommes/starwars/acclamator/acclamator_sky_128.mdl",
		},
		names = {
			"RNS Resolute Spear", "RNS Valiant", "RNS Deliverance",
			"RNS Steadfast", "RNS Atlas",
		},
		groundVehicleCapacity = 8,
		cargoCapacity = 600,
		supplyYield = {
			supplies = 900, fuel = 420, munitions = 300,
			medical = 120, repair = 350,
		},
		description = "Assault transport with eight ground-vehicle berths and a high-capacity cargo deck.",
	},
	arquitens = {
		label = "Arquitens-class Light Cruiser",
		shortLabel = "ARQUITENS",
		role = "republic",
		maxOwned = 4,
		hull = 6500,
		cost = {
			funding = 45000, supplies = 300, munitions = 250, repair = 180,
		},
		models = {
			"models/salty/repubarquitens-cruiser.mdl",
		},
		names = {
			"RNS Vigil", "RNS Guardian", "RNS Reliant",
			"RNS Sentinel", "RNS Wayfarer",
		},
		fireSupportDamage = 320,
		cargoCapacity = 220,
		supplyYield = {
			supplies = 420, fuel = 220, munitions = 450,
			medical = 60, repair = 160,
		},
		description = "Fast escort cruiser that contributes an extra turbolaser volley while attached to the fleet.",
	},
}

-- Persistent flagship cargo hold and dynamic markets. Prices rise when the
-- current world is short of a commodity and fall when local stock is high.
naval.FleetBaseCargoCapacity = naval.FleetBaseCargoCapacity or 420
naval.TradeMaximumUnitsPerOrder = naval.TradeMaximumUnitsPerOrder or 100
naval.TradeContactDuration = naval.TradeContactDuration or 120
naval.TradeBuyStockMinimum = naval.TradeBuyStockMinimum or 1
naval.TradeSellReturnFraction = naval.TradeSellReturnFraction or 0.72
naval.TradeCommodityOrder = naval.TradeCommodityOrder or {
	"food", "medical", "fuel", "parts", "industrial", "munitions", "scrap",
}
naval.TradeCommodities = naval.TradeCommodities or {
	food = {
		label = "Relief Rations", manifest = "food and relief packages",
		basePrice = 70, volume = 1, economyKey = "food",
	},
	medical = {
		label = "Medical Supplies", manifest = "medical supplies and bacta",
		basePrice = 185, volume = 1, economyKey = "medical",
	},
	fuel = {
		label = "Refined Fuel Cells", manifest = "refined fuel cells",
		basePrice = 145, volume = 1, economyKey = "fuel",
	},
	parts = {
		label = "Starship Parts", manifest = "replacement starship parts",
		basePrice = 165, volume = 2, economyKey = "parts",
	},
	industrial = {
		label = "Industrial Components", manifest = "industrial components",
		basePrice = 110, volume = 2, economyKey = "industrial",
	},
	munitions = {
		label = "Sealed Munitions", manifest = "sealed Republic munitions",
		basePrice = 235, volume = 2, economyKey = "munitions",
	},
	scrap = {
		label = "Recovered Scrap", manifest = "salvaged hull plating and components",
		basePrice = 48, volume = 1, economyKey = "scrap", buyable = false,
	},
}

-- This is the funding gate used by the future trooper/regimental skill tree.
-- Unlocks are permanent once the campaign reaches the threshold. A disabled
-- tier may be built privately and enabled here when it is ready for players.
naval.RegimentalSkillTiers = naval.RegimentalSkillTiers or {
	[1] = { label = "TIER I", requiredFunding = 0, enabled = true },
	[2] = { label = "TIER II", requiredFunding = 100000, enabled = true },
	[3] = { label = "TIER III", requiredFunding = 175000, enabled = true },
	[4] = { label = "TIER IV", requiredFunding = 250000, enabled = false },
	[5] = { label = "TIER V", requiredFunding = 350000, enabled = false },
}

-- Costs are picked by a case-insensitive token in a vehicle's configured
-- name, entity class or category. Put specific craft above generic entries.
naval.VehicleCosts = naval.VehicleCosts or {
	{ token = "arc-170", funding = 6500, supplies = 420, fuel = 260, munitions = 180 },
	{ token = "arc170", funding = 6500, supplies = 420, fuel = 260, munitions = 180 },
	{ token = "v-wing", funding = 4700, supplies = 315, fuel = 205, munitions = 145 },
	{ token = "vwing", funding = 4700, supplies = 315, fuel = 205, munitions = 145 },
	-- Retained for legacy requisition entities that still advertise V-19 names.
	{ token = "v-19", funding = 4400, supplies = 300, fuel = 190, munitions = 135 },
	{ token = "v19", funding = 4400, supplies = 300, fuel = 190, munitions = 135 },
	{ token = "y-wing", funding = 5800, supplies = 390, fuel = 240, munitions = 230 },
	{ token = "laat", funding = 5200, supplies = 360, fuel = 220, munitions = 90 },
	{ token = "fighter", funding = 4000, supplies = 280, fuel = 180, munitions = 120 },
	{ token = "shuttle", funding = 3200, supplies = 230, fuel = 150, munitions = 40 },
	{ token = "speeder", funding = 1200, supplies = 90, fuel = 55, munitions = 20 },
	{ token = "walker", funding = 3500, supplies = 260, fuel = 120, munitions = 100 },
	{ token = "vehicle", funding = 1800, supplies = 140, fuel = 80, munitions = 50 },
}
naval.DefaultVehicleCost = naval.DefaultVehicleCost
	or { funding = 2200, supplies = 160, fuel = 100, munitions = 60 }
naval.VehicleReturnRadius = naval.VehicleReturnRadius or 230
naval.VehicleReturnSpeed = naval.VehicleReturnSpeed or 18
naval.VehicleReturnHoldTime = naval.VehicleReturnHoldTime or 10
naval.VehicleReturnMinimumCondition = naval.VehicleReturnMinimumCondition or 0.2
naval.VehicleReturnRefund = naval.VehicleReturnRefund or {
	funding = 0.75,
	supplies = 1,
	fuel = 0.65,
	munitions = 0.8,
}

naval.PowerSystems = naval.PowerSystems or {
	"engines", "maneuvering", "shields", "weapons",
	"sensors", "communications", "life_support",
}
naval.InitialPower = naval.InitialPower or {
	engines = 18,
	maneuvering = 10,
	shields = 18,
	weapons = 16,
	sensors = 14,
	communications = 8,
	life_support = 16,
}
naval.PowerPresets = naval.PowerPresets or {
	cruise = {
		label = "CRUISE",
		engines = 18, maneuvering = 10, shields = 18, weapons = 16,
		sensors = 14, communications = 8, life_support = 16,
	},
	battle = {
		label = "BATTLE STATIONS",
		engines = 12, maneuvering = 8, shields = 24, weapons = 24,
		sensors = 12, communications = 8, life_support = 12,
	},
	pursuit = {
		label = "PURSUIT",
		engines = 28, maneuvering = 18, shields = 16, weapons = 14,
		sensors = 10, communications = 6, life_support = 8,
	},
	damage_control = {
		label = "DAMAGE CONTROL",
		engines = 8, maneuvering = 6, shields = 24, weapons = 6,
		sensors = 10, communications = 12, life_support = 24,
	},
}

naval.WatchStations = naval.WatchStations or {
	"command", "helm", "navigation", "tactical", "communications",
	"engineering", "flight_control", "traffic_control", "medical",
}

naval.EWModes = naval.EWModes or {
	passive = { label = "PASSIVE", sensorMultiplier = 1, drain = 0 },
	scan = { label = "ACTIVE SCAN", sensorMultiplier = 1.45, drain = 2 },
	jamming = { label = "JAMMING", sensorMultiplier = 0.9, drain = 3 },
	mask = { label = "SIGNATURE MASK", sensorMultiplier = 0.72, drain = 2 },
}

naval.Squadrons = naval.Squadrons or {
	red = { name = "Red Squadron", craft = "ARC-170", total = 6 },
	blue = { name = "Blue Squadron", craft = "V-Wing", total = 8 },
	gold = { name = "Gold Squadron", craft = "LAAT/i", total = 4 },
}
-- The same model is used at full scale on the physical hangar route and is
-- normalised to the configured target radius after transfer into the skybox.
naval.SquadronVisualModels = naval.SquadronVisualModels or {
	red = {
		"models/blu/arc170.mdl",
	},
	blue = {
		"models/blu/vwing.mdl",
	},
	gold = {
		"models/blu/laat.mdl",
		"models/arson/kotor/ships/telos_shuttle.mdl",
	},
}
naval.SquadronVisualScale = naval.SquadronVisualScale or 0.012
naval.SquadronMaximumVisuals = naval.SquadronMaximumVisuals or 3
naval.SquadronMaximumPhysicalCraft = naval.SquadronMaximumPhysicalCraft or 8
naval.SquadronPhysicalLaunchEnabled = naval.SquadronPhysicalLaunchEnabled ~= false
-- Craft travelling through the playable map use their native model size.
-- They are replaced by the much smaller skybox representation only after the
-- configured launch route has been completed.
naval.SquadronMapFullScale = naval.SquadronMapFullScale ~= false
naval.SquadronMapVisualScale = naval.SquadronMapVisualScale or 1
naval.SquadronDefaultHangarGroup = naval.SquadronDefaultHangarGroup or "main"
naval.SquadronHangarAssignments = naval.SquadronHangarAssignments or {
	red = "main",
	blue = "main",
	gold = "main",
}
-- Legacy normalised map sizing, used only when SquadronMapFullScale is false.
naval.SquadronMapTargetRadius = naval.SquadronMapTargetRadius or {
	default = 58,
	red = 62,
	blue = 56,
	gold = 78,
}
naval.SquadronSkyboxTargetRadius = naval.SquadronSkyboxTargetRadius or {
	default = 16,
	red = 17,
	blue = 15,
	gold = 21,
}
-- Optional remote control for lightweight skybox squadron representatives.
-- The controller uses an assisted mouse-aim reticle, server-authoritative
-- momentum and weapons, and client-side camera prediction. It does not convert
-- the lightweight skybox actors into LVS entities.
naval.SkyboxPilotEnabled = naval.SkyboxPilotEnabled ~= false
naval.SkyboxPilotInputRate = naval.SkyboxPilotInputRate or 0.04
naval.SkyboxPilotInputTimeout = naval.SkyboxPilotInputTimeout or 1
naval.SkyboxPilotMouseSensitivity = naval.SkyboxPilotMouseSensitivity or 0.028
naval.SkyboxPilotThrottleRate = naval.SkyboxPilotThrottleRate or 0.34
naval.SkyboxPilotBoundaryMargin = naval.SkyboxPilotBoundaryMargin or 260
naval.SkyboxPilotBoundaryStrength = naval.SkyboxPilotBoundaryStrength or 0.88
naval.SkyboxPilotCameraDistance = naval.SkyboxPilotCameraDistance or 6
naval.SkyboxPilotCameraHeight = naval.SkyboxPilotCameraHeight or 1.35
naval.SkyboxPilotCameraSmoothing = naval.SkyboxPilotCameraSmoothing or 7.5
naval.SkyboxPilotCameraAimInfluence = naval.SkyboxPilotCameraAimInfluence or 0.2
naval.SkyboxPilotCameraSpeedPullback = naval.SkyboxPilotCameraSpeedPullback or 0.32
naval.SkyboxPilotCameraCollisionPadding = naval.SkyboxPilotCameraCollisionPadding or 8
-- Remote CalcView runs inside the map's physical 3D-skybox volume. Leaving
-- Source's normal 3D-skybox projection enabled there draws a second copy of
-- the skybox around the fighter. Disable that projection only for the local
-- pilot, then restore the player's previous r_3dsky setting on release.
naval.SkyboxPilotSuppressNested3DSkybox = naval.SkyboxPilotSuppressNested3DSkybox ~= false
naval.SkyboxPilotCursorYaw = naval.SkyboxPilotCursorYaw or 52
naval.SkyboxPilotCursorPitch = naval.SkyboxPilotCursorPitch or 34
naval.SkyboxPilotTargetLockCone = naval.SkyboxPilotTargetLockCone or 20
naval.SkyboxPilotTargetCycleRange = naval.SkyboxPilotTargetCycleRange or 7000
naval.SkyboxPilotDamageIndicatorDuration = naval.SkyboxPilotDamageIndicatorDuration or 2.2
naval.SkyboxPilotControlHintsDuration = naval.SkyboxPilotControlHintsDuration or 14
-- Remote fighter communications, contact orders and faction reactions.
naval.SkyboxPilotCommsRange = naval.SkyboxPilotCommsRange or 8500
naval.SkyboxPilotOrderCooldown = naval.SkyboxPilotOrderCooldown or 1.1
naval.SkyboxPilotOrderFormationSpacing = naval.SkyboxPilotOrderFormationSpacing or 2.4
naval.SkyboxPilotOrderedDepartureTime = naval.SkyboxPilotOrderedDepartureTime or 24
naval.SkyboxPilotCivilianDefenseChance = naval.SkyboxPilotCivilianDefenseChance or 0.35
naval.SkyboxPilotFriendlyFireHitThreshold = naval.SkyboxPilotFriendlyFireHitThreshold or 3
naval.SkyboxPilotFriendlyFireDamageThreshold = naval.SkyboxPilotFriendlyFireDamageThreshold or 0.12
naval.SkyboxPilotWingOrderCooldown = naval.SkyboxPilotWingOrderCooldown or 1.2
naval.SkyboxPilotCriticalHullFraction = naval.SkyboxPilotCriticalHullFraction or 0.12
naval.SkyboxPilotProfiles = naval.SkyboxPilotProfiles or {
	default = {
		label = "STARFIGHTER", maximumSpeed = 195, cruiseThrottle = 0.58,
		boostMultiplier = 1.18, accelerate = 82, brake = 118, airBrake = 225,
		jerk = 190, steering = 54, bank = 15, manualBank = 42, bankRate = 82,
		turnThrottle = 0.72, lowSpeedControl = 0.42, highSpeedControl = 0.88,
		weaponDamage = 26, fireInterval = 0.16, weaponRange = 4200,
		weaponCone = 7, lockCone = 20, projectileSpeed = 1450, weaponConvergence = 1800,
		weaponHeatPerShot = 0.075, weaponHeatCoolRate = 0.24,
		weaponHeatResume = 0.55, muzzleSeparation = 0.34, muzzleForward = 0.48,
		cameraDistance = 1, cameraHeight = 1, optimalTurnMin = 0.36, optimalTurnMax = 0.78,
		boostDrain = 0.24, boostRecharge = 0.16, missileDamage = 110, missileRange = 6000,
		missileCooldown = 6, missileAmmo = 4, missileFlightTime = 1.15, subsystemDamage = 0.055,
	},
	red = {
		label = "ARC-170", maximumSpeed = 182, cruiseThrottle = 0.62,
		boostMultiplier = 1.17, accelerate = 70, brake = 105, airBrake = 205,
		jerk = 165, steering = 43, bank = 12, manualBank = 36, bankRate = 68,
		turnThrottle = 0.76, lowSpeedControl = 0.48, highSpeedControl = 0.92,
		weaponDamage = 34, fireInterval = 0.19, weaponRange = 4600,
		weaponCone = 6.5, lockCone = 18, projectileSpeed = 1500, weaponConvergence = 2100,
		weaponHeatPerShot = 0.085, weaponHeatCoolRate = 0.21,
		weaponHeatResume = 0.5, muzzleSeparation = 0.42, muzzleForward = 0.52,
		cameraDistance = 1.12, cameraHeight = 1.08, optimalTurnMin = 0.42, optimalTurnMax = 0.76,
		boostDrain = 0.2, boostRecharge = 0.17, missileDamage = 145, missileRange = 6500,
		missileCooldown = 7, missileAmmo = 6, missileFlightTime = 1.25, subsystemDamage = 0.065,
	},
	blue = {
		label = "V-WING", maximumSpeed = 228, cruiseThrottle = 0.55,
		boostMultiplier = 1.23, accelerate = 108, brake = 148, airBrake = 285,
		jerk = 240, steering = 72, bank = 19, manualBank = 58, bankRate = 112,
		turnThrottle = 0.66, lowSpeedControl = 0.34, highSpeedControl = 0.78,
		weaponDamage = 23, fireInterval = 0.125, weaponRange = 3900,
		weaponCone = 8.5, lockCone = 24, projectileSpeed = 1650, weaponConvergence = 1650,
		weaponHeatPerShot = 0.062, weaponHeatCoolRate = 0.29,
		weaponHeatResume = 0.58, muzzleSeparation = 0.3, muzzleForward = 0.5,
		cameraDistance = 0.92, cameraHeight = 0.92, optimalTurnMin = 0.34, optimalTurnMax = 0.84,
		boostDrain = 0.29, boostRecharge = 0.19, missileDamage = 95, missileRange = 5600,
		missileCooldown = 5.2, missileAmmo = 4, missileFlightTime = 0.95, subsystemDamage = 0.05,
	},
	gold = {
		label = "LAAT/i", maximumSpeed = 145, cruiseThrottle = 0.64,
		boostMultiplier = 1.12, accelerate = 52, brake = 86, airBrake = 170,
		jerk = 130, steering = 31, bank = 8, manualBank = 26, bankRate = 48,
		turnThrottle = 0.82, lowSpeedControl = 0.62, highSpeedControl = 0.96,
		weaponDamage = 42, fireInterval = 0.24, weaponRange = 3600,
		weaponCone = 6, lockCone = 18, projectileSpeed = 1300, weaponConvergence = 1500,
		weaponHeatPerShot = 0.105, weaponHeatCoolRate = 0.18,
		weaponHeatResume = 0.48, muzzleSeparation = 0.5, muzzleForward = 0.44,
		cameraDistance = 1.24, cameraHeight = 1.18, optimalTurnMin = 0.45, optimalTurnMax = 0.7,
		boostDrain = 0.18, boostRecharge = 0.14, missileDamage = 180, missileRange = 5200,
		missileCooldown = 8.5, missileAmmo = 2, missileFlightTime = 1.4, subsystemDamage = 0.075,
	},
}
-- Minimum time between craft entering the same physical flight route. The
-- server also calculates a longer interval when a full-size model needs more
-- room to accelerate clear of the following craft.
naval.SquadronLaunchSpacing = naval.SquadronLaunchSpacing or 2.75
naval.SquadronRecoverySpacing = naval.SquadronRecoverySpacing or 3
naval.SquadronMapMinimumSeparation = naval.SquadronMapMinimumSeparation or 720
naval.SquadronMapHullSpacingMultiplier = naval.SquadronMapHullSpacingMultiplier or 1.55
naval.SquadronMapHullClearance = naval.SquadronMapHullClearance or 180
naval.SquadronMapSpacingBuffer = naval.SquadronMapSpacingBuffer or 0.35
naval.SquadronMapMaximumRouteSpacing = naval.SquadronMapMaximumRouteSpacing or 7
naval.SquadronFormationSpacing = naval.SquadronFormationSpacing or 145
naval.SquadronCombatFormationSpacing = naval.SquadronCombatFormationSpacing or 160
naval.SquadronEscortFormationSpacing = naval.SquadronEscortFormationSpacing or 175
naval.SquadronShadowFormationSpacing = naval.SquadronShadowFormationSpacing or 270
naval.SquadronMapFlightSpeed = naval.SquadronMapFlightSpeed or 520
naval.SquadronMapFlightAcceleration = naval.SquadronMapFlightAcceleration or 260
naval.SquadronMapFlightTurnRate = naval.SquadronMapFlightTurnRate or 2.6
-- HangarDoorOpenDelay is a minimum. Launches additionally wait until every
-- linked door has stopped moving for HangarDoorOpenSettleTime.
naval.HangarDoorOpenDelay = naval.HangarDoorOpenDelay or 3
naval.HangarDoorOpenSettleTime = naval.HangarDoorOpenSettleTime or 0.8
naval.HangarDoorOpenPollInterval = naval.HangarDoorOpenPollInterval or 0.1
naval.HangarDoorMotionPositionEpsilon = naval.HangarDoorMotionPositionEpsilon or 0.2
naval.HangarDoorMotionAngleEpsilon = naval.HangarDoorMotionAngleEpsilon or 0.15
naval.HangarDoorCloseDelay = naval.HangarDoorCloseDelay or 1.5
naval.HangarDoorSafetyPadding = naval.HangarDoorSafetyPadding or 72
naval.HangarDoorSafetyRetry = naval.HangarDoorSafetyRetry or 1
naval.HangarDoorOperationTimeout = naval.HangarDoorOperationTimeout or 18

naval.SquadronMissionDefinitions = naval.SquadronMissionDefinitions or {
	ready_five = { label = "READY FIVE" },
	cap = { label = "COMBAT AIR PATROL" },
	patrol = { label = "SYSTEM PATROL" },
	close_escort = { label = "CLOSE FLEET ESCORT" },
	escort = { label = "ESCORT CONTACT", target = true },
	intercept = { label = "INTERCEPT CONTACT", target = true },
	attack = { label = "ATTACK CONTACT", target = true },
	defend = { label = "DEFEND CONTACT", target = true },
	screen = { label = "FLEET SCREEN" },
	disable = { label = "DISABLE CONTACT", target = true },
	recon = { label = "RECONNAISSANCE" },
	shadow = { label = "SHADOW CONTACT", target = true },
	search_rescue = { label = "SEARCH AND RESCUE" },
	blockade = { label = "BLOCKADE SUPPORT" },
	convoy = { label = "CONVOY ESCORT", target = true },
	boarding_cover = { label = "BOARDING COVER", target = true },
	recall = { label = "RETURN TO HANGAR" },
}
naval.SquadronROE = naval.SquadronROE or {
	weapons_hold = { label = "WEAPONS HOLD" },
	return_fire = { label = "RETURN FIRE ONLY" },
	confirmed_hostiles = { label = "CONFIRMED HOSTILES" },
	restricted_zone = { label = "ENFORCE RESTRICTED AREA" },
	avoid_capitals = { label = "AVOID CAPITAL SHIPS" },
}
naval.SquadronFormations = naval.SquadronFormations or {
	vee = { label = "V FORMATION" },
	line = { label = "LINE ABREAST" },
	column = { label = "TRAIL COLUMN" },
	echelon_left = { label = "LEFT ECHELON" },
	echelon_right = { label = "RIGHT ECHELON" },
	diamond = { label = "DIAMOND" },
	screen = { label = "WIDE SCREEN" },
}
naval.SquadronMaintenanceSecondsPerDamage = naval.SquadronMaintenanceSecondsPerDamage or 2
naval.SquadronMaintenanceMinimum = naval.SquadronMaintenanceMinimum or 12
naval.SquadronOrderCost = naval.SquadronOrderCost or {
	ready_five = {},
	cap = { fuel = 55, munitions = 20, supplies = 10 },
	patrol = { fuel = 45, supplies = 8 },
	close_escort = { fuel = 45, supplies = 8 },
	intercept = { fuel = 70, munitions = 55, supplies = 12 },
	escort = { fuel = 55, supplies = 10 },
	attack = { fuel = 75, munitions = 70, supplies = 14 },
	defend = { fuel = 65, munitions = 45, supplies = 12 },
	screen = { fuel = 60, munitions = 40, supplies = 10 },
	disable = { fuel = 70, munitions = 45, supplies = 14 },
	recon = { fuel = 35, supplies = 6 },
	shadow = { fuel = 42, supplies = 7 },
	search_rescue = { fuel = 50, medical = 20, supplies = 15 },
	blockade = { fuel = 65, munitions = 35, supplies = 12 },
	convoy = { fuel = 58, munitions = 30, supplies = 12 },
	boarding_cover = { fuel = 70, munitions = 55, supplies = 15 },
	rescue = { fuel = 50, medical = 20, supplies = 15 },
	recall = {},
}

naval.DamageEscalationInterval = naval.DamageEscalationInterval or 90
naval.DamageRepairCost = naval.DamageRepairCost or 30
naval.EWDrainInterval = naval.EWDrainInterval or 60
naval.RescueLifetime = naval.RescueLifetime or 900
