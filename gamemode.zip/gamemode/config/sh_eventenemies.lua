--[[
	Playable event enemies.

	Event staff can OFFER players the chance to play as an enemy for an event
	(a droid, a raider, a hostile trooper...). Players who accept respawn as
	that class with a set number of lives, then revert to their normal unit
	when the lives run out or staff ends the event.

	  /eventenemy <class>            offer to everyone (they get a Yes/No popup)
	  /eventenemy <class> <player>   offer to one player
	  /eventenemyend                 revert every event enemy now
	  /eventenemyspawn               set the enemy respawn point to your spot

	Server owners: edit the classes below to use your own models and weapons.
	The defaults use stock HL2 content so it works out of the box.
]]

-- Default lives if a class doesn't set its own.
MilBase.Config.EventEnemyLives = 3

-- How long (seconds) an invite popup stays open before auto-declining.
MilBase.Config.EventEnemyOfferTime = 25

-- Short grace period after spawning at a pod/invisible spawn. It ends early
-- when the enemy moves or attacks.
MilBase.Config.EventEnemySpawnProtection = 5

-- Visual used by both staff-created and Galaxy raid drill pods. Individual
-- callers may still override this per pod.
MilBase.Config.EventEnemyDrillPodModel = "models/summe/drochclass/pod.mdl"

-- Event enemies can hold RELOAD while cuffed to break free.
MilBase.Config.EventEnemyCuffEscapeTime = 4
MilBase.Config.EventEnemyCuffEscapeCooldown = 8

-- NPCs ignore event enemies by default. Individual classes may override this
-- with `noTarget = false` in their definition or through the staff editor.
MilBase.Config.EventEnemyNoTarget = true

-- Fallen friendly soldiers can be stripped for temporary armor. The corpse is
-- consumed once and the stolen protection disappears when the enemy role ends.
MilBase.Config.EventEnemyArmorStealEnabled = true
MilBase.Config.EventEnemyArmorStealPerCorpse = 35
MilBase.Config.EventEnemyArmorStealMax = 200

-- Full movement lock while cuffed/dragged.
MilBase.Config.CuffedMovementLock = true

--------------------------------------------------------------------------
-- Voice modulator (optional)
--------------------------------------------------------------------------
-- Layers radio/droid vocoder sounds around an event enemy's voice chat:
-- an on-click when they key up, an optional static bed under their speech
-- and an off-click when they release - like a B1's comlink chatter.
--
-- Give a class `voice = "<profile id>"` to use one. Optional on both ends:
--   speakers  - /voicefx toggles their own modulator
--   listeners - console setting mb_enemy_voicefx 0 hides the effect
--
-- Note: GMod Lua can't pitch-shift the mic stream itself, so droid profiles
-- fake it with chirpy pitched-up clicks. If you have a droid content pack,
-- point start/stop/loop at its real comlink sounds for the full effect.
--
-- `dsp` (experimental): an engine DSP preset applied to incoming voice
-- (the dsp_voice cvar) while this enemy transmits - this distorts the real
-- voice, not just the overlay. 0 = off. It affects every voice you're
-- hearing at that moment, so keep it for distinctive enemies. To find a
-- preset you like: voice_loopback 1, then dsp_voice <number> in console
-- and talk; put the winner here.
MilBase.Config.EventEnemyVoiceFX = true

MilBase.EventEnemyVoiceProfiles = {
	-- Squad comlink: flat radio squelch (stock HL2 sounds).
	comlink = {
		name = "Comlink",
		start = { "npc/combine_soldier/vo/on1.wav", "npc/combine_soldier/vo/on2.wav" },
		stop = { "npc/combine_soldier/vo/off1.wav", "npc/combine_soldier/vo/off2.wav" },
		loop = "",          -- optional looping static bed played under speech
		loopVolume = 0.3,   -- 0-1, ducked with the speaker's live voice level
		pitch = { 95, 105 },
		volume = 0.55,
		dsp = 0,            -- engine voice DSP preset while transmitting (0 = off)
	},
	-- Battle droid: the same clicks pitched way up for that chirpy B1 feel.
	droid = {
		name = "Battle Droid",
		start = { "npc/combine_soldier/vo/on1.wav", "npc/combine_soldier/vo/on2.wav" },
		stop = { "npc/combine_soldier/vo/off1.wav", "npc/combine_soldier/vo/off2.wav" },
		loop = "",
		loopVolume = 0.25,
		pitch = { 150, 175 },
		volume = 0.6,
		dsp = 0,
	},
}

--------------------------------------------------------------------------
-- Classes
--------------------------------------------------------------------------
-- Fields: name, models (string or list), health, armor, weapons, speed, lives,
-- voice (profile id), certifications (temporary cert ids), gear (temporary
-- inventory items as item_id = amount), noTarget, jammer and stealArmor.

MilBase.RegisterEventEnemy("b1", {
	name = "CGI B1 Battle Droid",
	models = {
		"models/aussiwozzi/cgi/b1droids/b1_battledroid_pm.mdl",
		"models/aussiwozzi/cgi/b1droids/b1_battledroid_security_pm.mdl",
	},
	health = 180,
	armor = 25,
	weapons = { "arccw_cgi_k_e5", "arccw_cgi_k_e5c" },
	speed = 215,
	lives = 3,
	voice = "droid",
	noTarget = true,
	jammer = false,
	stealArmor = false,
	certifications = {},
	gear = {},
})

MilBase.RegisterEventEnemy("b2", {
	name = "CGI B2 Super Battle Droid",
	models = {
		"models/aussiwozzi/cgi/b1droids/b2_battledroid_pm.mdl",
		"models/aussiwozzi/cgi/b1droids/b2_battledroid_camo_pm.mdl",
	},
	health = 650,
	armor = 150,
	weapons = { "arccw_k_b2hand" },
	speed = 180,
	lives = 2,
	voice = "droid",
	noTarget = true,
	jammer = false,
	stealArmor = false,
	certifications = {},
	gear = {},
})

MilBase.RegisterEventEnemy("raider", {
	name = "Raider",
	models = {
		"models/player/combine_soldier.mdl",
		"models/player/combine_soldier_prisonguard.mdl",
	},
	health = 100,
	armor = 25,
	weapons = { "weapon_smg1", "weapon_frag" },
	speed = 220,
	lives = 5,
	voice = "comlink",
	noTarget = true,
	jammer = true,
	stealArmor = true,
	certifications = {},
	gear = {},
})

MilBase.RegisterEventEnemy("heavy", {
	name = "Heavy Raider",
	models = { "models/player/combine_super_soldier.mdl" },
	health = 250,
	armor = 100,
	weapons = { "weapon_ar2" },
	speed = 180,
	lives = 3,
	noTarget = true,
	jammer = true,
	stealArmor = true,
	certifications = {},
	gear = {},
})

MilBase.RegisterEventEnemy("boss", {
	name = "Elite Commander (Boss)",
	models = { "models/player/combine_super_soldier.mdl" },
	health = 1200,
	armor = 200,
	weapons = { "weapon_ar2", "weapon_frag" },
	speed = 200,
	lives = 1,
	noTarget = true,
	jammer = true,
	stealArmor = true,
	certifications = {},
	gear = {},
})
