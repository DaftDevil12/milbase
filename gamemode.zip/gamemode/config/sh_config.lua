--[[
	MilBase settings.
	Everything here is safe to change - this file (and sh_factions.lua)
	are the only files you need to edit to configure your server.
]]

local cfg = MilBase.Config

-- The faction new players spawn into (must match an id in sh_factions.lua).
cfg.DefaultFaction = "Cadets"

-- Movement
cfg.WalkSpeed = 160
cfg.RunSpeed = 260

-- Combat / realism
cfg.RespawnTime = 8              -- seconds before a dead player may respawn
cfg.RealisticFallDamage = true   -- HL2DM-style scaled fall damage instead of flat 10

-- Voice & chat ranges (source units; ~52 units = 1 meter). 0 = unlimited.
cfg.VoiceRange = 550             -- proximity voice chat
cfg.TalkRange = 300              -- normal in-character chat
cfg.WhisperRange = 90            -- /w
cfg.YellRange = 600              -- /y
cfg.OOCEnabled = true            -- allow /ooc and // global out-of-character chat

-- Stamina
cfg.StaminaEnabled = true
cfg.StaminaDrain = 10            -- per second while sprinting
cfg.StaminaRegen = 14            -- per second while not sprinting

-- Economy
cfg.CurrencySymbol = "₡"
cfg.CurrencyName = "credits"
cfg.StartingMoney = 100
cfg.SalaryInterval = 300         -- seconds between paychecks (see rank salaries)

-- Every player always spawns with these (faction/rank loadouts are added on top).
cfg.DefaultLoadout = { "mvp_perfecthands" }

-- How many spare magazines players get for each loadout weapon.
cfg.SpareMagazines = 3

-- If true, only admins can use the spawn menu, toolgun, and noclip.
cfg.SandboxAdminOnly = true

-- Workshop content packs players auto-download (fonts, UI art, sounds).
-- 3565959952 = Kraken's Scripts Main Content (Bebas Neue/D-DIN fonts, the
-- BF2-style menu art, faction emblems, UI sounds the interface uses).
-- The F4 menu's Battlefront-II art is bundled inside the gamemode itself
-- (content/materials/astolfo/ui/, sent to clients from init.lua) - no extra
-- workshop addon required for it.
-- After publishing your own MilBase content addon (see addons/milbase_content),
-- add its workshop ID here too.
cfg.WorkshopContent = {
	"3565959952",
}

--------------------------------------------------------------------------
-- Milsim realism
--------------------------------------------------------------------------

-- Wounded system: lethal hits down you instead of killing you. Teammates
-- hold E on you to stabilize before you bleed out. See modules/sh_medical.lua.
cfg.MedicalEnabled = true
cfg.BleedoutTime = 60            -- seconds before a wounded soldier dies
cfg.ReviveTime = 8               -- seconds holding E to stabilize someone
cfg.MedicReviveTime = 4          -- faster revive for medics (rank/faction with medic = true)
cfg.ReviveHealth = 40            -- health after being stabilized
cfg.LimpHealth = 30              -- at or below this HP you limp (reduced speed)

-- Weapon handling
cfg.DropWeaponOnDeath = false     -- your weapon hits the ground when you go down

-- Squads
cfg.SquadsEnabled = true
cfg.SquadMaxMembers = 6
cfg.SquadPingsEnabled = cfg.SquadPingsEnabled ~= false
cfg.SquadPingCooldown = cfg.SquadPingCooldown or 0.65
cfg.SquadPingLifetime = cfg.SquadPingLifetime or 8
cfg.SquadPingHostileLifetime = cfg.SquadPingHostileLifetime or 10
cfg.SquadPingMaximumRange = cfg.SquadPingMaximumRange or 18000
cfg.SquadPingMaximumActive = cfg.SquadPingMaximumActive or 8
cfg.SquadPingHoldTime = cfg.SquadPingHoldTime or 0.2

-- Inventory (Tarkov-style grid; see config/sh_items.lua for the items)
cfg.InventoryWidth = 10          -- stash grid cells
cfg.InventoryHeight = 6

-- Weapon carry slots (EFT style): two primaries + one secondary.
-- Melee, grenades and tools are exempt automatically (no magazine).
cfg.PrimarySlots = 2
cfg.SecondarySlots = 1
cfg.SecondaryWeapons = {         -- classes that count as sidearms
	weapon_pistol = true,
	weapon_357 = true,
}
cfg.SlotExemptWeapons = {        -- never count against a slot
	weapon_fists = true,
	weapon_physgun = true,
	gmod_tool = true,
	gmod_camera = true,
	weapon_medkit = true,
	weapon_stunstick = true,
	weapon_crowbar = true,
}
cfg.StarterItems = {             -- given once, on a player's first ever join
	bandage = 1,
	mre = 1,
}

--------------------------------------------------------------------------
-- Spawn Selector (modules/sh_spawnselector.lua + Toolgun stool)
--
-- Staff place persistent spawn points with:
--   Toolgun -> Star Wars RP -> Spawn Selector
--
-- Access rules are set directly in the Toolgun panel. Faction/job names or
-- ids, rank index ranges, rank groups and specs/certs can all unlock spawns.
-- Players open /spawns to choose any point they currently qualify for.
--------------------------------------------------------------------------
cfg.SpawnSelectorEnabled = true
cfg.SpawnSelectorStaffLevel = 3          -- staff level allowed to place/edit/remove spawns
cfg.SpawnSelectorShowLocked = false      -- false hides restricted spawns from players entirely
cfg.SpawnSelectorOpenOnJoin = true       -- send joining players to spawn selection
cfg.SpawnSelectorOpenOnDeath = true      -- send dead players to spawn selection once respawn time has passed
cfg.SpawnSelectorRequireChoiceBeforeSpawn = true -- players do not deploy until they pick an eligible spawn
cfg.SpawnSelectorPreviewEnabled = true   -- allowed spawn points expose a client camera preview
cfg.SpawnSelectorDefaultZoneSize = 192    -- side length of each spawn square in Hammer units
cfg.SpawnSelectorMaxZoneSize = 1024       -- max side length staff can set in the Toolgun
cfg.SpawnSelectorSpawnAttempts = 28       -- random safe-position attempts inside the selected square
cfg.SpawnSelectorSpawnPadding = 32        -- extra spacing around other players when picking a spot
cfg.SpawnSelectorAutoOpenIfNoChoice = true
cfg.SpawnSelectorOpenOnSpawnNoChoice = false -- legacy fallback; require-choice flow handles this automatically


--------------------------------------------------------------------------
-- Quartermaster NPCs (modules/sh_quartermaster.lua + mb_quartermaster)
--
-- Staff place persistent NPCs with:
--   /quartermaster add       place one where you are aiming
--   /quartermaster remove    remove the nearest one
--   /quartermaster reload    respawn saved quartermasters for this map
--
-- Players press E on the NPC to retrieve their basic gear. The module builds
-- the issue list from faction + rank group + certifications, so a 104th
-- officer with Field Medic receives the 104th Medic Officer armor.
--------------------------------------------------------------------------
cfg.QuartermasterEnabled = true
cfg.QuartermasterStaffLevel = 3
cfg.QuartermasterNPCModel = "models/player/clone cadet/clonecadet.mdl"
cfg.QuartermasterNPCFallbackModel = "models/Humans/Group03/male_07.mdl"
cfg.QuartermasterUseRange = 150
cfg.QuartermasterCooldown = 5
cfg.QuartermasterGiveWeapons = true       -- re-issue missing faction/rank/cert weapons
cfg.QuartermasterGiveAmmo = false         -- false prevents unlimited ammo farming
cfg.QuartermasterIncludeIssue = true      -- include existing faction/rank/cert `issue` tables
cfg.QuartermasterRemoveOldGear = true     -- remove/trim old Quartermaster basic gear before issuing
cfg.QuartermasterRemoveOldArmor = true    -- remove any armor not authorized by current faction/rank/certs
cfg.QuartermasterPreventArmorDrops = true  -- prevents farming armor by dropping it before resupplying
cfg.QuartermasterCleanupOnSpawn = true    -- cleans old armor after faction/rank/cert changes trigger a respawn
cfg.QuartermasterCleanupOnRoleChange = true -- immediate cleanup when faction/rank/cert data changes
cfg.QuartermasterNotifyCleanupOnSpawn = false -- set true if players should see cleanup notices on spawn
cfg.QuartermasterArmorObjectiveEnabled = true -- personal objective when current role/certs authorize new armor
cfg.QuartermasterArmorObjectiveTitle = "Obtain new armor"
cfg.QuartermasterArmorObjectiveType = "rally"
cfg.QuartermasterArmorObjectiveExcludedFactions = {
	Cadets = true,
	["Republic Fleet"] = true,
	republic_fleet = true,
}
cfg.QuartermasterArmorObjectiveExcludedRanks = {
	Cadet = true,
}

-- Items every soldier can ask the Quartermaster to top up to.
cfg.QuartermasterDefaultItems = {
	helmet_trooper = 1,
	backpack_field = 1,
	mre = 1,
}

-- Rank group detection. You can override an individual rank by adding
-- quartermasterGroup = "officer" to that rank in sh_factions.lua.
cfg.QuartermasterRankGroups = {
	commander = { "marshal", "senior commander", "commander", "admiral", "commodore" },
	officer = { "officer", "lieutenant", "captain", "major", "ensign", "colonel" },
	nco = { "sergeant", "corporal", "petty officer", "chief" },
}

-- Certs that affect which armor variant is selected. Field Medic maps to
-- the "medic" armor role; officer/commander medics use medic_officer armor
-- when the faction has one.
cfg.QuartermasterCertArmorRoles = {
	field_medic = "medic",
}

-- Per-faction Quartermaster rules. armorPrefix auto-builds item ids such as:
--   armor_104th_trp, armor_104th_nco, armor_104th_officer,
--   armor_104th_commander, armor_104th_medic, armor_104th_medic_officer
-- You can override any generated id with an `armor = { ... }` table.
cfg.QuartermasterFactionLoadouts = {
	["Cadets"] = {
		armor = { trp = "armor_trooper", nco = "armor_trooper", officer = "armor_trooper", commander = "armor_trooper" },
		baseItems = { bandage = 1 },
	},
	["Unassigned Clone Troopers"] = {
		armor = { trp = "armor_trooper", nco = "armor_trooper", officer = "armor_trooper", commander = "armor_trooper" },
		baseItems = { bandage = 1, ammo_pistol = 1 },
	},
	["501st Legion"] = {
		armorPrefix = "501st",
		baseItems = { bandage = 2, ammo_pistol = 1 },
	},
	["104th"] = {
		armorPrefix = "104th",
		baseItems = { bandage = 2, ammo_pistol = 1 },
	},
	["41st"] = {
		armorPrefix = "41st",
		baseItems = { bandage = 2, ammo_pistol = 1 },
	},
	["cg"] = {
		armorPrefix = "cg",
		baseItems = { bandage = 2, ammo_pistol = 1 },
	},
	["212th"] = {
		armorPrefix = "212th",
		baseItems = { bandage = 2, ammo_pistol = 1 },
	},
}

-- Extra Quartermaster items by rank group and certification. These are top-up
-- targets, not one-time grants, so repeated use will not duplicate the same gear.
cfg.QuartermasterRankItems = {
	nco = { ifak = 1 },
	officer = { ifak = 1 },
	commander = { ifak = 1 },
}

cfg.QuartermasterCertItems = {
	field_medic = { bandage = 4, splint = 1, ifak = 1, medkit = 1, surgical_kit = 1 },
	engineer = { repair_kit = 1, fuel_can = 1 },
	saboteur = { det_charge = 2 },
	forward_observer = {},
}

-- Progression: star cards (config/sh_starcards.lua) & crates (config/sh_crates.lua)
cfg.StarCardSlots = 3            -- how many star cards a soldier can equip at once

-- Tarkov-style injuries (see modules/sh_medical.lua)
cfg.ReviveRequiresMedical = true -- stabilizing a wounded soldier consumes one of the reviver's bandages
cfg.BleedChance = 0.35           -- chance a solid bullet/blade hit causes bleeding
cfg.BleedDamageThreshold = 12    -- minimum damage to roll for bleeding
cfg.BleedInterval = 2            -- seconds per 1 HP lost while bleeding
cfg.FractureChance = 0.3         -- chance on leg hits (doubled for hard falls)
cfg.PainkillerDuration = 120     -- seconds of pain suppression per dose

-- EFT-style limb health (see the MEDICAL tab in the F4 menu).
-- Destroyed ("blacked") limbs: legs = limp, arms = weapon sway,
-- stomach = slow stamina regen. Only a surgical kit restores them.
cfg.LimbHealth = {
	head      = 35,
	thorax    = 85,
	stomach   = 70,
	left_arm  = 60,
	right_arm = 60,
	left_leg  = 65,
	right_leg = 65,
}
cfg.BlackedDamageScale = 1.2     -- hits to destroyed limbs hurt this much more
cfg.SurgeryRestoreFraction = 0.3 -- surgery restores a limb to this fraction of max

-- Engineering incidents: hull breach & terminal spots placed with /engspot
-- (admin) randomly malfunction. Breaches are welded shut (LVS repair torch
-- or engineers holding E); terminals are fixed with a timing minigame.
cfg.EngIncidentInterval = 0    -- seconds between random malfunctions (0 = never)
cfg.EngRepairReward = 40         -- credits for sealing a breach / fixing a terminal

-- Ship-system consoles (see modules/sh_shipsystems.lua). Assign each to a
-- system:  /engspot shipnode <starmap|engines|maneuver|hyperspace>
-- (omit the system and it binds to the nearest Star Wars Universe terminal).
-- You can place SEVERAL consoles per system for redundancy. Destroy consoles
-- (weapons or a saboteur's charge) and the system degrades by how many are
-- down (alive / total):
--   ALL down  -> system fully offline (no map / dead in space / can't turn /
--                can't jump)
--   SOME down -> engines lose top speed, turning slows, hyperspace jumps take
--                longer; the star map stays up while any console survives
-- Engineers repair a console (hold E -> a system-specific minigame).
-- Inert (no effect) if the Star Wars Universe addon isn't installed.
cfg.ShipSystemsEnabled = true
cfg.ShipNodeHealth = 150         -- damage a console soaks before it fails
cfg.ShipNodeBindRadius = 140     -- how close a console binds to an SWU terminal
cfg.ShipNodeModel = "models/props_lab/monitor01b.mdl"

-- Hackable SECURITY consoles (see modules/sh_shipsabotage.lua). Place with
-- /engspot hackconsole. A saboteur presses E -> slice minigame to HACK it,
-- which softly knocks engines AND hyperdrive fully offline at once. An
-- engineer presses E -> types a recovery code to restore both. No physical
-- damage - fast to break, fast to fix.
cfg.HackConsolesEnabled = true
cfg.HackConsoleModel = "models/props_lab/servers.mdl"

-- Physical ENGINE / HYPERDRIVE parts (see modules/sh_shipsabotage.lua). Place
-- with /engspot shippart <engines|hyperspace>. Destroyed ONLY by a saboteur's
-- planted charge (immune to gunfire). A destroyed part is repaired in three
-- in-world stages: WELD the seam (repair tool) -> RE-WIRE -> FIX CIRCUITS.
-- Several parts per system: the system only goes fully offline once all its
-- parts are destroyed (partial = degraded, same fraction model as consoles).
cfg.ShipPartModels = {
	engines    = "models/props_combine/combine_generator01.mdl",
	hyperspace = "models/props_combine/combine_interface001.mdl",
}
cfg.ShipPartModel = "models/props_combine/combine_generator01.mdl" -- fallback

-- Gravity / zero-gravity (see modules/sh_zerog.lua). Every map has normal
-- gravity by default. On a space/ship map an admin opens /gravity, DISABLES
-- gravity for that map, then SAVEs it (persists per map). Once disabled the
-- whole map is weightless EXCEPT inside GRAVITY ZONES traced with the toolgun
-- (MilBase -> Gravity Zones): paint the ship interior as gravity boxes; the
-- void outside floats. Weightless players drift; Magnetic Boots (an item,
-- toggled in the self-menu with hold G) let them walk normally. Only staff
-- holding the tool see the zone boxes.
cfg.ZeroGEnabled = true        -- master switch for the whole gravity system
cfg.ZeroGDefaultHeight = 512   -- default gravity-box height (tool slider default)
cfg.ZeroGGravity = 0           -- gravity outside zones on a zero-g map (0 = full float)

-- Appearance / bodygroup editor (see modules/sh_appearance.lua). Players
-- customise their model's bodygroups + skin in the F4 APPEARANCE tab. Staff
-- lock individual bodygroups behind a rank or equipment IN-GAME via the
-- MODEL RULES tab (no config needed). Equipped armor still wins its own slots.
cfg.AppearanceEnabled = true

-- Disease / bio-warfare (modules/sh_disease.lua + sh_biolab.lua). Event staff
-- author viruses in-game (F4 BIO-LAB tab / /virus) and infect players
-- (/infect <id> while aiming). Medics sample the infected, analyze at an
-- mb_analyzer, then cure individually or flush a cure through the vents.
cfg.DiseaseEnabled = true
cfg.HallucinationModel = "models/b1_droid.mdl" -- what infected players see others as (needs the model mounted)
cfg.DiseaseSpreadInterval = 3       -- seconds between contagion rolls per infected
cfg.DiseaseComponentsPerAnalysis = 1 -- virus components revealed per sample analyzed
cfg.VentCureRange = 0               -- cure-canister flush radius (0 = shipwide)

-- Moderation suite (modules/sh_staffmode.lua, sh_reports.lua, sh_logs.lua).
-- /staffmode  - cloak + god + notarget + noclip + physgun, with wallhack ESP;
--               toggling back restores your RP character exactly.
-- @ <text>             - players alert staff; staff see popups top-left
--                        (hold C to click CLAIM / DISMISS).
-- /sit, /sitadd, /endsit, /sitspot add|remove - admin sits: participants are
--               teleported to a sit area, can't deal or take damage, and are
--               returned to where they were when the sit ends.
-- LOGS F4 tab (staff) - combat / connections / chat / commands / economy /
--               staff actions, persisted in SQLite.
cfg.StaffModeLevel = 1         -- min staff level for /staffmode + ESP
cfg.StaffGiveItemLevel = 3     -- min staff level for the GIVE ITEMS staff tab
cfg.FactionEditorLevel = 4     -- min staff level for the FACTIONS creator/editor
cfg.CertificationEditorLevel = 4 -- min staff level for the CERT EDITOR
cfg.CrateEditorLevel = 4       -- min staff level for the CRATE EDITOR
cfg.StarCardEditorLevel = 4    -- min staff level for the STAR CARD EDITOR
cfg.ArmorEditorLevel = 4       -- min staff level for the ARMOR EDITOR
cfg.ArmorMaximum = 255         -- maximum armor points equipment profiles may grant

-- Multiple independent roleplay lives. Slot 1 keeps the historical SteamID64
-- database key, so existing characters migrate without a conversion script.
cfg.CharacterSlots = 2
cfg.CharacterSwitchCooldown = 30 -- seconds between successful switches
cfg.CharacterCombatLock = 30     -- cannot switch this many seconds after damage
cfg.CharacterSwitchRequiresAlive = true
cfg.CharacterMenuOpenOnJoin = true
cfg.CharacterRequireSelectionBeforeDeploy = true -- join flow is CHARACTER -> DEPLOYMENT
cfg.ReportPrefix = "@"          -- type this at the start of chat to alert staff
cfg.ReportCooldown = 30        -- seconds between staff alerts per player
cfg.StaffReminderEnabled = true
cfg.StaffReminderInterval = 30 * 60 -- seconds (30 minutes)
cfg.StaffReminderText = "If you need assistance or need to make a report contact our staff team with @ [MESSAGE] and we will be happy to assist"
cfg.LogRetention = 20000   -- max log rows kept (oldest pruned), only used when LogWipeOnBoot is false
 
-- The log table can grow huge on a busy server to the point SQL browsers
-- (HeidiSQL etc.) choke trying to open it. These fully wipe frontier_logs
-- instead of just pruning old rows. Both can be on at once.
cfg.LogWipeOnBoot = true          -- wipe all logs every time the server restarts
cfg.LogAutoWipeEnabled = true      -- also wipe on a recurring timer while running
cfg.LogAutoWipeInterval = 21600    -- seconds between auto-wipes (21600 = 6 hours)

-- MUSIC F4 tab (see modules/sh_music.lua). Staff at/above this level get a
-- MUSIC tab that plays a YouTube link (or any direct audio URL - mp3/ogg/aac
-- stream) to everyone. Players keep a personal volume/mute slider in the tab.
cfg.MusicStaffLevel = 1
-- YouTube needs a real web origin to play in-game, so the tab loads a small
-- hosted wrapper page (the same trick the Media Player addon uses). Leave blank
-- to use the public default; set this to your own host (must end in "/") if you
-- self-host youtube.html. Direct mp3/stream URLs don't use this.
cfg.MusicHTMLBaseURL = ""
-- YouTube embeds can play ads and give NO signal when an ad ends, so ads can't
-- be skipped. As a fallback you can keep a YouTube track muted for this many
-- seconds at the start to ride through a typical pre-roll ad (0 = off). Caveat:
-- this also mutes the first seconds of ad-free tracks and won't catch mid-roll
-- ads - for guaranteed ad-free audio, use a direct mp3/stream URL instead.
cfg.MusicYouTubeAdMute = 0
cfg.MusicPresets = {       -- optional one-click tracks in the MUSIC tab
	-- { title = "Imperial March", url = "https://www.youtube.com/watch?v=-bzWSJG93P8" },
	-- { title = "Ambient Base Radio", url = "https://example.com/stream.mp3" },
}
-- LVS vehicle subsystems (see modules/sh_vehsystems.lua). Combat damage
-- can knock out Shields / Engines / Weapons; engineers repair each one
-- with a Repair Kit. Disabled engines can't start, disabled weapons can't
-- fire, disabled shields collapse - so pilots need their engineers.
cfg.VehicleSubsystemsEnabled = true
cfg.SubsystemDamageThreshold = 20  -- min hit damage to roll subsystem damage
cfg.SubsystemDamageChance = 0.20   -- chance per qualifying hit to knock a system
cfg.SubsystemRepairPerUse = 50     -- condition (0-100) restored per repair-kit use

-- LVS hacking (see modules/sh_hacking.lua). A player carrying a Slicer Kit
-- can crouch+E on an ALLOWED, unoccupied LVS vehicle and beat a slice
-- minigame to commandeer it: enables its AI and flips it to their team.
cfg.HackAllVehicles = false        -- true = every LVS vehicle is hackable
cfg.HackableVehicleClasses = {     -- otherwise, only these classes:
	["lvs_starfighter_droidtrifighter"] = true,
    ["lvs_starfighter_vulturedroid"]      = true,
}
cfg.HackedVehicleTeam = 1          -- AI team a hacked ship joins if the slicer has none
cfg.HackCooldown = 20              -- seconds between hacks per player

-- MilBase cockpit HUD while driving/riding LVS vehicles (hull, shields,
-- subsystem status, speed, altitude, fuel). Complements the LVS crosshair.
cfg.LVSHudEnabled = true

-- Sabotage (see modules/sh_sabotage.lua). Saboteurs (saboteur cert) see a
-- ship's weak points (the hull-breach spots), plant Detonation Charges on
-- them (aim + E), and blow them from the self-menu (hold G) - opening hull
-- breaches for the enemy engineers to seal.
cfg.SabotagePlantRange = 100     -- how close to a weak point you must be to plant
cfg.SabotageBlastDamage = 120    -- explosion damage per charge
cfg.SabotageBlastRadius = 260
cfg.MaxChargesPerPlayer = 4      -- planted charges a saboteur can have out at once

-- Atmosphere: an ACTIVE hull breach vents the area around it. Unprotected
-- soldiers suffocate; engineers can /sealsuit to breathe from their tank.
cfg.BreachVacuumRadius = 550     -- venting radius around an active breach (0 = off)
cfg.SuitOxygenTime = 300         -- seconds of air in a sealed suit's tank
cfg.LungAirTime = 25             -- seconds an unsealed soldier lasts in vacuum
cfg.SuffocationDamage = 15       -- HP per second once out of air


--------------------------------------------------------------------------
-- Automatic Star Wars RP naming (modules/sh_naming.lua)
--
-- Display format is:
--   FACTION RANK [MEDIC] NUMBER PERSONALNAME
-- Example:
--   501st PVT JM 0989 Bob
--
-- Players still set only their personal name with /name Bob. The four-digit
-- clone number is generated once and saved permanently in frontier_name_data.
--------------------------------------------------------------------------
cfg.NamingEnabled = true
cfg.NamingPendingNumber = "0000"
cfg.NamingManageStaffLevel = 4       -- can manually set clone numbers
cfg.NamingMedicRankStaffLevel = 3    -- staff level that can set medic title ranks
cfg.NamingMedicDefaultRank = "junior_medic"
cfg.NamingShowMedicRankWithoutCert = false

-- Certs that count as medical for the name. Cert definitions with medic=true
-- also count automatically, so Field Medic works out of the box.
cfg.NamingMedicCerts = {
	field_medic = true,
}

-- Medic title ranks shown between the rank and clone number.
cfg.NamingMedicRanks = {
	junior_medic = { name = "Junior Medic", short = "JM", order = 1 },
	medic = { name = "Medic", short = "M", order = 2 },
	senior_medic = { name = "Senior Medic", short = "SM", order = 3 },
	chief_medic = { name = "Medical Officer", short = "MO", order = 4 },
	director_medic = { name = "Medical Director", short = "MD", order = 5 },
}

-- Short faction/job names. Keys can be faction ids or faction display names.
cfg.NamingFactionShort = {
	["Cadets"] = "CDT",
	["Unassigned Clone Troopers"] = "CT",
	["501st Legion"] = "501st",
	["501st"] = "501st",
	["212th Attack Battalion"] = "212th",
	["212th"] = "212th",
	["41st Recon Forces"] = "41st",
	["41st"] = "41st",
	["104th Wolfpack Battalion"] = "104th",
	["104th"] = "104th",
	["Coruscant Guard"] = "CG",
	["cg"] = "CG",
	["Republic Navy"] = "NAVY",
	["Republic Fleet"] = "RF",
}

-- Short rank names. You can also put short="PVT" directly on any rank in
-- config/sh_factions.lua to override one specific faction's rank.
cfg.NamingRankShort = {
	["Cadet"] = "CDT",
	["Private"] = "PVT",
	["Private First Class"] = "PFC",
	["Lance Corporal"] = "LCPL",
	["Corporal"] = "CPL",
	["Sergeant"] = "SGT",
	["Staff Sergeant"] = "SSG",
	["Master Sergeant"] = "MSG",
	["Sergeant Major"] = "SGM",
	["Second Lieutenant"] = "2LT",
	["Lieutenant"] = "LT",
	["Captain"] = "CPT",
	["Major"] = "MAJ",
	["Commander"] = "CMD",
	["Senior Commander"] = "SCMD",
	["Marshal Commander"] = "MCMD",
	["Crewman Recruit"] = "CMR",
	["Crewman"] = "CMN",
	["Senior Crewman"] = "SCMN",
	["Petty Officer"] = "PO",
	["Chief Petty Officer"] = "CPO",
	["Senior Chief Petty Officer"] = "SCPO",
	["Master Chief Petty Officer"] = "MCPO",
	["Ensign"] = "ENS",
	["Lieutenant Commander"] = "LCDR",
	["Commodore"] = "CDRE",
	["Rear Admiral"] = "RADM",
	["Vice Admiral"] = "VADM",
	["Admiral"] = "ADM",
}

-- Immersion
cfg.CompassEnabled = true        -- bearing compass at the top of the screen
cfg.HideKillfeed = true          -- milsim: no kill confirmations
cfg.DisableKillCommand = true      -- blocks the console kill/suicide command
cfg.HideCrosshair = false        -- set true for hardcore servers
cfg.JumpStaminaCost = 20          -- stamina spent per jump

-- Keycards / keypads (see modules/sh_keycards.lua). Define tiers and assign
-- which rank of which regiment is issued which tier on the F4 "KEYCARDS" tab
-- (admin). Place keypads and link them to doors with the "Keypads / Keycards"
-- toolgun tool, then SAVE them there (persisted per map).
cfg.KeycardsEnabled = true       -- issue the keycard weapon on spawn to cleared ranks
cfg.KeypadHoldTime = 4           -- seconds a keypad holds its linked door open
cfg.KeypadModel = "models/kingpommes/starwars/misc/misc_panel_1.mdl" -- standalone surface reader model; converted buttons keep their own model
cfg.KeypadModelYawOffset = -90    -- rotate standalone reader model so it faces out from the wall
cfg.KeypadModelSurfaceOffset = 2.5 -- distance standalone reader sits off the surface
cfg.KeypadButtonSearchRadius = 96 -- left-click near a button to convert the nearest one
cfg.KeycardModel = ""            -- in-hand world model ("" = nothing visible)
-- Keypad interaction (billy-style extras):
-- PIN pads: set a keypad's mode (Card / PIN / Both) + PIN with the tool panel.
-- Destruction: shoot a keypad to break it -> it breaches (force-opens) its door;
--   an Engineer (repair kit) USEs the broken keypad to fix it.
-- Cracking: a Saboteur crouch+USEs a keypad to bypass it (force-opens once).
cfg.KeypadHealth = 200           -- keypad HP (0 = indestructible)
cfg.KeypadBreachOnBreak = true   -- a destroyed keypad forces its linked door open
cfg.KeypadCrackTime = 8          -- seconds for a saboteur to crack a keypad
cfg.KeypadRepairTime = 6         -- seconds for an engineer to repair a broken keypad

-- Database. By default MilBase stores everything in GMod's built-in SQLite
-- (garrysmod/sv.db) - no setup needed. To store in your MySQL / MariaDB server
-- instead (the one you manage with HeidiSQL):
--   1. Install the MySQLOO binary module (gmsv_mysqloo_*.dll in
--      garrysmod/lua/bin/) - see the MilBase console message for the link.
--   2. Create an empty database/schema in HeidiSQL (e.g. "milbase").
--   3. Set Enabled = true and fill in the details below, then restart.
-- If MySQL can't connect, MilBase automatically falls back to SQLite so the
-- server always runs.
cfg.Database = {
	Enabled = true,
	Host = "109.228.47.43",
	Port = 3306,
	User = "u27_VvPvVKcPeD",
	Pass = "X0rkYoYtQa!0=HArpBlrQi!6",             -- your MySQL user's password
	Name = "s27_frontier",      -- the database (schema) name you created in HeidiSQL
}

--------------------------------------------------------------------------
-- Jail / Arrest / Criminal Records system (modules/sh_jail.lua)
--------------------------------------------------------------------------
cfg.JailEnabled = true
cfg.JailPoliceFactions = { cg = true, ["Coruscant Guard"] = true, ["Republic Navy"] = true }
cfg.JailTerminalUseRange = 170          -- officer must be this close to use an arrest/records terminal
cfg.JailArrestTargetRange = 220         -- cuffed target must be this close to the arrest terminal
cfg.JailSetupStaffLevel = 4             -- Toolgun placement access for jail cells/terminals
cfg.JailCrimeOwnerLevel = 7             -- Owner-only crime definition tab
cfg.JailMaxSentence = 7200              -- cap total arrest time in seconds
cfg.JailCellLeashRadius = 900           -- jailed players far from their assigned cell are returned
cfg.JailThinkInterval = 1.5
cfg.JailRecordsSearchLimit = 60
cfg.JailArrestTerminalModel = "models/lordtrilobite/starwars/isd/imp_console_large01.mdl"
cfg.JailRecordsTerminalModel = "models/props_lab/monitor02.mdl"
cfg.JailTerminalFallbackModel = "models/lordtrilobite/starwars/isd/imp_console_large01.mdl"

-- Seeded only when the crime table is empty. Owners can edit/delete these in the CRIMES staff tab.
-- Seeded only when the crime table is empty. Owners can edit/delete these in the CRIMES staff tab.
cfg.JailDefaultCrimes = {
	-- 100 - Public Order
	{ code = "RLC-101", name = "Disorderly Conduct", charge = "Causing avoidable disruption, shouting, fighting gestures, or refusing to stop disruptive behaviour.", time = 300, fine = 100 },
	{ code = "RLC-102", name = "Harassment", charge = "Repeated unwanted conduct, intimidation, or targeted verbal abuse after being told to stop.", time = 300, fine = 100 },
	{ code = "RLC-103", name = "Threatening Behaviour", charge = "Making a credible threat of harm without immediately carrying it out.", time = 600, fine = 250 },
	{ code = "RLC-104", name = "Fighting", charge = "Participating in an unauthorized physical fight where no deadly weapon is used.", time = 600, fine = 250 },
	{ code = "RLC-105", name = "Failure to Identify", charge = "Refusing to provide a valid name, rank, or identification when lawfully required.", time = 300, fine = 100 },
	{ code = "RLC-106", name = "Obstruction of a Public or Military Route", charge = "Blocking doors, corridors, hangars, checkpoints, or emergency routes without authorization.", time = 300, fine = 100 },
	{ code = "RLC-107", name = "False Emergency Report", charge = "Knowingly reporting a fake attack, bomb, breach, medical emergency, or other crisis.", time = 600, fine = 250 },

	-- 200 - Military Discipline
	{ code = "RLC-201", name = "Failure to Follow a Lawful Order", charge = "Ignoring or refusing a lawful instruction from authorized personnel.", time = 300, fine = 100 },
	{ code = "RLC-202", name = "Insubordination", charge = "Openly defying, challenging, or obstructing a lawful superior order.", time = 600, fine = 250 },
	{ code = "RLC-203", name = "Disrespect to Command or Fleet", charge = "Serious abusive or degrading conduct toward authorized command or Fleet personnel.", time = 300, fine = 100 },
	{ code = "RLC-204", name = "Dereliction of Duty", charge = "Failing to perform an assigned duty without reasonable cause.", time = 600, fine = 250 },
	{ code = "RLC-205", name = "Abandoning a Battle Station", charge = "Leaving an assigned DEFCON or combat station without permission.", time = 600, fine = 250 },
	{ code = "RLC-206", name = "Desertion", charge = "Intentionally abandoning service, a combat operation, or an assigned unit during a serious threat.", time = 900, fine = 500 },
	{ code = "RLC-207", name = "DEFCON Noncompliance", charge = "Ignoring a DEFCON instruction, battle-station order, lockdown, or evacuation command.", time = 600, fine = 250 },
	{ code = "RLC-208", name = "Conduct Unbecoming", charge = "Serious unprofessional conduct that damages discipline or public trust but is not covered elsewhere.", time = 300, fine = 100 },

	-- 300 - Security & Restricted Areas
	{ code = "RLC-301", name = "Unauthorized Restricted-Area Access", charge = "Entering the Bridge, AIC, Command Centre, Brig, or another restricted area without clearance.", time = 600, fine = 250 },
	{ code = "RLC-302", name = "Checkpoint Evasion", charge = "Bypassing, fleeing, deceiving, or forcing passage through an authorized checkpoint.", time = 600, fine = 250 },
	{ code = "RLC-303", name = "False Identification", charge = "Presenting false credentials, rank, clearance, or identity information.", time = 600, fine = 250 },
	{ code = "RLC-304", name = "Impersonation", charge = "Pretending to be Fleet, High Command, CG, Republic Intelligence, or another protected authority.", time = 900, fine = 500 },
	{ code = "RLC-305", name = "Access-Control Tampering", charge = "Damaging, hacking, disabling, or bypassing a security door, terminal, scanner, or checkpoint system without authorization.", time = 900, fine = 500 },
	{ code = "RLC-306", name = "Unauthorized Data Access", charge = "Accessing classified, command, personnel, or operational information without clearance.", time = 900, fine = 500 },
	{ code = "RLC-307", name = "Unauthorized Information Disclosure", charge = "Sharing classified or restricted information with unauthorized personnel.", time = 900, fine = 500 },
	{ code = "RLC-308", name = "Possession of Unauthorized Access Equipment", charge = "Holding stolen keycards, access codes, security tools, or similar restricted items without authority.", time = 600, fine = 250 },

	-- 400 - Violence & Threats
	{ code = "RLC-401", name = "Assault", charge = "Intentionally striking or injuring another person without a deadly weapon.", time = 600, fine = 250 },
	{ code = "RLC-402", name = "Aggravated Assault", charge = "Causing serious injury, attacking a restrained person, or assaulting with exceptional violence.", time = 900, fine = 500 },
	{ code = "RLC-403", name = "Assault with a Deadly Weapon", charge = "Using or attempting to use a firearm, blade, explosive, vehicle, or other lethal weapon against a person.", time = 1200, fine = 500 },
	{ code = "RLC-404", name = "Attempted Murder", charge = "Taking a clear, deliberate action intended to kill another person.", time = 1500, fine = 1000 },
	{ code = "RLC-405", name = "Murder", charge = "Unlawfully and intentionally killing another person.", time = 1800, fine = 1000 },
	{ code = "RLC-406", name = "Kidnapping", charge = "Unlawfully moving, holding, or concealing another person against their will.", time = 1200, fine = 500 },
	{ code = "RLC-407", name = "Hostage-Taking", charge = "Holding a person to force a demand, exchange, withdrawal, or political outcome.", time = 1800, fine = 1000 },
	{ code = "RLC-408", name = "Reckless Endangerment", charge = "Creating a serious and avoidable risk of injury through reckless conduct.", time = 600, fine = 250 },
	{ code = "RLC-409", name = "Armed Threat", charge = "Brandishing or aiming a weapon to threaten or control another person without lawful authority.", time = 900, fine = 500 },

	-- 500 - Property, Vehicles & Equipment
	{ code = "RLC-501", name = "Theft of Republic or Personal Property", charge = "Taking property, supplies, credits, or equipment without permission.", time = 600, fine = 250 },
	{ code = "RLC-502", name = "Vehicle Theft", charge = "Taking, operating, or attempting to steal a Republic vehicle without authorization.", time = 900, fine = 500 },
	{ code = "RLC-503", name = "Destruction of Property", charge = "Intentionally or recklessly damaging Republic or personal property.", time = 600, fine = 250 },
	{ code = "RLC-504", name = "Unauthorized Vehicle Use", charge = "Operating a vehicle without required role, clearance, or Officer on Duty approval.", time = 600, fine = 250 },
	{ code = "RLC-505", name = "Unauthorized Specialist Equipment", charge = "Possessing or using restricted weapons, armor, tools, or company equipment without qualification.", time = 600, fine = 250 },
	{ code = "RLC-506", name = "Equipment Tampering", charge = "Altering, disabling, sabotaging, or interfering with equipment without authority, where the act does not meet high-crime sabotage.", time = 600, fine = 250 },
	{ code = "RLC-507", name = "Possession of Contraband", charge = "Possessing prohibited items, enemy equipment, unauthorized explosives, or unlawfully obtained access items.", time = 600, fine = 250 },

	-- 600 - Weapons & Explosives
	{ code = "RLC-601", name = "Unsafe Weapon Discharge", charge = "Firing a weapon without a lawful target, safe lane, or operational reason.", time = 600, fine = 250 },
	{ code = "RLC-602", name = "Unlawful Brandishing", charge = "Displaying or handling a weapon in a threatening or unsafe manner without lawful reason.", time = 300, fine = 100 },
	{ code = "RLC-603", name = "Unauthorized Explosive Possession", charge = "Possessing bombs, mines, charges, rockets, or restricted ordnance without authorization.", time = 900, fine = 500 },
	{ code = "RLC-604", name = "Explosive Misuse", charge = "Deploying or detonating explosives without authorization, against an improper target, or in a prohibited key area.", time = 1500, fine = 1000 },
	{ code = "RLC-605", name = "Specialist-Weapon Misuse", charge = "Using heavy, anti-armor, EOD, breaching, or company-restricted weapons outside their approved purpose.", time = 600, fine = 250 },
	{ code = "RLC-606", name = "Weapon Use in a Restricted Area", charge = "Discharging a weapon in the AIC, Brig, Command Centre, Bridge, or another protected area without immediate necessity.", time = 900, fine = 500 },
	{ code = "RLC-607", name = "Failure to Secure a Weapon", charge = "Leaving a weapon, explosive, or restricted item unattended or accessible to unauthorized personnel.", time = 300, fine = 100 },

	-- 700 - Custody, Investigations & Justice
	{ code = "RLC-701", name = "Resisting Arrest", charge = "Physically resisting, fleeing, or defeating a lawful arrest after being informed of detention.", time = 600, fine = 250 },
	{ code = "RLC-702", name = "Obstruction of Justice", charge = "Intentionally interfering with an arrest, investigation, checkpoint, search, or lawful CG operation.", time = 600, fine = 250 },
	{ code = "RLC-703", name = "Aiding an Escape", charge = "Helping a detainee or prisoner avoid, leave, or defeat lawful custody.", time = 900, fine = 500 },
	{ code = "RLC-704", name = "Escape from Custody", charge = "Leaving or attempting to leave lawful detention, transport, interrogation, or Brig confinement.", time = 900, fine = 500 },
	{ code = "RLC-705", name = "Assaulting Law Enforcement", charge = "Assaulting CG or authorized security personnel during an arrest, search, transport, or checkpoint action.", time = 900, fine = 500 },
	{ code = "RLC-706", name = "Interfering with an Investigation", charge = "Destroying leads, intimidating witnesses, refusing lawful evidence preservation, or deliberately misleading investigators.", time = 600, fine = 250 },
	{ code = "RLC-707", name = "Evidence Tampering", charge = "Destroying, hiding, planting, changing, or contaminating evidence.", time = 900, fine = 500 },
	{ code = "RLC-708", name = "False Statement or Report", charge = "Knowingly giving materially false information in an official complaint, investigation, or testimony.", time = 600, fine = 250 },
	{ code = "RLC-709", name = "Prisoner Abuse", charge = "Using unnecessary force, humiliation, denial of care, or unauthorized punishment against a detainee.", time = 900, fine = 500 },

	-- 800 - High Crimes
	{ code = "RLC-801", name = "Sabotage", charge = "Intentionally damaging or disabling critical Republic systems, vehicles, defenses, or operations to cause major harm.", time = 1800, fine = 1000 },
	{ code = "RLC-802", name = "Espionage", charge = "Collecting, stealing, or transmitting protected Republic information for an enemy or unauthorized power.", time = 1800, fine = 1000 },
	{ code = "RLC-803", name = "Sedition", charge = "Organizing or encouraging unlawful resistance against legitimate Republic command.", time = 1200, fine = 500 },
	{ code = "RLC-804", name = "Treason", charge = "Knowingly betraying the Republic, serving an enemy, or attempting to overthrow lawful Republic command.", time = 1800, fine = 1000 },
	{ code = "RLC-805", name = "Aiding the Enemy", charge = "Providing information, equipment, access, shelter, or operational assistance to hostile forces.", time = 1800, fine = 1000 },
	{ code = "RLC-806", name = "Terrorism", charge = "Using or threatening mass violence to intimidate, coerce, or destabilize Republic personnel or civilians.", time = 1800, fine = 1000 },
	{ code = "RLC-807", name = "Bomb Threat or Active Bomb Offence", charge = "Placing, activating, controlling, or knowingly making a credible threat involving an explosive device.", time = 1500, fine = 1000 },
	{ code = "RLC-808", name = "Mutiny or Unlawful Seizure of Command", charge = "Organizing or participating in the unlawful removal, detention, or replacement of legitimate command.", time = 1800, fine = 1000 },
}

-- Unified RP Datapad -------------------------------------------------------
-- One SWEP (mb_datapad) for records, CCTV, medical RP, incidents, warrants,
-- and owner-managed access control. Locked apps are hidden unless the player
-- has a Slicer Kit and the app allows slicing.
cfg.DatapadEnabled = true
cfg.DatapadWeaponClass = "mb_datapad"
cfg.DatapadOwnerLevel = 7
cfg.DatapadSearchLimit = 60
cfg.DatapadCheckupRange = 160
cfg.DatapadSliceUnlockSeconds = 300
cfg.DatapadMaxWarrantMinutes = 10080
cfg.DatapadWindowWidth = 960
cfg.DatapadWindowHeight = 660
cfg.DatapadSidebarWidth = 220
cfg.DatapadMaxScreenWidth = 0.75
cfg.DatapadMaxScreenHeight = 0.82

-- Persistent server-wide DEFCON system (modules/sh_defcon.lua).
-- DEFCON 5 is normal readiness; DEFCON 1 is the highest alert state.
cfg.DefconEnabled = true
cfg.DefconDefaultLevel = 5
cfg.DefconHUDEnabled = true
cfg.DefconHUDAliveOnly = true
cfg.DefconHUDPosition = "top_left" -- "top_left" or "top_right"
cfg.DefconHUDWidth = 250
cfg.DefconHistoryLimit = 20
cfg.DefconChangeStaffLevel = 3      -- staff at/above this level may change it
cfg.DefconAllowSuperAdmin = true
cfg.DefconCommandMinRankIndex = 8  -- Navy Ensign and above in the default config
cfg.DefconCommandFactions = { Navy = true, ["Republic Navy"] = true }
cfg.DefconLevels = {
	[5] = { name = "Normal Operations", description = "Routine duties and standard security posture.", color = Color(110, 205, 135) },
	[4] = { name = "Heightened Readiness", description = "Increased patrols and readiness for possible hostilities.", color = Color(225, 205, 80) },
	[3] = { name = "Battle Stations", description = "Personnel report to combat stations and prepare for engagement.", color = Color(255, 155, 65) },
	[2] = { name = "Base Lockdown", description = "Critical areas secured; all personnel follow emergency orders.", color = Color(225, 85, 70) },
	[1] = { name = "Maximum Alert", description = "Immediate threat. Full combat readiness and command authority in effect.", color = Color(190, 45, 50) },
}

-- ArcCW-compatible MilBase weapon HUD (core/cl_hud.lua).
cfg.ArcCWHUDEnabled = true
cfg.ArcCWHUDShowFiremode = true
cfg.ArcCWHUDShowAmmoType = true
cfg.ArcCWHUDShowHeat = true
cfg.ArcCWHUDShowUnderbarrel = true
-- Management-only global ArcCW weapon tuning (modules/sh_arccw_weapon_editor.lua).
-- Level 6 is the default Management rank; Owners at level 7 also have access.
cfg.ArcCWWeaponEditorStaffLevel = cfg.ArcCWWeaponEditorStaffLevel or 6

-- Persistent daily quest / duty-order system (modules/sh_dailyquests.lua).
-- Every player receives a deterministic set of personal orders each reset.
cfg.DailyQuestsEnabled = true
cfg.DailyQuestCount = 3
cfg.DailyQuestResetHourUTC = 0
cfg.DailyQuestStaffLevel = 4
cfg.DailyQuestHUDTracker = true
cfg.DailyQuestF4TabEnabled = true -- Daily Orders live in the F4 menu instead of the datapad
cfg.DailyQuestHUDMaxRows = 3
cfg.DailyQuestProgressSaveSeconds = 15
cfg.DailyQuestPlaytimeTickSeconds = 60
cfg.DailyQuestCountFriendlyNPCKills = false
cfg.DailyQuestCountSelfSpawnedNPCKills = false
cfg.DailyQuestDefinitions = {
	{
		id = "active_duty", group = "duty", event = "play_minutes", name = "Active Duty",
		description = "Remain on active duty and assist the garrison.", target_min = 25, target_max = 40,
		reward_xp = 180, reward_credits = 300, color = Color(100, 185, 235),
	},
	{
		id = "extended_watch", group = "duty", event = "play_minutes", name = "Extended Watch",
		description = "Maintain an extended active-duty watch.", target_min = 45, target_max = 60,
		reward_xp = 260, reward_credits = 425, color = Color(90, 170, 225),
	},
	{
		id = "hostile_suppression", group = "combat", event = "combat_kills", name = "Hostile Suppression",
		description = "Eliminate hostile NPCs or authorised event enemies.", target_min = 15, target_max = 30,
		reward_xp = 225, reward_credits = 375, color = Color(225, 95, 75),
	},
	{
		id = "combat_sweep", group = "combat", event = "combat_kills", name = "Combat Sweep",
		description = "Clear a larger hostile force from the operation area.", target_min = 30, target_max = 45,
		reward_xp = 325, reward_credits = 525, color = Color(210, 75, 65),
	},
	{
		id = "mission_objectives", group = "objectives", event = "objectives", name = "Mission Objectives",
		description = "Complete event objectives assigned to your unit.", target_min = 2, target_max = 4,
		reward_xp = 260, reward_credits = 425, color = Color(255, 198, 60),
	},
	{
		id = "rapid_response", group = "objectives", event = "objectives", name = "Rapid Response",
		description = "Complete priority event objectives assigned to your unit.", target_min = 1, target_max = 2,
		reward_xp = 175, reward_credits = 300, color = Color(245, 185, 55),
	},
	{
		id = "field_medicine", group = "specialist", event = "heal_points", name = "Field Medicine",
		description = "Restore health or stabilise other personnel.", target_min = 150, target_max = 300,
		reward_xp = 275, reward_credits = 450, cert = "field_medic", color = Color(105, 215, 145),
	},
	{
		id = "combat_engineering", group = "specialist", event = "repair_points", name = "Combat Engineering",
		description = "Repair damaged vehicle hulls or subsystems.", target_min = 150, target_max = 300,
		reward_xp = 275, reward_credits = 450, cert = "engineer", color = Color(125, 190, 235),
	},
}

-- Optional fallback lists. Factions with `police = true` or `medic = true`
-- automatically pass these sections too.
cfg.DatapadSecurityFactions = cfg.DatapadSecurityFactions or cfg.JailPoliceFactions or {
	["Coruscant Guard"] = true,
	["CG"] = true,
}
cfg.DatapadMedicalFactions = cfg.DatapadMedicalFactions or {
	["Medical Corps"] = true,
}

-- Access rules. Owner can override these in-game in the DATAPAD staff tab.
-- Supported keys: owner_only, staff_level, factions={ids/names}, police=true,
-- medic=true, officer=true, inspection=true, cert="id", certs={"any","of","these"},
-- certs_all={"all","required"}, min_rank_index, max_rank_index,
-- rank_group, rank_groups={...}, min_rank_group, roster=true, slice=true.
--
-- Regiment roster rules:
--   Officers can view and manage their own regiment.
--   Navy can inspect every regiment; Navy officers can also manage them.
--   Superadmins retain recovery access if a roster ever needs correcting.
cfg.DatapadRosterNavyFactions = cfg.DatapadRosterNavyFactions or {
	["Navy"] = true,
}
cfg.DatapadRosterNavyEditRequiresOfficer = cfg.DatapadRosterNavyEditRequiresOfficer ~= false
cfg.DatapadRosterMaxResults = math.Clamp(tonumber(cfg.DatapadRosterMaxResults) or 80, 25, 150)
cfg.DatapadRosterStrikeReasonMax = math.Clamp(tonumber(cfg.DatapadRosterStrikeReasonMax) or 240, 32, 512)

cfg.DatapadTabs = cfg.DatapadTabs or {
	home = { name = "Home" },
	defcon = { name = "DEFCON Status" },
	criminal_records = { name = "Criminal Records", police = true, min_rank_group = "trooper", slice = true },
	charge_lookup = { name = "Charge Lookup", police = true, min_rank_group = "trooper", slice = false },
	cctv = { name = "CCTV", police = true, slice = true },
	medical_records = { name = "Medical Records", medic = true, certs = { "field_medic" }, slice = true },
	medical_checkup = { name = "Medical Checkup", medic = true, certs = { "field_medic" }, slice = false },
	personnel = { name = "Personnel File", officer = true, min_rank_group = "officer", slice = true },
	certifications = { name = "Certifications", officer = true, min_rank_group = "officer", slice = false },
	regiment_roster = { name = "Regiment Roster", roster = true, slice = false },
	incidents = { name = "Incident Reports", rank_groups = { "nco", "officer", "commander" }, slice = true },
	customs_cases = { name = "Customs Cases", inspection = true, slice = false },
	warrants = { name = "Warrants / BOLOs", police = true, min_rank_group = "nco", slice = true },
	admin_config = { name = "Access Control", owner_only = true },
}

-- Player collision guard
-- Keeps normal live players solid while still allowing intentional ghost states
-- such as staff mode, event mode, deployment selection, and LAAT infil.
-- Player collision recovery. Keeps normal faction players solid while preserving
-- intentional ghost states like staff/event mode and spawn selection.
cfg.PlayerCollisionFix = true
cfg.PlayerCollisionFixInterval = 0.5
cfg.PlayerCollisionForceTeammateCollide = true
cfg.PlayerCollisionDebug = false
