--[[
	MilBase zero-gravity rescue tether configuration.

	The tether is intentionally a rescue tool rather than a physics gun. It can
	only acquire drifting players by default, applies capped spring forces, and
	breaks when the cable is obstructed or stretched beyond its safe length.
]]

local cfg = MilBase.Config

cfg.RescueTether = cfg.RescueTether or {
	Enabled = true,
	WeaponClass = "weapon_mb_rescue_tether",
	WeaponName = "Zero-G Rescue Tether",
	ViewModel = "models/kraken/cgi/v_cgi_dc17revolver.mdl",
	WorldModel = "models/kraken/cgi/world/w_cgi_dc17revolver.mdl",
	HoldType = "pistol",

	-- Target acquisition and cable limits.
	AcquireRange = 1800,
	AcquireHull = 12,
	RequireTargetZeroG = true,
	AllowJuggernautTargets = false,
	AllowVehicleTargets = false,
	AllowMultipleTethers = false,
	MaximumCableLength = 2200,
	BreakDistance = 2600,
	BlockedBreakDelay = 1.5,
	FireCooldown = 0.35,

	-- Reeling and spring physics. These are velocity changes, not teleports.
	MinimumReelLength = 72,
	ReelSpeed = 285,
	PullAcceleration = 920,
	MaximumPullSpeed = 610,
	StretchSpeedScale = 2.25,
	UnanchoredOperatorReaction = 0.62,
	CloseRangeDamping = 0.32,
	SecureDistance = 92,
	ThinkInterval = 0.05,

	-- A second cable can anchor the operator to a world/static surface. This
	-- stops the rescuer being pulled into space while recovering a casualty.
	AllowWorldAnchor = true,
	AnchorRange = 1500,
	AnchorSlack = 260,
	AnchorBreakDistance = 2300,
	AnchorPullAcceleration = 1100,
	AnchorMaximumPullSpeed = 520,

	-- Self-reeling is deliberately restricted to the map's zero-G state.
	-- In normal gravity the anchor may stabilise a rescue line, but it can't add velocity to the operator or function as a grapple hook.
	AllowSelfReel = true,
	RequireOperatorZeroGForAnchorPull = true,
	SelfReelSpeed = 360,
	MinimumSelfReelLength = 64,

	-- Safety and anti-abuse.
	TargetEscapeHoldTime = 1.1,
	SafeFallWindow = 1.4,
	ReleaseWhenHolstered = true,
	HighlightAttachedTarget = true,
	LogActions = true,
}
