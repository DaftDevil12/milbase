--[[
	Certification definitions - edit freely, like sh_factions.lua.

	Certs are granted in game by officers/admins with:
	  /certify <player> <cert id>       /decertify <player> <cert id>

	Fields: name, desc, health (+max HP), loadout (weapons), issue (items,
	resupplied every spawn), medic, medicOthers, medEfficiency, medSpeed,
	factions (optional set/list of faction ids allowed to use the cert).
	Items in sh_items.lua can require a cert with cert = "<id>".
]]

MilBase.RegisterCertification("field_medic", {
	name = "Field Medic",
	icon = "kraken/bf2f4/medic.png",
	desc = "Advanced medical training: treat other soldiers, work faster and more effectively, perform field surgery.",
	medic = true,          -- stabilizes the wounded faster
	medicOthers = true,    -- can use meds on other soldiers
	medEfficiency = 1.5,   -- meds heal 50% more
	medSpeed = 0.75,       -- first aid 25% faster
	issue = { bandage = 2, splint = 1, ifak = 1 },
})

MilBase.RegisterCertification("marksman", {
	name = "Marksman",
	icon = "kraken/bf2f4/specialist.png",
	desc = "Designated marksman qualification.",
	loadout = { "weapon_crossbow" },
})

MilBase.RegisterCertification("assault", {
	name = "Assault Trooper",
	icon = "kraken/bf2f4/assault.png",
	desc = "Close-quarters and breaching qualification.",
	health = 15,
	loadout = { "weapon_shotgun" },
	issue = { frag = 1 },
})

MilBase.RegisterCertification("hardened", {
	name = "Hardened",
	icon = "kraken/bf2f4/heavy.png",
	desc = "Veteran conditioning. A tougher constitution.",
	health = 25,
})

MilBase.RegisterCertification("engineer", {
	name = "Combat Engineer",
	icon = "battlegrid/icons/repair.png",
	desc = "Vehicle maintenance training: repair, refuel and rebuild LVS vehicles (crouch + hold E on a vehicle).",
	issue = { repair_kit = 1, fuel_can = 1 },
})

MilBase.RegisterCertification("saboteur", {
	name = "Saboteur",
	desc = "Demolitions training: see a ship's weak points, plant Detonation Charges (aim + E), and blow them from the self-menu (hold G).",
	issue = { det_charge = 2 },
})

MilBase.RegisterCertification("sigint", {
	name = "Signals Intelligence",
	desc = "Comms-warfare training: hold [E] on a fallen Event Enemy to slice its transceiver and tap the encrypted Hostile Net — you hear (and can transmit on) enemy comms until you're killed.",
})

MilBase.RegisterCertification("forward_observer", {
	name = "Forward Observer",
	desc = "Fleet targeting qualification: carries binoculars that transmit grid areas for ordnance support.",
	loadout = { "mb_fo_binoculars" },
})

MilBase.RegisterCertification("fleet_operator", {
	name = "Fleet Fire Control",
	desc = "Bridge crew qualification: can use fleet ordnance consoles to authorize support packages.",
})

MilBase.RegisterCertification("massif_handler", {
	name = "Massif Handler",
	desc = "Coruscant Guard K-9 qualification: deploy, command, search with, track through, and temporarily control a trained Massif.",
	loadout = { "mb_massif_handler" },
	factions = { cg = true },
})
