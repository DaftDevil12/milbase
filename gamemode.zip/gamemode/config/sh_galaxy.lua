--[[
	Galaxy Director configuration.

	This file is shared so the client can build the staff controls and display
	faction/planet information. Keep secrets such as the Discord webhook in
	config/sv_galaxy.lua, which is never sent to clients.

	The system is an adapter around Star Wars Universe. It never edits SWU
	files and also remains usable (with a manually selected location) when SWU
	is missing.
]]

local cfg = MilBase.Config

cfg.GalaxyDirector = cfg.GalaxyDirector or {}
local gd = cfg.GalaxyDirector

-- Permission split:
--   Staff can pause the director and operate/cancel encounters.
--   Management controls planets, strategic simulation and live tuning.
gd.StaffLevel = gd.StaffLevel or 3
gd.ManagementLevel = gd.ManagementLevel or 6

-- Content mounted by the server for the director.
gd.WorkshopContent = gd.WorkshopContent or {
	"2735358488", -- Star Wars Universe
	"2332782456", -- Clone Wars capital ship prop pack (Munificent, Venator...)
	"2832262727", -- KOTOR civilian, pirate and Republic ship variety
}
for _, workshopID in ipairs({ "2735358488", "2332782456", "2832262727" }) do
	local found = false
	for _, existing in ipairs(gd.WorkshopContent) do
		if tostring(existing) == workshopID then found = true break end
	end
	if not found then gd.WorkshopContent[#gd.WorkshopContent + 1] = workshopID end
end

-- Default live settings. Management can tune these from the F2 staff tab;
-- overrides persist in the MilBase database.
gd.RuntimeDefaults = gd.RuntimeDefaults or {
	enabled = true,
	encounters = true,
	attacks = true,
	simulation = true,

	minPlayersEncounter = 2,
	minPlayersAttack = 6,
	afkSeconds = 600,

	encounterMin = 480,
	encounterMax = 900,
	arrivalDelay = 18,
	majorCooldown = 5400,
	ambientMin = 180,
	ambientMax = 360,

	warningDuration = 90,
	assaultDuration = 90,
	breachDuration = 25,
	boardingDuration = 360,
	waveInterval = 48,
	waveSize = 5,
	maxWaves = 6,
	maxNPCs = 36,
	baseIntegrity = 100,

	simulationInterval = 1800,
	cisPressureMin = 6,
	cisPressureMax = 14,
}

-- Metadata used to validate network input and construct the management UI.
-- `toggleLevel` is for the four main switches; numeric tuning is management.
gd.RuntimeFields = gd.RuntimeFields or {
	{ key = "minPlayersEncounter", label = "Minimum players: encounters", min = 0, max = 128, decimals = 0 },
	{ key = "minPlayersAttack", label = "Minimum players: CIS attacks", min = 1, max = 128, decimals = 0 },
	{ key = "afkSeconds", label = "AFK exclusion time (seconds)", min = 60, max = 3600, decimals = 0 },
	{ key = "encounterMin", label = "Encounter interval minimum", min = 60, max = 14400, decimals = 0 },
	{ key = "encounterMax", label = "Encounter interval maximum", min = 60, max = 14400, decimals = 0 },
	{ key = "arrivalDelay", label = "Delay after hyperspace arrival", min = 3, max = 300, decimals = 0 },
	{ key = "majorCooldown", label = "Major attack cooldown", min = 300, max = 86400, decimals = 0 },
	{ key = "ambientMin", label = "Ambient flight minimum", min = 30, max = 7200, decimals = 0 },
	{ key = "ambientMax", label = "Ambient flight maximum", min = 30, max = 7200, decimals = 0 },
	{ key = "warningDuration", label = "Attack warning duration", min = 15, max = 900, decimals = 0 },
	{ key = "assaultDuration", label = "Space assault duration", min = 20, max = 1800, decimals = 0 },
	{ key = "breachDuration", label = "Breach transition duration", min = 5, max = 300, decimals = 0 },
	{ key = "boardingDuration", label = "Boarding holdout duration", min = 60, max = 3600, decimals = 0 },
	{ key = "waveInterval", label = "Boarding wave interval", min = 10, max = 300, decimals = 0 },
	{ key = "waveSize", label = "Base droids per wave", min = 1, max = 24, decimals = 0 },
	{ key = "maxWaves", label = "Maximum boarding waves", min = 1, max = 30, decimals = 0 },
	{ key = "maxNPCs", label = "Maximum live Galaxy NPCs", min = 1, max = 100, decimals = 0 },
	{ key = "baseIntegrity", label = "Starting ship integrity", min = 25, max = 500, decimals = 0 },
	{ key = "simulationInterval", label = "CIS strategy tick interval", min = 300, max = 86400, decimals = 0 },
	{ key = "cisPressureMin", label = "CIS pressure per tick minimum", min = 1, max = 50, decimals = 0 },
	{ key = "cisPressureMax", label = "CIS pressure per tick maximum", min = 1, max = 50, decimals = 0 },
}

gd.LockHyperspaceDuringRaid = gd.LockHyperspaceDuringRaid ~= false
gd.AllowFleeDuringRaid = gd.AllowFleeDuringRaid ~= false
gd.FleePressureIncrease = gd.FleePressureIncrease or 7
gd.SimulateWhileEmpty = gd.SimulateWhileEmpty == true
gd.ArrivalEncounterChance = gd.ArrivalEncounterChance or 0.72
gd.CISContactRaidChance = gd.CISContactRaidChance or 0.8
gd.PirateRetreatChance = gd.PirateRetreatChance or 0.45
gd.RepublicRepairNodes = gd.RepublicRepairNodes or 2
gd.RecentEncounterMemory = gd.RecentEncounterMemory or 4
gd.BoardingPodsPerRaid = gd.BoardingPodsPerRaid or 4
-- Major raids arrive as a small Munificent attack group. Raid spawns use only
-- the models below, even when other CIS capital models are available to the
-- ambient universe and blockade systems.
gd.RaidMunificentMinimum = gd.RaidMunificentMinimum or 2
gd.RaidMunificentMaximum = gd.RaidMunificentMaximum or 4
gd.RaidMunificentPlayersPerExtra = gd.RaidMunificentPlayersPerExtra or 8
gd.RaidMunificentHullBase = gd.RaidMunificentHullBase or 7600
gd.RaidMunificentHullPerPlayer = gd.RaidMunificentHullPerPlayer or 320
gd.RaidMunificentShieldBase = gd.RaidMunificentShieldBase or 5200
gd.RaidMunificentShieldPerPlayer = gd.RaidMunificentShieldPerPlayer or 220
gd.RaidMunificentBearingSpread = gd.RaidMunificentBearingSpread or 14
gd.RaidMunificentMapSpacing = gd.RaidMunificentMapSpacing or 900
gd.RaidMunificentMapAltitudeStep = gd.RaidMunificentMapAltitudeStep or 120
gd.RaidMunificentSkyboxEntrySpacing = gd.RaidMunificentSkyboxEntrySpacing or 900
gd.RaidMunificentSkyboxEntryHeightStep = gd.RaidMunificentSkyboxEntryHeightStep or 150
gd.RaidMunificentIngressStagger = gd.RaidMunificentIngressStagger or 0.65
gd.RaidMunificentModels = gd.RaidMunificentModels or {
	"models/salty/munificent-class.mdl",
}
-- Fighter screen launched by the Munificent group. Skybox actors use the
-- lightweight Galaxy ship entity so large raids do not instantiate full LVS
-- physics in the 3D skybox.
gd.RaidVultureSkyboxEnabled = gd.RaidVultureSkyboxEnabled ~= false
gd.RaidVultureSkyboxModels = gd.RaidVultureSkyboxModels or {
	"models/salza/vulture_droid.mdl",
}
gd.RaidVultureSkyboxMinimum = gd.RaidVultureSkyboxMinimum or 4
gd.RaidVultureSkyboxMaximum = gd.RaidVultureSkyboxMaximum or 12
gd.RaidVulturePlayersPerExtra = gd.RaidVulturePlayersPerExtra or 2
gd.RaidVulturePerMunificent = gd.RaidVulturePerMunificent or 2
gd.RaidVultureTargetRadius = gd.RaidVultureTargetRadius or 13
gd.RaidVultureHull = gd.RaidVultureHull or 280
gd.RaidVultureSpeed = gd.RaidVultureSpeed or 112
gd.RaidVultureDamage = gd.RaidVultureDamage or 18
gd.RaidVultureFireInterval = gd.RaidVultureFireInterval or 0.9
gd.RaidVultureLaunchStagger = gd.RaidVultureLaunchStagger or 0.2

-- Full LVS enemies are spawned in playable map-space during CIS raids so
-- players flying normal LVS craft can intercept them. Record a MAIN hangar
-- launch route for the best automatic approach vector; per-map anchors can be
-- supplied below when a map needs a hand-authored airspace location.
gd.RaidLVSVultureEnabled = gd.RaidLVSVultureEnabled ~= false
gd.RaidLVSVultureClass = gd.RaidLVSVultureClass or "lvs_starfighter_vulturedroid"
gd.RaidLVSVultureMinimum = gd.RaidLVSVultureMinimum or 2
gd.RaidLVSVultureMaximum = gd.RaidLVSVultureMaximum or 8
gd.RaidLVSVulturePlayersPerExtra = gd.RaidLVSVulturePlayersPerExtra or 4
gd.RaidLVSVultureSpawnDistance = gd.RaidLVSVultureSpawnDistance or 3400
gd.RaidLVSVultureSpawnAltitude = gd.RaidLVSVultureSpawnAltitude or 850
gd.RaidLVSVultureSpawnSpacing = gd.RaidLVSVultureSpawnSpacing or 520
gd.RaidLVSVultureSpawnStagger = gd.RaidLVSVultureSpawnStagger or 0.55
gd.RaidLVSVultureSpawnAttempts = gd.RaidLVSVultureSpawnAttempts or 12
gd.RaidLVSFighterAnchors = gd.RaidLVSFighterAnchors or {
	-- ["map_name"] = { pos = Vector(0, 0, 2000), ang = Angle(0, 180, 0) },
}
-- Each raid establishes several independent internal fronts. Player count can
-- add fronts, but the NPC cap remains the final performance safeguard.
gd.RaidBreachZoneMinimum = gd.RaidBreachZoneMinimum or 2
gd.RaidBreachZoneMaximum = gd.RaidBreachZoneMaximum or 4
gd.RaidBreachZonePlayersPerExtra = gd.RaidBreachZonePlayersPerExtra or 8
gd.RaidBreachZoneMinimumSeparation = gd.RaidBreachZoneMinimumSeparation or 650
gd.RaidDroidsPerAdditionalBreach = gd.RaidDroidsPerAdditionalBreach or 2
gd.RaidBreachesToDamage = gd.RaidBreachesToDamage or 4
gd.RaidSystemsToDamage = gd.RaidSystemsToDamage or 2
gd.RaidBreachZoneBlastDamage = gd.RaidBreachZoneBlastDamage or 18
-- Zones without an explicit type alternate between pods and flying
-- dropships. Dedicated boarding_drill / boarding_dropship anchors override
-- this pattern, while boarding_player anchors are reserved for volunteers.
gd.RaidDeploymentPattern = gd.RaidDeploymentPattern or {
	"drill", "dropship",
}
gd.RaidDrillPodModel = gd.RaidDrillPodModel
	or "models/summe/drochclass/pod.mdl"
gd.RaidDropshipModel = gd.RaidDropshipModel or "auto"
gd.RaidDropshipApproachTime = gd.RaidDropshipApproachTime or 7
gd.RaidDropshipHoldTime = gd.RaidDropshipHoldTime or 5
gd.RaidDropshipDepartureTime = gd.RaidDropshipDepartureTime or 7
gd.RaidDropshipApproachDistance = gd.RaidDropshipApproachDistance or 2400
gd.RaidDropshipApproachHeight = gd.RaidDropshipApproachHeight or 900
gd.RaidDropshipHoverHeight = gd.RaidDropshipHoverHeight or 155
gd.RaidDropshipDropRadius = gd.RaidDropshipDropRadius or 135
-- Playable attackers remain opt-in. Enough Republic players are always
-- reserved so volunteering cannot empty the defending side.
gd.RaidPlayableEnemiesEnabled = gd.RaidPlayableEnemiesEnabled ~= false
gd.RaidPlayableEnemiesMinimumPlayers = gd.RaidPlayableEnemiesMinimumPlayers or 12
gd.RaidPlayableEnemiesDefenderReserve = gd.RaidPlayableEnemiesDefenderReserve or 8
gd.RaidPlayableEnemiesMaximum = gd.RaidPlayableEnemiesMaximum or 4
gd.RaidPlayableEnemyOfferMultiplier = gd.RaidPlayableEnemyOfferMultiplier or 2
gd.RaidPlayableEnemyLives = gd.RaidPlayableEnemyLives or 3
gd.RaidPlayableEnemyClasses = gd.RaidPlayableEnemyClasses or {
	"b1", "battle_droid", "b2", "super_battle_droid",
}
gd.AutoNavAnchorMinDistance = gd.AutoNavAnchorMinDistance or 700
gd.AutoNavAnchorMaxDistance = gd.AutoNavAnchorMaxDistance or 6500
gd.CapitalVolleyCooldown = gd.CapitalVolleyCooldown or 45
gd.CapitalVolleyDamage = gd.CapitalVolleyDamage or 2600
gd.CommsTerminalModel = gd.CommsTerminalModel or "models/lordtrilobite/starwars/isd/imp_console_medium02.mdl"
gd.CommsUseDistance = gd.CommsUseDistance or 220
gd.RequireCommsTerminal = gd.RequireCommsTerminal ~= false
gd.CommsPingSound = gd.CommsPingSound or "buttons/blip1.wav"
gd.CommsPingInterval = gd.CommsPingInterval or 5
gd.CommsPingSoundLevel = gd.CommsPingSoundLevel or 72
gd.OutgoingHailCooldown = gd.OutgoingHailCooldown or 8
gd.OutgoingHailResponseDelayMin = gd.OutgoingHailResponseDelayMin or 0.8
gd.OutgoingHailResponseDelayMax = gd.OutgoingHailResponseDelayMax or 2.2
gd.MaximumHailContacts = gd.MaximumHailContacts or 16
gd.CommsHailResponseSound = gd.CommsHailResponseSound or "buttons/button15.wav"
gd.HailResponseChance = gd.HailResponseChance or {
	republic = 0.98,
	civilian = 0.86,
	pirate = 0.65,
	cis = 0.52,
	neutral = 0.7,
}

-- Bridge stations are deliberately separate. Communications handles hails
-- and incoming calls, Tactical Scanner identifies contacts, and Fire Control
-- authorises long-range batteries against scanner-locked skybox hostiles.
gd.ScannerTerminalModel = gd.ScannerTerminalModel or gd.CommsTerminalModel
gd.ScannerUseDistance = gd.ScannerUseDistance or gd.CommsUseDistance
gd.GunnerTerminalModel = gd.GunnerTerminalModel or gd.CommsTerminalModel
gd.GunnerUseDistance = gd.GunnerUseDistance or gd.CommsUseDistance
-- Different ordnance batteries are separate bridge stations.  The original
-- gunner is retained as the turbolaser station for existing maps/dupes.
gd.IonTerminalModel = gd.IonTerminalModel or gd.GunnerTerminalModel
gd.TorpedoTerminalModel = gd.TorpedoTerminalModel or gd.GunnerTerminalModel
gd.IonUseDistance = gd.IonUseDistance or gd.GunnerUseDistance
gd.TorpedoUseDistance = gd.TorpedoUseDistance or gd.GunnerUseDistance

-- Ships curve into a new course instead of instantly sliding sideways when
-- traffic chooses a route or avoids a planet.  If a particular addon model
-- faces the wrong way, add that role's yaw correction here (for example
-- cis_capital = 180) without changing the movement code.
gd.ShipTurnRate = gd.ShipTurnRate or 120
gd.ShipModelFacingYaw = gd.ShipModelFacingYaw or { default = 0 }
-- Movement is deliberately cinematic rather than physics-perfect: a ship
-- accelerates and brakes by class, makes a real turning arc, and banks a
-- little through a manoeuvre. The extra inertia controls prevent ships from
-- sliding sideways or changing thrust instantly when a route turns.
gd.ShipFlightSmoothingEnabled = gd.ShipFlightSmoothingEnabled ~= false
gd.ShipBankingEnabled = gd.ShipBankingEnabled ~= false
gd.ShipTurnThrottleEnabled = gd.ShipTurnThrottleEnabled ~= false
gd.ShipRouteWaypointEnabled = gd.ShipRouteWaypointEnabled ~= false
gd.ShipRouteCurveFraction = gd.ShipRouteCurveFraction or 0.16
gd.ShipRouteLookAhead = gd.ShipRouteLookAhead or 320
gd.ShipFormationPositionGain = gd.ShipFormationPositionGain or 0.22
gd.ShipFormationMaximumCatchup = gd.ShipFormationMaximumCatchup or 0.55
gd.ShipMapSpaceMotionScale = gd.ShipMapSpaceMotionScale or 8
gd.ShipAutonomousMotionEnabled = gd.ShipAutonomousMotionEnabled ~= false
gd.ShipAutonomousIdleDelay = gd.ShipAutonomousIdleDelay or 1.5
gd.ShipAutonomousRoutePoints = gd.ShipAutonomousRoutePoints or 3
gd.ShipAutonomousRouteMinimum = gd.ShipAutonomousRouteMinimum or 420
gd.ShipAutonomousRouteMaximum = gd.ShipAutonomousRouteMaximum or 1050
gd.ShipAutonomousSpeeds = gd.ShipAutonomousSpeeds or {
	default = { 26, 40 },
	civilian = { 24, 36 },
	republic = { 30, 44 },
	pirate = { 38, 54 },
	cis_scout = { 38, 56 },
	cis_capital = { 16, 24 },
	republic_flagship = { 17, 25 },
}
gd.ShipFlightProfiles = gd.ShipFlightProfiles or {
	default = {
		accelerate = 14, brake = 24, jerk = 72, steering = 58,
		bank = 9, bankRate = 40, turnThrottle = 0.5,
	},
	civilian = {
		accelerate = 9, brake = 17, jerk = 38, steering = 34,
		bank = 5, bankRate = 26, turnThrottle = 0.62,
	},
	republic = {
		accelerate = 14, brake = 25, jerk = 64, steering = 54,
		bank = 8, bankRate = 38, turnThrottle = 0.5,
	},
	pirate = {
		accelerate = 21, brake = 36, jerk = 105, steering = 88,
		bank = 14, bankRate = 62, turnThrottle = 0.36,
	},
	cis_scout = {
		accelerate = 19, brake = 33, jerk = 94, steering = 80,
		bank = 12, bankRate = 56, turnThrottle = 0.4,
	},
	cis_capital = {
		accelerate = 5, brake = 10, jerk = 20, steering = 14,
		bank = 2.5, bankRate = 12, turnThrottle = 0.76,
	},
	republic_flagship = {
		accelerate = 6, brake = 11, jerk = 24, steering = 16,
		bank = 2.8, bankRate = 14, turnThrottle = 0.74,
	},
}

-- Living-universe expansion. These systems all use the same communications
-- operator, lightweight skybox actors and campaign recommendation safeguards
-- as the core Galaxy Director.
gd.LivingUniverseExpansion = gd.LivingUniverseExpansion ~= false
gd.SensorScanTimeMin = gd.SensorScanTimeMin or 2.5
gd.SensorScanTimeMax = gd.SensorScanTimeMax or 5
gd.SensorScanCooldown = gd.SensorScanCooldown or 2
gd.SensorMinimumSignal = gd.SensorMinimumSignal or 12
gd.CommsHistoryLimit = gd.CommsHistoryLimit or 40
gd.IntelRecordLimit = gd.IntelRecordLimit or 30
gd.IntelLifetime = gd.IntelLifetime or 1800
gd.ContactMemoryLimit = gd.ContactMemoryLimit or 250
gd.FakeTransponderChance = gd.FakeTransponderChance or {
	civilian = 0.03,
	pirate = 0.42,
	cis = 0.12,
	republic = 0.01,
}
gd.FakeDistressChance = gd.FakeDistressChance or 0.22
gd.SpecialTrafficChance = gd.SpecialTrafficChance or 0.28
gd.SpecialTrafficMinimumInterval = gd.SpecialTrafficMinimumInterval or 240
-- Ordinary traffic is intentionally separate from priority contacts. It keeps
-- the route alive without turning every passing ship into an encounter.
gd.AmbientTrafficEnabled = gd.AmbientTrafficEnabled ~= false
-- This is only a cap on ships physically represented in the current skybox.
-- The galaxy simulation itself remains virtual, so a busier view does not make
-- every system load entities at once.
gd.AmbientTrafficMaximumShips = gd.AmbientTrafficMaximumShips or 16
gd.AmbientTrafficDistantChance = gd.AmbientTrafficDistantChance or 0.34
gd.AmbientTrafficFormationChance = gd.AmbientTrafficFormationChance or 0.28
gd.AmbientTrafficCrossingChance = gd.AmbientTrafficCrossingChance or 0.62
gd.AmbientTrafficSpeedMin = gd.AmbientTrafficSpeedMin or 24
gd.AmbientTrafficSpeedMax = gd.AmbientTrafficSpeedMax or 48
gd.AmbientTrafficDistantLaneFraction = gd.AmbientTrafficDistantLaneFraction or 0.24
gd.AmbientTrafficDistantHeightFraction = gd.AmbientTrafficDistantHeightFraction or 0.18
-- Routine traffic is simulated across the whole SWU galaxy, not spawned around
-- the Republic ship.  Every record has a real system, destination and travel
-- clock; only the traffic relevant to the current system is made visible.
gd.PersistentUniverseTrafficEnabled = gd.PersistentUniverseTrafficEnabled ~= false
gd.GalaxyTrafficSimulationEnabled = gd.GalaxyTrafficSimulationEnabled ~= false
gd.GalaxyTrafficShipsPerPlanet = gd.GalaxyTrafficShipsPerPlanet or 8
-- Independently seeded orbital services mean every system already has local
-- activity before the Republic ship comes out of hyperspace there.
gd.GalaxyTrafficMinimumSystemPresence = gd.GalaxyTrafficMinimumSystemPresence or 4
gd.GalaxyTrafficMaximumRecords = gd.GalaxyTrafficMaximumRecords or 480
gd.GalaxyTrafficHoldingMinimum = gd.GalaxyTrafficHoldingMinimum or 150
gd.GalaxyTrafficHoldingMaximum = gd.GalaxyTrafficHoldingMaximum or 780
gd.GalaxyTrafficTravelMinimum = gd.GalaxyTrafficTravelMinimum or 90
gd.GalaxyTrafficTravelMaximum = gd.GalaxyTrafficTravelMaximum or 1800
gd.GalaxyTrafficTravelSecondsPerUnit = gd.GalaxyTrafficTravelSecondsPerUnit or 0.06
gd.GalaxyTrafficVisibilityWindow = gd.GalaxyTrafficVisibilityWindow or 300
gd.GalaxyTrafficVisibleMaximum = gd.GalaxyTrafficVisibleMaximum or 16
gd.GalaxyTrafficPopulationRefresh = gd.GalaxyTrafficPopulationRefresh or 90
gd.GalaxyTrafficSaveInterval = gd.GalaxyTrafficSaveInterval or 60
-- Full galaxy records do not need to be revisited every server frame/second.
-- Visible actors still move through their own lightweight entity Think.
gd.GalaxyTrafficAdvanceInterval = gd.GalaxyTrafficAdvanceInterval or 5
gd.GalaxyTrafficPlanetCacheSeconds = gd.GalaxyTrafficPlanetCacheSeconds or 30
gd.GalaxyStateBroadcastMinimumInterval = gd.GalaxyStateBroadcastMinimumInterval or 0.12
gd.GalaxyShipCombatThinkInterval = gd.GalaxyShipCombatThinkInterval or 0.03
gd.GalaxyShipMovingThinkInterval = gd.GalaxyShipMovingThinkInterval or 0.05
gd.GalaxyShipIdleThinkInterval = gd.GalaxyShipIdleThinkInterval or 0.15
gd.GalaxyTrafficMaximumTrackedRoutes = gd.GalaxyTrafficMaximumTrackedRoutes or 3
-- Stationed service traffic follows gentle orbital circuits instead of sitting
-- frozen in one place. Disable this if a map's skybox is exceptionally small.
gd.GalaxyTrafficServiceOrbitEnabled = gd.GalaxyTrafficServiceOrbitEnabled ~= false
gd.GalaxyTrafficServiceOrbitSpeed = gd.GalaxyTrafficServiceOrbitSpeed or 22
-- The strategic layer runs independently of player position. It creates trade
-- demand, fleet schedules, lane hazards, sector reports and long-running
-- background conflicts for the traffic simulation to react to.
gd.LivingGalaxySimulationEnabled = gd.LivingGalaxySimulationEnabled ~= false
gd.LivingGalaxySimulationInterval = gd.LivingGalaxySimulationInterval or 30
gd.GalaxyNewsMaximum = gd.GalaxyNewsMaximum or 36
gd.GalaxyNewsVisibleMaximum = gd.GalaxyNewsVisibleMaximum or 5
gd.GalaxyLaneMinimumLifetime = gd.GalaxyLaneMinimumLifetime or 600
gd.GalaxyLaneMaximumLifetime = gd.GalaxyLaneMaximumLifetime or 1800
gd.GalaxyLaneEventChance = gd.GalaxyLaneEventChance or 0.06
gd.GalaxyBattleMinimumDuration = gd.GalaxyBattleMinimumDuration or 600
gd.GalaxyBattleMaximumDuration = gd.GalaxyBattleMaximumDuration or 1800
gd.GalaxyBattleCreationChance = gd.GalaxyBattleCreationChance or 0.025
gd.GalaxyMaximumVirtualBattles = gd.GalaxyMaximumVirtualBattles or 4
gd.GalaxyDistressLifetime = gd.GalaxyDistressLifetime or 720
gd.GalaxyMaximumVirtualDistress = gd.GalaxyMaximumVirtualDistress or 5
gd.GalaxyDistressChance = gd.GalaxyDistressChance or 0.14
gd.GalaxyEconomyMaximumStock = gd.GalaxyEconomyMaximumStock or 100
-- Legacy limits are retained so older server configs still load cleanly. They
-- now apply to visible local representations, not to the simulated galaxy.
gd.PersistentUniverseMaximumShips = gd.PersistentUniverseMaximumShips or 14
gd.PersistentUniverseMinimumShips = gd.PersistentUniverseMinimumShips or 5
gd.PersistentUniverseReentryDelay = gd.PersistentUniverseReentryDelay or 2
-- Strategic patrol AI lets background Republic and CIS traffic react to one
-- another. It never bypasses the existing attack/player-count safeguards.
gd.StrategicPatrolAIEnabled = gd.StrategicPatrolAIEnabled ~= false
gd.StrategicPatrolAcquireRange = gd.StrategicPatrolAcquireRange or 1500
gd.StrategicPatrolEngagementRange = gd.StrategicPatrolEngagementRange or 620
gd.StrategicPatrolBaseAttackRange = gd.StrategicPatrolBaseAttackRange or 360
gd.StrategicPatrolCruiseSpeed = gd.StrategicPatrolCruiseSpeed or 48
gd.StrategicPatrolFleeSpeed = gd.StrategicPatrolFleeSpeed or 64
gd.StrategicPatrolSupportRange = gd.StrategicPatrolSupportRange or 1150
gd.StrategicPatrolPlayerStrength = gd.StrategicPatrolPlayerStrength or 1
gd.StrategicPatrolDamage = gd.StrategicPatrolDamage or 28
gd.StrategicPatrolFireInterval = gd.StrategicPatrolFireInterval or 4.5
gd.StrategicPatrolPostRaidCooldown = gd.StrategicPatrolPostRaidCooldown or 180
gd.NearbyRepublicRaidSupportEnabled = gd.NearbyRepublicRaidSupportEnabled ~= false
gd.NearbyRepublicRaidSupportRange = gd.NearbyRepublicRaidSupportRange or 2200
gd.NearbyRepublicRaidSupportMaximum = gd.NearbyRepublicRaidSupportMaximum or 6
gd.NearbyRepublicRaidSupportHoldRange = gd.NearbyRepublicRaidSupportHoldRange or 620
gd.NearbyRepublicRaidSupportSpeed = gd.NearbyRepublicRaidSupportSpeed or 58
gd.NearbyRepublicRaidSupportDamage = gd.NearbyRepublicRaidSupportDamage or 42
gd.NearbyRepublicRaidSupportCapitalMultiplier = gd.NearbyRepublicRaidSupportCapitalMultiplier or 1.3
gd.NearbyRepublicRaidSupportFireInterval = gd.NearbyRepublicRaidSupportFireInterval or 4.2
gd.NearbyRepublicRaidReturnFireDamage = gd.NearbyRepublicRaidReturnFireDamage or 58
gd.NearbyRepublicRaidReturnFireInterval = gd.NearbyRepublicRaidReturnFireInterval or 5
-- Planet-side lanes make visible SWU planets feel inhabited. Ships approach a
-- safe surface corridor, descend out of sight, or launch from it and depart.
gd.PlanetTrafficEnabled = gd.PlanetTrafficEnabled ~= false
gd.PlanetTrafficMinimumInterval = gd.PlanetTrafficMinimumInterval or 25
gd.PlanetTrafficMaximumInterval = gd.PlanetTrafficMaximumInterval or 52
gd.PlanetTrafficMaximumShips = gd.PlanetTrafficMaximumShips or 6
gd.PlanetTrafficTakeoffChance = gd.PlanetTrafficTakeoffChance or 0.48
gd.PlanetTrafficApproachSpeed = gd.PlanetTrafficApproachSpeed or 30
gd.PlanetTrafficDepartureSpeed = gd.PlanetTrafficDepartureSpeed or 38
gd.PlanetTrafficSurfaceClearance = gd.PlanetTrafficSurfaceClearance or 280
gd.PlanetTrafficLandingHold = gd.PlanetTrafficLandingHold or 4
gd.PlanetTrafficArrivalRadius = gd.PlanetTrafficArrivalRadius or 170
-- Orbital blockades are persistent campaign state, but only the blockade at
-- the currently visible planet is spawned into the skybox.  Republic groups
-- use Venators; CIS occupations use Munificent-class capital ships.
gd.OrbitalBlockadesEnabled = gd.OrbitalBlockadesEnabled ~= false
gd.RepublicBlockadeVenators = gd.RepublicBlockadeVenators or 3
gd.CISBlockadeCapitalShips = gd.CISBlockadeCapitalShips or 2
gd.BlockadeOrbitClearance = gd.BlockadeOrbitClearance or 950
gd.BlockadeShipSpacing = gd.BlockadeShipSpacing or 520
gd.BlockadeFormationSpacing = gd.BlockadeFormationSpacing or 900
gd.CISAutomaticBlockades = gd.CISAutomaticBlockades ~= false
gd.RestrictedAirspaceCivilianCompliance = gd.RestrictedAirspaceCivilianCompliance or 0.9
gd.RestrictedAirspacePirateCompliance = gd.RestrictedAirspacePirateCompliance or 0.48
gd.RestrictedAirspaceOrderCooldown = gd.RestrictedAirspaceOrderCooldown or 120
-- Visual hyperlane flashes make ordinary traffic arrivals and departures feel
-- like real Star Wars Universe travel instead of ships simply appearing.
gd.HyperspaceTransitEffectsEnabled = gd.HyperspaceTransitEffectsEnabled ~= false
gd.HyperspaceTransitEffectLength = gd.HyperspaceTransitEffectLength or 950
-- Passive points of interest are scanner-visible, optional contacts. They do
-- not create an attack and remain available while attacks are paused.
gd.AmbientPhenomenaEnabled = gd.AmbientPhenomenaEnabled ~= false
gd.AmbientPhenomenaChance = gd.AmbientPhenomenaChance or 0.24
gd.AmbientPhenomenaMinimumInterval = gd.AmbientPhenomenaMinimumInterval or 180
gd.AmbientPhenomenaLifetime = gd.AmbientPhenomenaLifetime or 210
gd.AmbientPhenomenaMaximum = gd.AmbientPhenomenaMaximum or 3
gd.NavigationBeaconChance = gd.NavigationBeaconChance or 0.38
gd.SensorAnomalyChance = gd.SensorAnomalyChance or 0.38
-- Routine ships stay radio-silent. Unsolicited calls are reserved for a
-- Republic ship that genuinely needs help or a hostile CIS ship demanding the
-- Republic vessel surrender; Fleet may still hail every visible contact.
gd.AmbientCommsChatterEnabled = gd.AmbientCommsChatterEnabled ~= false
gd.AmbientCommsChatterMinimumInterval = gd.AmbientCommsChatterMinimumInterval or 70
gd.AmbientCommsChatterMaximumInterval = gd.AmbientCommsChatterMaximumInterval or 135
gd.IncomingRepublicAssistanceHullFraction = gd.IncomingRepublicAssistanceHullFraction or 0.68
gd.IncomingCISSurrenderDemandChance = gd.IncomingCISSurrenderDemandChance or 0.72
gd.IncomingShipTransmissionCooldown = gd.IncomingShipTransmissionCooldown or 180
gd.TrafficOrderCooldown = gd.TrafficOrderCooldown or 90
gd.TrafficOrderCivilianCompliance = gd.TrafficOrderCivilianCompliance or 0.92
gd.TrafficOrderPirateCompliance = gd.TrafficOrderPirateCompliance or 0.48
gd.TrafficOrderCISCompliance = gd.TrafficOrderCISCompliance or 0.08
-- Background engagements make the route feel contested without forcing a
-- priority encounter. Fleet may scan and hail either participant to join.
gd.BackgroundBattlesEnabled = gd.BackgroundBattlesEnabled ~= false
gd.BackgroundBattleChance = gd.BackgroundBattleChance or 0.24
gd.BackgroundBattleMinimumInterval = gd.BackgroundBattleMinimumInterval or 240
gd.BackgroundBattleDuration = gd.BackgroundBattleDuration or 145
gd.BackgroundBattleAttackerHull = gd.BackgroundBattleAttackerHull or 3200
gd.BackgroundBattleRepublicHull = gd.BackgroundBattleRepublicHull or 3900
gd.BackgroundBattleCivilianHull = gd.BackgroundBattleCivilianHull or 2800
gd.BackgroundBattleAttackerDamage = gd.BackgroundBattleAttackerDamage or 54
gd.BackgroundBattleDefenderDamage = gd.BackgroundBattleDefenderDamage or 38
-- A local CIS battle can escalate into a proper boarding assault only after
-- Fleet chooses to join it. The normal player-count, attack-enabled and major
-- attack cooldown safeguards still apply.
gd.BackgroundBattleBoardingEscalationEnabled = gd.BackgroundBattleBoardingEscalationEnabled ~= false
gd.BackgroundBattleBoardingEscalationChance = gd.BackgroundBattleBoardingEscalationChance or 0.24
gd.BackgroundBattleBoardingDelayMinimum = gd.BackgroundBattleBoardingDelayMinimum or 38
gd.BackgroundBattleBoardingDelayMaximum = gd.BackgroundBattleBoardingDelayMaximum or 82
gd.BackgroundBattleBoardingAttackerHullMinimum = gd.BackgroundBattleBoardingAttackerHullMinimum or 0.46
gd.EncounterProfilesEnabled = gd.EncounterProfilesEnabled ~= false
gd.EncounterProfileFollowupChance = gd.EncounterProfileFollowupChance or 0.5
gd.EscortDuration = gd.EscortDuration or 105
-- Convoys stay in the SWU skybox. The Republic's main ship is the escort;
-- taking it underway advances the formation and pauses it again when stopped.
-- The old map/LVS convoy route is intentionally disabled.
gd.EscortMapBattles = false
gd.EscortMapRendezvousDistance = gd.EscortMapRendezvousDistance or 1800
gd.EscortMapAltitude = gd.EscortMapAltitude or 1100
gd.EscortMapRouteLength = gd.EscortMapRouteLength or 5200
gd.EscortMapConvoySpeed = gd.EscortMapConvoySpeed or 105
gd.EscortMapRendezvousRange = gd.EscortMapRendezvousRange or 1250
gd.EscortMapArrivalRadius = gd.EscortMapArrivalRadius or 260
gd.EscortMapMaximumWaves = gd.EscortMapMaximumWaves or 3
gd.EscortMapHostileIngressSpeed = gd.EscortMapHostileIngressSpeed or 340
gd.EscortMapDuration = gd.EscortMapDuration or 330
gd.EscortSkyboxSpeed = gd.EscortSkyboxSpeed or 34
gd.EscortSkyboxMaximumWaves = gd.EscortSkyboxMaximumWaves or 3
gd.EscortSkyboxDuration = gd.EscortSkyboxDuration or 300
gd.EscortSkyboxProgressPerSecond = gd.EscortSkyboxProgressPerSecond or 0.52

-- Republic fleets occasionally appear as a separate temporary task force.
-- Hail the Venator lead and ask it to join formation; it follows the main
-- Republic ship until dismissed or recalled to patrol.
gd.RepublicFleetRendezvousEnabled = gd.RepublicFleetRendezvousEnabled ~= false
gd.RepublicFleetRendezvousChance = gd.RepublicFleetRendezvousChance or 0.16
gd.RepublicFleetEscortCountMin = gd.RepublicFleetEscortCountMin or 1
gd.RepublicFleetEscortCountMax = gd.RepublicFleetEscortCountMax or 3
gd.RepublicFleetFollowDuration = gd.RepublicFleetFollowDuration or 360
-- Separate bridge ordnance stations engage scanned hostile contacts that
-- cannot be reached by LVS fighters inside the SWU skybox.
gd.SkyboxFireControlEnabled = gd.SkyboxFireControlEnabled ~= false
gd.SkyboxVolleyCooldown = gd.SkyboxVolleyCooldown or 32
gd.SkyboxVolleyDamage = gd.SkyboxVolleyDamage or 1100
gd.SkyboxVolleyShots = gd.SkyboxVolleyShots or 4
gd.SkyboxVolleyMinimumSignal = gd.SkyboxVolleyMinimumSignal or 18
gd.SkyboxVolleyRequireAuthorization = gd.SkyboxVolleyRequireAuthorization == true
gd.SkyboxVolleyBatteryDistance = gd.SkyboxVolleyBatteryDistance or 0.2
gd.SkyboxVolleyBatteryDrop = gd.SkyboxVolleyBatteryDrop or 0.08
gd.SkyboxVolleyBatterySeparation = gd.SkyboxVolleyBatterySeparation or 0.025
gd.SkyboxVolleyShotInterval = gd.SkyboxVolleyShotInterval or 0.3
gd.IonCannonCooldown = gd.IonCannonCooldown or 42
gd.IonCannonShieldDamage = gd.IonCannonShieldDamage or 1850
gd.IonCannonDisableDuration = gd.IonCannonDisableDuration or 16
gd.IonCannonShots = gd.IonCannonShots or 3
gd.TorpedoCooldown = gd.TorpedoCooldown or 68
gd.TorpedoDamage = gd.TorpedoDamage or 2350
gd.TorpedoFlightTime = gd.TorpedoFlightTime or 1.15
gd.BlockadeDuration = gd.BlockadeDuration or 180
gd.SalvageDuration = gd.SalvageDuration or 28
gd.CounterBoardDuration = gd.CounterBoardDuration or 75
gd.AftermathDuration = gd.AftermathDuration or 300
gd.AftermathTrafficMultiplier = gd.AftermathTrafficMultiplier or 0.45
gd.ReinforcementMaximum = gd.ReinforcementMaximum or 3
gd.ReinforcementStartingCharges = gd.ReinforcementStartingCharges or 2
gd.ReinforcementRechargeTime = gd.ReinforcementRechargeTime or 1800
gd.ReinforcementArrivalDelay = gd.ReinforcementArrivalDelay or 12
gd.ReinforcementLifetime = gd.ReinforcementLifetime or 150
gd.ReinforcementShips = gd.ReinforcementShips or 2
gd.BoardingSabotageDelay = gd.BoardingSabotageDelay or 28
gd.BoardingWaveVariants = gd.BoardingWaveVariants or {
	assault = { label = "B1 ASSAULT WAVE", weight = 38, health = 1 },
	heavy = { label = "B2 HEAVY WAVE", weight = 24, health = 1.8 },
	commando = { label = "BX COMMANDO WAVE", weight = 18, health = 1.35 },
	saboteur = { label = "CIS SABOTAGE TEAM", weight = 11, health = 1.15 },
	demolition = { label = "DROID DEMOLITION TEAM", weight = 9, health = 1.2 },
}
-- Mixed unit composition used inside every boarding wave. Exact ArcCW weapon
-- classes are preferred; the runtime falls back safely when workshop content
-- has not mounted yet.
gd.RaidBoardingUnits = gd.RaidBoardingUnits or {
	{
		id = "b1_rifleman",
		label = "CGI B1 RIFLEMAN",
		npcType = "b1",
		weight = 48,
		model = "models/aussiwozzi/cgi/b1droids/b1_battledroid.mdl",
		weapon = "arccw_cgi_k_e5",
		health = 1,
		minimumHealth = 120,
		proficiency = WEAPON_PROFICIENCY_GOOD or 3,
	},
	{
		id = "b1_support",
		label = "CGI B1 SUPPORT DROID",
		npcType = "b1",
		weight = 24,
		model = "models/aussiwozzi/cgi/b1droids/b1_battledroid.mdl",
		weapon = "arccw_cgi_k_e5c",
		health = 1.15,
		minimumHealth = 150,
		proficiency = WEAPON_PROFICIENCY_GOOD or 3,
	},
	{
		id = "b2_heavy",
		label = "CGI B2 SUPER BATTLE DROID",
		npcType = "b2",
		weight = 28,
		model = "models/aussiwozzi/cgi/b1droids/b2_battledroid_rocket.mdl",
		weapon = "arccw_k_b2hand",
		health = 2.6,
		minimumHealth = 600,
		proficiency = WEAPON_PROFICIENCY_VERY_GOOD or 4,
	},
}
gd.RareContactTypes = gd.RareContactTypes or {
	medical = { name = "Republic Medical Relief Ship", faction = "republic" },
	bounty = { name = "Independent Bounty Vessel", faction = "pirate" },
	smuggler = { name = "Outer Rim Freight Cooperative", faction = "civilian" },
	diplomatic = { name = "Diplomatic Courier", faction = "civilian" },
	derelict = { name = "Unresponsive Derelict", faction = "civilian" },
	defector = { name = "CIS Defector Vessel", faction = "cis" },
}
gd.TrackShipsInSWUUniverse = gd.TrackShipsInSWUUniverse ~= false
gd.SkyboxEntryInset = gd.SkyboxEntryInset or 180
gd.SkyboxMovementThreshold = gd.SkyboxMovementThreshold or 0.5
gd.PlanetAvoidanceEnabled = gd.PlanetAvoidanceEnabled ~= false
gd.PlanetAvoidanceMargin = gd.PlanetAvoidanceMargin or 180
gd.PlanetAvoidanceLookAhead = gd.PlanetAvoidanceLookAhead or 5
gd.PlanetAvoidanceTurnRate = gd.PlanetAvoidanceTurnRate or 2.5

-- Hostile CIS vessels are physical LVS targets. Their regenerating shield
-- absorbs damage first; overflow and later hits permanently damage the hull.
gd.CISSkyboxCombatEnabled = gd.CISSkyboxCombatEnabled ~= false
gd.CISCombatPositionRadius = gd.CISCombatPositionRadius or 0.34
gd.CISCombatIngressSpeed = gd.CISCombatIngressSpeed or 82
gd.CISCapitalIngressSpeed = gd.CISCapitalIngressSpeed or 58
gd.CISCombatArrivalTolerance = gd.CISCombatArrivalTolerance or 70
-- Arrival points are reservations, not a single shared coordinate. This
-- padding is added outside both ships' visible hulls.
gd.CISCombatSeparationPadding = gd.CISCombatSeparationPadding or 140
gd.CISScoutShield = gd.CISScoutShield or 2600
gd.CISCapitalShield = gd.CISCapitalShield or 9000
gd.CISShieldPerPlayer = gd.CISShieldPerPlayer or 350
gd.CISShieldRegenDelay = gd.CISShieldRegenDelay or 12
gd.CISShieldRegenPerSecond = gd.CISShieldRegenPerSecond or 0.04
gd.CISUseModelCollision = gd.CISUseModelCollision ~= false
gd.CISMaximumCollisionConvexes = gd.CISMaximumCollisionConvexes or 64
gd.CISMaximumCollisionVertices = gd.CISMaximumCollisionVertices or 4000
gd.CISNonLVSDamageScale = gd.CISNonLVSDamageScale or 0.2
gd.CISScoutMaximumDamagePerHit = gd.CISScoutMaximumDamagePerHit or 1400
gd.CISCapitalMaximumDamagePerHit = gd.CISCapitalMaximumDamagePerHit or 2600
gd.CISHullEffectsStartAt = gd.CISHullEffectsStartAt or 0.7
gd.CISRetreatSpeed = gd.CISRetreatSpeed or 110
gd.CISRetreatLifetime = gd.CISRetreatLifetime or gd.CISRetreatDuration or 18

-- Capital ships use real map coordinates so the Munificent can enter and hold
-- above the playable map. The final position is persisted per map. A CAPITAL
-- map anchor, when configured, overrides the automatically saved position.
gd.CISCapitalUsesMapSpace = gd.CISCapitalUsesMapSpace ~= false
gd.CISCapitalMapDistance = gd.CISCapitalMapDistance or 1700
gd.CISCapitalMapAltitude = gd.CISCapitalMapAltitude or 1500
gd.CISCapitalMapIngressDistance = gd.CISCapitalMapIngressDistance or 3200
gd.CISCapitalMapIngressRise = gd.CISCapitalMapIngressRise or 250
gd.CISCapitalMapIngressSpeed = gd.CISCapitalMapIngressSpeed or 420
gd.CISCapitalMapRetreatSpeed = gd.CISCapitalMapRetreatSpeed or 650

gd.BreachDoorSearchRadius = gd.BreachDoorSearchRadius or 260
gd.BreachDoorFallbackRadius = gd.BreachDoorFallbackRadius or 750
gd.BreachDoorDamage = gd.BreachDoorDamage or 35

-- Territory determines the encounter weighting. Pressure further increases
-- danger, so a safe Republic world can become threatening before it falls.
gd.DangerByAllegiance = gd.DangerByAllegiance or {
	republic = 0.12,
	neutral = 0.38,
	contested = 0.68,
	cis = 0.88,
}

gd.EncounterWeights = gd.EncounterWeights or {
	-- Weight is interpolated from safe (danger=0) to hostile (danger=1).
	civilian = { safe = 44, hostile = 16 },
	republic = { safe = 35, hostile = 7 },
	pirate = { safe = 8, hostile = 24 },
	distress = { safe = 8, hostile = 25 },
	cis = { safe = 5, hostile = 40 },
}

-- Model candidates are tried in order. Missing packs gracefully fall back to
-- stock props, so a bad/missing model can never stop the director.
gd.ShipModels = gd.ShipModels or {
	cis_fighter = {
		"models/salza/vulture_droid.mdl",
	},
	cis_scout = {
		-- Routine CIS contacts are light patrols, couriers and raiders. Capital
		-- Separatist hulls remain exclusive to cis_capital encounters.
		"models/arson/kotor/ships/g_wing.mdl",
		"models/arson/kotor/ships/sith_freighter.mdl",
	},
	cis_capital = {
		"models/salty/munificent-class.mdl",
		"models/kingpommes/starwars/providence/providence_sky_128.mdl",
		"models/salty/providence.mdl",
	},
	republic = {
		-- A routine Republic patrol is deliberately smaller than a task-force
		-- flagship. Venators remain in republic_flagship/fleet encounters.
		"models/salty/repubarquitens-cruiser.mdl",
	},
	republic_flagship = {
		"models/salty/venator-class-cruiser.mdl",
		"models/lordtrilobite/starwars/props/venator_128.mdl",
	},
	civilian = {
		"models/arson/kotor/ships/freighter_neutral.mdl",
		"models/arson/kotor/ships/lethisk_class_freighter.mdl",
		"models/arson/kotor/ships/telos_passenger_shuttle.mdl",
		"models/arson/kotor/ships/telos_shuttle.mdl",
		"models/arson/kotor/ships/ebon_hawk.mdl",
	},
	pirate = {
		"models/arson/kotor/ships/ebon_hawk_damaged.mdl",
		"models/arson/kotor/ships/g_wing.mdl",
		"models/arson/kotor/ships/sith_freighter.mdl",
	},
}

-- Visual and handling classes let local traffic contain genuinely small
-- fighters and shuttles instead of normalising every contact to corvette size.
-- targetRadius is the intended rendered radius inside the 3D skybox.
gd.ShipSizeClasses = gd.ShipSizeClasses or {
	fighter = {
		targetRadius = 13,
		maximumRadius = 18,
		hullMultiplier = 0.18,
		shieldMultiplier = 0.12,
		speed = { 76, 116 },
		formationSpacing = 42,
		flightProfile = {
			accelerate = 32, brake = 52, jerk = 165, steering = 150,
			bank = 24, bankRate = 125, turnThrottle = 0.24,
		},
	},
	shuttle = {
		targetRadius = 28,
		maximumRadius = 38,
		hullMultiplier = 0.38,
		shieldMultiplier = 0.28,
		speed = { 46, 70 },
		formationSpacing = 66,
		flightProfile = {
			accelerate = 18, brake = 31, jerk = 92, steering = 82,
			bank = 13, bankRate = 66, turnThrottle = 0.38,
		},
	},
	light = {
		targetRadius = 52,
		maximumRadius = 68,
		hullMultiplier = 0.62,
		shieldMultiplier = 0.55,
		speed = { 36, 57 },
		formationSpacing = 105,
		flightProfile = {
			accelerate = 15, brake = 27, jerk = 76, steering = 62,
			bank = 10, bankRate = 46, turnThrottle = 0.48,
		},
	},
	corvette = {
		targetRadius = 105,
		maximumRadius = 145,
		hullMultiplier = 1,
		shieldMultiplier = 1,
		speed = { 25, 43 },
		formationSpacing = 190,
		flightProfile = {
			accelerate = 10, brake = 19, jerk = 50, steering = 38,
			bank = 6, bankRate = 30, turnThrottle = 0.58,
		},
	},
	capital = {
		targetRadius = 300,
		maximumRadius = 340,
		hullMultiplier = 1,
		shieldMultiplier = 1,
		speed = { 16, 25 },
		formationSpacing = 430,
		flightProfile = {
			accelerate = 5, brake = 10, jerk = 20, steering = 14,
			bank = 2.5, bankRate = 12, turnThrottle = 0.76,
		},
	},
}

gd.ShipRoleDefaultSizeClass = gd.ShipRoleDefaultSizeClass or {
	cis_fighter = "fighter",
	cis_scout = "light",
	cis_capital = "capital",
	republic = "corvette",
	republic_flagship = "capital",
	civilian = "light",
	pirate = "light",
	salvage = "light",
	default = "light",
}

-- Exact model classifications are also used when an encounter supplies a
-- model directly instead of drawing from the weighted variant pools.
gd.ShipModelSizeClass = gd.ShipModelSizeClass or {
	["models/blu/arc170.mdl"] = "fighter",
	["models/blu/vwing.mdl"] = "fighter",
	["models/salza/vulture_droid.mdl"] = "fighter",
	["models/arson/kotor/ships/g_wing.mdl"] = "fighter",
	["models/arson/kotor/ships/telos_passenger_shuttle.mdl"] = "shuttle",
	["models/arson/kotor/ships/telos_shuttle.mdl"] = "shuttle",
	["models/arson/kotor/ships/ebon_hawk.mdl"] = "light",
	["models/arson/kotor/ships/ebon_hawk_damaged.mdl"] = "light",
	["models/arson/kotor/ships/sith_freighter.mdl"] = "light",
	["models/arson/kotor/ships/freighter_neutral.mdl"] = "corvette",
	["models/arson/kotor/ships/lethisk_class_freighter.mdl"] = "corvette",
	["models/salty/repubarquitens-cruiser.mdl"] = "corvette",
	["models/salty/munificent-class.mdl"] = "capital",
	["models/kingpommes/starwars/providence/providence_sky_128.mdl"] = "capital",
	["models/salty/providence.mdl"] = "capital",
	["models/salty/venator-class-cruiser.mdl"] = "capital",
	["models/lordtrilobite/starwars/props/venator_128.mdl"] = "capital",
}

-- Weighted variants make routine lanes visually mixed. Missing Workshop
-- models are skipped at runtime and the original role model list remains the
-- fallback, so a server can remove any entry without breaking encounters.
gd.ShipVariantPools = gd.ShipVariantPools or {
	republic = {
		{ model = "models/blu/vwing.mdl", sizeClass = "fighter", weight = 5 },
		{ model = "models/blu/arc170.mdl", sizeClass = "fighter", weight = 3 },
		{ model = "models/salty/repubarquitens-cruiser.mdl", sizeClass = "corvette", weight = 4 },
	},
	cis_scout = {
		{ model = "models/salza/vulture_droid.mdl", sizeClass = "fighter", weight = 6 },
		{ model = "models/arson/kotor/ships/g_wing.mdl", sizeClass = "fighter", weight = 2 },
		{ model = "models/arson/kotor/ships/sith_freighter.mdl", sizeClass = "light", weight = 2 },
	},
	civilian = {
		{ model = "models/arson/kotor/ships/telos_passenger_shuttle.mdl", sizeClass = "shuttle", weight = 4 },
		{ model = "models/arson/kotor/ships/telos_shuttle.mdl", sizeClass = "shuttle", weight = 4 },
		{ model = "models/arson/kotor/ships/ebon_hawk.mdl", sizeClass = "light", weight = 3 },
		{ model = "models/arson/kotor/ships/freighter_neutral.mdl", sizeClass = "corvette", weight = 2 },
		{ model = "models/arson/kotor/ships/lethisk_class_freighter.mdl", sizeClass = "corvette", weight = 2 },
	},
	pirate = {
		{ model = "models/arson/kotor/ships/g_wing.mdl", sizeClass = "fighter", weight = 5 },
		{ model = "models/arson/kotor/ships/ebon_hawk_damaged.mdl", sizeClass = "light", weight = 3 },
		{ model = "models/arson/kotor/ships/sith_freighter.mdl", sizeClass = "light", weight = 2 },
	},
	cis_capital = {
		{ model = "models/salty/munificent-class.mdl", sizeClass = "capital", weight = 5 },
		{ model = "models/kingpommes/starwars/providence/providence_sky_128.mdl", sizeClass = "capital", weight = 1 },
		{ model = "models/salty/providence.mdl", sizeClass = "capital", weight = 1 },
	},
	republic_flagship = {
		{ model = "models/salty/venator-class-cruiser.mdl", sizeClass = "capital", weight = 4 },
		{ model = "models/lordtrilobite/starwars/props/venator_128.mdl", sizeClass = "capital", weight = 1 },
	},
}

-- Hardcells are fixed Separatist factory/transport structures rather than
-- suitable roaming encounter ships. Fragments here are rejected even if an
-- older or custom ShipModels table still contains them.
gd.BlockedShipModelFragments = gd.BlockedShipModelFragments or {
	"hardcell",
}

gd.ShipModelScale = gd.ShipModelScale or {
	cis_scout = 0.06,
	cis_capital = 0.09,
	republic = 0.07,
	republic_flagship = 0.07,
	civilian = 0.045,
	pirate = 0.05,
}

-- Each native model has a different source size. These desired visual radii
-- keep varied civilian, pirate and Republic designs readable in the skybox
-- without allowing them to cover a planet.
gd.ShipModelTargetRadius = gd.ShipModelTargetRadius or {
	-- Routine traffic is intentionally small against the SWU planets. Capital
	-- ships remain impressive, but are never allowed to read as planet-sized.
	cis_scout = 105,
	cis_capital = 300,
	republic = 125,
	republic_flagship = 300,
	civilian = 75,
	pirate = 85,
}
gd.SkyboxMaximumModelScale = gd.SkyboxMaximumModelScale or 1.25

-- Map-space ships, such as the physical CIS capital encounter, use their
-- native model scale. Convoys no longer use map-space ship actors.
gd.MapSpaceShipModelScale = gd.MapSpaceShipModelScale or {
	default = 1,
	cis_scout = 1,
	cis_capital = 1,
	republic = 1,
	republic_flagship = 1,
	civilian = 1,
	pirate = 1,
}

-- Source packs use very different native sizes. This cap keeps an unexpectedly
-- large model from covering a planet even when its configured scale is wrong.
gd.MaximumShipVisualRadius = gd.MaximumShipVisualRadius or {
	default = 180,
	cis_scout = 120,
	republic = 140,
	civilian = 100,
	pirate = 110,
	cis_capital = 340,
	republic_flagship = 340,
}

gd.FactionColors = gd.FactionColors or {
	republic = Color(80, 150, 235),
	cis = Color(220, 80, 70),
	civilian = Color(115, 215, 155),
	pirate = Color(225, 150, 60),
	neutral = Color(190, 190, 190),
}

-- Preferred droid NPC classes. The runtime also searches every registered NPC
-- for "battle droid", "B1", "B2" and CIS tokens before using the stock
-- Combine fallback.
gd.DroidNPCCandidates = gd.DroidNPCCandidates or {
	"npc_b1_battledroid",
	"npc_b1_battle_droid",
	"npc_battle_droid",
	"npc_cis_b1",
	"npc_vj_b1",
	"npc_combine_s",
}
gd.DroidNPCCandidatesByType = gd.DroidNPCCandidatesByType or {
	b1 = {
		"npc_cgi_b1_battledroid",
		"npc_cgi_b1",
		"npc_vj_cgi_b1",
		"npc_b1_battledroid",
		"npc_b1_battle_droid",
		"npc_battle_droid",
		"npc_cis_b1",
		"npc_vj_b1",
	},
	b2 = {
		"npc_cgi_b2_battledroid",
		"npc_cgi_b2",
		"npc_vj_cgi_b2",
		"npc_b2_battledroid",
		"npc_b2_battle_droid",
		"npc_b2_super_battle_droid",
		"npc_super_battle_droid",
		"npc_cis_b2",
		"npc_vj_b2",
	},
}
gd.DroidWeapon = gd.DroidWeapon or "weapon_ar2"
gd.DroidHealthMultiplier = gd.DroidHealthMultiplier or 1

-- These anchors can be supplemented in game from F2 -> GALAXY DIRECTOR.
-- Existing Event Enemy spawn points are also reused automatically.
gd.MapAnchors = gd.MapAnchors or {
	-- ["rp_venator_notorious"] = {
	-- 	boarding = { Vector(0, 0, 0) },
	-- 	boarding_drill = { Vector(0, 0, 0) },
	-- 	boarding_dropship = { Vector(0, 0, 0) },
	-- 	boarding_player = { Vector(0, 0, 0) },
	-- 	impact = { Vector(0, 0, 0) },
	-- 	breach_door = { Vector(0, 0, 0) },
	-- 	capital = { Vector(0, 0, 1800) },
	-- 	space_battle = { Vector(0, 0, 1800) },
	-- },
}

-- Era-safe starting points. Every planet found in SWU is available to
-- management; unlisted worlds begin neutral with zero opinion/pressure.
-- A lore lock prevents automatic CIS capture, but management may unlock it.
gd.PlanetSeeds = gd.PlanetSeeds or {
	["Coruscant"] = {
		allegiance = "republic", republicOpinion = 100, cisOpinion = -100,
		locked = true, lockFaction = "republic", note = "Clone Wars lore lock",
	},
	["Kamino"] = {
		allegiance = "republic", republicOpinion = 90, cisOpinion = -80,
		locked = true, lockFaction = "republic", note = "Clone Wars lore lock",
	},
	["Kuat"] = {
		allegiance = "republic", republicOpinion = 85, cisOpinion = -70,
		locked = true, lockFaction = "republic", note = "Republic shipyard",
	},
	["Geonosis"] = {
		allegiance = "cis", republicOpinion = -80, cisOpinion = 95,
		locked = false, note = "Separatist stronghold",
	},
	["Raxus"] = {
		allegiance = "cis", republicOpinion = -75, cisOpinion = 95,
		locked = true, lockFaction = "cis", note = "Separatist capital",
	},
	["Serenno"] = {
		allegiance = "cis", republicOpinion = -65, cisOpinion = 90,
		locked = false, note = "Count Dooku's homeworld",
	},
	["Naboo"] = {
		allegiance = "republic", republicOpinion = 80, cisOpinion = -55,
		locked = true, lockFaction = "republic", note = "Republic-aligned lore lock",
	},
	["Alderaan"] = {
		allegiance = "republic", republicOpinion = 80, cisOpinion = -60,
		locked = true, lockFaction = "republic", note = "Republic-aligned lore lock",
	},
	["Mandalore"] = {
		allegiance = "neutral", republicOpinion = 5, cisOpinion = -5,
		locked = true, lockFaction = "neutral", note = "Neutrality lore lock",
	},
}

gd.DefaultPlanet = gd.DefaultPlanet or "Deep Space"

gd.EncounterChoices = gd.EncounterChoices or {
	civilian = {
		{ id = "intel", label = "REQUEST INTELLIGENCE" },
		{ id = "trade", label = "OPEN TRADE CHANNEL" },
		{ id = "persuade", label = "ADVOCATE FOR THE REPUBLIC" },
		{ id = "continue", label = "CONTINUE ON COURSE" },
	},
	pirate = {
		{ id = "negotiate", label = "NEGOTIATE PASSAGE" },
		{ id = "surrender", label = "DEMAND THEIR SURRENDER" },
		{ id = "attack", label = "OPEN FIRE" },
		{ id = "continue", label = "BREAK CONTACT" },
	},
	republic = {
		{ id = "intel", label = "REQUEST INTELLIGENCE" },
		{ id = "repairs", label = "REQUEST REPAIRS" },
		{ id = "offer_repairs", label = "OFFER ASSISTANCE" },
		{ id = "continue", label = "CONTINUE ON COURSE" },
	},
	distress = {
		{ id = "accept", label = "ANSWER DISTRESS CALL" },
		{ id = "decline", label = "RECORD AND CONTINUE" },
	},
}
