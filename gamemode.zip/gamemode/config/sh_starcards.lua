--[[
	Star Cards - edit freely, like sh_factions.lua.

	Each card grants loadout bonuses when equipped. Restrict with
	`faction` (only that regiment) or `cert` (only holders of that cert -
	this is how "cert cards" work). Rarity is cosmetic + affects crate
	drops. Cards are unlocked from crates (config/sh_crates.lua) or
	`/givecard <player> <id>` (admin).

	Fields: name, desc, rarity (common/rare/epic/legendary), faction, cert,
	health (+max HP), armor (spawn armor), loadout (weapons), issue (items),
	attachments (ArcCW attachment_id = amount), apply(ply) [server],
	grantsText (extra tooltip line).
]]

--------------------------------------------------------------------------
-- Universal cards (any faction)
--------------------------------------------------------------------------

MilBase.RegisterStarCard("hardened_plates", {
	name = "Hardened Plates", rarity = "common",
	desc = "Reinforced kit. Tougher in a firefight.",
	health = 20,
})

MilBase.RegisterStarCard("field_supplies", {
	name = "Field Supplies", rarity = "common",
	desc = "Spawn with extra medical supplies.",
	issue = { bandage = 2, mre = 1 },
})

MilBase.RegisterStarCard("grenadier", {
	name = "Grenadier", rarity = "rare",
	desc = "Carry an extra fragmentation grenade.",
	issue = { frag = 1 },
})

MilBase.RegisterStarCard("bulwark", {
	name = "Bulwark", rarity = "rare",
	desc = "Deploy with a plate of combat shielding.",
	grantsText = "+25 armor",
	apply = function(ply)
		ply:SetArmor(math.min(100, ply:Armor() + 25))
	end,
})

--------------------------------------------------------------------------
-- Faction cards (unique to a regiment)
--------------------------------------------------------------------------

MilBase.RegisterStarCard("inf_ammo", {
	name = "Ammunition Reserve", rarity = "common", faction = "infantry",
	desc = "Infantry Corps: spawn with spare SMG magazines.",
	issue = { ammo_smg = 1 },
})

MilBase.RegisterStarCard("recon_marksman", {
	name = "Designated Marksman", rarity = "rare", faction = "recon",
	desc = "Recon Battalion: a marksman weapon in your kit.",
	loadout = { "weapon_crossbow" },
})

MilBase.RegisterStarCard("mp_breacher", {
	name = "Breacher", rarity = "rare", faction = "mp",
	desc = "Military Police: a combat shotgun for close work.",
	loadout = { "weapon_shotgun" },
})

MilBase.RegisterStarCard("cmd_sidearm", {
	name = "Command Sidearm", rarity = "epic", faction = "command",
	desc = "High Command: a heavy rifle befitting your rank.",
	loadout = { "weapon_ar2" },
})

--------------------------------------------------------------------------
-- Cert cards (only holders of a certification can equip these)
--------------------------------------------------------------------------

MilBase.RegisterStarCard("medic_stims", {
	name = "Advanced Stims", rarity = "epic", cert = "field_medic",
	desc = "Field Medic: spawn with an IFAK and painkillers.",
	issue = { ifak = 1, painkillers = 1 },
})

MilBase.RegisterStarCard("engineer_kit", {
	name = "Field Toolkit", rarity = "rare", cert = "engineer",
	desc = "Combat Engineer: spawn with a spare Repair Kit.",
	issue = { repair_kit = 1 },
})

MilBase.RegisterStarCard("saboteur_charges", {
	name = "Extra Ordnance", rarity = "epic", cert = "saboteur",
	desc = "Saboteur: spawn with extra Detonation Charges.",
	issue = { det_charge = 2 },
})
