--[[
	MilBase item definitions
	Organized version of the uploaded item file.

	Fields:
	  name, desc    - shown in the inventory tooltip
	  icon          - UI icon path
	  model         - world model used for the icon and dropped entity
	  w, h          - grid footprint in cells
	  stack         - max per stack, default 1
	  charges       - resource pool, such as medkit HP remaining
	  cert          - certification required to use the item
	  type          - item handler type, such as medical, engineering, hack
	  onUse(ply)    - custom server-side behavior. Return false to avoid consumption.

	Equipment:
	  slot        - "head", "armor", "backpack", or "jetpack"
	  armor       - armor points granted while equipped
	  playerModel - swaps the player's model while equipped
	  bodygroups  - optional bodygroup table, for example { [1] = 2 }
	  storage     - backpacks only, for example { w = 6, h = 4 }
]]

--------------------------------------------------------------------------
-- Shared equipment constants/helpers
--------------------------------------------------------------------------

local ICON_TROOPER_HELMET = "armorstore/ui/trooper_helmet.png"
local ICON_TROOPER_TORSO  = "armorstore/ui/trooper_torso.png"
local ICON_COMMAND_TORSO  = "armorstore/ui/commander_torso.png"
local ICON_BACKPACK       = "armorstore/ui/backpack_universal.png"

local MODEL_HELMET   = "models/aussiwozzi/cgi/base/helmet.mdl"
local MODEL_CHEST    = "models/aussiwozzi/cgi/base/chest.mdl"
local MODEL_BACKPACK = "models/props_junk/cardboard_box003a.mdl"

local function RegisterHelmet(id, name, armor, desc)
	MilBase.RegisterItem(id, {
		name = name,
		icon = ICON_TROOPER_HELMET,
		desc = desc,
		model = MODEL_HELMET,
		w = 2,
		h = 2,
		slot = "head",
		armor = armor,
	})
end

local function RegisterArmor(id, name, playerModel, armor, desc, icon)
	armor = armor or 30

	MilBase.RegisterItem(id, {
		name = name,
		icon = icon or ICON_COMMAND_TORSO,
		desc = desc or ("+" .. armor .. " armor while worn."),
		model = MODEL_CHEST,
		w = 3,
		h = 3,
		slot = "armor",
		armor = armor,
		playerModel = playerModel,
	})
end

local function RegisterBackpack(id, name, model, w, h, storageW, storageH, desc)
	MilBase.RegisterItem(id, {
		name = name,
		icon = ICON_BACKPACK,
		desc = desc,
		model = model,
		w = w,
		h = h,
		slot = "backpack",
		storage = { w = storageW, h = storageH },
	})
end

--------------------------------------------------------------------------
-- Medical
--------------------------------------------------------------------------

MilBase.RegisterItem("bandage", {
	name = "Bandage",
	icon = "milbase/ui/items/bandage.png",
	desc = "Stops bleeding. 3s to apply.",
	model = "models/items/healthvial.mdl",
	w = 1,
	h = 1,
	stack = 4,
	charges = 100000,
	type = "medical",
	med = { action = "bandage", time = 3 },
})

MilBase.RegisterItem("splint", {
	name = "Splint",
	icon = "milbase/ui/items/splint.png",
	desc = "Fixes a fractured leg. 5s to apply.",
	model = "models/props_junk/harpoon002a.mdl",
	w = 1,
	h = 2,
	type = "medical",
	med = { action = "splint", time = 5 },
})

MilBase.RegisterItem("painkillers", {
	name = "Painkillers",
	icon = "milbase/ui/items/painkillers.png",
	desc = "Suppresses pain for 2 minutes: no limping, clear vision.",
	model = "models/props_lab/jar01a.mdl",
	w = 1,
	h = 1,
	stack = 2,
	charges = 100000,
	type = "medical",
	med = { action = "painkillers", time = 2 },
})

MilBase.RegisterItem("ifak", {
	name = "IFAK",
	icon = "milbase/ui/items/ifak.png",
	desc = "Personal first aid kit. Restores 30 HP per use, 100 HP pool.",
	model = "models/items/healthkit.mdl",
	w = 1,
	h = 2,
	charges = 100000,
	type = "medical",
	med = { action = "heal", time = 4, heal = 30 },
})

MilBase.RegisterItem("medkit", {
	name = "Field Medkit",
	icon = "milbase/ui/items/medkit.png",
	desc = "Squad medkit. Restores 50 HP per use, 250 HP pool.",
	model = "models/props_c17/BriefCase001a.mdl",
	w = 2,
	h = 2,
	charges = 100000,
	type = "medical",
	med = { action = "heal", time = 6, heal = 50 },
})

MilBase.RegisterItem("surgical_kit", {
	name = "Surgical Kit",
	icon = "milbase/ui/items/surgical.png",
	desc = "Field surgery: restores a destroyed body part. 3 uses. Requires Field Medic certification.",
	model = "models/props_c17/SuitCase001a.mdl",
	w = 1,
	h = 2,
	charges = 100000,
	cert = "field_medic",
	type = "medical",
	med = { action = "surgery", time = 8 },
})

--------------------------------------------------------------------------
-- Helmets
--------------------------------------------------------------------------

RegisterHelmet(
	"helmet_trooper",
	"Trooper Helmet",
	10,
	"Standard issue helmet. +10 armor while worn."
)

-- Fixed old typo: helmet_trooper_reinforced)
RegisterHelmet(
	"helmet_trooper_reinforced",
	"Reinforced Trooper Helmet",
	30,
	"Modified standard issue helmet. +30 armor while worn."
)

RegisterHelmet(
	"helmet_trooper_advanced",
	"Advanced Trooper Helmet",
	50,
	"Modified reinforced helmet. +50 armor while worn."
)

--------------------------------------------------------------------------
-- Base armor
--------------------------------------------------------------------------

RegisterArmor(
	"armor_trooper",
	"Unassigned Armor",
	"models/aussiwozzi/cgi/base/unassigned_trp.mdl",
	40,
	"Standard issue plate carrier. +40 armor while worn.",
	ICON_TROOPER_TORSO
)

--------------------------------------------------------------------------
-- Legion armor: 501st Legion
--------------------------------------------------------------------------

RegisterArmor(
	"armor_501st_trp",
	"501st Trooper",
	"models/aussiwozzi/cgi/base/501st_trooper.mdl",
	30,
	"+30 armor and reinforced 501st trooper plating."
)

RegisterArmor(
	"armor_501st_nco",
	"501st NCO",
	"models/aussiwozzi/cgi/base/501st_torrent.mdl",
	30,
	"+30 armor and reinforced 501st NCO plating."
)

RegisterArmor(
	"armor_501st_officer",
	"501st Officer",
	"models/aussiwozzi/cgi/base/501st_officer.mdl",
	30,
	"+30 armor and reinforced 501st officer plating."
)

RegisterArmor(
	"armor_501st_commander",
	"501st Commander",
	"models/aussiwozzi/cgi/base/501st_appo.mdl",
	30,
	"+30 armor and commander-grade 501st plating."
)

--------------------------------------------------------------------------
-- Legion armor: 104th Wolfpack
--------------------------------------------------------------------------

RegisterArmor(
	"armor_104th_trp",
	"104th Trooper",
	"models/aussiwozzi/cgi/base/104th_trooper.mdl",
	30,
	"+30 armor and reinforced 104th trooper plating."
)

RegisterArmor(
	"armor_104th_nco",
	"104th NCO",
	"models/aussiwozzi/cgi/base/104th_sinker.mdl",
	30,
	"+30 armor and reinforced 104th NCO plating."
)

RegisterArmor(
	"armor_104th_officer",
	"104th Officer",
	"models/aussiwozzi/cgi/base/104th_officer.mdl",
	30,
	"+30 armor and reinforced 104th officer plating."
)

RegisterArmor(
	"armor_104th_commander",
	"104th Commander",
	"models/aussiwozzi/cgi/base/104th_wolffe.mdl",
	30,
	"+30 armor and commander-grade 104th Wolfpack plating."
)

--------------------------------------------------------------------------
-- Legion armor: 41st Elite Corps
--------------------------------------------------------------------------

RegisterArmor(
	"armor_41st_trp",
	"41st Trooper",
	"models/aussiwozzi/cgi/base/41st_trooper.mdl",
	30,
	"+30 armor and reinforced 41st trooper plating."
)

RegisterArmor(
	"armor_41st_nco",
	"41st NCO",
	"models/aussiwozzi/cgi/base/41st_havoc.mdl",
	30,
	"+30 armor and reinforced 41st NCO plating."
)

RegisterArmor(
	"armor_41st_officer",
	"41st Officer",
	"models/aussiwozzi/cgi/base/41st_officer.mdl",
	30,
	"+30 armor and reinforced 41st officer plating."
)

RegisterArmor(
	"armor_41st_commander",
	"41st Commander",
	"models/aussiwozzi/cgi/base/41st_gree.mdl",
	30,
	"+30 armor and commander-grade 41st Elite Corps plating."
)

--------------------------------------------------------------------------
-- Legion armor: Coruscant Guard
--------------------------------------------------------------------------

RegisterArmor(
	"armor_cg_trp",
	"CG Trooper",
	"models/aussiwozzi/cgi/base/cg_trooper.mdl",
	30,
	"+30 armor and reinforced Coruscant Guard trooper plating."
)

RegisterArmor(
	"armor_cg_nco",
	"CG NCO",
	"models/aussiwozzi/cgi/base/cg_hound.mdl",
	30,
	"+30 armor and reinforced Coruscant Guard NCO plating."
)

RegisterArmor(
	"armor_cg_officer",
	"CG Officer",
	"models/aussiwozzi/cgi/base/cg_officer.mdl",
	30,
	"+30 armor and reinforced Coruscant Guard officer plating."
)

RegisterArmor(
	"armor_cg_commander",
	"CG Commander",
	"models/aussiwozzi/cgi/base/cg_fox.mdl",
	30,
	"+30 armor and commander-grade Coruscant Guard plating."
)

--------------------------------------------------------------------------
-- Legion armor: 212th Attack Battalion
--------------------------------------------------------------------------

RegisterArmor(
	"armor_212th_trp",
	"212th Trooper",
	"models/aussiwozzi/cgi/base/212th_trooper.mdl",
	30,
	"+30 armor and reinforced 212th trooper plating."
)

RegisterArmor(
	"armor_212th_nco",
	"212th NCO",
	"models/aussiwozzi/cgi/base/212th_boil.mdl",
	30,
	"+30 armor and reinforced 212th NCO plating."
)

RegisterArmor(
	"armor_212th_officer",
	"212th Officer",
	"models/aussiwozzi/cgi/base/212th_officer.mdl",
	30,
	"+30 armor and reinforced 212th officer plating."
)

RegisterArmor(
	"armor_212th_commander",
	"212th Commander",
	"models/aussiwozzi/cgi/base/212th_cody.mdl",
	30,
	"+30 armor and commander-grade 212th Attack Battalion plating."
)

--------------------------------------------------------------------------
-- Medic armor
--------------------------------------------------------------------------

RegisterArmor(
	"armor_501st_medic",
	"501st Medic",
	"models/aussiwozzi/cgi/base/501st_medic.mdl",
	30,
	"+30 armor and reinforced 501st medic plating."
)

RegisterArmor(
	"armor_501st_medic_officer",
	"501st Medic Officer",
	"models/aussiwozzi/cgi/base/501st_medic_officer.mdl",
	30,
	"+30 armor and reinforced 501st medic officer plating."
)

RegisterArmor(
	"armor_104th_medic",
	"104th Medic",
	"models/aussiwozzi/cgi/base/104th_medic.mdl",
	30,
	"+30 armor and reinforced 104th medic plating."
)

RegisterArmor(
	"armor_104th_medic_officer",
	"104th Medic Officer",
	"models/aussiwozzi/cgi/base/104th_medic_officer.mdl",
	30,
	"+30 armor and reinforced 104th medic officer plating."
)

RegisterArmor(
	"armor_41st_medic",
	"41st Medic",
	"models/aussiwozzi/cgi/base/41st_medic.mdl",
	30,
	"+30 armor and reinforced 41st medic plating."
)

RegisterArmor(
	"armor_41st_medic_officer",
	"41st Medic Officer",
	"models/aussiwozzi/cgi/base/41st_medic_officer.mdl",
	30,
	"+30 armor and reinforced 41st medic officer plating."
)

RegisterArmor(
	"armor_cg_medic",
	"CG Medic",
	"models/aussiwozzi/cgi/base/cg_medic.mdl",
	30,
	"+30 armor and reinforced Coruscant Guard medic plating."
)

RegisterArmor(
	"armor_cg_medic_officer",
	"CG Medic Officer",
	"models/aussiwozzi/cgi/base/cg_medic_officer.mdl",
	30,
	"+30 armor and reinforced Coruscant Guard medic officer plating."
)

RegisterArmor(
	"armor_212th_medic",
	"212th Medic",
	"models/aussiwozzi/cgi/base/212th_medic.mdl",
	30,
	"+30 armor and reinforced 212th medic plating."
)

RegisterArmor(
	"armor_212th_2ndac_medic",
	"212th 2ndAC Medic",
	"models/aussiwozzi/cgi/base/212th_2ndacmedic.mdl",
	30,
	"+30 armor and reinforced 212th 2ndAC medic plating."
)

RegisterArmor(
	"armor_212th_medic_officer",
	"212th Medic Officer",
	"models/aussiwozzi/cgi/base/212th_medic_officer.mdl",
	30,
	"+30 armor and reinforced 212th medic officer plating."
)

--------------------------------------------------------------------------
-- Backpacks
--------------------------------------------------------------------------

RegisterBackpack(
	"backpack_field",
	"Field Backpack",
	MODEL_BACKPACK,
	3,
	3,
	6,
	4,
	"Adds a 6x4 backpack grid to your gear."
)

RegisterBackpack(
	"backpack_raid",
	"Raid Backpack",
	"models/props_junk/cardboard_box004a.mdl",
	3,
	4,
	8,
	5,
	"Adds an 8x5 backpack grid to your gear."
)

-- Reusable jetpack equipment. This is intentionally not certification-locked;
-- a future certification can issue the item through its normal `issue` table.
do
	local jet = (MilBase.Config and MilBase.Config.Jetpack) or {}
	local backModel = tostring(jet.BackModel or "")
	local itemModel = tostring(jet.InventoryItemModel or "")
	if itemModel == "" then itemModel = backModel ~= "" and backModel or "models/props_c17/canister01a.mdl" end

	MilBase.RegisterItem(jet.InventoryItemID or "jetpack_jt12", {
		name = jet.InventoryItemName or "JT-12 Jetpack",
		icon = jet.InventoryItemIcon or ICON_BACKPACK,
		desc = jet.InventoryItemDescription or "Reusable personal flight system. Equip it in the JETPACK gear slot.",
		model = itemModel,
		w = math.max(1, math.floor(tonumber(jet.InventoryItemWidth) or 2)),
		h = math.max(1, math.floor(tonumber(jet.InventoryItemHeight) or 3)),
		stack = 1,
		slot = "jetpack",
		jetpack = true,
		canEquip = function(ply, item)
			if not MilBase.CanEquipJetpack then return false, "Jetpack systems are unavailable." end
			return MilBase.CanEquipJetpack(ply, item)
		end,
		canUnequip = function(ply)
			if not ply:OnGround() then return false, "Land before removing the jetpack." end
			return true
		end,
	})
end

--------------------------------------------------------------------------
-- Slicing, sabotage, and utility
--------------------------------------------------------------------------

MilBase.RegisterItem("slicer_kit", {
	name = "Slicer Kit",
	desc = "A datapad for slicing LVS vehicles: crouch + hold E on an allowed ship to commandeer it.",
	model = "models/props_lab/binderblue.mdl",
	w = 1,
	h = 2,
	type = "hack",
})

MilBase.RegisterItem("det_charge", {
	name = "Detonation Charge",
	desc = "Plant on a ship's weak point (aim at it, press E). Detonate from the self-menu (hold G). Requires Saboteur.",
	model = "models/weapons/w_slam.mdl",
	w = 1,
	h = 1,
	stack = 4,
	cert = "saboteur",
	type = "sabotage",
})

MilBase.RegisterItem("magboots", {
	name = "Magnetic Boots",
	desc = "Toggle in the self-menu (hold G) to lock to the deck and walk normally in zero-g.",
	model = "models/props_c17/TrapPropeller_Engine.mdl",
	w = 2,
	h = 1,
	type = "magboots",
})

--------------------------------------------------------------------------
-- Bio-warfare
--------------------------------------------------------------------------

MilBase.RegisterItem("sample_kit", {
	name = "Bio Sample Kit",
	desc = "Take a blood/saliva sample from an infected patient (C + right-click them). Analyze at a Bio-Analyzer.",
	model = "models/props_lab/box01a.mdl",
	w = 1,
	h = 2,
})

MilBase.RegisterItem("cure", {
	name = "Cure Serum",
	desc = "Cures an infection. C + right-click an infected patient to administer.",
	model = "models/props_lab/jar01a.mdl",
	w = 1,
	h = 1,
	stack = 5,
})

MilBase.RegisterItem("cure_canister", {
	name = "Cure Canister",
	desc = "Release into the vents (self-menu, hold G): cures everyone whose suit isn't sealed.",
	model = "models/props_lab/reciever01b.mdl",
	w = 2,
	h = 2,
})

--------------------------------------------------------------------------
-- Engineering: LVS vehicles
--------------------------------------------------------------------------

MilBase.RegisterItem("repair_kit", {
	name = "Repair Kit",
	icon = "milbase/ui/items/repair.png",
	desc = "Repairs LVS vehicles: 200 hull per use, 600 pool. Rebuilds wrecks. Requires Combat Engineer.",
	model = "models/props_c17/tools_wrench01a.mdl",
	w = 2,
	h = 2,
	charges = 600,
	cert = "engineer",
	type = "engineering",
	eng = { action = "repair", amount = 200, time = 6 },
})

MilBase.RegisterItem("fuel_can", {
	name = "Jerry Can",
	icon = "milbase/ui/items/fuel.png",
	desc = "Refuels LVS vehicles: up to 50% tank per use. Requires Combat Engineer.",
	model = "models/props_junk/gascan001a.mdl",
	w = 1,
	h = 2,
	charges = 100,
	cert = "engineer",
	type = "engineering",
	eng = { action = "fuel", amount = 50, time = 4 },
})

--------------------------------------------------------------------------
-- Sustenance and supplies
--------------------------------------------------------------------------

MilBase.RegisterItem("mre", {
	name = "MRE",
	icon = "milbase/ui/items/mre.png",
	desc = "Meal, Ready-to-Eat. Restores a little health.",
	model = "models/props_junk/garbage_metalcan001a.mdl",
	w = 1,
	h = 1,
	stack = 3,
	onUse = function(ply)
		ply:SetHealth(math.min(ply:GetMaxHealth(), ply:Health() + 10))
		ply:EmitSound("physics/cardboard/cardboard_box_impact_soft2.wav")
		MilBase.Notify(ply, "You eat the MRE. Tastes like 2009.")
	end,
})

MilBase.RegisterItem("ammo_smg", {
	name = "SMG Magazines",
	desc = "Three spare SMG magazines (+90).",
	model = "models/items/boxmrounds.mdl",
	w = 1,
	h = 1,
	stack = 3,
	onUse = function(ply)
		ply:GiveAmmo(90, "SMG1")
		ply:EmitSound("items/ammo_pickup.wav")
	end,
})

MilBase.RegisterItem("ammo_pistol", {
	name = "Pistol Magazines",
	desc = "Spare pistol ammunition (+54).",
	model = "models/items/boxsrounds.mdl",
	w = 1,
	h = 1,
	stack = 3,
	onUse = function(ply)
		ply:GiveAmmo(54, "Pistol")
		ply:EmitSound("items/ammo_pickup.wav")
	end,
})

MilBase.RegisterItem("frag", {
	name = "Frag Grenade",
	desc = "One fragmentation grenade.",
	model = "models/weapons/w_grenade.mdl",
	w = 1,
	h = 1,
	stack = 2,
	onUse = function(ply)
		if ply:HasWeapon("weapon_frag") then
			ply:GiveAmmo(1, "Grenade")
		else
			ply:Give("weapon_frag")
		end

		ply:EmitSound("items/ammo_pickup.wav")
	end,
})
