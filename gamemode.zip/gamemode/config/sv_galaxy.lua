--[[
	Server-only Galaxy Director secrets.

	Do not move the webhook into sh_galaxy.lua: shared files are downloaded by
	clients. Leave the URL blank to disable Discord delivery.
]]

MilBase.Config.GalaxyDiscord = MilBase.Config.GalaxyDiscord or {
	Enabled = true,
	WebhookURL = "https://discord.com/api/webhooks/1532464434629443756/DyM_0FJsiVKUBxmsPz8ZCcnMEQBrSTrmV9l1-pYAkTHWrIuEVEX6RzZgmc4kSuJpF-q1",
	RoleID = "1337915803390971984",
	Username = "Republic Strategic Command",
	AvatarURL = "",
	MentionOnAttack = true,
	MentionOnPlanetFall = true,
	MinimumSecondsBetweenPosts = 20,
}
