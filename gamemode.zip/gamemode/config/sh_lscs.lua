--[[
	MilBase x LSCS integration.

	The skill tree is intentionally data-driven: add, remove, or rebalance nodes
	here without touching the persistence, admin, or UI modules. An `item` is an
	LSCS entity class and is granted/equipped when the node is learned.

	Supported effects:
	  maxForce     flat Force-capacity bonus
	  forceRegen   flat LSCS regeneration-per-tick bonus
	  saberDamage  outgoing LSCS saber damage multiplier bonus (0.05 = 5%)
	  saberDefense incoming LSCS saber damage reduction (0.05 = 5%)

	Optional node gates:
	  minJediLevel  1 Initiate -> 5 Council
	  minAlignment  minimum Light-side score
	  maxAlignment  maximum Dark-side score (for example -25)
	  trial          completed trial id required
	  holocron       discovered holocron id required
	  active         power consumes an active Force-loadout slot
]]

local cfg = MilBase.Config

cfg.LSCS = {
	Enabled = true,
	PersistInventory = true,
	BootstrapInterval = 0.5, -- seconds between LSCS readiness/restore retries
	BootstrapAttempts = 30, -- 15-second recovery window for DB/addon load races
	HideDefaultHUD = true,
	HUDEnabled = true,
	HUDAlways = false, -- false: fade away while Force is full and no saber is held

	AdminLevel = 3,
	StartingPoints = 3,
	XPPerPoint = 500,
	BaseMaxForce = 100,
	BaseForceRegen = 1,
	MaxPoints = 9999,
	ForceSlots = 4,
	AllowUnmanagedForcePowers = false,
	PresetSlots = 3,
	RespecCooldown = 21600, -- six hours
	WorkbenchUseTime = 120,
	MasterLevel = 4,
	PadawanMaxLevel = 2,
	AuditRetention = 50,
	WorkbenchModel = "models/props_combine/combine_interface001.mdl",
	HolocronModel = "models/props_lab/reciever01b.mdl",

	JediLevels = {
		[1] = "Initiate",
		[2] = "Padawan",
		[3] = "Knight",
		[4] = "Master",
		[5] = "Council",
	},

	-- Small alignment changes are earned through actual Force use. Larger
	-- changes can be awarded through trials, events, or the Jedi admin panel.
	PowerAlignmentShift = {
		item_force_heal = 1,
		item_force_replenish = 1,
		item_force_immunity = 1,
		item_force_throw = -1,
		item_force_lightning = -2,
	},

	Trials = {
		control_basics = {
			name = "Trial of Control", description = "Perform eight controlled Force Jumps.",
			event = "force_use", match = { item_force_jump = true }, target = 8,
			minLevel = 1, mentorApproval = true, rewardAlignment = 10,
		},
		healer = {
			name = "Trial of Compassion", description = "Use Force Heal ten times.",
			event = "force_use", match = { item_force_heal = true }, target = 10,
			minLevel = 2, mentorApproval = true, rewardAlignment = 15,
		},
		saber = {
			name = "Trial of the Blade", description = "Land twenty-five lightsaber strikes.",
			event = "saber_hit", target = 25,
			minLevel = 2, mentorApproval = true, rewardAlignment = 0,
		},
		wisdom = {
			name = "Trial of Insight", description = "Study two distinct holocrons.",
			event = "holocron", target = 2,
			minLevel = 2, mentorApproval = true, rewardAlignment = 5,
		},
	},

	Holocrons = {
		guardian = { name = "Guardian Holocron", color = Color(90, 150, 255) },
		consular = { name = "Consular Holocron", color = Color(90, 220, 140) },
		sentinel = { name = "Sentinel Holocron", color = Color(255, 205, 75) },
		shadow = { name = "Shadow Holocron", color = Color(190, 80, 235) },
	},

	-- Jedi eligibility always comes from `jedi = true` in sh_factions.lua.
	-- This optional list can further restrict which Jedi factions start enabled;
	-- it can never grant Force access to a non-Jedi faction.
	AllowedFactions = nil,

	Branches = {
		{ id = "control", name = "FORCE CONTROL", color = Color(80, 155, 235) },
		{ id = "vitality", name = "FORCE RESERVES", color = Color(160, 175, 205) },
		{ id = "light", name = "LIGHT SIDE", color = Color(125, 205, 145) },
		{ id = "dark", name = "DARK SIDE", color = Color(205, 80, 115) },
		{ id = "saber", name = "SABER FORMS", color = Color(255, 198, 60) },
	},

	Nodes = {
		force_sensitivity = {
			name = "Force Sensitivity", branch = "control", row = 1, cost = 1,
			description = "Open yourself to the Force and increase your reserves.",
			minJediLevel = 1,
			effects = { maxForce = 20 },
		},
		force_jump = {
			name = "Force Jump", branch = "control", row = 2, cost = 1,
			description = "Unlock the LSCS Jump power.",
			requires = { "force_sensitivity" }, item = "item_force_jump", active = true,
			minJediLevel = 1,
		},
		force_push = {
			name = "Force Push", branch = "control", row = 3, cost = 2,
			description = "Unlock the LSCS Push power.",
			requires = { "force_jump" }, item = "item_force_push", active = true,
			minJediLevel = 2, trial = "control_basics",
		},
		force_pull = {
			name = "Force Pull", branch = "control", row = 4, cost = 2,
			description = "Unlock the LSCS Pull power.",
			requires = { "force_push" }, item = "item_force_pull", active = true,
			minJediLevel = 2, trial = "control_basics",
		},
		force_throw = {
			name = "Telekinetic Throw", branch = "control", row = 5, cost = 3,
			description = "Unlock the LSCS Throw power.",
			requires = { "force_pull" }, item = "item_force_throw", active = true,
			minJediLevel = 3, trial = "control_basics",
		},
		force_sense = {
			name = "Battle Meditation", branch = "control", row = 6, cost = 3,
			description = "Unlock Force Sense and gain another 20 Force.",
			requires = { "force_throw" }, item = "item_force_sense", active = true,
			minJediLevel = 3, trial = "wisdom",
			effects = { maxForce = 20 },
		},
		consular_legacy = {
			name = "Consular Legacy", branch = "control", row = 7, cost = 4,
			description = "Study the Consular Holocron to deepen Force recovery.",
			requires = { "force_sense" }, minJediLevel = 3, trial = "wisdom",
			holocron = "consular", effects = { forceRegen = 0.5, maxForce = 15 },
		},

		force_focus = {
			name = "Focused Mind", branch = "vitality", row = 1, cost = 1,
			description = "Recover Force energy more quickly.",
			minJediLevel = 1,
			effects = { forceRegen = 0.25 },
		},
		deep_reserves = {
			name = "Deep Reserves", branch = "vitality", row = 2, cost = 2,
			description = "Increase maximum Force and regeneration.",
			requires = { "force_focus" }, minJediLevel = 2,
			effects = { maxForce = 35, forceRegen = 0.25 },
		},
		force_heal = {
			name = "Force Heal", branch = "light", row = 1, cost = 3,
			description = "Unlock the LSCS Heal power.",
			requires = { "deep_reserves" }, item = "item_force_heal", active = true,
			minJediLevel = 2, minAlignment = 10,
		},
		force_replenish = {
			name = "Replenish", branch = "light", row = 2, cost = 3,
			description = "Unlock the LSCS Replenish power.",
			requires = { "force_heal" }, item = "item_force_replenish", active = true,
			minJediLevel = 3, minAlignment = 25, trial = "healer",
		},
		force_immunity = {
			name = "Force Immunity", branch = "light", row = 3, cost = 4,
			description = "Unlock the LSCS Immunity power.",
			requires = { "force_replenish" }, item = "item_force_immunity", active = true,
			minJediLevel = 4, minAlignment = 40, trial = "healer",
			effects = { saberDefense = 0.05 },
		},
		guardian_legacy = {
			name = "Guardian Legacy", branch = "light", row = 4, cost = 4,
			description = "Study the Guardian Holocron to strengthen your defenses.",
			requires = { "force_immunity" }, minJediLevel = 4, trial = "healer",
			holocron = "guardian", effects = { saberDefense = 0.10 },
		},

		shadow_discipline = {
			name = "Shadow Discipline", branch = "dark", row = 1, cost = 2,
			description = "Embrace controlled aggression to sharpen Force recovery.",
			requires = { "force_push" }, minJediLevel = 2, maxAlignment = -10,
			effects = { forceRegen = 0.25 },
		},
		dark_reserves = {
			name = "Dark Reserves", branch = "dark", row = 2, cost = 3,
			description = "Draw deeper reserves from the Dark Side.",
			requires = { "shadow_discipline", "force_throw" }, minJediLevel = 3, maxAlignment = -20,
			effects = { maxForce = 30 },
		},
		force_lightning = {
			name = "Force Lightning", branch = "dark", row = 3, cost = 5,
			description = "Unlock LSCS Lightning. Server rules may restrict its use.",
			requires = { "dark_reserves" }, item = "item_force_lightning", active = true,
			minJediLevel = 3, maxAlignment = -25, holocron = "shadow",
		},

		saber_training = {
			name = "Saber Training", branch = "saber", row = 1, cost = 1,
			description = "Learn the fundamentals and deal 5% more saber damage.", minJediLevel = 1,
			effects = { saberDamage = 0.05 },
		},
		juggernaut_stance = {
			name = "Juggernaut Form", branch = "saber", row = 2, cost = 2,
			description = "Unlock the heavy Juggernaut LSCS stance.",
			requires = { "saber_training" }, item = "item_stance_juggernaut",
			minJediLevel = 2,
		},
		butterfly_stance = {
			name = "Butterfly Form", branch = "saber", row = 3, cost = 3,
			description = "Unlock the agile Butterfly LSCS stance.",
			requires = { "juggernaut_stance" }, item = "item_stance_butterfly",
			minJediLevel = 3, trial = "saber",
		},
		yongli_stance = {
			name = "YongLi Form", branch = "saber", row = 4, cost = 4,
			description = "Unlock the advanced YongLi LSCS stance.",
			requires = { "butterfly_stance" }, item = "item_stance_yongli",
			minJediLevel = 3, trial = "saber",
		},
		saber_ward = {
			name = "Saber Ward", branch = "saber", row = 5, cost = 4,
			description = "Reduce incoming lightsaber damage by 10%.",
			requires = { "yongli_stance" }, minJediLevel = 4, trial = "saber",
			effects = { saberDefense = 0.10 },
		},
		saber_mastery = {
			name = "Saber Mastery", branch = "saber", row = 6, cost = 5,
			description = "Deal a further 15% lightsaber damage.",
			requires = { "saber_ward" }, minJediLevel = 4, trial = "saber",
			effects = { saberDamage = 0.15 },
		},
		sentinel_legacy = {
			name = "Sentinel Legacy", branch = "saber", row = 7, cost = 4,
			description = "Study the Sentinel Holocron to refine your saber technique.",
			requires = { "saber_mastery" }, minJediLevel = 4, trial = "saber",
			holocron = "sentinel", effects = { saberDamage = 0.10 },
		},
	},
}
