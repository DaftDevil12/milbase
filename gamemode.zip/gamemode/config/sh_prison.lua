-- Persistent shipboard detention and allied-prison transfer configuration.
MilBase.Config.Prison = MilBase.Config.Prison or {}
local p = MilBase.Config.Prison

p.Enabled = p.Enabled ~= false
p.SetupStaffLevel = p.SetupStaffLevel or 6
p.CommandStaffLevel = p.CommandStaffLevel or 3
p.StandardCellCapacity = p.StandardCellCapacity or 2
p.MaximumPrisoners = p.MaximumPrisoners or 48
p.MaximumIncidentHistory = p.MaximumIncidentHistory or 80
p.StateSaveDelay = p.StateSaveDelay or 2
p.NeedsTickSeconds = p.NeedsTickSeconds or 30
p.SecurityTickSeconds = p.SecurityTickSeconds or 15
p.AISleepDistance = p.AISleepDistance or 2200
p.InteractionDistance = p.InteractionDistance or 190
p.EscortFollowDistance = p.EscortFollowDistance or 88
p.EscortStopDistance = p.EscortStopDistance or 76
p.EscortResumeDistance = p.EscortResumeDistance or 120
p.EscortJogDistance = p.EscortJogDistance or 185
p.EscortCatchUpDistance = p.EscortCatchUpDistance or 340
p.EscortCatchUpSpeed = p.EscortCatchUpSpeed or 310
p.EscortMaximumSpeed = p.EscortMaximumSpeed or 340
p.EscortBreadcrumbSpacing = p.EscortBreadcrumbSpacing or 52
p.EscortBreadcrumbReachDistance = p.EscortBreadcrumbReachDistance or 28
p.EscortBreakDistance = p.EscortBreakDistance or 850
p.EscortAssistDistance = p.EscortAssistDistance or 520
p.RequireTwoGuardsForCritical = p.RequireTwoGuardsForCritical ~= false
p.PrisonerWalkSpeed = p.PrisonerWalkSpeed or 165
p.PrisonerRunSpeed = p.PrisonerRunSpeed or 265
p.PrisonerAcceleration = p.PrisonerAcceleration or 850
p.PrisonerDeceleration = p.PrisonerDeceleration or 680
p.PrisonerStepHeight = p.PrisonerStepHeight or 22
p.PrisonerTurnRate = p.PrisonerTurnRate or 320
p.MovementArrivalDistance = p.MovementArrivalDistance or 24
p.MovementDynamicArrivalDistance = p.MovementDynamicArrivalDistance or 14
p.MovementRepathSeconds = p.MovementRepathSeconds or 0.4
p.MovementTargetRepathDistance = p.MovementTargetRepathDistance or 40
p.MovementLookAheadDistance = p.MovementLookAheadDistance or 135
p.MovementGoalTolerance = p.MovementGoalTolerance or 20
p.MovementSlowRadius = p.MovementSlowRadius or 92
p.MovementMinimumSpeed = p.MovementMinimumSpeed or 72
p.MovementNudgeDistance = p.MovementNudgeDistance or 56
p.PathNodeLinkDistance = p.PathNodeLinkDistance or 760
p.PathNodeStartDistance = p.PathNodeStartDistance or 900
p.PathNodeVerticalTolerance = p.PathNodeVerticalTolerance or 180
p.LocalAvoidanceRadius = p.LocalAvoidanceRadius or 58
p.ActivitySlotSpacing = p.ActivitySlotSpacing or 54
p.ActivitySlotColumns = p.ActivitySlotColumns or 4
p.StuckCheckSeconds = p.StuckCheckSeconds or 1.25
p.StuckMinimumProgress = p.StuckMinimumProgress or 16
p.StuckRecoverySeconds = p.StuckRecoverySeconds or 7
p.SafeRelocationHiddenRadius = p.SafeRelocationHiddenRadius or 650
p.DoorApproachDistance = p.DoorApproachDistance or 190
p.DoorClearDistance = p.DoorClearDistance or 105
p.DoorOpenWaitSeconds = p.DoorOpenWaitSeconds or 0.45
p.RouteDoorCloseSeconds = p.RouteDoorCloseSeconds or 3
p.RouteDoorsRelock = p.RouteDoorsRelock ~= false
p.PrisonerMeleeDamage = p.PrisonerMeleeDamage or 8
p.PrisonerMeleeCooldown = p.PrisonerMeleeCooldown or 1.1
p.PrisonerHealth = p.PrisonerHealth or 100
p.PrisonerVoiceResponses = p.PrisonerVoiceResponses ~= false
p.LanguageTranslatorRadius = p.LanguageTranslatorRadius or 320
p.LanguageSpeechRadius = p.LanguageSpeechRadius or 720
p.LanguageSpeechMinimumDelay = p.LanguageSpeechMinimumDelay or 38
p.LanguageSpeechMaximumDelay = p.LanguageSpeechMaximumDelay or 82
p.LanguageSpeechDuration = p.LanguageSpeechDuration or 6
p.CinematicInterviews = p.CinematicInterviews ~= false
p.CinematicInterviewDistance = p.CinematicInterviewDistance or 230
p.AmbientPrisonerSpeech = p.AmbientPrisonerSpeech ~= false
p.LayoutMarkerDrawDistance = p.LayoutMarkerDrawDistance or 3500
p.GuardPresenceRadius = p.GuardPresenceRadius or 900
p.TransferResponseMinimum = p.TransferResponseMinimum or 4
p.TransferResponseMaximum = p.TransferResponseMaximum or 9
p.TransferBoardingTimeout = p.TransferBoardingTimeout or 600
p.TransferTravelMinimum = p.TransferTravelMinimum or 90
p.TransferTravelMaximum = p.TransferTravelMaximum or 300
p.TransferTransportModel = p.TransferTransportModel or "models/blu/laat.mdl"
p.TransferPickupFlightSpeed = p.TransferPickupFlightSpeed or 420
p.TransferPickupBoardingRadius = p.TransferPickupBoardingRadius or 180
p.TransferPickupApproachDistance = p.TransferPickupApproachDistance or 1800
p.TransferPickupApproachHeight = p.TransferPickupApproachHeight or 520
p.TransferPickupDepartureDelay = p.TransferPickupDepartureDelay or 2
p.TransferPickupArrivalTimeout = p.TransferPickupArrivalTimeout or 300
p.TransferHangarGroup = p.TransferHangarGroup or ((MilBase.Config.SmugglingInspections or {}).InspectionHangarGroup or "main")
p.UseNavalLaunchRoute = p.UseNavalLaunchRoute ~= false
p.ConsumeNavalSupplies = p.ConsumeNavalSupplies ~= false
p.FoodSupplyCost = p.FoodSupplyCost or 1
p.MealsPerCollection = p.MealsPerCollection or 6
p.WaterUnitsPerCollection = p.WaterUnitsPerCollection or 10
p.MaximumCarriedMeals = p.MaximumCarriedMeals or 12
p.MaximumCarriedWater = p.MaximumCarriedWater or 20
p.WaterSupplyCost = p.WaterSupplyCost or 0
p.AutomaticLowPopulationCare = p.AutomaticLowPopulationCare ~= false
p.AutomaticCareMaximumPlayers = p.AutomaticCareMaximumPlayers or 4
p.AutomaticCareMinimumNeed = p.AutomaticCareMinimumNeed or 22
p.RiotMinimumPrisoners = p.RiotMinimumPrisoners or 3
p.RiotBaseChance = p.RiotBaseChance or 0.012
p.TakeoverMinimumRioters = p.TakeoverMinimumRioters or 3
p.TakeoverObjectiveHoldSeconds = p.TakeoverObjectiveHoldSeconds or 24
p.TakeoverCaptureRadius = p.TakeoverCaptureRadius or 190
p.TakeoverGuardContestRadius = p.TakeoverGuardContestRadius or 240
p.TakeoverRetakeDistance = p.TakeoverRetakeDistance or 220
p.TakeoverArmedDamageMultiplier = p.TakeoverArmedDamageMultiplier or 1.6
p.TakeoverProgressPerRiot = p.TakeoverProgressPerRiot or 0.35
p.IncidentWarningMinimum = p.IncidentWarningMinimum or 25
p.IncidentWarningMaximum = p.IncidentWarningMaximum or 55
p.IncidentCooldownSeconds = p.IncidentCooldownSeconds or 90
p.ContrabandMoveChance = p.ContrabandMoveChance or 0.14
p.CommandCooldownSeconds = p.CommandCooldownSeconds or 0.65
p.MaximumPrisonerMemories = p.MaximumPrisonerMemories or 24
p.CameraRange = p.CameraRange or 1100
p.CameraFOV = p.CameraFOV or 78
p.CameraScanSeconds = p.CameraScanSeconds or 0.5
p.CameraAlertCooldown = p.CameraAlertCooldown or 8
p.AlarmAutoClearSeconds = p.AlarmAutoClearSeconds or 180
p.LockdownDefaultSeconds = p.LockdownDefaultSeconds or 600
p.CriticalOvercrowdingRatio = p.CriticalOvercrowdingRatio or 1.5
p.SevereOvercrowdingRatio = p.SevereOvercrowdingRatio or 1.2
p.MildOvercrowdingRatio = p.MildOvercrowdingRatio or 1.01
p.IsolationCapacity = p.IsolationCapacity or 1
p.OverflowRiotMultiplier = p.OverflowRiotMultiplier or 2.5
p.NeglectDamageEnabled = p.NeglectDamageEnabled ~= false
p.WaterCriticalThreshold = p.WaterCriticalThreshold or 8
p.FoodCriticalThreshold = p.FoodCriticalThreshold or 5
p.ScheduleAutomatic = p.ScheduleAutomatic ~= false
p.Schedule = p.Schedule or {
	{ id = "lockdown", label = "NIGHT LOCKDOWN", seconds = 600 },
	{ id = "rollcall", label = "MORNING ROLL CALL", seconds = 120 },
	{ id = "meal", label = "BREAKFAST / WATER", seconds = 240 },
	{ id = "cell_search", label = "CELL INSPECTIONS", seconds = 180 },
	{ id = "social", label = "SOCIAL / EXERCISE", seconds = 420 },
	{ id = "meal", label = "MIDDAY MEAL", seconds = 240 },
	{ id = "interviews", label = "INTERVIEWS / MEDICAL", seconds = 300 },
	{ id = "work", label = "PRISON WORK PERIOD", seconds = 360 },
	{ id = "meal", label = "EVENING MEAL", seconds = 240 },
	{ id = "rollcall", label = "FINAL ROLL CALL", seconds = 120 },
}

p.RiskLevels = p.RiskLevels or {
	low = { label = "LOW", weight = 1 },
	medium = { label = "MEDIUM", weight = 2 },
	high = { label = "HIGH", weight = 3 },
	critical = { label = "CRITICAL", weight = 4 },
}

p.PrisonerTraits = p.PrisonerTraits or {
	"cooperative", "nervous", "aggressive", "manipulative", "loyal",
	"self_serving", "cowardly", "ideological", "takeover_planner",
	"riot_leader", "informant", "patient", "unstable",
}

-- CGI Civilian Pack by OkFellow:
-- https://steamcommunity.com/sharedfiles/filedetails/?id=2997442699
--
-- These are player-manager aliases published by the addon, not copied model
-- paths. At runtime the server resolves only aliases that the mounted addon
-- actually registered. Missing content safely falls back to the old model.
p.PrisonerWorkshopID = p.PrisonerWorkshopID or "2997442699"
p.UseCivilianPackPrisonerModels = p.UseCivilianPackPrisonerModels ~= false
p.DefaultPrisonerModel = p.DefaultPrisonerModel or "models/Humans/Group03/male_07.mdl"
if p.UseCivilianPackPrisonerModels and tostring(p.PrisonerWorkshopID) ~= "" then
	MilBase.Config.WorkshopContent = MilBase.Config.WorkshopContent or {}
	local listed = false
	for _, workshopID in ipairs(MilBase.Config.WorkshopContent) do
		if tostring(workshopID) == tostring(p.PrisonerWorkshopID) then listed = true break end
	end
	if not listed then
		MilBase.Config.WorkshopContent[#MilBase.Config.WorkshopContent + 1]
			= tostring(p.PrisonerWorkshopID)
	end
end
p.PrisonerSpeciesWeights = p.PrisonerSpeciesWeights or {
	human = 58,
	wookiee = 9,
	twilek = 15,
	togruta = 9,
	zabrak = 9,
}

p.PrisonerAmbientLines = p.PrisonerAmbientLines or {
	default = {
		"How long are you keeping us aboard this ship?",
		"I want the detention record reviewed.",
		"The guards have changed shifts again.",
		"Tell me when the next meal period begins.",
	},
	incarcerated = {
		"This cell is not a permanent answer.",
		"I need to speak with someone about my case.",
		"When is the next exercise period?",
	},
	needs = {
		"I need water and medical attention.",
		"The conditions in this block are getting worse.",
		"I have requested food more than once.",
	},
	rioting = {
		"The cell block belongs to us now!",
		"Push forward and take the ship!",
		"Do not let the guards retake this section!",
	},
	transfer_ready = {
		"Is the planetary transport here yet?",
		"I was told another facility accepted custody.",
	},
}

p.InitialNeeds = p.InitialNeeds or {
	food = 78,
	water = 82,
	sleep = 72,
	hygiene = 75,
	social = 65,
	medical = 100,
}

p.NeedDecayPerTick = p.NeedDecayPerTick or {
	food = 0.9,
	water = 1.35,
	sleep = 0.55,
	hygiene = 0.38,
	social = 0.65,
}

p.AlliedPrisons = p.AlliedPrisons or {
	coruscant = {
		name = "Coruscant Judicial Detention Centre",
		planet = "Coruscant",
		security = 4,
		capacity = 160,
		acceptedRisk = { low = true, medium = true, high = true, critical = true },
		travelSeconds = 180,
	},
	naboo = {
		name = "Naboo Royal Security Prison",
		planet = "Naboo",
		security = 2,
		capacity = 48,
		acceptedRisk = { low = true, medium = true, high = true },
		travelSeconds = 130,
	},
	kuat = {
		name = "Kuat Sector Holding Facility",
		planet = "Kuat",
		security = 3,
		capacity = 72,
		acceptedRisk = { low = true, medium = true, high = true, critical = false },
		travelSeconds = 155,
	},
	alderaan = {
		name = "Alderaan Civil Detention Service",
		planet = "Alderaan",
		security = 1,
		capacity = 36,
		acceptedRisk = { low = true, medium = true },
		travelSeconds = 145,
	},
}

p.LayoutKinds = p.LayoutKinds or {
	-- Facility workflow.
	"entrance", "intake", "search", "property", "mugshot", "guard_control",
	"alarm", "transfer", "transfer_laat", "transfer_boarding", "exit", "overflow", "food_store", "water_store",
	"social", "exercise", "shower", "medical", "interview", "work",
	"isolation", "path_node", "route_door", "camera", "guard_post", "riot_response",
	"takeover_armory", "takeover_engineering", "takeover_comms", "takeover_bridge",
	-- Per-cell markers. The tool's cell_id groups these together.
	"cell_origin", "cell_corner_a", "cell_corner_b", "cell_spawn_1", "cell_spawn_2",
	"cell_bed_1", "cell_bed_2", "cell_sit_1", "cell_sit_2", "cell_toilet",
	"cell_food", "cell_water", "cell_search", "cell_observe", "cell_door",
}

p.LayoutLabels = p.LayoutLabels or {
	entrance = "Prison entrance", intake = "Intake processing", search = "Prisoner search",
	property = "Property storage", mugshot = "Identification / mugshot", guard_control = "Guard control",
	alarm = "Prison alarm", transfer = "Transfer guard staging",
	transfer_laat = "Transfer LAAT landing position",
	transfer_boarding = "Transfer LAAT boarding ramp",
	exit = "Custody exit",
	overflow = "Overflow holding", food_store = "Meal collection", water_store = "Water collection",
	social = "Social area", exercise = "Exercise area", shower = "Shower area", medical = "Medical area",
	interview = "Interview room", work = "Prison work area", isolation = "Isolation cell",
	path_node = "Prison movement node", route_door = "Linked prison route door",
	camera = "Prison surveillance camera", guard_post = "Guard post",
	takeover_armory = "Takeover objective: armory",
	takeover_engineering = "Takeover objective: engineering",
	takeover_comms = "Takeover objective: communications",
	takeover_bridge = "Takeover objective: bridge",
	riot_response = "Riot response point", cell_origin = "Cell centre", cell_corner_a = "Cell volume corner A",
	cell_corner_b = "Cell volume corner B", cell_spawn_1 = "Prisoner position 1", cell_spawn_2 = "Prisoner position 2",
	cell_bed_1 = "Bed 1", cell_bed_2 = "Bed 2", cell_sit_1 = "Seat 1", cell_sit_2 = "Seat 2",
	cell_toilet = "Toilet", cell_food = "Meal hatch", cell_water = "Water point",
	cell_search = "Cell search position", cell_observe = "Observation point", cell_door = "Linked cell door",
}

-- Prison operations are handled via physical Security Terminals (mb_prison_terminal),
-- Guard Desk NPCs, and 3D Inmate Radial Interactions.
-- Global Datapad remains clean for Fleet Roster, Medical, Warrants, and Customs.
