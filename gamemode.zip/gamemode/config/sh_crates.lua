--[[
	Crates - edit freely. Opened from the CRATES tab in the F4 menu.

	Fields:
	  cost     - credits to open (0 = free)
	  item     - optional inventory item consumed to open (e.g. a found crate)
	  rewards  - how many pulls per open
	  loot     - weighted reward table. Entry types:
	     { type = "card",    weight = n, pool = {...ids}, fallback = credits }
	     { type = "item",       id = "ifak", amount = 1, weight = n }
	     { type = "attachment", id = "optic_id", amount = 1, weight = n }
	     { type = "weapon",     id = "weapon_class", fallback = credits, weight = n }
	     { type = "credits",    min = n, max = n, weight = n }
	     { type = "booster", mult = 1.5, duration = 3600, weight = n }
]]

MilBase.RegisterCrate("supply_crate", {
	name = "Supply Crate",
	tier = 1,              -- 1-4, drives the crate icon/colour in the CRATES tab
	cost = 300,
	rewards = 1,
	loot = {
		{ type = "card",    weight = 25, fallback = 150 },
		{ type = "credits", min = 50,  max = 250, weight = 40 },
		{ type = "item",    id = "ifak",       amount = 1, weight = 12 },
		{ type = "item",    id = "frag",       amount = 2, weight = 8 },
		{ type = "booster", mult = 1.5, duration = 1800,   weight = 15 },
	},
})

MilBase.RegisterCrate("war_chest", {
	name = "War Chest",
	tier = 3,
	cost = 1200,
	rewards = 3,
	loot = {
		{ type = "card",    weight = 40, fallback = 300 },
		{ type = "credits", min = 200, max = 600, weight = 25 },
		{ type = "item",    id = "medkit",  amount = 1, weight = 10 },
		{ type = "item",    id = "surgical_kit", amount = 1, weight = 5 },
		{ type = "booster", mult = 2,   duration = 3600, weight = 20 },
	},
})
