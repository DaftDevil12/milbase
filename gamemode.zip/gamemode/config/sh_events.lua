--[[
	Event tool settings.

	The palette AUTO-DETECTS every spawnmenu NPC and every installed LVS
	vehicle, grouped by their own categories - you don't have to list them.
	Add VJ Base / Zombie / clone-trooper NPC packs or LVS vehicle packs and
	they simply appear.

	Open the event view in game with /event (staff level >= EventStaffLevel).
]]

-- Minimum staff level to use the event tool (see config/sh_staff.lua):
--   1 Trial Mod  2 Mod  3 Admin  4 Head Admin  5 Dev  6 Management  7 Owner
MilBase.Config.EventStaffLevel = 3

-- Auto-detect NPCs & LVS vehicles into the palette (recommended).
MilBase.Config.EventAutoDetect = true

-- Total live event-spawned entities allowed at once (anti-lag budget).
-- Spawning is blocked past this until units are cleared.
MilBase.Config.MaxEventEntities = 250

--------------------------------------------------------------------------
-- Effects & objects the game master can place (Zeus-style)
--------------------------------------------------------------------------

MilBase.RegisterEventSpawn("fx_explosion", {
	name = "Explosion", category = "Effects", kind = "effect", effect = "explosion",
})
MilBase.RegisterEventSpawn("fx_fire", {
	name = "Fire", category = "Effects", kind = "effect", effect = "fire",
})
MilBase.RegisterEventSpawn("fx_smoke", {
	name = "Smoke Column", category = "Effects", kind = "effect", effect = "smoke",
})

MilBase.RegisterEventSpawn("prop_crate", {
	name = "Crate", category = "Objects", kind = "prop",
	model = "models/props_junk/wood_crate001a.mdl",
})
MilBase.RegisterEventSpawn("prop_barrier", {
	name = "Barrier", category = "Objects", kind = "prop",
	model = "models/props_c17/concrete_barrier001a.mdl",
})
MilBase.RegisterEventSpawn("prop_barrel", {
	name = "Barrel", category = "Objects", kind = "prop",
	model = "models/props_c17/oildrum001.mdl",
})

-- RP entities: spawned already malfunctioning so engineers work them live.
MilBase.RegisterEventSpawn("rp_terminal", {
	name = "Hackable Terminal", category = "RP Entities", kind = "terminal",
})
MilBase.RegisterEventSpawn("rp_breach", {
	name = "Hull Breach", category = "RP Entities", kind = "breach",
})
MilBase.RegisterEventSpawn("rp_cache", {
	name = "Supply Cache", category = "RP Entities", kind = "prop",
	model = "models/props_junk/wood_crate002a.mdl",
})
MilBase.RegisterEventSpawn("rp_relay_dish", {
	name = "Relay Antenna", category = "RP Entities", kind = "relay_dish",
})
MilBase.RegisterEventSpawn("rp_relay_terminal", {
	name = "Relay Terminal", category = "RP Entities", kind = "relay_terminal",
})

--------------------------------------------------------------------------
-- Optional manual entries / overrides
--------------------------------------------------------------------------
-- Auto-detect covers everything, but you can still add custom entries or
-- override a detected one (register the same class to replace it). Fields:
--   name, category, kind ("npc"/"lvs"), class, weapon (npc), ai (lvs).

-- Example: an armed Combine variant in its own "Event" category.
-- MilBase.RegisterEventSpawn("event_elite", {
-- 	name = "Combine Elite", category = "Event", kind = "npc",
-- 	class = "npc_combine_s", weapon = "weapon_ar2",
-- })

-- Example: force an LVS gunship into an "Air Support" category.
-- MilBase.RegisterEventSpawn("lvs_yourgunship", {
-- 	name = "Gunship", category = "Air Support", kind = "lvs",
-- 	class = "lvs_yourgunship", ai = true,
-- })
