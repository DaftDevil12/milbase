-- Certification-backed languages available to NPC and RP systems.
-- Galactic Basic intentionally has no certification requirement.

MilBase.RegisterCertification("language_wookiee", {
	name = "Wookiee Language (Shyriiwook)",
	desc = "Fluent spoken comprehension of Shyriiwook. Allows the holder to understand Wookiee speakers and translate their dialogue for nearby personnel.",
})

MilBase.RegisterCertification("language_twileki", {
	name = "Twi'leki Language (Ryl)",
	desc = "Fluent spoken comprehension of Ryl. Allows the holder to understand Twi'leki speakers and translate their dialogue for nearby personnel.",
})

MilBase.RegisterCertification("language_huttese", {
	name = "Huttese Language",
	desc = "Fluent spoken comprehension of Huttese. Allows the holder to understand Huttese speakers and translate their dialogue for nearby personnel.",
})

MilBase.RegisterCertification("language_togruti", {
	name = "Togruti Language",
	desc = "Fluent spoken comprehension of Togruti. Allows the holder to understand Togruta speakers and translate their dialogue for nearby personnel.",
})

MilBase.RegisterCertification("language_zabraki", {
	name = "Zabraki Language",
	desc = "Fluent spoken comprehension of Zabraki. Allows the holder to understand Zabrak speakers and translate their dialogue for nearby personnel.",
})

MilBase.RegisterLanguage("basic", {
	name = "Galactic Basic",
	certification = "",
	untranslated = "",
})

MilBase.RegisterLanguage("shyriiwook", {
	name = "Shyriiwook (Wookiee)",
	certification = "language_wookiee",
	untranslated = "Rrraugh... hnn-rowr, rroooarr!",
})

MilBase.RegisterLanguage("twileki", {
	name = "Ryl (Twi'leki)",
	certification = "language_twileki",
	untranslated = "Koyi tal... tchun n'abarra.",
})

MilBase.RegisterLanguage("huttese", {
	name = "Huttese",
	certification = "language_huttese",
	untranslated = "Chuba da naga... peedunkee wata.",
})

MilBase.RegisterLanguage("togruti", {
	name = "Togruti",
	certification = "language_togruti",
	untranslated = "Shaak ven talora... kiresh na.",
})

MilBase.RegisterLanguage("zabraki", {
	name = "Zabraki",
	certification = "language_zabraki",
	untranslated = "Vorda karesh... tal vek.",
})
