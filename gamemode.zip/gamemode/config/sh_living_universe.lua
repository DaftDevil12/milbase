--[[
	Star Wars RP: Living Universe

	This configuration extends the existing persistent Galaxy Director traffic.
	It never replaces the original encounter, communications, economy or battle
	systems; every simulated life belongs to one of their real persistent ships.
]]

MilBase.Config.LivingUniverse = MilBase.Config.LivingUniverse or {}
local cfg = MilBase.Config.LivingUniverse

cfg.Enabled = cfg.Enabled ~= false

-- One real hour advances this many hours for off-screen crew routines.
-- Four makes a complete simulated day last six real hours.
cfg.TimeScale = tonumber(cfg.TimeScale) or 4
cfg.ThinkInterval = tonumber(cfg.ThinkInterval) or 5
cfg.ProfilesPerThink = tonumber(cfg.ProfilesPerThink) or 12
cfg.SaveInterval = tonumber(cfg.SaveInterval) or 10
cfg.MaximumSavesPerFlush = tonumber(cfg.MaximumSavesPerFlush) or 24
cfg.MaximumOfflineDays = tonumber(cfg.MaximumOfflineDays) or 30
cfg.MaximumTimelineEvents = tonumber(cfg.MaximumTimelineEvents) or 30

-- Named characters are the people the Republic can learn about and remember.
-- The wider ship complement is also tracked without creating hundreds of rows.
cfg.MinimumNamedCrew = tonumber(cfg.MinimumNamedCrew) or 3
cfg.MaximumNamedCrew = tonumber(cfg.MaximumNamedCrew) or 12

cfg.RoutineEventChancePerDay = tonumber(cfg.RoutineEventChancePerDay) or 0.42
cfg.DangerEventChancePerDay = tonumber(cfg.DangerEventChancePerDay) or 0.30
cfg.CrewChangeChancePerDay = tonumber(cfg.CrewChangeChancePerDay) or 0.06
cfg.SeriousInjuryChance = tonumber(cfg.SeriousInjuryChance) or 0.12
cfg.FatalityChance = tonumber(cfg.FatalityChance) or 0.018
cfg.PersistentShipDamageEnabled = cfg.PersistentShipDamageEnabled ~= false
cfg.PermanentShipLossEnabled = cfg.PermanentShipLossEnabled ~= false
cfg.DestructionSurvivalChance = tonumber(cfg.DestructionSurvivalChance) or 0.28

cfg.StartingFundsMinimum = tonumber(cfg.StartingFundsMinimum) or 1800
cfg.StartingFundsMaximum = tonumber(cfg.StartingFundsMaximum) or 9000
cfg.ContractPayMinimum = tonumber(cfg.ContractPayMinimum) or 500
cfg.ContractPayMaximum = tonumber(cfg.ContractPayMaximum) or 4200

cfg.VisibleActivityUpdates = cfg.VisibleActivityUpdates ~= false
cfg.PublishMajorLifeEvents = cfg.PublishMajorLifeEvents ~= false
cfg.AllowEmergencySupplyAid = cfg.AllowEmergencySupplyAid ~= false
