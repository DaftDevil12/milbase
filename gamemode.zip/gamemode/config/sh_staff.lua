--[[
	Staff ranks - edit freely, like the other config files.

	level     - authority (higher outranks lower; level 4+ can /setstaff)
	usergroup - optional engine group mapping: "admin" makes IsAdmin()
	            true (noclip, spawn menu, all gamemode admin commands),
	            "superadmin" additionally makes IsSuperAdmin() true.
	color     - shown on the scoreboard and staff tags

	Rough powers by level (see modules/sh_interactions.lua):
	  1+  goto, bring, freeze     2+  kick     3+  full admin commands
	  4+  manage staff ranks
]]

MilBase.RegisterStaffRank("tmod", {
	name = "Trial Moderator",
	level = 1,
	color = Color(120, 180, 120),
})

MilBase.RegisterStaffRank("mod", {
	name = "Moderator",
	level = 2,
	color = Color(80, 160, 90),
})

MilBase.RegisterStaffRank("admin", {
	name = "Admin",
	level = 3,
	color = Color(80, 130, 200),
	usergroup = "admin",
})

MilBase.RegisterStaffRank("headadmin", {
	name = "Head Admin",
	level = 4,
	color = Color(210, 140, 60),
	usergroup = "admin",
})

MilBase.RegisterStaffRank("developer", {
	name = "Developer",
	level = 5,
	color = Color(150, 100, 210),
	usergroup = "admin",
})

MilBase.RegisterStaffRank("management", {
	name = "Management",
	level = 6,
	color = Color(200, 80, 80),
	usergroup = "superadmin",
})

MilBase.RegisterStaffRank("owner", {
	name = "Owner",
	level = 7,
	color = Color(225, 60, 60),
	usergroup = "superadmin",
})
