-- Republic customs, false-IFF and physical cargo inspection configuration.
MilBase.Config.SmugglingInspections = MilBase.Config.SmugglingInspections or {}
local c = MilBase.Config.SmugglingInspections

c.Enabled = c.Enabled ~= false
c.CaseChance = c.CaseChance or {
	civilian = 0.34,
	pirate = 1,
	cis = 0.7,
	republic = 0.05,
	neutral = 0.22,
}
c.AllowFighterInspections = c.AllowFighterInspections == true
c.MaximumOpenCases = c.MaximumOpenCases or 12
c.EvidenceForLawfulArrest = c.EvidenceForLawfulArrest or 3
c.EvidenceForImpound = c.EvidenceForImpound or 4
c.LandingDelay = c.LandingDelay or 2.5
c.LandingTimeout = c.LandingTimeout or 45
c.InteractionDistance = c.InteractionDistance or 180
c.CinematicConversations = c.CinematicConversations ~= false
c.CinematicConversationDistance = c.CinematicConversationDistance or 230
c.LanguageTranslatorRadius = c.LanguageTranslatorRadius or 340
c.CrewSpeciesWeights = c.CrewSpeciesWeights or {
	human = 58,
	wookiee = 9,
	twilek = 15,
	togruta = 9,
	zabrak = 9,
}
c.ResistanceChance = c.ResistanceChance or 0.32
c.HiddenCompartmentBaseChance = c.HiddenCompartmentBaseChance or 0.3
c.EngineFailureChance = c.EngineFailureChance or 0.2
c.FakeEmergencyChance = c.FakeEmergencyChance or 0.3
c.InspectionShipScale = c.InspectionShipScale or {
	fighter = 1,
	shuttle = 0.8,
	light = 0.62,
	corvette = 0.32,
	capital = 0.16,
}
c.CrewModel = c.CrewModel or "models/Humans/Group03/male_07.mdl"
c.CrewModels = c.CrewModels or {
	"models/Humans/Group03/male_02.mdl",
	"models/Humans/Group03/male_04.mdl",
	"models/Humans/Group03/male_07.mdl",
	"models/Humans/Group03/female_02.mdl",
	"models/Humans/Group03/female_04.mdl",
}
c.CargoModel = c.CargoModel or "models/props_junk/wood_crate001a.mdl"
c.HostileCrewNPC = c.HostileCrewNPC or "npc_citizen"
c.HostileCrewWeapon = c.HostileCrewWeapon or "weapon_smg1"
c.AnchorStaffLevel = c.AnchorStaffLevel or 6
c.FineFundingMinimum = c.FineFundingMinimum or 350
c.FineFundingMaximum = c.FineFundingMaximum or 1400
c.ConfiscationFundingMinimum = c.ConfiscationFundingMinimum or 700
c.ConfiscationFundingMaximum = c.ConfiscationFundingMaximum or 2800
c.ConfiscationSuppliesMinimum = c.ConfiscationSuppliesMinimum or 8
c.ConfiscationSuppliesMaximum = c.ConfiscationSuppliesMaximum or 35
c.WrongfulActionReputationPenalty = c.WrongfulActionReputationPenalty or 5
c.SuccessReputationGain = c.SuccessReputationGain or 3
c.CaseLifetime = c.CaseLifetime or 1800
c.PhysicalEncounterLifetime = c.PhysicalEncounterLifetime or 1200
c.EnableViolentResistance = c.EnableViolentResistance ~= false
c.EnableNaturalFailures = c.EnableNaturalFailures ~= false
c.EnablePersistence = c.EnablePersistence ~= false

-- Physical inspection-bay landing and datapad workflow.
c.EnableDatapadInspection = c.EnableDatapadInspection ~= false
c.InspectionShipFloorClearance = c.InspectionShipFloorClearance or 6
c.InspectionApproachSpeed = c.InspectionApproachSpeed or 520
c.InspectionApproachMinimumDuration = c.InspectionApproachMinimumDuration or 1.2
c.InspectionApproachMaximumDuration = c.InspectionApproachMaximumDuration or 8
c.InspectionApproachDefaultDistance = c.InspectionApproachDefaultDistance or 1500
c.InspectionApproachDefaultHeight = c.InspectionApproachDefaultHeight or 360
c.InspectionApproachSettleTime = c.InspectionApproachSettleTime or 0.8
c.InspectionApproachSound = c.InspectionApproachSound or "vehicles/airboat/fan_motor_idle_loop1.wav"
c.InspectionLandingSound = c.InspectionLandingSound or "vehicles/apc/apc_shutdown.wav"
c.DatapadBayRange = c.DatapadBayRange or 900

-- Customs landings reuse the naval squadron recovery corridor. Source's 3D
-- skybox is a separate coordinate space, so the visible skybox contact is
-- transferred to a full-scale map entity at the first recovery node once the
-- linked hangar doors are fully open.
c.InspectionHangarGroup = c.InspectionHangarGroup or "main"
c.InspectionUseNavalRecoveryRoute = c.InspectionUseNavalRecoveryRoute ~= false
c.InspectionOpenLinkedHangarDoors = c.InspectionOpenLinkedHangarDoors ~= false
c.InspectionCloseLinkedHangarDoors = c.InspectionCloseLinkedHangarDoors ~= false
c.InspectionRequireRecoveryRoute = c.InspectionRequireRecoveryRoute == true
c.InspectionMapTransitionDelay = c.InspectionMapTransitionDelay or 0.35
c.InspectionDoorCloseDelay = c.InspectionDoorCloseDelay or 1.2
c.InspectionRecoveryRouteJoinDistance = c.InspectionRecoveryRouteJoinDistance or 96
c.CrewIdleSequences = c.CrewIdleSequences or {
	"idle_all_01",
	"idle_subtle",
	"idle_passive",
	"idle",
}

-- Staff-only inspection test harness. Test cases never affect live campaign
-- funding, supplies, reputation, wanted records or persisted case history.
c.EnableTestHarness = c.EnableTestHarness ~= false
c.TestStaffLevel = c.TestStaffLevel or c.AnchorStaffLevel or 6
c.TestContactLifetime = c.TestContactLifetime or 1800
c.TestMaximumContacts = c.TestMaximumContacts or 6
