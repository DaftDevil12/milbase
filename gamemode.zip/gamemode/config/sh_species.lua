-- Model-backed species profiles shared by Customs and the prison system.
-- A model profile always carries its species' native language.

local function addWorkshop(id)
	MilBase.Config.WorkshopContent = MilBase.Config.WorkshopContent or {}
	for _, listed in ipairs(MilBase.Config.WorkshopContent) do
		if tostring(listed) == tostring(id) then return end
	end
	MilBase.Config.WorkshopContent[#MilBase.Config.WorkshopContent + 1] = tostring(id)
end

addWorkshop("2997442699") -- CGI Civilian Pack
addWorkshop("2825079448") -- CGI HD Wookie models

MilBase.RegisterSpecies("human", {
	name = "Human",
	nativeLanguage = "basic",
	weights = { crew = 58, prisoner = 58 },
	names = {
		first = { "Jace", "Mira", "Talon", "Rhea", "Kellan", "Sena", "Daro", "Vela" },
		last = { "Venn", "Korda", "Renn", "Tane", "Varo", "Sorn", "Kesh", "Vale" },
	},
	models = {
		crew = {
			{ alias = "pm_civ_smuggler_human_male", weight = 4 },
			{ alias = "pm_civ_smuggler_human_female", weight = 4 },
			{ alias = "pm_civ_merc_human_male", weight = 2 },
			{ alias = "pm_civ_merc_human_female", weight = 2 },
			{ path = "models/Humans/Group03/male_07.mdl", weight = 1 },
			{ path = "models/Humans/Group03/female_02.mdl", weight = 1 },
		},
		prisoner = {
			{ alias = "pm_civ_prisoner_human_male", weight = 5 },
			{ alias = "pm_civ_prisoner_human_female", weight = 5 },
			{ path = "models/Humans/Group03/male_07.mdl", weight = 1 },
		},
	},
})

MilBase.RegisterSpecies("wookiee", {
	name = "Wookiee",
	nativeLanguage = "shyriiwook",
	weights = { crew = 9, prisoner = 9 },
	names = {
		first = { "Rorwarr", "Krrsantan", "Tarfful", "Chalmun", "Lumpawaroo", "Mallatobuck" },
		last = { "of Kashyyyk", "of Kachirho", "of Rwookrrorro" },
	},
	models = {
		-- The addon also contains Trooper and Kwehs variants. The explicit token
		-- allowlist plus rejection list makes Wookie Wild the only eligible one.
		crew = {
			{ tokens = { "wook", "wild" }, rejectTokens = { "trooper", "41st", "kwehs", "server manager" }, weight = 1 },
		},
		prisoner = {
			{ tokens = { "wook", "wild" }, rejectTokens = { "trooper", "41st", "kwehs", "server manager" }, weight = 1 },
		},
	},
})

MilBase.RegisterSpecies("twilek", {
	name = "Twi'lek",
	nativeLanguage = "twileki",
	weights = { crew = 15, prisoner = 15 },
	names = {
		first = { "Aayla", "Numa", "Lyn", "Vette", "Tann", "Twi'ra", "Koyi", "Nuro" },
		last = { "Secura", "Syndulla", "Lethan", "Bibra", "Taa", "Venn" },
	},
	models = {
		crew = {
			{ alias = "pm_civ_bandit_twilek_male", weight = 2 },
			{ alias = "pm_civ_bandit_twilek_female", weight = 2 },
		},
		prisoner = {
			{ alias = "pm_civ_bandit_twilek_male", weight = 2 },
			{ alias = "pm_civ_bandit_twilek_female", weight = 2 },
		},
	},
})

MilBase.RegisterSpecies("togruta", {
	name = "Togruta",
	nativeLanguage = "togruti",
	weights = { crew = 9, prisoner = 9 },
	names = {
		first = { "Ashla", "Raana", "Kiros", "Shaak", "Tano", "Vokara" },
		last = { "Ti", "Tano", "Kora", "Venn", "Shaal" },
	},
	models = {
		crew = {
			{ alias = "pm_civ_smuggler_togruta_male", weight = 2 },
			{ alias = "pm_civ_smuggler_togruta_female", weight = 2 },
		},
		prisoner = {
			{ alias = "pm_civ_smuggler_togruta_male", weight = 2 },
			{ alias = "pm_civ_smuggler_togruta_female", weight = 2 },
		},
	},
})

MilBase.RegisterSpecies("zabrak", {
	name = "Zabrak",
	nativeLanguage = "zabraki",
	weights = { crew = 9, prisoner = 9 },
	names = {
		first = { "Agen", "Bao", "Eeth", "Sugi", "Kao", "Maris" },
		last = { "Kolar", "Dur", "Koth", "Venn", "Rook" },
	},
	models = {
		crew = {
			{ alias = "pm_civ_merc_zabrak_male", weight = 2 },
			{ alias = "pm_civ_merc_zabrak_female", weight = 2 },
		},
		prisoner = {
			{ alias = "pm_civ_merc_zabrak_male", weight = 2 },
			{ alias = "pm_civ_merc_zabrak_female", weight = 2 },
		},
	},
})
