--[[
	501st Torrent Company Juggernaut configuration.
	This is a gameplay system only. It does not register or alter certifications.
]]

local cfg = MilBase.Config

cfg.Juggernaut = cfg.Juggernaut or {
	Enabled = true,

	-- Required content selected by the server owner.
	WorkshopID = "2604315429",
	AutoDownloadWorkshop = true,
	WeaponClass = "arccw_cgi_k_z6",
	RequireWeapon = true,
	RequireModel = true,

	-- Confirmed model path. The resolver also checks fallback locations,
	-- registered playermodels, and mounted model folders.
	Model = "models/moxfort/501st-juggernaut.mdl",
	Models = {
		"models/moxfort/501st-juggernaut.mdl",
		"models/player/501st/juggernaut.mdl",
		"models/player/501st_juggernaut.mdl",
		"models/player/juggernaut_501st.mdl",
		"models/salty/501st_juggernaut.mdl",
		"models/player/salty/501st_juggernaut.mdl",
		"models/501st/juggernaut.mdl",
	},
	ModelSearchTerms = { "501st", "juggernaut", "darktrooper" },
	Skin = 0,
	Bodygroups = {}, -- Example: { [1] = 1, [2] = 0 }

	-- The normal character health, armour, walk speed, jump power and Z-6
	-- weapon behaviour are not replaced by this system.
	RestoreOriginalModel = true,
	PreventFallDamage = true, -- Landing slam still triggers from OnPlayerHitGround.
	GiveZ6 = true,
	SelectZ6 = true,

	-- While the armour is active the normal weapon inventory is replaced by
	-- the Juggernaut loadout. The original classes, clips, reserve ammunition
	-- and selected weapon are restored when the suit is disengaged alive.
	ReplaceWeaponsWhileActive = true,
	RestoreWeaponsOnDeactivate = true,
	RestoreAmmoOnDeactivate = true,
	AdditionalArmourWeapons = {}, -- The configured WeaponClass is always included.

	-- Sectional armour. Values are durability, not extra player health.
	Sections = {
		head =      { name = "HELMET",    max = 120, reduction = 0.55, wear = 1.00 },
		chest =     { name = "CHEST",     max = 260, reduction = 0.45, wear = 1.00 },
		left_arm =  { name = "L. ARM",    max = 140, reduction = 0.25, wear = 0.90 },
		right_arm = { name = "R. ARM",    max = 140, reduction = 0.25, wear = 0.90 },
		left_leg =  { name = "L. LEG",    max = 160, reduction = 0.30, wear = 0.95 },
		right_leg = { name = "R. LEG",    max = 160, reduction = 0.30, wear = 0.95 },
	},
	ExplosionSection = "chest",
	BrokenOneLegSpeedScale = 0.82,
	BrokenBothLegsSpeedScale = 0.64,
	BrokenArmSway = 0.28,

	-- Shared suit power.
	PowerMax = 100,
	PowerRegenPerSecond = 9,
	PowerRegenDelay = 3,

	-- Frontal shield.
	ShieldMax = 260,
	ShieldArcDegrees = 125,
	ShieldPowerPerSecond = 11,
	ShieldPowerPerDamage = 0.025,
	ShieldMoveScale = 0.55,
	ShieldExplosionDamageScale = 1.8,
	ShieldRegenPerSecond = 24,
	ShieldRegenDelay = 5,

	-- Z-6 near-miss suppression. The ArcCW weapon itself is not rewritten.
	SuppressionRadius = 145,
	SuppressionPerShot = 6,
	SuppressionMax = 100,
	SuppressionDecayPerSecond = 22,
	SuppressionRunScaleAtMax = 0.82,
	SuppressionSpreadAtMax = 0.018,
	SuppressFriendlies = false,

	-- Charge.
	ChargePowerCost = 30,
	ChargeCooldown = 12,
	ChargeDuration = 1.05,
	ChargeSpeed = 520,
	ChargeHullMins = Vector(-22, -22, 0),
	ChargeHullMaxs = Vector(22, 22, 72),
	ChargeImpactDamage = 18,
	ChargeImpactForce = 520,
	ChargeStaggerDuration = 1.25,

	-- Automatic landing slam. It only triggers after a genuine high drop;
	-- ordinary jumps do not meet both the distance and speed thresholds.
	AutomaticSlam = true,
	AllowManualSlam = false,
	SlamMinimumDropHeight = 220,
	SlamMinimumLandingSpeed = 450,
	SlamPowerCost = 35,
	SlamCooldown = 14,
	SlamImpactDelay = 0.05,
	SlamDelay = 0.42, -- Used only if AllowManualSlam is enabled later.
	SlamRadius = 260,
	SlamDamage = 12,
	SlamForce = 520,
	SlamStaggerDuration = 1.75,
	SlamAffectsFriendlies = false,

	-- Armour lock.
	ArmourLockMinimumPower = 20,
	ArmourLockPowerPerSecond = 20,
	ArmourLockDamageScale = 0.22,
	ArmourLockMaxDuration = 6,
	ArmourLockCooldown = 18,

	-- Juggernaut-specific incapacitation. A medic stabilizes the operator and
	-- an engineer restores the suit before the player can stand again.
	IncapacitationEnabled = true,
	IncapacitationDuration = 50,
	ExecutionDamage = 20,
	ReviveHealth = 35,
	RevivePower = 25,
	MedicStabilizeTime = 4,
	EngineerRestoreTime = 6,
	EngineerRepairTime = 4,
	EngineerRepairAmount = 70,
	EngineerRepairChargeCost = 50,
	RequireBandageForStabilize = true,
	RequireRepairKit = true,

	-- Ability-wheel input. G opens it; the console command
	-- mb_juggernaut_wheel is also available for custom binds.
	WheelKey = KEY_G or 17,
	LogActions = true,
}

if cfg.Juggernaut.AutoDownloadWorkshop and cfg.Juggernaut.WorkshopID then
	cfg.WorkshopContent = cfg.WorkshopContent or {}
	local found = false
	for _, id in ipairs(cfg.WorkshopContent) do
		if tostring(id) == tostring(cfg.Juggernaut.WorkshopID) then
			found = true
			break
		end
	end
	if not found then table.insert(cfg.WorkshopContent, tostring(cfg.Juggernaut.WorkshopID)) end
end
