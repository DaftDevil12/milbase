--[[
	Coruscant Guard Massif Handler configuration.
	The Workshop item is only content; all gameplay is implemented by MilBase.
]]

local cfg = MilBase.Config

cfg.Massif = cfg.Massif or {
	Enabled = true,
	CertificationID = "massif_handler",
	AllowedFactions = { cg = true },

	-- Original model requested by the server owner.
	WorkshopID = "760630012",
	AutoDownloadWorkshop = false,
	Models = {
		"models/boost/player/massif.mdl", -- known path used by Massif packs
		"models/player/massif.mdl",
		"models/massif.mdl",
	},
	FallbackModel = "models/antlion.mdl", -- keeps the system testable if content is missing
	DefaultName = "Hound",

	-- This model is a GMod player model. Locomotion is resolved from player
	-- activities (ACT_HL2MP/ACT_MP) and driven with 9-way move pose parameters.
	-- The names below are only fallbacks for custom or one-shot sequences.
	PreferPlayerActivities = true,
	Animations = {
		idle = { "idle_all_01", "idle_all_02", "idle_all", "idle", "stand_idle", "Idle01" },
		walk = { "walk_all", "walk", "Walk_ALL", "walk_lower", "menu_walk" },
		run = { "run_all", "run", "sprint", "Run_ALL", "run_lower" },
		crouchIdle = { "cidle_all", "crouch_idle", "crouchidle", "idle_crouch" },
		crouchWalk = { "cwalk_all", "crouch_walk", "crouchwalk", "walk_crouch" },
		attack = { "attack", "bite", "melee", "attack1", "gesture_melee_attack1", "range_melee" },
		sniff = { "sniff", "search", "gesture_item_place", "gesture_signal_forward" },
		death = { "death", "dead", "death_01", "ragdoll" },
	},

	Health = 225,
	WalkSpeed = 190,
	RunSpeed = 350,
	ControlledSprintSpeed = 430,
	ControlledCrouchSpeed = 125,
	AnimationPlaybackScale = 1,
	TurnRate = 8,
	FollowDistance = 85,
	LeashDistance = 2600,
	TrackStopDistance = 165, -- Track follows and observes; it never attacks
	SearchReturnCommand = "follow",
	StuckTeleportDistance = 1800,
	StuckRecoveryDelay = 4,
	-- Teleport recovery is intentionally limited to catch-up orders. Stay,
	-- Guard, Track, Search and Apprehend will never silently teleport.
	TeleportRecoveryCommands = { follow = true, ["return"] = true },
	CollisionMins = Vector(-22, -18, 0),
	CollisionMaxs = Vector(22, 18, 45),

	BiteDamage = 12,
	BiteRange = 105,
	BiteCooldown = 0.9,
	TackleRange = 115,
	TackleDuration = 3.25,
	TackleCooldown = 7,
	AllowFriendlyApprehension = true,
	ProtectHandler = true,

	PossessionDuration = 40,
	PossessionCooldown = 35,
	TrackingRange = 6000,
	ScentPulseCooldown = 4,
	ScentPulseDuration = 1.2,
	BodyVulnerableWhileControlling = true,
	ThirdPersonControlCamera = true,

	SearchRange = 180,
	AreaSearchRadius = 650,
	SearchCooldown = 8,
	ContrabandItems = {
		frag = "explosives",
		det_charge = "explosives",
		slicer_kit = "restricted equipment",
	},
	ContrabandWeapons = {
		weapon_rpg = "heavy weapon",
		weapon_frag = "explosives",
	},

	DeployCooldown = 12,
	IncapacitatedCooldown = 35,
	MaxActiveMassifs = 12,
	StaffProtectionLevel = 4,
	LogActions = true,
}

-- The original Workshop item is currently removed, so automatic download is
-- disabled by default. Mount the model through your own content pack, or set
-- this true if the item becomes available again.
if cfg.Massif.AutoDownloadWorkshop and cfg.Massif.WorkshopID then
	cfg.WorkshopContent = cfg.WorkshopContent or {}
	local found = false
	for _, id in ipairs(cfg.WorkshopContent) do
		if tostring(id) == tostring(cfg.Massif.WorkshopID) then found = true break end
	end
	if not found then table.insert(cfg.WorkshopContent, tostring(cfg.Massif.WorkshopID)) end
end
