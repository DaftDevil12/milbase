--[[
	Unified RP Datapad.

	One SWEP (mb_datapad) now owns the RP apps that used to be split across
	Records/CCTV datapads. Apps are server-authoritative and can be hidden by
	faction, rank, certification, staff level, or owner-only rules. Restricted
	apps marked slice=true can be temporarily unlocked with the existing slicing
	minigame when the player has a Slicer Kit.

	Apps included: Home, Criminal Records, Charge Lookup, CCTV, Medical Records,
	Medical Checkup, Personnel File, Certifications, Regiment Roster,
	Incident Reports, Customs Cases, Warrants/BOLOs, and Owner-only Access Control.
]]

local cfg = MilBase.Config
MilBase.Datapad = MilBase.Datapad or {}
MilBase.Datapad.Tabs = MilBase.Datapad.Tabs or {}
MilBase.Datapad.TabOrder = MilBase.Datapad.TabOrder or {}
MilBase.Datapad.AccessOverrides = MilBase.Datapad.AccessOverrides or {}

local NET_OPEN = "MilBase_Datapad_Open"
local NET_REQUEST = "MilBase_Datapad_Request"
local NET_DATA = "MilBase_Datapad_Data"
local NET_SLICE = "MilBase_Datapad_Slice"
local NET_ADMIN = "MilBase_Datapad_Admin"
local NET_ADMIN_DATA = "MilBase_Datapad_AdminData"

local function trim(s) return string.Trim(tostring(s or "")) end
local function lower(s) return string.lower(trim(s)) end
local function now() return os.time() end
local function clampInt(v, min, max)
	v = math.floor(tonumber(v or 0) or 0)
	if min then v = math.max(min, v) end
	if max then v = math.min(max, v) end
	return v
end

local GROUP_WEIGHT = { trooper = 1, trp = 1, nco = 2, officer = 3, commander = 4, command = 4 }
local function rankGroup(ply)
	if not IsValid(ply) or not ply.MBRank then return "trooper", 1 end
	local rank = ply:MBRank()
	local idx = ply.MBRankIndex and ply:MBRankIndex() or 1
	local name = lower(rank and rank.name or "")
	if string.find(name, "marshal", 1, true) or string.find(name, "commander", 1, true) then return "commander", 4 end
	if (rank and rank.canPromote) or string.find(name, "lieutenant", 1, true) or string.find(name, "captain", 1, true)
	or string.find(name, "major", 1, true) or string.find(name, "officer", 1, true) then return "officer", 3 end
	if string.find(name, "corporal", 1, true) or string.find(name, "sergeant", 1, true) or idx >= 4 then return "nco", 2 end
	return "trooper", 1
end
MilBase.DatapadRankGroup = rankGroup

local function listContains(list, value, alt)
	if not istable(list) then return false end
	local v = lower(value)
	local a = lower(alt)
	for _, item in ipairs(list) do
		local x = lower(item)
		if x ~= "" and (x == v or x == a) then return true end
	end
	return false
end

local function hasAnyCert(ply, certs)
	if not istable(certs) or #certs == 0 then return true end
	if not (IsValid(ply) and ply.MBHasCert) then return false end
	for _, id in ipairs(certs) do
		if ply:MBHasCert(tostring(id)) then return true end
	end
	return false
end

local function hasAllCerts(ply, certs)
	if not istable(certs) or #certs == 0 then return true end
	if not (IsValid(ply) and ply.MBHasCert) then return false end
	for _, id in ipairs(certs) do
		if not ply:MBHasCert(tostring(id)) then return false end
	end
	return true
end

local function isPolice(ply)
	if not IsValid(ply) then return false end
	local faction = ply.MBFaction and ply:MBFaction()
	if faction and faction.police then return true end
	local allowed = cfg.JailPoliceFactions or cfg.DatapadSecurityFactions or {}
	local fid = ply.MBFactionID and ply:MBFactionID() or ""
	return allowed[fid] == true or (faction and allowed[faction.name] == true)
end

local function isMedic(ply)
	if not IsValid(ply) then return false end
	if ply.MBHasCert and ply:MBHasCert("field_medic") then return true end
	local faction = ply.MBFaction and ply:MBFaction()
	if faction and faction.medic then return true end
	local allowed = cfg.DatapadMedicalFactions or {}
	local fid = ply.MBFactionID and ply:MBFactionID() or ""
	return allowed[fid] == true or (faction and allowed[faction.name] == true)
end

local function isOfficer(ply)
	local _, weight = rankGroup(ply)
	return weight >= 3
end

local function isInspectionPersonnel(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsAdmin() or isPolice(ply) then return true end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local factionName = lower(faction and faction.name or "")
	local factionID = lower(ply.MBFactionID and ply:MBFactionID() or "")
	local combined = factionName .. " " .. factionID
	return string.find(combined, "clone", 1, true) ~= nil
		or string.find(combined, "guard", 1, true) ~= nil
		or string.find(combined, "nav", 1, true) ~= nil
end

local function isRosterNavy(ply)
	if MilBase.DatapadRosterIsNavy then return MilBase.DatapadRosterIsNavy(ply) end
	if not IsValid(ply) then return false end
	local factions = cfg.DatapadRosterNavyFactions or { ["Navy"] = true }
	local faction = ply.MBFaction and ply:MBFaction()
	local factionID = ply.MBFactionID and ply:MBFactionID() or ""
	return factions[factionID] == true or (faction and factions[faction.name] == true)
end

local function copyTable(t)
	return istable(t) and table.Copy(t) or {}
end

local function mergedRules(tabID)
	local base = copyTable((cfg.DatapadTabs or {})[tabID])
	local over = MilBase.Datapad.AccessOverrides and MilBase.Datapad.AccessOverrides[tabID]
	if istable(over) then
		for k, v in pairs(over) do base[k] = v end
	end
	return base
end

local function staffOwner(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) then return false end
	if ply:IsSuperAdmin() and (not ply.MBStaffLevel or ply:MBStaffLevel() <= 0) then return true end
	return ply.MBStaffLevel and ply:MBStaffLevel() >= (cfg.DatapadOwnerLevel or cfg.JailCrimeOwnerLevel or 7)
end

local function accessByRules(ply, rules)
	if cfg.DatapadEnabled == false then return false, "disabled" end
	if not (IsValid(ply) and ply:IsPlayer()) then return false, "invalid" end
	rules = rules or {}

	if rules.owner_only and not staffOwner(ply) then return false, "owner" end
	if rules.staff_level and (not ply.MBStaffLevel or ply:MBStaffLevel() < tonumber(rules.staff_level)) then return false, "staff" end

	local faction = ply.MBFaction and ply:MBFaction()
	local factionID = ply.MBFactionID and ply:MBFactionID() or ""
	if istable(rules.factions) and #rules.factions > 0 and not listContains(rules.factions, factionID, faction and faction.name or "") then
		return false, "faction"
	end
	if rules.police and not isPolice(ply) then return false, "police" end
	if rules.inspection and not isInspectionPersonnel(ply) then return false, "inspection" end
	if rules.medic and not isMedic(ply) then return false, "medic" end
	if rules.officer and not isOfficer(ply) then return false, "officer" end
	if rules.roster and not (isOfficer(ply) or isRosterNavy(ply) or ply:IsSuperAdmin()) then return false, "officer" end
	if rules.cert and not (ply.MBHasCert and ply:MBHasCert(tostring(rules.cert))) then return false, "cert" end
	if not hasAllCerts(ply, rules.certs_all) then return false, "cert" end
	if not hasAnyCert(ply, rules.certs) then return false, "cert" end

	if rules.min_rank_index and (not ply.MBRankIndex or ply:MBRankIndex() < tonumber(rules.min_rank_index)) then return false, "rank" end
	if rules.max_rank_index and (not ply.MBRankIndex or ply:MBRankIndex() > tonumber(rules.max_rank_index)) then return false, "rank" end
	local group, weight = rankGroup(ply)
	if rules.rank_group and lower(rules.rank_group) ~= group then return false, "rank" end
	if istable(rules.rank_groups) and #rules.rank_groups > 0 and not listContains(rules.rank_groups, group) then return false, "rank" end
	if rules.min_rank_group then
		local need = GROUP_WEIGHT[lower(rules.min_rank_group)] or 1
		if weight < need then return false, "rank" end
	end
	return true
end

function MilBase.DatapadCanAccess(ply, tabID)
	local def = MilBase.Datapad.Tabs[tabID]
	if not def then return false, "missing" end
	local rules = mergedRules(tabID)
	local ok, reason = accessByRules(ply, rules)
	if ok then return true end
	if IsValid(ply) and ply.mb_datapadSlices and (ply.mb_datapadSlices[tabID] or 0) > CurTime() then return true, "sliced" end
	return false, reason
end

function MilBase.DatapadCanSlice(ply, tabID)
	local def = MilBase.Datapad.Tabs[tabID]
	if not def then return false end
	local rules = mergedRules(tabID)
	if not rules.slice then return false end
	if MilBase.DatapadCanAccess(ply, tabID) then return false end
	if MilBase.PlayerHasSlicerKit then return MilBase.PlayerHasSlicerKit(ply) end
	return ply:IsAdmin()
end

local function tabRules(id, name, icon, rules)
	rules = rules or {}
	rules.name = rules.name or name
	rules.icon = rules.icon or icon
	return rules
end

local function registerTab(id, name, icon, order, rules)
	MilBase.Datapad.Tabs[id] = { id = id, name = name, icon = icon or "●", order = order or 100, rules = rules or {} }
	MilBase.Datapad.TabOrder[#MilBase.Datapad.TabOrder + 1] = id
end

-- Register the built-in apps. Access rules are read from cfg.DatapadTabs plus DB overrides.
registerTab("home", "Home", "⌂", 1)
registerTab("defcon", "DEFCON Status", "D", 5)
registerTab("criminal_records", "Criminal Records", "⚖", 10)
registerTab("charge_lookup", "Charge Lookup", "§", 20)
registerTab("cctv", "CCTV", "◉", 30)
registerTab("medical_records", "Medical Records", "+", 40)
registerTab("medical_checkup", "Medical Checkup", "✚", 50)
registerTab("personnel", "Personnel File", "ID", 60)
registerTab("certifications", "Certifications", "★", 70)
registerTab("regiment_roster", "Regiment Roster", "R", 75)
registerTab("incidents", "Incident Reports", "!", 80)
registerTab("customs_cases", "Customs Cases", "C", 85)
registerTab("prison_ops", "Prison Operations", "P", 88)
registerTab("warrants", "Warrants / BOLOs", "⌕", 90)
registerTab("admin_config", "Access Control", "⚙", 100)
table.sort(MilBase.Datapad.TabOrder, function(a, b) return (MilBase.Datapad.Tabs[a].order or 0) < (MilBase.Datapad.Tabs[b].order or 0) end)

local function tabListFor(ply)
	local out = {}
	for _, id in ipairs(MilBase.Datapad.TabOrder) do
		local tab = MilBase.Datapad.Tabs[id]
		local ok, state = MilBase.DatapadCanAccess(ply, id)
		local canSlice = MilBase.DatapadCanSlice(ply, id)
		if ok or canSlice or id == "home" then
			out[#out + 1] = {
				id = id,
				name = tab.name,
				icon = tab.icon,
				allowed = ok,
				sliced = state == "sliced",
				canSlice = canSlice,
				expires = IsValid(ply) and ply.mb_datapadSlices and math.max(0, (ply.mb_datapadSlices[id] or 0) - CurTime()) or 0,
			}
		end
	end
	return out
end

local function playerSummary(ply)
	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local certNames = {}
	for _, id in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[id]
		certNames[#certNames + 1] = cert and cert.name or id
	end
	local group = rankGroup(ply)
	return {
		name = ply:MBName(), steam_name = ply:Nick(), steamid = ply:SteamID64(),
		faction = faction and faction.name or ply:MBFactionID(), faction_id = ply:MBFactionID(),
		rank = rank and rank.name or "Unknown", rank_index = ply:MBRankIndex(), rank_group = group,
		certs = certNames,
		staff_level = ply.MBStaffLevel and ply:MBStaffLevel() or 0,
		has_slicer = MilBase.PlayerHasSlicerKit and MilBase.PlayerHasSlicerKit(ply) or false,
	}
end

if SERVER then
	util.AddNetworkString(NET_OPEN)
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_DATA)
	util.AddNetworkString(NET_SLICE)
	util.AddNetworkString(NET_ADMIN)
	util.AddNetworkString(NET_ADMIN_DATA)

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_datapad_access (tab VARCHAR(64) PRIMARY KEY, rules TEXT)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_datapad_medical ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", steamid VARCHAR(32), rp_name TEXT, steam_name TEXT, "
		.. "medic_steamid VARCHAR(32), medic_name TEXT, diagnosis TEXT, treatment TEXT, duty_status TEXT, notes TEXT, created_at INTEGER )")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_datapad_personnel ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", steamid VARCHAR(32), rp_name TEXT, steam_name TEXT, author_steamid VARCHAR(32), author_name TEXT, "
		.. "faction TEXT, rank_name TEXT, entry_type TEXT, notes TEXT, created_at INTEGER )")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_datapad_incidents ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", title TEXT, category TEXT, involved TEXT, author_steamid VARCHAR(32), author_name TEXT, notes TEXT, created_at INTEGER, status VARCHAR(24) )")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_datapad_warrants ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", steamid VARCHAR(32), rp_name TEXT, steam_name TEXT, issuer_steamid VARCHAR(32), issuer_name TEXT, reason TEXT, expires_at INTEGER, created_at INTEGER, status VARCHAR(24) )")

	function MilBase.DatapadReloadAccess(cb)
		MilBase.DB.Query("SELECT * FROM frontier_datapad_access", function(rows)
			MilBase.Datapad.AccessOverrides = {}
			for _, row in ipairs(rows or {}) do
				local t = util.JSONToTable(row.rules or "")
				if istable(t) and row.tab then MilBase.Datapad.AccessOverrides[row.tab] = t end
			end
			if cb then cb() end
		end)
	end

	hook.Add("InitPostEntity", "MilBase.Datapad.LoadAccess", function()
		MilBase.DatapadReloadAccess()
	end)

	local function sendOpen(ply, preferred)
		if cfg.DatapadEnabled == false then MilBase.Notify(ply, "Datapad is disabled.", "warn") return end
		net.Start(NET_OPEN)
			net.WriteString(preferred or "")
			net.WriteTable(tabListFor(ply))
			net.WriteTable(playerSummary(ply))
		net.Send(ply)
	end

	function MilBase.DatapadOpen(ply, preferred)
		if not (IsValid(ply) and ply:IsPlayer()) then return end
		sendOpen(ply, preferred)
	end

	local function sendData(ply, tab, action, payload)
		net.Start(NET_DATA)
			net.WriteString(tab or "")
			net.WriteString(action or "")
			net.WriteTable(payload or {})
		net.Send(ply)
	end

	local function whereLike(columns, query)
		query = string.sub(trim(query), 1, 80)
		if query == "" then return "1=1" end
		local like = MilBase.SQLStr("%" .. query .. "%")
		local parts = {}
		for _, col in ipairs(columns) do parts[#parts + 1] = col .. " LIKE " .. like end
		return "(" .. table.concat(parts, " OR ") .. ")"
	end

	local function onlineMatches(query)
		query = lower(query)
		local out = {}
		for _, p in ipairs(player.GetAll()) do
			local faction = p:MBFaction()
			local rank = p:MBRank()
			local hay = lower(table.concat({ p:MBName(), p:Nick(), p:SteamID64(), faction and faction.name or "", rank and rank.name or "" }, " "))
			if query == "" or string.find(hay, query, 1, true) then
				local certs = {}
				for _, id in ipairs(p:MBCertList()) do
					local cert = MilBase.Certs[id]
					certs[#certs + 1] = { id = id, name = cert and cert.name or id }
				end
				out[#out + 1] = {
					steamid = p:SteamID64(), rp_name = p:MBName(), steam_name = p:Nick(), ent = p,
					faction = faction and faction.name or p:MBFactionID(), rank = rank and rank.name or "Unknown",
					rank_index = p:MBRankIndex(), rank_group = rankGroup(p), certs = certs,
				}
			end
		end
		return out
	end

	local function sendCriminal(ply, query)
		local limit = clampInt(cfg.DatapadSearchLimit or cfg.JailRecordsSearchLimit or 60, 10, 200)
		local sql = "SELECT * FROM frontier_jail_records WHERE "
			.. whereLike({ "rp_name", "steam_name", "steamid", "crime_names", "officer_name", "charge_text", "notes" }, query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sql, function(rows)
			local records, totals = {}, { count = 0, totalFine = 0, totalPaid = 0, totalOwed = 0, totalTime = 0 }
			for _, row in ipairs(rows or {}) do
				local rec = {
					id = tonumber(row.id) or 0, steamid = row.steamid or "", rp_name = row.rp_name or "Unknown", steam_name = row.steam_name or "",
					officer_name = row.officer_name or "Unknown", crime_names = row.crime_names or "", charge_text = row.charge_text or "", notes = row.notes or "",
					jail_seconds = tonumber(row.jail_seconds or 0) or 0, fine_amount = tonumber(row.fine_amount or 0) or 0,
					fine_paid = tonumber(row.fine_paid or 0) or 0, fine_owed = tonumber(row.fine_owed or 0) or 0,
					created_at = tonumber(row.created_at or 0) or 0, expires_at = tonumber(row.expires_at or 0) or 0, status = row.status or "recorded",
				}
				records[#records + 1] = rec
				totals.totalFine = totals.totalFine + rec.fine_amount
				totals.totalPaid = totals.totalPaid + rec.fine_paid
				totals.totalOwed = totals.totalOwed + rec.fine_owed
				totals.totalTime = totals.totalTime + rec.jail_seconds
			end
			totals.count = #records
			if IsValid(ply) then sendData(ply, "criminal_records", "records", { query = query, records = records, summary = totals }) end
		end)
	end

	local function sendCrimes(ply)
		local out = {}
		if MilBase.Jail and MilBase.Jail.CrimeOrder then
			for _, id in ipairs(MilBase.Jail.CrimeOrder) do
				local c = MilBase.Jail.Crimes[id]
				if c and tonumber(c.active or 1) == 1 then out[#out + 1] = c end
			end
		end
		sendData(ply, "charge_lookup", "crimes", { crimes = out })
	end

	local function sendMedical(ply, query)
		local limit = clampInt(cfg.DatapadSearchLimit or 60, 10, 200)
		local sql = "SELECT * FROM frontier_datapad_medical WHERE "
			.. whereLike({ "rp_name", "steam_name", "steamid", "medic_name", "diagnosis", "treatment", "duty_status", "notes" }, query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sql, function(rows)
			if IsValid(ply) then sendData(ply, "medical_records", "records", { query = query, records = rows or {} }) end
		end)
	end

	local function saveCheckup(ply, data)
		if not MilBase.DatapadCanAccess(ply, "medical_checkup") then return end
		local target = data and data.target
		if not (IsValid(target) and target:IsPlayer()) then MilBase.Notify(ply, "Select a nearby patient.", "warn") return end
		if target:GetPos():DistToSqr(ply:GetPos()) > (cfg.DatapadCheckupRange or 160) ^ 2 then MilBase.Notify(ply, "Patient is too far away.", "warn") return end
		local diagnosis = string.sub(trim(data.diagnosis), 1, 160)
		local treatment = string.sub(trim(data.treatment), 1, 220)
		local status = string.sub(trim(data.status), 1, 60)
		local notes = string.sub(trim(data.notes), 1, 512)
		MilBase.DB.Run(string.format("INSERT INTO frontier_datapad_medical (steamid, rp_name, steam_name, medic_steamid, medic_name, diagnosis, treatment, duty_status, notes, created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%d)",
			MilBase.SQLStr(target:SteamID64()), MilBase.SQLStr(target:MBName()), MilBase.SQLStr(target:Nick()), MilBase.SQLStr(ply:SteamID64()), MilBase.SQLStr(ply:MBName()),
			MilBase.SQLStr(diagnosis), MilBase.SQLStr(treatment), MilBase.SQLStr(status), MilBase.SQLStr(notes), now()))
		MilBase.Notify(ply, "Medical checkup saved for " .. target:MBName() .. ".", "ok")
		MilBase.Notify(target, "A medical checkup was recorded by " .. ply:MBName() .. ".")
		sendMedical(ply, target:MBName())
	end

	local function sendPersonnel(ply, query)
		local limit = clampInt(cfg.DatapadSearchLimit or 60, 10, 200)
		local sql = "SELECT * FROM frontier_datapad_personnel WHERE "
			.. whereLike({ "rp_name", "steam_name", "steamid", "author_name", "faction", "rank_name", "entry_type", "notes" }, query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sql, function(rows)
			if IsValid(ply) then sendData(ply, "personnel", "records", { query = query, online = onlineMatches(query), records = rows or {} }) end
		end)
	end

	local function savePersonnel(ply, data)
		if not MilBase.DatapadCanAccess(ply, "personnel") then return end
		local target = data and data.target
		if not (IsValid(target) and target:IsPlayer()) then MilBase.Notify(ply, "Select an online trooper.", "warn") return end
		local faction = target:MBFaction(); local rank = target:MBRank()
		MilBase.DB.Run(string.format("INSERT INTO frontier_datapad_personnel (steamid, rp_name, steam_name, author_steamid, author_name, faction, rank_name, entry_type, notes, created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%d)",
			MilBase.SQLStr(target:SteamID64()), MilBase.SQLStr(target:MBName()), MilBase.SQLStr(target:Nick()), MilBase.SQLStr(ply:SteamID64()), MilBase.SQLStr(ply:MBName()),
			MilBase.SQLStr(faction and faction.name or target:MBFactionID()), MilBase.SQLStr(rank and rank.name or "Unknown"), MilBase.SQLStr(string.sub(trim(data.entry_type), 1, 40)), MilBase.SQLStr(string.sub(trim(data.notes), 1, 512)), now()))
		MilBase.Notify(ply, "Personnel note saved.", "ok")
		sendPersonnel(ply, target:MBName())
	end

	local function sendCerts(ply, query)
		sendData(ply, "certifications", "certs", { query = query, online = onlineMatches(query), certs = MilBase.Certs or {}, order = MilBase.CertOrder or {} })
	end

	local function sendIncidents(ply, query)
		local limit = clampInt(cfg.DatapadSearchLimit or 60, 10, 200)
		local sql = "SELECT * FROM frontier_datapad_incidents WHERE "
			.. whereLike({ "title", "category", "involved", "author_name", "notes", "status" }, query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sql, function(rows)
			if IsValid(ply) then sendData(ply, "incidents", "records", { query = query, records = rows or {} }) end
		end)
	end

	local function saveIncident(ply, data)
		if not MilBase.DatapadCanAccess(ply, "incidents") then return end
		local title = string.sub(trim(data.title), 1, 100)
		if title == "" then title = "Incident Report" end
		MilBase.DB.Run(string.format("INSERT INTO frontier_datapad_incidents (title, category, involved, author_steamid, author_name, notes, created_at, status) VALUES (%s,%s,%s,%s,%s,%s,%d,%s)",
			MilBase.SQLStr(title), MilBase.SQLStr(string.sub(trim(data.category), 1, 40)), MilBase.SQLStr(string.sub(trim(data.involved), 1, 220)),
			MilBase.SQLStr(ply:SteamID64()), MilBase.SQLStr(ply:MBName()), MilBase.SQLStr(string.sub(trim(data.notes), 1, 1024)), now(), MilBase.SQLStr(string.sub(trim(data.status), 1, 24) ~= "" and string.sub(trim(data.status), 1, 24) or "open")))
		MilBase.Notify(ply, "Incident report saved.", "ok")
		sendIncidents(ply, title)
	end

	local function sendWarrants(ply, query)
		local limit = clampInt(cfg.DatapadSearchLimit or 60, 10, 200)
		local sql = "SELECT * FROM frontier_datapad_warrants WHERE "
			.. whereLike({ "rp_name", "steam_name", "steamid", "issuer_name", "reason", "status" }, query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sql, function(rows)
			if IsValid(ply) then sendData(ply, "warrants", "records", { query = query, records = rows or {}, online = onlineMatches(query) }) end
		end)
	end

	local function saveWarrant(ply, data)
		if not MilBase.DatapadCanAccess(ply, "warrants") then return end
		local target = data and data.target
		if not (IsValid(target) and target:IsPlayer()) then MilBase.Notify(ply, "Select an online suspect.", "warn") return end
		local minutes = clampInt(data.minutes, 5, cfg.DatapadMaxWarrantMinutes or 10080)
		local reason = string.sub(trim(data.reason), 1, 512)
		if reason == "" then reason = "Wanted for questioning" end
		MilBase.DB.Run(string.format("INSERT INTO frontier_datapad_warrants (steamid, rp_name, steam_name, issuer_steamid, issuer_name, reason, expires_at, created_at, status) VALUES (%s,%s,%s,%s,%s,%s,%d,%d,%s)",
			MilBase.SQLStr(target:SteamID64()), MilBase.SQLStr(target:MBName()), MilBase.SQLStr(target:Nick()), MilBase.SQLStr(ply:SteamID64()), MilBase.SQLStr(ply:MBName()), MilBase.SQLStr(reason), now() + minutes * 60, now(), MilBase.SQLStr("active")))
		MilBase.Notify(ply, "BOLO issued for " .. target:MBName() .. ".", "ok")
		MilBase.ChatMsg(player.GetAll(), Color(255, 198, 60), "[BOLO] ", color_white, target:MBName() .. " is wanted: " .. reason)
		sendWarrants(ply, target:MBName())
	end

	local function clearWarrant(ply, id)
		if not MilBase.DatapadCanAccess(ply, "warrants") then return end
		id = clampInt(id, 0, nil)
		if id <= 0 then return end
		MilBase.DB.Run("UPDATE frontier_datapad_warrants SET status = 'cleared' WHERE id = " .. id)
		MilBase.Notify(ply, "Warrant cleared.", "ok")
		sendWarrants(ply, "")
	end

	local function sendDefcon(ply)
		if not MilBase.DefconBuildDatapadPayload then
			sendData(ply, "defcon", "state", {
				state = { level = cfg.DefconDefaultLevel or 5, reason = "DEFCON system is still loading.", changed_by = "System", changed_at = 0 },
				can_change = false,
				history = {},
			})
			return
		end
		MilBase.DefconBuildDatapadPayload(ply, function(payload)
			if IsValid(ply) then sendData(ply, "defcon", "state", payload or {}) end
		end)
	end

	local function sendDailyQuests(ply)
		if not MilBase.DailyQuestGetPayload then
			sendData(ply, "daily_quests", "state", {
				loaded = false, day = "", reset_in = 0, quests = {},
			})
			return
		end
		MilBase.DailyQuestGetPayload(ply, function(payload)
			if IsValid(ply) then sendData(ply, "daily_quests", "state", payload or {}) end
		end)
	end

	local function sendAdminAccess(ply)
		if not staffOwner(ply) then return end
		local rows = {}
		for _, id in ipairs(MilBase.Datapad.TabOrder) do
			local tab = MilBase.Datapad.Tabs[id]
			rows[#rows + 1] = { id = id, name = tab.name, rules = mergedRules(id), base = (cfg.DatapadTabs or {})[id] or {}, override = MilBase.Datapad.AccessOverrides[id] or {} }
		end
		net.Start(NET_ADMIN_DATA)
			net.WriteTable(rows)
		net.Send(ply)
	end

	net.Receive(NET_REQUEST, function(_, ply)
		local tab = net.ReadString()
		local action = net.ReadString()
		local data = net.ReadTable() or {}
		if (ply.mb_nextDatapadReq or 0) > CurTime() then return end
		ply.mb_nextDatapadReq = CurTime() + 0.15
		if not MilBase.DatapadCanAccess(ply, tab) then MilBase.Notify(ply, "Datapad access denied.", "warn") return end
		if tab == "home" then
			sendData(ply, "home", "summary", { profile = playerSummary(ply), apps = tabListFor(ply) })
		elseif tab == "defcon" and action == "set" then
			local ok, err = false, "DEFCON system is unavailable."
			if MilBase.DefconSetLevel then
				ok, err = MilBase.DefconSetLevel(tonumber(data.level), ply, data.reason, "datapad")
			end
			if not ok then MilBase.Notify(ply, err or "Unable to change DEFCON.", "warn") end
			sendDefcon(ply)
		elseif tab == "defcon" then sendDefcon(ply)
		elseif tab == "daily_quests" and action == "claim" then
			local ok, err = false, "Daily quest system is unavailable."
			if MilBase.DailyQuestClaim then ok, err = MilBase.DailyQuestClaim(ply, tostring(data.id or "")) end
			if not ok then MilBase.Notify(ply, err or "Unable to claim that reward.", "warn") end
			sendDailyQuests(ply)
		elseif tab == "daily_quests" then sendDailyQuests(ply)
		elseif tab == "criminal_records" then sendCriminal(ply, data.query or "")
		elseif tab == "charge_lookup" then sendCrimes(ply)
		elseif tab == "medical_records" then sendMedical(ply, data.query or "")
		elseif tab == "medical_checkup" and action == "save" then saveCheckup(ply, data)
		elseif tab == "personnel" and action == "save" then savePersonnel(ply, data)
		elseif tab == "personnel" then sendPersonnel(ply, data.query or "")
		elseif tab == "certifications" then sendCerts(ply, data.query or "")
		elseif tab == "regiment_roster" and MilBase.RosterHandleDatapadRequest then
			MilBase.RosterHandleDatapadRequest(ply, action, data, sendData)
		elseif tab == "incidents" and action == "save" then saveIncident(ply, data)
		elseif tab == "incidents" then sendIncidents(ply, data.query or "")
		elseif tab == "customs_cases" and MilBase.Inspections and MilBase.Inspections.HandleDatapadRequest then
			MilBase.Inspections.HandleDatapadRequest(ply, action, data, sendData)
		elseif tab == "prison_ops" and MilBase.Prison and MilBase.Prison.HandleDatapadRequest then
			MilBase.Prison.HandleDatapadRequest(ply, action, data, sendData)
		elseif tab == "warrants" and action == "save" then saveWarrant(ply, data)
		elseif tab == "warrants" and action == "clear" then clearWarrant(ply, data.id)
		elseif tab == "warrants" then sendWarrants(ply, data.query or "")
		elseif tab == "admin_config" then sendAdminAccess(ply)
		end
	end)

	net.Receive(NET_SLICE, function(_, ply)
		local tab = net.ReadString()
		if (ply.mb_nextDatapadSlice or 0) > CurTime() then return end
		ply.mb_nextDatapadSlice = CurTime() + 2
		if not MilBase.DatapadCanSlice(ply, tab) then MilBase.Notify(ply, "Slicing failed: no access vector.", "warn") return end
		ply.mb_datapadSlices = ply.mb_datapadSlices or {}
		ply.mb_datapadSlices[tab] = CurTime() + (cfg.DatapadSliceUnlockSeconds or 300)
		MilBase.Notify(ply, "Slicer override unlocked: " .. (MilBase.Datapad.Tabs[tab] and MilBase.Datapad.Tabs[tab].name or tab) .. ".", "ok")
		if MilBase.Log then MilBase.Log("datapad", MilBase.LogTag(ply) .. " sliced datapad tab " .. tab, ply) end
		sendOpen(ply, tab)
	end)

	net.Receive(NET_ADMIN, function(_, ply)
		if not staffOwner(ply) then return end
		local action = net.ReadString()
		if action == "list" then sendAdminAccess(ply) return end
		if action ~= "save" then return end
		local tab = net.ReadString()
		local rules = net.ReadTable() or {}
		if not MilBase.Datapad.Tabs[tab] then return end
		MilBase.Datapad.AccessOverrides[tab] = rules
		MilBase.DB.Run(string.format("REPLACE INTO frontier_datapad_access (tab, rules) VALUES (%s, %s)", MilBase.SQLStr(tab), MilBase.SQLStr(util.TableToJSON(rules) or "{}")))
		MilBase.Notify(ply, "Datapad access saved for " .. MilBase.Datapad.Tabs[tab].name .. ".", "ok")
		sendAdminAccess(ply)
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.Datapad.WarrantJoinAlert", function(ply)
		timer.Simple(4, function()
			if not IsValid(ply) then return end
			MilBase.DB.Query("SELECT * FROM frontier_datapad_warrants WHERE steamid = " .. MilBase.SQLStr(ply:SteamID64()) .. " AND status = 'active' AND expires_at > " .. now(), function(rows)
				if not rows or #rows == 0 then return end
				for _, p in ipairs(player.GetAll()) do
					if MilBase.DatapadCanAccess(p, "warrants") then MilBase.Notify(p, "BOLO subject online: " .. ply:MBName() .. ".", "warn") end
				end
			end)
		end)
	end)

	MilBase.RegisterChatCommand("datapad", {
		help = "Open the RP Datapad if you are carrying one.",
		func = function(ply)
			if ply:HasWeapon(cfg.DatapadWeaponClass or "mb_datapad") or ply:IsAdmin() then
				MilBase.DatapadOpen(ply)
			else
				MilBase.Notify(ply, "You need an RP Datapad weapon or a records terminal.", "warn")
			end
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client UI
--------------------------------------------------------------------------

local function ui()
	return MilBase.UI or {
		panel = Color(10, 10, 11, 220), raised = Color(255, 198, 60, 12), hover = Color(255, 198, 60, 25),
		outline = Color(255, 198, 60, 50), accent = Color(255, 198, 60), text = color_white,
		dim = Color(180, 180, 180), faint = Color(110, 110, 110), ok = Color(120, 205, 120),
		warn = Color(255, 198, 60), danger = Color(220, 80, 70),
	}
end
local function font(name, fallback) return (MilBase.UI and name) or (fallback or "DermaDefault") end
if surface and surface.CreateFont then
	surface.CreateFont("MB.DatapadName", { font = "Bebas Neue", size = 46, weight = 400 })
	surface.CreateFont("MB.DatapadNameSmall", { font = "Bebas Neue", size = 38, weight = 400 })
end
local function drawPanel(x, y, w, h, opts)
	if MilBase.DrawPanelBF2 then MilBase.DrawPanelBF2(x, y, w, h, opts or {})
	else surface.SetDrawColor((opts and opts.color) or Color(0,0,0,220)); surface.DrawRect(x,y,w,h); surface.SetDrawColor((opts and opts.accent) or ui().outline); surface.DrawOutlinedRect(x,y,w,h) end
end
local function dateText(ts) ts = tonumber(ts or 0) or 0; return ts > 0 and os.date("%Y-%m-%d %H:%M", ts) or "Unknown" end
local function durationText(seconds)
	seconds = math.max(0, tonumber(seconds or 0) or 0)
	local mins = math.floor(seconds / 60)
	if mins >= 60 then return math.floor(mins / 60) .. "h " .. (mins % 60) .. "m" end
	if mins > 0 then return mins .. "m " .. (seconds % 60) .. "s" end
	return seconds .. "s"
end
local function money(v) return (cfg.CurrencySymbol or "₡") .. tostring(math.floor(tonumber(v or 0) or 0)) end
local function fitText(text, fnt, maxWide)
	text = tostring(text or "")
	maxWide = tonumber(maxWide or 0) or 0
	if maxWide <= 0 or text == "" then return text end
	surface.SetFont(fnt)
	if surface.GetTextSize(text) <= maxWide then return text end
	local suffix = "..."
	while #text > 0 and surface.GetTextSize(text .. suffix) > maxWide do
		text = string.sub(text, 1, #text - 1)
	end
	return text .. suffix
end
local function drawFitText(text, fnt, x, y, col, maxWide, align)
	draw.SimpleText(fitText(text, fnt, maxWide), fnt, x, y, col, align or TEXT_ALIGN_LEFT)
end
local function paintEntry(self, w, h)
	local u = ui()
	surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(self:HasFocus() and u.accent or u.outline); surface.DrawOutlinedRect(0, 0, w, h)
	self:DrawTextEntryText(u.text, u.accent, u.text)
end
local function btn(parent, label, accent, onClick)
	local b = vgui.Create("DButton", parent); b:SetText(""); b:SetTall(34)
	b.Paint = function(self, w, h)
		local u = ui(); local col = accent or u.accent
		drawPanel(0, 0, w, h, { cut = 7, color = self:IsHovered() and Color(col.r, col.g, col.b, 48) or u.raised, accent = col })
		draw.SimpleText(label, font("MB.Small", "DermaDefaultBold"), w / 2, h / 2, u.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end
local function request(tab, action, data)
	net.Start(NET_REQUEST); net.WriteString(tab or ""); net.WriteString(action or ""); net.WriteTable(data or {}); net.SendToServer()
end
local function sliceTab(tab)
	if MilBase.OpenCodeMinigame then
		MilBase.OpenCodeMinigame({
			title = "SLICING — DATAPAD ACCESS",
			subtitle = "Break section encryption to unlock a temporary RP access override.",
			color = Color(120, 200, 140),
			lines = MilBase.GenCodeLines(5),
			onSuccess = function() net.Start(NET_SLICE); net.WriteString(tab); net.SendToServer() end,
		})
	else
		net.Start(NET_SLICE); net.WriteString(tab); net.SendToServer()
	end
end

local frame, body, appList, tabs, profile, activeTab, selected = nil, nil, {}, {}, nil, nil, nil
local contentBuilders = {}
local pendingData = {}

local function clearCCTV()
	if MilBase.CCTVSetActive then MilBase.CCTVSetActive(false) end
end

local function makeSearch(parent, placeholder, onSearch)
	local row = vgui.Create("DPanel", parent); row:Dock(TOP); row:SetTall(38); row:DockMargin(0, 0, 0, 8); row.Paint = nil
	local entry = vgui.Create("DTextEntry", row); entry:Dock(FILL); entry:DockMargin(0, 0, 8, 0); entry:SetPaintBackground(false); entry:SetFont(font("MB.Small", "DermaDefault")); entry:SetPlaceholderText(placeholder or "Search…"); entry.Paint = paintEntry
	local go = btn(row, "SEARCH", ui().accent, function() onSearch(entry:GetValue() or "") end); go:Dock(RIGHT); go:SetWide(110)
	entry.OnEnter = function() onSearch(entry:GetValue() or "") end
	return entry
end

local function section(parent, title, h)
	local p = vgui.Create("DPanel", parent); p:Dock(TOP); p:SetTall(h or 150); p:DockMargin(0, 0, 0, 10)
	p.Paint = function(self, w, h2)
		local u = ui(); drawPanel(0, 0, w, h2, { cut = 8, color = Color(0,0,0,120), accent = u.outline })
		draw.SimpleText(title, font("MB.Small", "DermaDefaultBold"), 12, 8, u.accent)
	end
	return p
end

local function fitLeftPane(w)
	return math.Clamp(math.floor((w or 0) * 0.42), 280, 420)
end

local function selectTab(id)
	if activeTab == "cctv" and id ~= "cctv" then clearCCTV() end
	activeTab = id
	selected = nil
	if not IsValid(body) then return end
	body:Clear()
	body.PerformLayout = nil
	local tab = tabs[id]
	if not tab then return end
	if tab.canSlice and not tab.allowed then
		local p = section(body, tab.name, 180)
		local u = ui()
		p.Paint = function(self, w, h)
			drawPanel(0,0,w,h,{cut=8,color=Color(0,0,0,135),accent=u.danger})
			draw.SimpleText("RESTRICTED APP", font("MB.Big", "DermaLarge"), 16, 16, u.danger)
			draw.SimpleText("Your rank/faction/certs do not grant this section. Use a Slicer Kit to attempt a temporary override.", font("MB.Small", "DermaDefault"), 18, 58, u.dim)
		end
		local b = btn(p, "RUN SLICER OVERRIDE", u.ok, function() sliceTab(id) end); b:SetPos(18, 104); b:SetSize(230, 40)
		return
	end
	local builder = contentBuilders[id]
	if builder then builder(body) else request(id, "list", {}) end
end

local function appButton(parent, tab)
	local b = vgui.Create("DButton", parent); b:Dock(TOP); b:SetTall(50); b:DockMargin(0,0,0,6); b:SetText("")
	b.Paint = function(self, w, h)
		local u = ui(); local on = activeTab == tab.id; local denied = tab.canSlice and not tab.allowed
		local accent = denied and u.warn or (tab.sliced and u.ok or u.accent)
		drawPanel(0,0,w,h,{cut=7,color=on and Color(accent.r,accent.g,accent.b,38) or (self:IsHovered() and u.hover or Color(255,255,255,4)), accent=on and accent or nil})
		draw.SimpleText(tab.icon or "•", font("MB.Small", "DermaDefaultBold"), 14, h/2, accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(tab.name or tab.id, font("MB.Small", "DermaDefaultBold"), 42, 12, u.text)
		local sub = denied and "SLICER OVERRIDE AVAILABLE" or (tab.sliced and "TEMPORARY SLICED ACCESS" or "AUTHORIZED")
		draw.SimpleText(sub, font("MB.Tiny", "DermaDefault"), 42, 31, denied and u.warn or (tab.sliced and u.ok or u.dim))
	end
	b.DoClick = function() selectTab(tab.id) end
	return b
end

local function rebuildApps()
	if not IsValid(appList) then return end
	appList:Clear()
	for _, tab in ipairs(tabs.__order or {}) do appButton(appList, tab) end
end

contentBuilders.home = function(parent)
	local u = ui(); clearCCTV()
	local p = section(parent, "IDENTITY", 158)
	p.Paint = function(self, w, h)
		drawPanel(0,0,w,h,{cut=9,color=Color(0,0,0,125),accent=u.accent})
		local name = (profile and profile.name) or LocalPlayer():MBName()
		local rank = (profile and profile.rank) or ""
		local faction = (profile and profile.faction) or ""
		local certText = table.concat((profile and profile.certs) or {}, ", ")
		if certText == "" then certText = "None listed" end
		draw.SimpleText("RP DATAPAD", font("MB.Big", "DermaLarge"), 18, 12, u.text)
		drawFitText(string.upper(name), "MB.DatapadName", 18, 45, u.accent, w - 36)
		drawFitText(rank .. "  •  " .. faction, font("MB.Small", "DermaDefault"), 20, 103, u.text, w - 40)
		drawFitText("Certs: " .. certText, font("MB.Tiny", "DermaDefault"), 20, 128, u.dim, w - 40)
	end
	local apps = section(parent, "AVAILABLE APPS", 220); apps:Dock(FILL)
	local scroll = vgui.Create("DScrollPanel", apps); scroll:Dock(FILL); scroll:DockMargin(10, 38, 16, 10)
	for _, tab in ipairs(tabs.__order or {}) do
		local row = vgui.Create("DButton", scroll); row:Dock(TOP); row:SetTall(42); row:DockMargin(0,0,0,5); row:SetText("")
		row.Paint = function(self, w, h)
			local denied = tab.canSlice and not tab.allowed; local col = denied and u.warn or (tab.sliced and u.ok or u.accent)
			drawPanel(0,0,w,h,{cut=6,color=self:IsHovered() and Color(col.r,col.g,col.b,34) or Color(255,255,255,4),accent=col})
			drawFitText((tab.icon or "•") .. "  " .. (tab.name or tab.id), font("MB.Small", "DermaDefaultBold"), 12, 6, u.text, w - 26)
			drawFitText(denied and "Can be sliced" or (tab.sliced and "Sliced access active" or "Unlocked"), font("MB.Tiny", "DermaDefault"), 13, 25, col, w - 26)
		end
		row.DoClick = function() selectTab(tab.id) end
	end
end

local function drawRecordRows(scroll, records, detailFn, rowFn)
	if not IsValid(scroll) then return end
	scroll:Clear()
	for _, rec in ipairs(records or {}) do
		if not IsValid(scroll) then return end
		local row = vgui.Create("DButton", scroll); row:Dock(TOP); row:SetTall(72); row:DockMargin(0,0,0,6); row:SetText("")
		row.Paint = function(self,w,h) rowFn(self,w,h,rec, selected == rec) end
		row.DoClick = function() selected = rec; if detailFn then detailFn(rec) end end
	end
	if #(records or {}) == 0 and IsValid(scroll) then
		local l = vgui.Create("DLabel", scroll); l:Dock(TOP); l:SetTall(44); l:SetFont(font("MB.Small", "DermaDefault")); l:SetTextColor(ui().dim); l:SetText("No records found.")
	end
end

contentBuilders.defcon = function(parent)
	local u = ui(); clearCCTV()

	local function render(payload)
		if activeTab ~= "defcon" or not IsValid(parent) then return end
		parent:Clear()
		parent.PerformLayout = nil
		payload = payload or {}
		local state = payload.state or (MilBase.DefconGetState and MilBase.DefconGetState()) or {}
		local level = math.Clamp(math.floor(tonumber(state.level or cfg.DefconDefaultLevel or 5) or 5), 1, 5)
		local definition = MilBase.DefconGetDefinition and MilBase.DefconGetDefinition(level)
			or { name = "DEFCON " .. level, description = "", color = u.accent }
		local history = payload.history or {}

		local scroll = vgui.Create("DScrollPanel", parent)
		scroll:Dock(FILL)

		local current = section(scroll, "CURRENT ALERT CONDITION", 190)
		current.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 135), accent = definition.color })
			draw.SimpleText("DEFCON " .. level, "MB.Huge", 18, 22, definition.color)
			drawFitText(string.upper(definition.name or ""), font("MB.Med", "DermaDefaultBold"), 22, 91, u.text, w - 44)
			drawFitText(definition.description or "", font("MB.Small", "DermaDefault"), 22, 120, u.dim, w - 44)
			drawFitText("ORDER: " .. tostring(state.reason or "No reason supplied."), font("MB.Tiny", "DermaDefault"), 22, 148, u.text, w - 44)
			drawFitText("Set by " .. tostring(state.changed_by or "System") .. "  •  " .. dateText(state.changed_at), font("MB.Tiny", "DermaDefault"), 22, 169, u.faint, w - 44)
		end

		if payload.can_change then
			local controls = section(scroll, "COMMAND AUTHORIZATION", 174)
			local reason = vgui.Create("DTextEntry", controls)
			reason:SetPos(14, 40); reason:SetSize(420, 46)
			reason:SetMultiline(true); reason:SetPlaceholderText("Reason / command order for this DEFCON change…")
			reason:SetPaintBackground(false); reason:SetFont(font("MB.Small", "DermaDefault")); reason.Paint = paintEntry

			local buttons = {}
			for newLevel = 5, 1, -1 do
				local levelValue = newLevel
				local target = MilBase.DefconGetDefinition and MilBase.DefconGetDefinition(levelValue)
					or { name = "DEFCON " .. levelValue, color = u.accent }
				local b = btn(controls, "DEFCON " .. levelValue, target.color, function()
					local why = string.Trim(reason:GetValue() or "")
					Derma_Query(
						"Change the server alert condition to DEFCON " .. levelValue .. " — " .. target.name .. "?",
						"Confirm DEFCON Change",
						"CONFIRM", function() request("defcon", "set", { level = levelValue, reason = why }) end,
						"CANCEL"
					)
				end)
				b:SetSize(100, 42)
				buttons[#buttons + 1] = b
			end
			controls.PerformLayout = function(self, w, h)
				reason:SetPos(14, 40); reason:SetSize(math.max(100, w - 28), 46)
				local gap = 7
				local bw = math.max(70, math.floor((w - 28 - gap * 4) / 5))
				for index, b in ipairs(buttons) do b:SetPos(14 + (index - 1) * (bw + gap), 104); b:SetSize(bw, 42) end
			end
		else
			local denied = section(scroll, "COMMAND AUTHORIZATION", 92)
			denied.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.outline })
				draw.SimpleText("VIEW-ONLY ACCESS", font("MB.Med", "DermaDefaultBold"), 16, 38, u.dim)
				drawFitText("Only authorised staff or configured Navy command ranks can alter the alert condition.", font("MB.Small", "DermaDefault"), 16, 63, u.faint, w - 32)
			end
		end

		local historyHeight = 48 + math.max(1, #history) * 62
		local historyPanel = section(scroll, "RECENT DEFCON CHANGES", historyHeight)
		if #history == 0 then
			local empty = vgui.Create("DLabel", historyPanel)
			empty:SetPos(14, 42); empty:SetSize(400, 24); empty:SetFont(font("MB.Small", "DermaDefault")); empty:SetTextColor(u.faint); empty:SetText("No DEFCON changes have been recorded yet.")
		else
			local historyItems = {}
			for index, row in ipairs(history) do
				local rowLevel = math.Clamp(math.floor(tonumber(row.level or 5) or 5), 1, 5)
				local rowDef = MilBase.DefconGetDefinition and MilBase.DefconGetDefinition(rowLevel)
					or { name = "DEFCON " .. rowLevel, color = u.accent }
				local item = vgui.Create("DPanel", historyPanel)
				item:SetPos(12, 38 + (index - 1) * 62); item:SetSize(420, 56)
				item.Paint = function(self, w, h)
					drawPanel(0, 0, w, h, { cut = 7, color = Color(255, 255, 255, 4), accent = rowDef.color })
					draw.SimpleText("DEFCON " .. rowLevel, font("MB.Small", "DermaDefaultBold"), 12, 8, rowDef.color)
					drawFitText(rowDef.name .. " — " .. tostring(row.reason or ""), font("MB.Tiny", "DermaDefault"), 102, 10, u.text, w - 114)
					drawFitText("By " .. tostring(row.changed_by or "System") .. "  •  " .. dateText(row.changed_at), font("MB.Tiny", "DermaDefault"), 12, 34, u.faint, w - 24)
				end
				historyItems[#historyItems + 1] = item
			end
			historyPanel.PerformLayout = function(self, w, h)
				for itemIndex, item in ipairs(historyItems) do
					item:SetPos(12, 38 + (itemIndex - 1) * 62)
					item:SetSize(math.max(100, w - 24), 56)
				end
			end
		end
	end

	pendingData.defcon = function(payload) render(payload) end
	request("defcon", "get", {})
end

contentBuilders.daily_quests = function(parent)
	local u = ui(); clearCCTV()

	local function resetText(seconds)
		seconds = math.max(0, math.floor(tonumber(seconds or 0) or 0))
		local hours = math.floor(seconds / 3600)
		local minutes = math.floor((seconds % 3600) / 60)
		return string.format("%02dh %02dm", hours, minutes)
	end

	local function render(payload)
		if activeTab ~= "daily_quests" or not IsValid(parent) then return end
		parent:Clear()
		parent.PerformLayout = nil
		payload = payload or {}
		local quests = payload.quests or {}
		local receivedAt = RealTime()

		local scroll = vgui.Create("DScrollPanel", parent)
		scroll:Dock(FILL)

		local header = section(scroll, "DAILY DUTY ORDERS", 112)
		header.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 135), accent = u.accent })
			draw.SimpleText("REPUBLIC DAILY ORDERS", font("MB.Big", "DermaLarge"), 18, 18, u.text)
			drawFitText("Complete your assigned duties and claim each reward before the daily reset.", font("MB.Small", "DermaDefault"), 20, 58, u.dim, w - 40)
			local remaining = math.max(0, (tonumber(payload.reset_in or 0) or 0) - (RealTime() - receivedAt))
			draw.SimpleText("RESET IN  " .. resetText(remaining), font("MB.Small", "DermaDefaultBold"), w - 18, 20, u.accent, TEXT_ALIGN_RIGHT)
			draw.SimpleText("ORDER DATE  " .. tostring(payload.day or ""), font("MB.Tiny", "DermaDefault"), w - 18, 48, u.faint, TEXT_ALIGN_RIGHT)
		end

		if payload.disabled then
			local disabled = section(scroll, "SYSTEM STATUS", 86)
			disabled.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.danger })
				draw.SimpleText("DAILY ORDERS DISABLED", font("MB.Med", "DermaDefaultBold"), 16, 40, u.danger)
			end
			return
		end

		if not payload.loaded then
			local loading = section(scroll, "SYSTEM STATUS", 86)
			loading.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.warn })
				draw.SimpleText("LOADING PERSONAL ORDERS…", font("MB.Med", "DermaDefaultBold"), 16, 40, u.warn)
			end
			return
		end

		if #quests == 0 then
			local empty = section(scroll, "SYSTEM STATUS", 100)
			empty.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.outline })
				draw.SimpleText("NO ORDERS ASSIGNED", font("MB.Med", "DermaDefaultBold"), 16, 35, u.dim)
				draw.SimpleText("Reconnect or ask staff to run mb_daily_reset on your character.", font("MB.Small", "DermaDefault"), 16, 64, u.faint)
			end
			return
		end

		for _, quest in ipairs(quests) do
			local accent = IsColor(quest.color) and quest.color or u.accent
			local target = math.max(1, math.floor(tonumber(quest.target or 1) or 1))
			local progress = math.Clamp(math.floor(tonumber(quest.progress or 0) or 0), 0, target)
			local complete = quest.complete == true or progress >= target
			local claimed = quest.claimed == true
			local panel = section(scroll, string.upper(quest.name or "DAILY ORDER"), 154)
			local claimButton
			panel.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 130), accent = claimed and u.faint or (complete and u.ok or accent) })
				drawFitText(quest.description or "", font("MB.Small", "DermaDefault"), 16, 40, u.text, w - 32)
				local status = claimed and "REWARD CLAIMED" or (complete and "ORDER COMPLETE" or (progress .. " / " .. target))
				draw.SimpleText(status, font("MB.Small", "DermaDefaultBold"), 16, 76, claimed and u.faint or (complete and u.ok or accent))
				MilBase.DrawBar(16, 103, math.max(80, w - 32), 8, progress / target, claimed and u.faint or (complete and u.ok or accent))
				local rewards = {}
				if tonumber(quest.reward_xp or 0) > 0 then rewards[#rewards + 1] = tostring(quest.reward_xp) .. " XP" end
				if tonumber(quest.reward_credits or 0) > 0 then rewards[#rewards + 1] = cfg.CurrencySymbol .. tostring(quest.reward_credits) end
				if tostring(quest.reward_item or "") ~= "" then rewards[#rewards + 1] = tostring(quest.reward_item_amount or 1) .. "x " .. tostring(quest.reward_item) end
				draw.SimpleText("REWARD  " .. table.concat(rewards, "  •  "), font("MB.Tiny", "DermaDefault"), 16, 124, u.dim)
			end
			if complete and not claimed then
				claimButton = btn(panel, "CLAIM REWARD", u.ok, function() request("daily_quests", "claim", { id = quest.id }) end)
				claimButton:SetSize(150, 34)
				panel.PerformLayout = function(self, w, h) claimButton:SetPos(w - 166, h - 45) end
			end
		end
	end

	pendingData.daily_quests = function(payload) render(payload) end
	request("daily_quests", "get", {})
end

contentBuilders.criminal_records = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search criminal records…", function(q) request("criminal_records", "search", { query = q }) end)
	local wrap = vgui.Create("DPanel", parent); wrap:Dock(FILL); wrap.Paint = nil
	local list = vgui.Create("DScrollPanel", wrap); list:Dock(LEFT); list:SetWide(360); list:DockMargin(0,0,12,0)
	wrap.PerformLayout = function(self, w, h) list:SetWide(fitLeftPane(w)) end
	local detail = section(wrap, "RECORD DETAILS", 100); detail:Dock(FILL)
	local function paintDetail(rec)
		detail.Paint = function(self,w,h)
			drawPanel(0,0,w,h,{cut=9,color=Color(0,0,0,125),accent=u.warn})
			if not rec then draw.SimpleText("SELECT A RECORD", font("MB.Big", "DermaLarge"), 18, 18, u.text); return end
			draw.SimpleText(string.upper(rec.rp_name or "Unknown"), font("MB.Big", "DermaLarge"), 18, 14, u.text)
			draw.SimpleText((rec.steam_name or "") .. "  •  " .. (rec.steamid or ""), font("MB.Tiny", "DermaDefault"), 18, 50, u.dim)
			draw.SimpleText("CRIMES", font("MB.Small", "DermaDefaultBold"), 18, 88, u.accent)
			draw.DrawText(rec.crime_names or "", font("MB.Small", "DermaDefault"), 18, 110, u.text)
			draw.SimpleText("CHARGES", font("MB.Small", "DermaDefaultBold"), 18, 164, u.accent)
			draw.DrawText(rec.charge_text or "", font("MB.Tiny", "DermaDefault"), 18, 186, u.dim)
			draw.SimpleText("OFFICER: " .. (rec.officer_name or "Unknown"), font("MB.Small", "DermaDefault"), 18, h - 132, u.text)
			draw.SimpleText("DATE: " .. dateText(rec.created_at), font("MB.Small", "DermaDefault"), 18, h - 106, u.text)
			draw.SimpleText("TIME: " .. durationText(rec.jail_seconds), font("MB.Small", "DermaDefault"), 18, h - 80, u.text)
			draw.SimpleText("FINE: " .. money(rec.fine_amount) .. "  •  OWED: " .. money(rec.fine_owed), font("MB.Small", "DermaDefault"), 18, h - 54, (rec.fine_owed or 0) > 0 and u.warn or u.ok)
			draw.SimpleText("STATUS: " .. string.upper(rec.status or "recorded"), font("MB.Small", "DermaDefaultBold"), 18, h - 28, rec.status == "active" and u.danger or u.accent)
		end
	end
	paintDetail(nil)
	pendingData.criminal_records = function(payload)
		drawRecordRows(list, payload.records, paintDetail, function(self,w,h,rec,on)
			drawPanel(0,0,w,h,{cut=7,color=on and Color(u.accent.r,u.accent.g,u.accent.b,35) or (self:IsHovered() and u.hover or Color(255,255,255,4)),accent=on and u.accent or nil})
			drawFitText(rec.rp_name or "Unknown", font("MB.Small", "DermaDefaultBold"), 12, 8, u.text, w - 110)
			drawFitText(rec.crime_names or "", font("MB.Tiny", "DermaDefault"), 12, 30, u.dim, w - 24)
			draw.SimpleText(dateText(rec.created_at), font("MB.Tiny", "DermaDefault"), 12, 52, u.faint)
			draw.SimpleText(money(rec.fine_amount), font("MB.Small", "DermaDefaultBold"), w-12, 10, u.accent, TEXT_ALIGN_RIGHT)
		end)
	end
	request("criminal_records", "search", { query = "" })
end

contentBuilders.charge_lookup = function(parent)
	local u = ui(); clearCCTV()
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.charge_lookup = function(payload)
		list:Clear()
		for _, c in ipairs(payload.crimes or {}) do
			local row = section(list, "", 78)
			row.Paint = function(self,w,h)
				drawPanel(0,0,w,h,{cut=8,color=Color(255,255,255,4),accent=u.accent})
				draw.SimpleText("[" .. (c.code or "") .. "] " .. (c.name or "Crime"), font("MB.Small", "DermaDefaultBold"), 12, 8, u.text)
				draw.SimpleText(durationText(c.time) .. "  •  " .. money(c.fine), font("MB.Tiny", "DermaDefault"), w-12, 12, u.accent, TEXT_ALIGN_RIGHT)
				draw.DrawText(c.charge or "", font("MB.Tiny", "DermaDefault"), 12, 34, u.dim)
			end
		end
	end
	request("charge_lookup", "list", {})
end

contentBuilders.cctv = function(parent)
	local u = ui()
	if MilBase.CCTVSetActive then MilBase.CCTVSetActive(true) end
	local p = section(parent, "SECURITY FEEDS", 190)
	p.Paint = function(self,w,h)
		drawPanel(0,0,w,h,{cut=9,color=Color(0,0,0,125),accent=u.accent})
		draw.SimpleText("CCTV / HELMET CAMS", font("MB.Big", "DermaLarge"), 18, 18, u.text)
		draw.SimpleText("The live camera monitor is active while this app is open.", font("MB.Small", "DermaDefault"), 20, 58, u.dim)
		draw.DrawText("MOUSE1/MOUSE2 cycle feeds. Reload toggles focus on the datapad weapon. In focus, A/D pans physical cameras.", font("MB.Small", "DermaDefault"), 20, 86, u.text)
	end
	local controls = vgui.Create("DPanel", p); controls:SetPos(18, 132); controls:SetSize(460, 38); controls.Paint = nil
	local nextB = btn(controls, "NEXT FEED", u.accent, function() if MilBase.CCTVCycle then MilBase.CCTVCycle(1) end end); nextB:Dock(LEFT); nextB:SetWide(135); nextB:DockMargin(0,0,8,0)
	local prevB = btn(controls, "PREV FEED", u.accent, function() if MilBase.CCTVCycle then MilBase.CCTVCycle(-1) end end); prevB:Dock(LEFT); prevB:SetWide(135); prevB:DockMargin(0,0,8,0)
	local full = btn(controls, "FOCUS", u.ok, function() if MilBase.CCTVToggleFull then MilBase.CCTVToggleFull() end end); full:Dock(FILL)
	p.PerformLayout = function(self, w, h) controls:SetPos(18, h - 52); controls:SetSize(math.max(280, w - 36), 38) end
end

local function onlineSelect(parent, onPick)
	local box = vgui.Create("DComboBox", parent); box:Dock(TOP); box:SetTall(32); box:DockMargin(0,0,0,8); box:SetValue("Select online player…")
	for _, p in ipairs(player.GetAll()) do box:AddChoice(p:MBName() .. "  •  " .. p:Nick(), p) end
	box.OnSelect = function(_, _, _, data) if onPick then onPick(data) end end
	return box
end

contentBuilders.medical_records = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search medical records…", function(q) request("medical_records", "search", { query = q }) end)
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.medical_records = function(payload)
		drawRecordRows(list, payload.records, nil, function(self,w,h,rec,on)
			drawPanel(0,0,w,h,{cut=7,color=self:IsHovered() and u.hover or Color(255,255,255,4),accent=u.accent})
			drawFitText(rec.rp_name or "Unknown", font("MB.Small", "DermaDefaultBold"), 12, 8, u.text, w - 24)
			drawFitText((rec.diagnosis or "No diagnosis") .. "  •  " .. (rec.duty_status or ""), font("MB.Tiny", "DermaDefault"), 12, 30, u.dim, w - 24)
			drawFitText("Medic: " .. (rec.medic_name or "Unknown") .. "  •  " .. dateText(rec.created_at), font("MB.Tiny", "DermaDefault"), 12, 52, u.faint, w - 24)
		end)
	end
	request("medical_records", "search", { query = "" })
end

contentBuilders.medical_checkup = function(parent)
	local u = ui(); clearCCTV()
	local form = section(parent, "NEW MEDICAL CHECKUP", 390)
	local inside = vgui.Create("DPanel", form); inside:Dock(FILL); inside:DockMargin(14, 42, 14, 14); inside.Paint = nil
	local target
	onlineSelect(inside, function(p) target = p end)
	local diagnosis = vgui.Create("DTextEntry", inside); diagnosis:Dock(TOP); diagnosis:SetTall(32); diagnosis:DockMargin(0,0,0,8); diagnosis:SetPlaceholderText("Diagnosis / injury…"); diagnosis:SetPaintBackground(false); diagnosis:SetFont(font("MB.Small", "DermaDefault")); diagnosis.Paint = paintEntry
	local treatment = vgui.Create("DTextEntry", inside); treatment:Dock(TOP); treatment:SetTall(32); treatment:DockMargin(0,0,0,8); treatment:SetPlaceholderText("Treatment given…"); treatment:SetPaintBackground(false); treatment:SetFont(font("MB.Small", "DermaDefault")); treatment.Paint = paintEntry
	local status = vgui.Create("DComboBox", inside); status:Dock(TOP); status:SetTall(32); status:DockMargin(0,0,0,8); status:SetValue("Fit for duty"); for _, s in ipairs({"Fit for duty","Light duty","Medical leave","Grounded from combat","Needs bacta treatment","Psych eval recommended"}) do status:AddChoice(s) end
	local notes = vgui.Create("DTextEntry", inside); notes:Dock(TOP); notes:SetTall(78); notes:DockMargin(0,0,0,10); notes:SetMultiline(true); notes:SetPlaceholderText("Medical notes…"); notes:SetPaintBackground(false); notes:SetFont(font("MB.Small", "DermaDefault")); notes.Paint = paintEntry
	local save = btn(inside, "SAVE CHECKUP", u.ok, function() request("medical_checkup", "save", { target = target, diagnosis = diagnosis:GetValue(), treatment = treatment:GetValue(), status = status:GetValue(), notes = notes:GetValue() }) end)
	save:Dock(TOP); save:SetTall(38)
end

contentBuilders.personnel = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search personnel files…", function(q) request("personnel", "search", { query = q }) end)
	local top = section(parent, "ADD COMMAND / PERSONNEL NOTE", 250)
	local inner = vgui.Create("DPanel", top); inner:Dock(FILL); inner:DockMargin(14,42,14,14); inner.Paint = nil
	local target; onlineSelect(inner, function(p) target = p end)
	local kind = vgui.Create("DComboBox", inner); kind:Dock(TOP); kind:SetTall(30); kind:DockMargin(0,0,0,8); kind:SetValue("Command Note"); for _, s in ipairs({"Command Note","Commendation","Disciplinary","Training","Promotion Note"}) do kind:AddChoice(s) end
	local notes = vgui.Create("DTextEntry", inner); notes:Dock(TOP); notes:SetTall(62); notes:DockMargin(0,0,0,8); notes:SetMultiline(true); notes:SetPlaceholderText("Personnel note…"); notes:SetPaintBackground(false); notes:SetFont(font("MB.Small", "DermaDefault")); notes.Paint = paintEntry
	local saveNote = btn(inner, "SAVE NOTE", u.ok, function() request("personnel", "save", { target = target, entry_type = kind:GetValue(), notes = notes:GetValue() }) end); saveNote:Dock(TOP); saveNote:SetTall(36)
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.personnel = function(payload)
		list:Clear()
		for _, p in ipairs(payload.online or {}) do
			local row = section(list, "", 58)
			row.Paint = function(self,w,h) drawPanel(0,0,w,h,{cut=7,color=Color(255,255,255,4),accent=u.accent}); drawFitText(p.rp_name, font("MB.Small","DermaDefaultBold"), 12, 8, u.text, w - 24); drawFitText(p.rank .. " • " .. p.faction .. " • " .. p.rank_group, font("MB.Tiny","DermaDefault"), 12, 32, u.dim, w - 24) end
		end
		for _, rec in ipairs(payload.records or {}) do
			local row = section(list, "", 64)
			row.Paint = function(self,w,h) drawPanel(0,0,w,h,{cut=7,color=Color(255,255,255,4),accent=u.warn}); drawFitText((rec.entry_type or "Note") .. " — " .. (rec.rp_name or "Unknown"), font("MB.Small","DermaDefaultBold"), 12, 8, u.text, w - 150); drawFitText(rec.notes or "", font("MB.Tiny","DermaDefault"), 12, 30, u.dim, w - 24); draw.SimpleText(dateText(rec.created_at), font("MB.Tiny","DermaDefault"), w-12, 10, u.faint, TEXT_ALIGN_RIGHT) end
		end
	end
	request("personnel", "search", { query = "" })
end

contentBuilders.certifications = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search certification holders…", function(q) request("certifications", "search", { query = q }) end)
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.certifications = function(payload)
		list:Clear()
		for _, p in ipairs(payload.online or {}) do
			local names = {}; for _, c in ipairs(p.certs or {}) do names[#names+1] = c.name end
			local row = section(list, "", 64)
			row.Paint = function(self,w,h) drawPanel(0,0,w,h,{cut=7,color=Color(255,255,255,4),accent=u.accent}); drawFitText(p.rp_name, font("MB.Small","DermaDefaultBold"), 12, 8, u.text, w - 24); drawFitText(p.rank .. " • " .. p.faction, font("MB.Tiny","DermaDefault"), 12, 30, u.dim, w - 24); drawFitText(#names > 0 and table.concat(names, ", ") or "No certs", font("MB.Tiny","DermaDefault"), 12, 48, #names > 0 and u.ok or u.faint, w - 24) end
		end
	end
	request("certifications", "search", { query = "" })
end

contentBuilders.regiment_roster = function(parent)
	local u = ui(); clearCCTV()
	if not MilBase.BuildRegimentRosterDatapad then
		local unavailable = section(parent, "REGIMENT ROSTER", 110)
		unavailable.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.danger })
			draw.SimpleText("Roster service is unavailable.", font("MB.Small", "DermaDefaultBold"), 14, 48, u.danger)
		end
		return
	end
	MilBase.BuildRegimentRosterDatapad(parent, request, {
		ui = ui,
		font = font,
		drawPanel = drawPanel,
		dateText = dateText,
		drawFitText = drawFitText,
		paintEntry = paintEntry,
		btn = btn,
		section = section,
		setHandler = function(handler) pendingData.regiment_roster = handler end,
	})
end

contentBuilders.incidents = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search incident reports…", function(q) request("incidents", "search", { query = q }) end)
	local form = section(parent, "NEW INCIDENT REPORT", 290)
	local inner = vgui.Create("DPanel", form); inner:Dock(FILL); inner:DockMargin(14,42,14,14); inner.Paint = nil
	local title = vgui.Create("DTextEntry", inner); title:Dock(TOP); title:SetTall(30); title:DockMargin(0,0,0,6); title:SetPlaceholderText("Title…"); title:SetPaintBackground(false); title:SetFont(font("MB.Small","DermaDefault")); title.Paint = paintEntry
	local cat = vgui.Create("DComboBox", inner); cat:Dock(TOP); cat:SetTall(30); cat:DockMargin(0,0,0,6); cat:SetValue("Security"); for _, s in ipairs({"Security","Medical","Battle Report","Misconduct","Equipment Loss","Other"}) do cat:AddChoice(s) end
	local involved = vgui.Create("DTextEntry", inner); involved:Dock(TOP); involved:SetTall(30); involved:DockMargin(0,0,0,6); involved:SetPlaceholderText("Involved players / witnesses…"); involved:SetPaintBackground(false); involved:SetFont(font("MB.Small","DermaDefault")); involved.Paint = paintEntry
	local notes = vgui.Create("DTextEntry", inner); notes:Dock(TOP); notes:SetTall(62); notes:DockMargin(0,0,0,8); notes:SetMultiline(true); notes:SetPlaceholderText("Report details…"); notes:SetPaintBackground(false); notes:SetFont(font("MB.Small","DermaDefault")); notes.Paint = paintEntry
	local saveReport = btn(inner, "SAVE REPORT", u.ok, function() request("incidents", "save", { title = title:GetValue(), category = cat:GetValue(), involved = involved:GetValue(), notes = notes:GetValue(), status = "open" }) end); saveReport:Dock(TOP); saveReport:SetTall(36)
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.incidents = function(payload)
		drawRecordRows(list, payload.records, nil, function(self,w,h,rec,on) drawPanel(0,0,w,h,{cut=7,color=self:IsHovered() and u.hover or Color(255,255,255,4),accent=u.warn}); drawFitText(rec.title or "Incident", font("MB.Small","DermaDefaultBold"), 12, 8, u.text, w - 24); drawFitText((rec.category or "") .. " • " .. (rec.involved or ""), font("MB.Tiny","DermaDefault"), 12, 30, u.dim, w - 24); drawFitText("By " .. (rec.author_name or "Unknown") .. " • " .. dateText(rec.created_at), font("MB.Tiny","DermaDefault"), 12, 52, u.faint, w - 24) end)
	end
	request("incidents", "search", { query = "" })
end

contentBuilders.customs_cases = function(parent)
	local u = ui(); clearCCTV()
	local function customButton(parentPanel, label, accent, callback)
		local button = vgui.Create("DButton", parentPanel)
		button:SetText("")
		button.Paint = function(self, w, h)
			local col = accent or u.accent
			drawPanel(0, 0, w, h, {
				cut = 6,
				color = self:IsHovered() and Color(col.r, col.g, col.b, 42) or Color(255, 255, 255, 5),
				accent = col,
			})
			drawFitText(string.upper(tostring(label or "ACTION")),
				font("MB.Tiny", "DermaDefaultBold"), 12, h / 2 - 7, u.text, w - 24)
		end
		button.DoClick = callback
		return button
	end

	local function render(payload)
		if activeTab ~= "customs_cases" or not IsValid(parent) then return end
		parent:Clear()
		parent.PerformLayout = nil
		payload = payload or {}
		local cases = payload.cases or {}
		local selection = payload.selection or {}
		local selectedCase = payload.selected

		local header = vgui.Create("DPanel", parent)
		header:Dock(TOP)
		header:SetTall(74)
		header:DockMargin(0, 0, 0, 10)
		header.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 135), accent = u.accent })
			draw.SimpleText("CUSTOMS / INSPECTION CASES", font("MB.Big", "DermaLarge"), 16, 10, u.text)
			drawFitText("Select a case and physical subject. Actions remain proximity-checked by the server.",
				font("MB.Tiny", "DermaDefault"), 18, 49, u.dim, w - 150)
		end
		local refresh = btn(header, "REFRESH", u.accent, function()
			request("customs_cases", "get", { caseID = selection.caseID, kind = selection.kind, index = selection.index })
		end)
		refresh:SetSize(108, 32)
		header.PerformLayout = function(self, w) refresh:SetPos(w - 124, 21) end

		local left = vgui.Create("DPanel", parent)
		left:Dock(LEFT)
		left:SetWide(255)
		left:DockMargin(0, 0, 10, 0)
		left.Paint = nil
		parent.PerformLayout = function(self, w)
			left:SetWide(math.Clamp(math.floor(w * 0.32), 220, 300))
		end

		local caseTitlePanel = vgui.Create("DPanel", left)
		caseTitlePanel:Dock(TOP)
		caseTitlePanel:SetTall(34)
		caseTitlePanel.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 5, color = Color(0, 0, 0, 120), accent = u.outline })
			draw.SimpleText("ACTIVE CASES", font("MB.Small", "DermaDefaultBold"), 10, h / 2, u.accent,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local caseList = vgui.Create("DScrollPanel", left)
		caseList:Dock(TOP)
		caseList:SetTall(math.min(220, 62 + #cases * 62))
		caseList:DockMargin(0, 6, 0, 10)
		if #cases == 0 then
			local empty = vgui.Create("DLabel", caseList)
			empty:Dock(TOP); empty:SetTall(58); empty:SetFont(font("MB.Small", "DermaDefault"))
			empty:SetTextColor(u.faint); empty:SetWrap(true); empty:SetText("No landed or approaching inspection cases are active.")
		end
		for _, caseRow in ipairs(cases) do
			local rowData = caseRow
			local row = vgui.Create("DButton", caseList)
			row:Dock(TOP); row:SetTall(58); row:DockMargin(0, 0, 4, 6); row:SetText("")
			row.Paint = function(self, w, h)
				local active = selection.caseID == rowData.id
				local col = active and u.accent or (rowData.status == "landed" and u.ok or u.warn)
				drawPanel(0, 0, w, h, {
					cut = 6,
					color = active and Color(col.r, col.g, col.b, 34)
						or (self:IsHovered() and Color(255, 255, 255, 8) or Color(255, 255, 255, 3)),
					accent = col,
				})
				drawFitText(rowData.name or rowData.id, font("MB.Small", "DermaDefaultBold"), 10, 8, u.text, w - 20)
				drawFitText(string.upper(tostring(rowData.statusLabel or rowData.status or "UNKNOWN"))
					.. "  •  EVIDENCE " .. tostring(rowData.evidence or 0),
					font("MB.Tiny", "DermaDefault"), 10, 34, col, w - 20)
			end
			row.DoClick = function()
				request("customs_cases", "select", { caseID = rowData.id, kind = "ship", index = 0 })
			end
		end

		local subjectTitle = vgui.Create("DPanel", left)
		subjectTitle:Dock(TOP); subjectTitle:SetTall(34)
		subjectTitle.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 5, color = Color(0, 0, 0, 120), accent = u.outline })
			draw.SimpleText("INSPECTION SUBJECTS", font("MB.Small", "DermaDefaultBold"), 10, h / 2, u.accent,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local subjects = vgui.Create("DScrollPanel", left)
		subjects:Dock(FILL); subjects:DockMargin(0, 6, 0, 0)
		for _, subject in ipairs(selectedCase and selectedCase.subjects or {}) do
			local subjectRow = subject
			local row = vgui.Create("DButton", subjects)
			row:Dock(TOP); row:SetTall(46); row:DockMargin(0, 0, 4, 5); row:SetText("")
			row.Paint = function(self, w, h)
				local active = selection.kind == subjectRow.kind and tonumber(selection.index or 0) == tonumber(subjectRow.index or 0)
				local col = (subjectRow.state == "DETAINED" or subjectRow.state == "SEIZED") and u.warn
					or subjectRow.state == "SEARCHED" and u.ok or u.accent
				drawPanel(0, 0, w, h, { cut = 5,
					color = active and Color(col.r, col.g, col.b, 32) or (self:IsHovered() and u.hover or Color(255,255,255,3)),
					accent = active and col or nil })
				drawFitText(subjectRow.label or "SUBJECT", font("MB.Tiny", "DermaDefaultBold"), 10, 8, u.text, w - 20)
				drawFitText(subjectRow.state or "AVAILABLE", font("MB.Tiny", "DermaDefault"), 10, 27, col, w - 20)
			end
			row.DoClick = function()
				request("customs_cases", "select", {
					caseID = selection.caseID,
					kind = subjectRow.kind,
					index = subjectRow.index,
				})
			end
		end

		local right = vgui.Create("DPanel", parent)
		right:Dock(FILL); right.Paint = nil
		if not selectedCase then
			local empty = section(right, "NO CASE SELECTED", 130)
			empty.Paint = function(self, w, h)
				drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = u.outline })
				draw.SimpleText("Choose an active case from the left.", font("MB.Small", "DermaDefault"), 16, 58, u.dim)
			end
			return
		end

		local summary = vgui.Create("DPanel", right)
		summary:Dock(TOP); summary:SetTall(92); summary:DockMargin(0, 0, 0, 8)
		summary.Paint = function(self, w, h)
			local statusCol = selectedCase.nearby and u.ok or u.warn
			drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 130), accent = statusCol })
			drawFitText(selectedCase.title or selectedCase.name or "CUSTOMS CASE", font("MB.Med", "DermaDefaultBold"), 14, 11, u.text, w - 28)
			drawFitText((selectedCase.subjectTitle or "VESSEL") .. "  •  "
				.. (selectedCase.nearby and "IN INTERACTION RANGE" or "MOVE CLOSER TO SUBJECT"),
				font("MB.Tiny", "DermaDefault"), 15, 43, statusCol, w - 30)
			drawFitText("SUSPICION " .. tostring(selectedCase.suspicion or 0) .. "%  •  EVIDENCE "
				.. tostring(selectedCase.evidence or 0) .. "  •  " .. string.upper(tostring(selectedCase.statusLabel or "UNKNOWN")),
				font("MB.Tiny", "DermaDefault"), 15, 66, u.dim, w - 30)
		end

		local detail = vgui.Create("DScrollPanel", right)
		detail:Dock(FILL)
		local bodyLabel = vgui.Create("DLabel", detail)
		bodyLabel:Dock(TOP); bodyLabel:DockMargin(10, 8, 12, 12)
		bodyLabel:SetFont(font("MB.Small", "DermaDefault")); bodyLabel:SetTextColor(u.dim)
		bodyLabel:SetWrap(true); bodyLabel:SetAutoStretchVertical(true)
		bodyLabel:SetText(tostring(selectedCase.body or "No case details are available."))

		local actionHeader = vgui.Create("DLabel", detail)
		actionHeader:Dock(TOP); actionHeader:DockMargin(10, 4, 10, 6); actionHeader:SetTall(24)
		actionHeader:SetFont(font("MB.Small", "DermaDefaultBold")); actionHeader:SetTextColor(u.accent)
		actionHeader:SetText("AVAILABLE ACTIONS")

		local actions = selectedCase.actions or {}
		if #actions == 0 then
			local none = vgui.Create("DLabel", detail)
			none:Dock(TOP); none:DockMargin(10, 0, 10, 8); none:SetTall(38)
			none:SetFont(font("MB.Small", "DermaDefault")); none:SetTextColor(u.faint)
			none:SetText("No actions are available for this subject.")
		end
		for index, action in ipairs(actions) do
			local actionData = action
			local button = customButton(detail, actionData.label or actionData.id, actionData.danger and u.danger or u.accent, function()
				request("customs_cases", "action", {
					caseID = selection.caseID,
					kind = selection.kind,
					index = selection.index,
					action = actionData.id,
				})
			end)
			button:Dock(TOP); button:SetTall(40); button:DockMargin(10, 0, 12, 6)
			button:SetEnabled(selectedCase.nearby == true)
		end
	end

	pendingData.customs_cases = function(payload)
		render(payload)
	end
	request("customs_cases", "get", {})
end

contentBuilders.prison_ops = function(parent)
	if not MilBase.BuildPrisonDatapad then
		local p = section(parent, "PRISON OPERATIONS UNAVAILABLE", 140)
		p.Paint = function(self, w, h)
			drawPanel(0,0,w,h,{cut=8,color=Color(0,0,0,130),accent=ui().warn})
			draw.SimpleText("Prison Operations failed to initialise. Reconnect or contact staff.", font("MB.Small","DermaDefault"), 14, 54, ui().dim)
		end
		return
	end
	MilBase.BuildPrisonDatapad(parent, request, {
		ui = ui, font = font, section = section, button = btn, pending = pendingData,
		drawPanel = drawPanel, drawFitText = drawFitText,
	})
end

contentBuilders.warrants = function(parent)
	local u = ui(); clearCCTV()
	makeSearch(parent, "Search warrants / BOLOs…", function(q) request("warrants", "search", { query = q }) end)
	local form = section(parent, "NEW WARRANT / BOLO", 260)
	local inner = vgui.Create("DPanel", form); inner:Dock(FILL); inner:DockMargin(14,42,14,14); inner.Paint = nil
	local target; onlineSelect(inner, function(p) target = p end)
	local reason = vgui.Create("DTextEntry", inner); reason:Dock(TOP); reason:SetTall(62); reason:DockMargin(0,0,0,8); reason:SetMultiline(true); reason:SetPlaceholderText("Reason…"); reason:SetPaintBackground(false); reason:SetFont(font("MB.Small","DermaDefault")); reason.Paint = paintEntry
	local minutes = vgui.Create("DTextEntry", inner); minutes:Dock(TOP); minutes:SetTall(30); minutes:DockMargin(0,0,0,8); minutes:SetNumeric(true); minutes:SetValue("60"); minutes:SetPaintBackground(false); minutes:SetFont(font("MB.Small","DermaDefault")); minutes.Paint = paintEntry
	local issueBolo = btn(inner, "ISSUE BOLO", u.warn, function() request("warrants", "save", { target = target, reason = reason:GetValue(), minutes = tonumber(minutes:GetValue()) or 60 }) end); issueBolo:Dock(TOP); issueBolo:SetTall(36)
	local list = vgui.Create("DScrollPanel", parent); list:Dock(FILL)
	pendingData.warrants = function(payload)
		list:Clear()
		for _, rec in ipairs(payload.records or {}) do
			local row = vgui.Create("DPanel", list); row:Dock(TOP); row:SetTall(82); row:DockMargin(0,0,0,6)
			row.Paint = function(self,w,h) drawPanel(0,0,w,h,{cut=7,color=Color(255,255,255,4),accent=rec.status == "active" and u.danger or u.faint}); drawFitText(rec.rp_name or "Unknown", font("MB.Small","DermaDefaultBold"), 12, 8, u.text, w - 110); drawFitText(rec.reason or "", font("MB.Tiny","DermaDefault"), 12, 30, u.dim, w - 24); drawFitText("Issuer: " .. (rec.issuer_name or "Unknown") .. " • expires " .. dateText(rec.expires_at), font("MB.Tiny","DermaDefault"), 12, 52, u.faint, w - 24); draw.SimpleText(string.upper(rec.status or "active"), font("MB.Tiny","DermaDefault"), w-12, 10, rec.status == "active" and u.danger or u.faint, TEXT_ALIGN_RIGHT) end
			if rec.status == "active" then local clear = btn(row, "CLEAR", u.ok, function() request("warrants", "clear", { id = rec.id }) end); clear:SetPos(row:GetWide()-100, 38); clear:SetSize(84, 28); row.PerformLayout = function(self,w,h) clear:SetPos(w-100,38) end end
		end
	end
	request("warrants", "search", { query = "" })
end

contentBuilders.admin_config = function(parent)
	local u = ui(); clearCCTV()
	local left = vgui.Create("DScrollPanel", parent); left:Dock(LEFT); left:SetWide(280); left:DockMargin(0,0,12,0)
	parent.PerformLayout = function(self, w, h) left:SetWide(math.Clamp(math.floor(w * 0.34), 220, 310)) end
	local right = section(parent, "EDIT ACCESS RULES", 100); right:Dock(FILL)
	local editor = vgui.Create("DTextEntry", right); editor:Dock(FILL); editor:DockMargin(14,42,14,54); editor:SetMultiline(true); editor:SetPaintBackground(false); editor:SetFont("DermaDefault"); editor.Paint = paintEntry
	local selectedID
	local save = btn(right, "SAVE JSON RULES", u.ok, function()
		if not selectedID then return end
		local tbl = util.JSONToTable(editor:GetValue() or "{}")
		if not istable(tbl) then MilBase.Notify("Invalid JSON.") return end
		net.Start(NET_ADMIN); net.WriteString("save"); net.WriteString(selectedID); net.WriteTable(tbl); net.SendToServer()
	end); save:Dock(BOTTOM); save:SetTall(40); save:DockMargin(14,0,14,10)
	local function fill(rows)
		left:Clear()
		for _, row in ipairs(rows or {}) do
			local b = vgui.Create("DButton", left); b:Dock(TOP); b:SetTall(54); b:DockMargin(0,0,0,6); b:SetText("")
			b.Paint = function(self,w,h) local on = selectedID == row.id; drawPanel(0,0,w,h,{cut=7,color=on and Color(u.accent.r,u.accent.g,u.accent.b,35) or (self:IsHovered() and u.hover or Color(255,255,255,4)),accent=on and u.accent or nil}); draw.SimpleText(row.name, font("MB.Small","DermaDefaultBold"), 12, 8, u.text); draw.SimpleText(row.id, font("MB.Tiny","DermaDefault"), 12, 30, u.dim) end
			b.DoClick = function() selectedID = row.id; editor:SetText(util.TableToJSON(row.rules or {}, true) or "{}") end
		end
	end
	pendingData.admin_config = fill
	net.Start(NET_ADMIN); net.WriteString("list"); net.SendToServer()
end

net.Receive(NET_DATA, function()
	local tab = net.ReadString(); local action = net.ReadString(); local payload = net.ReadTable() or {}
	if not IsValid(frame) or activeTab ~= tab then return end
	local handler = pendingData[tab]
	if handler then handler(payload, action) end
end)

net.Receive(NET_ADMIN_DATA, function()
	local rows = net.ReadTable() or {}
	local handler = pendingData.admin_config
	if handler then handler(rows, "admin") end
end)

hook.Add("MilBase.DefconUpdated", "MilBase.Datapad.RefreshDefcon", function()
	if IsValid(frame) and activeTab == "defcon" then request("defcon", "get", {}) end
end)

hook.Add("MilBase.DailyQuestsUpdated", "MilBase.Datapad.RefreshDailyQuests", function()
	if IsValid(frame) and activeTab == "daily_quests" then request("daily_quests", "get", {}) end
end)

local function openDatapad(preferred, list, prof)
	if IsValid(frame) then frame:Remove() end
	tabs = { __order = {} }; profile = prof or {}
	for _, t in ipairs(list or {}) do tabs[t.id] = t; tabs.__order[#tabs.__order + 1] = t end
	local u = ui()
	local sw, sh = ScrW(), ScrH()
	local maxW = math.max(640, math.floor(sw * (cfg.DatapadMaxScreenWidth or 0.72)))
	local maxH = math.max(480, math.floor(sh * (cfg.DatapadMaxScreenHeight or 0.78)))
	local fw = math.Clamp(cfg.DatapadWindowWidth or 960, 720, maxW)
	local fh = math.Clamp(cfg.DatapadWindowHeight or 660, 560, maxH)
	local leftW = math.Clamp(cfg.DatapadSidebarWidth or 220, 180, math.max(180, math.min(240, math.floor(fw * 0.28))))

	frame = vgui.Create("DFrame")
	frame:SetSize(fw, fh)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	if frame.SetSizable then frame:SetSizable(true) end
	if frame.SetMinWidth then frame:SetMinWidth(720) end
	if frame.SetMinHeight then frame:SetMinHeight(560) end
	frame:MakePopup()
	frame.Paint = function(self, w, h)
		if MilBase.DrawBlur then MilBase.DrawBlur(self, 3) end

		surface.SetDrawColor(4, 10, 18, 246)
		surface.DrawRect(0, 0, w, h)

		surface.SetDrawColor(65, 175, 240, 220)
		surface.DrawOutlinedRect(0, 0, w, h, 2)

		surface.SetDrawColor(8, 22, 38, 235)
		surface.DrawRect(10, 10, w - 20, 64)
		surface.SetDrawColor(65, 175, 240, 80)
		surface.DrawOutlinedRect(10, 10, w - 20, 64, 1)

		local pulse = math.abs(math.sin(CurTime() * 3))
		surface.SetDrawColor(60, 230, 150, 160 + math.floor(pulse * 95))
		surface.DrawRect(28, 26, 10, 10)

		draw.SimpleText("REPUBLIC TACTICAL DATAPAD", font("MB.Med", "DermaDefaultBold"), 48, 18, Color(225, 240, 255))
		draw.SimpleText(string.upper(tostring(profile.name or LocalPlayer():Nick())) .. "  •  " .. string.upper(tostring(profile.rank or "OPERATIVE")) .. "  •  " .. string.upper(tostring(profile.faction or "REPUBLIC NAVY")), font("MB.Tiny", "DermaDefault"), 48, 44, Color(120, 180, 220))

		draw.SimpleText("COMMS LINK: SECURE  [ENCRYPTED]", font("MB.Tiny", "DermaDefaultBold"), w - 120, 24, Color(90, 205, 145), TEXT_ALIGN_RIGHT)
		draw.SimpleText("SYSTEM READY", font("MB.Tiny", "DermaDefault"), w - 120, 44, Color(160, 190, 215), TEXT_ALIGN_RIGHT)
	end
	frame.OnRemove = clearCCTV
	frame.OnKeyCodePressed = function(self, key) if key == KEY_ESCAPE then self:Close() end end

	local close = btn(frame, "CLOSE", u.dim, function() frame:Close() end); close:SetSize(86, 32)
	appList = vgui.Create("DScrollPanel", frame)
	body = vgui.Create("DPanel", frame); body.Paint = nil
	frame.PerformLayout = function(self, w, h)
		leftW = math.Clamp(cfg.DatapadSidebarWidth or 220, 180, math.max(180, math.min(240, math.floor(w * 0.28))))
		close:SetPos(w - 108, 25)
		appList:SetPos(18, 88); appList:SetSize(leftW, h - 106)
		body:SetPos(leftW + 30, 88); body:SetSize(w - leftW - 48, h - 106)
	end
	frame:InvalidateLayout(true)
	rebuildApps()
	local first = (preferred ~= "" and tabs[preferred] and preferred) or (tabs.home and "home") or (tabs.__order[1] and tabs.__order[1].id)
	if first then selectTab(first) end
end

net.Receive(NET_OPEN, function()
	local preferred = net.ReadString()
	local list = net.ReadTable()
	local prof = net.ReadTable()
	openDatapad(preferred, list, prof)
end)

if MilBase.AddMenuTab then
	MilBase.AddMenuTab("DATAPAD", 95, function(content)
		if contentBuilders and contentBuilders.admin_config then
			contentBuilders.admin_config(content)
		end
	end, function(lp)
		return IsValid(lp) and lp.MBStaffLevel and lp:MBStaffLevel() >= (cfg.DatapadOwnerLevel or cfg.JailCrimeOwnerLevel or 7)
	end)
end
