--[[
	Playable event enemies (server logic + client UI).

	Staff offer players an enemy class; players accept via a popup and respawn
	as that class with N lives. Their real faction/rank/name are untouched
	underneath - when the lives run out (or staff ends the event) they revert
	to their normal unit on the next respawn.

	The spawn pipeline in core (GetPlayerModel / CalcMaxHealth / PlayerLoadout /
	PlayerSpawn / PlayerDeath) checks the helpers below to swap in the class's
	model, health, armor and weapons while the flag is set.
]]

--------------------------------------------------------------------------
-- Shared helpers (read the networked class so both realms agree)
--------------------------------------------------------------------------

-- A dedicated team so event enemies group apart from the factions.
MilBase.EventEnemyTeam = 250
team.SetUp(MilBase.EventEnemyTeam, "Event Enemies", Color(200, 65, 55))

function MilBase.IsEventEnemy(ply)
	return IsValid(ply) and ply:GetNWBool("mb_eventenemy", false)
end

function MilBase.EventEnemyClassOf(ply)
	return MilBase.EventEnemyClasses[ply:GetNWString("mb_enemyclass", "")]
end

-- Model for an event enemy (deterministic per player, like faction models).
function MilBase.EventEnemyModel(ply)
	if not MilBase.IsEventEnemy(ply) then return end
	local override = ply:GetNWString("mb_enemymodeloverride", "")
	if override ~= "" then return override end
	local class = MilBase.EventEnemyClassOf(ply)
	if not class then return end

	local models = class.models or class.model
	if isstring(models) then return models end
	if not istable(models) or #models == 0 then return end

	local idx = (tonumber(util.CRC(ply:SteamID())) % #models) + 1
	return models[idx]
end

function MilBase.EventEnemyHealth(ply)
	if not MilBase.IsEventEnemy(ply) then return end
	local override = ply:GetNWInt("mb_enemyhealthoverride", 0)
	if override > 0 then return override end
	local class = MilBase.EventEnemyClassOf(ply)
	return class and class.health
end

-- Active voice-modulator profile for a speaking enemy, or nil when the
-- feature is off, the class has none, or the player toggled theirs off.
function MilBase.EventEnemyVoiceProfile(ply)
	if not MilBase.Config.EventEnemyVoiceFX then return end
	if not MilBase.IsEventEnemy(ply) then return end
	if ply:GetNWBool("mb_voicefx_off", false) then return end
	local class = MilBase.EventEnemyClassOf(ply)
	return class and (MilBase.EventEnemyVoiceProfiles or {})[class.voice or ""]
end

MilBase.EventEnemyConfigDefaults = MilBase.EventEnemyConfigDefaults
	or table.Copy(MilBase.EventEnemyClasses or {})
MilBase.EventEnemyConfigOrder = MilBase.EventEnemyConfigOrder
	or table.Copy(MilBase.EventEnemyOrder or {})

MilBase.EventEnemySpawns = MilBase.EventEnemySpawns or {}
MilBase.EventEnemySpawnOrder = MilBase.EventEnemySpawnOrder or {}

function MilBase.EventEnemyClassEnabled(id)
	local class = MilBase.EventEnemyClasses[id]
	return class and class.enabled ~= false
end

local function spawnClassSet(spawn)
	local out = {}
	for _, id in ipairs(spawn and spawn.classes or {}) do out[id] = true end
	return out
end

function MilBase.EventEnemySpawnAllowsClass(spawn, classID)
	if not spawn then return false end
	if not spawn.classes or #spawn.classes == 0 then return true end
	return spawnClassSet(spawn)[classID] == true
end

function MilBase.EventEnemySpawnIsActive(spawn, classID)
	if not spawn or spawn.enabled == false then return false end
	if spawn.status and spawn.status ~= "active" then return false end
	if classID and not MilBase.EventEnemySpawnAllowsClass(spawn, classID) then return false end
	return true
end

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_EnemyOffer")
	util.AddNetworkString("MilBase_EnemyAccept")
	util.AddNetworkString("MilBase_EnemyInvite")
	util.AddNetworkString("MilBase_EnemyRecruit")
	util.AddNetworkString("MilBase_EnemySpawnSet")
	util.AddNetworkString("MilBase_EnemyManage")
	util.AddNetworkString("MilBase_EnemyClasses")
	util.AddNetworkString("MilBase_EnemySaveClass")
	util.AddNetworkString("MilBase_EnemyDeleteClass")
	util.AddNetworkString("MilBase_EnemyClassToggle")
	util.AddNetworkString("MilBase_EnemyTestClass")
	util.AddNetworkString("MilBase_EnemySpawns")
	util.AddNetworkString("MilBase_EnemySpawnAction")
	util.AddNetworkString("MilBase_EnemyRespawnChoice")
	util.AddNetworkString("MilBase_EnemyRespawnAt")
	util.AddNetworkString("MilBase_CorpseHackDone")
	util.AddNetworkString("MilBase_EnemyStealArmor")

	local function classLives(class)
		return class.lives or MilBase.Config.EventEnemyLives or 3
	end

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_eventenemy_classes "
		.. "(id VARCHAR(64) PRIMARY KEY, data TEXT)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_eventenemy_class_state "
		.. "(id VARCHAR(64) PRIMARY KEY, data TEXT)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_eventenemy_spawns "
		.. "(map VARCHAR(64), id VARCHAR(64), data TEXT)")

	local CUSTOM_CLASSES = {}
	local CLASS_STATE = {}

	local function cleanID(id, fallback)
		id = string.lower(string.Trim(tostring(id or "")))
		id = string.gsub(id, "%s+", "_")
		id = string.gsub(id, "[^%w_]", "")
		id = string.sub(id, 1, 32)
		if id == "" then id = fallback or ("enemy_" .. math.random(1000, 9999)) end
		return id
	end

	local function cleanStringList(value, maxItems, maxLen)
		local out, seen = {}, {}
		if not istable(value) then value = string.gsub(tostring(value or ""), "[\r\n;]+", ",") end
		local src = istable(value) and value or string.Explode(",", value)
		for _, raw in ipairs(src) do
			local v = string.Trim(tostring(raw or ""))
			v = string.sub(v, 1, maxLen or 96)
			if v ~= "" and not seen[v] then
				out[#out + 1] = v
				seen[v] = true
				if #out >= (maxItems or 12) then break end
			end
		end
		return out
	end

	local function cleanIssueMap(value)
		local out = {}
		if isstring(value) then
			local parsed = {}
			for _, part in ipairs(string.Explode(",", string.gsub(value, "[\r\n;]+", ","))) do
				local id, amount = string.match(part, "^%s*([%w_]+)%s*=%s*(%d+)%s*$")
				if id then parsed[id] = tonumber(amount) end
			end
			value = parsed
		end
		if not istable(value) then return out end
		for rawID, rawAmount in pairs(value) do
			local id = string.lower(string.Trim(tostring(rawID or "")))
			local amount = math.Clamp(math.floor(tonumber(rawAmount) or 0), 0, 99)
			if amount > 0 and MilBase.Items and MilBase.Items[id] then out[id] = amount end
		end
		return out
	end

	local function sanitizeClass(raw, oldID)
		if not istable(raw) then return nil, "Bad class data." end
		local id = cleanID(raw.id or oldID, oldID)
		local models = cleanStringList(raw.models or raw.model, 8, 128)
		local validModels = {}
		for _, model in ipairs(models) do
			if util.IsValidModel(model) then validModels[#validModels + 1] = model end
		end
		if #validModels == 0 then validModels = { "models/player/combine_soldier.mdl" } end

		local weapons = {}
		for _, wep in ipairs(cleanStringList(raw.weapons, 8, 64)) do
			if string.match(wep, "^[%w_]+$") then weapons[#weapons + 1] = wep end
		end

		-- Voice modulator profile (must exist in the config; blank = none).
		local voice = string.lower(string.Trim(tostring(raw.voice or "")))
		if not (MilBase.EventEnemyVoiceProfiles or {})[voice] then voice = "" end

		local certifications = {}
		for _, certID in ipairs(cleanStringList(raw.certifications or raw.certs, 24, 64)) do
			certID = string.lower(certID)
			if MilBase.Certs and MilBase.Certs[certID] then certifications[#certifications + 1] = certID end
		end

		return id, {
			id = id,
			name = string.sub(string.Trim(tostring(raw.name or id)), 1, 48),
			models = validModels,
			health = math.Clamp(math.floor(tonumber(raw.health) or 100), 1, 5000),
			armor = math.Clamp(math.floor(tonumber(raw.armor) or 0), 0, 1000),
			weapons = weapons,
			certifications = certifications,
			gear = cleanIssueMap(raw.gear or raw.issue),
			speed = math.Clamp(math.floor(tonumber(raw.speed) or 220), 80, 500),
			voice = voice,
			noTarget = raw.noTarget ~= false,
			jammer = raw.jammer ~= false,
			stealArmor = raw.stealArmor ~= false,
			lives = math.Clamp(math.floor(tonumber(raw.lives) or classLives(raw)), 1, 50),
			limit = math.Clamp(math.floor(tonumber(raw.limit) or 0), 0, 64),
			enabled = raw.enabled ~= false,
			source = raw.source == "temporary" and "temporary" or "custom",
		}
	end

	local function applyClassState()
		for id, state in pairs(CLASS_STATE) do
			local class = MilBase.EventEnemyClasses[id]
			if class then
				if state.enabled ~= nil then class.enabled = state.enabled == true end
				if state.limit ~= nil then
					class.limit = math.Clamp(math.floor(tonumber(state.limit) or 0), 0, 64)
				end
			end
		end
	end

	local function rebuildEnemyClasses()
		MilBase.EventEnemyClasses = table.Copy(MilBase.EventEnemyConfigDefaults or {})
		MilBase.EventEnemyOrder = table.Copy(MilBase.EventEnemyConfigOrder or {})

		for id, class in pairs(CUSTOM_CLASSES) do
			MilBase.RegisterEventEnemy(id, table.Copy(class))
		end
		applyClassState()
	end

	local function classPayload()
		return util.TableToJSON({
			classes = MilBase.EventEnemyClasses,
			order = MilBase.EventEnemyOrder,
		})
	end

	function MilBase.SyncEventEnemyClasses(target)
		net.Start("MilBase_EnemyClasses")
			net.WriteString(classPayload())
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	local function saveClassState(id)
		local class = MilBase.EventEnemyClasses[id]
		if not class then return end
		CLASS_STATE[id] = {
			enabled = class.enabled ~= false,
			limit = tonumber(class.limit) or 0,
		}
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_eventenemy_class_state (id, data) VALUES (%s, %s)",
			MilBase.SQLStr(id), MilBase.SQLStr(util.TableToJSON(CLASS_STATE[id]))))
	end

	local function saveCustomClass(id)
		local class = CUSTOM_CLASSES[id]
		if not class then return end
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_eventenemy_classes (id, data) VALUES (%s, %s)",
			MilBase.SQLStr(id), MilBase.SQLStr(util.TableToJSON(class))))
	end

	local function activeClassCount(classID)
		local count = 0
		for _, p in ipairs(player.GetAll()) do
			if MilBase.IsEventEnemy(p) and p:GetNWString("mb_enemyclass", "") == classID then
				count = count + 1
			end
		end
		return count
	end

	local function classCanAccept(classID)
		local class = MilBase.EventEnemyClasses[classID]
		if not class or class.enabled == false then return false end
		local limit = tonumber(class.limit) or 0
		return limit <= 0 or activeClassCount(classID) < limit
	end

	local function posToData(pos)
		return { x = pos.x, y = pos.y, z = pos.z }
	end

	local function dataToPos(data)
		if isvector(data) then return data end
		if not istable(data) then return vector_origin end
		return Vector(tonumber(data.x) or 0, tonumber(data.y) or 0, tonumber(data.z) or 0)
	end

	local function addSpawnOrder(id)
		if not table.HasValue(MilBase.EventEnemySpawnOrder, id) then
			MilBase.EventEnemySpawnOrder[#MilBase.EventEnemySpawnOrder + 1] = id
		end
	end

	local function removeSpawnOrder(id)
		for i = #MilBase.EventEnemySpawnOrder, 1, -1 do
			if MilBase.EventEnemySpawnOrder[i] == id then table.remove(MilBase.EventEnemySpawnOrder, i) end
		end
	end

	local function sanitizeSpawn(raw)
		if not istable(raw) then return nil end
		local id = cleanID(raw.id, "spawn_" .. math.random(1000, 9999))
		local pos = dataToPos(raw.pos)
		return {
			id = id,
			name = string.sub(string.Trim(tostring(raw.name or "Enemy Spawn")), 1, 48),
			type = raw.type == "drill" and "drill" or "invisible",
			pos = pos,
			enabled = raw.enabled ~= false,
			status = raw.status or "active",
			radius = math.Clamp(tonumber(raw.radius) or 96, 32, 512),
			maxActive = math.Clamp(math.floor(tonumber(raw.maxActive) or 0), 0, 64),
			classes = cleanStringList(raw.classes or {}, 64, 32),
		}
	end

	local function spawnPayload()
		local spawns = {}
		for id, spawn in pairs(MilBase.EventEnemySpawns) do
			spawns[id] = {
				id = id,
				name = spawn.name,
				type = spawn.type,
				pos = posToData(spawn.pos or vector_origin),
				enabled = spawn.enabled ~= false,
				status = spawn.status or "active",
				radius = spawn.radius or 96,
				maxActive = spawn.maxActive or 0,
				classes = spawn.classes or {},
			}
		end
		return util.TableToJSON({ spawns = spawns, order = MilBase.EventEnemySpawnOrder })
	end

	function MilBase.SyncEventEnemySpawns(target)
		net.Start("MilBase_EnemySpawns")
			net.WriteString(spawnPayload())
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	function MilBase.RegisterEventEnemySpawn(spawn)
		local ent = spawn and spawn.ent
		spawn = sanitizeSpawn(spawn)
		if not spawn then return end
		spawn.ent = ent
		MilBase.EventEnemySpawns[spawn.id] = spawn
		addSpawnOrder(spawn.id)
		MilBase.EventEnemySpawnPos = spawn.pos
		SetGlobalBool("mb_enemyspawnset", #MilBase.EventEnemySpawnOrder > 0)
		MilBase.SyncEventEnemySpawns()
		return spawn
	end

	function MilBase.UpdateEventEnemySpawn(id, patch)
		local spawn = MilBase.EventEnemySpawns[id]
		if not spawn then return end
		for k, v in pairs(patch or {}) do spawn[k] = v end
		if IsValid(spawn.ent) then
			spawn.ent:SetSpawnName(spawn.name or "Drill Pod")
			spawn.ent:SetSpawnEnabled(spawn.enabled ~= false)
			spawn.ent:SetSpawnStatus(spawn.status or "active")
			spawn.ent:SetSpawnRadius(spawn.radius or 96)
			spawn.ent:SetMaxActive(spawn.maxActive or 0)
			spawn.ent.mb_spawnClasses = spawn.classes or {}
		end
		MilBase.RegisterEventEnemySpawn(spawn)
		return spawn
	end

	function MilBase.RemoveEventEnemySpawn(id)
		local spawn = MilBase.EventEnemySpawns[id]
		if not spawn then return end
		if IsValid(spawn.ent) and not spawn.ent.mb_keepAfterUnregister then
			spawn.ent.mb_skipSpawnUnregister = true
			spawn.ent:Remove()
		end
		MilBase.UnregisterEventEnemySpawn(id)
	end

	function MilBase.UnregisterEventEnemySpawn(id)
		if not MilBase.EventEnemySpawns[id] then return end
		MilBase.EventEnemySpawns[id] = nil
		removeSpawnOrder(id)
		SetGlobalBool("mb_enemyspawnset", #MilBase.EventEnemySpawnOrder > 0)
		MilBase.SyncEventEnemySpawns()
	end

	function MilBase.ClearEventEnemySpawns()
		for _, id in ipairs(table.Copy(MilBase.EventEnemySpawnOrder)) do
			MilBase.RemoveEventEnemySpawn(id)
		end
		MilBase.EventEnemySpawnPos = nil
		SetGlobalBool("mb_enemyspawnset", false)
	end

	local function activeSpawnCount(spawnID)
		local count = 0
		for _, p in ipairs(player.GetAll()) do
			if p:Alive() and MilBase.IsEventEnemy(p)
			and p:GetNWString("mb_enemyspawn", "") == spawnID then
				count = count + 1
			end
		end
		return count
	end

	function MilBase.EventEnemySpawnAvailable(spawnID, classID)
		local spawn = MilBase.EventEnemySpawns[spawnID]
		if not MilBase.EventEnemySpawnIsActive(spawn, classID) then return false end
		local limit = tonumber(spawn.maxActive) or 0
		return limit <= 0 or activeSpawnCount(spawnID) < limit
	end

	local function validSpawnIDs(classID)
		local out = {}
		for _, id in ipairs(MilBase.EventEnemySpawnOrder) do
			if MilBase.EventEnemySpawnAvailable(id, classID) then out[#out + 1] = id end
		end
		return out
	end

	local function fallbackSpawnID(classID)
		local ids = validSpawnIDs(classID)
		return ids[1]
	end

	local function playerSpawnIDs(ply, classID)
		local restricted = IsValid(ply) and ply.mb_eventEnemyContext
			and ply.mb_eventEnemyContext.spawnIDs
		if not istable(restricted) then return validSpawnIDs(classID) end
		local result = {}
		for _, id in ipairs(restricted) do
			if MilBase.EventEnemySpawnAvailable(id, classID) then
				result[#result + 1] = id
			end
		end
		return result
	end

	local function safeSpawnPos(spawn)
		local base = spawn and spawn.pos or MilBase.EventEnemySpawnPos
		if not isvector(base) then return end
		local radius = math.max(32, tonumber(spawn and spawn.radius) or 96)
		local tries = { 0, 40, 72, radius, radius * 1.35 }
		local mins, maxs = Vector(-16, -16, 0), Vector(16, 16, 72)

		for _, r in ipairs(tries) do
			local steps = r == 0 and 1 or 12
			for i = 1, steps do
				local ang = math.rad((i / steps) * 360)
				local start = base + Vector(math.cos(ang) * r, math.sin(ang) * r, 72)
				local down = util.TraceHull({
					start = start,
					endpos = start - Vector(0, 0, 180),
					mins = mins,
					maxs = maxs,
					mask = MASK_PLAYERSOLID,
				})
				local pos = down.Hit and (down.HitPos + Vector(0, 0, 4)) or start
				local block = util.TraceHull({
					start = pos,
					endpos = pos + Vector(0, 0, 1),
					mins = mins,
					maxs = maxs,
					mask = MASK_PLAYERSOLID,
				})
				if not block.Hit and util.IsInWorld(pos) then return pos end
			end
		end

		return base + Vector(0, 0, 8)
	end

	function MilBase.GetEventEnemySpawnPos(ply, classID)
		local desired = IsValid(ply) and ply:GetNWString("mb_enemyspawn", "") or ""
		local available = playerSpawnIDs(ply, classID)
		if desired == "" or not table.HasValue(available, desired) then
			desired = available[1] or ""
		end
		local spawn = MilBase.EventEnemySpawns[desired]
		if IsValid(ply) then ply:SetNWString("mb_enemyspawn", spawn and desired or "") end
		return safeSpawnPos(spawn)
	end

	local function traceAimPos(ply)
		if not IsValid(ply) then return end
		local tr = ply:GetEyeTrace()
		if not tr or not tr.Hit then return end
		return tr.HitPos
	end

	function MilBase.CreateInvisibleEventEnemySpawn(ply, pos, opts)
		opts = opts or {}
		pos = isvector(pos) and pos or traceAimPos(ply)
		if not isvector(pos) then return end
		local spawn = MilBase.RegisterEventEnemySpawn({
			id = opts.id or ("spawn_" .. os.time() .. "_" .. math.random(100, 999)),
			name = opts.name or "Enemy Spawn",
			type = "invisible",
			pos = pos,
			enabled = opts.enabled ~= false,
			status = "active",
			radius = opts.radius or 96,
			maxActive = opts.maxActive or 0,
			classes = opts.classes or {},
		})
		if IsValid(ply) and spawn then MilBase.Notify(ply, "Enemy spawn created: " .. spawn.name, "ok") end
		return spawn
	end

	function MilBase.CreateEventEnemyDrillPod(ply, pos, opts)
		opts = opts or {}
		pos = isvector(pos) and pos or traceAimPos(ply)
		if not isvector(pos) then return end

		local pod = ents.Create("mb_enemy_drillpod")
		if not IsValid(pod) then return end

		local height = math.Clamp(tonumber(opts.dropHeight) or 1600, 200, 6000)
		local id = cleanID(opts.id, "pod_" .. os.time() .. "_" .. math.random(100, 999))
		pod:SetPos(pos + Vector(0, 0, height))
		pod:SetAngles(Angle(0, IsValid(ply) and ply:EyeAngles().y or 0, 0))
		if IsValid(ply) then pod:SetCreator(ply) end
		pod:SetSpawnID(id)
		pod:SetSpawnName(string.sub(tostring(opts.name or "Drill Pod"), 1, 48))
		pod:SetTargetPos(pos)
		pod:SetSpawnRadius(math.Clamp(tonumber(opts.radius) or 110, 32, 512))
		pod:SetMaxActive(math.Clamp(math.floor(tonumber(opts.maxActive) or 0), 0, 64))
		pod:SetDropDuration(math.Clamp(tonumber(opts.dropTime) or 3, 0.2, 20))
		pod:SetDrillDuration(math.Clamp(tonumber(opts.drillTime) or 3, 0, 20))
		pod:SetSpawnEnabled(opts.enabled ~= false)
		pod.mb_spawnClasses = opts.classes or {}
		pod.mb_requestedModel = tostring(opts.model
			or MilBase.Config.EventEnemyDrillPodModel or "")
		pod.mb_activateCallback = isfunction(opts.onActive) and opts.onActive or nil
		pod.mb_activationCancelledCallback = isfunction(opts.onCancel)
			and opts.onCancel or nil
		pod.mb_startPos = pod:GetPos()
		pod:Spawn()
		pod:Activate()

		if opts.instant and pod.ActivateSpawn then pod:ActivateSpawn(true) end
		if IsValid(ply) then MilBase.Notify(ply, "Drill pod inbound: " .. pod:GetSpawnName(), "ok") end
		return pod
	end

	function MilBase.SaveEventEnemySpawns(ply)
		local map = game.GetMap()
		MilBase.DB.Run("DELETE FROM frontier_eventenemy_spawns WHERE map = " .. MilBase.SQLStr(map))
		for _, id in ipairs(MilBase.EventEnemySpawnOrder) do
			local spawn = MilBase.EventEnemySpawns[id]
			if spawn then
				local data = {
					id = id,
					name = spawn.name,
					type = spawn.type,
					pos = posToData(spawn.pos or vector_origin),
					enabled = spawn.enabled ~= false,
					status = "active",
					radius = spawn.radius or 96,
					maxActive = spawn.maxActive or 0,
					classes = spawn.classes or {},
				}
				MilBase.DB.Run(string.format(
					"INSERT INTO frontier_eventenemy_spawns (map, id, data) VALUES (%s, %s, %s)",
					MilBase.SQLStr(map), MilBase.SQLStr(id), MilBase.SQLStr(util.TableToJSON(data))))
			end
		end
		if IsValid(ply) then MilBase.Notify(ply, "Enemy spawns saved for this map.", "ok") end
	end

	function MilBase.LoadEventEnemySpawns(ply)
		MilBase.ClearEventEnemySpawns()
		MilBase.DB.Query("SELECT data FROM frontier_eventenemy_spawns WHERE map = "
			.. MilBase.SQLStr(game.GetMap()), function(rows)
			for _, row in ipairs(rows) do
				local spawn = sanitizeSpawn(util.JSONToTable(row.data or ""))
				if not spawn then continue end
				if spawn.type == "drill" then
					MilBase.CreateEventEnemyDrillPod(nil, spawn.pos, {
						id = spawn.id,
						name = spawn.name,
						radius = spawn.radius,
						maxActive = spawn.maxActive,
						classes = spawn.classes,
						enabled = spawn.enabled,
						instant = true,
						dropHeight = 1,
						dropTime = 0.1,
						drillTime = 0,
					})
				else
					MilBase.RegisterEventEnemySpawn(spawn)
				end
			end
			if IsValid(ply) then MilBase.Notify(ply, "Loaded " .. #rows .. " saved enemy spawn(s).", "ok") end
			MilBase.SyncEventEnemySpawns()
		end)
	end

	local function eventEnemyTemporaryWeapons(class)
		local out, seen = {}, {}
		local function add(className)
			className = string.Trim(tostring(className or ""))
			if className ~= "" and not seen[className] then
				out[#out + 1] = className
				seen[className] = true
			end
		end

		for _, className in ipairs(class.weapons or {}) do add(className) end
		for _, certID in ipairs(class.certifications or {}) do
			local cert = MilBase.Certs and MilBase.Certs[certID]
			for _, className in ipairs(cert and cert.loadout or {}) do add(className) end
		end
		return out
	end

	local function eventEnemyTemporaryGear(class)
		local issue = {}
		for id, amount in pairs(class.gear or {}) do
			issue[id] = math.max(issue[id] or 0, math.floor(tonumber(amount) or 0))
		end
		for _, certID in ipairs(class.certifications or {}) do
			local cert = MilBase.Certs and MilBase.Certs[certID]
			for id, amount in pairs(cert and cert.issue or {}) do
				issue[id] = math.max(issue[id] or 0, math.floor(tonumber(amount) or 0))
			end
		end
		return issue
	end

	function MilBase.IssueEventEnemyGear(ply, class)
		if not IsValid(ply) or not class or not MilBase.GiveItem then return end
		local issued = 0
		for id, amount in pairs(eventEnemyTemporaryGear(class)) do
			issued = issued + (MilBase.GiveItem(ply, id, amount) or 0)
		end
		if issued > 0 then MilBase.Notify(ply, "Temporary event gear issued to your datapad inventory.", "ok") end
	end

	local function otherNoTargetMode(ply)
		return ply:GetNWBool("mb_eventmode", false)
			or ply:GetNWBool("mb_staffmode", false)
			or ply:GetNWBool("mb_cloaked", false)
	end

	local function clearEventEnemyNoTarget(ply)
		if not ply.mb_eventEnemyNoTarget then return end
		ply.mb_eventEnemyNoTarget = nil
		if not otherNoTargetMode(ply) then ply:SetNoTarget(false) end
	end

	local function applyEventEnemyNoTarget(ply, class)
		local enabled = class.noTarget
		if enabled == nil then enabled = MilBase.Config.EventEnemyNoTarget ~= false end
		if enabled then
			ply:SetNoTarget(true)
			ply.mb_eventEnemyNoTarget = true
		else
			clearEventEnemyNoTarget(ply)
		end
	end

	local function clearEventEnemyRuntime(ply)
		clearEventEnemyNoTarget(ply)
		if MilBase.SetTemporaryCertifications then MilBase.SetTemporaryCertifications(ply, {}) end
		ply:SetNWString("mb_jam_mode", "")
		ply:SetNWBool("mb_jam_mapwide", false)
		ply:SetNWInt("mb_jam_radius", 0)
		ply:SetNWInt("mb_enemyhealthoverride", 0)
		ply:SetNWString("mb_enemymodeloverride", "")
		ply.mb_eventEnemyWeaponOverride = nil
		ply.mb_eventEnemyContext = nil
		ply.mb_galaxyRaidEventEnemy = nil
	end

	function MilBase.RefreshActiveEventEnemyClass(oldID, newID)
		newID = newID or oldID
		local class = MilBase.EventEnemyClasses[newID]
		if not class then return end
		for _, member in ipairs(player.GetAll()) do
			if not MilBase.IsEventEnemy(member) then continue end
			if member:GetNWString("mb_enemyclass", "") ~= oldID then continue end
			if oldID ~= newID then member:SetNWString("mb_enemyclass", newID) end
			if MilBase.SetTemporaryCertifications then
				MilBase.SetTemporaryCertifications(member, class.certifications or {})
			end
			applyEventEnemyNoTarget(member, class)
			if class.jammer == false then
				member:SetNWString("mb_jam_mode", "")
				member:SetNWBool("mb_jam_mapwide", false)
			end
		end
	end

	-- Give the class weapons (called from PlayerLoadout). Returns true when
	-- it handled the loadout. Temporary certification weapons are folded into
	-- the class loadout without touching the character's persistent loadout.
	function MilBase.EventEnemyLoadout(ply)
		if not MilBase.IsEventEnemy(ply) then return false end
		local class = MilBase.EventEnemyClassOf(ply)
		if not class then return false end

		local weapons = istable(ply.mb_eventEnemyWeaponOverride)
			and #ply.mb_eventEnemyWeaponOverride > 0
			and ply.mb_eventEnemyWeaponOverride
			or eventEnemyTemporaryWeapons(class)
		ply.mb_giveLoadout = true -- bypass the weapon-slot limits
		for _, wep in ipairs(weapons) do ply:Give(wep) end
		ply.mb_giveLoadout = false

		for _, wep in ipairs(ply:GetWeapons()) do
			local ammoType = wep:GetPrimaryAmmoType()
			local clip = wep:GetMaxClip1()
			if ammoType >= 0 and clip > 0 then ply:GiveAmmo(clip * 3, ammoType, true) end
		end

		local sel = weapons[#weapons]
		if sel then ply:SelectWeapon(sel) end
		return true
	end

	-- Armor / speed / spawn position (called from PlayerSpawn).
	function MilBase.ApplyEventEnemyExtras(ply)
		local class = MilBase.EventEnemyClassOf(ply)
		if not class then return end

		ply:SetArmor(class.armor or 0)
		applyEventEnemyNoTarget(ply, class)
		if class.jammer == false then
			ply:SetNWString("mb_jam_mode", "")
			ply:SetNWBool("mb_jam_mapwide", false)
		end
		if class.speed then
			ply:SetWalkSpeed(class.speed)
			ply:SetRunSpeed(class.speed)
		end

		local pos = MilBase.GetEventEnemySpawnPos(ply, ply:GetNWString("mb_enemyclass", ""))
		if isvector(pos) then ply:SetPos(pos) end

		local protect = math.max(0, tonumber(MilBase.Config.EventEnemySpawnProtection or 5) or 5)
		ply:SetNWFloat("mb_enemyprotect", CurTime() + protect)
	end

	function MilBase.MakeEventEnemy(ply, classID, spawnID, context)
		local class = MilBase.EventEnemyClasses[classID]
		if not class or not IsValid(ply) then return false end
		if not classCanAccept(classID) then
			MilBase.Notify(ply, "That enemy class is full or disabled.")
			return false
		end
		context = istable(context) and table.Copy(context) or nil
		if context and context.raidID then
			local maximum = math.max(0, math.floor(tonumber(context.maximum) or 0))
			local activeRaidEnemies = 0
			for _, member in ipairs(player.GetAll()) do
				if MilBase.IsEventEnemy(member)
				and member.mb_galaxyRaidEventEnemy == context.raidID then
					activeRaidEnemies = activeRaidEnemies + 1
				end
			end
			if maximum > 0 and activeRaidEnemies >= maximum then
				MilBase.Notify(ply, "The player-controlled CIS force is already full.")
				return false
			end
		end

		if spawnID == "" or not MilBase.EventEnemySpawnAvailable(spawnID, classID) then
			spawnID = ""
			for _, candidate in ipairs(context and context.spawnIDs or {}) do
				if MilBase.EventEnemySpawnAvailable(candidate, classID) then
					spawnID = candidate
					break
				end
			end
			if spawnID == "" then spawnID = fallbackSpawnID(classID) or "" end
		end
		if #MilBase.EventEnemySpawnOrder > 0 and spawnID == "" then
			MilBase.Notify(ply, "No active enemy spawn is available for that class.")
			return false
		end

		ply:SetNWBool("mb_eventenemy", true)
		ply:SetNWString("mb_enemyclass", classID)
		ply:SetNWString("mb_enemyspawn", spawnID or "")
		ply:SetNWInt("mb_enemylives", math.max(1, math.floor(
			tonumber(context and context.lives) or classLives(class))))
		ply:SetNWBool("mb_voicefx_off", false) -- modulator defaults on
		ply:SetNWInt("mb_enemyhealthoverride", math.max(0,
			math.floor(tonumber(context and context.health) or 0)))
		local model = tostring(context and context.model or "")
		ply:SetNWString("mb_enemymodeloverride",
			model ~= "" and util.IsValidModel(model) and model or "")
		ply.mb_eventEnemyWeaponOverride = istable(context and context.weapons)
			and table.Copy(context.weapons) or nil
		ply.mb_eventEnemyContext = context
		ply.mb_galaxyRaidEventEnemy = context and context.raidID or nil
		ply.mb_enemyOffer = nil
		if MilBase.SetTemporaryCertifications then
			MilBase.SetTemporaryCertifications(ply, class.certifications or {})
		end

		-- Swap in a throwaway inventory so class gear and certification issue
		-- disappear on reversion and never reach the real character's stash.
		if MilBase.EnterEventInventory then MilBase.EnterEventInventory(ply) end
		MilBase.IssueEventEnemyGear(ply, class)

		ply:Spawn()
		MilBase.Notify(ply, "You are now an event enemy: " .. class.name .. ".")
		hook.Run("MilBase.EventEnemyActivated", ply, classID, context)
		return true
	end

	function MilBase.RevertEventEnemy(ply, silent)
		if not MilBase.IsEventEnemy(ply) then return end

		local context = ply.mb_eventEnemyContext
		clearEventEnemyRuntime(ply)
		ply:SetNWBool("mb_eventenemy", false)
		ply:SetNWString("mb_enemyclass", "")
		ply:SetNWString("mb_enemyspawn", "")
		ply:SetNWInt("mb_enemylives", 0)
		ply:SetNWFloat("mb_enemyprotect", 0)
		ply:SetNWBool("mb_voicefx_off", false)

		-- Discard the event scratch inventory and restore their real one.
		if MilBase.ExitEventInventory then MilBase.ExitEventInventory(ply) end

		if ply:Alive() then ply:Spawn() end
		if not silent then MilBase.Notify(ply, "You have returned to your unit.") end
		hook.Run("MilBase.EventEnemyReverted", ply, context)
	end

	function MilBase.EndEventEnemies()
		local n = 0
		for _, p in ipairs(player.GetAll()) do
			if MilBase.IsEventEnemy(p) then MilBase.RevertEventEnemy(p) n = n + 1 end
		end
		return n
	end

	-- On death: lose a life; revert (on next respawn) when out.
	function MilBase.OnEventEnemyDeath(ply)
		if not MilBase.IsEventEnemy(ply) then return end

		-- Remember the class so the corpse's comms can still be tagged after we
		-- clear the event-enemy flag below (out of lives). See CreateEntityRagdoll.
		ply.mb_lastEnemyClass = ply:GetNWString("mb_enemyclass", "")

		local lives = ply:GetNWInt("mb_enemylives", 0) - 1
		ply:SetNWInt("mb_enemylives", math.max(0, lives))
		ply:SetNWString("mb_jam_mode", "")
		ply:SetNWBool("mb_jam_mapwide", false)

		if lives <= 0 then
			-- Clear temporary permissions and NPC no-target before the automatic
			-- respawn returns the player to their normal unit.
			local context = ply.mb_eventEnemyContext
			clearEventEnemyRuntime(ply)
			ply:SetNWBool("mb_eventenemy", false)
			ply:SetNWString("mb_enemyclass", "")
			ply:SetNWString("mb_enemyspawn", "")
			ply:SetNWInt("mb_enemylives", 0)
			ply:SetNWFloat("mb_enemyprotect", 0)
			ply:SetNWBool("mb_voicefx_off", false)
			-- Drop the event scratch inventory; their real one returns on respawn.
			if MilBase.ExitEventInventory then MilBase.ExitEventInventory(ply) end
			MilBase.Notify(ply, "Out of lives - you'll respawn as your normal unit.")
			hook.Run("MilBase.EventEnemyReverted", ply, context)
		else
			MilBase.Notify(ply, "Life lost. " .. lives .. " remaining.")
			timer.Simple(0.3, function()
				if IsValid(ply) and not ply:Alive() and MilBase.SendEventEnemyRespawnChoice then
					MilBase.SendEventEnemyRespawnChoice(ply)
				end
			end)
		end
	end

	hook.Add("EntityTakeDamage", "MilBase.EventEnemySpawnProtection", function(ent)
		if not (IsValid(ent) and ent:IsPlayer() and MilBase.IsEventEnemy(ent)) then return end
		if ent:GetNWFloat("mb_enemyprotect", 0) > CurTime() then return true end
	end)

	hook.Add("KeyPress", "MilBase.EventEnemyProtectCancel", function(ply, key)
		if not MilBase.IsEventEnemy(ply) then return end
		if ply:GetNWFloat("mb_enemyprotect", 0) <= CurTime() then return end
		local active = bit.bor(IN_ATTACK, IN_ATTACK2, IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT)
		if bit.band(key, active) ~= 0 then ply:SetNWFloat("mb_enemyprotect", 0) end
	end)

	function MilBase.SendEventEnemyRespawnChoice(ply)
		local classID = ply:GetNWString("mb_enemyclass", "")
		if classID == "" then return end
		local spawns = playerSpawnIDs(ply, classID)
		if #spawns <= 1 then return end

		net.Start("MilBase_EnemyRespawnChoice")
			net.WriteString(classID)
			net.WriteUInt(math.min(#spawns, 255), 8)
			for i = 1, math.min(#spawns, 255) do net.WriteString(spawns[i]) end
		net.Send(ply)
	end

	-- Offer a player a choice of enemy classes (they pick one in a popup).
	-- `classIDs` is a list of allowed class ids.
	function MilBase.OfferEventEnemy(staff, target, classIDs, opts)
		if not IsValid(target) or MilBase.IsEventEnemy(target) then return false end
		if target:GetNWBool("mb_eventmode", false) then return false end -- skip game masters
		opts = istable(opts) and opts or {}

		local valid = {}
		for _, id in ipairs(classIDs) do
			if classCanAccept(id) then valid[#valid + 1] = id end
		end
		if #valid == 0 then return false end

		local spawns = {}
		for _, id in ipairs(opts.spawnIDs or MilBase.EventEnemySpawnOrder) do
			local spawn = MilBase.EventEnemySpawns[id]
			if MilBase.EventEnemySpawnIsActive(spawn) then spawns[#spawns + 1] = id end
		end
		if istable(opts.spawnIDs) and #spawns == 0 then return false end

		target.mb_enemyOffer = {
			classes = valid,
			spawns = spawns,
			expires = CurTime() + (MilBase.Config.EventEnemyOfferTime or 25),
			context = istable(opts.context) and table.Copy(opts.context) or nil,
		}

		net.Start("MilBase_EnemyOffer")
			net.WriteString(tostring(opts.sourceName
				or IsValid(staff) and staff:MBName() or "Event Staff"))
			net.WriteUInt(math.min(#valid, 255), 8)
			for i = 1, math.min(#valid, 255) do net.WriteString(valid[i]) end
			net.WriteUInt(math.min(#spawns, 255), 8)
			for i = 1, math.min(#spawns, 255) do net.WriteString(spawns[i]) end
		net.Send(target)
		return true
	end

	-- Player accepts, choosing one of the offered classes (locked in after).
	net.Receive("MilBase_EnemyAccept", function(_, ply)
		local offer = ply.mb_enemyOffer
		if not offer or offer.expires < CurTime() then return end
		if MilBase.IsEventEnemy(ply) then return end

		local chosen = net.ReadString()
		local spawnID = net.ReadString()
		if not table.HasValue(offer.classes, chosen) then return end -- must be offered
		if spawnID ~= "" and not table.HasValue(offer.spawns or {}, spawnID) then return end

		ply.mb_enemyOffer = nil
		local context = istable(offer.context) and table.Copy(offer.context) or nil
		local override = context and istable(context.classOverrides)
			and context.classOverrides[chosen] or nil
		if context then context.classOverrides = nil end
		if istable(override) then
			context = context or {}
			table.Merge(context, table.Copy(override))
		end
		MilBase.MakeEventEnemy(ply, chosen, spawnID, context)
	end)

	-- Game master invites a specific player to a single class (context menu).
	net.Receive("MilBase_EnemyInvite", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local target = net.ReadEntity()
		local classID = net.ReadString()
		if IsValid(target) and target:IsPlayer() and MilBase.EventEnemyClasses[classID] then
			if MilBase.OfferEventEnemy(ply, target, { classID }) then
				MilBase.Notify(ply, "Offered " .. target:MBName() .. " the " ..
					MilBase.EventEnemyClasses[classID].name .. " role.")
			end
		end
	end)

	-- Recruit: offer a set of classes to every eligible player at once.
	net.Receive("MilBase_EnemyRecruit", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local n = net.ReadUInt(8)
		local classes = {}
		for i = 1, n do classes[i] = net.ReadString() end
		if #classes == 0 then
			for _, id in ipairs(MilBase.EventEnemyOrder) do
				if MilBase.EventEnemyClassEnabled(id) then classes[#classes + 1] = id end
			end
		end

		local count = 0
		for _, t in ipairs(player.GetAll()) do
			if t ~= ply and MilBase.OfferEventEnemy(ply, t, classes) then count = count + 1 end
		end
		MilBase.ChatMsg(nil, Color(200, 90, 80), "[EVENT] ", color_white,
			ply:MBName() .. " is recruiting event enemies - check your screen.")
		MilBase.Notify(ply, "Offered the role to " .. count .. " players.")
	end)

	-- Set / clear the respawn point (staff manager).
	net.Receive("MilBase_EnemySpawnSet", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local pos = net.ReadVector()
		if isvector(pos) and util.IsInWorld(pos) then
			MilBase.CreateInvisibleEventEnemySpawn(ply, pos, {
				id = "respawn_point",
				name = "Respawn Point",
			})
		end
	end)

	-- Manage active enemies (staff manager): revert one / all, clear spawn.
	net.Receive("MilBase_EnemyManage", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local mode = net.ReadString()

		if mode == "endall" then
			local n = MilBase.EndEventEnemies()
			MilBase.ChatMsg(nil, Color(200, 90, 80), "[EVENT] ", color_white,
				ply:MBName() .. " ended the event - " .. n .. " enemies reverted.")
		elseif mode == "revertone" then
			local target = net.ReadEntity()
			if IsValid(target) then MilBase.RevertEventEnemy(target) end
		elseif mode == "clearspawn" then
			MilBase.ClearEventEnemySpawns()
			MilBase.Notify(ply, "Event-enemy spawns cleared.")
		end
	end)

	hook.Add("PostCleanupMap", "MilBase.EventEnemyClear", function()
		MilBase.EventEnemySpawns = {}
		MilBase.EventEnemySpawnOrder = {}
		MilBase.EventEnemySpawnPos = nil
		SetGlobalBool("mb_enemyspawnset", false)
		timer.Simple(1, function()
			if MilBase.LoadEventEnemySpawns then MilBase.LoadEventEnemySpawns() end
		end)
	end)

	MilBase.DB.Query("SELECT id, data FROM frontier_eventenemy_classes", function(rows)
		for _, row in ipairs(rows) do
			local id, class = sanitizeClass(util.JSONToTable(row.data or ""), row.id)
			if id and class then
				class.source = "custom"
				CUSTOM_CLASSES[id] = class
			end
		end
		rebuildEnemyClasses()
		MilBase.SyncEventEnemyClasses()
	end)

	MilBase.DB.Query("SELECT id, data FROM frontier_eventenemy_class_state", function(rows)
		for _, row in ipairs(rows) do
			local state = util.JSONToTable(row.data or "")
			if istable(state) then CLASS_STATE[row.id] = state end
		end
		applyClassState()
		MilBase.SyncEventEnemyClasses()
	end)

	hook.Add("InitPostEntity", "MilBase.EventEnemyLoadSpawns", function()
		timer.Simple(1, function()
			if MilBase.LoadEventEnemySpawns then MilBase.LoadEventEnemySpawns() end
		end)
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.EventEnemySync", function(ply)
		timer.Simple(2, function()
			if IsValid(ply) then
				MilBase.SyncEventEnemyClasses(ply)
				MilBase.SyncEventEnemySpawns(ply)
			end
		end)
	end)

	net.Receive("MilBase_EnemySaveClass", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local raw = util.JSONToTable(net.ReadString() or "")
		local oldID = net.ReadString()
		local save = net.ReadBool()
		local id, class = sanitizeClass(raw, oldID)
		if not id or not class then return end

		class.source = save and "custom" or "temporary"
		if oldID ~= "" and oldID ~= id and CUSTOM_CLASSES[oldID] then
			CUSTOM_CLASSES[oldID] = nil
			MilBase.DB.Run("DELETE FROM frontier_eventenemy_classes WHERE id = " .. MilBase.SQLStr(oldID))
		end
		if save then
			CUSTOM_CLASSES[id] = class
			saveCustomClass(id)
		else
			CUSTOM_CLASSES[id] = class
			MilBase.DB.Run("DELETE FROM frontier_eventenemy_classes WHERE id = " .. MilBase.SQLStr(id))
		end

		rebuildEnemyClasses()
		MilBase.RefreshActiveEventEnemyClass(oldID ~= "" and oldID or id, id)
		MilBase.SyncEventEnemyClasses()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " saved event enemy class " .. id, ply) end
		MilBase.Notify(ply, "Enemy class saved: " .. class.name, "ok")
	end)

	net.Receive("MilBase_EnemyDeleteClass", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local id = net.ReadString()
		local class = MilBase.EventEnemyClasses[id]
		if not class then return end
		if not CUSTOM_CLASSES[id] then
			MilBase.Notify(ply, "Config classes can be disabled, not deleted.", "warn")
			return
		end
		for _, member in ipairs(player.GetAll()) do
			if MilBase.IsEventEnemy(member) and member:GetNWString("mb_enemyclass", "") == id then
				MilBase.RevertEventEnemy(member)
			end
		end
		CUSTOM_CLASSES[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_eventenemy_classes WHERE id = " .. MilBase.SQLStr(id))
		rebuildEnemyClasses()
		MilBase.SyncEventEnemyClasses()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " deleted event enemy class " .. id, ply) end
		MilBase.Notify(ply, "Enemy class deleted.", "warn")
	end)

	net.Receive("MilBase_EnemyClassToggle", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local id = net.ReadString()
		local enabled = net.ReadBool()
		local limit = net.ReadUInt(8)
		local class = MilBase.EventEnemyClasses[id]
		if not class then return end
		class.enabled = enabled
		class.limit = math.Clamp(limit, 0, 64)
		if CUSTOM_CLASSES[id] then
			CUSTOM_CLASSES[id] = table.Copy(class)
			if class.source == "custom" then saveCustomClass(id) end
		end
		saveClassState(id)
		MilBase.SyncEventEnemyClasses()
	end)

	net.Receive("MilBase_EnemyTestClass", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local id = net.ReadString()
		local spawnID = fallbackSpawnID(id) or ""
		MilBase.MakeEventEnemy(ply, id, spawnID)
	end)

	net.Receive("MilBase_EnemySpawnAction", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		if (ply.mb_nextEnemySpawnAction or 0) > CurTime() then return end
		ply.mb_nextEnemySpawnAction = CurTime() + 0.2

		local action = net.ReadString()
		if action == "create_invisible" then
			local data = util.JSONToTable(net.ReadString() or "") or {}
			MilBase.CreateInvisibleEventEnemySpawn(ply, nil, data)
		elseif action == "create_drill" then
			local data = util.JSONToTable(net.ReadString() or "") or {}
			MilBase.CreateEventEnemyDrillPod(ply, nil, data)
		elseif action == "save" then
			local data = sanitizeSpawn(util.JSONToTable(net.ReadString() or ""))
			if data and MilBase.EventEnemySpawns[data.id] then
				MilBase.UpdateEventEnemySpawn(data.id, data)
				MilBase.Notify(ply, "Enemy spawn updated: " .. data.name, "ok")
			end
		elseif action == "toggle" then
			local id = net.ReadString()
			local spawn = MilBase.EventEnemySpawns[id]
			if spawn then
				spawn.enabled = not spawn.enabled
				MilBase.UpdateEventEnemySpawn(id, spawn)
			end
		elseif action == "delete" then
			MilBase.RemoveEventEnemySpawn(net.ReadString())
			MilBase.Notify(ply, "Enemy spawn deleted.", "warn")
		elseif action == "save_map" then
			MilBase.SaveEventEnemySpawns(ply)
		elseif action == "load_map" then
			MilBase.LoadEventEnemySpawns(ply)
		elseif action == "clear_saved" then
			MilBase.DB.Run("DELETE FROM frontier_eventenemy_spawns WHERE map = "
				.. MilBase.SQLStr(game.GetMap()))
			MilBase.Notify(ply, "Saved enemy spawns cleared for this map.", "warn")
		end
	end)

	net.Receive("MilBase_EnemyRespawnAt", function(_, ply)
		if not MilBase.IsEventEnemy(ply) then return end
		local spawnID = net.ReadString()
		local classID = ply:GetNWString("mb_enemyclass", "")
		if spawnID ~= "" and not table.HasValue(playerSpawnIDs(ply, classID), spawnID) then return end
		ply:SetNWString("mb_enemyspawn", spawnID)
		if not ply:Alive() then
			local wait = (MilBase.Config.RespawnTime or 5) - (CurTime() - ply:GetNWFloat("mb_deathtime", 0))
			timer.Simple(math.max(0, wait), function()
				if IsValid(ply) and not ply:Alive() and MilBase.IsEventEnemy(ply) then ply:Spawn() end
			end)
		end
	end)

	--------------------------------------------------------------------
	-- Trooper armor theft: normal soldier ragdolls expose one temporary
	-- armor salvage charge to eligible event enemies.
	--------------------------------------------------------------------

	local function corpseArmorValue(owner)
		local equipped = 0
		if MilBase.GetInventory then
			local inv = MilBase.GetInventory(owner)
			for _, item in pairs(inv and inv.equip or {}) do
				local def = MilBase.Items and MilBase.Items[item.id]
				if def and def.armor then equipped = equipped + math.max(0, tonumber(def.armor) or 0) end
			end
		end

		local available = math.max(math.max(0, owner:Armor()), equipped)
		local perCorpse = math.max(1, tonumber(MilBase.Config.EventEnemyArmorStealPerCorpse) or 35)
		return math.floor(math.min(available, perCorpse))
	end

	hook.Add("CreateEntityRagdoll", "MilBase.EventEnemyArmorLoot", function(owner, ragdoll)
		if MilBase.Config.EventEnemyArmorStealEnabled == false then return end
		if not (IsValid(owner) and owner:IsPlayer() and IsValid(ragdoll)) then return end
		if MilBase.IsEventEnemy(owner) or (owner.mb_lastEnemyClass and owner.mb_lastEnemyClass ~= "") then return end
		if owner:GetNWBool("mb_eventmode", false) or owner:GetNWBool("mb_staffmode", false) then return end

		local amount = corpseArmorValue(owner)
		if amount <= 0 then return end
		ragdoll.mb_eventArmorLoot = amount
		ragdoll:SetNWBool("mb_eventArmorLootable", true)
		ragdoll:SetNWInt("mb_eventArmorLoot", amount)
		ragdoll:SetNWString("mb_eventArmorOwner", owner:MBName())
	end)

	net.Receive("MilBase_EnemyStealArmor", function(_, ply)
		if MilBase.Config.EventEnemyArmorStealEnabled == false then return end
		if not (IsValid(ply) and ply:Alive() and MilBase.IsEventEnemy(ply)) then return end
		if (ply.mb_nextArmorSteal or 0) > CurTime() then return end
		ply.mb_nextArmorSteal = CurTime() + 0.75

		local ragdoll = net.ReadEntity()
		if not IsValid(ragdoll) or ragdoll.mb_eventArmorLoot == nil then return end
		if not ragdoll:GetNWBool("mb_eventArmorLootable", false) then return end
		if ragdoll:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end

		local class = MilBase.EventEnemyClassOf(ply)
		if not class or class.stealArmor == false then return end
		local cap = math.max(tonumber(class.armor) or 0,
			tonumber(MilBase.Config.EventEnemyArmorStealMax) or 200)
		local gain = math.min(math.max(0, ragdoll.mb_eventArmorLoot or 0),
			math.max(0, cap - ply:Armor()))
		if gain <= 0 then
			MilBase.Notify(ply, "Your armor is already at capacity.")
			return
		end

		ragdoll.mb_eventArmorLoot = nil
		ragdoll:SetNWBool("mb_eventArmorLootable", false)
		ragdoll:SetNWInt("mb_eventArmorLoot", 0)
		ply:SetArmor(math.min(cap, ply:Armor() + gain))
		ply:EmitSound("physics/metal/metal_box_impact_soft2.wav", 65, 95)
		MilBase.Notify(ply, "Stole " .. gain .. " armor from the fallen trooper.", "ok")
	end)

	--------------------------------------------------------------------
	-- Corpse comms: a fallen enemy's transceiver can be sliced by a
	-- Signals-Intel soldier to tap the Hostile Net (see sh_comms.lua).
	--------------------------------------------------------------------

	-- Tag the death ragdoll with the enemy's comm identity so it can be hacked.
	-- The engine makes a server-side prop_ragdoll on death and fires this hook;
	-- SetNWBool lets clients prompt/aim at it.
	hook.Add("CreateEntityRagdoll", "MilBase.EnemyCorpseComms", function(owner, ragdoll)
		if not (IsValid(owner) and owner:IsPlayer() and IsValid(ragdoll)) then return end

		-- Prefer the live class (the ragdoll is usually made before we clear the
		-- flag); fall back to the class cached at death (out-of-lives clears it).
		local classID = MilBase.IsEventEnemy(owner)
			and owner:GetNWString("mb_enemyclass", "")
			or owner.mb_lastEnemyClass
		if not classID or classID == "" then return end

		ragdoll.mb_eeComms = true
		ragdoll.mb_eeClass = classID
		ragdoll:SetNWBool("mb_eeComms", true)
	end)

	-- Don't let a stale cached class tag a normal soldier's later corpse.
	hook.Add("PlayerSpawn", "MilBase.EnemyCorpseReset", function(ply)
		if not MilBase.IsEventEnemy(ply) then
			ply.mb_lastEnemyClass = nil
			if ply:GetNWString("mb_temp_certs", "") ~= "" or ply.mb_eventEnemyNoTarget then
				clearEventEnemyRuntime(ply)
			end
		end
	end)

	-- Client finished the slice minigame: re-validate, then grant Hostile Net access.
	net.Receive("MilBase_CorpseHackDone", function(_, ply)
		local rag = net.ReadEntity()
		if not IsValid(rag) or not rag.mb_eeComms then return end
		if not ply:Alive() or ply:GetNWBool("mb_ee_hacked", false) then return end
		if not (ply:MBHasCert("sigint") or ply:IsAdmin()) then return end
		if rag:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end

		rag:EmitSound("buttons/button14.wav", 65)
		if MilBase.GrantEEComms then MilBase.GrantEEComms(ply) end

		-- Tip off the enemy that their net is compromised.
		local cls = MilBase.EventEnemyClasses[rag.mb_eeClass or ""]
		local who = cls and cls.name or "an enemy"
		for _, p in ipairs(player.GetAll()) do
			if MilBase.IsEventEnemy(p) or p:GetNWBool("mb_eventmode", false) then
				MilBase.Notify(p, "! Hostile Net compromised — " .. ply:MBName()
					.. " sliced " .. who .. "'s transceiver !")
			end
		end
	end)

	--------------------------------------------------------------------
	-- Commands
	--------------------------------------------------------------------

	local function listClasses(ply)
		local names = {}
		for _, id in ipairs(MilBase.EventEnemyOrder) do
			names[#names + 1] = id .. " (" .. MilBase.EventEnemyClasses[id].name .. ")"
		end
		MilBase.Notify(ply, #names > 0 and ("Enemy classes: " .. table.concat(names, ", "))
			or "No event-enemy classes configured.")
	end

	MilBase.RegisterChatCommand("eventenemy", {
		help = "(Event staff) Offer players an enemy role: /eventenemy <class> [player]",
		func = function(ply, args)
			if not MilBase.CanRunEvents(ply) then
				MilBase.Notify(ply, "You don't have event permission.")
				return
			end

			local classID = args[1]
			if not classID or not MilBase.EventEnemyClasses[classID] then
				listClasses(ply)
				return
			end

			if args[2] then
				local target = MilBase.FindPlayer(args[2])
				if not IsValid(target) then
					MilBase.Notify(ply, "Player not found.")
					return
				end
				if MilBase.OfferEventEnemy(ply, target, { classID }) then
					MilBase.Notify(ply, "Offered " .. target:MBName() .. " the role.")
				end
			else
				local n = 0
				for _, t in ipairs(player.GetAll()) do
					if t ~= ply and MilBase.OfferEventEnemy(ply, t, { classID }) then n = n + 1 end
				end
				MilBase.ChatMsg(nil, Color(200, 90, 80), "[EVENT] ", color_white,
					ply:MBName() .. " is recruiting event enemies (" ..
					MilBase.EventEnemyClasses[classID].name .. ") - check your screen.")
				MilBase.Notify(ply, "Offered the role to " .. n .. " players.")
			end
		end,
	})

	MilBase.RegisterChatCommand("voicefx", {
		help = "(Event enemy) Toggle your class's voice modulator on/off.",
		func = function(ply)
			if not MilBase.IsEventEnemy(ply) then
				MilBase.Notify(ply, "Only event enemies have a voice modulator.")
				return
			end
			local class = MilBase.EventEnemyClassOf(ply)
			if not (class and (MilBase.EventEnemyVoiceProfiles or {})[class.voice or ""]) then
				MilBase.Notify(ply, "Your enemy class has no voice modulator.")
				return
			end
			local off = not ply:GetNWBool("mb_voicefx_off", false)
			ply:SetNWBool("mb_voicefx_off", off)
			MilBase.Notify(ply, "Voice modulator " .. (off and "disabled." or "enabled."),
				off and "warn" or "ok")
		end,
	})

	MilBase.RegisterChatCommand("eventenemyend", {
		help = "(Event staff) Revert all event enemies to their units.",
		func = function(ply)
			if not MilBase.CanRunEvents(ply) then
				MilBase.Notify(ply, "You don't have event permission.")
				return
			end
			local n = MilBase.EndEventEnemies()
			MilBase.ChatMsg(nil, Color(200, 90, 80), "[EVENT] ", color_white,
				ply:MBName() .. " ended the event - " .. n .. " enemies reverted.")
		end,
	})

	MilBase.RegisterChatCommand("eventenemyspawn", {
		help = "(Event staff) Set the event-enemy respawn point to your position.",
		func = function(ply)
			if not MilBase.CanRunEvents(ply) then
				MilBase.Notify(ply, "You don't have event permission.")
				return
			end
			MilBase.CreateInvisibleEventEnemySpawn(ply, ply:GetPos(), {
				id = "respawn_point",
				name = "Respawn Point",
			})
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: class-select popup, staff manager, lives HUD
--------------------------------------------------------------------------

local RED = Color(200, 65, 55)

local function styledButton(parent, x, y, w, h, label, col, font, onClick)
	local b = vgui.Create("DButton", parent)
	b:SetPos(x, y) b:SetSize(w, h) b:SetText("")
	b.Paint = function(self, bw, bh)
		surface.SetDrawColor(self:IsHovered() and ColorAlpha(col, 90) or ColorAlpha(col, 45))
		surface.DrawRect(0, 0, bw, bh)
		surface.SetDrawColor(col) surface.DrawOutlinedRect(0, 0, bw, bh)
		draw.SimpleText(label, font or "MB.Small", bw / 2, bh / 2, MilBase.UI.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

local function classLivesC(class)
	return class.lives or (MilBase.Config and MilBase.Config.EventEnemyLives) or 3
end

local function tableToVector(data)
	if isvector(data) then return data end
	if not istable(data) then return vector_origin end
	return Vector(tonumber(data.x) or 0, tonumber(data.y) or 0, tonumber(data.z) or 0)
end

net.Receive("MilBase_EnemyClasses", function()
	local data = util.JSONToTable(net.ReadString() or "") or {}
	MilBase.EventEnemyClasses = data.classes or MilBase.EventEnemyClasses or {}
	MilBase.EventEnemyOrder = data.order or MilBase.EventEnemyOrder or {}
end)

net.Receive("MilBase_EnemySpawns", function()
	local data = util.JSONToTable(net.ReadString() or "") or {}
	MilBase.EventEnemySpawns = data.spawns or {}
	MilBase.EventEnemySpawnOrder = data.order or {}
	for _, spawn in pairs(MilBase.EventEnemySpawns) do
		spawn.pos = tableToVector(spawn.pos)
	end
end)

local function spawnAllowsClassC(spawn, classID)
	if not spawn then return false end
	if not spawn.classes or #spawn.classes == 0 then return true end
	for _, id in ipairs(spawn.classes) do
		if id == classID then return true end
	end
	return false
end

local function activeSpawnIDsForClass(classID, offered)
	local out = {}
	for _, id in ipairs(offered or MilBase.EventEnemySpawnOrder or {}) do
		local spawn = MilBase.EventEnemySpawns and MilBase.EventEnemySpawns[id]
		if spawn and spawn.enabled ~= false
		and (not spawn.status or spawn.status == "active")
		and spawnAllowsClassC(spawn, classID) then
			out[#out + 1] = id
		end
	end
	return out
end

------------------------------------------------------------------
-- Player: choose a class when recruited (locked in on accept)
------------------------------------------------------------------

function MilBase.OpenEnemyOffer(staff, classIDs, spawnIDs)
	local ui = MilBase.UI
	if IsValid(MilBase.EnemyOfferFrame) then MilBase.EnemyOfferFrame:Remove() end
	if #classIDs == 0 then return end
	spawnIDs = spawnIDs or {}

	local rowH = 42
	local spawnH = math.min(116, math.max(0, #spawnIDs * 30))
	local frame = vgui.Create("DFrame")
	MilBase.EnemyOfferFrame = frame
	frame:SetSize(480, 142 + #classIDs * (rowH + 4) + spawnH + 60)
	frame:SetPos(ScrW() / 2 - 240, ScrH() * 0.15)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(false)

	local expire = CurTime() + (MilBase.Config and MilBase.Config.EventEnemyOfferTime or 25)
	local chosen = classIDs[1]
	local chosenSpawn = ""

	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, accent = RED })
		draw.SimpleText("EVENT ENEMY REQUEST", "MB.Tab", 18, 16, Color(220, 90, 80), TEXT_ALIGN_LEFT)
		draw.SimpleText(staff .. " invites you to join the event - pick a class and spawn:", "MB.Small",
			18, 46, ui.dim, TEXT_ALIGN_LEFT)
		local left = math.max(0, math.ceil(expire - CurTime()))
		draw.SimpleText("Auto-declines in " .. left .. "s", "MB.Tiny", w - 18, 20, ui.faint,
			TEXT_ALIGN_RIGHT)
	end

	local y = 68
	for _, id in ipairs(classIDs) do
		local class = MilBase.EventEnemyClasses[id]
		if class then
			local row = vgui.Create("DButton", frame)
			row:SetPos(18, y) row:SetSize(444, rowH) row:SetText("")
			row.Paint = function(self, w, h)
				local sel = chosen == id
				surface.SetDrawColor(sel and ColorAlpha(RED, 70)
					or (self:IsHovered() and ui.hover or Color(0, 0, 0, 120)))
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(sel and RED or Color(255, 255, 255, 25))
				surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(string.upper(class.name), "MB.Med", 12, h / 2, ui.text,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText((class.health or 100) .. " HP  •  " .. classLivesC(class) .. " LIVES",
					"MB.Tiny", w - 12, h / 2, ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function()
				chosen = id
				local available = activeSpawnIDsForClass(chosen, spawnIDs)
				if chosenSpawn ~= "" and not table.HasValue(available, chosenSpawn) then
					chosenSpawn = available[1] or ""
				end
				MilBase.PlayUISound("select")
			end
			y = y + rowH + 4
		end
	end

	if #spawnIDs > 0 then
		y = y + 6
		local lbl = vgui.Create("DLabel", frame)
		lbl:SetPos(18, y) lbl:SetSize(444, 18)
		lbl:SetFont("MB.Tiny")
		lbl:SetText("SPAWN POINT")
		lbl:SetTextColor(ui.dim)
		y = y + 22

		local scroll = vgui.Create("DScrollPanel", frame)
		scroll:SetPos(18, y)
		scroll:SetSize(444, spawnH)
		for _, id in ipairs(spawnIDs) do
			local spawn = MilBase.EventEnemySpawns[id]
			if spawn then
				local b = vgui.Create("DButton", scroll)
				b:Dock(TOP) b:DockMargin(0, 0, 0, 3) b:SetTall(28) b:SetText("")
				b.Paint = function(self, w, h)
					local allowed = spawnAllowsClassC(spawn, chosen)
					local on = chosenSpawn == id
					surface.SetDrawColor(on and ColorAlpha(RED, 65)
						or (self:IsHovered() and ui.hover or Color(0, 0, 0, 120)))
					surface.DrawRect(0, 0, w, h)
					surface.SetDrawColor(on and RED or Color(255, 255, 255, 25))
					surface.DrawOutlinedRect(0, 0, w, h)
					draw.SimpleText(spawn.name or id, "MB.Small", 8, h / 2,
						allowed and ui.text or ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(string.upper(spawn.type or "spawn"), "MB.Tiny", w - 8, h / 2,
						allowed and ui.dim or ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				b.DoClick = function()
					if spawnAllowsClassC(spawn, chosen) then
						chosenSpawn = id
						MilBase.PlayUISound("select")
					end
				end
			end
		end
		chosenSpawn = activeSpawnIDsForClass(chosen, spawnIDs)[1] or ""
		y = y + spawnH + 8
	else
		y = y + 12
	end

	styledButton(frame, 18, y, 214, 40, "ACCEPT", Color(120, 200, 140), "MB.Tab", function()
		net.Start("MilBase_EnemyAccept")
			net.WriteString(chosen)
			net.WriteString(chosenSpawn or "")
		net.SendToServer()
		frame:Remove()
	end)
	styledButton(frame, 248, y, 214, 40, "DECLINE", Color(200, 80, 70), "MB.Tab", function()
		frame:Remove()
	end)

	frame.Think = function() if CurTime() >= expire then frame:Remove() end end
	surface.PlaySound("ambient/alarms/warningbell1.wav")
end

net.Receive("MilBase_EnemyOffer", function()
	local staff = net.ReadString()
	local n = net.ReadUInt(8)
	local classIDs = {}
	for i = 1, n do classIDs[i] = net.ReadString() end
	local sn = net.ReadUInt(8)
	local spawnIDs = {}
	for i = 1, sn do spawnIDs[i] = net.ReadString() end
	MilBase.OpenEnemyOffer(staff, classIDs, spawnIDs)
end)

local function openRespawnChoice(classID, spawnIDs)
	if IsValid(MilBase.EnemyRespawnFrame) then MilBase.EnemyRespawnFrame:Remove() end
	if #spawnIDs == 0 then return end
	local ui = MilBase.UI
	local class = MilBase.EventEnemyClasses[classID]
	local chosen = spawnIDs[1]

	local frame = vgui.Create("DFrame")
	MilBase.EnemyRespawnFrame = frame
	frame:SetSize(380, 128 + math.min(180, #spawnIDs * 32))
	frame:SetPos(ScrW() / 2 - 190, ScrH() * 0.22)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(false)
	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, accent = RED })
		draw.SimpleText("SELECT SPAWN", "MB.Tab", 18, 16, RED, TEXT_ALIGN_LEFT)
		draw.SimpleText(string.upper(class and class.name or "EVENT ENEMY"),
			"MB.Tiny", 20, 44, ui.dim, TEXT_ALIGN_LEFT)
	end

	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:SetPos(18, 66)
	scroll:SetSize(344, math.min(180, #spawnIDs * 32))
	for _, id in ipairs(spawnIDs) do
		local spawn = MilBase.EventEnemySpawns[id]
		if spawn then
			local b = vgui.Create("DButton", scroll)
			b:Dock(TOP) b:DockMargin(0, 0, 0, 4) b:SetTall(28) b:SetText("")
			b.Paint = function(self, w, h)
				local on = chosen == id
				surface.SetDrawColor(on and ColorAlpha(RED, 70)
					or (self:IsHovered() and ui.hover or Color(0, 0, 0, 130)))
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(on and RED or Color(255, 255, 255, 25))
				surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(spawn.name or id, "MB.Small", 8, h / 2, ui.text,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(string.upper(spawn.type or "spawn"), "MB.Tiny", w - 8, h / 2, ui.dim,
					TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			b.DoClick = function() chosen = id MilBase.PlayUISound("select") end
		end
	end

	local y = 76 + math.min(180, #spawnIDs * 32)
	styledButton(frame, 18, y, 344, 36, "DEPLOY", Color(120, 200, 140), "MB.Tab", function()
		net.Start("MilBase_EnemyRespawnAt")
			net.WriteString(chosen or "")
		net.SendToServer()
		frame:Remove()
	end)
end

net.Receive("MilBase_EnemyRespawnChoice", function()
	local classID = net.ReadString()
	local n = net.ReadUInt(8)
	local ids = {}
	for i = 1, n do ids[i] = net.ReadString() end
	openRespawnChoice(classID, ids)
end)

------------------------------------------------------------------
-- Staff: the event-enemy manager (opened from the game master bar)
------------------------------------------------------------------

function MilBase.OpenEnemyManager()
	local ui = MilBase.UI
	if IsValid(MilBase.EnemyManagerFrame) then
		MilBase.EnemyManagerFrame:Remove() -- toggle closed
		return
	end

	MilBase.EventModal = true

	local frame = vgui.Create("DFrame")
	MilBase.EnemyManagerFrame = frame
	frame:SetSize(430, 560)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(false)
	frame.OnRemove = function() MilBase.EventModal = false end
	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, accent = RED })
		draw.SimpleText("EVENT ENEMIES", "MB.Tab", 18, 16, Color(220, 90, 80), TEXT_ALIGN_LEFT)

		draw.SimpleText("RESPAWN POINT", "MB.Tiny", 18, 52, ui.dim, TEXT_ALIGN_LEFT)
		local set = GetGlobalBool("mb_enemyspawnset", false)
		draw.SimpleText(set and "SET" or "NOT SET", "MB.Small", 18, 66,
			set and ui.ok or ui.faint, TEXT_ALIGN_LEFT)

		draw.SimpleText("CLASSES PLAYERS CAN PICK", "MB.Tiny", 18, 138, ui.dim, TEXT_ALIGN_LEFT)
		draw.SimpleText("ACTIVE ENEMIES", "MB.Tiny", 18, 330, ui.dim, TEXT_ALIGN_LEFT)
	end

	styledButton(frame, 430 - 34, 12, 24, 24, "X", Color(200, 80, 70), "MB.Small",
		function() frame:Remove() end)

	-- Spawn point controls: set to the point the camera is aimed at.
	styledButton(frame, 206, 58, 134, 26, "SET AT AIM", ui.accent, "MB.Small", function()
		if not MilBase.EventAimPos then return end
		net.Start("MilBase_EnemySpawnSet")
			net.WriteVector(MilBase.EventAimPos())
		net.SendToServer()
	end)
	styledButton(frame, 346, 58, 66, 26, "CLEAR", Color(160, 90, 80), "MB.Small", function()
		net.Start("MilBase_EnemyManage") net.WriteString("clearspawn") net.SendToServer()
	end)

	-- Class enable toggles (which classes recruits may pick).
	local enabled = {}
	for _, id in ipairs(MilBase.EventEnemyOrder) do
		local class = MilBase.EventEnemyClasses[id]
		enabled[id] = class and class.enabled ~= false
	end

	local classScroll = vgui.Create("DScrollPanel", frame)
	classScroll:SetPos(18, 156) classScroll:SetSize(394, 130)
	for _, id in ipairs(MilBase.EventEnemyOrder) do
		local class = MilBase.EventEnemyClasses[id]
		local btn = vgui.Create("DButton", classScroll)
		btn:Dock(TOP) btn:DockMargin(0, 0, 0, 3) btn:SetTall(26) btn:SetText("")
		btn.Paint = function(_, w, h)
			surface.SetDrawColor(0, 0, 0, 120) surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 25) surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(class.name, "MB.Small", 8, h / 2, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(enabled[id] and "ON" or "OFF", "MB.Small", w - 10, h / 2,
				enabled[id] and ui.ok or ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = function() enabled[id] = not enabled[id] MilBase.PlayUISound("select") end
	end

	-- Recruit.
	styledButton(frame, 18, 294, 394, 30, "RECRUIT PLAYERS", ui.accent, "MB.Tab", function()
		local ids = {}
		for _, id in ipairs(MilBase.EventEnemyOrder) do
			if enabled[id] then ids[#ids + 1] = id end
		end
		net.Start("MilBase_EnemyRecruit")
			net.WriteUInt(math.min(#ids, 255), 8)
			for i = 1, math.min(#ids, 255) do net.WriteString(ids[i]) end
		net.SendToServer()
	end)

	-- Active enemies list (refreshed on a timer).
	local activeScroll = vgui.Create("DScrollPanel", frame)
	activeScroll:SetPos(18, 348) activeScroll:SetSize(394, 158)

	local function refreshActive()
		activeScroll:Clear()
		for _, p in ipairs(player.GetAll()) do
			if not MilBase.IsEventEnemy(p) then continue end
			local class = MilBase.EventEnemyClassOf(p)
			local row = vgui.Create("DPanel", activeScroll)
			row:Dock(TOP) row:DockMargin(0, 0, 0, 3) row:SetTall(30)
			row.Paint = function(_, w, h)
				surface.SetDrawColor(0, 0, 0, 120) surface.DrawRect(0, 0, w, h)
				draw.SimpleText(p:MBName(), "MB.Small", 8, 7, ui.text, TEXT_ALIGN_LEFT)
				draw.SimpleText((class and class.name or "?") .. "  •  "
					.. p:GetNWInt("mb_enemylives", 0) .. " lives", "MB.Tiny", 8, 18, ui.dim, TEXT_ALIGN_LEFT)
			end
			styledButton(row, 316, 4, 74, 22, "RETURN", Color(160, 90, 80), "MB.Tiny", function()
				net.Start("MilBase_EnemyManage")
					net.WriteString("revertone")
					net.WriteEntity(p)
				net.SendToServer()
			end)
		end
	end
	refreshActive()

	local nextRef = CurTime() + 1
	frame.Think = function()
		if CurTime() > nextRef then nextRef = CurTime() + 1 refreshActive() end
	end

	-- End the whole event.
	styledButton(frame, 18, 516, 394, 32, "END EVENT — REVERT ALL", Color(200, 80, 70), "MB.Tab", function()
		net.Start("MilBase_EnemyManage") net.WriteString("endall") net.SendToServer()
	end)
end

--------------------------------------------------------------------------
-- Staff F2 tab: class editor + spawn manager
--------------------------------------------------------------------------

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["EVENT ENEMIES"] = true

local function dockButton(parent, label, accent, onClick)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(self, w, h)
		local ui = MilBase.UI
		local col = accent or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6,
			color = self:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised,
			accent = col,
		})
		if self:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

local function darkInput(parent, value, placeholder)
	local e = vgui.Create("DTextEntry", parent)
	e:SetText(tostring(value or ""))
	e:SetFont("MB.Small")
	e:SetPaintBackground(false)
	if placeholder then e:SetPlaceholderText(placeholder) end
	e.Paint = function(self, w, h)
		local ui = MilBase.UI
		surface.SetDrawColor(0, 0, 0, 155)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end
	return e
end

local function csv(list)
	return table.concat(list or {}, ", ")
end

local function parseCSV(text)
	local out, seen = {}, {}
	text = string.gsub(tostring(text or ""), "[\r\n;]+", ",")
	for part in string.gmatch(text .. ",", "([^,]*),") do
		local v = string.Trim(part)
		if v ~= "" and not seen[v] then
			out[#out + 1] = v
			seen[v] = true
		end
	end
	return out
end

local function issueText(issue)
	local out = {}
	for id, amount in SortedPairs(issue or {}) do
		out[#out + 1] = id .. "=" .. math.max(1, math.floor(tonumber(amount) or 1))
	end
	return table.concat(out, ", ")
end

local function parseIssueText(text)
	local out = {}
	text = string.gsub(tostring(text or ""), "[\r\n;]+", ",")
	for part in string.gmatch(text .. ",", "([^,]*),") do
		local id, amount = string.match(part, "^%s*([%w_]+)%s*=%s*(%d+)%s*$")
		if id then out[string.lower(id)] = tonumber(amount) or 1 end
	end
	return out
end

local function vectorToData(pos)
	pos = isvector(pos) and pos or vector_origin
	return { x = pos.x, y = pos.y, z = pos.z }
end

local function sendClassToggle(id, enabled, limit)
	net.Start("MilBase_EnemyClassToggle")
		net.WriteString(id)
		net.WriteBool(enabled)
		net.WriteUInt(math.Clamp(math.floor(tonumber(limit) or 0), 0, 64), 8)
	net.SendToServer()
end

local function sendSpawnAction(action, value)
	net.Start("MilBase_EnemySpawnAction")
		net.WriteString(action)
		if istable(value) then
			net.WriteString(util.TableToJSON(value))
		elseif isstring(value) then
			net.WriteString(value)
		end
	net.SendToServer()
end

local function classWarnings(def)
	local warn = {}
	if (tonumber(def.health) or 100) > 1000 then warn[#warn + 1] = "HIGH HP" end
	if (tonumber(def.armor) or 0) > 300 then warn[#warn + 1] = "HIGH ARMOR" end
	if (tonumber(def.speed) or 220) > 300 then warn[#warn + 1] = "FAST" end
	if (tonumber(def.lives) or 3) > 8 then warn[#warn + 1] = "MANY LIVES" end
	if (tonumber(def.limit) or 0) == 0 then warn[#warn + 1] = "NO LIMIT" end
	return table.concat(warn, " / ")
end

local PRESETS = {
	raider = {
		id = "raider_variant", name = "Raider Variant",
		models = { "models/player/combine_soldier.mdl" },
		health = 100, armor = 25, weapons = { "weapon_smg1", "weapon_frag" },
		speed = 220, lives = 5, limit = 0, enabled = true,
		certifications = {}, gear = {}, noTarget = true, jammer = true, stealArmor = true,
	},
	heavy = {
		id = "heavy_variant", name = "Heavy Variant",
		models = { "models/player/combine_super_soldier.mdl" },
		health = 250, armor = 100, weapons = { "weapon_ar2" },
		speed = 180, lives = 3, limit = 4, enabled = true,
		certifications = {}, gear = {}, noTarget = true, jammer = true, stealArmor = true,
	},
	boss = {
		id = "boss_variant", name = "Boss Variant",
		models = { "models/player/combine_super_soldier.mdl" },
		health = 1200, armor = 200, weapons = { "weapon_ar2", "weapon_frag" },
		speed = 200, lives = 1, limit = 1, enabled = true,
		certifications = {}, gear = {}, noTarget = true, jammer = true, stealArmor = true,
	},
}

local function openClassEditor(existing, duplicate)
	local ui = MilBase.UI
	local def = table.Copy(existing or PRESETS.raider)
	def.id = duplicate and ((def.id or "enemy") .. "_copy") or (def.id or "")
	def.name = duplicate and ((def.name or "Enemy") .. " Copy") or (def.name or "New Enemy")
	def.models = def.models or def.model or {}
	if isstring(def.models) then def.models = { def.models } end
	def.weapons = def.weapons or {}
	def.certifications = def.certifications or def.certs or {}
	def.gear = def.gear or def.issue or {}
	def.noTarget = def.noTarget ~= false
	def.jammer = def.jammer ~= false
	def.stealArmor = def.stealArmor ~= false
	def.health = def.health or 100
	def.armor = def.armor or 0
	def.speed = def.speed or 220
	def.lives = def.lives or classLivesC(def)
	def.limit = def.limit or 0
	def.voice = def.voice or ""
	def.enabled = def.enabled ~= false

	local oldID = duplicate and "" or (existing and existing.id or "")
	local saved = def.source ~= "temporary"
	local modelEntry

	local frame = vgui.Create("DFrame")
	frame:SetSize(820, 720)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Paint = function(_, w, h)
		MilBase.DrawBlur(frame, 5)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, color = Color(8, 9, 11, 248), accent = RED })
		draw.SimpleText("EVENT ENEMY CLASS", "MB.Tab", 22, 14, ui.text)
		local warning = classWarnings(def)
		if warning ~= "" then draw.SimpleText(warning, "MB.Tiny", 22, 42, ui.warn) end
	end

	local close = dockButton(frame, "X", ui.danger, function() frame:Remove() end)
	close:SetPos(778, 12); close:SetSize(28, 28)

	local modelPanel = vgui.Create("DModelPanel", frame)
	modelPanel:SetPos(22, 70)
	modelPanel:SetSize(220, 410)
	modelPanel:SetModel(def.models[1] or "models/player/combine_soldier.mdl")
	modelPanel:SetFOV(34)
	function modelPanel:LayoutEntity(ent)
		ent:SetAngles(Angle(0, 45, 0))
	end

	local function updateModel()
		local models = parseCSV(modelEntry:GetValue())
		local model = models[1] or "models/player/combine_soldier.mdl"
		if util.IsValidModel(model) then modelPanel:SetModel(model) end
	end

	local form = vgui.Create("DPanel", frame)
	form:SetPos(260, 70)
	form:SetSize(538, 560)
	form.Paint = nil

	local y = 0
	local function label(text)
		local l = vgui.Create("DLabel", form)
		l:SetPos(0, y); l:SetSize(130, 22)
		l:SetFont("MB.Tiny"); l:SetText(text); l:SetTextColor(ui.dim)
	end
	local function field(text, value, placeholder)
		label(text)
		local e = darkInput(form, value, placeholder)
		e:SetPos(140, y); e:SetSize(398, 26)
		y = y + 32
		return e
	end

	local idEntry = field("ID", def.id, "enemy_id")
	local nameEntry = field("NAME", def.name, "Enemy name")
	modelEntry = field("MODELS", csv(def.models), "model path, model path")
	modelEntry.OnLoseFocus = updateModel
	local weaponEntry = field("WEAPONS", csv(def.weapons), "weapon_ar2, weapon_frag")
	local certEntry = field("TEMP CERTS", csv(def.certifications), "engineer, sigint, pilot")
	local gearEntry = field("TEMP GEAR", issueText(def.gear), "armor_trooper=1, medkit=2")
	local hpEntry = field("HEALTH", def.health)
	local armorEntry = field("ARMOR", def.armor)
	local speedEntry = field("SPEED", def.speed)
	local livesEntry = field("LIVES", def.lives)
	local limitEntry = field("ACTIVE LIMIT", def.limit)

	local voiceIDs = {}
	for pid in pairs(MilBase.EventEnemyVoiceProfiles or {}) do voiceIDs[#voiceIDs + 1] = pid end
	table.sort(voiceIDs)
	local voiceEntry = field("VOICE FX", def.voice,
		#voiceIDs > 0 and (table.concat(voiceIDs, ", ") .. " or blank") or "voice profile id")
	voiceEntry:SetSize(318, 26)
	local voiceTest = dockButton(form, "TEST", ui.accent, function()
		local id = string.lower(string.Trim(voiceEntry:GetValue()))
		if id ~= "" then RunConsoleCommand("mb_voicefx_test", id) end
	end)
	voiceTest:SetPos(468, y - 32); voiceTest:SetSize(70, 26)

	local function toggleButton(x, rowY, w, onText, offText, getter, setter, onColor)
		local button = dockButton(form, "", onColor or ui.ok, function() setter(not getter()) end)
		button:SetPos(x, rowY); button:SetSize(w, 30)
		button.Paint = function(self, bw, bh)
			local on = getter()
			local col = on and (onColor or ui.ok) or ui.faint
			MilBase.DrawPanelBF2(0, 0, bw, bh, {
				cut = 6,
				color = self:IsHovered() and ui.hover or ui.raised,
				accent = col,
			})
			draw.SimpleText(on and onText or offText, "MB.Tiny", bw / 2, bh / 2, col,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return button
	end

	toggleButton(140, y, 190, "ENABLED", "DISABLED",
		function() return def.enabled end, function(v) def.enabled = v end, ui.ok)
	toggleButton(338, y, 200, "SAVED", "TEMPORARY",
		function() return saved end, function(v) saved = v end, ui.accent)
	y = y + 36
	toggleButton(140, y, 126, "NPC NOTARGET", "NPC TARGETABLE",
		function() return def.noTarget end, function(v) def.noTarget = v end, ui.ok)
	toggleButton(272, y, 126, "JAMMER", "NO JAMMER",
		function() return def.jammer end, function(v) def.jammer = v end, ui.warn)
	toggleButton(404, y, 134, "ARMOR THEFT", "NO THEFT",
		function() return def.stealArmor end, function(v) def.stealArmor = v end, RED)

	local function collect()
		def.id = idEntry:GetValue()
		def.name = nameEntry:GetValue()
		def.models = parseCSV(modelEntry:GetValue())
		def.weapons = parseCSV(weaponEntry:GetValue())
		def.certifications = parseCSV(certEntry:GetValue())
		def.gear = parseIssueText(gearEntry:GetValue())
		def.health = tonumber(hpEntry:GetValue()) or 100
		def.armor = tonumber(armorEntry:GetValue()) or 0
		def.speed = tonumber(speedEntry:GetValue()) or 220
		def.lives = tonumber(livesEntry:GetValue()) or 3
		def.limit = tonumber(limitEntry:GetValue()) or 0
		def.voice = string.lower(string.Trim(voiceEntry:GetValue()))
		return def
	end

	local save = dockButton(frame, "SAVE", ui.ok, function()
		net.Start("MilBase_EnemySaveClass")
			net.WriteString(util.TableToJSON(collect()))
			net.WriteString(oldID or "")
			net.WriteBool(saved)
		net.SendToServer()
		frame:Remove()
	end)
	save:SetPos(638, 664); save:SetSize(160, 36)

	local test = dockButton(frame, "TEST SELF", ui.accent, function()
		local id = idEntry:GetValue()
		if id == "" then return end
		net.Start("MilBase_EnemyTestClass")
			net.WriteString(id)
		net.SendToServer()
	end)
	test:SetPos(466, 664); test:SetSize(160, 36)

	if existing and existing.source ~= "config" then
		local del = dockButton(frame, "DELETE", ui.danger, function()
			net.Start("MilBase_EnemyDeleteClass")
				net.WriteString(existing.id or "")
			net.SendToServer()
			frame:Remove()
		end)
		del:SetPos(22, 664); del:SetSize(120, 36)
	end
end

local function openSpawnEditor(spawn)
	local ui = MilBase.UI
	local def = table.Copy(spawn)
	def.classes = def.classes or {}
	local selected = {}
	for _, id in ipairs(def.classes) do selected[id] = true end
	local allClasses = #def.classes == 0

	local frame = vgui.Create("DFrame")
	frame:SetSize(520, 580)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Paint = function(_, w, h)
		MilBase.DrawBlur(frame, 5)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, color = Color(8, 9, 11, 248), accent = ui.accent })
		draw.SimpleText("ENEMY SPAWN", "MB.Tab", 22, 14, ui.text)
	end

	local close = dockButton(frame, "X", ui.danger, function() frame:Remove() end)
	close:SetPos(478, 12); close:SetSize(28, 28)

	local name = darkInput(frame, def.name or "", "Spawn name")
	name:SetPos(22, 66); name:SetSize(476, 28)
	local radius = darkInput(frame, tostring(def.radius or 96), "Radius")
	radius:SetPos(22, 104); radius:SetSize(230, 28)
	local limit = darkInput(frame, tostring(def.maxActive or 0), "Max active")
	limit:SetPos(268, 104); limit:SetSize(230, 28)

	local allBtn = dockButton(frame, "", ui.accent, function()
		allClasses = not allClasses
	end)
	allBtn:SetPos(22, 144); allBtn:SetSize(476, 30)
	allBtn.Paint = function(self, w, h)
		local col = allClasses and ui.ok or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6, color = self:IsHovered() and ui.hover or ui.raised, accent = col })
		draw.SimpleText(allClasses and "ALL CLASSES" or "SELECTED CLASSES", "MB.Small",
			w / 2, h / 2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:SetPos(22, 184); scroll:SetSize(476, 318)
	for _, id in ipairs(MilBase.EventEnemyOrder or {}) do
		local class = MilBase.EventEnemyClasses[id]
		if class then
			local row = vgui.Create("DButton", scroll)
			row:Dock(TOP); row:DockMargin(0, 0, 0, 4); row:SetTall(28); row:SetText("")
			row.Paint = function(self, w, h)
				local on = allClasses or selected[id]
				MilBase.DrawPanelBF2(0, 0, w, h, {
					cut = 5,
					color = on and Color(ui.accent.r, ui.accent.g, ui.accent.b, 35)
						or (self:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
					accent = on and ui.accent or nil,
				})
				draw.SimpleText(class.name or id, "MB.Small", 10, h / 2,
					on and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function()
				allClasses = false
				selected[id] = not selected[id]
			end
		end
	end

	local save = dockButton(frame, "SAVE SPAWN", ui.ok, function()
		local classes = {}
		if not allClasses then
			for _, id in ipairs(MilBase.EventEnemyOrder or {}) do
				if selected[id] then classes[#classes + 1] = id end
			end
		end
		sendSpawnAction("save", {
			id = def.id,
			name = name:GetValue(),
			type = def.type,
			pos = vectorToData(def.pos),
			enabled = def.enabled ~= false,
			status = def.status or "active",
			radius = tonumber(radius:GetValue()) or 96,
			maxActive = tonumber(limit:GetValue()) or 0,
			classes = classes,
		})
		frame:Remove()
	end)
	save:SetPos(338, 524); save:SetSize(160, 36)
end

local function spawnActiveCountC(id)
	local n = 0
	for _, p in ipairs(player.GetAll()) do
		if p:Alive() and MilBase.IsEventEnemy(p)
		and p:GetNWString("mb_enemyspawn", "") == id then n = n + 1 end
	end
	return n
end

local function buildEventEnemyTab(content)
	local ui = MilBase.UI

	local top = vgui.Create("DPanel", content)
	top:Dock(TOP); top:SetTall(38); top:DockMargin(0, 0, 0, 8); top.Paint = nil

	local function topBtn(label, w, color, click)
		local b = dockButton(top, label, color, click)
		b:Dock(LEFT); b:SetWide(w); b:DockMargin(0, 0, 8, 0)
	end
	topBtn("+ NEW", 86, ui.ok, function() openClassEditor(PRESETS.raider, true) end)
	topBtn("RAIDER", 86, RED, function() openClassEditor(PRESETS.raider, true) end)
	topBtn("HEAVY", 86, RED, function() openClassEditor(PRESETS.heavy, true) end)
	topBtn("BOSS", 76, RED, function() openClassEditor(PRESETS.boss, true) end)

	local recruit = dockButton(top, "RECRUIT ENABLED", ui.accent, function()
		local ids = {}
		for _, id in ipairs(MilBase.EventEnemyOrder or {}) do
			local class = MilBase.EventEnemyClasses[id]
			if class and class.enabled ~= false then ids[#ids + 1] = id end
		end
		net.Start("MilBase_EnemyRecruit")
			net.WriteUInt(math.min(#ids, 255), 8)
			for i = 1, math.min(#ids, 255) do net.WriteString(ids[i]) end
		net.SendToServer()
	end)
	recruit:Dock(RIGHT); recruit:SetWide(170)

	local body = vgui.Create("DPanel", content)
	body:Dock(FILL); body.Paint = nil

	local classPanel = vgui.Create("DScrollPanel", body)
	classPanel:Dock(LEFT); classPanel:SetWide(390); classPanel:DockMargin(0, 0, 10, 0)

	local spawnPanel = vgui.Create("DScrollPanel", body)
	spawnPanel:Dock(FILL); spawnPanel:DockMargin(0, 0, 10, 0)

	local roster = vgui.Create("DScrollPanel", body)
	roster:Dock(RIGHT); roster:SetWide(300)

	local function header(parent, text)
		local h = vgui.Create("DLabel", parent)
		h:Dock(TOP); h:SetTall(26); h:DockMargin(2, 0, 8, 6)
		h:SetFont("MB.Tab"); h:SetText(text); h:SetTextColor(ui.text)
		return h
	end

	header(classPanel, "CLASSES")
	for _, id in ipairs(MilBase.EventEnemyOrder or {}) do
		local class = MilBase.EventEnemyClasses[id]
		if not class then continue end
		local row = vgui.Create("DPanel", classPanel)
		row:Dock(TOP); row:SetTall(96); row:DockMargin(0, 0, 8, 6)
		row.Paint = function(_, w, h)
			local accent = class.enabled == false and ui.faint or RED
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = accent })
			draw.SimpleText(string.upper(class.name or id), "MB.Med", 12, 8,
				class.enabled == false and ui.faint or ui.text)
			draw.SimpleText(id .. " / " .. string.upper(class.source or "config"), "MB.Tiny", 12, 34, ui.dim)
			local lim = tonumber(class.limit) or 0
			draw.SimpleText((class.health or 100) .. " HP / " .. classLivesC(class)
				.. " lives / limit " .. (lim > 0 and lim or "none"), "MB.Tiny", 12, 53, ui.dim)
			local flags = {
				class.noTarget ~= false and "NOTARGET" or "TARGETABLE",
				class.jammer ~= false and "JAMMER" or "NO JAMMER",
				class.stealArmor ~= false and "ARMOR THEFT" or "NO THEFT",
			}
			if #(class.certifications or {}) > 0 then flags[#flags + 1] = #class.certifications .. " TEMP CERTS" end
			if table.Count(class.gear or {}) > 0 then flags[#flags + 1] = table.Count(class.gear) .. " GEAR ITEMS" end
			draw.SimpleText(table.concat(flags, " / "), "MB.Tiny", 12, 72, ui.faint)
		end
		local edit = dockButton(row, "EDIT", ui.accent, function() openClassEditor(class, false) end)
		edit:SetPos(245, 8); edit:SetSize(54, 26)
		local dup = dockButton(row, "DUP", ui.ok, function() openClassEditor(class, true) end)
		dup:SetPos(305, 8); dup:SetSize(52, 26)
		local tog = dockButton(row, class.enabled == false and "ON" or "OFF",
			class.enabled == false and ui.ok or ui.warn, function()
				sendClassToggle(id, class.enabled == false, tonumber(class.limit) or 0)
			end)
		tog:SetPos(245, 42); tog:SetSize(112, 26)
	end

	header(spawnPanel, "SPAWNS")
	local spawnActions = vgui.Create("DPanel", spawnPanel)
	spawnActions:Dock(TOP); spawnActions:SetTall(72); spawnActions:DockMargin(0, 0, 8, 8); spawnActions.Paint = nil
	local inv = dockButton(spawnActions, "INVISIBLE AT AIM", ui.ok, function()
		sendSpawnAction("create_invisible", { name = "Enemy Spawn", radius = 96, maxActive = 0 })
	end)
	inv:SetPos(0, 0); inv:SetSize(176, 30)
	local pod = dockButton(spawnActions, "DRILL POD AT AIM", RED, function()
		sendSpawnAction("create_drill", { name = "Drill Pod", radius = 110, maxActive = 0 })
	end)
	pod:SetPos(184, 0); pod:SetSize(176, 30)
	local saveMap = dockButton(spawnActions, "SAVE MAP", ui.accent, function() sendSpawnAction("save_map", "") end)
	saveMap:SetPos(0, 38); saveMap:SetSize(112, 30)
	local loadMap = dockButton(spawnActions, "LOAD MAP", ui.accent, function() sendSpawnAction("load_map", "") end)
	loadMap:SetPos(120, 38); loadMap:SetSize(112, 30)
	local clearSaved = dockButton(spawnActions, "CLEAR SAVED", ui.danger, function() sendSpawnAction("clear_saved", "") end)
	clearSaved:SetPos(240, 38); clearSaved:SetSize(120, 30)

	for _, id in ipairs(MilBase.EventEnemySpawnOrder or {}) do
		local spawn = MilBase.EventEnemySpawns[id]
		if not spawn then continue end
		local row = vgui.Create("DPanel", spawnPanel)
		row:Dock(TOP); row:SetTall(72); row:DockMargin(0, 0, 8, 6)
		row.Paint = function(_, w, h)
			local active = spawn.enabled ~= false and (not spawn.status or spawn.status == "active")
			local accent = active and ui.ok or ui.warn
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = accent })
			draw.SimpleText(string.upper(spawn.name or id), "MB.Med", 12, 8, ui.text)
			draw.SimpleText(string.upper(spawn.type or "spawn") .. " / " .. string.upper(spawn.status or "active"),
				"MB.Tiny", 12, 34, active and ui.ok or ui.warn)
			local lim = tonumber(spawn.maxActive) or 0
			draw.SimpleText(spawnActiveCountC(id) .. " active / limit " .. (lim > 0 and lim or "none"),
				"MB.Tiny", 12, 53, ui.dim)
		end
		local edit = dockButton(row, "EDIT", ui.accent, function() openSpawnEditor(spawn) end)
		edit:SetPos(220, 8); edit:SetSize(54, 26)
		local tog = dockButton(row, spawn.enabled == false and "ON" or "OFF",
			spawn.enabled == false and ui.ok or ui.warn, function() sendSpawnAction("toggle", id) end)
		tog:SetPos(280, 8); tog:SetSize(54, 26)
		local del = dockButton(row, "DEL", ui.danger, function() sendSpawnAction("delete", id) end)
		del:SetPos(340, 8); del:SetSize(54, 26)
	end

	header(roster, "ACTIVE")
	for _, p in ipairs(player.GetAll()) do
		if not MilBase.IsEventEnemy(p) then continue end
		local class = MilBase.EventEnemyClassOf(p)
		local spawn = MilBase.EventEnemySpawns[p:GetNWString("mb_enemyspawn", "")]
		local row = vgui.Create("DPanel", roster)
		row:Dock(TOP); row:SetTall(58); row:DockMargin(0, 0, 0, 6)
		row.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = RED })
			draw.SimpleText(p:MBName(), "MB.Small", 10, 8, ui.text)
			draw.SimpleText((class and class.name or "?") .. " / " .. p:GetNWInt("mb_enemylives", 0) .. " lives",
				"MB.Tiny", 10, 28, ui.dim)
			draw.SimpleText(spawn and spawn.name or "No spawn", "MB.Tiny", 10, 43, ui.faint)
		end
		local ret = dockButton(row, "RETURN", ui.danger, function()
			net.Start("MilBase_EnemyManage")
				net.WriteString("revertone")
				net.WriteEntity(p)
			net.SendToServer()
		end)
		ret:SetPos(200, 16); ret:SetSize(88, 28)
	end

	local endAll = dockButton(roster, "END EVENT", ui.danger, function()
		net.Start("MilBase_EnemyManage")
			net.WriteString("endall")
		net.SendToServer()
	end)
	endAll:Dock(TOP); endAll:SetTall(34); endAll:DockMargin(0, 6, 0, 0)
end

MilBase.AddMenuTab("EVENT ENEMIES", 92, buildEventEnemyTab,
	function(lp) return MilBase.CanRunEvents and MilBase.CanRunEvents(lp) end)

-- Lives banner while you're an event enemy.
hook.Add("HUDPaint", "MilBase.EventEnemyHUD", function()
	local lp = LocalPlayer()
	if not MilBase.IsEventEnemy(lp) then return end
	if MilBase.InEventView and MilBase.InEventView() then return end

	local class = MilBase.EventEnemyClassOf(lp)
	local name = class and class.name or "ENEMY"
	local lives = lp:GetNWInt("mb_enemylives", 0)

	local cx, y = ScrW() / 2, 70
	draw.SimpleTextOutlined("EVENT ENEMY  •  " .. string.upper(name), "MB.Small", cx, y,
		Color(225, 95, 85), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	draw.SimpleTextOutlined("LIVES  " .. lives, "MB.Tab", cx, y + 20, MilBase.UI.text,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

	if MilBase.Config.EventEnemyVoiceFX and class
	and (MilBase.EventEnemyVoiceProfiles or {})[class.voice or ""] then
		local off = lp:GetNWBool("mb_voicefx_off", false)
		draw.SimpleTextOutlined("VOICE MODULATOR " .. (off and "OFF" or "ON") .. "  •  /voicefx",
			"MB.Tiny", cx, y + 42, off and MilBase.UI.faint or Color(140, 200, 150),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end
end)

------------------------------------------------------------------
-- Armor theft: event enemies press [E] on an eligible trooper corpse.
------------------------------------------------------------------

local function aimedArmorCorpse(lp)
	local ent = lp:GetEyeTrace().Entity
	if not IsValid(ent) or not ent:GetNWBool("mb_eventArmorLootable", false) then return end
	if ent:GetPos():DistToSqr(lp:GetPos()) > 130 * 130 then return end
	return ent
end

hook.Add("Think", "MilBase.EventEnemyArmorSteal", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() or not MilBase.IsEventEnemy(lp)
	or (MilBase.InEventView and MilBase.InEventView()) then return end

	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible() then
		lp.mb_wasArmorUse = true
		return
	end

	local using = lp:KeyDown(IN_USE)
	if using and not lp.mb_wasArmorUse and (lp.mb_nextArmorSteal or 0) < CurTime() then
		local class = MilBase.EventEnemyClassOf(lp)
		local ragdoll = aimedArmorCorpse(lp)
		if IsValid(ragdoll) and class and class.stealArmor ~= false then
			lp.mb_nextArmorSteal = CurTime() + 0.75
			net.Start("MilBase_EnemyStealArmor")
				net.WriteEntity(ragdoll)
			net.SendToServer()
		end
	end
	lp.mb_wasArmorUse = using
end)

hook.Add("HUDPaint", "MilBase.EventEnemyArmorStealHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() or not MilBase.IsEventEnemy(lp)
	or (MilBase.InEventView and MilBase.InEventView()) then return end
	local class = MilBase.EventEnemyClassOf(lp)
	if not class or class.stealArmor == false then return end

	local ragdoll = aimedArmorCorpse(lp)
	if not IsValid(ragdoll) then return end
	local screen = (ragdoll:GetPos() + Vector(0, 0, 14)):ToScreen()
	if not screen.visible then return end

	local amount = ragdoll:GetNWInt("mb_eventArmorLoot", 0)
	local owner = ragdoll:GetNWString("mb_eventArmorOwner", "fallen trooper")
	draw.SimpleTextOutlined("STRIP ARMOR FROM " .. string.upper(owner) .. "  •  [E]  •  +" .. amount,
		"MB.Small", screen.x, screen.y, Color(225, 145, 75),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end)

------------------------------------------------------------------
-- Corpse comms: hold [E] on a fallen enemy to slice its transceiver
-- (Signals-Intel cert) and tap the Hostile Net until you're killed.
------------------------------------------------------------------

local function hasSigint(lp)
	return lp:MBHasCert("sigint") or lp:IsAdmin()
end

local function aimedEnemyCorpse(lp)
	local ent = lp:GetEyeTrace().Entity
	if not IsValid(ent) or not ent:GetNWBool("mb_eeComms", false) then return end
	if ent:GetPos():DistToSqr(lp:GetPos()) > 130 * 130 then return end
	return ent
end

local function openCorpseHack(rag)
	MilBase.OpenCodeMinigame({
		title = "SLICING TRANSCEIVER",
		subtitle = "Crack the fallen enemy's comms unit to tap the Hostile Net.",
		color = RED,
		lines = MilBase.GenCodeLines(5),
		valid = function()
			local lp = LocalPlayer()
			return IsValid(rag) and IsValid(lp) and lp:Alive()
				and rag:GetNWBool("mb_eeComms", false)
				and not lp:GetNWBool("mb_ee_hacked", false)
				and rag:GetPos():DistToSqr(lp:GetPos()) < 150 * 150
		end,
		onSuccess = function()
			net.Start("MilBase_CorpseHackDone")
				net.WriteEntity(rag)
			net.SendToServer()
		end,
	})
end

hook.Add("Think", "MilBase.CorpseHack", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive()
	or (MilBase.InEventView and MilBase.InEventView()) then return end

	-- Don't fight the popup for the [E] key; re-arm cleanly when it closes.
	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible() then
		lp.mb_wasCorpseUse = true
		return
	end

	local using = lp:KeyDown(IN_USE)
	if using and not lp.mb_wasCorpseUse
	and (lp.mb_nextCorpseHack or 0) < CurTime()
	and not lp:GetNWBool("mb_ee_hacked", false) then
		local rag = aimedEnemyCorpse(lp)
		if IsValid(rag) and hasSigint(lp) then
			lp.mb_nextCorpseHack = CurTime() + 1
			openCorpseHack(rag)
		end
	end
	lp.mb_wasCorpseUse = using
end)

hook.Add("HUDPaint", "MilBase.CorpseHackHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive()
	or (MilBase.InEventView and MilBase.InEventView()) then return end

	local rag = aimedEnemyCorpse(lp)
	if not IsValid(rag) then return end
	local screen = (rag:GetPos() + Vector(0, 0, 12)):ToScreen()
	if not screen.visible then return end

	local text, col
	if lp:GetNWBool("mb_ee_hacked", false) then
		text, col = "HOSTILE NET TAPPED", RED
	elseif hasSigint(lp) then
		text, col = "ENEMY TRANSCEIVER — HOLD [E] TO SLICE COMMS", Color(120, 200, 140)
	else
		text, col = "ENEMY TRANSCEIVER — SIGINT CERT REQUIRED", MilBase.UI.dim
	end
	draw.SimpleTextOutlined(text, "MB.Small", screen.x, screen.y, col,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end)
