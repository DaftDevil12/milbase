--[[
	Third-person camera module.

	Adds a client-side F4 settings tab with a live model preview, plus an
	archived third-person toggle and camera offset controls.
]]

if SERVER then return end

local SETTINGS = {
	{
		label = "CAMERA DISTANCE",
		name = "mb_thirdperson_distance",
		default = 96,
		min = 48,
		max = 180,
		step = 2,
		suffix = "u",
	},
	{
		label = "SHOULDER OFFSET",
		name = "mb_thirdperson_right",
		default = 28,
		min = -60,
		max = 60,
		step = 2,
		suffix = "u",
	},
	{
		label = "CAMERA HEIGHT",
		name = "mb_thirdperson_up",
		default = 10,
		min = -24,
		max = 48,
		step = 2,
		suffix = "u",
	},
	{
		label = "FOV OFFSET",
		name = "mb_thirdperson_fov",
		default = 0,
		min = -20,
		max = 20,
		step = 1,
		suffix = "",
	},
}

local cvEnabled = CreateClientConVar(
	"mb_thirdperson_enabled",
	"0",
	true,
	false,
	"Enable MilBase third-person camera.",
	0,
	1
)

for _, setting in ipairs(SETTINGS) do
	setting.cv = CreateClientConVar(
		setting.name,
		tostring(setting.default),
		true,
		false,
		"MilBase third-person " .. string.lower(setting.label) .. ".",
		setting.min,
		setting.max
	)
end

local function settingValue(setting)
	return math.Clamp(setting.cv:GetFloat(), setting.min, setting.max)
end

local function writeSetting(setting, value)
	value = math.Clamp(tonumber(value) or setting.default, setting.min, setting.max)
	value = math.Round(value / setting.step) * setting.step
	RunConsoleCommand(setting.name, tostring(value))
end

local function valueText(setting)
	local value = settingValue(setting)
	if setting.step >= 1 then value = math.Round(value) end
	return tostring(value) .. (setting.suffix or "")
end

local function localPlayerBlocked(ply)
	if not IsValid(ply) or not ply:Alive() then return true end
	if ply:InVehicle() then return true end
	if ply.GetObserverMode and ply:GetObserverMode() ~= (OBS_MODE_NONE or 0) then return true end
	if MilBase.InEventView and MilBase.InEventView() then return true end

	if SWInfil and (SWInfil.ClientState or SWInfil.SpawnMenuOpen or SWInfil.SkyboxState) then
		return true
	end

	if ply:GetNWBool("SWInfilSkyboxWaiting", false)
	or ply:GetNWBool("SWInfilChoosingSpawn", false) then
		return true
	end

	return false
end

local function thirdPersonActive(ply)
	ply = ply or LocalPlayer()
	return cvEnabled:GetBool() and not localPlayerBlocked(ply)
end

function MilBase.ThirdPersonActive()
	return thirdPersonActive(LocalPlayer())
end

function MilBase.SetThirdPersonEnabled(enabled)
	RunConsoleCommand("mb_thirdperson_enabled", enabled and "1" or "0")
end

function MilBase.ToggleThirdPerson()
	local enabled = not cvEnabled:GetBool()
	MilBase.SetThirdPersonEnabled(enabled)

	if MilBase.Notify then
		MilBase.Notify(enabled and "Third person enabled." or "Third person disabled.",
			enabled and "ok" or "warn")
	end
end

concommand.Add("mb_thirdperson_toggle", function()
	MilBase.ToggleThirdPerson()
end)

local bindCommand = "mb_thirdperson_toggle"

local function normaliseBindKey(value)
	value = string.Trim(string.lower(tostring(value or "")))
	if value == "" or not string.match(value, "^[%w_]+$") then return nil end
	return value
end

local function currentBindKey()
	local key = input.LookupBinding(bindCommand, true)
	return normaliseBindKey(key)
end

local function bindDisplayName()
	local key = currentBindKey()
	return key and string.upper(key) or "UNBOUND"
end

local function setThirdPersonBind(key)
	key = normaliseBindKey(key)
	if not key then return false end

	RunConsoleCommand("bind", key, bindCommand)
	if MilBase.Notify then
		MilBase.Notify("Third-person toggle bound to " .. string.upper(key) .. ".", "ok")
	end
	return true
end

local function clearThirdPersonBind()
	local key = currentBindKey()
	if not key then
		if MilBase.Notify then MilBase.Notify("Third-person toggle is not currently bound.", "warn") end
		return false
	end

	RunConsoleCommand("unbind", key)
	if MilBase.Notify then
		MilBase.Notify("Third-person toggle bind cleared.", "warn")
	end
	return true
end

concommand.Add("mb_thirdperson_bind", function(_, _, args)
	local key = normaliseBindKey(args and args[1])
	if not key then
		if MilBase.Notify then
			MilBase.Notify("Usage: mb_thirdperson_bind <key>   Example: mb_thirdperson_bind v", "warn")
		end
		return
	end

	setThirdPersonBind(key)
end)

concommand.Add("mb_thirdperson_unbind", function()
	clearThirdPersonBind()
end)

local function traceCamera(ply, startPos, desiredPos)
	local filter = { ply }
	local weapon = ply:GetActiveWeapon()
	if IsValid(weapon) then filter[#filter + 1] = weapon end

	local tr = util.TraceHull({
		start = startPos,
		endpos = desiredPos,
		mins = Vector(-4, -4, -4),
		maxs = Vector(4, 4, 4),
		filter = filter,
		mask = MASK_SOLID,
	})

	if tr.Hit then
		return tr.HitPos + tr.HitNormal * 4
	end

	return desiredPos
end

hook.Add("CalcView", "MilBase.ThirdPersonView", function(ply, pos, ang, fov)
	if not thirdPersonActive(ply) then return end

	local distance = settingValue(SETTINGS[1])
	local right = settingValue(SETTINGS[2])
	local up = settingValue(SETTINGS[3])
	local fovOffset = settingValue(SETTINGS[4])

	local eyePos = pos
	local desired = eyePos
		- ang:Forward() * distance
		+ ang:Right() * right
		+ Vector(0, 0, up)

	return {
		origin = traceCamera(ply, eyePos, desired),
		angles = ang,
		fov = math.Clamp((fov or 75) + fovOffset, 45, 110),
		drawviewer = true,
	}
end)

hook.Add("ShouldDrawLocalPlayer", "MilBase.ThirdPersonDrawPlayer", function()
	if thirdPersonActive(LocalPlayer()) then return true end
end)

hook.Add("PreDrawViewModel", "MilBase.ThirdPersonHideViewModel", function()
	if thirdPersonActive(LocalPlayer()) then return true end
end)

local hiddenHudElements = {
	CHudCrosshair = true,
	CHudZoom = true,
}

hook.Add("HUDShouldDraw", "MilBase.ThirdPersonHideHUD", function(name)
	if thirdPersonActive(LocalPlayer()) and hiddenHudElements[name] then return false end
end)

local arccwSightMethods = {
	"DoHolosight",
	"DrawHolosight",
	"FormCheapScope",
	"FormRTScope",
	"DrawHUD",
	"DoDrawCrosshair",
}

local patchedArcCWWeapons = setmetatable({}, { __mode = "k" })

local function isArcCWWeapon(wep)
	if not IsValid(wep) then return false end
	if wep.ArcCW then return true end

	local class = wep:GetClass()
	return isstring(class) and string.StartWith(class, "arccw_")
end

local function wrapArcCWMethod(wep, method)
	local original = wep[method]
	if not isfunction(original) then return end

	local storeName = "MilBase_ThirdPerson_" .. method
	wep[storeName] = wep[storeName] or original

	wep[method] = function(self, ...)
		local owner = self.GetOwner and self:GetOwner()
		if thirdPersonActive(IsValid(owner) and owner or LocalPlayer()) then
			return false
		end

		return self[storeName](self, ...)
	end
end

local function patchArcCWWeapon(wep)
	if not isArcCWWeapon(wep) or patchedArcCWWeapons[wep] then return end

	patchedArcCWWeapons[wep] = true
	for _, method in ipairs(arccwSightMethods) do
		wrapArcCWMethod(wep, method)
	end
end

hook.Add("Think", "MilBase.ThirdPersonArcCWCompat", function()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	patchArcCWWeapon(ply:GetActiveWeapon())
end)

local function panelButton(parent, label, onClick)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.mb_label = label
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6,
			color = self:IsHovered() and ui.hover or ui.raised,
			outlineColor = self:IsHovered() and ui.accent or ui.outline,
		})

		if self:IsHovered() then
			MilBase.DrawBrackets(3, 3, w - 6, h - 6, ui.accent, 8)
		end

		draw.SimpleText(self.mb_label, "MB.Small", w / 2, h / 2,
			ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		if MilBase.PlayUISound then MilBase.PlayUISound("select") end
		onClick()
	end
	return button
end

local function sliderRow(parent, setting)
	local row = vgui.Create("DPanel", parent)
	row:Dock(TOP)
	row:SetTall(58)
	row:DockMargin(0, 0, 8, 8)

	local dragging = false

	local function barBounds(w)
		return 14, 35, math.max(80, w - 130), 6
	end

	local function setFromCursor()
		local x = row:CursorPos()
		local bx, _, bw = barBounds(row:GetWide())
		local frac = math.Clamp((x - bx) / bw, 0, 1)
		writeSetting(setting, setting.min + (setting.max - setting.min) * frac)
	end

	row.Paint = function(self, w, h)
		local ui = MilBase.UI
		local value = settingValue(setting)
		local frac = math.Clamp((value - setting.min) / (setting.max - setting.min), 0, 1)
		local bx, by, bw, bh = barBounds(w)

		MilBase.PaintPanel(w, h)
		draw.SimpleText(setting.label, "MB.Small", 14, 8, ui.text)
		draw.SimpleText(valueText(setting), "MB.Small", w - 14, 8, ui.accent,
			TEXT_ALIGN_RIGHT)

		surface.SetDrawColor(255, 255, 255, 18)
		surface.DrawRect(bx, by, bw, bh)
		surface.SetDrawColor(ui.accent)
		surface.DrawRect(bx, by, math.floor(bw * frac), bh)

		local knobX = bx + math.floor(bw * frac)
		surface.SetDrawColor(ui.text)
		surface.DrawRect(knobX - 2, by - 5, 4, bh + 10)

		draw.SimpleText(tostring(setting.min) .. (setting.suffix or ""), "MB.Tiny",
			bx, h - 13, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(setting.max) .. (setting.suffix or ""), "MB.Tiny",
			bx + bw, h - 13, ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	row.OnMousePressed = function(self, code)
		if code ~= MOUSE_LEFT then return end
		local x, y = self:CursorPos()
		local bx, by, bw, bh = barBounds(self:GetWide())
		if x < bx or x > bx + bw or y < by - 10 or y > by + bh + 10 then return end

		dragging = true
		self:MouseCapture(true)
		setFromCursor()
	end

	row.OnMouseReleased = function(self)
		dragging = false
		self:MouseCapture(false)
	end

	row.Think = function()
		if dragging then setFromCursor() end
	end

	local minus = panelButton(row, "-", function()
		writeSetting(setting, settingValue(setting) - setting.step)
	end)
	local plus = panelButton(row, "+", function()
		writeSetting(setting, settingValue(setting) + setting.step)
	end)

	row.PerformLayout = function(self, w, h)
		plus:SetSize(28, 28)
		plus:SetPos(w - 36, 26)
		minus:SetSize(28, 28)
		minus:SetPos(w - 70, 26)
	end

	return row
end

local function applyPreviewAppearance(panel, ply)
	if not IsValid(panel) or not IsValid(panel.Entity) or not IsValid(ply) then return end

	local ent = panel.Entity
	ent:SetSkin(ply:GetSkin() or 0)
	for i = 0, ply:GetNumBodyGroups() - 1 do
		ent:SetBodygroup(i, ply:GetBodygroup(i))
	end
end

local function updatePreviewCamera(panel)
	if not IsValid(panel) then return end

	local distance = settingValue(SETTINGS[1])
	local right = settingValue(SETTINGS[2])
	local up = settingValue(SETTINGS[3])
	local fovOffset = settingValue(SETTINGS[4])
	local camPos = Vector(-distance, right, 58 + up)

	panel:SetCamPos(camPos)
	panel:SetLookAt(camPos + Vector(distance + 120, 0, 0))
	panel:SetFOV(math.Clamp(54 + fovOffset * 0.35, 42, 66))
end

local function buildPreview(parent)
	local ui = MilBase.UI
	local ply = LocalPlayer()

	local wrap = vgui.Create("DPanel", parent)
	wrap:Dock(LEFT)
	wrap:SetWide(math.min(460, math.max(340, math.floor(parent:GetWide() * 0.42))))
	wrap:DockMargin(0, 0, 14, 0)
	wrap.Paint = function(self, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("CAMERA PREVIEW", "MB.Tab", 16, 10, ui.text)
		MilBase.DrawIcon(ui.art.bf2.accentBar, 16, 41, 150, 3)
		draw.SimpleText(cvEnabled:GetBool() and "ONLINE" or "STANDBY", "MB.Small",
			w - 16, 22, cvEnabled:GetBool() and ui.ok or ui.faint,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local preview = vgui.Create("DModelPanel", wrap)
	preview:SetModel(IsValid(ply) and ply:GetModel() or "models/player/group01/male_02.mdl")
	preview:SetMouseInputEnabled(false)
	preview.Paint = function(self, w, h)
		surface.SetDrawColor(2, 3, 5, 235)
		surface.DrawRect(0, 0, w, h)

		surface.SetDrawColor(255, 198, 60, 18)
		for y = 0, h, 10 do
			surface.DrawRect(0, y, w, 1)
		end

		self:DrawModel()
	end
	preview.PaintOver = function(self, w, h)
		local cx, cy = math.floor(w / 2), math.floor(h / 2)

		surface.SetDrawColor(255, 198, 60, 130)
		surface.DrawLine(cx - 10, cy, cx - 3, cy)
		surface.DrawLine(cx + 3, cy, cx + 10, cy)
		surface.DrawLine(cx, cy - 10, cx, cy - 3)
		surface.DrawLine(cx, cy + 3, cx, cy + 10)

		MilBase.DrawBrackets(0, 0, w, h, MilBase.UI.accent, 10)
	end

	function preview:LayoutEntity(ent)
		ent:SetAngles(Angle(0, 0, 0))
	end

	applyPreviewAppearance(preview, ply)
	updatePreviewCamera(preview)

	wrap.PerformLayout = function(self, w, h)
		preview:SetPos(14, 56)
		preview:SetSize(w - 28, h - 70)
	end

	wrap.Think = function()
		updatePreviewCamera(preview)
	end

	return wrap
end

local function buildThirdPersonTab(content)
	local ui = MilBase.UI

	buildPreview(content)

	local controls = vgui.Create("DScrollPanel", content)
	controls:Dock(FILL)

	local header = vgui.Create("DPanel", controls)
	header:Dock(TOP)
	header:SetTall(58)
	header:DockMargin(0, 0, 8, 8)
	header.Paint = function(self, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("THIRD PERSON SETTINGS", "MB.Tab", 14, 7, ui.text)
		MilBase.DrawIcon(ui.art.bf2.accentBar, 14, 39, 190, 3)
	end

	local toggle = vgui.Create("DButton", controls)
	toggle:Dock(TOP)
	toggle:SetTall(62)
	toggle:DockMargin(0, 0, 8, 8)
	toggle:SetText("")
	toggle.Paint = function(self, w, h)
		local enabled = cvEnabled:GetBool()
		local accent = enabled and ui.ok or ui.accent

		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 8,
			color = self:IsHovered() and Color(accent.r, accent.g, accent.b, 45) or ui.raised,
			outlineColor = Color(accent.r, accent.g, accent.b, enabled and 190 or 90),
			accent = accent,
		})

		if self:IsHovered() then
			MilBase.DrawBrackets(3, 3, w - 6, h - 6, accent, 9)
		end

		draw.SimpleText(enabled and "THIRD PERSON: ON" or "THIRD PERSON: OFF",
			"MB.Med", 16, h / 2 - 8, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("TOGGLE", "MB.Tiny", 16, h / 2 + 13,
			enabled and ui.ok or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	toggle.DoClick = function()
		if MilBase.PlayUISound then MilBase.PlayUISound("select") end
		MilBase.ToggleThirdPerson()
	end

	local bindRow = vgui.Create("DPanel", controls)
	bindRow:Dock(TOP)
	bindRow:SetTall(72)
	bindRow:DockMargin(0, 0, 8, 8)
	bindRow.Paint = function(self, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("TOGGLE KEY", "MB.Small", 14, 10, ui.text)
		draw.SimpleText("Stored in your normal Garry's Mod key bindings.", "MB.Tiny",
			14, 31, ui.dim)
	end

	local capture = panelButton(bindRow, "", function() end)
	local clear = panelButton(bindRow, "CLEAR", function()
		clearThirdPersonBind()
	end)
	local capturing = false

	local function stopCapture()
		capturing = false
		capture:SetKeyboardInputEnabled(false)
	end

	capture.Paint = function(self, w, h)
		local accent = capturing and ui.ok or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6,
			color = self:IsHovered() and ui.hover or ui.raised,
			outlineColor = accent,
		})
		if self:IsHovered() or capturing then
			MilBase.DrawBrackets(3, 3, w - 6, h - 6, accent, 8)
		end

		draw.SimpleText(capturing and "PRESS A KEY..." or bindDisplayName(), "MB.Small",
			w / 2, h / 2, capturing and ui.ok or ui.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	capture.DoClick = function(self)
		if MilBase.PlayUISound then MilBase.PlayUISound("select") end
		capturing = true
		self:SetKeyboardInputEnabled(true)
		self:RequestFocus()
	end
	capture.OnKeyCodePressed = function(self, keyCode)
		if not capturing then return end

		if keyCode == KEY_ESCAPE then
			stopCapture()
			return
		end

		if keyCode == KEY_BACKSPACE or keyCode == KEY_DELETE then
			clearThirdPersonBind()
			stopCapture()
			return
		end

		local keyName = input.GetKeyName(keyCode)
		local normalised = normaliseBindKey(keyName)
		if not normalised then return end

		local existing = input.LookupKeyBinding and input.LookupKeyBinding(keyCode) or nil
		if isstring(existing) and existing ~= "" and existing ~= bindCommand then
			stopCapture()
			Derma_Query(
				string.upper(normalised) .. " is currently bound to: " .. existing .. "\n\nReplace that bind?",
				"REPLACE KEY BIND",
				"REPLACE",
				function() setThirdPersonBind(normalised) end,
				"CANCEL"
			)
			return
		end

		if setThirdPersonBind(normalised) then stopCapture() end
	end
	capture.OnLoseFocus = function()
		if capturing then stopCapture() end
	end

	bindRow.PerformLayout = function(self, w, h)
		clear:SetSize(78, 32)
		clear:SetPos(w - 88, 20)
		capture:SetSize(142, 32)
		capture:SetPos(w - 238, 20)
	end

	for _, setting in ipairs(SETTINGS) do
		sliderRow(controls, setting)
	end

	local reset = panelButton(controls, "RESET CAMERA", function()
		for _, setting in ipairs(SETTINGS) do
			writeSetting(setting, setting.default)
		end
	end)
	reset:Dock(TOP)
	reset:SetTall(38)
	reset:DockMargin(0, 0, 8, 8)
end

MilBase.AddMenuTab("THIRD PERSON", 88, buildThirdPersonTab)
