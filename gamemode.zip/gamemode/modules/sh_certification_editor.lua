--[[
	Persistent certification creator/editor for the F2 staff menu.

	File certifications remain defaults. Editing one stores a database override;
	RESET TO FILE removes the override. New certifications live in the database.
	The optional `factions` set restricts persistent grants and active benefits.
]]

local cfg = MilBase.Config
local EDIT_LEVEL = tonumber(cfg.CertificationEditorLevel) or 4
local NET_REQUEST = "MilBase_CertEditorRequest"
local NET_SYNC = "MilBase_CertEditorSync"
local NET_ACTION = "MilBase_CertEditorAction"
local MAX_RAW = 256 * 1024

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function stringList(source)
	local out, seen = {}, {}
	for _, value in ipairs(istable(source) and source or {}) do
		value = trim(value)
		if value ~= "" and not seen[value] then out[#out + 1], seen[value] = value, true end
	end
	return out
end

local function issueTable(source)
	local out = {}
	for id, amount in pairs(istable(source) and source or {}) do
		id = trim(id)
		amount = math.floor(tonumber(amount) or 0)
		if id ~= "" and amount > 0 then out[id] = amount end
	end
	return out
end

local function factionSet(source)
	local out = {}
	for key, enabled in pairs(istable(source) and source or {}) do
		local id = isnumber(key) and trim(enabled) or trim(key)
		if (isnumber(key) or enabled == true or enabled == 1) and id ~= "" then
			out[string.lower(id)] = true
		end
	end
	return out
end

function MilBase.CertificationToEditable(cert)
	if not istable(cert) then return nil end
	return {
		id = trim(cert.id),
		name = trim(cert.name),
		icon = trim(cert.icon),
		desc = tostring(cert.desc or ""),
		health = math.floor(tonumber(cert.health) or 0),
		loadout = stringList(cert.loadout),
		issue = issueTable(cert.issue),
		attachments = issueTable(cert.attachments),
		armor = string.lower(trim(cert.armor)),
		medic = cert.medic == true,
		medicOthers = cert.medicOthers == true,
		medEfficiency = tonumber(cert.medEfficiency) or 1,
		medSpeed = tonumber(cert.medSpeed) or 1,
		factions = factionSet(cert.factions),
	}
end

MilBase.CertFileDefaults = MilBase.CertFileDefaults or {}
if not MilBase._CertFileDefaultsCaptured then
	for _, id in ipairs(MilBase.CertOrder or {}) do
		local cert = MilBase.Certs[id]
		if cert then
			local copy = table.Copy(cert)
			copy.id = nil
			MilBase.CertFileDefaults[id] = copy
		end
	end
	MilBase._CertFileDefaultsCaptured = true
end

local function cleanText(value, label, minLength, maxLength)
	value = trim(value)
	value = string.gsub(value, "[%z\1-\8\11\12\14-\31]", "")
	if #value < (minLength or 0) then return nil, label .. " is required." end
	if #value > maxLength then return nil, label .. " is too long (max " .. maxLength .. ")." end
	return value
end

local function validateList(source, label, maxItems, maxLength)
	if not istable(source) then return nil, label .. " must be a list." end
	local out = stringList(source)
	if #out > maxItems then return nil, label .. " has too many entries." end
	for _, value in ipairs(out) do
		if #value > maxLength then return nil, label .. " entry is too long." end
	end
	return out
end

local function validateCertification(source, allowUnknownFactions)
	if not istable(source) then return nil, "Malformed certification data." end
	local out, err = {}
	out.id, err = cleanText(source.id, "Certification id", 1, 48)
	if not out.id then return nil, err end
	out.id = string.lower(out.id)
	if not string.match(out.id, "^[%w_%-]+$") then
		return nil, "Certification id may contain only letters, numbers, underscores and hyphens."
	end
	out.name, err = cleanText(source.name, "Name", 1, 80)
	if not out.name then return nil, err end
	out.desc, err = cleanText(source.desc or "", "Description", 0, 1200)
	if not out.desc then return nil, err end
	out.icon, err = cleanText(source.icon or "", "Icon", 0, 192)
	if not out.icon then return nil, err end
	out.health = math.Clamp(math.floor(tonumber(source.health) or 0), 0, 1000)
	out.medEfficiency = math.Clamp(tonumber(source.medEfficiency) or 1, 0.1, 10)
	out.medSpeed = math.Clamp(tonumber(source.medSpeed) or 1, 0.1, 10)
	out.medic = source.medic == true
	out.medicOthers = source.medicOthers == true
	out.loadout, err = validateList(source.loadout or {}, "Loadout", 64, 96)
	if not out.loadout then return nil, err end
	out.issue = issueTable(source.issue)
	if table.Count(out.issue) > 64 then return nil, "Issue list has too many entries." end
	for id, amount in pairs(out.issue) do
		if #id > 96 or amount > 1000 then return nil, "Invalid issue item/count for " .. id .. "." end
	end
	out.attachments = issueTable(source.attachments)
	if table.Count(out.attachments) > 64 then return nil, "Attachment list has too many entries." end
	for id, amount in pairs(out.attachments) do
		if #id > 128 or amount > 1000 then return nil, "Invalid ArcCW attachment/count for " .. id .. "." end
	end
	out.armor = string.lower(trim(source.armor))
	if out.armor == "" then out.armor = nil end
	if out.armor then
		if not string.match(out.armor, "^[%w_%-]+$") then return nil, "Invalid armor id." end
		local armor = MilBase.Items and MilBase.Items[out.armor]
		if not allowUnknownFactions and (not armor or armor.slot ~= "armor") then
			return nil, "Unknown armor profile: " .. out.armor
		end
	end
	out.factions = factionSet(source.factions)
	for id in pairs(out.factions) do
		if not string.match(id, "^[%w_%-]+$") then return nil, "Invalid faction restriction: " .. id end
		if not allowUnknownFactions and not MilBase.GetFaction(id) then
			return nil, "Unknown faction restriction: " .. id
		end
	end
	if table.IsEmpty(out.factions) then out.factions = nil end
	return out
end

MilBase.ValidateCertificationDefinition = validateCertification

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_SYNC)
	util.AddNetworkString(NET_ACTION)

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_certifications (
		id VARCHAR(64) PRIMARY KEY,
		data TEXT,
		source VARCHAR(16),
		updated_by VARCHAR(32),
		updated_at INTEGER
	)]])

	MilBase.CertEditorOverrides = MilBase.CertEditorOverrides or {}

	local function canEdit(ply)
		return IsValid(ply) and (ply:IsSuperAdmin() or ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL)
	end

	local function payload()
		local definitions, meta = {}, {}
		for _, id in ipairs(MilBase.CertOrder or {}) do
			local cert = MilBase.Certs[id]
			if cert then
				definitions[#definitions + 1] = MilBase.CertificationToEditable(cert)
				meta[id] = {
					file = MilBase.CertFileDefaults[id] ~= nil,
					overridden = MilBase.CertEditorOverrides[id] == true,
				}
			end
		end
		return { definitions = definitions, meta = meta }
	end

	local function sendSync(target)
		local raw = util.TableToJSON(payload()) or "{}"
		local compressed = util.Compress(raw)
		if not compressed then return end
		net.Start(NET_SYNC)
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	MilBase.SyncCertificationDefinitions = sendSync

	local function refreshHolders(id)
		for _, ply in ipairs(player.GetAll()) do
			if ply:MBHasPersistentCert(id) then
				local active = MilBase.CertAllowedForFaction(MilBase.Certs[id], ply)
				MilBase.Notify(ply, active and ("Your " .. (MilBase.Certs[id].name or id) .. " certification was updated.")
					or ("Your " .. (MilBase.Certs[id].name or id) .. " certification is inactive in this faction."), active and "ok" or "warn")
				if ply:Alive() and not (MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)) then
					timer.Simple(0, function() if IsValid(ply) then ply:Spawn() end end)
				end
			end
		end
	end

	local function saveCertification(actor, source, options)
		options = options or {}
		local clean, err = validateCertification(source)
		if not clean then return false, err end
		local id = clean.id
		local existing = MilBase.Certs[id]
		local fileBacked = MilBase.CertFileDefaults[id] ~= nil
		if not existing and #MilBase.CertOrder >= 256 then return false, "Certification limit reached." end
		MilBase.RegisterCertification(id, clean)
		MilBase.CertEditorOverrides[id] = true
		local updatedBy = IsValid(actor) and actor:SteamID64() or "console"
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_certifications (id, data, source, updated_by, updated_at) VALUES (%s, %s, %s, %s, %d)",
			MilBase.SQLStr(id), MilBase.SQLStr(util.TableToJSON(clean)),
			MilBase.SQLStr(fileBacked and "override" or "custom"),
			MilBase.SQLStr(updatedBy), os.time()))
		if not options.skipRefresh then refreshHolders(id) end
		if not options.skipSync then sendSync() end
		if not options.skipLog and MilBase.Log then
			MilBase.Log("staff", MilBase.LogTag(actor) .. (existing and " updated certification " or " created certification ") .. id, actor)
		end
		return true, (existing and "Certification updated." or "Certification created."), id
	end
	MilBase.SaveCertificationDefinition = saveCertification
	MilBase.RefreshCertificationHolders = refreshHolders

	local function resetCertification(id, actor)
		local default = MilBase.CertFileDefaults[id]
		if not default then return false, "That certification has no file default." end
		MilBase.RegisterCertification(id, table.Copy(default))
		MilBase.CertEditorOverrides[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_certifications WHERE id = " .. MilBase.SQLStr(id))
		refreshHolders(id)
		sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " reset certification " .. id .. " to file defaults", actor) end
		return true, "Certification reset to its file definition."
	end

	local function deleteCertification(id, actor, done)
		if MilBase.CertFileDefaults[id] then done(false, "File certifications must be reset, not deleted.") return end
		if not MilBase.Certs[id] then done(false, "Unknown certification.") return end
		MilBase.DB.Query("SELECT steamid FROM frontier_certs WHERE cert = " .. MilBase.SQLStr(id) .. " LIMIT 1", function(rows)
			if rows and rows[1] then done(false, "Cannot delete: at least one character still holds this certification.") return end
			MilBase.RemoveCertification(id)
			MilBase.CertEditorOverrides[id] = nil
			MilBase.DB.Run("DELETE FROM frontier_certifications WHERE id = " .. MilBase.SQLStr(id))
			sendSync()
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " deleted certification " .. id, actor) end
			done(true, "Custom certification deleted.")
		end)
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if canEdit(ply) then sendSync(ply) end
	end)

	net.Receive(NET_ACTION, function(_, ply)
		if not canEdit(ply) then return end
		if (ply.mb_nextCertEditorAction or 0) > CurTime() then return end
		ply.mb_nextCertEditorAction = CurTime() + 0.2
		local action = net.ReadString()
		if action == "save" then
			local length = net.ReadUInt(20)
			if length <= 0 or length > MAX_RAW then return end
			local compressed = net.ReadData(length)
			local raw = compressed and util.Decompress(compressed)
			if not raw or #raw > MAX_RAW then return end
			local ok, message = saveCertification(ply, util.JSONToTable(raw))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "reset" then
			local ok, message = resetCertification(string.lower(trim(net.ReadString())), ply)
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "delete" then
			deleteCertification(string.lower(trim(net.ReadString())), ply, function(ok, message)
				if IsValid(ply) then MilBase.Notify(ply, message, ok and "ok" or "warn") end
			end)
		end
	end)

	local function loadOverrides()
		MilBase.DB.Query("SELECT id, data FROM frontier_certifications", function(rows)
			rows = rows or {}
			table.sort(rows, function(a, b) return tostring(a.id or "") < tostring(b.id or "") end)
			for _, row in ipairs(rows) do
				local clean = validateCertification(util.JSONToTable(row.data or ""), true)
				if clean and clean.id == tostring(row.id or "") then
					MilBase.RegisterCertification(clean.id, clean)
					MilBase.CertEditorOverrides[clean.id] = true
				end
			end
			sendSync()
			-- During a live Lua refresh, connected players may have loaded their
			-- certification rows before custom definitions arrived from MySQL.
			for _, ply in ipairs(player.GetAll()) do
				if IsValid(ply) and MilBase.LoadCerts then MilBase.LoadCerts(ply) end
			end
		end)
	end
	loadOverrides()

	hook.Add("PlayerInitialSpawn", "MilBase.CertEditorSync", function(ply)
		timer.Simple(2, function() if IsValid(ply) then sendSync(ply) end end)
	end)

	return
end

-- Client -----------------------------------------------------------------

MilBase.CertEditorMeta = MilBase.CertEditorMeta or {}
local editorPayload = {}

local function decodeSync()
	local length = net.ReadUInt(20)
	local compressed = net.ReadData(length)
	local raw = compressed and util.Decompress(compressed)
	local payload = raw and util.JSONToTable(raw) or {}
	MilBase.Certs = {}
	MilBase.CertOrder = {}
	for _, cert in ipairs(payload.definitions or {}) do MilBase.RegisterCertification(cert.id, cert) end
	MilBase.CertEditorMeta = istable(payload.meta) and payload.meta or {}
	editorPayload = payload
	hook.Run("MilBase.CertEditorUpdated")
end
net.Receive(NET_SYNC, decodeSync)

local function requestSync()
	net.Start(NET_REQUEST)
	net.SendToServer()
end

local function sendAction(action, value)
	net.Start(NET_ACTION)
		net.WriteString(action)
		if action == "save" then
			local compressed = util.Compress(util.TableToJSON(value) or "{}") or ""
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		else
			net.WriteString(tostring(value or ""))
		end
	net.SendToServer()
end

local function splitList(raw)
	local out = {}
	for value in string.gmatch(tostring(raw or ""), "[^,\n]+") do
		value = trim(value)
		if value ~= "" then out[#out + 1] = value end
	end
	return out
end

local function parseIssue(raw)
	local out = {}
	for entry in string.gmatch(tostring(raw or ""), "[^,\n]+") do
		local id, amount = string.match(entry, "^%s*([^=:%s]+)%s*[=:]%s*(%d+)%s*$")
		if id then out[id] = tonumber(amount) or 1 end
	end
	return out
end

local function listText(list)
	return table.concat(list or {}, ", ")
end

local function issueText(issue)
	local entries = {}
	for id, amount in pairs(issue or {}) do entries[#entries + 1] = id .. "=" .. amount end
	table.sort(entries)
	return table.concat(entries, ", ")
end

MilBase.StaffMenuTabs["CERT EDITOR"] = true
MilBase.AddMenuTab("CERT EDITOR", 93, function(content)
	local ui = MilBase.UI
	local selectedID
	local fields = {}
	local factionChecks = {}

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(260)
	left:DockMargin(0, 0, 12, 0)
	left.Paint = function(_, w, h) MilBase.PaintPanel(w, h) end

	local newButton = vgui.Create("DButton", left)
	newButton:Dock(TOP)
	newButton:SetTall(38)
	newButton:SetText("NEW CERTIFICATION")

	local list = vgui.Create("DScrollPanel", left)
	list:Dock(FILL)
	list:DockMargin(8, 8, 8, 8)

	local form = vgui.Create("DScrollPanel", content)
	form:Dock(FILL)

	local function addLabel(text)
		local label = vgui.Create("DLabel", form)
		label:Dock(TOP)
		label:SetTall(20)
		label:SetFont("MB.Tiny")
		label:SetText(text)
		label:SetTextColor(ui.dim)
		label:DockMargin(0, 5, 0, 2)
		return label
	end

	local function addEntry(key, label, multiline)
		addLabel(label)
		local entry = vgui.Create("DTextEntry", form)
		entry:Dock(TOP)
		entry:SetTall(multiline and 72 or 30)
		entry:SetMultiline(multiline == true)
		fields[key] = entry
		return entry
	end

	addEntry("id", "ID (cannot be changed after creation)")
	addEntry("name", "DISPLAY NAME")
	addEntry("icon", "ICON MATERIAL PATH")
	addEntry("desc", "DESCRIPTION", true)
	addEntry("health", "BONUS MAX HEALTH")
	addEntry("medEfficiency", "MEDIC EFFICIENCY (1.0 = normal)")
	addEntry("medSpeed", "MEDIC SPEED MULTIPLIER (0.75 = faster)")
	addEntry("loadout", "WEAPON CLASSES (comma separated)", true)
	addEntry("issue", "ISSUED ITEMS (item=amount, comma separated)", true)
	addEntry("attachments", "ARCCW ATTACHMENTS (attachment=amount, comma separated)", true)

	addLabel("ARMOR OVERRIDE (optional; replaces faction/rank Quartermaster armor)")
	fields.armor = vgui.Create("DComboBox", form)
	fields.armor:Dock(TOP)
	fields.armor:SetTall(30)
	local function rebuildArmorChoices(selected)
		selected = string.lower(trim(selected or (fields.armor.GetOptionData and fields.armor:GetOptionData(fields.armor:GetSelectedID() or 0)) or ""))
		fields.armor:Clear()
		fields.armor:AddChoice("FACTION / RANK DEFAULT", "")
		local rows = {}
		for id, item in pairs(MilBase.Items or {}) do
			if item and item.slot == "armor" then rows[#rows + 1] = { id = id, name = item.name or id } end
		end
		table.sort(rows, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
		local choose = 1
		for _, row in ipairs(rows) do
			local index = fields.armor:AddChoice(row.name .. "  [" .. row.id .. "]", row.id)
			if row.id == selected then choose = index end
		end
		fields.armor:ChooseOptionID(choose)
	end
	rebuildArmorChoices("")

	local toggles = vgui.Create("DPanel", form)
	toggles:Dock(TOP)
	toggles:SetTall(58)
	toggles.Paint = nil
	fields.medic = vgui.Create("DCheckBoxLabel", toggles)
	fields.medic:SetText("Counts as medic")
	fields.medic:SetPos(4, 8)
	fields.medic:SizeToContents()
	fields.medicOthers = vgui.Create("DCheckBoxLabel", toggles)
	fields.medicOthers:SetText("Can treat other players")
	fields.medicOthers:SetPos(4, 32)
	fields.medicOthers:SizeToContents()

	addLabel("ALLOWED FACTIONS (none checked = all factions)")
	local factionPanel = vgui.Create("DIconLayout", form)
	factionPanel:Dock(TOP)
	factionPanel:SetSpaceX(8)
	factionPanel:SetSpaceY(4)
	factionPanel:SetTall(math.ceil(math.max(1, #MilBase.FactionOrder) / 3) * 28)
	for _, id in ipairs(MilBase.FactionOrder or {}) do
		local faction = MilBase.GetFaction(id)
		local check = factionPanel:Add("DCheckBoxLabel")
		check:SetSize(180, 24)
		check:SetText(faction and faction.name or id)
		check:SetTooltip(id)
		factionChecks[id] = check
	end

	local actions = vgui.Create("DPanel", form)
	actions:Dock(TOP)
	actions:SetTall(46)
	actions:DockMargin(0, 10, 0, 0)
	actions.Paint = nil
	local save = vgui.Create("DButton", actions)
	save:SetText("SAVE")
	save:SetSize(120, 36)
	local reset = vgui.Create("DButton", actions)
	reset:SetText("RESET TO FILE")
	reset:SetSize(140, 36)
	local delete = vgui.Create("DButton", actions)
	delete:SetText("DELETE CUSTOM")
	delete:SetSize(140, 36)
	actions.PerformLayout = function()
		save:SetPos(0, 5); reset:SetPos(128, 5); delete:SetPos(276, 5)
	end

	local function loadForm(cert)
		cert = cert or { id = "", name = "", icon = "", desc = "", health = 0,
			medEfficiency = 1, medSpeed = 1, loadout = {}, issue = {}, attachments = {}, armor = "", factions = {} }
		fields.id:SetText(cert.id or "")
		fields.id:SetEditable(selectedID == nil)
		fields.name:SetText(cert.name or "")
		fields.icon:SetText(cert.icon or "")
		fields.desc:SetText(cert.desc or "")
		fields.health:SetText(tostring(cert.health or 0))
		fields.medEfficiency:SetText(tostring(cert.medEfficiency or 1))
		fields.medSpeed:SetText(tostring(cert.medSpeed or 1))
		fields.loadout:SetText(listText(cert.loadout))
		fields.issue:SetText(issueText(cert.issue))
		fields.attachments:SetText(issueText(cert.attachments))
		rebuildArmorChoices(cert.armor or "")
		fields.medic:SetChecked(cert.medic == true)
		fields.medicOthers:SetChecked(cert.medicOthers == true)
		for id, check in pairs(factionChecks) do check:SetChecked(cert.factions and cert.factions[id] == true or false) end
		local meta = selectedID and MilBase.CertEditorMeta[selectedID] or {}
		reset:SetEnabled(meta.file == true and meta.overridden == true)
		delete:SetEnabled(selectedID ~= nil and meta.file ~= true)
	end

	local function selectCert(id)
		selectedID = id
		loadForm(MilBase.CertificationToEditable(MilBase.Certs[id]))
	end

	local function rebuildList()
		list:Clear()
		for _, id in ipairs(MilBase.CertOrder or {}) do
			local cert = MilBase.Certs[id]
			local button = list:Add("DButton")
			button:Dock(TOP)
			button:SetTall(38)
			button:DockMargin(0, 0, 0, 4)
			button:SetText((cert and cert.name or id) .. "  [" .. id .. "]")
			button.DoClick = function() selectCert(id) end
		end
		if selectedID and MilBase.Certs[selectedID] then selectCert(selectedID) else loadForm(nil) end
	end

	newButton.DoClick = function()
		selectedID = nil
		loadForm(nil)
	end

	save.DoClick = function()
		local factions = {}
		for id, check in pairs(factionChecks) do if check:GetChecked() then factions[id] = true end end
		sendAction("save", {
			id = selectedID or fields.id:GetValue(),
			name = fields.name:GetValue(), icon = fields.icon:GetValue(), desc = fields.desc:GetValue(),
			health = tonumber(fields.health:GetValue()) or 0,
			medEfficiency = tonumber(fields.medEfficiency:GetValue()) or 1,
			medSpeed = tonumber(fields.medSpeed:GetValue()) or 1,
			loadout = splitList(fields.loadout:GetValue()), issue = parseIssue(fields.issue:GetValue()),
			attachments = parseIssue(fields.attachments:GetValue()),
			armor = fields.armor:GetOptionData(fields.armor:GetSelectedID() or 0) or "",
			medic = fields.medic:GetChecked(), medicOthers = fields.medicOthers:GetChecked(), factions = factions,
		})
	end
	reset.DoClick = function()
		if selectedID then Derma_Query("Discard the database override and restore the Lua file definition?", "Reset Certification",
			"RESET", function() sendAction("reset", selectedID) end, "CANCEL") end
	end
	delete.DoClick = function()
		if selectedID then Derma_Query("Permanently delete this custom certification?", "Delete Certification",
			"DELETE", function() sendAction("delete", selectedID) selectedID = nil end, "CANCEL") end
	end

	local hookID = "MilBase.CertEditorPanel." .. tostring(content)
	hook.Add("MilBase.CertEditorUpdated", hookID, rebuildList)
	hook.Add("MilBase.ArmorEditorUpdated", hookID, function()
		local selected = selectedID and MilBase.Certs[selectedID]
		rebuildArmorChoices(selected and selected.armor or "")
	end)
	content.OnRemove = function()
		hook.Remove("MilBase.CertEditorUpdated", hookID)
		hook.Remove("MilBase.ArmorEditorUpdated", hookID)
	end
	requestSync()
	rebuildList()
end, function(ply)
	return ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL
end)
