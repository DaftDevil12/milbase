--[[
	Ship systems: ties MilBase engineering to the Star Wars Universe (SWU)
	addon. mb_shipnode consoles are assigned to a system (/engspot shipnode
	<system>, or nearest terminal if unassigned). A system can have several
	consoles for redundancy; an engineer repairs a downed one (hold E -> a
	system-specific minigame). Everything is reversible and guarded, so this
	module is inert without SWU.

	Consequence scales with frac = alive consoles / total consoles per system:
	  STAR MAP   - unusable only once ALL its consoles are down
	  ENGINES    - top speed = 100 * frac  (all down = full stop)
	  MANEUVERING- turn time = base / frac  (all down = can't turn)
	  HYPERDRIVE - jump blocked only when all down; else travel time / frac

	SWU internals used: per-terminal `SWU_Interactable` flag (gated by the
	interaction hooks in sh_swu_interaction.lua), the global SWU.Controller
	networked vars (TargetShipAcceleration / TargetShipAccelerationLimit /
	CanJumpIntoHyperspace) + its server-side TurnSpeedPerDegree, and
	SWU.GlobalConfig.hyperspaceAcceleration for jump duration.
]]

local cfg = MilBase.Config

-- SWU terminal class -> ship-system category.
local CATEGORY = {
	swu_map                 = "starmap",
	swu_speed_controller    = "engines",
	swu_lever_speed         = "engines",
	swu_rotation_controller = "maneuver",
	swu_navigation_computer = "hyperspace",
	swu_lever_hyperspace    = "hyperspace",
}

local SYSTEM_LABEL = {
	starmap    = "STAR MAP",
	engines    = "SUBLIGHT ENGINES",
	maneuver   = "MANEUVERING",
	hyperspace = "HYPERDRIVE",
}

-- Friendly /engspot shipnode <system> aliases -> canonical category.
local ALIAS = {
	starmap = "starmap", map = "starmap", galaxy = "starmap",
	engines = "engines", engine = "engines", sublight = "engines", speed = "engines",
	maneuver = "maneuver", maneuvering = "maneuver", rotation = "maneuver", turn = "maneuver",
	hyperspace = "hyperspace", hyperdrive = "hyperspace", jump = "hyperspace", hyper = "hyperspace",
}

-- A console's ship-system category: an explicit /engspot assignment if one was
-- given (node.mb_assigned), otherwise the nearest SWU terminal. Cached once
-- resolved (SWU recreates terminals each session, so proximity may need a few
-- tries). Also labels the console for the HUD.
local function nodeCategory(node)
	if node.mb_cat then return node.mb_cat end

	if node.mb_assigned then
		node.mb_cat = ALIAS[string.lower(node.mb_assigned)]
	end

	if not node.mb_cat then
		local radius = cfg.ShipNodeBindRadius or 140
		local bestDist
		for class, cat in pairs(CATEGORY) do
			for _, term in ipairs(ents.FindByClass(class)) do
				local d = term:GetPos():DistToSqr(node:GetPos())
				if d <= radius * radius and (not bestDist or d < bestDist) then
					node.mb_cat, bestDist = cat, d
				end
			end
		end
	end

	-- mb_shipnode labels itself for the HUD; mb_shippart has no SystemName var.
	if SERVER and node.mb_cat and node.SetSystemName
	and node:GetSystemName() ~= SYSTEM_LABEL[node.mb_cat] then
		node:SetSystemName(SYSTEM_LABEL[node.mb_cat])
	end
	return node.mb_cat
end

--------------------------------------------------------------------------
-- Server: consequences + repair
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_ShipNodeGame")
	util.AddNetworkString("MilBase_ShipNodeFix")

	-- Best-effort hyperdrive "longer travel": scale SWU's hyperspace speed by a
	-- fraction. Caches the original so it restores exactly; clamped so a jump
	-- always still completes. (Needs in-game verification against your SWU build.)
	local origHyperAccel
	function MilBase.SetHyperspaceSpeed(frac)
		if not istable(SWU) or not istable(SWU.GlobalConfig) then return end
		if not isvector(SWU.GlobalConfig.hyperspaceAcceleration) then return end
		origHyperAccel = origHyperAccel or Vector(SWU.GlobalConfig.hyperspaceAcceleration)
		SWU.GlobalConfig.hyperspaceAcceleration = origHyperAccel * math.Clamp(frac, 0.2, 1)
	end

	-- Re-asserts every consequence from the current console states. Idempotent,
	-- so it's safe to call on break/fix and on a timer (covers SWU respawning
	-- its terminals or the controller resetting after a jump).
	--
	-- Redundancy model: for each system, frac = alive consoles / total consoles.
	-- All destroyed -> hard offline; some destroyed -> degraded (less top speed,
	-- slower turning, longer hyperspace travel).
	function MilBase.RefreshShipSystems()
		if cfg.ShipSystemsEnabled == false or not istable(SWU) then return end

		-- Count consoles (mb_shipnode) AND physical parts (mb_shippart) per
		-- category; both feed the same alive/total fraction.
		local total, alive = {}, {}
		local function tally(class, isDown)
			for _, ent in ipairs(ents.FindByClass(class)) do
				local cat = nodeCategory(ent)
				if cat then
					total[cat] = (total[cat] or 0) + 1
					if not isDown(ent) then alive[cat] = (alive[cat] or 0) + 1 end
				end
			end
		end
		tally("mb_shipnode", function(e) return e:GetBroken() end)
		tally("mb_shippart", function(e) return e:GetDestroyed() end)

		-- A hacked security console softly forces engines + hyperdrive fully off.
		local hacked = false
		for _, hc in ipairs(ents.FindByClass("mb_hackconsole")) do
			if hc:GetHacked() then hacked = true break end
		end

		local function frac(cat)
			local t = total[cat] or 0
			if t == 0 then return 1 end
			return (alive[cat] or 0) / t
		end

		local navalManaged = MilBase.Naval and MilBase.Naval.State ~= nil
		local navalPowerKey = {
			starmap = "sensors",
			engines = "engines",
			maneuver = "maneuvering",
			hyperspace = "engines",
		}

		-- A category's terminals only lock out when ALL its consoles/parts are
		-- down (redundancy). A hack forces engines + hyperspace terminals off.
		for class, cat in pairs(CATEGORY) do
			local managed = (total[cat] or 0) > 0
			local on = (total[cat] or 0) == 0 or (alive[cat] or 0) > 0
			if navalManaged then managed = true end
			if hacked and (cat == "engines" or cat == "hyperspace") then
				managed, on = true, false
			end
			if navalManaged and MilBase.Naval.PowerFactor(navalPowerKey[cat]) <= 0 then
				managed, on = true, false
			end
			if managed then
				for _, term in ipairs(ents.FindByClass(class)) do
					term.SWU_Interactable = on
				end
			end
		end

		local ctrl = SWU.Controller
		if not IsValid(ctrl) then return end
		local enginePower = navalManaged and MilBase.Naval.PowerFactor("engines") or 1
		local manoeuvrePower = navalManaged and MilBase.Naval.PowerFactor("maneuvering") or 1

		-- ENGINES: top speed scales with surviving consoles/parts; a hack = 0.
		if ((total.engines or 0) > 0 or hacked or navalManaged) and ctrl.SetTargetShipAccelerationLimit then
			local cap = math.Round(math.Clamp(100
				* (hacked and 0 or frac("engines")) * enginePower, 0, 100))
			ctrl:SetTargetShipAccelerationLimit(cap)
			if ctrl.GetTargetShipAcceleration and ctrl:GetTargetShipAcceleration() > cap then
				ctrl:SetTargetShipAcceleration(cap) -- pull current throttle down to the cap
			end
			ctrl.mb_engManaged = true
		elseif ctrl.mb_engManaged then
			ctrl:SetTargetShipAccelerationLimit(100)
			ctrl.mb_engManaged = nil
		end

		-- MANEUVERING: turning slows as consoles/parts are lost (halts entirely
		-- once all are down, via the terminal lockout above).
		if (total.maneuver or 0) > 0 or navalManaged then
			local f = frac("maneuver") * manoeuvrePower
			ctrl.TurnSpeedPerDegree = f > 0 and (0.5 / f) or 0.5
			ctrl.mb_turnManaged = true
		elseif ctrl.mb_turnManaged then
			ctrl.TurnSpeedPerDegree = 0.5
			ctrl.mb_turnManaged = nil
		end

		-- HYPERDRIVE: no jump if all down or hacked; otherwise the trip is longer.
		if (total.hyperspace or 0) > 0 or hacked or navalManaged then
			local f = hacked and 0 or (frac("hyperspace") * enginePower)
			if ctrl.SetCanJumpIntoHyperspace then ctrl:SetCanJumpIntoHyperspace(f > 0) end
			MilBase.SetHyperspaceSpeed(f > 0 and f or 1)
			ctrl.mb_hyperManaged = true
		elseif ctrl.mb_hyperManaged then
			if ctrl.SetCanJumpIntoHyperspace then ctrl:SetCanJumpIntoHyperspace(true) end
			MilBase.SetHyperspaceSpeed(1)
			ctrl.mb_hyperManaged = nil
		end
	end

	-- Announced shipwide when a console is destroyed (called from the entity).
	function MilBase.OnShipNodeBroken(node)
		local cat = nodeCategory(node)
		if not cat then return end

		local total, alive = 0, 0
		for _, n in ipairs(ents.FindByClass("mb_shipnode")) do
			if nodeCategory(n) == cat then
				total = total + 1
				if not n:GetBroken() then alive = alive + 1 end
			end
		end

		local label = SYSTEM_LABEL[cat] or "A ship system"
		MilBase.ChatMsg(nil, Color(215, 165, 70), "[ENGINEERING] ", color_white,
			alive <= 0
				and (label .. " is OFFLINE — all consoles destroyed. Engineers, repair them.")
				or (label .. " degraded — " .. alive .. "/" .. total .. " consoles online."))
	end

	net.Receive("MilBase_ShipNodeFix", function(_, ply)
		local node = net.ReadEntity()
		if not IsValid(node) or node:GetClass() ~= "mb_shipnode" then return end
		if not node:GetBroken() or not ply:Alive() then return end
		if node:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end
		-- The minigame takes a couple of seconds; reject instant replies.
		if (ply.mb_shipnodeOpen or 0) > CurTime() - 2 then return end

		node:Fix()
		if MilBase.EngIncidentFixed then
			MilBase.EngIncidentFixed(ply, "restored the "
				.. string.lower(node:GetSystemName() or "ship system") .. " console")
		end
	end)

	timer.Create("MilBase.ShipSystemsRefresh", 2, 0, function()
		MilBase.RefreshShipSystems()
	end)

	hook.Add("InitPostEntity", "MilBase.ShipSystemsInit", function()
		timer.Simple(3, MilBase.RefreshShipSystems)
	end)

else

	--------------------------------------------------------------------
	-- Client: repair minigame + offline markers
	--------------------------------------------------------------------

	-- Each system gets a themed repair minigame (see modules/cl_minigame.lua).
	net.Receive("MilBase_ShipNodeGame", function()
		local node = net.ReadEntity()
		if not IsValid(node) then return end

		local lp = LocalPlayer()
		local eng = lp:MBHasCert("engineer") or lp:IsAdmin() -- engineers get the easier variant
		local sys = node:GetSystemName() or ""

		local function valid()
			return IsValid(node) and node:GetBroken()
				and node:GetPos():DistToSqr(LocalPlayer():GetPos()) < 150 * 150
		end
		local function onSuccess()
			net.Start("MilBase_ShipNodeFix")
				net.WriteEntity(node)
			net.SendToServer()
		end

		if sys == "SUBLIGHT ENGINES" then
			MilBase.OpenReactorMinigame({
				title = "REACTOR STABILISATION",
				subtitle = "Vent the overloading drive plasma while the core is in the safe band.",
				locks = eng and 2 or 4, color = MilBase.UI.warn,
				valid = valid, onSuccess = onSuccess,
			})
		elseif sys == "HYPERDRIVE" then
			MilBase.OpenSequenceMinigame({
				title = "HYPERDRIVE RECALIBRATION",
				subtitle = "Repeat the jump-coordinate alignment sequence.",
				length = eng and 3 or 5,
				valid = valid, onSuccess = onSuccess,
			})
		elseif sys == "MANEUVERING" then
			MilBase.OpenWireMinigame({
				title = "THRUSTER CONTROL REWIRING",
				subtitle = "Reconnect each severed control line to its matching port.",
				wires = eng and 3 or 5,
				valid = valid, onSuccess = onSuccess,
			})
		else -- STAR MAP (and any unbound console): reboot the database
			MilBase.OpenCodeMinigame({
				title = "STAR MAP REBOOT",
				subtitle = "Type the recovery sequence to reboot the " ..
					string.lower(node:GetSystemName() or "system") .. " console.",
				lines = MilBase.GenCodeLines(eng and 3 or 5),
				valid = valid, onSuccess = onSuccess,
			})
		end
	end)

	hook.Add("HUDPaint", "MilBase.ShipNodeMarkers", function()
		if MilBase.InEventView() then return end
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then return end

		local ui = MilBase.UI
		local engineer = lp:MBHasCert("engineer") or lp:IsAdmin()
		local maxDist = engineer and 600 or 300

		for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
			if not node:GetBroken() then continue end

			local dist = lp:GetPos():Distance(node:GetPos())
			if dist > maxDist then continue end

			local screen = (node:GetPos() + Vector(0, 0, 20)):ToScreen()
			if not screen.visible then continue end

			draw.SimpleTextOutlined("⚠ " .. (node:GetSystemName() or "SYSTEM") .. " CONSOLE DOWN",
				"MB.Small", screen.x, screen.y - 10, ui.danger,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
			if dist < 160 then
				draw.SimpleTextOutlined("PRESS [E] TO REPAIR", "MB.Tiny",
					screen.x, screen.y + 8, ui.dim,
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
			end
		end
	end)

end
