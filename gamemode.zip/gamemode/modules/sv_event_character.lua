if not SERVER then return end

MilBase.EventCharacter = MilBase.EventCharacter or {}
local EC = MilBase.EventCharacter

local function canManageEC(ply)
	if not IsValid(ply) then return false end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	if ply.IsUserGroup and (ply:IsUserGroup("eventstaff") or ply:IsUserGroup("event_staff") or ply:IsUserGroup("admin") or ply:IsUserGroup("superadmin") or ply:IsUserGroup("moderator") or ply:IsUserGroup("operator") or ply:IsUserGroup("staff")) then return true end
	if MilBase.Staff and MilBase.Staff.IsStaff and MilBase.Staff.IsStaff(ply) then return true end
	if ply.MBStaffLevel and ply:MBStaffLevel() >= 1 then return true end
	return false
end

function EC.ApplyProfile(ply, data)
	if not IsValid(ply) or not istable(data) then return false end

	-- Backup original player stats if not already backed up
	if not ply.mb_ec_backup then
		ply.mb_ec_backup = {
			name = ply:GetNWString("mb_name", ""),
			model = ply:GetModel(),
			health = ply:Health(),
			maxHealth = ply:GetMaxHealth(),
			scale = ply:GetModelScale(),
		}
	end

	local name = string.Trim(tostring(data.name or "Event Character"))
	local model = string.Trim(tostring(data.model or "models/player/combine_soldier.mdl"))
	local hp = math.Clamp(tonumber(data.health) or 500, 10, 20000)
	local scale = math.Clamp(tonumber(data.scale) or 1.0, 0.5, 3.0)
	local language = string.Trim(tostring(data.language or "basic"))
	local unlimited = data.unlimitedWeapons ~= false

	ply:SetNWBool("mb_ec_active", true)
	ply:SetNWString("mb_ec_name", name)
	ply:SetNWString("mb_ec_language", language)
	ply:SetNWBool("mb_ec_unlimited_weapons", unlimited)

	if util.IsValidModel(model) then
		ply:SetModel(model)
	end

	ply:SetModelScale(scale, 0)
	ply:SetMaxHealth(hp)
	ply:SetHealth(hp)

	-- Give extra weapons
	if istable(data.weapons) then
		for _, wepClass in ipairs(data.weapons) do
			wepClass = string.Trim(tostring(wepClass))
			if wepClass ~= "" and not ply:HasWeapon(wepClass) then
				ply:Give(wepClass)
			end
		end
	end

	MilBase.Notify(ply, "Event Character Profile Applied: " .. name .. " [" .. language .. "]", "ok")
	return true
end

function EC.RevertProfile(ply)
	if not IsValid(ply) or not ply:MBIsEventCharacter() then return false end

	local backup = ply.mb_ec_backup or {}
	ply:SetNWBool("mb_ec_active", false)
	ply:SetNWString("mb_ec_name", "")
	ply:SetNWString("mb_ec_language", "")
	ply:SetNWBool("mb_ec_unlimited_weapons", false)

	if backup.model and util.IsValidModel(backup.model) then
		ply:SetModel(backup.model)
	end

	ply:SetModelScale(backup.scale or 1.0, 0)
	ply:SetMaxHealth(backup.maxHealth or 100)
	ply:SetHealth(math.min(ply:Health(), backup.maxHealth or 100))

	ply.mb_ec_backup = nil
	MilBase.Notify(ply, "Returned to normal player character.", "ok")
	return true
end

net.Receive("MilBase_EC_ApplyProfile", function(len, ply)
	if not canManageEC(ply) then return end
	local length = net.ReadUInt(24)
	if length <= 0 then return end
	local raw = util.Decompress(net.ReadData(length))
	local data = raw and util.JSONToTable(raw) or nil
	if istable(data) then
		EC.ApplyProfile(ply, data)
	end
end)

net.Receive("MilBase_EC_RevertProfile", function(len, ply)
	if not canManageEC(ply) then return end
	EC.RevertProfile(ply)
end)

-- Console command dispatch
concommand.Add("mb_ec", function(ply, cmd, args)
	if not canManageEC(ply) then return end
	local action = string.lower(string.Trim(args[1] or ""))
	if action == "off" or action == "revert" then
		EC.RevertProfile(ply)
	else
		net.Start("MilBase_EC_OpenMenu")
		net.Send(ply)
	end
end)

-- Register with MilBase Chat Command system (/ec, /eventchar)
if MilBase and MilBase.RegisterChatCommand then
	MilBase.RegisterChatCommand("ec", {
		help = "Open Event Character Creator menu or toggle profile (/ec off).",
		func = function(ply, args, rawText)
			if not canManageEC(ply) then
				MilBase.Notify(ply, "You must be Event Staff or Admin to use /ec.", "danger")
				return
			end
			local action = string.lower(string.Trim(args[1] or ""))
			if action == "off" or action == "revert" then
				EC.RevertProfile(ply)
			else
				net.Start("MilBase_EC_OpenMenu")
				net.Send(ply)
			end
		end,
	})

	MilBase.RegisterChatCommand("eventchar", {
		help = "Open Event Character Creator menu.",
		func = function(ply, args, rawText)
			if not canManageEC(ply) then
				MilBase.Notify(ply, "You must be Event Staff or Admin to use /eventchar.", "danger")
				return
			end
			local action = string.lower(string.Trim(args[1] or ""))
			if action == "off" or action == "revert" then
				EC.RevertProfile(ply)
			else
				net.Start("MilBase_EC_OpenMenu")
				net.Send(ply)
			end
		end,
	})
end
