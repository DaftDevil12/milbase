SWInfil = SWInfil or {}

if not SWInfil.SharedLoaded then
    include("modules/sh_sw_infil_core.lua")
end

if SWInfil.ServerLoaded then
    return
end

SWInfil.ServerLoaded = true

util.AddNetworkString("sw_infil_begin")
util.AddNetworkString("sw_infil_end")
util.AddNetworkString("sw_infil_skip")
util.AddNetworkString("sw_infil_seats_sync")
util.AddNetworkString("sw_infil_skybox_begin")
util.AddNetworkString("sw_infil_skybox_end")
util.AddNetworkString("sw_infil_spawns_sync")
util.AddNetworkString("sw_infil_spawn_menu")
util.AddNetworkString("sw_infil_spawn_select")

local cvEnabled = CreateConVar("sw_infil_enabled", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY }, "Enable Star Wars LAAT tactical infiltrations.", 0, 1)
local cvOnSpawn = CreateConVar("sw_infil_on_spawn", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY }, "Run the LAAT infiltration when a player spawns.", 0, 1)
local cvModel = CreateConVar("sw_infil_model", SWInfil.DefaultModel, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Model used for the cinematic LAAT.")
local cvSkin = CreateConVar("sw_infil_skin", "0", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Skin index for the infiltration LAAT.", 0)
local cvApproach = CreateConVar("sw_infil_approach_time", "8.5", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Seconds the LAAT spends flying to the LZ.", 2, 30)
local cvGround = CreateConVar("sw_infil_ground_time", "3.5", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Seconds the LAAT waits with doors open before departure.", 0.5, 20)
local cvDeparture = CreateConVar("sw_infil_departure_time", "5", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Seconds the LAAT spends leaving after drop-off.", 1, 20)
local cvDepartureDistance = CreateConVar("sw_infil_departure_distance", "2200", { FCVAR_ARCHIVE }, "How far forward the LAAT flies away after drop-off.", 400, 8000)
local cvDepartureHeight = CreateConVar("sw_infil_departure_height", "1000", { FCVAR_ARCHIVE }, "How much the LAAT climbs after drop-off.", 100, 4000)
local cvHover = CreateConVar("sw_infil_hover_height", "120", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "How high above the toolgun landing point the LAAT hovers.", 16, 512)
local cvGod = CreateConVar("sw_infil_god", "1", { FCVAR_ARCHIVE }, "Protect players while they are inside the cinematic LAAT.", 0, 1)
local cvAllowSkip = CreateConVar("sw_infil_allow_skip", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Let players press SPACE to skip their infiltration.", 0, 1)
local cvChat = CreateConVar("sw_infil_chat", "1", { FCVAR_ARCHIVE }, "Show LAAT infiltration chat messages.", 0, 1)
local cvSpawnDelay = CreateConVar("sw_infil_spawn_delay", "0.6", { FCVAR_ARCHIVE }, "Delay after PlayerSpawn before the LAAT sequence starts.", 0, 10)
local cvSpawnMenu = CreateConVar("sw_infil_spawn_menu_enabled", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Open a LAAT deployment menu when players respawn.", 0, 1)
local cvReleaseSide = CreateConVar("sw_infil_release_side", "auto", { FCVAR_ARCHIVE }, "Exit side: auto, left, or right.")
local cvShareLAAT = CreateConVar("sw_infil_share_laat", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Put players who spawn during the same landing into open seats on the same LAAT.", 0, 1)
local cvCameraForward = CreateConVar("sw_infil_camera_forward", "0", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Passenger camera forward/back offset inside the LAAT.", -80, 80)
local cvCameraRight = CreateConVar("sw_infil_camera_right", "8", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Passenger camera left/right offset inside the LAAT.", -80, 80)
local cvCameraUp = CreateConVar("sw_infil_camera_up", "54", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Passenger camera vertical offset inside the LAAT.", 24, 96)
local cvAnchorUp = CreateConVar("sw_infil_anchor_up", "0", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Passenger body vertical offset while riding the LAAT.", -32, 128)
local cvShowPassengers = CreateConVar("sw_infil_show_passengers", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Show controlled passenger playermodel proxies inside the LAAT.", 0, 1)
local cvLookYaw = CreateConVar("sw_infil_look_yaw", "140", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "How far left/right passengers can look during the LAAT ride.", 25, 180)
local cvLookPitch = CreateConVar("sw_infil_look_pitch", "65", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "How far up/down passengers can look during the LAAT ride.", 15, 89)
local cvGhostModel = CreateConVar("sw_infil_ghost_model", "models/player/Group01/male_07.mdl", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Preview playermodel used by the LAAT Seat Editor.")
local cvSeatPreviewHeight = CreateConVar("sw_infil_seat_preview_height", "120", { FCVAR_ARCHIVE }, "How far above the clicked ground point the seat-editor LAAT preview spawns.", -256, 512)
local cvSkyboxEnabled = CreateConVar("sw_infil_skybox_enabled", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Show a tiny LAAT flying through the skybox before the real LAAT spawns.", 0, 1)
local cvSkyboxTime = CreateConVar("sw_infil_skybox_time", "4", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Seconds spent showing the tiny skybox LAAT before the real one spawns.", 0, 20)
local cvSkyboxDistance = CreateConVar("sw_infil_skybox_distance", "7000", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "World distance behind the map entry point used for the tiny skybox LAAT start.", 500, 20000)
local cvSkyboxHeight = CreateConVar("sw_infil_skybox_height", "1800", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "World height offset used for the tiny skybox LAAT fly-in.", -2000, 8000)
local cvSkyboxModelScale = CreateConVar("sw_infil_skybox_model_scale", "0.045", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Clientside scale of the tiny skybox LAAT model.", 0.005, 0.25)
local cvSkyboxWorldFallbackScale = CreateConVar("sw_infil_skybox_world_fallback_scale", "0.45", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Clientside scale for the visible world fallback skybox LAAT model.", 0.005, 1.5)
local cvSkyboxMapMinScale = CreateConVar("sw_infil_skybox_map_min_scale", "0.35", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Minimum visible scale for the map-side mini LAAT fallback.", 0.005, 1.5)
local cvSkyboxMapIgnoreZ = CreateConVar("sw_infil_skybox_map_ignore_z", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Draw the map-side mini LAAT fallback through world geometry.", 0, 1)
local cvSkyboxPrompt = CreateConVar("sw_infil_skybox_prompt", "LAAT Flying IN", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Prompt shown while waiting for the real LAAT to spawn.")
local cvSkyboxEditorHeight = CreateConVar("sw_infil_skybox_editor_height", "0", { FCVAR_ARCHIVE }, "Vertical offset applied by the skybox flight editor tool.", -10000, 10000)
local cvFlightBankStrength = CreateConVar("sw_infil_bank_strength", "1.1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "How strongly the LAAT banks into turns.", 0, 4)
local cvFlightMaxBank = CreateConVar("sw_infil_max_bank", "20", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Maximum LAAT banking angle.", 0, 60)
local cvFlightLookAhead = CreateConVar("sw_infil_turn_lookahead", "0.055", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "How far ahead the flight model looks when calculating bank.", 0.01, 0.2)
local cvLandingPitch = CreateConVar("sw_infil_landing_pitch", "7", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Extra LAAT pitch flare while landing.", -20, 20)
local cvTurretsEnabled = CreateConVar("sw_infil_turrets_enabled", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enable LAAT defensive ball turrets during approach.", 0, 1)
local cvTurretRange = CreateConVar("sw_infil_turret_range", "2600", { FCVAR_ARCHIVE }, "Range for LAAT defensive turrets.", 256, 12000)
local cvTurretDamage = CreateConVar("sw_infil_turret_damage", "55", { FCVAR_ARCHIVE }, "Damage per LAAT turret shot.", 1, 500)
local cvTurretInterval = CreateConVar("sw_infil_turret_interval", "0.18", { FCVAR_ARCHIVE }, "Seconds between LAAT turret shots.", 0.05, 2)
local cvTurretTargetAllNPCs = CreateConVar("sw_infil_turret_target_all_npcs", "1", { FCVAR_ARCHIVE }, "Allow LAAT turrets to target any non-friendly NPC if hostility cannot be read.", 0, 1)
local cvTurretUseAttachments = CreateConVar("sw_infil_turret_use_attachments", "1", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Use LAAT/LVS model attachments for ball turret muzzle positions.", 0, 1)
local cvTurretLeftAttachment = CreateConVar("sw_infil_turret_left_attachment", "", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Optional exact left ball turret attachment name.")
local cvTurretRightAttachment = CreateConVar("sw_infil_turret_right_attachment", "", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Optional exact right ball turret attachment name.")

local function isAdmin(ply)
    return not IsValid(ply) or game.SinglePlayer() or ply:IsAdmin() or ply:IsSuperAdmin()
end

function SWInfil.Message(ply, text, force)
    local line = "[LAAT Infil] " .. text

    if IsValid(ply) then
        if force or cvChat:GetBool() then
            ply:ChatPrint(line)
        end

        ply:PrintMessage(HUD_PRINTCONSOLE, line)
    else
        print(line)
    end
end

local function vecToTable(vec)
    return { x = vec.x, y = vec.y, z = vec.z }
end

local function angToTable(ang)
    return { p = ang.p, y = ang.y, r = ang.r }
end

local function tableToVec(data)
    if not istable(data) then return nil end
    return Vector(tonumber(data.x) or 0, tonumber(data.y) or 0, tonumber(data.z) or 0)
end

local function tableToAng(data)
    if not istable(data) then return angle_zero end
    return Angle(tonumber(data.p) or 0, tonumber(data.y) or 0, tonumber(data.r) or 0)
end

function SWInfil.RoutePath()
    return "sw_infil/" .. game.GetMap() .. ".json"
end

function SWInfil.RoutesPath()
    return "sw_infil/" .. game.GetMap() .. "_routes.json"
end

function SWInfil.SeatPath()
    return "sw_infil/" .. game.GetMap() .. "_seats.json"
end

function SWInfil.SkyboxFlightPath()
    return "sw_infil/" .. game.GetMap() .. "_skybox_flight.json"
end

function SWInfil.NormalizeRouteID(routeID)
    routeID = string.Trim(tostring(routeID or "main"))
    routeID = string.lower(routeID)
    routeID = string.gsub(routeID, "%s+", "_")
    routeID = string.gsub(routeID, "[^%w_%-]", "")

    if routeID == "" then
        routeID = "main"
    end

    return string.Left(routeID, 32)
end

local function cleanRouteName(name, routeID)
    name = string.Trim(tostring(name or ""))
    if name == "" then
        if routeID == "main" then return "Main Landing Zone" end
        return string.upper(string.sub(routeID, 1, 1)) .. string.sub(routeID, 2)
    end

    return string.Left(name, 48)
end

local function routeToData(route)
    if not istable(route) then return nil end

    local data = {
        id = route.id,
        name = route.name
    }

    if route.start then
        data.start = {
            pos = vecToTable(route.start.pos),
            ang = angToTable(route.start.ang or angle_zero)
        }
    end

    if route.land then
        data.land = {
            pos = vecToTable(route.land.pos),
            ang = angToTable(route.land.ang or angle_zero)
        }
    end

    return data
end

local function dataToRoute(data, fallbackID)
    if not istable(data) then return nil end

    local routeID = SWInfil.NormalizeRouteID(data.id or fallbackID or "main")
    local route = {
        id = routeID,
        name = cleanRouteName(data.name, routeID)
    }

    if data.start then
        route.start = {
            pos = tableToVec(data.start.pos),
            ang = tableToAng(data.start.ang)
        }
    end

    if data.land then
        route.land = {
            pos = tableToVec(data.land.pos),
            ang = tableToAng(data.land.ang)
        }
    end

    return route
end

function SWInfil.RouteIsReady(route)
    route = route or SWInfil.Route
    return istable(route)
        and istable(route.start)
        and istable(route.land)
        and route.start.pos ~= nil
        and route.land.pos ~= nil
end

function SWInfil.GetReadyRoutes()
    local readyRoutes = {}

    for routeID, route in pairs(SWInfil.Routes or {}) do
        if SWInfil.RouteIsReady(route) then
            readyRoutes[#readyRoutes + 1] = {
                id = routeID,
                route = route
            }
        end
    end

    table.sort(readyRoutes, function(a, b)
        if a.id == "main" then return true end
        if b.id == "main" then return false end

        local aName = a.route.name or a.id
        local bName = b.route.name or b.id
        return string.lower(aName) < string.lower(bName)
    end)

    return readyRoutes
end

function SWInfil.HasAnyReadyRoute()
    return #SWInfil.GetReadyRoutes() > 0
end

function SWInfil.GetRoute(routeID)
    local normalized = SWInfil.NormalizeRouteID(routeID or SWInfil.ActiveRouteID or "main")
    local route = SWInfil.Routes and SWInfil.Routes[normalized]

    if SWInfil.RouteIsReady(route) then
        return route, normalized
    end

    if normalized ~= "main" and SWInfil.RouteIsReady(SWInfil.Routes and SWInfil.Routes.main) then
        return SWInfil.Routes.main, "main"
    end

    for _, item in ipairs(SWInfil.GetReadyRoutes()) do
        return item.route, item.id
    end
end

function SWInfil.PublishSpawnRoutes(target)
    local routes = SWInfil.GetReadyRoutes()
    local count = math.Clamp(#routes, 0, 63)

    net.Start("sw_infil_spawns_sync")
        net.WriteUInt(count, 6)

        for index = 1, count do
            local item = routes[index]
            local route = item.route

            net.WriteString(item.id)
            net.WriteString(route.name or item.id)
            net.WriteVector(route.start.pos)
            net.WriteAngle(route.start.ang or angle_zero)
            net.WriteVector(route.land.pos)
            net.WriteAngle(route.land.ang or angle_zero)
        end

    if IsValid(target) then
        net.Send(target)
    else
        net.Broadcast()
    end
end

function SWInfil.PublishRoute(target)
    local route = SWInfil.Route or {}
    local ready = SWInfil.RouteIsReady(route)

    SetGlobalBool("SWInfilRouteValid", ready)

    if route.start then
        SetGlobalVector("SWInfilRouteStart", route.start.pos or vector_origin)
        SetGlobalFloat("SWInfilRouteStartYaw", route.start.ang and route.start.ang.y or 0)
    end

    if route.land then
        SetGlobalVector("SWInfilRouteLand", route.land.pos or vector_origin)
        SetGlobalFloat("SWInfilRouteLandYaw", route.land.ang and route.land.ang.y or 0)
    end

    SWInfil.PublishSpawnRoutes(target)
end

function SWInfil.SaveRoute()
    file.CreateDir("sw_infil")

    local data = {
        active = SWInfil.ActiveRouteID or "main",
        routes = {}
    }

    for routeID, route in pairs(SWInfil.Routes or {}) do
        data.routes[routeID] = routeToData(route)
    end

    file.Write(SWInfil.RoutesPath(), util.TableToJSON(data, true))

    if SWInfil.RouteIsReady(SWInfil.Routes and SWInfil.Routes.main) then
        file.Write(SWInfil.RoutePath(), util.TableToJSON(routeToData(SWInfil.Routes.main), true))
    elseif file.Exists(SWInfil.RoutePath(), "DATA") then
        file.Delete(SWInfil.RoutePath())
    end

    local activeRoute = SWInfil.Routes and SWInfil.Routes[SWInfil.ActiveRouteID or "main"]
    SWInfil.Route = activeRoute or SWInfil.GetRoute()
    SWInfil.PublishRoute()
end

function SWInfil.LoadRoute()
    SWInfil.Routes = {}
    SWInfil.Route = {}

    local routesPath = SWInfil.RoutesPath()
    if file.Exists(routesPath, "DATA") then
        local decoded = util.JSONToTable(file.Read(routesPath, "DATA") or "") or {}
        local routes = decoded.routes or decoded

        if istable(routes) then
            for routeID, routeData in pairs(routes) do
                local route = dataToRoute(routeData, routeID)
                if route then
                    SWInfil.Routes[route.id] = route
                end
            end
        end

        SWInfil.ActiveRouteID = SWInfil.NormalizeRouteID(decoded.active or "main")
    end

    local legacyPath = SWInfil.RoutePath()
    if file.Exists(legacyPath, "DATA") then
        local decoded = util.JSONToTable(file.Read(legacyPath, "DATA") or "") or {}
        local route = dataToRoute(decoded, "main")
        if route and SWInfil.RouteIsReady(route) and not SWInfil.RouteIsReady(SWInfil.Routes.main) then
            route.id = "main"
            route.name = route.name or "Main Landing Zone"
            SWInfil.Routes.main = route
        end
    end

    local activeRoute, activeID = SWInfil.GetRoute(SWInfil.ActiveRouteID or "main")
    SWInfil.ActiveRouteID = activeID or "main"
    SWInfil.Route = activeRoute or {}
    SWInfil.PublishRoute()
end

function SWInfil.SetRoutePoint(kind, pos, ang, ply, routeID, routeName)
    if kind ~= "start" and kind ~= "land" then return false end

    routeID = SWInfil.NormalizeRouteID(routeID or "main")
    SWInfil.Routes = SWInfil.Routes or {}

    local route = SWInfil.Routes[routeID] or {
        id = routeID
    }

    route.name = cleanRouteName(routeName or route.name, routeID)
    route[kind] = {
        pos = pos,
        ang = Angle(0, ang.y, 0)
    }

    SWInfil.Routes[routeID] = route
    SWInfil.ActiveRouteID = routeID
    SWInfil.Route = route
    SWInfil.SaveRoute()

    local label = kind == "start" and "start point" or "landing zone"
    SWInfil.Message(ply, "Saved " .. label .. " for LAAT spawn '" .. route.name .. "' on " .. game.GetMap() .. ".")
    return true
end

function SWInfil.ClearRoute(ply, routeID)
    routeID = SWInfil.NormalizeRouteID(routeID or SWInfil.ActiveRouteID or "main")
    SWInfil.Routes = SWInfil.Routes or {}
    SWInfil.Routes[routeID] = nil

    if routeID == "main" then
        SWInfil.Route = {}
    elseif SWInfil.ActiveRouteID == routeID then
        local route, newID = SWInfil.GetRoute("main")
        SWInfil.Route = route or {}
        SWInfil.ActiveRouteID = newID or "main"
    end

    SWInfil.SaveRoute()
    SWInfil.Message(ply, "Cleared LAAT spawn '" .. routeID .. "' for " .. game.GetMap() .. ".")
end

function SWInfil.SkyboxRouteIsReady(route)
    route = route or SWInfil.SkyboxRoute
    return istable(route)
        and istable(route.start)
        and istable(route.finish)
        and route.start.pos ~= nil
        and route.finish.pos ~= nil
end

function SWInfil.PublishSkyboxRoute()
    local route = SWInfil.SkyboxRoute or {}
    local ready = SWInfil.SkyboxRouteIsReady(route)

    SetGlobalBool("SWInfilSkyboxRouteValid", ready)

    if route.start then
        SetGlobalVector("SWInfilSkyboxStart", route.start.pos or vector_origin)
        SetGlobalFloat("SWInfilSkyboxStartYaw", route.start.ang and route.start.ang.y or 0)
    end

    if route.mid then
        SetGlobalBool("SWInfilSkyboxHasMid", true)
        SetGlobalVector("SWInfilSkyboxMid", route.mid.pos or vector_origin)
        SetGlobalFloat("SWInfilSkyboxMidYaw", route.mid.ang and route.mid.ang.y or 0)
    else
        SetGlobalBool("SWInfilSkyboxHasMid", false)
    end

    if route.finish then
        SetGlobalVector("SWInfilSkyboxFinish", route.finish.pos or vector_origin)
        SetGlobalFloat("SWInfilSkyboxFinishYaw", route.finish.ang and route.finish.ang.y or 0)
    end
end

function SWInfil.SaveSkyboxRoute()
    file.CreateDir("sw_infil")

    local route = SWInfil.SkyboxRoute or {}
    local data = {}

    for _, key in ipairs({ "start", "mid", "finish" }) do
        if route[key] then
            data[key] = {
                pos = vecToTable(route[key].pos),
                ang = angToTable(route[key].ang or angle_zero)
            }
        end
    end

    file.Write(SWInfil.SkyboxFlightPath(), util.TableToJSON(data, true))
    SWInfil.PublishSkyboxRoute()
end

function SWInfil.LoadSkyboxRoute()
    SWInfil.SkyboxRoute = {}

    local path = SWInfil.SkyboxFlightPath()
    if file.Exists(path, "DATA") then
        local decoded = util.JSONToTable(file.Read(path, "DATA") or "") or {}

        for _, key in ipairs({ "start", "mid", "finish" }) do
            if decoded[key] then
                local pos = tableToVec(decoded[key].pos)
                if pos then
                    SWInfil.SkyboxRoute[key] = {
                        pos = pos,
                        ang = tableToAng(decoded[key].ang)
                    }
                end
            end
        end
    end

    SWInfil.PublishSkyboxRoute()
end

function SWInfil.SetSkyboxPoint(kind, pos, ang, ply)
    if kind ~= "start" and kind ~= "mid" and kind ~= "finish" then return false end

    SWInfil.SkyboxRoute = SWInfil.SkyboxRoute or {}
    SWInfil.SkyboxRoute[kind] = {
        pos = pos,
        ang = Angle(0, ang.y, 0)
    }

    SWInfil.SaveSkyboxRoute()

    local labels = {
        start = "skybox flight start",
        mid = "skybox flight curve point",
        finish = "skybox flight map-entry point"
    }

    SWInfil.Message(ply, "Saved " .. labels[kind] .. " for " .. game.GetMap() .. ".")
    return true
end

function SWInfil.ClearSkyboxRoute(ply)
    SWInfil.SkyboxRoute = {}

    local path = SWInfil.SkyboxFlightPath()
    if file.Exists(path, "DATA") then
        file.Delete(path)
    end

    SWInfil.PublishSkyboxRoute()
    SWInfil.Message(ply, "Cleared the custom skybox flight for " .. game.GetMap() .. ".")
end

local function copySeat(seat)
    return {
        pos = Vector(seat.pos.x, seat.pos.y, seat.pos.z),
        ang = Angle(seat.ang.p, seat.ang.y, seat.ang.r)
    }
end

function SWInfil.CopyDefaultSeats()
    local seats = {}

    for index, seat in ipairs(SWInfil.DefaultSeats or {}) do
        seats[index] = copySeat(seat)
    end

    return seats
end

function SWInfil.PublishSeats(target)
    local seats = SWInfil.Seats or {}
    local count = math.Clamp(#seats, 0, 63)

    net.Start("sw_infil_seats_sync")
        net.WriteUInt(count, 6)

        for index = 1, count do
            local seat = seats[index]
            net.WriteVector(seat.pos)
            net.WriteAngle(seat.ang)
        end

    if IsValid(target) then
        net.Send(target)
    else
        net.Broadcast()
    end
end

function SWInfil.SaveSeats()
    file.CreateDir("sw_infil")

    local data = {}
    for index, seat in ipairs(SWInfil.Seats or {}) do
        data[index] = {
            pos = vecToTable(seat.pos),
            ang = angToTable(seat.ang or angle_zero)
        }
    end

    file.Write(SWInfil.SeatPath(), util.TableToJSON(data, true))
    SWInfil.PublishSeats()
end

function SWInfil.LoadSeats()
    local path = SWInfil.SeatPath()

    if not file.Exists(path, "DATA") then
        SWInfil.Seats = SWInfil.CopyDefaultSeats()
        SWInfil.PublishSeats()
        return
    end

    local decoded = util.JSONToTable(file.Read(path, "DATA") or "") or {}
    local seats = {}

    for index, seat in ipairs(decoded) do
        local pos = tableToVec(seat.pos)
        if pos then
            seats[index] = {
                pos = pos,
                ang = tableToAng(seat.ang)
            }
        end
    end

    SWInfil.Seats = #seats > 0 and seats or SWInfil.CopyDefaultSeats()
    SWInfil.PublishSeats()
end

local function tellSetupProblem(ply, reason)
    if not IsValid(ply) or isAdmin(ply) then
        SWInfil.Message(ply, reason, true)
    end
end

function SWInfil.BuildPlayerRestore(ply)
    local hadGod = ply.HasGodMode and ply:HasGodMode() or false

    return {
        moveType = ply:GetMoveType(),
        noDraw = ply:GetNoDraw(),
        notSolid = ply.GetNotSolid and ply:GetNotSolid() or false,
        collisionGroup = ply:GetCollisionGroup(),
        hadGod = hadGod,
        godEnabledByInfil = cvGod:GetBool() and not hadGod
    }
end

function SWInfil.GetServerRideAnchorOffset()
    return Vector(0, 0, cvAnchorUp:GetFloat())
end

function SWInfil.EnsureVehicleSeats(ent)
    if not IsValid(ent) then return end

    ent.SWInfilOccupants = ent.SWInfilOccupants or {}
    ent.SWInfilSeatTaken = ent.SWInfilSeatTaken or {}
end

function SWInfil.GetVehicleOccupantCount(ent)
    if not IsValid(ent) then return 0 end

    local count = 0
    for ply, seat in pairs(ent.SWInfilOccupants or {}) do
        if IsValid(ply) and ply.SWInfilVehicle == ent then
            count = count + 1
        else
            SWInfil.RemoveVehicleOccupant(ent, ply)
        end
    end

    return count
end

function SWInfil.FindOpenSeat(ent)
    if not IsValid(ent) then return nil end

    SWInfil.EnsureVehicleSeats(ent)

    for seat = 1, #SWInfil.Seats do
        local takenBy = ent.SWInfilSeatTaken[seat]
        if not IsValid(takenBy) or takenBy.SWInfilVehicle ~= ent then
            ent.SWInfilSeatTaken[seat] = nil
            return seat
        end
    end
end

function SWInfil.AddVehicleOccupant(ent, ply, requestedSeat)
    if not IsValid(ent) or not IsValid(ply) then return nil end

    SWInfil.EnsureVehicleSeats(ent)

    local seat = requestedSeat
    if not seat or IsValid(ent.SWInfilSeatTaken[seat]) then
        seat = SWInfil.FindOpenSeat(ent)
    end

    if not seat then return nil end

    ent.SWInfilOccupants[ply] = seat
    ent.SWInfilSeatTaken[seat] = ply
    ent.SWInfilLastJoin = CurTime()
    ply.SWInfilSeat = seat

    if not IsValid(ent:GetOccupant()) then
        ent:SetOccupant(ply)
        ent:SetSeatNumber(seat)
    end

    return seat
end

function SWInfil.RemoveVehicleOccupant(ent, ply)
    if not IsValid(ent) then return end

    SWInfil.EnsureVehicleSeats(ent)

    local seat = ent.SWInfilOccupants[ply]
    if seat then
        ent.SWInfilOccupants[ply] = nil

        if ent.SWInfilSeatTaken[seat] == ply then
            ent.SWInfilSeatTaken[seat] = nil
        end
    end

    if ent:GetOccupant() == ply then
        ent:SetOccupant(NULL)
        ent:SetSeatNumber(1)

        for other, otherSeat in pairs(ent.SWInfilOccupants) do
            if IsValid(other) then
                ent:SetOccupant(other)
                ent:SetSeatNumber(otherSeat)
                break
            end
        end
    end
end

function SWInfil.FindJoinableLAAT(routeID)
    if not cvShareLAAT:GetBool() then return nil end

    routeID = routeID and SWInfil.NormalizeRouteID(routeID) or nil

    for _, ent in ipairs(ents.FindByClass("sw_infil_laat")) do
        if IsValid(ent) and (not routeID or ent.SWInfilRouteID == routeID) and SWInfil.FindOpenSeat(ent) then
            local phase = SWInfil.GetPhase(ent, CurTime())
            if phase == "approach" or phase == "landed" then
                return ent
            end
        end
    end
end

function SWInfil.ResolveSkyboxFlight(route)
    local custom = SWInfil.SkyboxRoute
    if SWInfil.SkyboxRouteIsReady(custom) then
        local start = custom.start
        local finish = custom.finish
        local mid = custom.mid

        if not mid then
            mid = {
                pos = SWInfil.MakeCurveMidpoint(start.pos, finish.pos, start.ang, finish.ang, cvSkyboxHeight:GetFloat() * 0.25, 0),
                ang = start.ang
            }
        end

        return {
            start = start,
            mid = mid,
            finish = finish,
            custom = true
        }
    end

    local entryPos = route.start.pos
    local entryAng = route.start.ang or angle_zero
    local startPos = entryPos - entryAng:Forward() * cvSkyboxDistance:GetFloat() + Vector(0, 0, cvSkyboxHeight:GetFloat())
    local finishPos = entryPos - entryAng:Forward() * 360 + Vector(0, 0, 220)
    local side = math.Clamp(cvSkyboxDistance:GetFloat() * 0.10, 350, 1400)
    local midPos = SWInfil.MakeCurveMidpoint(startPos, finishPos, entryAng, entryAng, math.max(cvSkyboxHeight:GetFloat() * 0.18, 250), side)

    return {
        start = {
            pos = startPos,
            ang = entryAng
        },
        mid = {
            pos = midPos,
            ang = entryAng
        },
        finish = {
            pos = finishPos,
            ang = entryAng
        },
        custom = false
    }
end

function SWInfil.SendSkyboxVisual(target, queue)
    queue = queue or SWInfil.SkyboxQueue
    if not queue then return end

    net.Start("sw_infil_skybox_begin")
        net.WriteVector(queue.entryPos or vector_origin)
        net.WriteAngle(queue.entryAng or angle_zero)
        net.WriteFloat(queue.started or CurTime())
        net.WriteFloat(queue.duration or 0)
        net.WriteString(queue.model or SWInfil.DefaultModel)
        net.WriteString(cvSkyboxPrompt:GetString() ~= "" and cvSkyboxPrompt:GetString() or "LAAT Flying IN")
        net.WriteVector(queue.skyStartPos or vector_origin)
        net.WriteAngle(queue.skyStartAng or angle_zero)
        net.WriteVector(queue.skyMidPos or vector_origin)
        net.WriteAngle(queue.skyMidAng or angle_zero)
        net.WriteVector(queue.skyFinishPos or vector_origin)
        net.WriteAngle(queue.skyFinishAng or angle_zero)
        net.WriteBool(queue.customSkybox == true)

    if IsValid(target) then
        net.Send(target)
    else
        net.Broadcast()
    end
end

local function sendSkyboxEndToQueue(queue)
    if not queue then return end

    local targets = {}
    for ply in pairs(queue.players or {}) do
        if IsValid(ply) then
            targets[#targets + 1] = ply
        end
    end

    if #targets <= 0 then return end

    net.Start("sw_infil_skybox_end")
    net.Send(targets)
end

function SWInfil.RestoreStagedPlayer(ply)
    if not IsValid(ply) then return end

    local restore = ply.SWInfilPendingRestore
    if not restore then return end

    ply:SetNWBool("SWInfilSkyboxWaiting", false)
    ply:SetNWBool("SWInfilChoosingSpawn", false)
    ply:SetNoDraw(restore.noDraw == true)

    if ply.SetNotSolid then
        ply:SetNotSolid(restore.notSolid == true)
    end

    ply:SetCollisionGroup(restore.collisionGroup or COLLISION_GROUP_PLAYER)

    if ply:Alive() then
        ply:SetMoveType(restore.moveType or MOVETYPE_WALK)
        ply:SetLocalVelocity(vector_origin)
    end

    if restore.godEnabledByInfil and ply.GodDisable then
        ply:GodDisable()
    end

    ply.SWInfilPendingRestore = nil
    ply.SWInfilSkyboxQueued = nil
    ply.SWInfilPendingRouteID = nil
    ply.SWInfilChoosingSpawn = nil
end

function SWInfil.StagePlayerForSpawnMenu(ply)
    if not IsValid(ply) or not ply:Alive() then return false end
    if ply:GetNWBool("SWInfilActive") or ply:GetNWBool("SWInfilSkyboxWaiting") then return false end

    ply.SWInfilPendingRestore = ply.SWInfilPendingRestore or SWInfil.BuildPlayerRestore(ply)
    ply.SWInfilChoosingSpawn = true
    ply:SetNWBool("SWInfilChoosingSpawn", true)
    ply:SetNoDraw(true)

    if ply.SetNotSolid then
        ply:SetNotSolid(true)
    end

    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    ply:SetMoveType(MOVETYPE_NONE)
    ply:SetLocalVelocity(vector_origin)

    if ply.SWInfilPendingRestore.godEnabledByInfil and ply.GodEnable then
        ply:GodEnable()
    end

    SWInfil.PublishSpawnRoutes(ply)

    net.Start("sw_infil_spawn_menu")
    net.Send(ply)

    return true
end

function SWInfil.UnstagePlayer(ply, restoreNow)
    if not IsValid(ply) then return end

    local routeID = ply.SWInfilSkyboxRouteID
    local queues = SWInfil.SkyboxQueues or {}

    for queueID, queue in pairs(queues) do
        if (not routeID or queueID == routeID) and queue.players then
            queue.players[ply] = nil

            local anyLeft = false
            for queued in pairs(queue.players) do
                if IsValid(queued) then
                    anyLeft = true
                    break
                end
            end

            if not anyLeft then
                timer.Remove("SWInfil_SkyboxComplete_" .. queueID)
                queues[queueID] = nil
            end
        end
    end

    if SWInfil.SkyboxQueue and SWInfil.SkyboxQueue.players then
        SWInfil.SkyboxQueue.players[ply] = nil
    end

    ply.SWInfilSkyboxRouteID = nil

    net.Start("sw_infil_skybox_end")
    net.Send(ply)

    if restoreNow then
        SWInfil.RestoreStagedPlayer(ply)
    end
end

function SWInfil.CompleteSkyboxQueue(routeID)
    routeID = SWInfil.NormalizeRouteID(routeID or "main")
    local queue = SWInfil.SkyboxQueues and SWInfil.SkyboxQueues[routeID]
    if not queue then return end

    SWInfil.SkyboxQueues[routeID] = nil

    if SWInfil.SkyboxQueue == queue then
        SWInfil.SkyboxQueue = nil
    end

    sendSkyboxEndToQueue(queue)

    local playersToStart = {}
    for ply in pairs(queue.players or {}) do
        if IsValid(ply) and ply:Alive() then
            playersToStart[#playersToStart + 1] = ply
        elseif IsValid(ply) then
            SWInfil.RestoreStagedPlayer(ply)
        end
    end

    for _, ply in ipairs(playersToStart) do
        ply:SetNWBool("SWInfilSkyboxWaiting", false)
        ply.SWInfilSkyboxQueued = nil
        ply.SWInfilSkyboxRouteID = nil

        local ok = SWInfil.StartForPlayer(ply, "skybox_complete", queue.routeID)
        if not ok then
            SWInfil.RestoreStagedPlayer(ply)
        end
    end
end

function SWInfil.StagePlayerForSkybox(ply, route, model, reason, routeID)
    if not IsValid(ply) or not ply:Alive() then return false end

    local duration = math.max(cvSkyboxTime:GetFloat(), 0)
    if duration <= 0 then return false end

    routeID = SWInfil.NormalizeRouteID(routeID or route.id or "main")
    SWInfil.SkyboxQueues = SWInfil.SkyboxQueues or {}

    local queue = SWInfil.SkyboxQueues[routeID]
    if not queue then
        local skyFlight = SWInfil.ResolveSkyboxFlight(route)

        queue = {
            routeID = routeID,
            players = {},
            started = CurTime(),
            duration = duration,
            model = model,
            entryPos = route.start.pos,
            entryAng = route.start.ang or angle_zero,
            skyStartPos = skyFlight.start.pos,
            skyStartAng = skyFlight.start.ang or angle_zero,
            skyMidPos = skyFlight.mid.pos,
            skyMidAng = skyFlight.mid.ang or skyFlight.start.ang or angle_zero,
            skyFinishPos = skyFlight.finish.pos,
            skyFinishAng = skyFlight.finish.ang or route.start.ang or angle_zero,
            customSkybox = skyFlight.custom == true
        }

        SWInfil.SkyboxQueues[routeID] = queue
        SWInfil.SkyboxQueue = queue

        timer.Create("SWInfil_SkyboxComplete_" .. routeID, duration, 1, function()
            SWInfil.CompleteSkyboxQueue(routeID)
        end)
    end

    if queue.players[ply] then
        SWInfil.SendSkyboxVisual(ply, queue)
        return true
    end

    ply.SWInfilPendingRestore = ply.SWInfilPendingRestore or SWInfil.BuildPlayerRestore(ply)
    ply.SWInfilSkyboxQueued = true
    ply.SWInfilSkyboxRouteID = routeID
    ply.SWInfilPendingRouteID = routeID
    queue.players[ply] = true

    ply:SetNWBool("SWInfilSkyboxWaiting", true)
    ply:SetNWBool("SWInfilChoosingSpawn", false)
    ply:SetNoDraw(true)

    if ply.SetNotSolid then
        ply:SetNotSolid(true)
    end

    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    ply:SetMoveType(MOVETYPE_NONE)
    ply:SetLocalVelocity(vector_origin)

    if ply.SWInfilPendingRestore.godEnabledByInfil and ply.GodEnable then
        ply:GodEnable()
    end

    SWInfil.SendSkyboxVisual(ply, queue)
    hook.Run("SWInfilSkyboxQueued", ply, reason or "spawn")

    return true
end

function SWInfil.GetSeatPreview()
    if IsValid(SWInfil.SeatPreview) then
        return SWInfil.SeatPreview
    end
end

function SWInfil.CloseSeatPreview(ply)
    local preview = SWInfil.GetSeatPreview()
    if IsValid(preview) then
        preview:Remove()
    end

    SWInfil.SeatPreview = nil
    SetGlobalEntity("SWInfilSeatPreview", NULL)
    SWInfil.Message(ply, "Removed the LAAT seat preview.")
end

function SWInfil.SpawnSeatPreview(pos, ang, ply)
    local model = cvModel:GetString()
    if model == "" then model = SWInfil.DefaultModel end

    if not util.IsValidModel(model) then
        SWInfil.Message(ply, "Could not spawn preview. Missing model: " .. model, true)
        return
    end

    local oldPreview = SWInfil.GetSeatPreview()
    if IsValid(oldPreview) then
        oldPreview:Remove()
    end

    local preview = ents.Create("sw_infil_laat_preview")
    if not IsValid(preview) then
        SWInfil.Message(ply, "Could not create the LAAT preview entity.", true)
        return
    end

    preview:SetVehicleModel(model)
    preview:SetPos(pos)
    preview:SetAngles(Angle(0, ang.y, 0))
    preview:Spawn()
    preview:Activate()

    SWInfil.SeatPreview = preview
    SetGlobalEntity("SWInfilSeatPreview", preview)
    SWInfil.PublishSeats()
    SWInfil.Message(ply, "Spawned LAAT seat preview. Right-click while standing where a passenger ghost should be.")

    return preview
end

function SWInfil.AddSeatFromPlayer(ply)
    if not isAdmin(ply) or not IsValid(ply) then return false end

    local preview = SWInfil.GetSeatPreview()
    if not IsValid(preview) then
        SWInfil.Message(ply, "Spawn the LAAT seat preview first with the Seat Editor tool.", true)
        return false
    end

    if #(SWInfil.Seats or {}) >= 63 then
        SWInfil.Message(ply, "Seat limit reached. Remove a seat before adding more.", true)
        return false
    end

    local localPos, localAng = WorldToLocal(
        ply:GetPos(),
        Angle(0, ply:EyeAngles().y, 0),
        preview:GetPos(),
        preview:GetAngles()
    )

    SWInfil.Seats = SWInfil.Seats or {}
    SWInfil.Seats[#SWInfil.Seats + 1] = {
        pos = localPos,
        ang = Angle(0, localAng.y, 0)
    }

    SWInfil.SaveSeats()
    SWInfil.Message(ply, "Added seat " .. #SWInfil.Seats .. " from your current position.")

    return true
end

function SWInfil.RemoveNearestSeat(ply)
    if not isAdmin(ply) or not IsValid(ply) then return false end

    local seats = SWInfil.Seats or {}
    if #seats <= 0 then
        SWInfil.Message(ply, "There are no seats to remove.", true)
        return false
    end

    local preview = SWInfil.GetSeatPreview()
    if not IsValid(preview) then
        SWInfil.Message(ply, "Spawn the LAAT seat preview first so I can find the nearest seat ghost.", true)
        return false
    end

    local comparePos = WorldToLocal(ply:GetPos(), angle_zero, preview:GetPos(), preview:GetAngles())

    local bestIndex
    local bestDistance

    for index, seat in ipairs(seats) do
        local distance = seat.pos:DistToSqr(comparePos)
        if not bestDistance or distance < bestDistance then
            bestIndex = index
            bestDistance = distance
        end
    end

    if not bestIndex then return false end

    table.remove(SWInfil.Seats, bestIndex)
    SWInfil.SaveSeats()
    SWInfil.Message(ply, "Removed seat " .. bestIndex .. ".")

    return true
end

function SWInfil.ClearSeats(ply)
    SWInfil.Seats = {}
    SWInfil.SaveSeats()
    SWInfil.Message(ply, "Cleared all custom LAAT seats. Add new seats or restore defaults before testing.", true)
end

function SWInfil.RestoreDefaultSeats(ply)
    SWInfil.Seats = SWInfil.CopyDefaultSeats()
    SWInfil.SaveSeats()
    SWInfil.Message(ply, "Restored the default LVS LAAT passenger seats.")
end

local function preferredReleaseSigns(ent, ply)
    local mode = string.lower(cvReleaseSide:GetString() or "auto")
    if mode == "left" then return { 1, -1 } end
    if mode == "right" then return { -1, 1 } end

    local seat = SWInfil.GetSeat(IsValid(ply) and ply.SWInfilSeat or (IsValid(ent) and ent:GetSeatNumber() or 1))
    local sign = seat.pos.y >= 0 and 1 or -1
    return { sign, -sign }
end

function SWInfil.FindSafeExit(ent, ply)
    local landPos = IsValid(ent) and ent:GetRouteLand() or ply:GetPos()
    local landAng = IsValid(ent) and ent:GetRouteLandAngle() or Angle(0, ply:EyeAngles().y, 0)
    local mins = IsValid(ply) and ply:OBBMins() or Vector(-16, -16, 0)
    local maxs = IsValid(ply) and ply:OBBMaxs() or Vector(16, 16, 72)
    local signs = preferredReleaseSigns(ent, ply)
    local xOffsets = { -80, -40, 0, 40, 80 }
    local yOffsets = { 190, 150, 115 }

    for _, sign in ipairs(signs) do
        for _, y in ipairs(yOffsets) do
            for _, x in ipairs(xOffsets) do
                local sample = LocalToWorld(Vector(x, sign * y, 150), angle_zero, landPos, landAng)
                local ground = util.TraceLine({
                    start = sample,
                    endpos = sample - Vector(0, 0, 520),
                    filter = { ply, ent },
                    mask = MASK_PLAYERSOLID
                })

                if ground.Hit then
                    local stand = ground.HitPos + Vector(0, 0, 4)
                    local hull = util.TraceHull({
                        start = stand,
                        endpos = stand + Vector(0, 0, 2),
                        mins = mins,
                        maxs = maxs,
                        filter = { ply, ent },
                        mask = MASK_PLAYERSOLID
                    })

                    if not hull.Hit then
                        return stand
                    end
                end
            end
        end
    end

    return landPos + Vector(0, 0, 64)
end

function SWInfil.CapturePlayer(ply, ent, seat)
    if not IsValid(ply) or not IsValid(ent) then return false end

    seat = SWInfil.AddVehicleOccupant(ent, ply, seat)
    if not seat then
        SWInfil.Message(ply, "No open LAAT seats were available.", true)
        return false
    end

    local restore = ply.SWInfilPendingRestore or SWInfil.BuildPlayerRestore(ply)
    ply.SWInfilPendingRestore = nil
    ply.SWInfilSkyboxQueued = nil
    ply.SWInfilPendingRouteID = nil
    ply.SWInfilChoosingSpawn = nil

    ply.SWInfilRestore = restore
    ply.SWInfilVehicle = ent
    ply:SetNWInt("SWInfilSeat", seat)
    ply:SetNWBool("SWInfilActive", true)
    ply:SetNWBool("SWInfilSkyboxWaiting", false)
    ply:SetNWBool("SWInfilChoosingSpawn", false)
    ply:SetNWEntity("SWInfilVehicle", ent)
    ply:SetNoDraw(true)

    if ply.SetNotSolid then
        ply:SetNotSolid(true)
    end

    ply:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    ply:SetMoveType(MOVETYPE_NONE)
    ply:SetLocalVelocity(vector_origin)
    ply:SetPos(SWInfil.GetRideAnchor(ent, CurTime(), seat, SWInfil.GetServerRideAnchorOffset()))

    if restore.godEnabledByInfil and ply.GodEnable then
        ply:GodEnable()
    end

    net.Start("sw_infil_begin")
        net.WriteEntity(ent)
        net.WriteUInt(math.Clamp(seat or 1, 1, #SWInfil.Seats), 6)
    net.Send(ply)

    return true
end

function SWInfil.ReleasePlayer(ply, ent, emergency)
    if not IsValid(ply) then return false end

    local restore = ply.SWInfilRestore or {}
    local vehicle = IsValid(ent) and ent or ply.SWInfilVehicle

    if ply:Alive() and IsValid(vehicle) and not emergency then
        ply:SetPos(SWInfil.FindSafeExit(vehicle, ply))
        ply:SetEyeAngles(Angle(0, vehicle:GetRouteLandAngle().y, 0))
    end

    if IsValid(vehicle) then
        SWInfil.RemoveVehicleOccupant(vehicle, ply)
    end

    ply:SetNWBool("SWInfilActive", false)
    ply:SetNWBool("SWInfilChoosingSpawn", false)
    ply:SetNWInt("SWInfilSeat", 0)
    ply:SetNWEntity("SWInfilVehicle", NULL)
    ply:SetNoDraw(restore.noDraw == true)

    if ply.SetNotSolid then
        ply:SetNotSolid(restore.notSolid == true)
    end

    ply:SetCollisionGroup(restore.collisionGroup or COLLISION_GROUP_PLAYER)

    if ply:Alive() then
        ply:SetMoveType(restore.moveType or MOVETYPE_WALK)
        ply:SetLocalVelocity(vector_origin)
    end

    if ply.UnLock then
        ply:UnLock()
    end

    if restore.godEnabledByInfil and ply.GodDisable then
        ply:GodDisable()
    end

    ply.SWInfilRestore = nil
    ply.SWInfilVehicle = nil
    ply.SWInfilSeat = nil
    ply.SWInfilPendingRouteID = nil
    ply.SWInfilChoosingSpawn = nil

    net.Start("sw_infil_end")
    net.Send(ply)

    hook.Run("SWInfilFinished", ply, vehicle, emergency == true)
    return true
end

function SWInfil.StartForPlayer(ply, reason, routeID)
    if not cvEnabled:GetBool() then return false, "disabled" end
    if not IsValid(ply) or not ply:Alive() then return false, "not_alive" end
    if IsValid(ply.SWInfilVehicle) or ply:GetNWBool("SWInfilActive") then return false, "already_active" end

    local route, resolvedRouteID = SWInfil.GetRoute(routeID or ply.SWInfilPendingRouteID)
    if not route then
        if reason ~= "spawn" then
            tellSetupProblem(ply, "No LAAT route is saved yet. Use the Star Wars RP > LAAT Infil Route tool first.")
        end

        return false, "no_route"
    end

    local model = cvModel:GetString()
    if model == "" then model = SWInfil.DefaultModel end

    if not util.IsValidModel(model) then
        tellSetupProblem(ply, "The LAAT model was not found: " .. model .. ". Install the LAAT/LVS content or set sw_infil_model.")
        return false, "bad_model"
    end

    ply:SetNWBool("SWInfilChoosingSpawn", false)
    ply.SWInfilChoosingSpawn = nil
    ply.SWInfilPendingRouteID = resolvedRouteID

    local joinable = SWInfil.FindJoinableLAAT(resolvedRouteID)
    if IsValid(joinable) then
        local seat = SWInfil.FindOpenSeat(joinable)
        if seat and SWInfil.CapturePlayer(ply, joinable, seat) then
            hook.Run("SWInfilStarted", ply, joinable, reason or "shared")
            return true, joinable
        end
    end

    if reason ~= "skybox_complete" and cvSkyboxEnabled:GetBool() and cvSkyboxTime:GetFloat() > 0 then
        local queued = SWInfil.StagePlayerForSkybox(ply, route, model, reason, resolvedRouteID)
        if queued then
            return true, "skybox_wait"
        end
    end

    local ent = ents.Create("sw_infil_laat")
    if not IsValid(ent) then
        tellSetupProblem(ply, "Could not create the LAAT infiltration entity.")
        return false, "entity_failed"
    end

    local landAng = route.land.ang or angle_zero
    local departPos = route.land.pos
        + landAng:Forward() * cvDepartureDistance:GetFloat()
        + Vector(0, 0, cvDepartureHeight:GetFloat())

    ent:SetVehicleModel(model)
    ent.SWInfilRouteID = resolvedRouteID
    ent.SWInfilRouteName = route.name or resolvedRouteID
    ent:SetRouteStart(route.start.pos)
    ent:SetRouteLand(route.land.pos)
    ent:SetRouteDepart(departPos)
    ent:SetRouteStartAngle(route.start.ang or angle_zero)
    ent:SetRouteLandAngle(landAng)
    ent:SetApproachDuration(cvApproach:GetFloat())
    ent:SetHoldDuration(cvGround:GetFloat())
    ent:SetDepartureDuration(cvDeparture:GetFloat())
    ent:SetSequenceStarted(CurTime() + 0.05)
    ent:SetDoorsOpen(false)
    ent:SetSeatNumber(1)
    ent:SetOccupant(NULL)
    ent:SetPos(route.start.pos)
    ent:SetAngles(route.start.ang or angle_zero)
    ent:Spawn()
    ent:Activate()
    ent:SetSkin(math.max(cvSkin:GetInt(), 0))

    local seat = SWInfil.FindOpenSeat(ent)
    if not SWInfil.CapturePlayer(ply, ent, seat) then
        ent:Remove()
        return false, "capture_failed"
    end

    hook.Run("SWInfilStarted", ply, ent, reason or "manual")

    return true, ent
end

net.Receive("sw_infil_skip", function(_, ply)
    if not cvAllowSkip:GetBool() then return end
    if not IsValid(ply) or not ply:GetNWBool("SWInfilActive") then return end

    local ent = ply.SWInfilVehicle
    if not IsValid(ent) then
        SWInfil.ReleasePlayer(ply, nil, true)
        return
    end

    ent:OpenDoors()
    SWInfil.ReleasePlayer(ply, ent, false)

    if SWInfil.GetVehicleOccupantCount(ent) <= 0 then
        ent:SetSequenceStarted(CurTime() - ent:GetApproachDuration() - ent:GetHoldDuration())
    end
end)

hook.Add("Initialize", "SWInfil_LoadRoute", function()
    timer.Simple(0, function()
        SWInfil.LoadRoute()
        SWInfil.LoadSeats()
        SWInfil.LoadSkyboxRoute()
    end)
end)

hook.Add("PlayerInitialSpawn", "SWInfil_SendSeatLayout", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then
            SWInfil.PublishSeats(ply)
            SWInfil.PublishSpawnRoutes(ply)
        end
    end)
end)

hook.Add("PlayerSpawn", "SWInfil_OnSpawn", function(ply)
    ply.SWInfilSpawnSerial = (ply.SWInfilSpawnSerial or 0) + 1
    local serial = ply.SWInfilSpawnSerial

    timer.Simple(cvSpawnDelay:GetFloat(), function()
        if not IsValid(ply) then return end
        if ply.SWInfilSpawnSerial ~= serial then return end
        if not cvOnSpawn:GetBool() then return end
        if not ply:Alive() then return end

        if cvSpawnMenu:GetBool() and SWInfil.HasAnyReadyRoute() then
            SWInfil.StagePlayerForSpawnMenu(ply)
            return
        end

        SWInfil.StartForPlayer(ply, "spawn")
    end)
end)

hook.Add("PlayerDeath", "SWInfil_DeathCleanup", function(ply)
    if ply:GetNWBool("SWInfilActive") then
        SWInfil.ReleasePlayer(ply, ply.SWInfilVehicle, true)
    end

    if ply:GetNWBool("SWInfilSkyboxWaiting") then
        SWInfil.UnstagePlayer(ply, true)
    end

    if ply:GetNWBool("SWInfilChoosingSpawn") then
        SWInfil.RestoreStagedPlayer(ply)
    end
end)

hook.Add("PlayerDisconnected", "SWInfil_DisconnectCleanup", function(ply)
    if ply:GetNWBool("SWInfilActive") then
        SWInfil.ReleasePlayer(ply, ply.SWInfilVehicle, true)
    end

    if ply:GetNWBool("SWInfilSkyboxWaiting") then
        SWInfil.UnstagePlayer(ply, false)
    end

    if ply:GetNWBool("SWInfilChoosingSpawn") then
        SWInfil.RestoreStagedPlayer(ply)
    end
end)

hook.Add("StartCommand", "SWInfil_BlockInput", function(ply, cmd)
    if not ply:GetNWBool("SWInfilActive") and not ply:GetNWBool("SWInfilSkyboxWaiting") and not ply:GetNWBool("SWInfilChoosingSpawn") then return end

    cmd:ClearMovement()
    cmd:ClearButtons()
end)

net.Receive("sw_infil_spawn_select", function(_, ply)
    if not IsValid(ply) or not ply:Alive() then return end

    local rawRouteID = string.Trim(net.ReadString() or "")

    if rawRouteID == "" or string.lower(rawRouteID) == "cancel" then
        SWInfil.RestoreStagedPlayer(ply)
        return
    end

    if not ply:GetNWBool("SWInfilChoosingSpawn") and not isAdmin(ply) then return end

    local routeID = SWInfil.NormalizeRouteID(rawRouteID)
    local ok = SWInfil.StartForPlayer(ply, "spawn_menu", routeID)
    if not ok then
        SWInfil.RestoreStagedPlayer(ply)
    end
end)

local function findPlayerByName(text)
    if not text or text == "" then return nil end

    local needle = string.lower(text)
    for _, target in ipairs(player.GetHumans()) do
        if string.find(string.lower(target:Nick()), needle, 1, true) then
            return target
        end
    end
end

concommand.Add("sw_infil_seats_preview_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end

    local trace = ply:GetEyeTrace()
    local basePos = trace.Hit and trace.HitPos or (ply:GetPos() + ply:EyeAngles():Forward() * 300)
    local pos = basePos + Vector(0, 0, cvSeatPreviewHeight:GetFloat())
    SWInfil.SpawnSeatPreview(pos, Angle(0, ply:EyeAngles().y, 0), ply)
end)

concommand.Add("sw_infil_seats_add_here", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.AddSeatFromPlayer(ply)
end)

concommand.Add("sw_infil_seats_remove_nearest", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.RemoveNearestSeat(ply)
end)

concommand.Add("sw_infil_seats_clear", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.ClearSeats(ply)
end)

concommand.Add("sw_infil_seats_defaults", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.RestoreDefaultSeats(ply)
end)

concommand.Add("sw_infil_seats_close_preview", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.CloseSeatPreview(ply)
end)

concommand.Add("sw_infil_seats_status", function(ply)
    if not isAdmin(ply) then return end

    local preview = SWInfil.GetSeatPreview()
    local text = "Seats: " .. #(SWInfil.Seats or {}) .. " | Preview: " .. tostring(IsValid(preview))
    SWInfil.Message(ply, text, true)
end)

local function skyboxEyePoint(ply)
    return ply:EyePos() + Vector(0, 0, cvSkyboxEditorHeight:GetFloat())
end

concommand.Add("sw_infil_skybox_start_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end
    SWInfil.SetSkyboxPoint("start", skyboxEyePoint(ply), Angle(0, ply:EyeAngles().y, 0), ply)
end)

concommand.Add("sw_infil_skybox_mid_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end
    SWInfil.SetSkyboxPoint("mid", skyboxEyePoint(ply), Angle(0, ply:EyeAngles().y, 0), ply)
end)

concommand.Add("sw_infil_skybox_finish_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end
    SWInfil.SetSkyboxPoint("finish", skyboxEyePoint(ply), Angle(0, ply:EyeAngles().y, 0), ply)
end)

concommand.Add("sw_infil_skybox_clear", function(ply)
    if not isAdmin(ply) then return end
    SWInfil.ClearSkyboxRoute(ply)
end)

concommand.Add("sw_infil_skybox_status", function(ply)
    if not isAdmin(ply) then return end

    local routeText = SWInfil.SkyboxRouteIsReady() and "custom route ready" or "using automatic skybox route"
    SWInfil.Message(ply, "Skybox flight: " .. routeText .. " | Time: " .. cvSkyboxTime:GetFloat() .. "s | Bank: " .. cvFlightBankStrength:GetFloat(), true)
end)

concommand.Add("sw_infil_test", function(ply, _, args)
    if not isAdmin(ply) then return end

    local target = IsValid(ply) and ply or nil
    if args and args[1] then
        target = findPlayerByName(table.concat(args, " ")) or target
    end

    if not IsValid(target) then
        target = player.GetHumans()[1]
    end

    if IsValid(target) then
        SWInfil.StartForPlayer(target, "manual")
    else
        SWInfil.Message(ply, "No player found to test on.", true)
    end
end)

concommand.Add("sw_infil_play_all", function(ply)
    if not isAdmin(ply) then return end

    local count = 0
    for _, target in ipairs(player.GetHumans()) do
        if target:Alive() then
            local ok = SWInfil.StartForPlayer(target, "manual_all")
            if ok then count = count + 1 end
        end
    end

    SWInfil.Message(ply, "Started LAAT infiltration for " .. count .. " player(s).", true)
end)

local function routeToolInfo(ply)
    if not IsValid(ply) then return "main", "Main Landing Zone" end

    local routeID = ply:GetInfo("sw_infil_route_route_id")
    local routeName = ply:GetInfo("sw_infil_route_route_name")
    return routeID, routeName
end

concommand.Add("sw_infil_route_start_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end

    local routeID, routeName = routeToolInfo(ply)
    SWInfil.SetRoutePoint("start", ply:GetPos() + Vector(0, 0, 80), Angle(0, ply:EyeAngles().y, 0), ply, routeID, routeName)
end)

concommand.Add("sw_infil_route_land_here", function(ply)
    if not isAdmin(ply) or not IsValid(ply) then return end

    local trace = ply:GetEyeTrace()
    local pos = (trace.Hit and trace.HitPos or ply:GetPos()) + Vector(0, 0, cvHover:GetFloat())
    local routeID, routeName = routeToolInfo(ply)
    SWInfil.SetRoutePoint("land", pos, Angle(0, ply:EyeAngles().y, 0), ply, routeID, routeName)
end)

concommand.Add("sw_infil_route_clear", function(ply)
    if not isAdmin(ply) then return end
    local routeID = routeToolInfo(ply)
    SWInfil.ClearRoute(ply, routeID)
end)

concommand.Add("sw_infil_status", function(ply)
    if not isAdmin(ply) then return end

    local readyRoutes = SWInfil.GetReadyRoutes()
    local routeText = #readyRoutes .. " ready spawn(s)"
    local model = cvModel:GetString() ~= "" and cvModel:GetString() or SWInfil.DefaultModel
    SWInfil.Message(ply, "Routes: " .. routeText .. " | Seats: " .. #(SWInfil.Seats or {}) .. " | Spawn menu: " .. tostring(cvSpawnMenu:GetBool()) .. " | Turrets: " .. tostring(cvTurretsEnabled:GetBool()) .. " | Model: " .. model .. " | On spawn: " .. tostring(cvOnSpawn:GetBool()), true)
end)

concommand.Add("sw_infil_turret_list_attachments", function(ply)
    if not isAdmin(ply) then return end

    local target
    if IsValid(ply) then
        local trace = ply:GetEyeTrace()
        if trace and IsValid(trace.Entity) then
            target = trace.Entity
        end
    end

    local temporary = false
    if not IsValid(target) then
        local model = cvModel:GetString() ~= "" and cvModel:GetString() or SWInfil.DefaultModel
        if not util.IsValidModel(model) then
            SWInfil.Message(ply, "Cannot list attachments because the LAAT model is invalid: " .. model, true)
            return
        end

        target = ents.Create("prop_dynamic")
        if not IsValid(target) then
            SWInfil.Message(ply, "Could not create temporary LAAT model for attachment listing.", true)
            return
        end

        target:SetModel(model)
        target:SetPos(IsValid(ply) and ply:GetPos() + Vector(0, 0, 80) or vector_origin)
        target:Spawn()
        temporary = true
    end

    local attachments = target.GetAttachments and target:GetAttachments() or {}
    if #attachments <= 0 then
        SWInfil.Message(ply, "No attachments found on " .. tostring(target:GetModel()) .. ".", true)
    else
        SWInfil.Message(ply, "Attachments for " .. tostring(target:GetModel()) .. " printed to console.", true)
        for _, attachment in ipairs(attachments) do
            local line = tostring(attachment.id) .. " = " .. tostring(attachment.name)
            if IsValid(ply) then
                ply:PrintMessage(HUD_PRINTCONSOLE, "[LAAT Infil] " .. line)
            else
                print("[LAAT Infil] " .. line)
            end
        end
    end

    if temporary and IsValid(target) then
        target:Remove()
    end
end)

timer.Simple(0, function()
    SWInfil.LoadRoute()
    SWInfil.LoadSeats()
    SWInfil.LoadSkyboxRoute()
end)
