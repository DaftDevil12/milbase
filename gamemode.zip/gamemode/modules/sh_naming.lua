--[[
	MilBase automatic Star Wars RP naming.

	Display format:
	  FACTION RANK [MEDIC] NUMBER NAME
	Example:
	  501st PVT JM 0989 Bob

	The player's chosen name stays stored as the simple personal name ("Bob").
	The clone number is generated once, saved permanently, and shown whenever
	MilBase displays MBName().
]]

local cfg = MilBase.Config
cfg.NamingEnabled = cfg.NamingEnabled ~= false

MilBase.Naming = MilBase.Naming or {}

local function trim(s)
	return string.Trim(tostring(s or ""))
end

local function lower(s)
	return string.lower(tostring(s or ""))
end

local function listHas(list, needle)
	needle = lower(needle)
	for _, v in ipairs(list or {}) do
		if lower(v) == needle then return true end
	end
	return false
end

local function abbrevFromWords(text)
	text = trim(text)
	if text == "" then return "" end
	local out = ""
	for word in string.gmatch(text, "[%w]+") do
		out = out .. string.sub(word, 1, 1)
	end
	if out == "" then out = string.sub(text, 1, 4) end
	return string.upper(out)
end

function MilBase.NamingFactionShort(faction)
	if not faction then return "UNK" end
	local map = cfg.NamingFactionShort or {}
	return map[faction.id] or map[faction.name] or map[lower(faction.id or "")]
		or map[lower(faction.name or "")] or abbrevFromWords(faction.name or faction.id or "UNK")
end

function MilBase.NamingRankShort(rank)
	if not rank then return "TRP" end
	if rank.short or rank.abbrev then return string.upper(rank.short or rank.abbrev) end
	local map = cfg.NamingRankShort or {}
	return map[rank.name] or map[lower(rank.name or "")] or abbrevFromWords(rank.name or "TRP")
end

function MilBase.NamingMedicRankDef(id)
	if not id or id == "" then return nil end
	local ranks = cfg.NamingMedicRanks or {}
	return ranks[id]
end

function MilBase.NamingIsMedic(ply)
	if not IsValid(ply) or not ply.MBCertList then return false end

	local explicit = cfg.NamingMedicCerts or {}
	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs and MilBase.Certs[certID]
		if explicit[certID] or (cert and cert.medic) then return true end
	end

	local faction = ply.MBFaction and ply:MBFaction() or nil
	local rank = ply.MBRank and ply:MBRank() or nil
	return (faction and faction.medic) or (rank and rank.medic) or false
end

function MilBase.NamingMedicShort(ply)
	if not IsValid(ply) then return "" end
	if not MilBase.NamingIsMedic(ply) and not cfg.NamingShowMedicRankWithoutCert then return "" end

	local rankID = ply:GetNWString("mb_medic_rank", "")
	if rankID == "" then rankID = cfg.NamingMedicDefaultRank or "junior_medic" end

	local def = MilBase.NamingMedicRankDef(rankID)
	return def and string.upper(def.short or def.abbrev or abbrevFromWords(def.name or rankID)) or "JM"
end

function MilBase.NamingCleanBaseName(raw)
	local name = trim(raw)

	-- If somebody pastes a full formatted name such as "501st PVT 0989 Bob"
	-- or an old clone tag such as "CT-7567 Rex", keep only the personal name.
	local _, afterNumber = string.match(name, "^.-(%d%d%d%d)%s+(.+)$")
	if afterNumber then name = trim(afterNumber) end

	-- Keep RP names readable and stop players from storing colour/control junk.
	name = string.gsub(name, "[%c]", "")
	name = string.gsub(name, "%s+", " ")
	return trim(name)
end

function MilBase.FormatRPName(ply, rawName)
	if not cfg.NamingEnabled or not IsValid(ply) then
		return rawName or (IsValid(ply) and ply:GetNWString("mb_name", "")) or ""
	end

	local base = MilBase.NamingCleanBaseName(rawName or ply:GetNWString("mb_name", ""))
	if base == "" then base = ply:Nick() or "Trooper" end

	local faction = ply.MBFaction and ply:MBFaction() or nil
	local rank = ply.MBRank and ply:MBRank() or nil
	local factionShort = MilBase.NamingFactionShort(faction)
	local rankShort = MilBase.NamingRankShort(rank)
	local medicShort = MilBase.NamingMedicShort(ply)
	local number = ply:GetNWString("mb_clone_number", "")
	if number == "" then number = cfg.NamingPendingNumber or "0000" end

	local parts = { factionShort, rankShort }
	if medicShort ~= "" then parts[#parts + 1] = medicShort end
	parts[#parts + 1] = number
	parts[#parts + 1] = base

	return table.concat(parts, " ")
end

function MilBase.GetRawRPName(ply)
	if not IsValid(ply) then return "" end
	local name = MilBase.NamingCleanBaseName(ply:GetNWString("mb_name", ""))
	return name ~= "" and name or ply:Nick()
end

local PLAYER = FindMetaTable("Player")

function PLAYER:MBRawName()
	return MilBase.GetRawRPName(self)
end

function PLAYER:MBCloneNumber()
	return self:GetNWString("mb_clone_number", "")
end

function PLAYER:MBMedicRankID()
	return self:GetNWString("mb_medic_rank", "")
end

function PLAYER:MBMedicRank()
	return MilBase.NamingMedicRankDef(self:MBMedicRankID())
end

if SERVER then
	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_name_data (
		steamid VARCHAR(32) PRIMARY KEY,
		clone_number VARCHAR(8),
		medic_rank VARCHAR(64)
	)]])

	local function saveNameData(ply)
		if not IsValid(ply) then return end
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_name_data (steamid, clone_number, medic_rank) VALUES (%s, %s, %s)",
			MilBase.SQLStr(ply:MBCharacterKey()),
			MilBase.SQLStr(ply:GetNWString("mb_clone_number", "")),
			MilBase.SQLStr(ply:GetNWString("mb_medic_rank", ""))
		))
	end
	MilBase.SaveNameData = saveNameData

	local function validNumber(n)
		return isstring(n) and string.match(n, "^%d%d%d%d$") ~= nil
	end

	local function generateNumber(cb, attempts)
		attempts = attempts or 0
		if attempts > 80 then
			-- Extremely unlikely unless the table is nearly full; still return a
			-- deterministic four-digit fallback instead of blocking the player.
			cb(string.format("%04d", math.random(0, 9999)))
			return
		end

		local n = string.format("%04d", math.random(0, 9999))
		MilBase.DB.Query("SELECT steamid FROM frontier_name_data WHERE clone_number = " .. MilBase.SQLStr(n) .. " LIMIT 1", function(rows)
			if rows and rows[1] then
				generateNumber(cb, attempts + 1)
			else
				cb(n)
			end
		end, function()
			cb(n)
		end)
	end

	function MilBase.LoadNameData(ply)
		if not IsValid(ply) then return end
		local key = ply:MBCharacterKey()
		local token = ply:MBCharacterLoadToken()
		MilBase.DB.Query("SELECT * FROM frontier_name_data WHERE steamid = " .. MilBase.SQLStr(key), function(rows)
			if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			local row = rows and rows[1]
			local number = row and tostring(row.clone_number or "") or ""
			local medicRank = row and tostring(row.medic_rank or "") or ""

			if validNumber(number) then
				ply:SetNWString("mb_clone_number", number)
				ply:SetNWString("mb_medic_rank", medicRank)
				return
			end

			generateNumber(function(newNumber)
				if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
				ply:SetNWString("mb_clone_number", newNumber)
				ply:SetNWString("mb_medic_rank", medicRank)
				saveNameData(ply)
			end)
		end)
	end

	function MilBase.SetCloneNumber(actor, target, number)
		if not IsValid(target) then return false, "Player not found." end
		number = tostring(number or "")
		if not validNumber(number) then return false, "Clone numbers must be exactly four digits." end
		local level = IsValid(actor) and (actor.MBStaffLevel and actor:MBStaffLevel() or 0) or math.huge
		if IsValid(actor) and level < (cfg.NamingManageStaffLevel or 4) then
			return false, "You need staff level " .. tostring(cfg.NamingManageStaffLevel or 4) .. "+ to set clone numbers."
		end

		MilBase.DB.Query("SELECT steamid FROM frontier_name_data WHERE clone_number = " .. MilBase.SQLStr(number) .. " AND steamid <> " .. MilBase.SQLStr(target:MBCharacterKey()) .. " LIMIT 1", function(rows)
			if not IsValid(target) then return end
			if rows and rows[1] then
				if IsValid(actor) then MilBase.Notify(actor, "That clone number is already assigned.", "warn") end
				return
			end
			target:SetNWString("mb_clone_number", number)
			saveNameData(target)
			MilBase.ChatMsg(nil, Color(115, 190, 255), "[NAMING] ", color_white,
				target:MBRawName() .. " is now clone number " .. number .. ".")
		end)
		return true
	end

	function MilBase.SetMedicRank(actor, target, rankID)
		if not IsValid(target) then return false, "Player not found." end
		rankID = lower(rankID or "")
		if rankID == "none" or rankID == "clear" then rankID = "" end
		if rankID ~= "" and not MilBase.NamingMedicRankDef(rankID) then
			local valid = {}
			for id in pairs(cfg.NamingMedicRanks or {}) do valid[#valid + 1] = id end
			table.sort(valid)
			return false, "Unknown medic rank. Valid: " .. table.concat(valid, ", ")
		end

		local allowed = not IsValid(actor)
		if IsValid(actor) then
			allowed = (actor.MBStaffLevel and actor:MBStaffLevel() >= (cfg.NamingMedicRankStaffLevel or 3))
				or (MilBase.CanManage and MilBase.CanManage(actor, target))
		end
		if not allowed then return false, "Only staff or the soldier's superiors can manage medic ranks." end

		target:SetNWString("mb_medic_rank", rankID)
		saveNameData(target)

		local def = MilBase.NamingMedicRankDef(rankID)
		MilBase.Notify(target, rankID ~= "" and ("Your medic rank is now " .. (def.name or rankID) .. ".") or "Your medic rank was cleared.")
		if IsValid(actor) then MilBase.Notify(actor, "Updated medic rank for " .. target:MBName() .. ".") end
		return true
	end

	hook.Add("PlayerInitialSpawn", "MilBase.NamingLoad", function(ply)
		MilBase.LoadNameData(ply)
	end)

	-- Keep stored names as personal names only; formatted name is generated.
	hook.Add("MilBase.PlayerLoaded", "MilBase.NamingCleanStoredName", function(ply)
		local clean = MilBase.NamingCleanBaseName(ply:GetNWString("mb_name", ""))
		if clean ~= ply:GetNWString("mb_name", "") then
			ply:SetNWString("mb_name", clean)
			MilBase.SavePlayer(ply)
		end
	end)

	MilBase.RegisterChatCommand("setclonenumber", {
		help = "Set a player's permanent clone number: /setclonenumber <player> <0000-9999> (staff)",
		func = function(ply, args)
			local target = MilBase.FindPlayer(args[1])
			local ok, err = MilBase.SetCloneNumber(ply, target, args[2])
			if not ok then MilBase.Notify(ply, err, "warn") end
		end,
	})

	MilBase.RegisterChatCommand("setmedicrank", {
		help = "Set medic name rank: /setmedicrank <player> <junior_medic|medic|senior_medic|chief_medic>",
		func = function(ply, args)
			local targetName = table.remove(args, 1)
			local target = MilBase.FindPlayer(targetName)
			local rankID = table.concat(args, "_")
			local ok, err = MilBase.SetMedicRank(ply, target, rankID)
			if not ok then MilBase.Notify(ply, err, "warn") end
		end,
	})

	MilBase.RegisterChatCommand("clearmedicrank", {
		help = "Clear medic name rank: /clearmedicrank <player>",
		func = function(ply, args)
			local target = MilBase.FindPlayer(args[1])
			local ok, err = MilBase.SetMedicRank(ply, target, "")
			if not ok then MilBase.Notify(ply, err, "warn") end
		end,
	})
end
