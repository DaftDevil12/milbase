-- Galaxy Director hostile-ship shield/hull targeting HUD.

if not CLIENT or MilBase._GalaxyCombatClientLoaded then return end
MilBase._GalaxyCombatClientLoaded = true
if (MilBase.Config.GalaxyDirector or {}).CISSkyboxCombatEnabled == false then return end

local G = MilBase.Galaxy

local function bar(x, y, width, fraction, color)
	surface.SetDrawColor(255, 255, 255, 18)
	surface.DrawRect(x, y, width, 7)
	surface.SetDrawColor(color)
	surface.DrawRect(x, y, width * math.Clamp(fraction, 0, 1), 7)
end

local function combatTarget()
	local active = (G.ClientState or {}).active
	if active and tonumber(active.targetEntity) then
		local entity = Entity(tonumber(active.targetEntity))
		if IsValid(entity) and entity:GetClass() == "mb_galaxy_ship" then return entity end
	end
	local best, bestPriority
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if ship:GetHostile() and ship:GetMaxShield() > 0 and ship:GetHull() > 0 then
			local priority = (ship:GetCapital() and 1000000000 or 0)
				- EyePos():DistToSqr(ship:GetPos())
			if not bestPriority or priority > bestPriority then
				best, bestPriority = ship, priority
			end
		end
	end
	return best
end

hook.Add("HUDPaint", "MilBase.GalaxySkyboxCombatHUD", function()
	local ship = combatTarget()
	if not IsValid(ship) then return end
	local ui = MilBase.UI
	if not ui then return end
	local stage, stageLabel = G.DefenseStage(ship)
	local width, height = math.min(540, ScrW() * 0.43), 112
	local x, y = (ScrW() - width) * 0.5, 158
	local accent = stage == "retreat" and Color(95, 220, 135)
		or stage == "ingress" and Color(235, 175, 70)
		or stage == "shield" and Color(70, 185, 255) or ui.danger
	MilBase.DrawPanelBF2(x, y, width, height, {
		cut = 8,
		color = Color(4, 9, 16, 228),
		accent = accent,
	})
	draw.SimpleText(ship:GetShipName(), "MB.Small", x + 14, y + 9, ui.text)
	draw.SimpleText(stageLabel, "MB.Tiny", x + width - 14, y + 14,
		accent, TEXT_ALIGN_RIGHT)

	local rangeMetres = math.max(0, EyePos():Distance(ship:WorldSpaceCenter()) * 0.01905)
	draw.SimpleText(string.format("RANGE  %.0f m", rangeMetres), "MB.Tiny",
		x + 14, y + 33, ui.faint)
	draw.SimpleText("SHIELD  " .. ship:GetShield() .. " / " .. ship:GetMaxShield(),
		"MB.Tiny", x + 14, y + 53, ui.dim)
	bar(x + 150, y + 57, width - 166, ship:GetShieldFraction(),
		Color(70, 185, 255))
	draw.SimpleText("HULL  " .. ship:GetHull() .. " / " .. ship:GetMaxHull(),
		"MB.Tiny", x + 14, y + 78, ui.dim)
	bar(x + 150, y + 82, width - 166, ship:GetHullFraction(),
		ship:GetShield() > 0 and Color(115, 125, 138) or ui.danger)
	draw.SimpleText(ship:GetShield() > 0
			and "Maintain fire to prevent shield regeneration."
			or "Shield down. Hull damage cannot regenerate.",
		"MB.Tiny", x + 14, y + 98, ui.faint)
end)

hook.Add("HUDPaint", "MilBase.GalaxyCombatTargetMarker", function()
	local ship = combatTarget()
	if not IsValid(ship) then return end
	local screen = ship:WorldSpaceCenter():ToScreen()
	if not screen.visible then return end
	local color = ship:GetShield() > 0 and Color(75, 190, 255, 220)
		or Color(245, 70, 55, 230)
	local size = ship:GetCapital() and 34 or 24
	local arm = math.floor(size * 0.48)
	surface.SetDrawColor(color)
	surface.DrawLine(screen.x - size, screen.y - size,
		screen.x - size + arm, screen.y - size)
	surface.DrawLine(screen.x - size, screen.y - size,
		screen.x - size, screen.y - size + arm)
	surface.DrawLine(screen.x + size, screen.y - size,
		screen.x + size - arm, screen.y - size)
	surface.DrawLine(screen.x + size, screen.y - size,
		screen.x + size, screen.y - size + arm)
	surface.DrawLine(screen.x - size, screen.y + size,
		screen.x - size + arm, screen.y + size)
	surface.DrawLine(screen.x - size, screen.y + size,
		screen.x - size, screen.y + size - arm)
	surface.DrawLine(screen.x + size, screen.y + size,
		screen.x + size - arm, screen.y + size)
	surface.DrawLine(screen.x + size, screen.y + size,
		screen.x + size, screen.y + size - arm)
end)

hook.Remove("HUDPaint", "MilBase.GalaxyWeakpointMarkers")
