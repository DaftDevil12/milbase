if not SERVER or MilBase._CinematicDialogueServerLoaded then return end
MilBase._CinematicDialogueServerLoaded = true

MilBase.CinematicDialogue = MilBase.CinematicDialogue or {}
local D = MilBase.CinematicDialogue
D.NET_OPEN = D.NET_OPEN or "MilBase_CinematicDialogue_Open"
D.NET_ACTION = D.NET_ACTION or "MilBase_CinematicDialogue_Action"
D.NET_CLOSE = D.NET_CLOSE or "MilBase_CinematicDialogue_Close"

util.AddNetworkString(D.NET_OPEN)
util.AddNetworkString(D.NET_ACTION)
util.AddNetworkString(D.NET_CLOSE)

D.Sessions = D.Sessions or {}

local function clean(value, maximum)
	return string.sub(string.Trim(tostring(value or "")), 1, maximum or 260)
end

local function playerName(ply)
	return IsValid(ply) and tostring(ply.MBName and ply:MBName() or ply:Nick()) or "PLAYER"
end

local function speakerPosition(session)
	local data = session and session.data or {}
	if IsValid(data.speaker) then return data.speaker:WorldSpaceCenter() end
	if isvector(data.anchorPosition) then return data.anchorPosition end
	return IsValid(session and session.player) and session.player:GetPos() or vector_origin
end

local function inRange(session)
	local ply, data = session.player, session.data
	if not IsValid(ply) or not ply:Alive() then return false end
	if data.mode ~= "physical" then return true end
	if not IsValid(data.speaker) then return false end
	local maximum = math.max(96, tonumber(data.maxDistance) or 220)
	return ply:EyePos():DistToSqr(data.speaker:NearestPoint(ply:EyePos())) <= maximum * maximum
end

local function resolveLanguage(session)
	local languageID = clean(session.data.languageID or "basic", 48)
	local language = MilBase.GetLanguage and MilBase.GetLanguage(languageID) or nil
	if not language then languageID = "basic" language = MilBase.GetLanguage and MilBase.GetLanguage("basic") or {} end
	local understood, translator = true, nil
	if MilBase.ResolveLanguageForListener then
		understood, translator = MilBase.ResolveLanguageForListener(
			session.player, languageID, speakerPosition(session),
			tonumber(session.data.translatorRadius) or 340)
	end
	session.understood = understood == true
	session.translator = IsValid(translator) and translator or nil
	return languageID, language or {}, session.understood, session.translator
end

local function publicChoices(session)
	local choices = {}
	if not session.understood then
		choices[1] = { id = "retry_translation", label = "ASK A NEARBY TRANSLATOR TO INTERPRET" }
		choices[2] = { id = "close", label = "END CONVERSATION" }
		return choices
	end
	for _, row in ipairs(session.data.choices or {}) do
		local id = clean(row.id, 48)
		if id ~= "" then
			choices[#choices + 1] = {
				id = id,
				label = clean(row.label or id, 140),
				danger = row.danger == true,
				disabled = row.disabled == true,
				reason = clean(row.reason, 140),
			}
		end
	end
	choices[#choices + 1] = { id = "close", label = "END CONVERSATION" }
	return choices
end

local function writePayload(ply, payload)
	local compressed = util.Compress(util.TableToJSON(payload, false) or "{}")
	if not compressed then return end
	net.Start(D.NET_OPEN)
		net.WriteUInt(#compressed, 24)
		net.WriteData(compressed, #compressed)
	net.Send(ply)
end

function D.Send(session)
	if not session or D.Sessions[session.player] ~= session or not inRange(session) then
		if session and IsValid(session.player) then D.Close(session.player) end
		return false
	end
	local data = session.data
	local languageID, language, understood, translator = resolveLanguage(session)
	local displayedLine = understood and clean(data.line, 480)
		or clean(language.untranslated or "[Unintelligible speech]", 260)
	writePayload(session.player, {
		token = session.token,
		mode = clean(data.mode or "physical", 16),
		speakerEntIndex = IsValid(data.speaker) and data.speaker:EntIndex() or 0,
		speakerName = clean(data.speakerName or "Civilian", 96),
		playerName = playerName(session.player),
		speciesName = clean(data.speciesName or "", 64),
		languageID = languageID,
		languageName = clean(language.name or languageID, 80),
		line = displayedLine,
		understood = understood,
		translator = IsValid(translator) and playerName(translator) or "",
		model = clean(data.model or (IsValid(data.speaker) and data.speaker:GetModel()) or "", 220),
		title = clean(data.title or "CONVERSATION", 80),
		subtitle = clean(data.subtitle or "", 120),
		choices = publicChoices(session),
	})
	return true
end

function D.Open(ply, data, handler)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	data = istable(data) and table.Copy(data) or {}
	data.speaker = data.speaker
	data.anchorPosition = data.anchorPosition
	local token = util.CRC(ply:SteamID64() .. ":" .. tostring(SysTime())
		.. ":" .. tostring(math.random(1, 2147483646)))
	local session = {
		player = ply,
		token = token,
		data = data,
		handler = handler,
		expiresAt = CurTime() + math.max(20, tonumber(data.duration) or 150),
		nextActionAt = 0,
	}
	D.Sessions[ply] = session
	if data.mode == "physical" and IsValid(data.speaker) then
		local direction = ply:GetPos() - data.speaker:GetPos()
		if direction:LengthSqr() > 1 then
			data.speaker:SetAngles(Angle(0, direction:Angle().y, 0))
		end
	end
	return D.Send(session)
end

function D.Close(ply)
	local session = D.Sessions[ply]
	if not session then return end
	D.Sessions[ply] = nil
	if session.data and isfunction(session.data.onClose) then
		local ok, reason = pcall(session.data.onClose, ply, session)
		if not ok then
			ErrorNoHalt("[MilBase Cinematic Dialogue] close callback: "
				.. tostring(reason) .. "\n")
		end
	end
	if IsValid(ply) then
		net.Start(D.NET_CLOSE)
		net.Send(ply)
	end
end

local function findChoice(session, action)
	for _, row in ipairs(session.data.choices or {}) do
		if clean(row.id, 48) == action and row.disabled ~= true then return row end
	end
end

net.Receive(D.NET_ACTION, function(_, ply)
	local token = clean(net.ReadString(), 64)
	local action = clean(net.ReadString(), 48)
	local session = D.Sessions[ply]
	if not session or token ~= session.token then return end
	if action == "close" then D.Close(ply) return end
	if CurTime() >= session.expiresAt or not inRange(session) then D.Close(ply) return end
	if (session.nextActionAt or 0) > CurTime() then return end
	session.nextActionAt = CurTime() + 0.3
	resolveLanguage(session)
	if action == "retry_translation" then D.Send(session) return end
	if not session.understood then D.Send(session) return end
	if not findChoice(session, action) then return end
	if not isfunction(session.handler) then D.Close(ply) return end

	local ok, result = pcall(session.handler, ply, action, session)
	if not ok then
		ErrorNoHalt("[MilBase Cinematic Dialogue] " .. tostring(result) .. "\n")
		D.Close(ply)
		return
	end
	if result == false or not D.Sessions[ply] then D.Close(ply) return end
	if istable(result) then
		for key, value in pairs(result) do session.data[key] = value end
	end
	session.expiresAt = CurTime() + math.max(20, tonumber(session.data.duration) or 150)
	D.Send(session)
end)

hook.Add("PlayerDisconnected", "MilBase_CinematicDialogue_Disconnect", function(ply)
	D.Sessions[ply] = nil
end)

hook.Add("PlayerDeath", "MilBase_CinematicDialogue_Death", function(ply)
	D.Close(ply)
end)

hook.Add("EntityTakeDamage", "MilBase_CinematicDialogue_Damage", function(target, damage)
	if target:IsPlayer() and D.Sessions[target] and damage:GetDamage() > 0 then D.Close(target) end
end)

timer.Create("MilBase_CinematicDialogue_Validate", 1, 0, function()
	for ply, session in pairs(D.Sessions) do
		if not IsValid(ply) or CurTime() >= (session.expiresAt or 0) or not inRange(session) then
			D.Close(ply)
		end
	end
end)
