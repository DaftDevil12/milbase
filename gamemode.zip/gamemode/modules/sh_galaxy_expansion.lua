--[[
	Galaxy Director living-universe expansion shared definitions.

	The server owns every scan, conversation and objective decision. Clients
	receive only the contact information earned by the communications operator.
]]

if MilBase._GalaxyExpansionSharedLoaded then return end
MilBase._GalaxyExpansionSharedLoaded = true

local G = MilBase.Galaxy
G.Version = math.max(tonumber(G.Version) or 2, 3)

G.OperationNames = {
	escort = "CONVOY ESCORT",
	blockade = "REPUBLIC BLOCKADE CONTROL",
	salvage = "SEARCH AND RECOVERY",
	counter_board = "COUNTER-BOARDING OPERATION",
	reinforcement = "REPUBLIC REINFORCEMENTS",
	background_battle = "LOCAL SPACE ENGAGEMENT",
}

G.ContactTypeNames = {
	medical = "MEDICAL RELIEF VESSEL",
	bounty = "BOUNTY HUNTER",
	smuggler = "SUSPECTED SMUGGLER",
	diplomatic = "DIPLOMATIC COURIER",
	derelict = "DERELICT VESSEL",
	defector = "POTENTIAL CIS DEFECTOR",
	convoy = "CONVOY LEAD",
	fleet = "REPUBLIC TASK FORCE",
	blockade = "BLOCKADE TRAFFIC",
	orbital_blockade = "ORBITAL BLOCKADE GROUP",
	salvage = "WRECKAGE / LIFEPODS",
	battle = "BATTLE IN PROGRESS",
	beacon = "NAVIGATION BEACON",
	anomaly = "SENSOR ANOMALY",
	debris = "DEBRIS FIELD",
}

G.TrafficPatternNames = {
	crossing = "CROSSING ROUTE",
	pass_by = "PASSING TRAFFIC",
	distant = "DISTANT TRANSIT",
	formation = "FORMATION TRANSIT",
	engagement = "BACKGROUND ENGAGEMENT",
	planet_arrival = "PLANETARY ARRIVAL",
	planet_departure = "PLANETARY DEPARTURE",
	orbital_blockade = "ORBITAL BLOCKADE PATROL",
	restricted_airspace = "RESTRICTED-AIRSPACE DIVERSION",
}

G.EncounterProfileNames = {
	trade_run = "TRADE RUN",
	refugee_run = "REFUGEE TRANSIT",
	damaged_freighter = "DAMAGED FREIGHTER",
	patrol_sweep = "PATROL SWEEP",
	relief_mission = "RELIEF MISSION",
	damaged_patrol = "DAMAGED PATROL",
	toll = "TOLL DEMAND",
	ransom = "RANSOM ATTEMPT",
	ambush = "AMBUSH",
	false_signal = "FALSE DISTRESS SIGNAL",
	under_fire = "UNDER FIRE",
	cis_recon = "CIS RECONNAISSANCE",
}

function G.SignalLabel(value)
	value = math.Clamp(math.floor(tonumber(value) or 0), 0, 100)
	if value >= 80 then return "CLEAR" end
	if value >= 55 then return "STABLE" end
	if value >= 30 then return "WEAK" end
	if value >= 12 then return "UNSTABLE" end
	return "LOST"
end
