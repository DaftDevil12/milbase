--[[
	Player collision guard

	MilBase derives from Sandbox. Sandbox/player-class defaults and several
	MilBase systems can temporarily make players pass-through. This guard restores
	normal live players to solid player collision and, importantly, disables
	teammate no-collide so same-faction players cannot walk through each other.
]]

local cfg = MilBase.Config

cfg.PlayerCollisionFix = cfg.PlayerCollisionFix ~= false
cfg.PlayerCollisionFixInterval = tonumber(cfg.PlayerCollisionFixInterval or 0.5) or 0.5
cfg.PlayerCollisionForceTeammateCollide = cfg.PlayerCollisionForceTeammateCollide ~= false
cfg.PlayerCollisionDebug = cfg.PlayerCollisionDebug or false

local NORMAL_GROUP = COLLISION_GROUP_PLAYER

-- Do not call player_manager.SetPlayerClass here. Some Sandbox-derived
-- gamemode load orders do not have custom classes registered when players
-- spawn, which causes repeated "unknown player class" errors. The collision
-- fix below works by directly restoring solidity, collision groups, teammate
-- collision, and the ShouldCollide result instead.

local function isSpecialGhostState(ply)
	if not IsValid(ply) then return true end
	if not ply:Alive() then return true end

	-- Intentional MilBase ghost states.
	if ply:GetNWBool("mb_staffmode", false) then return true end
	if ply:GetNWBool("mb_eventmode", false) then return true end
	if ply:GetNWBool("mb_spawn_selecting", false) or ply.mb_spawn_selecting then return true end

	-- LAAT / Star Wars infil hides bodies while players are in the cinematic or
	-- route picker. Those players must remain non-solid until the infil module
	-- releases them.
	if ply:GetNWBool("SWInfilActive", false) then return true end
	if ply:GetNWBool("SWInfilSkyboxWaiting", false) then return true end
	if ply:GetNWBool("SWInfilChoosingSpawn", false) then return true end
	if ply.SWInfilVehicle or ply.SWInfilRestore or ply.SWInfilPendingRestore then return true end

	-- Generic engine states that should not block others.
	local mt = ply:GetMoveType()
	if mt == MOVETYPE_NOCLIP or mt == MOVETYPE_OBSERVER then return true end
	if ply:GetNoDraw() then return true end

	return false
end

local function debugPrint(msg)
	if cfg.PlayerCollisionDebug then
		print("[MilBase Collision] " .. tostring(msg))
	end
end

function MilBase.PlayerCollisionGhosted(ply)
	return isSpecialGhostState(ply)
end

local function forceTeammateCollision(ply)
	if not cfg.PlayerCollisionForceTeammateCollide then return false end
	if not IsValid(ply) then return false end

	-- Sandbox can make same-team players no-collide. Since MilBase uses teams
	-- for factions, explicitly disable teammate no-collide without changing the
	-- player's class.
	if ply.SetAvoidPlayers then
		ply:SetAvoidPlayers(false)
	end

	if ply.SetNoCollideWithTeammates then
		ply:SetNoCollideWithTeammates(false)
		return true
	end

	return false
end

function MilBase.RestorePlayerCollision(ply, reason)
	if not cfg.PlayerCollisionFix then return false end
	if isSpecialGhostState(ply) then return false end

	local changed = false

	if ply.SetCustomCollisionCheck then
		-- Lets the ShouldCollide hook below participate in player/player checks.
		ply:SetCustomCollisionCheck(true)
	end

	forceTeammateCollision(ply)

	if ply.GetNotSolid and ply:GetNotSolid() then
		ply:SetNotSolid(false)
		changed = true
	end

	if ply:GetCollisionGroup() ~= NORMAL_GROUP then
		debugPrint((ply:Nick() or "player") .. " collision group " .. tostring(ply:GetCollisionGroup()) .. " -> " .. tostring(NORMAL_GROUP) .. " (" .. tostring(reason) .. ")")
		ply:SetCollisionGroup(NORMAL_GROUP)
		changed = true
	end

	return changed
end

local function restoreSoon(ply)
	if not IsValid(ply) then return end

	-- Run several times because spawn selector, event mode, team/class logic, and
	-- infil hooks can happen after PlayerSpawn. Special ghost states are ignored.
	for _, delay in ipairs({ 0, 0.1, 0.35, 1, 2.5 }) do
		timer.Simple(delay, function()
			if IsValid(ply) then
				MilBase.RestorePlayerCollision(ply, "spawn_" .. tostring(delay))
			end
		end)
	end
end

hook.Add("PlayerInitialSpawn", "MilBase.PlayerCollisionFix.Initial", restoreSoon)
hook.Add("PlayerSpawn", "MilBase.PlayerCollisionFix.Spawn", restoreSoon)

-- Re-apply after any script changes a faction/team.
hook.Add("OnPlayerChangedTeam", "MilBase.PlayerCollisionFix.Team", function(ply)
	restoreSoon(ply)
end)

hook.Add("ShouldCollide", "MilBase.PlayerCollisionFix.ShouldCollide", function(a, b)
	if not cfg.PlayerCollisionFix then return end
	if not IsValid(a) or not IsValid(b) then return end
	if not a:IsPlayer() or not b:IsPlayer() then return end

	-- Hidden/special-mode players should stay pass-through.
	if isSpecialGhostState(a) or isSpecialGhostState(b) then return false end

	-- Normal live players should physically block each other.
	return true
end)

local nextCheck = 0
hook.Add("Think", "MilBase.PlayerCollisionFix.Think", function()
	if not cfg.PlayerCollisionFix then return end
	if CurTime() < nextCheck then return end
	nextCheck = CurTime() + math.max(0.1, tonumber(cfg.PlayerCollisionFixInterval or 0.5) or 0.5)

	for _, ply in ipairs(player.GetAll()) do
		MilBase.RestorePlayerCollision(ply, "think")
	end
end)

local function fixAllCollision(requester)
	local fixed = 0
	for _, ply in ipairs(player.GetAll()) do
		if MilBase.RestorePlayerCollision(ply, "manual") then
			fixed = fixed + 1
		else
			forceTeammateCollision(ply)
		end
	end

	if IsValid(requester) and MilBase.Notify then
		MilBase.Notify(requester, "Player collision refreshed. Same-team no-collide disabled.", "ok")
	else
		print("[MilBase] Player collision refreshed. Same-team no-collide disabled.")
	end
end

concommand.Add("mb_fix_player_collision", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	fixAllCollision(ply)
end)

concommand.Add("mb_collision_debug", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end

	print("[MilBase] Collision debug dump:")
	for _, target in ipairs(player.GetAll()) do
		local noTeamCollide = "unknown"
		if target.GetNoCollideWithTeammates then
			noTeamCollide = tostring(target:GetNoCollideWithTeammates())
		end

		print(string.format(
			" - %s | team=%s | alive=%s | notsolid=%s | group=%s | movetype=%s | noCollideTeam=%s | ghost=%s",
			target:Nick(), tostring(target:Team()), tostring(target:Alive()),
			tostring(target.GetNotSolid and target:GetNotSolid() or false),
			tostring(target:GetCollisionGroup()), tostring(target:GetMoveType()),
			noTeamCollide, tostring(isSpecialGhostState(target))
		))
	end
end)

MilBase.RegisterChatCommand("fixcollision", {
	help = "(Staff) Refresh normal player collision if players are walking through each other.",
	adminOnly = true,
	func = function(ply)
		fixAllCollision(ply)
	end,
})
