-- Compass module: a bearing tape at the top of the screen, milsim style.
-- Call out contacts by bearing: "Contact, bearing 045!"

local cfg = MilBase.Config

local cardinals = {
	[0] = "N", [45] = "NE", [90] = "E", [135] = "SE",
	[180] = "S", [225] = "SW", [270] = "W", [315] = "NW",
}

hook.Add("HUDPaint", "MilBase.Compass", function()
	if MilBase.InEventView() then return end
	if not cfg.CompassEnabled then return end

	local ply = LocalPlayer()
	if not IsValid(ply) or not ply:Alive() then return end

	local w, h = 440, 34
	local defaultX, defaultY = ScrW() / 2 - w / 2, 12
	local left, top = defaultX, defaultY
	if MilBase.GetHUDPosition then
		left, top = MilBase.GetHUDPosition("compass", defaultX, defaultY)
	end
	local cx = left + w / 2
	local halfFOV = 70 -- degrees visible to each side

	-- Source yaw 90 = north; convert to a 0-359 compass bearing.
	local bearing = (90 - ply:EyeAngles().y) % 360

	MilBase.DrawPanelBF2(left, top, w, h, {
		cut = 8,
		color = Color(8, 8, 9, 150),
	})

	for deg = 0, 345, 15 do
		local diff = ((deg - bearing + 540) % 360) - 180
		if math.abs(diff) <= halfFOV then
			local x = cx + (diff / halfFOV) * (w / 2 - 14)
			local cardinal = cardinals[deg]

			if cardinal then
				draw.SimpleText(cardinal, "MB.Small", x, top + 9,
					deg == 0 and Color(220, 90, 90) or Color(230, 230, 230),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			else
				surface.SetDrawColor(150, 150, 150, 180)
				surface.DrawRect(x, top + 20, 1, 7)
			end
		end
	end

	-- Center marker and numeric bearing
	surface.SetDrawColor(255, 198, 60, 235)
	surface.DrawRect(cx - 1, top, 2, 7)
	draw.SimpleText(string.format("%03d", math.Round(bearing) % 360), "MB.Tiny",
		cx, top + h - 7, Color(200, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
