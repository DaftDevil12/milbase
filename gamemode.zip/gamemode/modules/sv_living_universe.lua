--[[
	Persistent vessel, career and crew simulation.

	Galaxy Director already owns where ships are, where they are going and when
	they arrive. This module gives those same records persistent people, money,
	work, needs, relationships and history. The skybox actor is only the current
	physical representation of a life which continues throughout the galaxy.
]]

if not SERVER or MilBase._LivingUniverseServerLoaded then return end
MilBase._LivingUniverseServerLoaded = true

local G = MilBase.Galaxy
local L = MilBase.LivingUniverse
local cfg = MilBase.Config.LivingUniverse or {}

L.Vessels = L.Vessels or {}
L.Dirty = L.Dirty or {}
L.DirtyQueue = L.DirtyQueue or {}
L.DirtyQueued = L.DirtyQueued or {}
L.DirtyHead = tonumber(L.DirtyHead) or 1
L.Loaded = L.Loaded or false
L.NextSaveAt = L.NextSaveAt or 0
L.SimulationOrder = L.SimulationOrder or {}
L.SimulationCursor = tonumber(L.SimulationCursor) or 1
L.NextSimulationOrderRefresh = L.NextSimulationOrderRefresh or 0

local function unix()
	return os.time()
end

local function clean(value, maximum)
	return G.CleanText(value, maximum or 128)
end

local function clamp(value, minimum, maximum)
	return math.Clamp(tonumber(value) or minimum, minimum, maximum)
end

local function choose(list)
	return list[math.random(#list)]
end

local function chance(probability)
	return math.Rand(0, 1) <= math.Clamp(tonumber(probability) or 0, 0, 1)
end

local function scaledChance(rate, days)
	rate = math.Clamp(tonumber(rate) or 0, 0, 1)
	days = math.max(0, tonumber(days) or 0)
	return 1 - math.pow(1 - rate, math.min(days, 90))
end

local function planetName(key)
	local planet = key and G.Planets and G.Planets[key] or nil
	return planet and planet.name or "an unregistered system"
end

local function planetKeyAvailable(key)
	return isstring(key) and key ~= "" and G.UniversePositions
		and isvector(G.UniversePositions[key])
end

local function factionFor(record)
	if not istable(record) then return "civilian" end
	return record.faction == "cis" and "cis"
		or record.faction == "republic" and "republic"
		or record.faction == "pirate" and "pirate" or "civilian"
end

local humanFirstNames = {
	"Adan", "Ari", "Bela", "Bren", "Caro", "Cassian", "Cira", "Dalen",
	"Dara", "Eli", "Jace", "Jora", "Kato", "Keira", "Lio", "Mara",
	"Nira", "Orin", "Pella", "Rane", "Rhea", "Sana", "Talon", "Vara",
}

local humanLastNames = {
	"Antilles", "Bex", "Calriss", "Dane", "Darr", "Fenn", "Hale", "Jinn",
	"Korr", "Marek", "Moth", "Naberrie", "Ordo", "Rendar", "Sato", "Tane",
	"Valorum", "Venn", "Voss", "Wren",
}

local alienNames = {
	twilek = {
		"Arali Venn", "Bela Syndulla", "Cesi Numa", "Daro Koyi",
		"Femi Lethan", "Hera Numa", "Koyi Secura", "Numa Vao",
	},
	rodian = {
		"Beedo", "Chido", "Greedo Tetsu", "Kelko", "Navik", "Neelo", "Wald", "Wuro",
	},
	duros = {
		"Baniss Keeg", "Cadom Lor", "Darik So", "Lensi Vara",
		"Monnda Teb", "Niin Talo", "Ralo Fen", "Sann Vek",
	},
	sullustan = {
		"Aril Nunb", "Bidi Nien", "Dall Ten", "Melo Pria",
		"Nien Varo", "Sian Tevv", "Soro Suub", "Vilo Numb",
	},
	zabrak = {
		"Asha Koth", "Bao Rane", "Eeth Var", "Korin Tal",
		"Maris Venn", "Ralo Sorn", "Sugi Vara", "Talon Vos",
	},
	mon_calamari = {
		"Ardo Ackbar", "Cil Dac", "Ibtis Fen", "Kina Tills",
		"Meena Verr", "Nahdar Venn", "Raddus Tor", "Toma Ares",
	},
}

local species = {
	{ key = "human", name = "Human", weight = 48 },
	{ key = "twilek", name = "Twi'lek", weight = 12 },
	{ key = "rodian", name = "Rodian", weight = 8 },
	{ key = "duros", name = "Duros", weight = 10 },
	{ key = "sullustan", name = "Sullustan", weight = 8 },
	{ key = "zabrak", name = "Zabrak", weight = 7 },
	{ key = "mon_calamari", name = "Mon Calamari", weight = 7 },
}

local traits = {
	"calm", "cautious", "curious", "dutiful", "gregarious", "idealistic",
	"loyal", "pragmatic", "protective", "restless", "resourceful", "stubborn",
}

local reasons = {
	"to keep the family business alive",
	"to see worlds no one at home ever could",
	"to pay off an old shipyard debt",
	"to support family living on their homeworld",
	"because a life planetside never felt large enough",
	"to help isolated systems survive the war",
	"to build a reputation independent of their family",
	"because the crew became the closest thing they have to a home",
}

local dreams = {
	"own a quiet repair yard after the war",
	"buy a larger ship and give the crew permanent shares",
	"retire somewhere with a real ocean",
	"map a safe route through the Outer Rim",
	"earn a Republic charter for the company",
	"bring every member of the crew home alive",
	"pay off the vessel and fly without creditors",
	"open a cantina beside a busy civilian spaceport",
}

local fears = {
	"being stranded between systems",
	"losing the crew to somebody else's war",
	"an inspection uncovering an old mistake",
	"failing the people waiting at home",
	"the hyperdrive giving out during a bad jump",
	"being forgotten after one final contract",
}

local civilianRoles = {
	"captain", "pilot", "chief engineer", "navigator", "cargo master",
	"medic", "communications officer", "deckhand", "loadmaster",
}

local militaryRoles = {
	"captain", "executive officer", "helm officer", "chief engineer",
	"tactical officer", "sensor officer", "communications officer",
	"medical officer", "quartermaster", "flight coordinator",
}

local pirateRoles = {
	"captain", "pilot", "engine keeper", "gunner", "slicer",
	"boarder", "scrounger", "medic", "lookout",
}

local commodities = {
	food = "food concentrates and agricultural goods",
	medical = "medical supplies and bacta",
	fuel = "refined fuel cells",
	parts = "replacement starship parts",
	industrial = "industrial machinery",
	munitions = "sealed military munitions",
	passengers = "civilian passengers and personal freight",
	relief = "emergency relief supplies",
	luxury = "high-value consumer goods",
	salvage = "licensed salvage and recovered components",
	contraband = "unregistered cargo",
}

local function weightedSpecies()
	local roll = math.random(1, 100)
	local running = 0
	for _, definition in ipairs(species) do
		running = running + definition.weight
		if roll <= running then return definition end
	end
	return species[1]
end

local function personName(faction, index)
	if faction == "cis" then
		if index == 1 then return "TA-" .. math.random(100, 999), "T-series tactical droid" end
		local series = choose({ "B1", "OOM", "DUM", "PK" })
		return series .. "-" .. math.random(1000, 9999),
			series == "DUM" and "DUM-series pit droid" or series .. "-series droid"
	end
	local selected = weightedSpecies()
	if selected.key == "human" then
		return choose(humanFirstNames) .. " " .. choose(humanLastNames), selected.name
	end
	return choose(alienNames[selected.key]), selected.name
end

local function crewRoles(faction)
	if faction == "republic" or faction == "cis" then return militaryRoles end
	if faction == "pirate" then return pirateRoles end
	return civilianRoles
end

local function namedCrewTarget(record)
	local minimum = math.max(2, math.floor(tonumber(cfg.MinimumNamedCrew) or 3))
	local maximum = math.max(minimum, math.floor(tonumber(cfg.MaximumNamedCrew) or 12))
	local faction = factionFor(record)
	local target = faction == "republic" and math.random(7, 11)
		or faction == "cis" and math.random(4, 7)
		or faction == "pirate" and math.random(5, 9)
		or math.random(3, 8)
	return math.Clamp(target, minimum, maximum)
end

local function totalComplement(record, named)
	local faction = factionFor(record)
	if faction == "republic" then return math.max(named, math.random(38, 110)) end
	if faction == "cis" then return math.max(named, math.random(70, 240)) end
	if faction == "pirate" then return math.max(named, math.random(8, 28)) end
	return math.max(named, math.random(5, 24))
end

local function profileProfession(record)
	local faction = factionFor(record)
	if record.stationed then return "orbital_service" end
	if faction == "republic" then
		return choose({ "republic_patrol", "republic_logistics", "republic_scout" })
	elseif faction == "cis" then
		return choose({ "cis_patrol", "cis_logistics", "cis_recon" })
	elseif faction == "pirate" then
		return chance(0.34) and "smuggler" or "raider"
	end
	return choose({ "freight", "freight", "courier", "passenger", "relief", "salvage" })
end

local function markDirty(profile)
	if not istable(profile) or not profile.id then return end
	profile.updatedAt = unix()
	profile._dirty = true
	L.Dirty[profile.id] = true
	if not L.DirtyQueued[profile.id] then
		L.DirtyQueued[profile.id] = true
		L.DirtyQueue[#L.DirtyQueue + 1] = profile.id
	end
end

local function addEvent(profile, kind, summary, personID, systemKey, major, at)
	if not istable(profile) then return end
	at = math.floor(tonumber(at) or unix())
	profile.timeline = profile.timeline or {}
	table.insert(profile.timeline, 1, {
		time = at,
		kind = clean(kind, 24),
		summary = clean(summary, 300),
		personID = clean(personID, 96),
		systemKey = clean(systemKey, 96),
		major = major == true,
	})
	local maximum = math.max(8, math.floor(tonumber(cfg.MaximumTimelineEvents) or 30))
	while #profile.timeline > maximum do table.remove(profile.timeline) end
	markDirty(profile)
	if major and cfg.PublishMajorLifeEvents ~= false and G.AddGalaxyReport
	and systemKey and systemKey ~= "" then
		G.AddGalaxyReport(kind, profile.shipName .. ": " .. clean(summary, 100),
			summary, systemKey, at)
	end
end

local function newCrewMember(profile, record, index, roleOverride)
	local faction = factionFor(record)
	local roles = crewRoles(faction)
	local role = roleOverride or roles[((index - 1) % #roles) + 1]
	local name, personSpecies = personName(faction, index)
	local person = {
		id = clean(profile.id .. "_person_" .. unix() .. "_" .. math.random(1000, 9999), 96),
		name = name,
		species = personSpecies,
		role = role,
		age = faction == "cis" and math.random(1, 16) or math.random(20, 59),
		homeKey = planetKeyAvailable(profile.homeKey) and profile.homeKey
			or record.locationKey or record.originKey or "",
		joinedAt = unix(),
		status = "active",
		health = math.random(82, 100),
		fatigue = math.random(8, 36),
		hunger = math.random(4, 28),
		stress = math.random(6, 35),
		morale = math.random(55, 88),
		skill = math.random(35, 78),
		experience = math.random(0, 480),
		savings = math.random(80, 2200),
		wage = faction == "cis" and 0 or math.random(30, 110),
		shiftOffset = math.random(0, 23),
		traitA = choose(traits),
		traitB = choose(traits),
		reason = choose(reasons),
		dream = choose(dreams),
		fear = choose(fears),
		relationships = {},
		currentActivity = "settling into the current watch",
	}
	if person.traitB == person.traitA then
		person.traitB = traits[(table.KeyFromValue(traits, person.traitA) % #traits) + 1]
	end
	return person
end

local function activeCrew(profile)
	local people = {}
	for _, person in ipairs(profile.crew or {}) do
		if person.status ~= "deceased" and person.status ~= "departed" then
			people[#people + 1] = person
		end
	end
	return people
end

local function captainFor(profile)
	for _, person in ipairs(profile.crew or {}) do
		if person.id == profile.captainID and person.status ~= "deceased"
		and person.status ~= "departed" then return person end
	end
	for _, person in ipairs(profile.crew or {}) do
		if person.status ~= "deceased" and person.status ~= "departed" then
			profile.captainID = person.id
			person.role = "captain"
			return person
		end
	end
	return nil
end

local function buildRelationships(profile)
	local people = activeCrew(profile)
	if #people < 2 then return end
	for index, person in ipairs(people) do
		person.relationships = person.relationships or {}
		if table.Count(person.relationships) == 0 then
			local other = people[(index % #people) + 1]
			local relationship = choose({
				"trusted friend", "old shipmate", "professional rival",
				"mentor", "protege", "quiet confidant",
			})
			person.relationships[other.id] = {
				kind = relationship,
				bond = relationship == "professional rival" and math.random(-18, 18)
					or math.random(28, 72),
			}
		end
	end
end

local function randomDestination(originKey)
	local candidates = {}
	for key, position in pairs(G.UniversePositions or {}) do
		if key ~= originKey and isvector(position) and G.Planets and G.Planets[key] then
			candidates[#candidates + 1] = key
		end
	end
	return #candidates > 0 and choose(candidates) or nil
end

local function contractCommodity(profession)
	if profession == "relief" then return chance(0.5) and "medical" or "relief" end
	if profession == "passenger" then return "passengers" end
	if profession == "salvage" then return "salvage" end
	if profession == "smuggler" or profession == "raider" then return "contraband" end
	if profession == "republic_logistics" or profession == "cis_logistics" then
		return choose({ "fuel", "parts", "munitions", "medical" })
	end
	return choose({ "food", "medical", "fuel", "parts", "industrial", "luxury" })
end

local function contractKind(profession)
	if string.find(profession, "patrol", 1, true) then return "sector patrol" end
	if string.find(profession, "scout", 1, true)
	or string.find(profession, "recon", 1, true) then return "reconnaissance sweep" end
	if profession == "raider" then return "armed raid" end
	if profession == "smuggler" then return "discreet delivery" end
	if profession == "passenger" then return "passenger charter" end
	if profession == "relief" then return "relief delivery" end
	if profession == "salvage" then return "salvage contract" end
	if string.find(profession, "logistics", 1, true) then return "fleet supply run" end
	return "freight contract"
end

local issueContract
local ensureProfile

issueContract = function(profile, record, now)
	if not istable(profile) or not istable(record) then return nil end
	now = math.floor(tonumber(now) or unix())
	if record.stationed then
		profile.contract = {
			id = "duty_" .. profile.id,
			kind = "orbital service rotation",
			originKey = record.locationKey or profile.homeKey,
			destinationKey = record.locationKey or profile.homeKey,
			commodity = "parts",
			manifest = "orbital service equipment",
			quantity = 1,
			pay = 0,
			acceptedAt = now,
			deadline = 0,
			status = "active",
		}
		record.assignment = "orbital_service"
		return profile.contract
	end
	local originKey = record.locationKey or record.originKey or profile.homeKey
	local destinationKey = record.state == "transit" and record.destinationKey
		or randomDestination(originKey)
	if not destinationKey then return nil end
	local commodity = contractCommodity(profile.profession)
	local quantity = math.random(3, 16)
	local distance = 1
	if isvector(G.UniversePositions[originKey]) and isvector(G.UniversePositions[destinationKey]) then
		distance = math.max(1, G.UniversePositions[originKey]:Distance(
			G.UniversePositions[destinationKey]) / 1000)
	end
	local payMinimum = math.max(100, tonumber(cfg.ContractPayMinimum) or 500)
	local payMaximum = math.max(payMinimum, tonumber(cfg.ContractPayMaximum) or 4200)
	local pay = math.floor(math.Clamp(payMinimum + distance * 125 + quantity * 45,
		payMinimum, payMaximum))
	if factionFor(record) == "pirate" then pay = math.floor(pay * 1.35) end
	local duration = math.floor(math.Clamp(900 + distance * 240, 1200, 10800))
	profile.contract = {
		id = string.format("contract_%d_%05d", now, math.random(1, 99999)),
		kind = contractKind(profile.profession),
		originKey = originKey,
		destinationKey = destinationKey,
		commodity = commodity,
		manifest = commodities[commodity],
		quantity = quantity,
		pay = pay,
		acceptedAt = now,
		deadline = now + duration,
		status = "active",
	}
	record.assignment = profile.contract.kind
	record.cargoKey = commodity == "relief" and "medical"
		or commodity == "luxury" and "industrial"
		or commodity == "contraband" and "parts"
		or commodity == "salvage" and "parts" or commodity
	record.cargo = profile.contract.manifest
	record.cargoValue = math.max(1, math.ceil(quantity / 2))
	if record.state == "holding" then record.nextDestinationKey = destinationKey end
	profile.activity = "preparing " .. profile.contract.kind .. " for "
		.. planetName(destinationKey)
	addEvent(profile, "contract",
		"Accepted a " .. profile.contract.kind .. " from " .. planetName(originKey)
			.. " to " .. planetName(destinationKey) .. ".", profile.captainID,
		originKey, false, now)
	return profile.contract
end

local function repairLoadedProfile(profile, record)
	profile.id = clean(profile.id or record.id, 80)
	profile.version = tonumber(profile.version) or L.Version
	profile.shipName = clean(profile.shipName or record.name, 96)
	profile.faction = factionFor(record)
	if G.ShipNameContradictsFaction(profile.shipName, profile.faction) then
		local replacement = clean(record.name, 96)
		if G.ShipNameContradictsFaction(replacement, profile.faction) then
			replacement = G.ChooseShipName(profile.faction, false)
		end
		profile.shipName = replacement
		markDirty(profile)
	end
	profile.homeKey = planetKeyAvailable(profile.homeKey) and profile.homeKey
		or record.homeKey or record.locationKey or record.originKey or ""
	profile.profession = clean(profile.profession or profileProfession(record), 40)
	profile.createdAt = math.floor(tonumber(profile.createdAt) or record.bornAt or unix())
	profile.updatedAt = math.floor(tonumber(profile.updatedAt) or unix())
	profile.lastSimulatedAt = math.floor(tonumber(profile.lastSimulatedAt) or unix())
	profile.funds = math.max(0, tonumber(profile.funds) or math.random(
		tonumber(cfg.StartingFundsMinimum) or 1800,
		tonumber(cfg.StartingFundsMaximum) or 9000))
	profile.debt = math.max(0, tonumber(profile.debt) or math.random(0, 2400))
	profile.fuel = clamp(profile.fuel or math.random(58, 96), 0, 100)
	profile.supplies = clamp(profile.supplies or math.random(55, 94), 0, 100)
	profile.condition = clamp(profile.condition or math.random(68, 97), 0, 100)
	profile.morale = clamp(profile.morale or math.random(55, 86), 0, 100)
	profile.republicReputation = clamp(profile.republicReputation or 0, -100, 100)
	profile.crew = istable(profile.crew) and profile.crew or {}
	profile.timeline = istable(profile.timeline) and profile.timeline or {}
	profile.contractHistory = istable(profile.contractHistory) and profile.contractHistory or {}
	profile.stats = istable(profile.stats) and profile.stats or {}
	profile.stats.routes = math.max(0, tonumber(profile.stats.routes) or 0)
	profile.stats.contracts = math.max(0, tonumber(profile.stats.contracts) or 0)
	profile.stats.battles = math.max(0, tonumber(profile.stats.battles) or 0)
	profile.stats.rescues = math.max(0, tonumber(profile.stats.rescues) or 0)
	profile.stats.crewLost = math.max(0, tonumber(profile.stats.crewLost) or 0)
	profile.stats.creditsEarned = math.max(0, tonumber(profile.stats.creditsEarned) or 0)
	profile.namedCrewTarget = math.Clamp(math.floor(tonumber(profile.namedCrewTarget)
		or namedCrewTarget(record)), 2, math.max(2, tonumber(cfg.MaximumNamedCrew) or 12))
	profile.complement = math.max(profile.namedCrewTarget,
		math.floor(tonumber(profile.complement) or totalComplement(record, profile.namedCrewTarget)))

	if profile.crewInitialised ~= true then
		while #activeCrew(profile) < profile.namedCrewTarget do
			local index = #profile.crew + 1
			profile.crew[index] = newCrewMember(profile, record, index,
				index == 1 and "captain" or nil)
		end
		if not captainFor(profile) then
			profile.crew[1] = newCrewMember(profile, record, 1, "captain")
			profile.captainID = profile.crew[1].id
		end
		profile.crewInitialised = true
	else
		captainFor(profile)
	end
	buildRelationships(profile)
	record.name = profile.shipName
	record.homeKey = profile.homeKey
	return profile
end

ensureProfile = function(record)
	if not L.Loaded or not istable(record) or not record.id then return nil end
	local profile = L.Vessels[record.id]
	local created = false
	if not istable(profile) then
		profile = {
			id = record.id,
			version = L.Version,
			shipName = record.name,
			faction = factionFor(record),
			homeKey = record.homeKey or record.locationKey or record.originKey,
			profession = profileProfession(record),
			createdAt = record.bornAt or unix(),
			lastSimulatedAt = unix(),
			funds = math.random(tonumber(cfg.StartingFundsMinimum) or 1800,
				tonumber(cfg.StartingFundsMaximum) or 9000),
			debt = math.random(0, 2400),
			fuel = math.random(58, 96),
			supplies = math.random(55, 94),
			condition = math.random(68, 97),
			morale = math.random(55, 86),
			republicReputation = 0,
			crew = {},
			timeline = {},
			contractHistory = {},
			stats = {},
		}
		L.Vessels[record.id] = profile
		created = true
	end
	repairLoadedProfile(profile, record)
	if not profile.contract and unix() >= (tonumber(profile.availableContractAt) or 0) then
		issueContract(profile, record, unix())
	end
	if created then
		local captain = captainFor(profile)
		addEvent(profile, "crew",
			(captain and captain.name or "A new captain") .. " registered "
				.. profile.shipName .. " for active service.",
			captain and captain.id or "", profile.homeKey, false)
	end
	return profile
end

function L.ProfileForRecord(record)
	return ensureProfile(record)
end

function L.ProfileForShip(ship)
	if not IsValid(ship) then return nil end
	local id = ship.mb_galaxyUniverseTrafficID
	local record = id and G.UniverseTraffic and G.UniverseTraffic[id] or nil
	return record and ensureProfile(record) or nil, record
end

local function crewAverage(profile, field, fallback)
	local total, count = 0, 0
	for _, person in ipairs(activeCrew(profile)) do
		total = total + (tonumber(person[field]) or fallback or 0)
		count = count + 1
	end
	return count > 0 and total / count or fallback or 0
end

local function battleAt(record)
	local key = record.state == "transit" and record.destinationKey or record.locationKey
	for id, battle in pairs(G.GalaxyBattles or {}) do
		if istable(battle) and battle.systemKey == key
		and (tonumber(battle.endsAt) or 0) > unix() then
			return id, battle
		end
	end
	return nil
end

local function dangerFor(record)
	local _, battle = battleAt(record)
	if battle then return 0.88, "fleet battle" end
	if record.state == "transit" and G.GetGalaxyLane then
		local lane = G.GetGalaxyLane(record.originKey, record.destinationKey)
		if lane.condition == "pirate_activity" then return 0.62, "pirate activity" end
		if lane.condition == "cis_interdiction" then return 0.72, "CIS interdiction" end
		if lane.condition == "ion_storm" then return 0.45, "ion storm" end
	end
	return 0.08, "routine traffic"
end

local function galacticHour(at)
	local scale = math.max(0.25, tonumber(cfg.TimeScale) or 4)
	return math.floor((tonumber(at) or unix()) * scale / 3600) % 24
end

local function routineFor(profile, record, person)
	local hour = galacticHour()
	local faction = factionFor(record)
	local danger = select(1, dangerFor(record))
	if danger >= 0.7 then
		return person.role == "medic" or person.role == "medical officer"
			and "preparing the casualty station" or "standing at battle stations"
	end
	if person.status == "injured" then return "recovering in the medical compartment" end
	if profile.supplies < 18 then return "working under emergency rationing" end
	if profile.fuel < 14 then return "monitoring critical fuel reserves" end
	if profile.condition < 32 and string.find(person.role, "engine", 1, true) then
		return "repairing accumulated drive damage"
	end
	local onWatch = ((hour + (tonumber(person.shiftOffset) or 0)) % 12) < 8
	if not onWatch then
		return hour >= 5 and hour <= 9 and "sleeping between watches"
			or "off watch in the crew compartment"
	end
	if record.state == "transit" then
		if string.find(person.role, "engine", 1, true) then
			return "inspecting the hyperdrive during transit"
		elseif person.role == "pilot" or person.role == "helm officer" then
			return "flying the current hyperspace leg"
		elseif string.find(person.role, "cargo", 1, true)
		or person.role == "loadmaster" or person.role == "quartermaster" then
			return "checking cargo restraints and delivery seals"
		elseif faction == "republic" or faction == "cis" then
			return "maintaining the current patrol watch"
		end
		return "working the current transit watch"
	end
	if record.stationed then return "working the local orbital service rotation" end
	if profile.contract and profile.contract.status == "active" then
		if string.find(person.role, "cargo", 1, true) or person.role == "loadmaster" then
			return "supervising cargo loading"
		elseif string.find(person.role, "engine", 1, true) then
			return "refuelling and inspecting the drive"
		end
		return "preparing the next departure"
	end
	return chance(0.35) and "taking shore leave" or "waiting for the next contract"
end

local function updateActivity(profile, record)
	local danger, dangerName = dangerFor(record)
	if danger >= 0.7 then
		profile.activity = factionFor(record) == "civilian"
			and "attempting to clear " .. dangerName
			or "at battle stations for " .. dangerName
	elseif profile.fuel < 14 then
		profile.activity = "broadcasting for emergency fuel"
	elseif profile.supplies < 18 then
		profile.activity = "rationing food and medical supplies"
	elseif profile.condition < 32 then
		profile.activity = "conducting emergency drive repairs"
	elseif record.state == "transit" then
		profile.activity = "hauling " .. (record.cargo or "registered cargo")
			.. " toward " .. planetName(record.destinationKey)
	elseif record.stationed then
		profile.activity = "working a permanent orbital service rotation"
	elseif profile.contract and profile.contract.status == "active" then
		profile.activity = "loading " .. (profile.contract.manifest or "cargo")
			.. " for " .. planetName(profile.contract.destinationKey)
	else
		profile.activity = "taking on fuel while the crew changes watch"
	end
	for _, person in ipairs(activeCrew(profile)) do
		person.currentActivity = routineFor(profile, record, person)
	end
end

local function completeContract(profile, record, destinationKey, now)
	local contract = profile.contract
	if not istable(contract) or contract.status ~= "active"
	or contract.destinationKey ~= destinationKey then return false end
	local pay = math.max(0, tonumber(contract.pay) or 0)
	local late = (tonumber(contract.deadline) or 0) > 0 and now > contract.deadline
	if late then pay = math.floor(pay * 0.55) end
	profile.funds = profile.funds + pay
	profile.stats.routes = profile.stats.routes + 1
	profile.stats.contracts = profile.stats.contracts + 1
	profile.stats.creditsEarned = profile.stats.creditsEarned + pay
	local people = activeCrew(profile)
	local wagePool = math.floor(pay * 0.24)
	for _, person in ipairs(people) do
		local share = #people > 0 and math.floor(wagePool / #people) or 0
		person.savings = math.max(0, (tonumber(person.savings) or 0) + share)
		person.experience = (tonumber(person.experience) or 0) + math.random(8, 22)
		person.morale = clamp((tonumber(person.morale) or 60) + (late and -4 or 3), 0, 100)
	end
	local summary = (late and "Completed a delayed " or "Completed ")
		.. contract.kind .. " at " .. planetName(destinationKey)
		.. " and earned " .. pay .. " credits."
	addEvent(profile, "arrival", summary, profile.captainID, destinationKey, false, now)
	table.insert(profile.contractHistory, 1, {
		kind = contract.kind,
		originKey = contract.originKey,
		destinationKey = destinationKey,
		completedAt = now,
		pay = pay,
		late = late,
	})
	while #profile.contractHistory > 8 do table.remove(profile.contractHistory) end
	profile.contract = nil
	profile.availableContractAt = now + math.random(90, 420)
	profile.fuel = math.min(100, profile.fuel + math.random(18, 40))
	profile.supplies = math.min(100, profile.supplies + math.random(15, 32))
	if profile.funds > 250 then
		local repair = math.min(100 - profile.condition, math.random(4, 14))
		profile.condition = profile.condition + repair
		profile.funds = math.max(0, profile.funds - math.ceil(repair * 7))
	end
	for _, person in ipairs(people) do
		if person.homeKey == destinationKey and chance(0.38) then
			person.stress = math.max(0, (tonumber(person.stress) or 0) - 18)
			person.morale = math.min(100, (tonumber(person.morale) or 60) + 10)
			addEvent(profile, "family",
				person.name .. " spent the layover visiting family on "
					.. planetName(destinationKey) .. ".",
				person.id, destinationKey, false, now)
			break
		end
	end
	markDirty(profile)
	return true
end

local function crewIncident(profile, record, danger, dangerName, now)
	local people = activeCrew(profile)
	if #people == 0 then return end
	local person = choose(people)
	local systemKey = record.state == "transit" and record.destinationKey or record.locationKey
	if danger >= 0.45 then
		local injuryChance = math.Clamp((tonumber(cfg.SeriousInjuryChance) or 0.12)
			* danger, 0, 0.8)
		if chance(injuryChance) then
			local damage = math.random(18, 48)
			person.health = math.max(0, (tonumber(person.health) or 100) - damage)
			person.status = person.health <= 0 and "deceased" or "injured"
			person.stress = math.min(100, (tonumber(person.stress) or 0) + 24)
			if person.status == "deceased"
			and chance(tonumber(cfg.FatalityChance) or 0.018) then
				profile.stats.crewLost = profile.stats.crewLost + 1
				addEvent(profile, "medical",
					person.name .. " was killed during " .. dangerName .. ".",
					person.id, systemKey, true, now)
			else
				if person.status == "deceased" then
					person.status = "injured"
					person.health = 8
				end
				addEvent(profile, "medical",
					person.name .. " was injured while the ship crossed " .. dangerName .. ".",
					person.id, systemKey, danger >= 0.7, now)
			end
			profile.condition = math.max(0, profile.condition - math.random(3, 13))
			return
		end
		if factionFor(record) == "civilian" and chance(0.34) then
			local loss = math.random(120, 900)
			profile.funds = math.max(0, profile.funds - loss)
			profile.condition = math.max(0, profile.condition - math.random(2, 9))
			addEvent(profile, "danger",
				"Lost cargo and " .. loss .. " credits while escaping " .. dangerName .. ".",
				profile.captainID, systemKey, danger >= 0.7, now)
			return
		end
		addEvent(profile, "danger",
			"The crew completed emergency drills while crossing " .. dangerName .. ".",
			person.id, systemKey, false, now)
		return
	end
	local events = {
		function()
			person.skill = math.min(100, (tonumber(person.skill) or 40) + math.random(1, 3))
			return person.name .. " ran a practical training watch for the crew.", "training"
		end,
		function()
			profile.condition = math.min(100, profile.condition + math.random(1, 4))
			return person.name .. " found and repaired a recurring power fault.", "maintenance"
		end,
		function()
			person.morale = math.min(100, (tonumber(person.morale) or 60) + 4)
			return person.name .. " received a long-delayed message from home.", "family"
		end,
		function()
			person.stress = math.max(0, (tonumber(person.stress) or 20) - 8)
			return "The crew shared a quiet meal between watches.", "crew"
		end,
	}
	local summary, kind = choose(events)()
	addEvent(profile, kind, summary, person.id, systemKey, false, now)
end

local function checkBattle(profile, record, now)
	local id, battle = battleAt(record)
	if id and profile.activeBattleID ~= id then
		profile.activeBattleID = id
		addEvent(profile, "battle",
			factionFor(record) == "civilian"
				and "Was caught inside an active fleet engagement and began emergency evasion."
				or "Reported to battle stations for the engagement near "
					.. planetName(battle.systemKey) .. ".",
			profile.captainID, battle.systemKey, true, now)
	elseif not id and profile.activeBattleID then
		profile.activeBattleID = nil
		profile.stats.battles = profile.stats.battles + 1
		addEvent(profile, "battle",
			"Cleared the engagement and began damage assessment.",
			profile.captainID, record.locationKey or record.destinationKey, false, now)
	end
end

local function advanceProfile(profile, record, now)
	now = math.floor(tonumber(now) or unix())
	local last = math.floor(tonumber(profile.lastSimulatedAt) or now)
	local maximum = math.max(1, tonumber(cfg.MaximumOfflineDays) or 30) * 86400
	local elapsed = math.Clamp(now - last, 0, maximum)
	if elapsed <= 0 then
		updateActivity(profile, record)
		return false
	end
	local hours = elapsed / 3600 * math.max(0.25, tonumber(cfg.TimeScale) or 4)
	local days = hours / 24
	local danger, dangerName = dangerFor(record)
	profile.lastSimulatedAt = now
	checkBattle(profile, record, now)
	if #activeCrew(profile) == 0 then
		profile.status = "derelict"
		profile.activity = "adrift with no active command crew"
		if profile.contract then profile.contract.status = "abandoned" end
		record.assignment = "adrift"
		record.cargo = "unattended cargo and abandoned personal effects"
		markDirty(profile)
		return true
	end

	local complement = math.max(1, tonumber(profile.complement) or 1)
	profile.supplies = math.max(0, profile.supplies - hours * math.Clamp(
		0.018 + complement * 0.00075, 0.018, 0.12))
	if record.state == "transit" then
		profile.fuel = math.max(0, profile.fuel - hours * (0.35 + danger * 0.2))
		profile.condition = math.max(0, profile.condition - hours * (0.025 + danger * 0.055))
	else
		if profile.funds > 150 and profile.supplies < 82 then
			local bought = math.min(82 - profile.supplies, hours * 0.9)
			profile.supplies = profile.supplies + bought
			profile.funds = math.max(0, profile.funds - bought * 3)
		end
		if profile.funds > 150 and profile.fuel < 86 then
			local bought = math.min(86 - profile.fuel, hours * 0.75)
			profile.fuel = profile.fuel + bought
			profile.funds = math.max(0, profile.funds - bought * 4)
		end
		if profile.funds > 250 and profile.condition < 78 then
			local repaired = math.min(78 - profile.condition, hours * 0.22)
			profile.condition = profile.condition + repaired
			profile.funds = math.max(0, profile.funds - repaired * 8)
		end
	end

	for _, person in ipairs(activeCrew(profile)) do
		local working = record.state == "transit" or danger >= 0.5
		person.fatigue = clamp((tonumber(person.fatigue) or 20)
			+ hours * (working and 0.7 or -0.85), 0, 100)
		person.hunger = clamp((tonumber(person.hunger) or 15)
			+ hours * (profile.supplies < 18 and 0.8 or -0.35), 0, 100)
		person.stress = clamp((tonumber(person.stress) or 20)
			+ hours * (danger * 0.7 - (record.state == "holding" and 0.3 or 0.08)), 0, 100)
		if person.status == "injured" and record.state == "holding" and profile.supplies > 10 then
			person.health = math.min(100, (tonumber(person.health) or 30) + hours * 0.8)
			if person.health >= 68 then
				person.status = "active"
				addEvent(profile, "medical",
					person.name .. " returned to duty after recovering from their injuries.",
					person.id, record.locationKey, false, now)
			end
		end
		local personalMorale = 72 - person.fatigue * 0.2 - person.hunger * 0.25
			- person.stress * 0.28 + profile.republicReputation * 0.03
		person.morale = clamp((tonumber(person.morale) or 60) * 0.85
			+ personalMorale * 0.15, 0, 100)
	end

	profile.morale = clamp(crewAverage(profile, "morale", profile.morale), 0, 100)
	if scaledChance((tonumber(cfg.RoutineEventChancePerDay) or 0.42), days) then
		crewIncident(profile, record, danger, dangerName, now)
	end
	if danger >= 0.4
	and scaledChance((tonumber(cfg.DangerEventChancePerDay) or 0.30) * danger, days) then
		crewIncident(profile, record, danger, dangerName, now)
	end

	if record.state == "holding" and #activeCrew(profile) > 3
	and scaledChance(tonumber(cfg.CrewChangeChancePerDay) or 0.06, days) then
		local candidates = {}
		for _, person in ipairs(activeCrew(profile)) do
			if person.id ~= profile.captainID then candidates[#candidates + 1] = person end
		end
		if #candidates > 0 then
			local departing = choose(candidates)
			if departing.morale < 42 or chance(0.22) then
				departing.status = "departed"
				addEvent(profile, "crew",
					departing.name .. " left the crew at " .. planetName(record.locationKey)
						.. " to pursue work planetside.",
					departing.id, record.locationKey, false, now)
			end
		end
	end

	if record.state == "holding" and #activeCrew(profile) < profile.namedCrewTarget
	and now >= (tonumber(profile.nextRecruitAt) or 0) then
		local recruit = newCrewMember(profile, record, #profile.crew + 1)
		profile.crew[#profile.crew + 1] = recruit
		profile.nextRecruitAt = now + math.random(900, 3600)
		buildRelationships(profile)
		addEvent(profile, "crew",
			recruit.name .. " joined the crew as " .. recruit.role .. " at "
				.. planetName(record.locationKey) .. ".",
			recruit.id, record.locationKey, false, now)
	end

	if profile.contract and profile.contract.status == "active"
	and (tonumber(profile.contract.deadline) or 0) > 0
	and now > profile.contract.deadline + 7200 then
		local failed = profile.contract
		profile.funds = math.max(0, profile.funds - math.floor((failed.pay or 0) * 0.2))
		for _, person in ipairs(activeCrew(profile)) do
			person.morale = math.max(0, (tonumber(person.morale) or 60) - 6)
		end
		addEvent(profile, "contract",
			"Lost the overdue " .. failed.kind .. " contract bound for "
				.. planetName(failed.destinationKey) .. ".",
			profile.captainID, record.locationKey or record.destinationKey, false, now)
		profile.contract = nil
		profile.availableContractAt = now + math.random(300, 900)
	end
	if not profile.contract and now >= (tonumber(profile.availableContractAt) or 0) then
		issueContract(profile, record, now)
	end
	updateActivity(profile, record)
	markDirty(profile)
	return true
end

local function serialisableProfile(profile)
	local saved = table.Copy(profile)
	saved._dirty = nil
	saved._lastVisualActivity = nil
	return saved
end

function L.SaveProfile(profile)
	if not L.Loaded or not istable(profile) or not profile.id then return end
	local encoded = util.TableToJSON(serialisableProfile(profile))
	if not encoded then return end
	MilBase.DB.Run("REPLACE INTO frontier_living_universe_vessels "
		.. "(vessel_id, profile_json, updated_at) VALUES ("
		.. MilBase.SQLStr(profile.id) .. ", " .. MilBase.SQLStr(encoded)
		.. ", " .. math.floor(tonumber(profile.updatedAt) or unix()) .. ")")
	profile._dirty = nil
	L.Dirty[profile.id] = nil
	L.DirtyQueued[profile.id] = nil
end

function L.FlushDirty(force)
	if not L.Loaded then return end
	if force then
		for id, profile in pairs(L.Vessels) do
			if profile._dirty or L.Dirty[id] then L.SaveProfile(profile) end
		end
		L.DirtyQueue = {}
		L.DirtyQueued = {}
		L.DirtyHead = 1
	else
		local limit = math.max(1,
			math.floor(tonumber(cfg.MaximumSavesPerFlush) or 24))
		local saved = 0
		while saved < limit and L.DirtyHead <= #L.DirtyQueue do
			local id = L.DirtyQueue[L.DirtyHead]
			L.DirtyHead = L.DirtyHead + 1
			local profile = id and L.Vessels[id] or nil
			if istable(profile) and (profile._dirty or L.Dirty[id]) then
				L.SaveProfile(profile)
				saved = saved + 1
			elseif id then
				L.Dirty[id] = nil
				L.DirtyQueued[id] = nil
			end
		end
		if L.DirtyHead > #L.DirtyQueue then
			L.DirtyQueue = {}
			L.DirtyHead = 1
		end
	end
	L.NextSaveAt = CurTime() + math.max(5, tonumber(cfg.SaveInterval) or 10)
end

local function initialiseDatabase()
	if L._databaseInitialising then return end
	L._databaseInitialising = true
	local valueType = MilBase.DB.IsMySQL() and "LONGTEXT" or "TEXT"
	MilBase.DB.Query("CREATE TABLE IF NOT EXISTS frontier_living_universe_vessels ("
		.. "vessel_id VARCHAR(80) PRIMARY KEY, profile_json " .. valueType
		.. ", updated_at INTEGER)", function()
		MilBase.DB.Query("SELECT vessel_id, profile_json FROM frontier_living_universe_vessels",
			function(rows)
				for _, row in ipairs(rows or {}) do
					local id = clean(row.vessel_id, 80)
					local profile = util.JSONToTable(tostring(row.profile_json or ""))
					if id ~= "" and istable(profile) then
						profile.id = id
						L.Vessels[id] = profile
					end
				end
				L.Loaded = true
				for _, record in pairs(G.UniverseTraffic or {}) do ensureProfile(record) end
				L.NextSaveAt = CurTime() + 2
				MsgC(Color(110, 220, 155), "[Living Universe] ", color_white,
					"Loaded " .. table.Count(L.Vessels) .. " persistent vessel lives.\n")
			end)
	end)
end

hook.Add("MilBase.DBReady", "MilBase.LivingUniverseDatabase", initialiseDatabase)
timer.Simple(0, function()
	if MilBase.DB and MilBase.DB.IsConnected and MilBase.DB.IsConnected() then
		initialiseDatabase()
	end
end)

local baseAssignUniverseTrafficLife = G.AssignUniverseTrafficLife
function G.AssignUniverseTrafficLife(record, originKey, planets)
	local result = baseAssignUniverseTrafficLife(record, originKey, planets)
	-- Normal traffic advancement calls this for every galaxy record. Existing
	-- profiles are already repaired and simulated by the rotating life queue.
	if L.Loaded and record and record.id and not L.Vessels[record.id] then
		ensureProfile(record)
	end
	return result
end

local baseChooseUniverseTrafficDestination = G.ChooseUniverseTrafficDestination
function G.ChooseUniverseTrafficDestination(record, originKey, planets)
	if L.Loaded then
		local profile = ensureProfile(record)
		local contract = profile and profile.contract or nil
		if istable(contract) and contract.status == "active"
		and planetKeyAvailable(contract.destinationKey)
		and contract.destinationKey ~= originKey then
			return { key = contract.destinationKey }
		end
	end
	return baseChooseUniverseTrafficDestination(record, originKey, planets)
end

local baseRecordUniverseTrafficArrival = G.RecordUniverseTrafficArrival
function G.RecordUniverseTrafficArrival(record, destinationKey, now)
	local result = baseRecordUniverseTrafficArrival(record, destinationKey, now)
	if L.Loaded then
		local profile = ensureProfile(record)
		if profile then completeContract(profile, record, destinationKey,
			math.floor(tonumber(now) or unix())) end
	end
	return result
end

function G.LivingUniverseScanText(ship)
	local profile = L.ProfileForShip(ship)
	if not profile then return "" end
	local captain = captainFor(profile)
	local active = activeCrew(profile)
	local injured = 0
	for _, person in ipairs(active) do
		if person.status == "injured" then injured = injured + 1 end
	end
	return "\nCAPTAIN: " .. clean(captain and captain.name or "unassigned", 96)
		.. "\nCREW COMPLEMENT: " .. math.floor(profile.complement or #active)
		.. " (" .. #active .. " individually identified)"
		.. (injured > 0 and (" / " .. injured .. " injured") or "")
		.. "\nVESSEL EMPLOYMENT: "
		.. (L.ProfessionNames[profile.profession] or string.upper(profile.profession))
		.. "\nCREW MORALE: " .. math.floor(profile.morale) .. "%"
		.. "\nSHIP CONDITION: " .. math.floor(profile.condition)
		.. "% / FUEL: " .. math.floor(profile.fuel)
		.. "% / SUPPLIES: " .. math.floor(profile.supplies) .. "%"
		.. "\nCURRENT CREW ACTIVITY: " .. clean(profile.activity, 180)
end

function G.IsLivingUniverseDialogueAction(action)
	return L.DialogueActions[action] == true
end

local function crewManifestText(profile)
	local lines = {}
	local people = activeCrew(profile)
	for index, person in ipairs(people) do
		if index > 6 then break end
		lines[#lines + 1] = person.name .. " - " .. person.role
			.. (person.status == "injured" and " (injured)" or "")
	end
	local remaining = math.max(0, math.floor(profile.complement or #people) - #lines)
	return table.concat(lines, "\n") .. (remaining > 0
		and ("\n...and " .. remaining .. " additional crew and support personnel.") or "")
end

local function crewNewsText(profile)
	local lines = {}
	for index, item in ipairs(profile.timeline or {}) do
		if index > 4 then break end
		lines[#lines + 1] = "- " .. clean(item.summary, 220)
	end
	return #lines > 0 and table.concat(lines, "\n")
		or "The crew has no notable recent events on record."
end

function G.HandleLivingUniverseDialogue(ply, ship, action)
	if not G.IsLivingUniverseDialogueAction(action) then return false end
	local profile, record = L.ProfileForShip(ship)
	if not profile or not record then
		return true, "CREW RECORD UNAVAILABLE",
			"This contact does not have a persistent civilian or fleet registry."
	end
	local captain = captainFor(profile)
	local captainName = captain and captain.name or "the acting captain"
	if action == "crew_manifest" then
		return true, "CREW IDENTIFICATION",
			"\"" .. captainName .. " speaking. Our current watch roster follows.\"\n\n"
				.. crewManifestText(profile)
	elseif action == "crew_story" then
		if not captain then
			return true, "CAPTAIN UNAVAILABLE", "No commanding officer is currently available."
		end
		local relationshipText = ""
		for otherID, relationship in pairs(captain.relationships or {}) do
			for _, other in ipairs(profile.crew or {}) do
				if other.id == otherID then
					relationshipText = " Their " .. relationship.kind .. " aboard ship is "
						.. other.name .. "."
					break
				end
			end
			if relationshipText ~= "" then break end
		end
		return true, "CAPTAIN'S STORY",
			captainName .. " is a " .. string.lower(captain.species)
				.. " from " .. planetName(captain.homeKey) .. ", known by the crew as "
				.. captain.traitA .. " and " .. captain.traitB .. ". They fly "
				.. captain.reason .. " and hope to " .. captain.dream .. "."
				.. relationshipText
	elseif action == "crew_work" then
		local contract = profile.contract
		local work = contract and contract.status == "active"
			and ("Current work: " .. contract.kind .. ", carrying "
				.. (contract.manifest or "registered freight") .. " from "
				.. planetName(contract.originKey) .. " to "
				.. planetName(contract.destinationKey) .. ".")
			or "The vessel is between contracts and taking on stores."
		return true, "VESSEL LIVELIHOOD",
			work .. "\n\n" .. clean(profile.activity, 200)
				.. "\nCompleted routes: " .. math.floor(profile.stats.routes or 0)
				.. " / Contracts: " .. math.floor(profile.stats.contracts or 0)
				.. " / Battles survived: " .. math.floor(profile.stats.battles or 0) .. "."
	elseif action == "crew_news" then
		return true, "CREW LOG EXCERPT", crewNewsText(profile)
	elseif action == "crew_supplies" then
		if cfg.AllowEmergencySupplyAid == false then
			return true, "SUPPLY TRANSFER UNAVAILABLE",
				"Republic emergency supply transfers are currently disabled."
		end
		local faction = factionFor(record)
		if faction == "cis" and ship:GetHostile() then
			return true, "TRANSFER REFUSED",
				"\"Confederate units do not accept supplies from a hostile Republic vessel.\""
		end
		if (tonumber(profile.nextRepublicAidAt) or 0) > unix() then
			return true, "SUPPLIES ALREADY RECEIVED",
				"\"Your earlier stores are aboard. Save them for somebody else who needs them.\""
		end
		profile.nextRepublicAidAt = unix() + 1800
		profile.supplies = math.min(100, profile.supplies + 28)
		profile.fuel = math.min(100, profile.fuel + 12)
		profile.republicReputation = math.min(100, profile.republicReputation + 8)
		profile.stats.rescues = profile.stats.rescues + 1
		for _, person in ipairs(activeCrew(profile)) do
			person.morale = math.min(100, (tonumber(person.morale) or 60) + 5)
		end
		addEvent(profile, "reputation",
			"Received emergency fuel, food and medical stores from a Republic vessel.",
			profile.captainID, record.locationKey or record.destinationKey, false)
		if G.ChangeContactTrust then
			G.ChangeContactTrust(ship, faction == "pirate" and 4 or 9,
				"Republic personnel supplied the crew with emergency stores.")
		end
		return true, "EMERGENCY STORES TRANSFERRED",
			"\"" .. captainName
				.. " here. Fuel and medical stores are aboard. The crew will remember this.\""
	end
	return false
end

local function applyProfileToVisibleShip(profile, record, ship)
	if not IsValid(ship) then return end
	local captain = captainFor(profile)
	ship.mb_livingUniverseProfileID = profile.id
	ship.mb_livingCaptainName = captain and captain.name or ""
	ship.mb_livingCrewActivity = profile.activity
	local captainName = clean(ship.mb_livingCaptainName, 96)
	local activity = clean(profile.activity, 160)
	local complement = math.floor(profile.complement or 0)
	local morale = math.floor(profile.morale or 0)
	if ship:GetNWString("mb_living_captain", "") ~= captainName then
		ship:SetNWString("mb_living_captain", captainName)
	end
	if ship:GetNWString("mb_living_activity", "") ~= activity then
		ship:SetNWString("mb_living_activity", activity)
	end
	if ship:GetNWInt("mb_living_complement", -1) ~= complement then
		ship:SetNWInt("mb_living_complement", complement)
	end
	if ship:GetNWInt("mb_living_morale", -1) ~= morale then
		ship:SetNWInt("mb_living_morale", morale)
	end
	if profile.contract and profile.contract.status == "active" then
		ship.mb_galaxyCargo = clean(profile.contract.manifest, 160)
		if planetKeyAvailable(profile.contract.destinationKey) then
			ship.mb_galaxyDestination = planetName(profile.contract.destinationKey)
		end
	end
	local targetHull = math.max(1, math.floor(ship:GetMaxHull()
		* math.Clamp((tonumber(profile.condition) or 100) / 100, 0.03, 1)))
	if not ship.mb_livingHullInitialised then
		ship:SetHull(targetHull)
		ship.mb_livingHullInitialised = true
	elseif record.state == "holding" and ship:GetHull() < targetHull then
		-- Repairs are only reflected physically while the ship is laid over.
		ship:SetHull(math.min(targetHull, ship:GetHull()
			+ math.max(1, math.ceil(ship:GetMaxHull() * 0.012))))
	end
	if cfg.VisibleActivityUpdates ~= false
	and ship.mb_galaxyUniverseTrafficMode == "holding"
	and not ship:GetHostile() and not ship.mb_galaxyCombatPrepared
	and profile._lastVisualActivity ~= profile.activity then
		ship:SetShipState(clean(profile.activity, 48))
		profile._lastVisualActivity = profile.activity
	end
end

local baseOnGalaxyHullDamaged = G.OnGalaxyHullDamaged
function G.OnGalaxyHullDamaged(ship, dmg)
	if baseOnGalaxyHullDamaged then baseOnGalaxyHullDamaged(ship, dmg) end
	if not IsValid(ship) or not ship.mb_galaxyUniverseTrafficID then return end
	local profile, record = L.ProfileForShip(ship)
	if not profile or not record then return end
	profile.condition = math.Clamp(ship:GetHull() / math.max(1, ship:GetMaxHull()) * 100, 0, 100)
	local damage = dmg and dmg.GetDamage and tonumber(dmg:GetDamage()) or 0
	if damage >= ship:GetMaxHull() * 0.08
	and CurTime() >= (ship.mb_livingNextDamageEvent or 0) then
		ship.mb_livingNextDamageEvent = CurTime() + 35
		local dangerName = ship:GetHostile() and "weapons fire" or "a major hull impact"
		crewIncident(profile, record, 0.72, dangerName, unix())
	end
	markDirty(profile)
end

local function attackerName(attacker)
	if IsValid(attacker) and attacker:IsPlayer() then return attacker:Nick() end
	if IsValid(attacker) and attacker.GetShipName then return attacker:GetShipName() end
	return "an unidentified attacker"
end

local function recordDestroyedVessel(ship, attacker)
	if cfg.PermanentShipLossEnabled == false or not IsValid(ship) then return false end
	local id = ship.mb_galaxyUniverseTrafficID
	local record = id and G.UniverseTraffic and G.UniverseTraffic[id] or nil
	local profile = record and ensureProfile(record) or (id and L.Vessels[id])
	if not id or not profile or profile.status == "destroyed" then return false end
	local systemKey = record and (record.state == "transit"
		and record.destinationKey or record.locationKey) or profile.homeKey
	local survivors = 0
	for _, person in ipairs(activeCrew(profile)) do
		local survival = math.Clamp((tonumber(cfg.DestructionSurvivalChance) or 0.28)
			+ (tonumber(person.health) or 100) / 500
			- (tonumber(person.stress) or 0) / 600, 0.08, 0.72)
		if chance(survival) then
			person.status = "missing"
			person.health = math.max(5, math.min(45, tonumber(person.health) or 30))
			person.stress = 100
			survivors = survivors + 1
		else
			person.status = "deceased"
			person.health = 0
			profile.stats.crewLost = profile.stats.crewLost + 1
		end
	end
	profile.status = "destroyed"
	profile.destroyedAt = unix()
	profile.destroyedSystemKey = systemKey
	profile.destroyedBy = clean(attackerName(attacker), 96)
	profile.condition = 0
	profile.activity = survivors > 0
		and (survivors .. " survivor beacon(s) awaiting rescue")
		or "lost with no confirmed survivors"
	ship.mb_livingSurvivorCount = survivors
	ship.mb_livingDestroyedVesselID = id
	if profile.contract then
		profile.contract.status = "lost"
		profile.contract.lostAt = unix()
	end
	addEvent(profile, "battle",
		"Vessel destroyed by " .. profile.destroyedBy .. ". "
			.. survivors .. " named crew member(s) reached escape craft.",
		profile.captainID, systemKey, true)
	if survivors > 0 and table.Count(G.GalaxyDistress or {}) < 12 then
		local distressID = string.format("crew_distress_%d_%05d", unix(), math.random(1, 99999))
		G.GalaxyDistress[distressID] = {
			id = distressID,
			systemKey = systemKey,
			sourceName = profile.shipName .. " survivors",
			createdAt = unix(),
			expiresAt = unix() + 1200,
			survivors = survivors,
			vesselID = id,
		}
		G.GalaxySimulationDirty = true
	end
	if G.UniverseTraffic then G.UniverseTraffic[id] = nil end
	if G.UniverseTrafficEntities then G.UniverseTrafficEntities[id] = nil end
	if G.TrackedUniverseTraffic then G.TrackedUniverseTraffic[id] = nil end
	G.UniverseTrafficDirty = true
	L.SaveProfile(profile)
	timer.Simple(0, function()
		if G.SaveUniverseTraffic then G.SaveUniverseTraffic() end
		if G.SaveTrackedUniverseTraffic then G.SaveTrackedUniverseTraffic() end
	end)
	return true
end

local baseOnShipDestroyed = G.OnShipDestroyed
function G.OnShipDestroyed(ship, attacker)
	recordDestroyedVessel(ship, attacker)
	if baseOnShipDestroyed then return baseOnShipDestroyed(ship, attacker) end
end

local baseResolveOperation = G.ResolveOperation
function G.ResolveOperation(outcome, details)
	local operation = G.Operation
	local vesselID = operation and operation.kind == "salvage"
		and IsValid(operation.target)
		and operation.target.mb_livingDestroyedVesselID or nil
	local operator = operation and operation.operator or nil
	local result = baseResolveOperation(outcome, details)
	if outcome ~= "success" or not vesselID then return result end
	local profile = L.Vessels[vesselID]
	if not istable(profile) then return result end
	local recovered = 0
	for _, person in ipairs(profile.crew or {}) do
		if person.status == "missing" then
			person.status = "rescued"
			person.health = math.max(18, tonumber(person.health) or 18)
			person.stress = math.min(92, tonumber(person.stress) or 92)
			recovered = recovered + 1
		end
	end
	if recovered > 0 then
		profile.activity = recovered .. " surviving crew recovered by the Republic"
		profile.republicReputation = math.min(100,
			(tonumber(profile.republicReputation) or 0) + 24)
		addEvent(profile, "medical",
			recovered .. " surviving crew member(s) were recovered by "
				.. (IsValid(operator) and operator:Nick() or "a Republic rescue team") .. ".",
			profile.captainID, profile.destroyedSystemKey, true)
		for id, distress in pairs(G.GalaxyDistress or {}) do
			if distress.vesselID == vesselID then G.GalaxyDistress[id] = nil end
		end
		G.GalaxySimulationDirty = true
		L.SaveProfile(profile)
	end
	return result
end

timer.Create("MilBase.LivingUniverseThink",
	math.max(5, tonumber(cfg.ThinkInterval) or 15), 0, function()
	if cfg.Enabled == false or not L.Loaded then return end
	local now = unix()
	if CurTime() >= (L.NextSimulationOrderRefresh or 0)
	or L.SimulationCursor > #L.SimulationOrder then
		L.SimulationOrder = {}
		for id in pairs(G.UniverseTraffic or {}) do
			L.SimulationOrder[#L.SimulationOrder + 1] = id
		end
		table.sort(L.SimulationOrder)
		L.SimulationCursor = 1
		L.NextSimulationOrderRefresh = CurTime() + 60
	end
	local profileLimit = math.max(1, math.floor(tonumber(cfg.ProfilesPerThink) or 12))
	for _ = 1, profileLimit do
		local id = L.SimulationOrder[L.SimulationCursor]
		if not id then break end
		L.SimulationCursor = L.SimulationCursor + 1
		local record = G.UniverseTraffic[id]
		if istable(record) then
			local profile = ensureProfile(record)
			if profile then advanceProfile(profile, record, now) end
		end
	end
	-- The handful of physical ships in the current skybox always receive their
	-- current activity immediately, independent of the off-screen batch cursor.
	for id, ship in pairs(G.UniverseTrafficEntities or {}) do
		local record = G.UniverseTraffic[id]
		local profile = record and ensureProfile(record) or nil
		if profile and IsValid(ship) then applyProfileToVisibleShip(profile, record, ship) end
	end
	if CurTime() >= (L.NextSaveAt or 0) then L.FlushDirty(false) end
end)

local function adminAllowed(ply)
	return not IsValid(ply) or ply:IsAdmin()
end

concommand.Add("mb_living_universe_list", function(ply)
	if not adminAllowed(ply) then return end
	local message = "Living Universe is tracking " .. table.Count(L.Vessels)
		.. " persistent vessels and " .. table.Count(L.Dirty) .. " unsaved updates."
	if IsValid(ply) then MilBase.Notify(ply, message, "info") end
	print("[Living Universe] " .. message)
	for id, profile in SortedPairs(L.Vessels) do
		print(string.format("  %s | %s | %s | %s", id, profile.shipName,
			L.ProfessionNames[profile.profession] or profile.profession,
			profile.activity or "no activity"))
	end
end)

concommand.Add("mb_living_universe_ship", function(ply, _, args)
	if not adminAllowed(ply) then return end
	local query = string.lower(table.concat(args, " "))
	local found
	for id, profile in pairs(L.Vessels) do
		if query == "" or string.find(string.lower(id), query, 1, true)
		or string.find(string.lower(profile.shipName or ""), query, 1, true) then
			found = profile
			break
		end
	end
	if not found then
		if IsValid(ply) then MilBase.Notify(ply, "No matching persistent vessel was found.", "warn") end
		return
	end
	local captain = captainFor(found)
	local summary = found.shipName .. " | Captain "
		.. (captain and captain.name or "unassigned") .. " | "
		.. (L.ProfessionNames[found.profession] or found.profession)
		.. " | " .. (found.activity or "no activity")
	print("[Living Universe] " .. summary)
	print(crewNewsText(found))
	if IsValid(ply) then MilBase.Notify(ply, summary, "info") end
end)

concommand.Add("mb_living_universe_save", function(ply)
	if not adminAllowed(ply) then return end
	for id, profile in pairs(L.Vessels) do
		profile._dirty = true
		L.Dirty[id] = true
	end
	L.FlushDirty(true)
	if IsValid(ply) then MilBase.Notify(ply, "Living Universe vessel lives saved.", "ok") end
end)

concommand.Add("mb_living_universe_simulate", function(ply, _, args)
	if not adminAllowed(ply) then return end
	local hours = math.Clamp(tonumber(args[1]) or 1, 0.25, 720)
	local scale = math.max(0.25, tonumber(cfg.TimeScale) or 4)
	local seconds = math.floor(hours / scale * 3600)
	for _, profile in pairs(L.Vessels) do
		profile.lastSimulatedAt = math.max(0,
			(tonumber(profile.lastSimulatedAt) or unix()) - seconds)
	end
	for _, record in pairs(G.UniverseTraffic or {}) do
		local profile = ensureProfile(record)
		if profile then advanceProfile(profile, record, unix()) end
	end
	L.FlushDirty(true)
	local message = "Advanced every persistent vessel by " .. hours .. " simulated hours."
	print("[Living Universe] " .. message)
	if IsValid(ply) then MilBase.Notify(ply, message, "ok") end
end)

hook.Add("ShutDown", "MilBase.LivingUniverseSave", function()
	if L.Loaded then L.FlushDirty(true) end
end)
