--[[
	CCTV system. Feeds = placed CCTV cameras (mb_cctv_camera) + HELMET CAMS of
	any player who's wearing a helmet and isn't an event enemy. Viewed on the
	CCTV Monitor SWEP (mb_cctv): a screen shows the last selected feed; press R
	to go FULLSCREEN, where A/D pan a physical camera. MOUSE1/2 change feed.
]]

if SERVER then

	util.AddNetworkString("MilBase_CCTVSave")
	util.AddNetworkString("MilBase_CCTVClear")

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_cctv (
		map VARCHAR(64), pos TEXT, ang TEXT, name TEXT
	)]])

	-- Spawn a camera (used by the tool, the command and the loader).
	function MilBase.SpawnCamera(pos, ang, name)
		local cam = ents.Create("mb_cctv_camera")
		if not IsValid(cam) then return end
		cam:SetPos(pos)
		cam:SetAngles(ang or angle_zero)
		cam:Spawn()
		if name and name ~= "" and cam.SetCamName then cam:SetCamName(name) end
		return cam
	end

	-- Persist every camera currently on the map (replaces this map's saved set).
	function MilBase.SaveCameras()
		MilBase.DB.Run("DELETE FROM frontier_cctv WHERE map = " .. MilBase.SQLStr(game.GetMap()))
		local n = 0
		for _, cam in ipairs(ents.FindByClass("mb_cctv_camera")) do
			if IsValid(cam) then
				MilBase.DB.Run(string.format(
					"INSERT INTO frontier_cctv (map, pos, ang, name) VALUES (%s, %s, %s, %s)",
					MilBase.SQLStr(game.GetMap()),
					MilBase.SQLStr(tostring(cam:GetPos())),
					MilBase.SQLStr(tostring(cam:GetAngles())),
					MilBase.SQLStr(cam.GetCamName and cam:GetCamName() or "")))
				n = n + 1
			end
		end
		return n
	end

	local function loadCameras()
		MilBase.DB.Query("SELECT * FROM frontier_cctv WHERE map = "
			.. MilBase.SQLStr(game.GetMap()), function(rows)
			for _, row in ipairs(rows) do
				MilBase.SpawnCamera(util.StringToType(row.pos, "Vector"),
					util.StringToType(row.ang, "Angle"), row.name)
			end
		end)
	end

	hook.Add("InitPostEntity", "MilBase.CCTVLoad", loadCameras)
	hook.Add("PostCleanupMap", "MilBase.CCTVLoad", loadCameras)

	net.Receive("MilBase_CCTVSave", function(_, ply)
		if not ply:IsAdmin() then return end
		local n = MilBase.SaveCameras()
		MilBase.Notify(ply, "Saved " .. n .. " camera(s) for " .. game.GetMap() .. ".")
	end)

	net.Receive("MilBase_CCTVClear", function(_, ply)
		if not ply:IsAdmin() then return end
		MilBase.DB.Run("DELETE FROM frontier_cctv WHERE map = " .. MilBase.SQLStr(game.GetMap()))
		MilBase.Notify(ply, "Cleared the saved cameras for this map (existing ones stay until removed).")
	end)

	MilBase.RegisterChatCommand("cctv", {
		help = "(Admin) Spawn a CCTV camera looking where you aim.",
		func = function(ply)
			if not ply:IsAdmin() then
				MilBase.Notify(ply, "Admins only.")
				return
			end
			local tr = ply:GetEyeTrace()
			MilBase.SpawnCamera(tr.HitPos + tr.HitNormal * 6, ply:EyeAngles())
			MilBase.Notify(ply, "CCTV camera spawned - aim it with the physgun, or use the CCTV Cameras tool + Save.")
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client
--------------------------------------------------------------------------

local ui = MilBase.UI

local active = false      -- holding the monitor SWEP
local fullscreen = false
local feeds = {}
local sel = 1
local pan = 0             -- physical-camera pan offset (degrees)
local nextBuild = 0

local RTW, RTH = 1024, 576
local RT = GetRenderTarget("mb_cctv_rt", RTW, RTH)
local MAT = CreateMaterial("mb_cctv_mat_" .. os.time(), "UnlitGeneric", {
	["$basetexture"] = RT:GetName(),
	["$nolod"] = "1",
})

-- Build the current list of viewable feeds.
local function buildFeeds()
	local out = {}
	for _, cam in ipairs(ents.FindByClass("mb_cctv_camera")) do
		if IsValid(cam) then
			out[#out + 1] = { kind = "camera", ent = cam,
				name = (cam.GetCamName and cam:GetCamName() ~= "" and cam:GetCamName()) or "CAMERA" }
		end
	end

	local lp = LocalPlayer()
	for _, p in ipairs(player.GetAll()) do
		if IsValid(p) and p ~= lp and p:Alive()
		and p:GetNWBool("mb_helmet", false)
		and not (MilBase.IsEventEnemy and MilBase.IsEventEnemy(p)) then
			out[#out + 1] = { kind = "helmet", ent = p, name = p:MBName() .. "  (HELMET)" }
		end
	end
	return out
end

-- Where a feed renders from.
local function feedView(feed)
	if not feed or not IsValid(feed.ent) then return end
	if feed.kind == "camera" then
		local e = feed.ent
		local ang = e:GetAngles() + Angle(0, pan, 0)
		return e:GetPos() + e:GetForward() * 6 + e:GetUp() * 1, ang, 85
	end
	return feed.ent:EyePos(), feed.ent:EyeAngles(), 90
end

function MilBase.CCTVSetActive(on)
	active = on and true or false
	if not active then fullscreen = false end
	if active then feeds = buildFeeds() sel = math.Clamp(sel, 1, math.max(#feeds, 1)) end
end

function MilBase.CCTVCycle(dir)
	feeds = buildFeeds()
	if #feeds == 0 then sel = 1 return end
	sel = ((sel - 1 + dir) % #feeds) + 1
	pan = 0
	surface.PlaySound("buttons/lever7.wav")
end

function MilBase.CCTVToggleFull()
	if #feeds == 0 then return end
	fullscreen = not fullscreen
	surface.PlaySound("buttons/button14.wav")
end

--------------------------------------------------------------------------
-- Render the feed into the RT (before the frame, outside a render context)
--------------------------------------------------------------------------

-- Render the feed into the RT before the HUD draws (a valid context for
-- render.RenderView; the guard prevents re-entrancy from the nested render).
local drawing = false
hook.Add("PreDrawHUD", "MilBase.CCTVRender", function()
	if not active or drawing then return end
	local pos, ang, fov = feedView(feeds[sel])
	if not pos then return end

	drawing = true
	render.PushRenderTarget(RT)
	render.Clear(0, 0, 0, 255, true, true)
	render.RenderView({
		origin = pos, angles = ang,
		x = 0, y = 0, w = RTW, h = RTH,
		fov = fov, drawviewmodel = false, drawhud = false, dopostprocess = false,
		drawviewer = true, -- draw the local player so you can see yourself on cams
	})
	render.PopRenderTarget()
	drawing = false
end)

--------------------------------------------------------------------------
-- Input: rebuild feeds, pan in fullscreen, freeze movement while fullscreen
--------------------------------------------------------------------------

hook.Add("Think", "MilBase.CCTVThink", function()
	if not active then return end

	if nextBuild < CurTime() then
		nextBuild = CurTime() + 1
		feeds = buildFeeds()
		if sel > #feeds then sel = math.max(#feeds, 1) end
	end

	if fullscreen and feeds[sel] and feeds[sel].kind == "camera" then
		if input.IsKeyDown(KEY_A) then pan = math.Clamp(pan + FrameTime() * 70, -80, 80) end
		if input.IsKeyDown(KEY_D) then pan = math.Clamp(pan - FrameTime() * 70, -80, 80) end
	end
end)

hook.Add("CreateMove", "MilBase.CCTVFreeze", function(cmd)
	if active and fullscreen then cmd:ClearMovement() end
end)

--------------------------------------------------------------------------
-- HUD: the monitor screen / fullscreen view
--------------------------------------------------------------------------

local function drawFeedName(feed, x, y, font, align)
	local name = feed and feed.name or "NO SIGNAL"
	local col = feed and (feed.kind == "helmet" and Color(120, 200, 255) or ui.ok) or ui.danger
	draw.SimpleTextOutlined("● " .. string.upper(name), font, x, y, col, align or TEXT_ALIGN_LEFT,
		TEXT_ALIGN_CENTER, 1, color_black)
end

local function drawScreen(x, y, w, h, feed)
	if feed then
		surface.SetMaterial(MAT)
		surface.SetDrawColor(255, 255, 255)
		surface.DrawTexturedRect(x, y, w, h)
	else
		surface.SetDrawColor(8, 10, 8)
		surface.DrawRect(x, y, w, h)
		draw.SimpleText("NO SIGNAL", "MB.Tab", x + w / 2, y + h / 2, ui.danger,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	-- faint scanline sweep
	local sy = y + (CurTime() * 120) % h
	surface.SetDrawColor(255, 255, 255, 12)
	surface.DrawRect(x, sy, w, 2)
end

hook.Add("HUDPaint", "MilBase.CCTVHUD", function()
	if not active then return end
	local feed = feeds[sel]

	if fullscreen then
		drawScreen(0, 0, ScrW(), ScrH(), feed)
		drawFeedName(feed, 26, 30, "MB.Big")
		draw.SimpleText(sel .. " / " .. math.max(#feeds, 1), "MB.Small", ScrW() - 26, 30, ui.dim,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleTextOutlined(
			(feed and feed.kind == "camera" and "A / D  pan     " or "")
			.. "MOUSE1 / MOUSE2  change cam     R  exit",
			"MB.Small", ScrW() / 2, ScrH() - 30, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	else
		local mw, mh = 384, 216
		local x, y = ScrW() - mw - 24, ScrH() - mh - 70
		MilBase.DrawPanelBF2(x - 6, y - 24, mw + 12, mh + 54, { cut = 8, accent = ui.accent })
		draw.SimpleText("CCTV", "MB.Small", x, y - 16, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		drawScreen(x, y, mw, mh, feed)
		drawFeedName(feed, x + 2, y + mh + 12, "MB.Small")
		draw.SimpleText("R focus  •  M1/M2 cam", "MB.Tiny", x + mw, y + mh + 12, ui.faint,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end)

-- Hide the normal HUD while fullscreen so it doesn't overlay the feed.
hook.Add("HUDShouldDraw", "MilBase.CCTVHideHUD", function(name)
	if active and fullscreen and name ~= "CHudGMod" then return false end
end)
