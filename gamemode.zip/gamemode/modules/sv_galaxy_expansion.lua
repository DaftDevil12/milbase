--[[
	Galaxy Director living-universe expansion (server).

	Adds private sensor scans, persistent ship captains, conversation branches,
	intelligence chains, escorts, blockades, salvage, reinforcements, varied
	boarders and counter-boarding without replacing Star Wars Universe.
]]

if not SERVER or MilBase._GalaxyExpansionServerLoaded then return end
MilBase._GalaxyExpansionServerLoaded = true

local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}
if gd.LivingUniverseExpansion == false then return end

util.AddNetworkString("MilBase_GalaxyHailAction")

G.ContactMemory = G.ContactMemory or {}
G.IntelRecords = G.IntelRecords or {}
G.CommsHistory = G.CommsHistory or {}
G.ScannedShips = G.ScannedShips or setmetatable({}, { __mode = "k" })
G.SystemDisruption = G.SystemDisruption or {
	sensors = 0,
	communications = 0,
	weapons = 0,
	shields = 0,
}
G.Support = G.Support or {
	charges = math.Clamp(tonumber(gd.ReinforcementStartingCharges) or 2, 0,
		math.max(1, tonumber(gd.ReinforcementMaximum) or 3)),
	nextRecharge = os.time() + math.max(60,
		tonumber(gd.ReinforcementRechargeTime) or 1800),
}
G.Wreckage = G.Wreckage or {}
G.AmbientTrafficShips = G.AmbientTrafficShips or {}
G.PlanetTrafficShips = G.PlanetTrafficShips or {}
G.AmbientPhenomena = G.AmbientPhenomena or {}
G.NextAmbientPhenomenonAt = G.NextAmbientPhenomenonAt or 0
G.NextAmbientCommsChatterAt = G.NextAmbientCommsChatterAt or 0
G.NextPlanetTrafficAt = G.NextPlanetTrafficAt or 0
G.NextPersistentTrafficMaintenanceAt = G.NextPersistentTrafficMaintenanceAt or 0
-- Galaxy traffic exists independently of the locally visible skybox ships.
-- These records are advanced using Unix time, so they also continue while the
-- server is empty or restarted.
G.UniverseTraffic = G.UniverseTraffic or {}
G.UniverseTrafficEntities = G.UniverseTrafficEntities or {}
G.TrackedUniverseTraffic = G.TrackedUniverseTraffic or {}
G.UniverseTrafficDirty = G.UniverseTrafficDirty or false
G.NextUniverseTrafficSaveAt = G.NextUniverseTrafficSaveAt or 0
G.NextUniverseTrafficPopulationAt = G.NextUniverseTrafficPopulationAt or 0
G._universeTrafficLoaded = G._universeTrafficLoaded or false
G.GalaxyNews = G.GalaxyNews or {}
G.GalaxyLanes = G.GalaxyLanes or {}
G.GalaxyBattles = G.GalaxyBattles or {}
G.GalaxyDistress = G.GalaxyDistress or {}
G.GalaxyEconomy = G.GalaxyEconomy or {}
G.GalaxySimulationDirty = G.GalaxySimulationDirty or false
G.NextLivingGalaxySimulationAt = G.NextLivingGalaxySimulationAt or 0
G.NextLivingGalaxySaveAt = G.NextLivingGalaxySaveAt or 0
G._livingGalaxyLoaded = G._livingGalaxyLoaded or false
G.BackgroundBattles = G.BackgroundBattles or {}
G.NextBackgroundBattleAt = G.NextBackgroundBattleAt or 0
G.ActiveRepublicFleet = G.ActiveRepublicFleet or nil
G.PendingRepublicFleet = G.PendingRepublicFleet or nil
G.OrbitalBlockades = G.OrbitalBlockades or {}
G.ActiveOrbitalBlockade = G.ActiveOrbitalBlockade or nil
G.NextOrbitalBlockadeCheck = G.NextOrbitalBlockadeCheck or 0

local factionNames = {
	republic = "GALACTIC REPUBLIC",
	civilian = "CIVILIAN",
	pirate = "PIRATE / UNALIGNED",
	cis = "CONFEDERACY OF INDEPENDENT SYSTEMS",
	neutral = "UNIDENTIFIED",
}

local cargoPools = {
	"medical supplies", "food and relief packages", "industrial components",
	"refined fuel cells", "passenger berths", "agricultural machinery",
	"replacement starship parts", "sealed diplomatic containers",
}

local contrabandPools = {
	"unregistered weapons", "stolen Republic munitions", "counterfeit transponders",
	"restricted droid components", "spice concealed behind a false bulkhead",
	"encrypted CIS datacores",
}

local destinationPools = {
	"the nearest neutral trade route", "a Republic-controlled refuelling point",
	"a protected civilian hyperspace lane", "the next inhabited system",
	"a scheduled rendezvous beyond the sector",
}

local function chooseKnownDestination(origin)
	local candidates = {}
	local originKey = G.PlanetKey and G.PlanetKey(origin or "") or ""
	for key, planet in pairs(G.Planets or {}) do
		if key ~= originKey and planet and planet.name and G.UniversePositions[key] then
			candidates[#candidates + 1] = planet.name
		end
	end
	if #candidates > 0 then return candidates[math.random(#candidates)] end
	return destinationPools[math.random(#destinationPools)]
end

local function unix()
	return os.time()
end

local function operatorName(ply)
	if not IsValid(ply) then return "Republic crew" end
	return ply.MBName and ply:MBName() or ply:Nick()
end

local function writeCompressed(name, data, target)
	if not IsValid(target) then return end
	local raw = util.TableToJSON(data or {})
	local compressed = util.Compress(raw)
	net.Start(name)
		net.WriteUInt(#compressed, 24)
		net.WriteData(compressed, #compressed)
	net.Send(target)
end

local function expansionLog(text, color)
	MsgC(color or Color(105, 195, 245), "[Galaxy Expansion] ",
		color_white, tostring(text) .. "\n")
end

local function announce(text, color)
	if G.AnnounceNavy then
		G.AnnounceNavy(text, color or Color(105, 195, 245), "[GALAXY] ")
	end
end

local function pingCommunications()
	local sound = tostring(gd.CommsPingSound or "buttons/blip1.wav")
	if sound == "" then return end
	for _, terminal in ipairs(ents.FindByClass("mb_galaxy_comms")) do
		if IsValid(terminal) then
			terminal:EmitSound(sound,
				math.Clamp(tonumber(gd.CommsPingSoundLevel) or 72, 40, 120),
				106, 0.72, CHAN_AUTO)
		end
	end
end

local function runQueries(queries, index, onDone)
	index = index or 1
	if index > #queries then
		if onDone then onDone() end
		return
	end
	MilBase.DB.Query(queries[index], function()
		runQueries(queries, index + 1, onDone)
	end, function()
		runQueries(queries, index + 1, onDone)
	end)
end

function G.SaveExpansionState()
	local value = util.TableToJSON({
		charges = G.Support.charges,
		nextRecharge = G.Support.nextRecharge,
	})
	MilBase.DB.Run("REPLACE INTO frontier_galaxy_expansion_state "
		.. "(state_key, state_value) VALUES ('support', "
		.. MilBase.SQLStr(value) .. ")")
end

function G.SaveOrbitalBlockades()
	if not G._expansionDatabaseInitializing then return end
	local saved = {}
	for key, blockade in pairs(G.OrbitalBlockades or {}) do
		if istable(blockade) and (blockade.faction == "republic" or blockade.faction == "cis") then
			saved[G.CleanText(key, 96)] = {
				planet = G.CleanText(blockade.planet, 96),
				faction = blockade.faction,
				persistent = blockade.persistent == true,
				createdAt = math.floor(tonumber(blockade.createdAt) or unix()),
				updatedAt = math.floor(tonumber(blockade.updatedAt) or unix()),
				reason = G.CleanText(blockade.reason, 180),
			}
		end
	end
	MilBase.DB.Run("REPLACE INTO frontier_galaxy_expansion_state "
		.. "(state_key, state_value) VALUES ('orbital_blockades', "
		.. MilBase.SQLStr(util.TableToJSON(saved)) .. ")")
end

function G.SaveUniverseTraffic()
	if not G._expansionDatabaseInitializing or not G._universeTrafficLoaded then return end
	local saved = {}
	for id, record in pairs(G.UniverseTraffic or {}) do
		if istable(record) and record.id == id then
			saved[id] = {
				id = G.CleanText(record.id, 80),
				name = G.CleanText(record.name, 96),
				role = G.CleanText(record.role, 32),
				faction = G.CleanText(record.faction, 24),
				state = G.CleanText(record.state, 24),
				locationKey = G.CleanText(record.locationKey, 96),
				originKey = G.CleanText(record.originKey, 96),
				destinationKey = G.CleanText(record.destinationKey, 96),
				nextDestinationKey = G.CleanText(record.nextDestinationKey, 96),
				assignment = G.CleanText(record.assignment, 32),
				homeKey = G.CleanText(record.homeKey, 96),
				routeAnchorKey = G.CleanText(record.routeAnchorKey, 96),
				fleetID = G.CleanText(record.fleetID, 96),
				cargoKey = G.CleanText(record.cargoKey, 32),
				cargo = G.CleanText(record.cargo, 160),
				cargoValue = math.max(1, math.floor(tonumber(record.cargoValue) or 1)),
				stationed = record.stationed == true,
				bornAt = math.floor(tonumber(record.bornAt) or unix()),
				departAt = math.floor(tonumber(record.departAt) or 0),
				departedAt = math.floor(tonumber(record.departedAt) or 0),
				arrivalAt = math.floor(tonumber(record.arrivalAt) or 0),
			}
		end
	end
	local value = util.TableToJSON({ savedAt = unix(), records = saved })
	MilBase.DB.Run("REPLACE INTO frontier_galaxy_expansion_state "
		.. "(state_key, state_value) VALUES ('universe_traffic', "
		.. MilBase.SQLStr(value) .. ")")
	G.UniverseTrafficDirty = false
	G.NextUniverseTrafficSaveAt = unix()
		+ math.max(15, tonumber(gd.GalaxyTrafficSaveInterval) or 60)
end

function G.SaveTrackedUniverseTraffic()
	if not G._expansionDatabaseInitializing then return end
	local saved = {}
	for id, tracking in pairs(G.TrackedUniverseTraffic or {}) do
		if G.UniverseTraffic[id] and istable(tracking) then
			saved[id] = {
				trackedAt = math.floor(tonumber(tracking.trackedAt) or unix()),
				trackedBy = G.CleanText(tracking.trackedBy, 96),
			}
		end
	end
	MilBase.DB.Run("REPLACE INTO frontier_galaxy_expansion_state "
		.. "(state_key, state_value) VALUES ('universe_traffic_tracking', "
		.. MilBase.SQLStr(util.TableToJSON(saved)) .. ")")
end

function G.SaveLivingGalaxySimulation()
	if not G._expansionDatabaseInitializing or not G._livingGalaxyLoaded then return end
	local value = util.TableToJSON({
		news = G.GalaxyNews or {},
		lanes = G.GalaxyLanes or {},
		battles = G.GalaxyBattles or {},
		distress = G.GalaxyDistress or {},
		economy = G.GalaxyEconomy or {},
	})
	MilBase.DB.Run("REPLACE INTO frontier_galaxy_expansion_state "
		.. "(state_key, state_value) VALUES ('living_galaxy', "
		.. MilBase.SQLStr(value) .. ")")
	G.GalaxySimulationDirty = false
	G.NextLivingGalaxySaveAt = unix()
		+ math.max(20, tonumber(gd.GalaxyTrafficSaveInterval) or 60)
end

function G.SaveContactMemory(memory)
	if not memory or not memory.key then return end
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_contacts "
			.. "(contact_key, ship_name, faction, trust, meetings, helped, threatened, "
			.. "last_seen, memory_json) VALUES (%s, %s, %s, %d, %d, %d, %d, %d, %s)",
		MilBase.SQLStr(memory.key), MilBase.SQLStr(memory.name),
		MilBase.SQLStr(memory.faction), math.Clamp(math.floor(memory.trust or 0), -100, 100),
		math.max(0, math.floor(memory.meetings or 0)),
		math.max(0, math.floor(memory.helped or 0)),
		math.max(0, math.floor(memory.threatened or 0)),
		math.floor(memory.lastSeen or unix()),
		MilBase.SQLStr(util.TableToJSON(memory.notes or {}))))
end

function G.AddCommsHistory(direction, ship, summary, ply)
	local faction = IsValid(ship) and (ship.mb_galaxyTrueFaction or ship:GetFaction()) or "neutral"
	local name = IsValid(ship) and ship:GetShipName() or "Republic Command"
	local item = {
		time = unix(),
		direction = G.CleanText(direction, 16),
		contact = G.CleanText(name, 96),
		faction = G.CleanText(faction, 24),
		summary = G.CleanText(summary, 500),
		operator = operatorName(ply),
		planet = G.CleanText(G.State.currentPlanet, 96),
	}
	table.insert(G.CommsHistory, 1, item)
	while #G.CommsHistory > math.max(5, tonumber(gd.CommsHistoryLimit) or 40) do
		table.remove(G.CommsHistory)
	end
	MilBase.DB.Run(string.format(
		"INSERT INTO frontier_galaxy_comms_history "
			.. "(event_time, direction_name, contact_name, faction, summary, "
			.. "operator_name, planet_key) VALUES (%d, %s, %s, %s, %s, %s, %s)",
		item.time, MilBase.SQLStr(item.direction), MilBase.SQLStr(item.contact),
		MilBase.SQLStr(item.faction), MilBase.SQLStr(item.summary),
		MilBase.SQLStr(item.operator), MilBase.SQLStr(G.PlanetKey(item.planet))))
end

function G.AddIntel(kind, title, details, source, confidence, followup)
	local item = {
		time = unix(),
		expires = unix() + math.max(60, tonumber(gd.IntelLifetime) or 1800),
		kind = G.CleanText(kind, 32),
		title = G.CleanText(title, 128),
		details = G.CleanText(details, 700),
		source = G.CleanText(source, 128),
		confidence = math.Clamp(math.floor(tonumber(confidence) or 50), 0, 100),
		planet = G.CleanText(G.State.currentPlanet, 96),
		followup = G.CleanText(followup, 32),
	}
	table.insert(G.IntelRecords, 1, item)
	while #G.IntelRecords > math.max(5, tonumber(gd.IntelRecordLimit) or 30) do
		table.remove(G.IntelRecords)
	end
	G.State.intelUntil = CurTime() + math.max(60, tonumber(gd.IntelLifetime) or 1800)
	G.State.intelText = item.title .. ": " .. item.details
	MilBase.DB.Run(string.format(
		"INSERT INTO frontier_galaxy_intel "
			.. "(created_at, expires_at, planet_key, intel_kind, title, details, "
			.. "source_name, confidence, followup_kind) VALUES "
			.. "(%d, %d, %s, %s, %s, %s, %s, %d, %s)",
		item.time, item.expires, MilBase.SQLStr(G.PlanetKey(item.planet)),
		MilBase.SQLStr(item.kind), MilBase.SQLStr(item.title),
		MilBase.SQLStr(item.details), MilBase.SQLStr(item.source),
		item.confidence, MilBase.SQLStr(item.followup)))
	if followup and followup ~= "" then
		G.IntelLead = {
			kind = followup,
			source = item.source,
			details = item.details,
			readyAt = CurTime() + math.Rand(45, 90),
			expiresAt = CurTime() + 900,
		}
	end
	G.BroadcastState()
	return item
end

function G.InitializeExpansionDatabase()
	if G._expansionDatabaseInitializing then return end
	G._expansionDatabaseInitializing = true
	-- The living-galaxy simulation keeps its complete news, route, battle,
	-- distress and economy state in one record.  A normal TEXT/VARCHAR column
	-- eventually fills up as the simulated galaxy grows, so MySQL needs its
	-- larger LONGTEXT type here. SQLite's TEXT field is already unbounded.
	local stateValueType = MilBase.DB.IsMySQL() and "LONGTEXT" or "TEXT"
	local queries = {
		[[CREATE TABLE IF NOT EXISTS frontier_galaxy_contacts (
			contact_key VARCHAR(160) PRIMARY KEY,
			ship_name VARCHAR(128),
			faction VARCHAR(24),
			trust INTEGER,
			meetings INTEGER,
			helped INTEGER,
			threatened INTEGER,
			last_seen INTEGER,
			memory_json TEXT
		)]],
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_comms_history ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", event_time INTEGER, "
			.. "direction_name VARCHAR(16), contact_name VARCHAR(128), "
			.. "faction VARCHAR(24), summary TEXT, operator_name VARCHAR(128), "
			.. "planet_key VARCHAR(96))",
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_intel ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", created_at INTEGER, "
			.. "expires_at INTEGER, planet_key VARCHAR(96), intel_kind VARCHAR(32), "
			.. "title VARCHAR(128), details TEXT, source_name VARCHAR(128), "
			.. "confidence INTEGER, followup_kind VARCHAR(32))",
		[[CREATE TABLE IF NOT EXISTS frontier_galaxy_expansion_state (
			state_key VARCHAR(64) PRIMARY KEY,
			state_value ]] .. stateValueType .. [[
		)]],
	}
	-- CREATE TABLE does not alter existing installations. Upgrade the old
	-- state_value column before loading or saving the living-galaxy record.
	if MilBase.DB.IsMySQL() then
		queries[#queries + 1] = "ALTER TABLE frontier_galaxy_expansion_state "
			.. "MODIFY COLUMN state_value LONGTEXT"
	end
	runQueries(queries, 1, function()
		MilBase.DB.Query("SELECT * FROM frontier_galaxy_contacts "
			.. "ORDER BY last_seen DESC LIMIT "
			.. math.max(10, tonumber(gd.ContactMemoryLimit) or 250), function(rows)
			for _, row in ipairs(rows) do
				local key = tostring(row.contact_key or "")
				if key ~= "" then
					G.ContactMemory[key] = {
						key = key,
						name = G.CleanText(row.ship_name, 96),
						faction = G.CleanText(row.faction, 24),
						trust = math.Clamp(tonumber(row.trust) or 0, -100, 100),
						meetings = math.max(0, tonumber(row.meetings) or 0),
						helped = math.max(0, tonumber(row.helped) or 0),
						threatened = math.max(0, tonumber(row.threatened) or 0),
						lastSeen = tonumber(row.last_seen) or 0,
						notes = util.JSONToTable(tostring(row.memory_json or "")) or {},
					}
				end
			end
		end)
		MilBase.DB.Query("SELECT * FROM frontier_galaxy_comms_history "
			.. "ORDER BY id DESC LIMIT "
			.. math.max(5, tonumber(gd.CommsHistoryLimit) or 40), function(rows)
			G.CommsHistory = {}
			for _, row in ipairs(rows) do
				G.CommsHistory[#G.CommsHistory + 1] = {
					time = tonumber(row.event_time) or 0,
					direction = G.CleanText(row.direction_name, 16),
					contact = G.CleanText(row.contact_name, 96),
					faction = G.CleanText(row.faction, 24),
					summary = G.CleanText(row.summary, 500),
					operator = G.CleanText(row.operator_name, 96),
					planet = G.CleanText(row.planet_key, 96),
				}
			end
		end)
		MilBase.DB.Query("SELECT * FROM frontier_galaxy_intel WHERE expires_at > "
			.. unix() .. " ORDER BY id DESC LIMIT "
			.. math.max(5, tonumber(gd.IntelRecordLimit) or 30), function(rows)
			G.IntelRecords = {}
			for _, row in ipairs(rows) do
				G.IntelRecords[#G.IntelRecords + 1] = {
					time = tonumber(row.created_at) or 0,
					expires = tonumber(row.expires_at) or 0,
					planet = G.CleanText(row.planet_key, 96),
					kind = G.CleanText(row.intel_kind, 32),
					title = G.CleanText(row.title, 128),
					details = G.CleanText(row.details, 700),
					source = G.CleanText(row.source_name, 128),
					confidence = math.Clamp(tonumber(row.confidence) or 0, 0, 100),
					followup = G.CleanText(row.followup_kind, 32),
				}
			end
		end)
		MilBase.DB.Query("SELECT state_value FROM frontier_galaxy_expansion_state "
			.. "WHERE state_key = 'support'", function(rows)
			local data = rows[1] and util.JSONToTable(tostring(rows[1].state_value or ""))
			if istable(data) then
				G.Support.charges = math.Clamp(tonumber(data.charges)
					or G.Support.charges, 0,
					math.max(1, tonumber(gd.ReinforcementMaximum) or 3))
				G.Support.nextRecharge = tonumber(data.nextRecharge)
					or G.Support.nextRecharge
			end
		end)
		MilBase.DB.Query("SELECT state_value FROM frontier_galaxy_expansion_state "
			.. "WHERE state_key = 'orbital_blockades'", function(rows)
			local data = rows[1] and util.JSONToTable(tostring(rows[1].state_value or ""))
			if istable(data) then
				G.OrbitalBlockades = {}
				for key, blockade in pairs(data) do
					if istable(blockade) and (blockade.faction == "republic"
						or blockade.faction == "cis") then
						local cleanKey = G.CleanText(key, 96)
						if cleanKey ~= "" then
							G.OrbitalBlockades[cleanKey] = {
								planet = G.CleanText(blockade.planet, 96),
								faction = blockade.faction,
								persistent = blockade.persistent == true,
								createdAt = math.floor(tonumber(blockade.createdAt) or unix()),
								updatedAt = math.floor(tonumber(blockade.updatedAt) or unix()),
								reason = G.CleanText(blockade.reason, 180),
							}
						end
					end
				end
			end
			G._orbitalBlockadesLoaded = true
			if G.BroadcastAdminData then G.BroadcastAdminData() end
		end)
		MilBase.DB.Query("SELECT state_value FROM frontier_galaxy_expansion_state "
			.. "WHERE state_key = 'universe_traffic'", function(rows)
			local data = rows[1] and util.JSONToTable(tostring(rows[1].state_value or ""))
			G.UniverseTraffic = {}
			if istable(data) and istable(data.records) then
				for id, record in pairs(data.records) do
					if istable(record) then
						local cleanID = G.CleanText(record.id or id, 80)
						local faction = string.lower(G.CleanText(record.faction, 24))
						local role = string.lower(G.CleanText(record.role, 32))
						if cleanID ~= "" and (faction == "republic" or faction == "cis"
							or faction == "civilian" or faction == "pirate")
						and (role == "republic" or role == "cis_scout"
							or role == "civilian" or role == "pirate") then
							G.UniverseTraffic[cleanID] = {
								id = cleanID,
								name = G.CleanText(record.name, 96),
								role = role,
								faction = faction,
								state = G.CleanText(record.state, 24),
								locationKey = G.CleanText(record.locationKey, 96),
								originKey = G.CleanText(record.originKey, 96),
								destinationKey = G.CleanText(record.destinationKey, 96),
								nextDestinationKey = G.CleanText(record.nextDestinationKey, 96),
								assignment = G.CleanText(record.assignment, 32),
								homeKey = G.CleanText(record.homeKey, 96),
								routeAnchorKey = G.CleanText(record.routeAnchorKey, 96),
								fleetID = G.CleanText(record.fleetID, 96),
								cargoKey = G.CleanText(record.cargoKey, 32),
								cargo = G.CleanText(record.cargo, 160),
								cargoValue = math.max(1, math.floor(tonumber(record.cargoValue) or 1)),
								stationed = record.stationed == true,
								bornAt = math.floor(tonumber(record.bornAt) or unix()),
								departAt = math.floor(tonumber(record.departAt) or 0),
								departedAt = math.floor(tonumber(record.departedAt) or 0),
								arrivalAt = math.floor(tonumber(record.arrivalAt) or 0),
							}
						end
					end
				end
			end
			G._universeTrafficLoaded = true
			G.UniverseTrafficDirty = false
			if G.UpdateUniverseTraffic then G.UpdateUniverseTraffic(unix(), true) end
		end)
		MilBase.DB.Query("SELECT state_value FROM frontier_galaxy_expansion_state "
			.. "WHERE state_key = 'universe_traffic_tracking'", function(rows)
			local data = rows[1] and util.JSONToTable(tostring(rows[1].state_value or ""))
			G.TrackedUniverseTraffic = {}
			if istable(data) then
				for id, tracking in pairs(data) do
					if G.UniverseTraffic[id] and istable(tracking) then
						G.TrackedUniverseTraffic[id] = {
							trackedAt = math.floor(tonumber(tracking.trackedAt) or unix()),
							trackedBy = G.CleanText(tracking.trackedBy, 96),
						}
					end
				end
			end
		end)
		MilBase.DB.Query("SELECT state_value FROM frontier_galaxy_expansion_state "
			.. "WHERE state_key = 'living_galaxy'", function(rows)
			local data = rows[1] and util.JSONToTable(tostring(rows[1].state_value or ""))
			data = istable(data) and data or {}
			G.GalaxyNews = istable(data.news) and data.news or {}
			G.GalaxyLanes = istable(data.lanes) and data.lanes or {}
			G.GalaxyBattles = istable(data.battles) and data.battles or {}
			G.GalaxyDistress = istable(data.distress) and data.distress or {}
			G.GalaxyEconomy = istable(data.economy) and data.economy or {}
			G._livingGalaxyLoaded = true
			G.GalaxySimulationDirty = false
			if G.UpdateLivingGalaxySimulation then G.UpdateLivingGalaxySimulation(unix(), true) end
		end)
		expansionLog("Persistent contacts, intelligence and communications history ready.",
			Color(120, 225, 145))
	end)
end

hook.Add("MilBase.DBReady", "MilBase.GalaxyExpansionDatabase", function()
	timer.Simple(0, G.InitializeExpansionDatabase)
end)

local function contactKey(name, faction)
	return G.PlanetKey(name) .. "|" .. string.lower(tostring(faction or "neutral"))
end

function G.ContactForShip(ship)
	if not IsValid(ship) then return nil end
	local trueFaction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local key = ship.mb_galaxyContactKey or contactKey(ship:GetShipName(), trueFaction)
	ship.mb_galaxyContactKey = key
	local memory = G.ContactMemory[key]
	if not memory then
		memory = {
			key = key,
			name = G.CleanText(ship:GetShipName(), 96),
			faction = G.CleanText(trueFaction, 24),
			trust = 0,
			meetings = 0,
			helped = 0,
			threatened = 0,
			lastSeen = unix(),
			notes = {},
		}
		G.ContactMemory[key] = memory
	end
	return memory
end

function G.ChangeContactTrust(ship, amount, reason)
	local memory = G.ContactForShip(ship)
	if not memory then return end
	memory.trust = math.Clamp((memory.trust or 0) + math.floor(tonumber(amount) or 0),
		-100, 100)
	memory.lastSeen = unix()
	if amount > 0 then memory.helped = (memory.helped or 0) + 1 end
	if amount < 0 then memory.threatened = (memory.threatened or 0) + 1 end
	if reason and reason ~= "" then
		memory.notes = memory.notes or {}
		table.insert(memory.notes, 1, {
			time = unix(),
			text = G.CleanText(reason, 180),
		})
		while #memory.notes > 8 do table.remove(memory.notes) end
	end
	G.SaveContactMemory(memory)
end

local function randomClaimedFaction(trueFaction)
	if trueFaction == "pirate" then
		return math.random(4) == 1 and "republic" or "civilian"
	elseif trueFaction == "cis" then
		return math.random(3) == 1 and "republic" or "civilian"
	elseif trueFaction == "civilian" then
		return math.random(2) == 1 and "republic" or "neutral"
	elseif trueFaction == "republic" then
		return "civilian"
	end
	return "neutral"
end

function G.InitializeShipIdentity(ship, opts)
	if not IsValid(ship) then return end
	if ship.mb_galaxyIdentityReady then
		G.RepairShipName(ship, ship.mb_galaxyTrueFaction or ship:GetFaction())
		return
	end
	opts = opts or {}
	ship.mb_galaxyIdentityReady = true
	ship.mb_galaxyAllowCrossFactionName = opts.allowCrossFactionName == true
		or ship.mb_galaxyAllowCrossFactionName == true
	ship.mb_galaxyTrueFaction = string.lower(tostring(opts.trueFaction
		or ship:GetFaction() or "neutral"))
	ship.mb_galaxyContactCode = string.format("%03X", ship:EntIndex() % 4096)
	ship.mb_galaxyRareType = opts.expansionType
	ship.mb_galaxyTrafficPattern = opts.trafficPattern
	ship.mb_galaxyDistantTraffic = opts.distantTraffic == true
	ship.mb_galaxyCargo = opts.cargo or cargoPools[math.random(#cargoPools)]
	ship.mb_galaxyOrigin = opts.origin or ((G.State and G.State.currentPlanet)
		or "the local orbital lane")
	ship.mb_galaxyDestination = opts.destination
		or chooseKnownDestination(ship.mb_galaxyOrigin)
	ship.mb_galaxyRouteStatus = opts.routeStatus or "cleared for local transit"
	ship.mb_galaxyRouteKind = opts.routeKind or "transit"
	ship.mb_galaxyWeapons = opts.weapons
		or (ship:GetCapital() and "capital turbolaser batteries"
			or ship:GetHostile() and "armed combat-grade energy weapons"
			or ship.mb_galaxyTrueFaction == "republic" and "Republic defensive batteries"
			or "light defensive armament")
	ship.mb_galaxySignalNoise = math.Rand(0, 18)
	ship.mb_galaxyTransponderFaction = opts.transponderFaction
		or ship.mb_galaxyTrueFaction
	local falseChance = tonumber((gd.FakeTransponderChance or {})
		[ship.mb_galaxyTrueFaction]) or 0
	if not opts.transponderFaction and math.Rand(0, 1) < falseChance then
		ship.mb_galaxyTransponderFaction = randomClaimedFaction(ship.mb_galaxyTrueFaction)
	end
	-- The public networked faction is the claimed transponder identity, so an
	-- unscanned contact's engine glow does not reveal a spoof. Server combat
	-- and diplomacy always use mb_galaxyTrueFaction.
	ship:SetFaction(ship.mb_galaxyTransponderFaction)
	ship.mb_galaxyManifestLegal = opts.manifestLegal
	if ship.mb_galaxyManifestLegal == false and not opts.cargo then
		ship.mb_galaxyCargo = contrabandPools[math.random(#contrabandPools)]
	end
	G.RepairShipName(ship, ship.mb_galaxyTrueFaction)
	G.ContactForShip(ship)
end

local baseSpawnShip = G.SpawnShip
function G.SpawnShip(role, opts)
	local ship = baseSpawnShip(role, opts)
	if IsValid(ship) then G.InitializeShipIdentity(ship, opts) end
	return ship
end

for _, existingShip in ipairs(ents.FindByClass("mb_galaxy_ship")) do
	G.InitializeShipIdentity(existingShip)
end

local function systemCategory(node)
	local name = string.lower(node.GetSystemName and node:GetSystemName() or "")
	if string.find(name, "engine", 1, true) then return "engines" end
	if string.find(name, "maneuver", 1, true) then return "maneuver" end
	if string.find(name, "hyper", 1, true) then return "hyperdrive" end
	if string.find(name, "map", 1, true) then return "sensors" end
	return "general"
end

function G.ShipSystemSnapshot()
	local totals, online = {}, {}
	for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
		local category = systemCategory(node)
		totals[category] = (totals[category] or 0) + 1
		if not node:GetBroken() then online[category] = (online[category] or 0) + 1 end
	end
	local function condition(category)
		local total = totals[category] or 0
		local physical = total > 0 and ((online[category] or 0) / total * 100) or 100
		return math.Clamp(math.floor(physical
			- (tonumber(G.SystemDisruption[category]) or 0)), 0, 100)
	end
	local hangar = 100
	if G.Active and G.Active.kind == "cis_raid" then
		hangar = G.Active.phase == "boarding" and 0
			or G.Active.phase == "breach" and 35 or 100
	end
	return {
		sensors = condition("sensors"),
		communications = condition("communications"),
		weapons = condition("weapons"),
		engines = condition("engines"),
		maneuver = condition("maneuver"),
		hyperdrive = condition("hyperdrive"),
		shields = condition("shields"),
		hangar = hangar,
	}
end

function G.DamageShipSystem(category, amount, reason)
	if G.SystemDisruption[category] == nil then G.SystemDisruption[category] = 0 end
	local before = G.SystemDisruption[category]
	G.SystemDisruption[category] = math.Clamp(before
		+ math.max(0, tonumber(amount) or 0), 0, 100)
	if G.SystemDisruption[category] > before then
		announce(string.upper(category) .. " disrupted"
			.. (reason and (": " .. G.CleanText(reason, 160)) or "."),
			Color(235, 155, 65))
		G.BroadcastState()
	end
end

local function pointSegmentDistance(point, startPos, endPos)
	local line = endPos - startPos
	local length = line:LengthSqr()
	if length <= 0.01 then return point:Distance(startPos) end
	local fraction = math.Clamp((point - startPos):Dot(line) / length, 0, 1)
	return point:Distance(startPos + line * fraction)
end

function G.ContactSignalStrength(ship)
	if not IsValid(ship) then return 0 end
	local center, radius = G.SkyboxFrame()
	local distance = math.Clamp(ship:GetPos():Distance(center)
		/ math.max(1, radius), 0, 1.5)
	local systems = G.ShipSystemSnapshot()
	local value = 104 - distance * 42 - (ship.mb_galaxySignalNoise or 0)
	value = value * (0.45 + systems.sensors / 100 * 0.35
		+ systems.communications / 100 * 0.2)
	if ship:GetCombat() then value = value - 8 end
	if G.Active and (G.Active.kind == "cis" or G.Active.kind == "cis_raid") then
		value = value - 10
	end
	for _, planet in ipairs(G.GetPlanetObstacles and G.GetPlanetObstacles() or {}) do
		local pos = G.PlanetWorldPosition and G.PlanetWorldPosition(planet)
		local obstacleRadius = G.PlanetObstacleRadius and G.PlanetObstacleRadius(planet) or 0
		if isvector(pos) and obstacleRadius > 0
		and pointSegmentDistance(pos, center, ship:GetPos()) < obstacleRadius then
			value = value - 24
			break
		end
	end
	return math.Clamp(math.floor(value), 0, 100)
end

local function validContact(ship)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return false end
	if ship:GetShipState() == "destroyed" or ship:GetHull() <= 0 then return false end
	if ship.mb_galaxyMapSpace then return util.IsInWorld(ship:GetPos()) end
	return not G.IsInsideSkybox or G.IsInsideSkybox(ship:GetPos())
end

function G.CanTargetSkyboxContact(ship)
	if not validContact(ship) or ship.mb_galaxyMapSpace then return false end
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	return faction == "cis" or faction == "pirate"
end

local function canAuthorizeSkyboxVolley(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if gd.SkyboxVolleyRequireAuthorization ~= true then return true end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	if ply.MBHasCert and (ply:MBHasCert("fleet_operator")
		or ply:MBHasCert("high_command")) then return true end
	return MilBase.CommsIsHighCommand and MilBase.CommsIsHighCommand(ply) == true
end

function G.RequestSkyboxVolley(ply, ship)
	if ply ~= G.GunnerOperator or not G.GunnerSessionValid(ply, G.GunnerTerminal) then
		return false, "Use the long-range fire-control terminal to operate the batteries."
	end
	if gd.SkyboxFireControlEnabled == false then
		return false, "Long-range skybox fire control is disabled."
	end
	if not G.CanTargetSkyboxContact(ship) then
		return false, "Only scanned CIS or pirate contacts inside the skybox can be targeted."
	end
	if G.ScannedShips[ship] ~= true then
		return false, "Complete a sensor scan before authorising skybox fire."
	end
	if not canAuthorizeSkyboxVolley(ply) then
		return false, "Fleet Fire Control or High Command authorisation is required."
	end
	if G.ShipSystemSnapshot().weapons < 20 then
		return false, "Weapons control is too damaged to lock a skybox contact."
	end
	local signal = G.ContactSignalStrength(ship)
	if signal < math.max(1, tonumber(gd.SkyboxVolleyMinimumSignal) or 18) then
		return false, "Target signal is too weak for a stable firing solution."
	end
	if CurTime() < (G.NextSkyboxVolleyAt or 0) then
		return false, "Long-range batteries recharging: "
			.. G.FormatDuration(G.NextSkyboxVolleyAt - CurTime())
	end

	G.NextSkyboxVolleyAt = CurTime()
		+ math.max(4, tonumber(gd.SkyboxVolleyCooldown) or 32)
	G.LastSkyboxVolleyTarget = ship
	ship:SetInvulnerable(false)
	ship:SetHostile(true)
	if (ship.mb_galaxyTrueFaction or ship:GetFaction()) == "cis"
	and G.PrepareCISCombatShip then
		G.PrepareCISCombatShip(ship)
	elseif ship.RefreshCombatCollision then
		ship:RefreshCombatCollision(gd.CISUseModelCollision ~= false)
	end
	ship:SetShipState("under Republic long-range fire")

	local shots = math.max(1, math.floor(tonumber(gd.SkyboxVolleyShots) or 4))
	local totalDamage = math.max(1, tonumber(gd.SkyboxVolleyDamage) or 1100)
	local damagePerShot = totalDamage / shots
	local origins = G.RepublicBatteryOrigins
		and G.RepublicBatteryOrigins(ship, shots) or {}
	for index = 1, shots do
		timer.Simple((index - 1) * math.max(0.12,
			tonumber(gd.SkyboxVolleyShotInterval) or 0.3), function()
			if not validContact(ship) then return end
			local start = origins[index] or select(1, G.SkyboxFrame())
			local impact = ship:WorldSpaceCenter() + VectorRand()
				* math.max(12, tonumber(ship:GetCombatRadius()) or 40) * 0.3
			G.EmitLaser(start, impact, Color(75, 150, 255), 6)
			local info = DamageInfo()
			info:SetDamage(damagePerShot)
			info:SetAttacker(ply)
			info:SetInflictor(IsValid(G.GunnerTerminal) and G.GunnerTerminal or ply)
			info:SetDamagePosition(impact)
			info:SetDamageType(DMG_ENERGYBEAM)
			ship.mb_galaxyFleetVolleyDamage = true
			ship:TakeDamageInfo(info)
			if IsValid(ship) then ship.mb_galaxyFleetVolleyDamage = nil end
		end)
	end
	G.AddCommsHistory("outgoing", ship,
		"Republic long-range batteries fired on the scanned skybox contact.", ply)
	announce("Republic long-range batteries are engaging " .. ship:GetShipName()
		.. " in the skybox.", Color(80, 155, 240))
	G.Audit(ply, "fired skybox volley", ship:GetShipName())
	G.BroadcastState()
	return true, "Long-range volley fired on " .. ship:GetShipName() .. "."
end

local function validateSkyboxOrdnance(ply, ship, kind)
	local definition = G.OrdnanceDefinition and G.OrdnanceDefinition(kind)
	if not definition or ply ~= G[definition.operator]
		or not G.OrdnanceSessionValid(ply, G[definition.terminal], kind) then
		return false, "Use the correct ordnance-control terminal to operate that weapon."
	end
	if gd.SkyboxFireControlEnabled == false then
		return false, "Long-range skybox fire control is disabled."
	end
	if not G.CanTargetSkyboxContact(ship) then
		return false, "Only scanned CIS or pirate contacts inside the skybox can be targeted."
	end
	if G.ScannedShips[ship] ~= true then
		return false, "Complete a sensor scan before authorising skybox fire."
	end
	if not canAuthorizeSkyboxVolley(ply) then
		return false, "Fleet Fire Control or High Command authorisation is required."
	end
	if G.ShipSystemSnapshot().weapons < 20 then
		return false, "Weapons control is too damaged to lock a skybox contact."
	end
	if G.ContactSignalStrength(ship) < math.max(1, tonumber(gd.SkyboxVolleyMinimumSignal) or 18) then
		return false, "Target signal is too weak for a stable firing solution."
	end
	return true
end

local function prepareSkyboxTarget(ship)
	ship:SetInvulnerable(false)
	ship:SetHostile(true)
	if (ship.mb_galaxyTrueFaction or ship:GetFaction()) == "cis"
	and G.PrepareCISCombatShip then
		G.PrepareCISCombatShip(ship)
	elseif ship.RefreshCombatCollision then
		ship:RefreshCombatCollision(gd.CISUseModelCollision ~= false)
	end
end

function G.RequestSkyboxOrdnance(ply, ship, kind)
	if kind == "turbolaser" then return G.RequestSkyboxVolley(ply, ship) end
	if kind ~= "ion" and kind ~= "torpedo" then return false, "Unknown ordnance selection." end
	local valid, message = validateSkyboxOrdnance(ply, ship, kind)
	if not valid then return false, message end

	local now = CurTime()
	local cooldownKey = kind == "ion" and "NextIonCannonAt" or "NextTorpedoAt"
	local targetKey = kind == "ion" and "LastIonTarget" or "LastTorpedoTarget"
	local cooldown = kind == "ion" and (tonumber(gd.IonCannonCooldown) or 42)
		or (tonumber(gd.TorpedoCooldown) or 68)
	if now < (G[cooldownKey] or 0) then
		return false, (kind == "ion" and "Ion banks are recharging: "
			or "Torpedo tubes are reloading: ") .. G.FormatDuration(G[cooldownKey] - now)
	end

	G[cooldownKey] = now + math.max(4, cooldown)
	G[targetKey] = ship
	prepareSkyboxTarget(ship)
	local center, radius = G.SkyboxFrame()
	local definition = G.OrdnanceDefinition(kind)
	local terminal = definition and G[definition.terminal] or nil
	if kind == "ion" then
		ship:SetShipState("ion systems disrupted")
		ship.mb_galaxyIonDisabledUntil = math.max(ship.mb_galaxyIonDisabledUntil or 0,
			now + math.max(3, tonumber(gd.IonCannonDisableDuration) or 16))
		local shots = math.max(1, math.floor(tonumber(gd.IonCannonShots) or 3))
		local damage = math.max(1, tonumber(gd.IonCannonShieldDamage) or 1850) / shots
		for index = 1, shots do
			timer.Simple((index - 1) * 0.23, function()
				if not validContact(ship) then return end
				local start = center + VectorRand() * math.min(160, radius * 0.07)
				local impact = ship:WorldSpaceCenter() + VectorRand()
					* math.max(12, tonumber(ship:GetCombatRadius()) or 40) * 0.28
				G.EmitLaser(start, impact, Color(90, 180, 255), 7)
				if ship.GetShield and ship:GetMaxShield() > 0 then
					ship:SetShield(math.max(0, ship:GetShield() - damage))
					ship.mb_galaxyLastCombatDamage = CurTime()
				end
			end)
		end
		G.AddCommsHistory("outgoing", ship,
			"Republic ion cannon discharge disrupted the scanned skybox contact.", ply)
		G.Audit(ply, "fired ion cannon", ship:GetShipName())
		G.BroadcastState()
		return true, "Ion cannon discharge disrupted " .. ship:GetShipName() .. "."
	end

	ship:SetShipState("torpedo lock acquired")
	local flightTime = math.max(0.2, tonumber(gd.TorpedoFlightTime) or 1.15)
	local launch = center + VectorRand() * math.min(140, radius * 0.06)
	G.EmitLaser(launch, ship:WorldSpaceCenter(), Color(255, 185, 75), 9)
	timer.Simple(flightTime, function()
		if not validContact(ship) then return end
		local impact = ship:WorldSpaceCenter() + VectorRand()
			* math.max(12, tonumber(ship:GetCombatRadius()) or 40) * 0.24
		G.EmitLaser(launch, impact, Color(255, 220, 120), 12)
		local info = DamageInfo()
		info:SetDamage(math.max(1, tonumber(gd.TorpedoDamage) or 2350))
		info:SetAttacker(ply)
		info:SetInflictor(IsValid(terminal) and terminal or ply)
		info:SetDamagePosition(impact)
		info:SetDamageType(DMG_BLAST)
		ship.mb_galaxyFleetVolleyDamage = true
		ship:TakeDamageInfo(info)
		if IsValid(ship) then ship.mb_galaxyFleetVolleyDamage = nil end
	end)
	G.AddCommsHistory("outgoing", ship,
		"Republic proton torpedo launched at the scanned skybox contact.", ply)
	G.Audit(ply, "launched proton torpedo", ship:GetShipName())
	G.BroadcastState()
	return true, "Proton torpedo launched at " .. ship:GetShipName() .. "."
end

function G.ExpandedContactSnapshot(ship)
	G.InitializeShipIdentity(ship)
	local scanned = G.ScannedShips[ship] == true
	local trafficID = ship.mb_galaxyUniverseTrafficID
	local trafficRecord = trafficID and G.UniverseTraffic[trafficID] or nil
	local memory = G.ContactForShip(ship)
	local known = scanned or (memory and (memory.meetings or 0) >= 2)
	local trueFaction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local claimed = ship.mb_galaxyTransponderFaction or trueFaction
	local inspections = MilBase.Inspections
	local inspectionFaction = inspections and inspections.PublicFaction
		and inspections.PublicFaction(ship, scanned) or nil
	local visibleFaction = inspectionFaction or (scanned and trueFaction or claimed)
	local identityKnown = not inspections or not inspections.IdentityNameKnown
		or inspections.IdentityNameKnown(ship)
	local maxHull = math.max(1, ship:GetMaxHull())
	local displayName = known and ship:GetShipName()
		or ("CONTACT " .. tostring(ship.mb_galaxyContactCode or ship:EntIndex()))
	return {
		entity = ship:EntIndex(),
		name = G.CleanText(displayName, 96),
		actualName = scanned and identityKnown and G.CleanText(ship:GetShipName(), 96) or "",
		faction = factionNames[visibleFaction] and visibleFaction or "neutral",
		factionName = factionNames[visibleFaction] or factionNames.neutral,
		transponder = factionNames[claimed] or factionNames.neutral,
		role = G.CleanText((inspections and inspections.PublicRole
			and inspections.PublicRole(ship)) or ship:GetRole(), 48),
		state = G.CleanText(ship:GetShipState(), 48),
		hostile = ship:GetHostile(),
		capital = ship:GetCapital(),
		hull = scanned and math.Clamp(ship:GetHull(), 0, maxHull) or nil,
		maxHull = scanned and maxHull or nil,
		shield = scanned and ship.GetShield and ship:GetShield() or nil,
		maxShield = scanned and ship.GetMaxShield and ship:GetMaxShield() or nil,
		scanned = scanned,
		known = known,
		signal = G.ContactSignalStrength(ship),
		signalLabel = G.SignalLabel(G.ContactSignalStrength(ship)),
		relationship = memory and math.Clamp(memory.trust or 0, -100, 100) or 0,
		contactType = (inspections and inspections.PublicContactType
			and inspections.PublicContactType(ship)) or ship.mb_galaxyRareType
			or (ship.mb_galaxySalvage and "salvage")
			or (ship.mb_galaxyConvoy and "convoy")
			or (ship.mb_galaxyRepublicFleet and "fleet")
			or (ship.mb_galaxyBlockade and "blockade")
			or (ship.mb_galaxyOrbitalBlockade and "orbital_blockade") or "",
		contactTypeName = G.ContactTypeNames[(inspections and inspections.PublicContactType
			and inspections.PublicContactType(ship)) or ship.mb_galaxyRareType
			or (ship.mb_galaxySalvage and "salvage")
			or (ship.mb_galaxyConvoy and "convoy")
			or (ship.mb_galaxyRepublicFleet and "fleet")
			or (ship.mb_galaxyBlockade and "blockade")
			or (ship.mb_galaxyOrbitalBlockade and "orbital_blockade") or ""] or "",
		trafficPattern = ship.mb_galaxyTrafficPattern or "",
		trafficPatternName = G.TrafficPatternNames[ship.mb_galaxyTrafficPattern or ""] or "",
		distantTraffic = ship.mb_galaxyDistantTraffic == true,
		origin = scanned and G.CleanText(ship.mb_galaxyOrigin, 96) or "",
		destination = scanned and G.CleanText(ship.mb_galaxyDestination, 128) or "",
		routeStatus = scanned and G.CleanText(ship.mb_galaxyRouteStatus, 128) or "",
		routeKind = scanned and G.CleanText(ship.mb_galaxyRouteKind, 32) or "",
		canTrackRoute = scanned and trafficRecord ~= nil,
		routeTracked = scanned and trafficID and G.TrackedUniverseTraffic[trafficID] ~= nil,
		canSkyboxVolley = scanned and G.CanTargetSkyboxContact(ship),
	}
end

local function trafficPlanetName(key)
	local planet = key and G.Planets and G.Planets[key] or nil
	return planet and planet.name or "unresolved system"
end

local function trafficTimeLabel(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	if seconds < 60 then return "under a minute" end
	if seconds < 3600 then return math.ceil(seconds / 60) .. " min" end
	return math.ceil(seconds / 3600) .. " hr"
end

function G.TrackedUniverseTrafficSnapshot()
	local now = unix()
	local routes = {}
	for id, tracking in pairs(G.TrackedUniverseTraffic or {}) do
		local record = G.UniverseTraffic[id]
		if record then
			local status, origin, destination
			if record.state == "holding" then
				origin = trafficPlanetName(record.locationKey)
				destination = trafficPlanetName(record.nextDestinationKey)
				status = "HOLDING AT " .. origin .. " / NEXT JUMP: " .. destination
					.. " IN " .. trafficTimeLabel((tonumber(record.departAt) or now) - now)
			else
				origin = trafficPlanetName(record.originKey)
				destination = trafficPlanetName(record.destinationKey)
				status = "IN HYPERSPACE: " .. origin .. " → " .. destination
					.. " / ARRIVAL IN " .. trafficTimeLabel((tonumber(record.arrivalAt) or now) - now)
			end
			routes[#routes + 1] = {
				id = id,
				name = G.CleanText(record.name, 96),
				faction = G.CleanText(record.faction, 24),
				role = G.CleanText(record.role, 32),
				state = record.state,
				origin = origin,
				destination = destination,
				status = status,
				trackedAt = tonumber(tracking.trackedAt) or now,
			}
		else
			G.TrackedUniverseTraffic[id] = nil
		end
	end
	table.sort(routes, function(a, b) return a.name < b.name end)
	return routes
end

function G.TrackUniverseTrafficContact(ply, ship)
	if ply ~= G.ScannerOperator or not G.ScannerSessionValid(ply, G.ScannerTerminal) then
		MilBase.Notify(ply, "Use the tactical scanner terminal to track a route.", "warn")
		return false
	end
	if not validContact(ship) or G.ScannedShips[ship] ~= true then
		MilBase.Notify(ply, "Resolve the contact with a full scanner profile first.", "warn")
		return false
	end
	local id = ship.mb_galaxyUniverseTrafficID
	local record = id and G.UniverseTraffic[id] or nil
	if not record then
		MilBase.Notify(ply, "Only persistent galaxy traffic can be route-tracked.", "warn")
		return false
	end
	if G.TrackedUniverseTraffic[id] then
		G.TrackedUniverseTraffic[id] = nil
		G.SaveTrackedUniverseTraffic()
		G.AddCommsHistory("scanner", ship, "Route tracker released.", ply)
		MilBase.Notify(ply, "Route tracker released from " .. ship:GetShipName() .. ".", "info")
		G.SendScannerContacts(ply)
		return true
	end
	local maximum = math.max(1, math.floor(tonumber(gd.GalaxyTrafficMaximumTrackedRoutes) or 3))
	if table.Count(G.TrackedUniverseTraffic) >= maximum then
		MilBase.Notify(ply, "Route tracker capacity reached (" .. maximum .. ").", "warn")
		return false
	end
	G.TrackedUniverseTraffic[id] = { trackedAt = unix(), trackedBy = operatorName(ply) }
	G.SaveTrackedUniverseTraffic()
	G.AddCommsHistory("scanner", ship,
		"Persistent route tracker assigned; Fleet can follow every future jump.", ply)
	MilBase.Notify(ply, "Route tracker locked on " .. ship:GetShipName()
		.. ". Its next destination will remain on Tactical Scanner.", "ok")
	G.SendScannerContacts(ply)
	return true
end

function G.HailableShips()
	local ships = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship) then ships[#ships + 1] = ship end
	end
	table.sort(ships, function(a, b)
		if a:GetHostile() ~= b:GetHostile() then return a:GetHostile() end
		if (G.ScannedShips[a] == true) ~= (G.ScannedShips[b] == true) then
			return G.ScannedShips[a] == true
		end
		return string.lower(a:GetShipName()) < string.lower(b:GetShipName())
	end)
	return ships
end

local function incomingTransmissionChoices(kind, ship)
	if kind == "republic_assistance" then
		local choices = {
			{ id = "request_status", label = "REQUEST SITUATION REPORT" },
			{ id = "offer_assistance", label = "OFFER IMMEDIATE ASSISTANCE" },
		}
		if ship.mb_galaxyBackgroundBattle then
			choices[#choices + 1] = { id = "join_battle", label = "JOIN LOCAL ENGAGEMENT" }
		end
		choices[#choices + 1] = { id = "close", label = "CLOSE CHANNEL" }
		return choices
	end
	return {
		{ id = "reject_surrender_demand", label = "REJECT SURRENDER DEMAND" },
		{ id = "order_withdraw", label = "ORDER IMMEDIATE WITHDRAWAL" },
		{ id = "engage", label = "PREPARE DEFENSIVE ACTION" },
		{ id = "close", label = "CLOSE CHANNEL" },
	}
end

-- Unsolicited transmissions are deliberately exceptional. Ordinary traffic is
-- visible and hailable, but does not keep interrupting the communications
-- operator with flavour chatter.
function G.SendAmbientCommsChatter()
	local ply = G.CommsOperator
	if gd.AmbientCommsChatterEnabled == false or not IsValid(ply)
		or not G.CommsSessionValid(ply, G.CommsTerminal)
		or G.PendingHail or G.HailConversation or G.Active then return false end
	local republicNeedsHelp, cisDemandingSurrender = {}, {}
	local cooldown = math.max(30, tonumber(gd.IncomingShipTransmissionCooldown) or 180)
	local hullThreshold = math.Clamp(tonumber(gd.IncomingRepublicAssistanceHullFraction) or 0.68, 0.1, 0.95)
	for _, ship in ipairs(G.HailableShips()) do
		if (ship.mb_galaxyIncomingTransmissionAt or 0) + cooldown <= CurTime() then
			local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
			local state = string.lower(ship:GetShipState() or "")
			local hullFraction = ship:GetHull() / math.max(1, ship:GetMaxHull())
			if faction == "republic" and (ship.mb_galaxyBackgroundBattle or ship:GetCombat()
			or hullFraction <= hullThreshold or state == "under attack"
			or string.find(state, "damaged", 1, true)) then
				republicNeedsHelp[#republicNeedsHelp + 1] = ship
			elseif faction == "cis" and (ship:GetHostile() or ship:GetCombat()
			or ship.mb_galaxyBackgroundBattle or state == "attacking") then
				cisDemandingSurrender[#cisDemandingSurrender + 1] = ship
			end
		end
	end
	local kind, ship
	if #republicNeedsHelp > 0 and (#cisDemandingSurrender == 0 or math.random(2) == 1) then
		kind, ship = "republic_assistance", republicNeedsHelp[math.random(#republicNeedsHelp)]
	elseif #cisDemandingSurrender > 0
	and math.Rand(0, 1) <= math.Clamp(tonumber(gd.IncomingCISSurrenderDemandChance) or 0.72, 0, 1) then
		kind, ship = "cis_surrender", cisDemandingSurrender[math.random(#cisDemandingSurrender)]
	end
	if not kind or not IsValid(ship) then return false end

	ship.mb_galaxyIncomingTransmissionAt = CurTime()
	local name = G.CleanText(ship:GetShipName(), 96)
	local title, body
	if kind == "republic_assistance" then
		local hull = math.floor(ship:GetHull() / math.max(1, ship:GetMaxHull()) * 100)
		title = "REPUBLIC PRIORITY ASSISTANCE"
		body = name .. " requests Republic aid. \"We are engaged or damaged in this sector; "
			.. "hull integrity is " .. hull .. " percent. Any assistance is appreciated.\""
	else
		title = "CIS SURRENDER DEMAND"
		body = name .. " cuts across the channel with a droid command signal. "
			.. "\"Republic vessel, power down your weapons and prepare to surrender. "
			.. "Resistance will be met with force.\""
	end
	local choices = incomingTransmissionChoices(kind, ship)
	G.HailConversation = {
		operator = ply,
		terminal = G.CommsTerminal,
		ship = ship,
		kind = kind,
		choices = choices,
		startedAt = CurTime(),
		expiresAt = CurTime() + 120,
	}
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "result",
		station = "communications",
		answered = true,
		title = title,
		body = body,
		contact = G.ExpandedContactSnapshot(ship),
		choices = choices,
	}, ply)
	G.AddCommsHistory("incoming", ship, body, ply)
	if IsValid(G.CommsTerminal) then
		G.CommsTerminal:EmitSound(tostring(gd.CommsHailResponseSound or "buttons/button15.wav"),
			68, 96, 0.72, CHAN_AUTO)
	end
	G.UpdateCommsTerminals()
	G.BroadcastState()
	return true
end

function G.SendHailContacts(ply)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
	local contacts = {}
	local maximum = math.max(1, math.floor(tonumber(gd.MaximumHailContacts) or 16))
	if G.PlanetContactSnapshot then
		local planetContact = G.PlanetContactSnapshot(ply)
		if istable(planetContact) then contacts[#contacts + 1] = planetContact end
	end
	for _, ship in ipairs(G.HailableShips()) do
		contacts[#contacts + 1] = G.ExpandedContactSnapshot(ship)
		if #contacts >= maximum then break end
	end
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "contacts",
		station = "communications",
		title = "TACTICAL COMMUNICATIONS",
		body = "Open a private channel with a visible local contact. Scanner operators identify ships and gunner crews receive their target locks at separate bridge stations.",
		contacts = contacts,
		supportCharges = G.Support.charges,
		supportMaximum = math.max(1, tonumber(gd.ReinforcementMaximum) or 3),
		supportPending = G.Support.pending == true,
	}, ply)
end

function G.SendScannerContacts(ply)
	if ply ~= G.ScannerOperator or not G.ScannerSessionValid(ply, G.ScannerTerminal) then return end
	local currentKey = G.PlanetKey((G.State and G.State.currentPlanet) or "")
	local economy = currentKey ~= "" and G.GalaxyEconomyFor(currentKey) or nil
	local contacts = {}
	local maximum = math.max(1, math.floor(tonumber(gd.MaximumHailContacts) or 16))
	for _, ship in ipairs(G.HailableShips()) do
		contacts[#contacts + 1] = G.ExpandedContactSnapshot(ship)
		if #contacts >= maximum then break end
	end
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "contacts",
		station = "scanner",
		title = "TACTICAL SCANNER",
		body = "SYSTEM ACTIVITY: " .. G.CleanText(economy and economy.activity
			or "normal traffic", 120) .. ". Resolve local contacts, then track persistent traffic to follow every future hyperspace leg.",
		contacts = contacts,
		tracking = G.TrackedUniverseTrafficSnapshot(),
		reports = G.RecentGalaxyReports(),
	}, ply)
end

function G.SendOrdnanceContacts(ply, kind)
	kind = kind or "turbolaser"
	local definition = G.OrdnanceDefinition and G.OrdnanceDefinition(kind)
	if not definition or ply ~= G[definition.operator]
		or not G.OrdnanceSessionValid(ply, G[definition.terminal], kind) then return end
	local titles = {
		turbolaser = "TURBOLASER FIRE CONTROL",
		ion = "ION CANNON CONTROL",
		torpedo = "PROTON TORPEDO CONTROL",
	}
	local bodies = {
		turbolaser = "Only scanner-locked CIS and pirate ships inside the skybox appear here. FIRE launches a rapid long-range turbolaser volley.",
		ion = "ION shots drain a target's regenerating shields and disable its weapons briefly, but do not damage its hull.",
		torpedo = "Proton torpedoes deal heavy damage to the target model after their flight time. They reload slowly, so choose the shot carefully.",
	}
	local actions = { turbolaser = "skybox_volley", ion = "skybox_ion", torpedo = "skybox_torpedo" }
	local buttons = { turbolaser = "FIRE", ion = "ION", torpedo = "TORPEDO" }
	local contacts = {}
	for _, ship in ipairs(G.HailableShips()) do
		if G.ScannedShips[ship] == true and G.CanTargetSkyboxContact(ship) then
			contacts[#contacts + 1] = G.ExpandedContactSnapshot(ship)
		end
	end
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "contacts",
		station = "gunner",
		ordnance = kind,
		ordnanceAction = actions[kind],
		ordnanceButton = buttons[kind],
		title = titles[kind] or "ORDNANCE CONTROL",
		body = bodies[kind] or "Scanner-locked hostiles only.",
		contacts = contacts,
	}, ply)
end

function G.SendGunnerContacts(ply)
	return G.SendOrdnanceContacts(ply, "turbolaser")
end

function G.SendCommsHistory(ply)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "history",
		station = "communications",
		title = "COMMUNICATIONS HISTORY",
		body = "Recent outgoing hails, replies, warnings and intelligence reports.",
		history = G.CommsHistory,
	}, ply)
end

local function scanBody(ship)
	if MilBase.Inspections and MilBase.Inspections.ScannerProfile then
		local inspectionProfile = MilBase.Inspections.ScannerProfile(ship)
		if inspectionProfile then return inspectionProfile end
	end
	local trueFaction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local claimed = ship.mb_galaxyTransponderFaction or trueFaction
	local anomaly = claimed ~= trueFaction
	local hull = math.floor(ship:GetHull() / math.max(1, ship:GetMaxHull()) * 100)
	local lifeSigns = ship.mb_galaxySurvivors and (ship.mb_galaxySurvivors
		.. " survivor beacon(s)") or "crew signatures detected"
	if ship.mb_galaxyRareType == "derelict" then lifeSigns = "no active crew signatures" end
	if ship.mb_galaxySalvage then
		lifeSigns = (ship.mb_galaxySurvivors or 0) > 0
			and (ship.mb_galaxySurvivors .. " life signs among the debris")
			or "no confirmed life signs"
	end
	local defense = ""
	local trafficRecord = ship.mb_galaxyUniverseTrafficID
		and G.UniverseTraffic[ship.mb_galaxyUniverseTrafficID] or nil
	local homePlanet = trafficRecord and G.Planets[trafficRecord.homeKey] or nil
	local assignment = trafficRecord and ("\nASSIGNMENT: "
		.. string.upper(G.CleanText(trafficRecord.assignment, 32))
		.. " / HOME: " .. (homePlanet and homePlanet.name or "UNRESOLVED")
		.. (trafficRecord.fleetID and trafficRecord.fleetID ~= ""
			and (" / FLEET: " .. string.upper(G.CleanText(trafficRecord.fleetID, 64))) or "")) or ""
	local livingCrew = G.LivingUniverseScanText and G.LivingUniverseScanText(ship) or ""
	if ship.GetMaxShield and ship:GetMaxShield() > 0 then
		local shield = math.floor(ship:GetShield()
			/ math.max(1, ship:GetMaxShield()) * 100)
		defense = "\nDEFLECTOR SHIELD: " .. shield .. "%"
			.. "\nDEFENCE PROFILE: REGENERATING SHIELD / NON-REGENERATING HULL"
	end
	return "IDENTITY: " .. G.CleanText(ship:GetShipName(), 96)
		.. "\nTRUE AFFILIATION: " .. (factionNames[trueFaction] or factionNames.neutral)
		.. "\nTRANSPONDER: " .. (factionNames[claimed] or factionNames.neutral)
		.. (anomaly and " — AUTHENTICATION MISMATCH DETECTED" or " — VERIFIED")
		.. (ship.mb_galaxyCombatPrepared and "" or ("\nHULL: " .. hull .. "%"))
		.. defense
		.. "\nARMAMENT: " .. G.CleanText(ship.mb_galaxyWeapons, 140)
		.. "\nCARGO: " .. G.CleanText(ship.mb_galaxyCargo, 160)
		.. "\nORIGIN: " .. G.CleanText(ship.mb_galaxyOrigin, 120)
		.. "\nDESTINATION: " .. G.CleanText(ship.mb_galaxyDestination, 160)
		.. "\nROUTE STATUS: " .. G.CleanText(ship.mb_galaxyRouteStatus, 160)
		.. assignment
		.. livingCrew
		.. (ship.mb_galaxyTrafficPattern and ("\nFLIGHT PROFILE: "
			.. (G.TrafficPatternNames[ship.mb_galaxyTrafficPattern]
				or string.upper(ship.mb_galaxyTrafficPattern))) or "")
		.. "\nLIFE SIGNS: " .. lifeSigns
end

function G.ScanContact(ply, ship)
	if ply ~= G.ScannerOperator or not G.ScannerSessionValid(ply, G.ScannerTerminal) then
		MilBase.Notify(ply, "Use the tactical scanner terminal to resolve contacts.", "warn")
		return
	end
	if not validContact(ship) then
		MilBase.Notify(ply, "That contact has left local sensor range.", "warn")
		G.SendScannerContacts(ply)
		return
	end
	if G.PendingScan then
		MilBase.Notify(ply, "The tactical scanner is already resolving a contact.", "warn")
		return
	end
	if (ply.mb_nextGalaxyScan or 0) > CurTime() then return end
	ply.mb_nextGalaxyScan = CurTime() + math.max(0.5,
		tonumber(gd.SensorScanCooldown) or 2)
	if G.ShipSystemSnapshot().sensors < 10 then
		MilBase.Notify(ply, "The tactical sensor array is offline.", "warn")
		return
	end
	local signal = G.ContactSignalStrength(ship)
	if signal < math.max(1, tonumber(gd.SensorMinimumSignal) or 12) then
		MilBase.Notify(ply, "The contact signal is too weak to resolve.", "warn")
		return
	end

	G._scanSequence = (G._scanSequence or 0) + 1
	local token = G._scanSequence
	G.PendingScan = {
		token = token,
		operator = ply,
		terminal = G.ScannerTerminal,
		ship = ship,
	}
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "pending",
		station = "scanner",
		title = "ACTIVE SENSOR SCAN",
		contact = G.ExpandedContactSnapshot(ship),
		body = "Resolving hull profile, transponder authentication, armament and life signs...",
	}, ply)
	G.UpdateCommsTerminals()

	local systems = G.ShipSystemSnapshot()
	local minimum = math.max(0.5, tonumber(gd.SensorScanTimeMin) or 2.5)
	local maximum = math.max(minimum, tonumber(gd.SensorScanTimeMax) or 5)
	local delay = math.Rand(minimum, maximum)
		* Lerp(systems.sensors / 100, 1.7, 0.75)
	timer.Simple(delay, function()
		local pending = G.PendingScan
		if not pending or pending.token ~= token then return end
		G.PendingScan = nil
		if not G.ScannerSessionValid(ply, pending.terminal) then
			G.ReleaseScannerOperator(nil, true)
			return
		end
		if not validContact(ship) then
			writeCompressed("MilBase_GalaxyHailContacts", {
				mode = "result",
				station = "scanner",
				answered = false,
				title = "SCAN LOST",
				body = "The contact moved outside local sensor range before resolution completed.",
				contact = G.ExpandedContactSnapshot(ship),
			}, ply)
			G.UpdateCommsTerminals()
			return
		end
		G.ScannedShips[ship] = true
		if MilBase.Inspections and MilBase.Inspections.OnScannerResolved then
			MilBase.Inspections.OnScannerResolved(ply, ship)
		end
		local snapshot = G.ExpandedContactSnapshot(ship)
		writeCompressed("MilBase_GalaxyHailContacts", {
			mode = "scan_result",
			station = "scanner",
			answered = true,
			title = "SENSOR PROFILE RESOLVED",
			body = scanBody(ship) .. "\n\nTARGET LOCK PUBLISHED TO LONG-RANGE FIRE CONTROL.",
			contact = snapshot,
			choices = {},
		}, ply)
		G.AddCommsHistory("scan", ship,
			"Sensor profile resolved at " .. snapshot.signal .. "% signal strength.", ply)
		for _, kind in ipairs({ "turbolaser", "ion", "torpedo" }) do
			local definition = G.OrdnanceDefinition and G.OrdnanceDefinition(kind)
			local operator = definition and G[definition.operator]
			local terminal = definition and G[definition.terminal]
			if definition and IsValid(operator)
			and G.OrdnanceSessionValid(operator, terminal, kind) then
				G.SendOrdnanceContacts(operator, kind)
				if IsValid(terminal) then
					terminal:EmitSound(tostring(gd.CommsHailResponseSound
						or "buttons/button15.wav"), 66, 112, 0.65, CHAN_AUTO)
				end
			end
		end
		local sound = tostring(gd.CommsHailResponseSound or "buttons/button15.wav")
		if sound ~= "" and IsValid(pending.terminal) then
			pending.terminal:EmitSound(sound, 66, 108, 0.65, CHAN_AUTO)
		end
		G.UpdateCommsTerminals()
	end)
end

local function releaseExpandedShip(ship, state, speed)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return end
	ship:ClearCombatTarget()
	if ship.mb_galaxyMapSpace then
		if ship:GetHostile() and G.BeginCISRetreat and G.BeginCISRetreat(ship) then return end
		ship:SetShipState(state or "departing")
		ship:SetFlightVelocity(ship:GetForward() * (speed or math.Rand(110, 160)))
		ship:SetDieAt(CurTime() + 15)
		return
	end
	ship:SetShipState(state or "departing")
	ship.mb_galaxyHoldForPlayerDeparture = false
	ship.mb_galaxyPlayerDeparting = true
	local center = select(1, G.SkyboxFrame())
	local away = ship:GetPos() - center
	away.z = 0
	if away:LengthSqr() < 1 then away = ship:GetForward() * -1 end
	ship:SetFlightVelocity(away:GetNormalized() * (speed or math.Rand(45, 70)))
	ship:SetDieAt(CurTime() + 20)
end

local function escortCrewCentre()
	local total = vector_origin
	local count = 0
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:Alive() and not ply:IsBot() then
			total = total + ply:GetPos()
			count = count + 1
		end
	end
	return count > 0 and total / count or nil
end

local function isLVSEntity(ent, visited)
	if not IsValid(ent) then return false end
	visited = visited or {}
	if visited[ent] then return false end
	visited[ent] = true
	if ent.LVS == true then return true end
	local class = string.lower(ent:GetClass() or "")
	if string.StartWith(class, "lvs_") or string.find(class, "_lvs_", 1, true) then
		return true
	end
	if ent.GetParent then
		local parent = ent:GetParent()
		if parent ~= ent and isLVSEntity(parent, visited) then return true end
	end
	if ent.GetOwner then
		local owner = ent:GetOwner()
		if owner ~= ent and isLVSEntity(owner, visited) then return true end
	end
	return false
end

local function escortBattleAnchor()
	for _, anchor in ipairs(G.Anchors or {}) do
		if anchor.kind == "space_battle" and isvector(anchor.pos)
		and util.IsInWorld(anchor.pos) then
			return Vector(anchor.pos), isangle(anchor.ang)
				and Angle(anchor.ang.p, anchor.ang.y, anchor.ang.r) or nil
		end
	end
	local configured = (gd.MapAnchors or {})[game.GetMap()] or {}
	for _, entry in ipairs(configured.space_battle or {}) do
		if isvector(entry) and util.IsInWorld(entry) then return Vector(entry), nil end
		if istable(entry) and isvector(entry.pos) and util.IsInWorld(entry.pos) then
			return Vector(entry.pos), isangle(entry.ang)
				and Angle(entry.ang.p, entry.ang.y, entry.ang.r) or nil
		end
	end
	return nil
end

local function buildEscortMapRoute(sideYaw)
	local centre, facing = escortBattleAnchor()
	if not isvector(centre) then
		local crew = escortCrewCentre()
		if not isvector(crew) then return nil end
		local yaw = tonumber(sideYaw) or math.Rand(0, 360)
		local direction = Angle(0, yaw, 0):Forward()
		local distance = math.max(400, tonumber(gd.EscortMapRendezvousDistance) or 1800)
		local altitude = math.max(200, tonumber(gd.EscortMapAltitude) or 1100)
		local ceiling = util.TraceLine({
			start = crew + Vector(0, 0, 64),
			endpos = crew + Vector(0, 0, 32768),
			mask = MASK_SOLID_BRUSHONLY,
		})
		local ceilingRoom = (ceiling.Hit and ceiling.HitPos.z or crew.z + altitude * 1.6) - crew.z
		altitude = math.min(altitude, math.max(260, ceilingRoom * 0.65))
		for _, scale in ipairs({ 1, 0.8, 0.6, 0.4, 0.2 }) do
			local candidate = crew + direction * distance * scale + Vector(0, 0, altitude)
			if util.IsInWorld(candidate) then
				centre = candidate
				facing = direction:Angle()
				break
			end
		end
	end
	if not isvector(centre) or not util.IsInWorld(centre) then return nil end
	local forward = isangle(facing) and facing:Forward()
		or Angle(0, tonumber(sideYaw) or math.Rand(0, 360), 0):Forward()
	forward.z = 0
	if forward:LengthSqr() < 1 then forward = Vector(1, 0, 0) end
	forward:Normalize()
	local routeLength = math.max(1200, tonumber(gd.EscortMapRouteLength) or 5200)
	for _, scale in ipairs({ 1, 0.8, 0.6, 0.45, 0.3 }) do
		local start = centre - forward * routeLength * scale * 0.5
		local destination = centre + forward * routeLength * scale * 0.5
		if util.IsInWorld(start) and util.IsInWorld(destination) then
			return {
				centre = centre,
				start = start,
				destination = destination,
				forward = forward,
				right = Angle(0, forward:Angle().y + 90, 0):Forward(),
				length = start:Distance(destination),
			}
		end
	end
	return nil
end

local function placeShipInMapSpace(ship, pos, angle)
	if not IsValid(ship) or not isvector(pos) or not util.IsInWorld(pos) then return false end
	ship.mb_galaxyMapSpace = true
	ship.mb_galaxySkyboxManaged = false
	ship.mb_galaxyUniversePos = nil
	ship.mb_galaxyUniverseAng = nil
	ship.mb_galaxyUniverseVelocity = nil
	ship.mb_galaxyLastFlightVelocity = nil
	ship.mb_galaxyHoldForPlayerDeparture = false
	ship.mb_galaxyPlayerDeparting = true
	ship:SetPos(pos)
	ship:SetAngles(isangle(angle) and angle or ship:GetAngles())
	ship:SetFlightVelocity(vector_origin)
	ship:SetDieAt(0)
	if G.ApplyMapSpaceShipScale then
		G.ApplyMapSpaceShipScale(ship, ship:GetRole())
	elseif ship.RefreshCombatCollision then
		ship:RefreshCombatCollision(gd.CISUseModelCollision ~= false)
	end
	return true
end

local function mapEscortPilotsPresent(operation)
	local lead = operation.target
	if not IsValid(lead) then return false end
	local range = math.max(200, tonumber(gd.EscortMapRendezvousRange) or 1250)
	local rangeSqr = range * range
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:Alive() and ply:InVehicle()
		and ply:GetPos():DistToSqr(lead:GetPos()) <= rangeSqr
		and isLVSEntity(ply:GetVehicle()) then
			return true
		end
	end
	return false
end

local function setMapConvoyVelocity(operation, velocity)
	local direction = velocity:LengthSqr() > 1 and velocity:GetNormalized() or nil
	for _, ship in ipairs(operation.targets or {}) do
		if IsValid(ship) then
			ship:SetFlightVelocity(velocity)
			if direction then ship:SetAngles(direction:Angle()) end
		end
	end
end

local function livingEscortTargets(operation)
	local living = 0
	for _, ship in ipairs(operation.targets or {}) do
		if validContact(ship) then living = living + 1 end
	end
	return living
end

local function livingEscortHostiles(operation)
	local living = 0
	for _, ship in ipairs(operation.hostiles or {}) do
		if validContact(ship) then living = living + 1 end
	end
	return living
end

function G.SpawnMapEscortWave(operation)
	if G.Operation ~= operation then return 0 end
	local route = operation.data and operation.data.route
	local lead = operation.target
	if not route or not IsValid(lead) then return 0 end
	operation.data.wave = (operation.data.wave or 0) + 1
	local wave = operation.data.wave
	local danger = G.State.currentRisk or 0.4
	local count = math.Clamp(math.floor(2 + danger * 2
		+ math.max(0, G.ActivePlayerCount() - 5) / 7), 2, 5)
	local faction = (danger > 0.5 or wave >= 2) and "cis" or "pirate"
	local created = 0
	local formationLeader
	for index = 1, count do
		local lane = (index - (count + 1) / 2) * 260
		local attackPos = lead:GetPos() + route.forward * math.Rand(1150, 1700)
			+ route.right * lane + Vector(0, 0, math.Rand(-180, 180))
		if util.IsInWorld(attackPos) then
			local role = faction == "cis" and "cis_scout" or "pirate"
			local hostile = G.SpawnShip(role, {
				sideYaw = lead.mb_galaxySideYaw or 0,
				hold = true,
				faction = faction,
				trueFaction = faction,
				hostile = true,
				hull = faction == "cis" and 3000 or 2200,
			})
			if IsValid(hostile) then
				if faction == "cis" and G.PrepareCISCombatShip then
					hostile.mb_galaxyEscortBattle = true
					hostile.mb_galaxyEscortBattleTarget = Vector(attackPos)
					G.PrepareCISCombatShip(hostile)
				else
					placeShipInMapSpace(hostile, attackPos,
						(lead:GetPos() - attackPos):Angle())
				end
				if IsValid(hostile) then
					hostile:SetInvulnerable(false)
					hostile:SetShipState("inbound to escorted convoy")
					local targets = operation.targets or {}
					local victim = targets[math.random(#targets)]
					if IsValid(victim) then
						hostile:SetCombatTarget(victim,
							faction == "cis" and 58 or 45, faction == "cis" and 3.6 or 4.1)
					end
					operation.hostiles[#operation.hostiles + 1] = hostile
					operation.entities[#operation.entities + 1] = hostile
					created = created + 1
				end
			end
		end
	end
	if created > 0 then
		announce("Hostile wave " .. wave
			.. " has entered the map-space convoy route. LVS pilots engage.",
			Color(235, 105, 60))
	end
	return created
end

function G.UpdateMapEscortOperation(operation, now)
	local route = operation.data and operation.data.route
	if not route then return end
	local survivors = livingEscortTargets(operation)
	if survivors <= 0 then
		G.ResolveOperation("failure", "The escorted convoy was destroyed in map-space.")
		return
	end
	local lead = IsValid(operation.target) and operation.target or operation.targets[1]
	if not IsValid(lead) then
		G.ResolveOperation("failure", "The convoy lead was lost during the operation.")
		return
	end
	operation.target = lead
	local escortsPresent = mapEscortPilotsPresent(operation)
	local phase = operation.phase
	if phase == "rendezvous" then
		setMapConvoyVelocity(operation, vector_origin)
		operation.progress = 0
		if escortsPresent then
			operation.phase = "transit"
			operation.data.departedAt = now
			operation.body = "LVS escort confirmed. Keep close to the convoy while it crosses the map-space extraction route."
			announce("LVS escort has reached the civilian convoy. Convoy transit is underway.",
				Color(105, 195, 245))
		else
			operation.body = "Launch an LVS craft and rendezvous with the convoy. It will not enter the route without a close escort."
		end
	elseif phase == "transit" or phase == "extraction" then
		if phase == "transit" and escortsPresent then
			setMapConvoyVelocity(operation, route.forward
				* math.max(20, tonumber(gd.EscortMapConvoySpeed) or 105))
		elseif phase == "transit" then
			setMapConvoyVelocity(operation, vector_origin)
			operation.body = "Convoy transit paused: return an LVS escort to the formation."
		end

		local total = math.max(1, tonumber(route.length) or 1)
		local progress = math.Clamp(1 - lead:GetPos():Distance(route.destination) / total, 0, 1)
		operation.progress = math.floor(progress * 100)
		operation.goal = 100
		local waves = G.Runtime.attacks
			and math.max(1, math.floor(tonumber(gd.EscortMapMaximumWaves) or 3)) or 0
		local milestones = { 0.12, 0.42, 0.72, 0.88 }
		if G.Runtime.attacks and phase == "transit"
		and (operation.data.wave or 0) < waves
		and progress >= (milestones[(operation.data.wave or 0) + 1] or 0.88) then
			G.SpawnMapEscortWave(operation)
		end

		for _, hostile in ipairs(operation.hostiles or {}) do
			if validContact(hostile) and not hostile.mb_galaxyCombatIngress
			and not hostile.mb_galaxyRetreating then
				local delta = lead:GetPos() - hostile:GetPos()
				local desiredRange = hostile:GetCapital() and 1450 or 760
				if delta:Length() > desiredRange then
					local direction = delta:GetNormalized()
					hostile:SetFlightVelocity(direction * (hostile:GetCapital() and 80 or 135))
					hostile:SetAngles(direction:Angle())
				else
					hostile:SetFlightVelocity(vector_origin)
				end
			end
		end

		if phase == "transit" and lead:GetPos():Distance(route.destination)
			<= math.max(80, tonumber(gd.EscortMapArrivalRadius) or 260) then
			setMapConvoyVelocity(operation, vector_origin)
			operation.phase = "extraction"
			operation.body = "Convoy has reached its extraction corridor. Clear any remaining hostiles for the hyperspace jump."
		end
		if operation.phase == "extraction" and livingEscortHostiles(operation) <= 0
		and (operation.data.wave or 0) >= waves then
			G.ResolveOperation("success",
				"LVS escort held the map-space route and the civilian convoy escaped into hyperspace.")
			return
		end
	end
	if now >= operation.endsAt then
		G.ResolveOperation("failure", "The convoy's extraction window closed before the escort could complete the route.")
	end
end

local function setSkyboxConvoyVelocity(operation, speed)
	local direction = operation.data and operation.data.routeDirection
	if not isvector(direction) or direction:LengthSqr() < 0.01 then return end
	local velocity = direction:GetNormalized() * math.max(0, tonumber(speed) or 0)
	for _, ship in ipairs(operation.targets or {}) do
		if IsValid(ship) then
			ship:SetFlightVelocity(velocity)
			if velocity:LengthSqr() > 0 then
				if G.HasSWUUniverseFrame() then
					G.UpdateShipTravelFacing(ship, velocity,
						SWU.Controller:GetInternalShipAngles(), 0.2, false)
				else
					G.UpdateShipTravelFacing(ship, velocity, angle_zero, 0, true)
				end
			end
		end
	end
end

function G.SpawnSkyboxEscortWave(operation)
	if G.Operation ~= operation then return 0 end
	local lead = IsValid(operation.target) and operation.target or operation.targets[1]
	if not IsValid(lead) then return 0 end
	operation.data.wave = (operation.data.wave or 0) + 1
	local wave = operation.data.wave
	local danger = G.State.currentRisk or 0.4
	local count = math.Clamp(math.floor(1 + danger * 2
		+ math.max(0, G.ActivePlayerCount() - 6) / 8), 1, 3)
	local faction = (danger > 0.55 or wave >= 2) and "cis" or "pirate"
	local created = 0
	for index = 1, count do
		local role = faction == "cis" and "cis_scout" or "pirate"
		local hostile = G.SpawnShip(role, {
			sideYaw = (lead.mb_galaxySideYaw or 0) + 150 + math.Rand(-18, 18),
			lane = (index - (count + 1) / 2) * 165,
			height = math.Rand(-120, 120),
			hold = true,
			faction = faction,
			trueFaction = faction,
			hostile = true,
			hull = faction == "cis" and 2800 or 1900,
		})
		if IsValid(hostile) then
			hostile:SetInvulnerable(false)
			hostile:SetShipState("intercepting escorted convoy")
			if faction == "cis" and G.PrepareCISCombatShip then
				G.PrepareCISCombatShip(hostile)
			end
			local victim = operation.targets[math.random(#operation.targets)]
			if IsValid(victim) then
				hostile:SetCombatTarget(victim, faction == "cis" and 54 or 42,
					faction == "cis" and 3.8 or 4.4)
			end
			operation.hostiles[#operation.hostiles + 1] = hostile
			operation.entities[#operation.entities + 1] = hostile
			created = created + 1
		end
	end
	if created > 0 then
		announce("Hostile skybox contacts are intercepting the civilian convoy. "
			.. "Fire Control, protect the formation.", Color(235, 105, 60))
	end
	return created
end

function G.UpdateSkyboxEscortOperation(operation, now)
	local survivors = livingEscortTargets(operation)
	if survivors <= 0 then
		G.ResolveOperation("failure", "The escorted convoy was destroyed in the skybox.")
		return
	end
	local lead = IsValid(operation.target) and operation.target or operation.targets[1]
	if not IsValid(lead) then
		G.ResolveOperation("failure", "The convoy lead was lost during the escort.")
		return
	end
	operation.target = lead
	local moving = G.PlayerShipIsMoving and G.PlayerShipIsMoving()
	local phase = operation.phase
	if phase == "rendezvous" then
		setSkyboxConvoyVelocity(operation, 0)
		operation.progress = 0
		if moving then
			operation.phase = "transit"
			operation.data.departedAt = now
			operation.body = "Republic ship underway. Maintain course while the convoy follows in formation."
			announce("The Republic ship has taken the convoy under escort. Skybox transit is underway.",
				Color(105, 195, 245))
		else
			operation.body = "Convoy formed up in the skybox. Take the Republic ship underway to begin the escort."
		end
	elseif phase == "transit" then
		if moving then
			setSkyboxConvoyVelocity(operation,
				math.max(8, tonumber(gd.EscortSkyboxSpeed) or 34))
			operation.progress = math.min(100, (operation.progress or 0)
				+ math.max(0.05, tonumber(gd.EscortSkyboxProgressPerSecond) or 0.52))
			operation.body = "Republic ship is escorting the convoy through the skybox. Hold course and protect the formation."
		else
			setSkyboxConvoyVelocity(operation, 0)
			operation.body = "Convoy holding formation. Take the Republic ship underway to continue the escort."
		end

		local waves = G.Runtime.attacks
			and math.max(1, math.floor(tonumber(gd.EscortSkyboxMaximumWaves) or 3)) or 0
		local milestones = { 12, 42, 72, 90 }
		if moving and G.Runtime.attacks and (operation.data.wave or 0) < waves
		and (operation.progress or 0) >= (milestones[(operation.data.wave or 0) + 1] or 90) then
			G.SpawnSkyboxEscortWave(operation)
		end
		if (operation.progress or 0) >= 100 then
			setSkyboxConvoyVelocity(operation, 0)
			operation.phase = "extraction"
			operation.body = "Convoy has reached its hyperspace corridor. Clear remaining hostiles for departure."
		end
	elseif phase == "extraction" then
		setSkyboxConvoyVelocity(operation, 0)
		local waves = G.Runtime.attacks
			and math.max(1, math.floor(tonumber(gd.EscortSkyboxMaximumWaves) or 3)) or 0
		if livingEscortHostiles(operation) <= 0 and (operation.data.wave or 0) >= waves then
			G.ResolveOperation("success",
				"The Republic ship escorted the civilian convoy through the skybox and into hyperspace.")
			return
		end
	end
	if now >= operation.endsAt then
		G.ResolveOperation("failure", "The convoy's hyperspace window closed before the escort was complete.")
	end
end

local function operationSnapshot(operation)
	if not operation then return nil end
	local progress = operation.progress or 0
	local goal = operation.goal or 1
	if operation.kind == "salvage" then
		goal = 1
		progress = math.Clamp((CurTime() - operation.startedAt)
			/ math.max(1, operation.endsAt - operation.startedAt), 0, 1)
	elseif operation.kind == "counter_board" then
		goal = 1
		progress = operation.phase == "evacuation" and 0.78
			or operation.phase == "aboard" and 0.48 or 0.2
	end
	return {
		id = operation.id,
		kind = operation.kind,
		title = operation.title,
		body = operation.body,
		phase = operation.phase,
		startedAt = operation.startedAt,
		endsAt = operation.endsAt,
		progress = progress,
		goal = goal,
		score = operation.score,
		mistakes = operation.mistakes,
		target = IsValid(operation.target) and operation.target:GetShipName() or "",
		targetEntity = IsValid(operation.target) and operation.target:EntIndex() or 0,
		mapSpace = operation.data and operation.data.mapSpace == true,
		rendezvous = operation.data and operation.data.route and {
			x = operation.data.route.start.x,
			y = operation.data.route.start.y,
			z = operation.data.route.start.z,
		} or nil,
		destination = operation.data and operation.data.route and {
			x = operation.data.route.destination.x,
			y = operation.data.route.destination.y,
			z = operation.data.route.destination.z,
		} or nil,
	}
end

local operationSequence = 0
function G.BeginOperation(kind, data)
	if G.Operation then return false, "Another fleet operation is already active." end
	data = data or {}
	operationSequence = operationSequence + 1
	local operation = {
		id = string.format("%s_%d_%03d", kind, unix(), operationSequence % 1000),
		kind = kind,
		title = data.title or G.OperationNames[kind] or "FLEET OPERATION",
		body = data.body or "Fleet operation underway.",
		phase = data.phase or "active",
		startedAt = CurTime(),
		endsAt = data.endsAt or (CurTime() + 120),
		progress = data.progress or 0,
		goal = data.goal or 1,
		score = data.score or 0,
		mistakes = data.mistakes or 0,
		operator = data.operator,
		target = data.target,
		targets = data.targets or {},
		hostiles = data.hostiles or {},
		entities = data.entities or {},
		data = data.data or {},
	}
	G.Operation = operation
	G.BroadcastState()
	return true, operation
end

function G.ResolveOperation(outcome, details)
	local operation = G.Operation
	if not operation then return end
	operation.outcome = outcome
	details = G.CleanText(details or "Fleet operation complete.", 700)
	local success = outcome == "success"

	if operation.kind == "escort" then
		if success then
			G.AddRecommendation(G.State.currentPlanet, 4, -2,
				"Republic forces protected a civilian convoy through a dangerous sector.",
				operatorName(operation.operator))
			if IsValid(operation.target) then
				G.ChangeContactTrust(operation.target, 12,
					"Republic convoy escort completed successfully.")
			end
			G.AddIntel("traffic", "Convoy route report",
				"The escorted convoy supplied updated traffic and hostile-movement reports.",
				IsValid(operation.target) and operation.target:GetShipName() or "Civilian convoy",
				76, math.Rand(0, 1) < 0.45 and "pirate" or "")
		end
	elseif operation.kind == "blockade" then
		if success and (operation.mistakes or 0) == 0 then
			G.AddRecommendation(G.State.currentPlanet, 3, -1,
				"Republic blockade crews protected legitimate traffic while detecting contraband.",
				operatorName(operation.operator))
		elseif (operation.mistakes or 0) > 0 then
			G.AddRecommendation(G.State.currentPlanet, -2, 1,
				"Blockade errors disrupted legitimate local traffic.",
				operatorName(operation.operator))
		end
	elseif operation.kind == "salvage" and success then
		if (operation.data.survivors or 0) > 0 then
			G.AddRecommendation(G.State.currentPlanet, 3, -1,
				"Republic search-and-rescue teams recovered survivors from a wreck.",
				operatorName(operation.operator))
		end
		G.AddIntel("black_box", "Recovered black-box telemetry",
			"Debris analysis recovered a partial route and weapons log from the destroyed vessel.",
			"Republic recovery team", 84,
			math.Rand(0, 1) < 0.55 and "cis" or "pirate")
	elseif operation.kind == "counter_board" and success then
		G.AddRecommendation(G.State.currentPlanet, 5, -3,
			"Republic forces disabled and boarded a hostile vessel.",
			operatorName(operation.operator))
		G.AddIntel("captured_data", "Captured hostile navigation data",
			"Boarding teams secured encrypted routes, fleet identifiers and supply coordinates.",
			"Republic boarding team", 92, "cis")
	elseif operation.kind == "background_battle" and success then
		G.AddRecommendation(G.State.currentPlanet, 4, -2,
			"Republic forces answered a local battle and protected traffic on the route.",
			operatorName(operation.operator))
		G.AddIntel("battle_report", "Local battle report",
			"Surviving crews supplied the Republic with hostile movements and route conditions.",
			IsValid(operation.target) and operation.target:GetShipName() or "Republic battle group",
			78, "cis")
	end

	G.RecordHistory("operation_" .. operation.kind, outcome,
		G.State.currentPlanet, details)
	announce(details, success and Color(95, 220, 135)
		or outcome == "failure" and Color(235, 70, 60) or Color(235, 175, 70))

	for _, ship in ipairs(operation.targets or {}) do
		if IsValid(ship) then releaseExpandedShip(ship) end
	end
	for _, ship in ipairs(operation.hostiles or {}) do
		if IsValid(ship) then releaseExpandedShip(ship, "retreating", 82) end
	end
	if operation.kind == "salvage" and IsValid(operation.target) then
		operation.target:Remove()
	elseif operation.kind == "counter_board" and IsValid(operation.target) then
		operation.target:SetInvulnerable(false)
		operation.target:SetShipState(success and "captured" or "retreating")
		releaseExpandedShip(operation.target,
			success and "captured" or "retreating", success and 35 or 85)
	end

	G.Operation = nil
	G.HailConversation = nil
	G.BroadcastState()
end

function G.CancelOperation(reason)
	local operation = G.Operation
	if not operation then return end
	for _, ship in ipairs(operation.targets or {}) do
		if IsValid(ship) then releaseExpandedShip(ship) end
	end
	for _, ship in ipairs(operation.hostiles or {}) do
		if IsValid(ship) then releaseExpandedShip(ship, "retreating", 82) end
	end
	if operation.kind == "salvage" and IsValid(operation.target) then
		operation.target:Remove()
	end
	G.RecordHistory("operation_" .. operation.kind, "cancelled",
		G.State.currentPlanet, reason or "Operation cancelled.")
	G.Operation = nil
	G.HailConversation = nil
	G.BroadcastState()
end

function G.StartEscortOperation(ply, lead)
	if G.Active then return false, "Priority tactical traffic must be cleared first." end
	if G.Operation then return false, "Another fleet operation is active." end
	if not validContact(lead) then return false, "The convoy lead has left sensor range." end
	local targets = {}
	local group = lead.mb_galaxyConvoyGroup
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship) and (ship == lead
		or (group and ship.mb_galaxyConvoyGroup == group)) then
			targets[#targets + 1] = ship
		end
	end
	if #targets == 0 then return false, "No convoy ships are available to escort." end

	local ok, operation = G.BeginOperation("escort", {
		title = "REPUBLIC SHIP CONVOY ESCORT",
		body = "Convoy formed up in the skybox. Take the Republic ship underway to begin the escort.",
		phase = "rendezvous",
		endsAt = CurTime() + math.max(90, tonumber(gd.EscortSkyboxDuration) or 300),
		goal = 100,
		target = lead,
		targets = targets,
		operator = ply,
		data = {
			skyboxEscort = true,
			wave = 0,
			routeDirection = Vector(lead:GetForward()),
		},
	})
	if not ok then return false, operation end
	for _, ship in ipairs(targets) do
		ship:SetDieAt(0)
		ship:SetInvulnerable(false)
		ship:SetFlightVelocity(vector_origin)
		ship.mb_galaxyHoldForPlayerDeparture = true
		ship.mb_galaxyPlayerDeparting = false
		ship:SetShipState("awaiting Republic ship escort")
	end
	G.AddCommsHistory("outgoing", lead,
		"Republic ship escort accepted; convoy has formed up in the skybox.", ply)
	G.ChangeContactTrust(lead, 6,
		"Republic crew committed the main ship to escort the convoy.")
	announce("Civilian convoy has formed up in the skybox. Take the Republic ship underway to begin escort.",
		Color(105, 195, 245))
	G.BroadcastState()
	return true, operation
end

function G.StartSalvageOperation(ply, wreck)
	if G.Active then return false, "Recovery cannot begin during priority combat operations." end
	if G.Operation then return false, "Another fleet operation is active." end
	if not validContact(wreck)
	or (not wreck.mb_galaxySalvage and wreck.mb_galaxyRareType ~= "derelict") then
		return false, "That contact is not a recoverable wreck."
	end
	if wreck.mb_navalSalvageReservedBy then
		return false, "A support vessel is already committed to that wreck."
	end
	wreck:SetDieAt(0)
	return G.BeginOperation("salvage", {
		title = (wreck.mb_galaxySurvivors or 0) > 0
			and "SEARCH AND RESCUE" or "WRECKAGE RECOVERY",
		body = "Recovery shuttles are searching the debris for survivors, cargo and intact flight recorders.",
		endsAt = CurTime() + math.max(12, tonumber(gd.SalvageDuration) or 28),
		target = wreck,
		targets = { wreck },
		operator = ply,
		data = {
			survivors = wreck.mb_galaxySurvivors or 0,
			cargo = wreck.mb_galaxyCargo,
		},
	})
end

function G.StartCounterBoardOperation(ply, ship)
	if G.Active then return false, "The hostile engagement must be contained before boarding." end
	if G.Operation then return false, "Another fleet operation is active." end
	if not G.Runtime.enabled or not G.Runtime.attacks then
		return false, "Hostile fleet operations are currently disabled."
	end
	if not validContact(ship) then return false, "The target has left local space." end
	if ship.mb_galaxyCombatPrepared then
		return false, "This encounter is resolved by forcing the vessel to withdraw, not by disabling or boarding it."
	end
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local damaged = ship:GetHull() / math.max(1, ship:GetMaxHull()) <= 0.55
		or ship:GetShipState() == "surrendered" or ship:GetShipState() == "disabled"
	if faction ~= "cis" and faction ~= "pirate" then
		return false, "Boarding authorization is limited to hostile vessels."
	end
	if not damaged then return false, "Disable the target below 55% hull before boarding." end
	ship:SetFlightVelocity(vector_origin)
	ship:SetShipState("disabled")
	ship:SetDieAt(0)
	local ok, operation = G.BeginOperation("counter_board", {
		title = "HOSTILE VESSEL BOARDING",
		body = "Republic boarding shuttles are approaching the disabled vessel. Select the boarding team's primary objective before its reactor becomes unstable.",
		phase = "approach",
		endsAt = CurTime() + math.max(40, tonumber(gd.CounterBoardDuration) or 75),
		target = ship,
		operator = ply,
		data = {
			decisionAt = CurTime() + 12,
			selfDestructAt = CurTime() + math.max(40,
				tonumber(gd.CounterBoardDuration) or 75),
		},
	})
	if ok then
		G.AddCommsHistory("outgoing", ship,
			"Republic boarding operation launched against disabled vessel.", ply)
	end
	return ok, operation
end

function G.SendCounterBoardDecision(operation)
	local ply = operation and operation.operator
	local ship = operation and operation.target
	if not IsValid(ship) then return end
	if not IsValid(ply) or ply ~= G.CommsOperator
	or not G.CommsSessionValid(ply, G.CommsTerminal) then
		ply = G.CommsOperator
	end
	if not IsValid(ply) or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
	operation.operator = ply
	operation.phase = "aboard"
	operation.body = "Boarding teams report entry. Choose one objective and evacuate before the hostile reactor overloads."
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "result",
		station = "communications",
		answered = true,
		title = "BOARDING TEAM AWAITING ORDERS",
		body = operation.body,
		contact = G.ExpandedContactSnapshot(ship),
		choices = {
			{ id = "board_bridge", label = "SEIZE BRIDGE INTELLIGENCE" },
			{ id = "board_engineering", label = "DISABLE THE REACTOR" },
			{ id = "board_cargo", label = "SECURE CARGO AND PRISONERS" },
			{ id = "board_withdraw", label = "ORDER IMMEDIATE WITHDRAWAL" },
		},
	}, ply)
	G.BroadcastState()
end

function G.HandleCounterBoardDecision(ply, action)
	local operation = G.Operation
	if not operation or operation.kind ~= "counter_board"
	or operation.operator ~= ply or operation.phase ~= "aboard" then return false end
	if action == "board_withdraw" then
		G.ResolveOperation("neutral",
			"Republic boarding teams withdrew before the hostile reactor became unstable.")
		return true
	end
	local descriptions = {
		board_bridge = "Boarding teams seized the bridge datacore and are returning to their shuttles.",
		board_engineering = "Boarding teams disabled the reactor overload and secured engineering control.",
		board_cargo = "Boarding teams recovered prisoners, cargo and the ship's physical flight logs.",
	}
	if not descriptions[action] then return false end
	operation.phase = "evacuation"
	operation.body = descriptions[action]
	operation.data.reward = action
	operation.endsAt = CurTime() + 18
	if action == "board_engineering" then
		operation.target:SetShipState("captured")
	elseif action == "board_cargo" then
		operation.data.survivors = math.random(1, 5)
	end
	G.AddCommsHistory("incoming", operation.target, descriptions[action], ply)
	G.BroadcastState()
	return true
end

local function hostileShips()
	local result = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship) and ship:GetHostile() then result[#result + 1] = ship end
	end
	return result
end

function G.CallReinforcements(ply)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then
		return false, "Use the communications terminal to request support."
	end
	if G.Support.pending then return false, "A Republic support group is already inbound." end
	if not G.Runtime.enabled or not G.Runtime.attacks then
		return false, "Fleet combat operations are currently disabled."
	end
	if (G.Support.charges or 0) <= 0 then
		return false, "No Republic reinforcement groups are currently available."
	end
	if G.ShipSystemSnapshot().communications < 20 then
		return false, "Communications damage prevents a secure reinforcement request."
	end
	if #hostileShips() == 0 and not (G.Active
	and (G.Active.kind == "cis" or G.Active.kind == "cis_raid")) then
		return false, "Republic Command requires a confirmed hostile contact."
	end

	G.Support.charges = G.Support.charges - 1
	G.Support.pending = true
	G.SaveExpansionState()
	G.AddCommsHistory("outgoing", nil,
		"Priority reinforcement request authenticated and accepted.", ply)
	announce("Republic Command has acknowledged a priority reinforcement request.",
		Color(80, 155, 240))
	G.BroadcastState()

	timer.Simple(math.max(3, tonumber(gd.ReinforcementArrivalDelay) or 12), function()
		G.Support.pending = nil
		local targets = hostileShips()
		if #targets == 0 then
			G.Support.charges = math.min(math.max(1,
				tonumber(gd.ReinforcementMaximum) or 3), G.Support.charges + 1)
			G.SaveExpansionState()
			announce("Republic reinforcements diverted: hostile contacts have already withdrawn.",
				Color(235, 175, 70))
			G.BroadcastState()
			return
		end
		local count = math.max(1, math.floor(tonumber(gd.ReinforcementShips) or 2))
		for i = 1, count do
			local target = targets[((i - 1) % #targets) + 1]
			local ally = G.SpawnShip("republic", {
				sideYaw = (target.mb_galaxySideYaw or 0) + 180,
				lane = i * 145,
				hold = true,
				faction = "republic",
				hull = 3200,
				name = "Republic Response " .. string.char(64 + i),
			})
			if IsValid(ally) then
				ally:SetDieAt(CurTime()
					+ math.max(30, tonumber(gd.ReinforcementLifetime) or 150))
				ally:SetShipState("supporting Republic forces")
				ally:SetCombatTarget(target, 82, 3.6)
			end
		end
		announce("Republic reinforcement group has entered local space.",
			Color(80, 155, 240))
		G.BroadcastState()
	end)
	return true, "Republic Command confirms support is inbound."
end

function G.StartBlockadeOperation(ply)
	if G.Active or G.Operation then return false, "Local space is already occupied." end
	local ok, operation = G.BeginOperation("blockade", {
		title = "REPUBLIC BLOCKADE CONTROL",
		body = "Three vessels are approaching the checkpoint. Scan their transponders and cargo, then clear legitimate traffic or detain contraband.",
		endsAt = CurTime() + math.max(90, tonumber(gd.BlockadeDuration) or 180),
		goal = 3,
		operator = ply,
		data = { decisions = {} },
	})
	if not ok then return false, operation end

	local smugglerIndex = math.random(1, 3)
	for i = 1, 3 do
		local smuggler = i == smugglerIndex
		local ship = G.SpawnShip(smuggler and "pirate" or "civilian", {
			sideYaw = math.Rand(0, 360),
			lane = (i - 2) * 165,
			hold = true,
			faction = smuggler and "pirate" or "civilian",
			trueFaction = smuggler and "pirate" or "civilian",
			transponderFaction = "civilian",
			manifestLegal = not smuggler,
			cargo = smuggler and contrabandPools[math.random(#contrabandPools)]
				or cargoPools[math.random(#cargoPools)],
			name = "Checkpoint Traffic " .. string.char(64 + i),
			expansionType = "blockade",
		})
		if IsValid(ship) then
			ship.mb_galaxyBlockade = true
			ship.mb_galaxyBlockadeOperation = operation.id
			ship.mb_galaxyBlockadeSlot = i
			ship:SetDieAt(0)
			ship:SetShipState("awaiting inspection")
			operation.targets[#operation.targets + 1] = ship
			operation.entities[#operation.entities + 1] = ship
			operation.data.decisions[tostring(i)] = { ship = ship }
		end
	end
	operation.goal = #operation.targets
	if operation.goal == 0 then
		G.Operation = nil
		return false, "No safe checkpoint approach lanes were available."
	end
	announce("Republic blockade checkpoint active. Fleet personnel must inspect approaching traffic.",
		Color(80, 155, 240))
	G.BroadcastState()
	return true, operation
end

function G.HandleBlockadeDecision(ply, ship, action)
	local operation = G.Operation
	if not operation or operation.kind ~= "blockade"
	or ship.mb_galaxyBlockadeOperation ~= operation.id then return false end
	local key = tostring(ship.mb_galaxyBlockadeSlot or ship:EntIndex())
	local record = operation.data.decisions[key] or {}
	operation.data.decisions[key] = record
	if not IsValid(operation.operator) then operation.operator = ply end

	if action == "inspect" then
		if G.ScannedShips[ship] ~= true then
			return true, "Complete a sensor scan before validating the cargo manifest."
		end
		record.inspected = true
		return true, "Cargo inspection reports " .. G.CleanText(ship.mb_galaxyCargo, 180)
			.. ". The transponder is "
			.. ((ship.mb_galaxyTransponderFaction ~= ship.mb_galaxyTrueFaction)
				and "inconsistent with the hull registry." or "consistent with the hull registry.")
	end
	if action ~= "clear" and action ~= "detain" then return false end
	if record.decided then return true, "A checkpoint decision has already been recorded." end
	if not record.inspected then return true, "Inspect the vessel before issuing a final order." end

	record.decided = action
	local legal = ship.mb_galaxyManifestLegal ~= false
	local correct = (action == "clear" and legal) or (action == "detain" and not legal)
	if correct then
		operation.score = (operation.score or 0) + 1
	else
		operation.mistakes = (operation.mistakes or 0) + 1
	end
	operation.progress = (operation.progress or 0) + 1
	ship:SetShipState(action == "clear" and "cleared to pass" or "detained")
	if action == "clear" then
		releaseExpandedShip(ship, "cleared to pass", 52)
	elseif legal then
		ship:SetFlightVelocity(vector_origin)
	else
		ship:SetHostile(false)
		ship:SetShipState("surrendered")
	end
	G.AddCommsHistory("outgoing", ship,
		action == "clear" and "Vessel cleared through Republic checkpoint."
			or "Vessel detained for Republic inspection.", ply)
	G.BroadcastState()
	if operation.progress >= operation.goal then
		timer.Simple(1.5, function()
			if G.Operation ~= operation then return end
			G.ResolveOperation((operation.mistakes or 0) <= 1 and "success" or "failure",
				"Blockade inspection complete: " .. (operation.score or 0)
				.. " correct decision(s), " .. (operation.mistakes or 0)
				.. " error(s).")
		end)
	end
	return true, correct
		and "Checkpoint decision confirmed. The inspection assessment was correct."
		or "Checkpoint decision recorded. Subsequent verification indicates the assessment was incorrect."
end

local function trafficOrderChoices(ship)
	local faction = IsValid(ship) and (ship.mb_galaxyTrueFaction or ship:GetFaction()) or "neutral"
	if faction == "republic" then
		return {
			{ id = "order_depart", label = "ORDER CLEAR LOCAL SPACE" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	elseif faction == "cis" then
		return {
			{ id = "order_withdraw", label = "ORDER IMMEDIATE WITHDRAWAL" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	return {
		{ id = "declare_restricted", label = "DECLARE RESTRICTED AIRSPACE" },
		{ id = "order_reroute", label = "ORDER RE-ROUTE" },
		{ id = "order_depart", label = "ORDER LEAVE LOCAL SPACE" },
		{ id = "close", label = "CLOSE CHANNEL" },
	}
end

function G.DialogueChoicesForShip(ship)
	if not IsValid(ship) then return {} end
	local inspections = MilBase.Inspections
	local faction = inspections and inspections.PublicFaction
		and inspections.PublicFaction(ship, G.ScannedShips[ship] == true)
		or ship.mb_galaxyTrueFaction or ship:GetFaction()
	if ship.mb_galaxyNavigationBeacon then
		return {
			{ id = "read_beacon", label = "READ NAVIGATION TELEMETRY" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	if ship.mb_galaxySensorAnomaly then
		return {
			{ id = "analyze_anomaly", label = "ANALYSE SENSOR SIGNATURE" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	if ship.mb_galaxyBackgroundBattle then
		return {
			{ id = "request_id", label = "REQUEST BATTLE IDENTIFICATION" },
			{ id = "join_battle", label = "JOIN LOCAL ENGAGEMENT" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	if ship.mb_galaxyOrbitalBlockade then
		if faction == "republic" then
			local choices = {
				{ id = "request_id", label = "REQUEST BLOCKADE STATUS" },
			}
			if ship.mb_galaxyOrbitalBlockadeLead then
				local active = G.ActiveOrbitalBlockade
				if active and active.lead == ship and active.formedWithPlayer then
					choices[#choices + 1] = {
						id = "leave_blockade",
						label = "LEAVE BLOCKADE FORMATION",
					}
				else
					choices[#choices + 1] = {
						id = "join_blockade",
						label = "JOIN BLOCKADE FORMATION",
					}
				end
			end
			choices[#choices + 1] = { id = "close", label = "CLOSE CHANNEL" }
			return choices
		end
		return {
			{ id = "request_id", label = "REQUEST OCCUPATION STATUS" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	if ship.mb_galaxySalvage or ship.mb_galaxyRareType == "derelict" then
		return {
			{ id = "recover", label = "BEGIN RECOVERY" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end
	if ship.mb_galaxyBlockade then
		return {
			{ id = "request_id", label = "DEMAND IDENTIFICATION" },
			{ id = "inspect", label = "INSPECT CARGO" },
			{ id = "clear", label = "CLEAR TO PASS" },
			{ id = "detain", label = "DETAIN VESSEL" },
			{ id = "close", label = "CLOSE CHANNEL" },
		}
	end

	local rare = ship.mb_galaxyRareType
	if inspections and inspections.PublicContactType then
		rare = inspections.PublicContactType(ship) or rare
	end
	local choices = {
		{ id = "request_id", label = "REQUEST IDENTIFICATION" },
		{ id = "destination", label = "ASK DESTINATION" },
	}
	if rare == "medical" then
		choices[#choices + 1] = { id = "request_repairs", label = "REQUEST MEDICAL/REPAIR AID" }
		choices[#choices + 1] = { id = "offer_assistance", label = "OFFER SUPPLIES" }
		choices[#choices + 1] = { id = "intel", label = "REQUEST ROUTE REPORT" }
	elseif rare == "bounty" then
		choices[#choices + 1] = { id = "intel", label = "BUY LOCAL INTELLIGENCE" }
		choices[#choices + 1] = { id = "trade", label = "OPEN TRADE CHANNEL" }
		choices[#choices + 1] = { id = "cargo", label = "QUESTION THEIR CONTRACT" }
	elseif rare == "smuggler" then
		choices[#choices + 1] = { id = "cargo", label = "DEMAND CARGO MANIFEST" }
		choices[#choices + 1] = { id = "surrender", label = "ORDER INSPECTION" }
		choices[#choices + 1] = { id = "negotiate", label = "NEGOTIATE COOPERATION" }
	elseif rare == "diplomatic" then
		choices[#choices + 1] = { id = "offer_escort", label = "OFFER DIPLOMATIC ESCORT" }
		choices[#choices + 1] = { id = "intel", label = "EXCHANGE POLITICAL INTEL" }
	elseif rare == "defector" then
		choices[#choices + 1] = { id = "verify_defector", label = "VERIFY DEFECTION" }
		choices[#choices + 1] = { id = "accept_defector", label = "ACCEPT DEFECTION" }
	elseif ship.mb_galaxyConvoy then
		choices[#choices + 1] = { id = "offer_escort", label = "OFFER CONVOY ESCORT" }
		choices[#choices + 1] = { id = "intel", label = "REQUEST ROUTE INTEL" }
	elseif faction == "republic" then
		choices[#choices + 1] = { id = "intel", label = "REQUEST INTELLIGENCE" }
		choices[#choices + 1] = { id = "request_repairs", label = "REQUEST REPAIRS" }
		choices[#choices + 1] = { id = "offer_assistance", label = "OFFER ASSISTANCE" }
		if ship.mb_galaxyOrbitalBlockadeLead then
			local active = G.ActiveOrbitalBlockade
			if active and active.lead == ship and active.formedWithPlayer then
				choices[#choices + 1] = { id = "leave_blockade", label = "RETURN GROUP TO ORBIT" }
			else
				choices[#choices + 1] = { id = "join_blockade", label = "JOIN BLOCKADE FORMATION" }
			end
		elseif ship.mb_galaxyFleetLead then
			if G.ActiveRepublicFleet and G.ActiveRepublicFleet.lead == ship then
				choices[#choices + 1] = { id = "dismiss_fleet", label = "RELEASE TASK FORCE" }
			else
				choices[#choices + 1] = { id = "join_fleet", label = "REQUEST TASK FORCE FORMATION" }
			end
		end
	elseif faction == "civilian" then
		choices[#choices + 1] = { id = "intel", label = "REQUEST INFORMATION" }
		choices[#choices + 1] = { id = "trade", label = "OPEN TRADE CHANNEL" }
		choices[#choices + 1] = { id = "warn", label = "WARN OF LOCAL DANGER" }
		choices[#choices + 1] = { id = "offer_escort", label = "OFFER ESCORT" }
	elseif faction == "pirate" then
		choices[#choices + 1] = { id = "cargo", label = "DEMAND CARGO MANIFEST" }
		choices[#choices + 1] = { id = "negotiate", label = "NEGOTIATE PASSAGE" }
		choices[#choices + 1] = { id = "surrender", label = "DEMAND SURRENDER" }
		choices[#choices + 1] = { id = "engage", label = "DECLARE HOSTILE INTENT" }
	elseif faction == "cis" then
		choices[#choices + 1] = { id = "surrender", label = "DEMAND SURRENDER" }
		choices[#choices + 1] = { id = "warn", label = "ORDER THEM TO WITHDRAW" }
		choices[#choices + 1] = { id = "engage", label = "OPEN HOSTILITIES" }
	end
	if (faction == "civilian" or faction == "pirate") and G.HasRepublicRestrictedAirspace()
	then
		choices[#choices + 1] = { id = "reroute", label = "ORDER RE-ROUTE" }
		choices[#choices + 1] = { id = "leave_restricted", label = "ORDER LEAVE RESTRICTED SPACE" }
	end

	local damaged = not ship.mb_galaxyCombatPrepared
		and ship:GetHull() / math.max(1, ship:GetMaxHull()) <= 0.55
	if damaged and (faction == "pirate" or faction == "cis") then
		choices[#choices + 1] = { id = "counter_board", label = "LAUNCH BOARDING TEAM" }
	end
	if faction == "republic" or faction == "civilian" or faction == "pirate" or faction == "cis" then
		choices[#choices + 1] = { id = "traffic_orders", label = "ISSUE NAVIGATION ORDER" }
	end
	if ship.mb_galaxyUniverseTrafficID and G.IsLivingUniverseDialogueAction then
		choices[#choices + 1] = { id = "crew_manifest", label = "ASK WHO IS ABOARD" }
		choices[#choices + 1] = { id = "crew_story", label = "ASK ABOUT THE CAPTAIN" }
		choices[#choices + 1] = { id = "crew_work", label = "ASK ABOUT THEIR WORK" }
		choices[#choices + 1] = { id = "crew_news", label = "ASK FOR CREW NEWS" }
		choices[#choices + 1] = { id = "crew_supplies", label = "OFFER EMERGENCY SUPPLIES" }
	end
	choices[#choices + 1] = { id = "close", label = "CLOSE CHANNEL" }
	return choices
end

local function hailReply(ship, memory)
	local inspections = MilBase.Inspections
	local faction = inspections and inspections.PublicFaction
		and inspections.PublicFaction(ship, G.ScannedShips[ship] == true)
		or ship.mb_galaxyTrueFaction or ship:GetFaction()
	local rare = ship.mb_galaxyRareType
	if inspections and inspections.PublicContactType then
		rare = inspections.PublicContactType(ship) or rare
	end
	local name = G.CleanText(ship:GetShipName(), 96)
	local remembered = memory and (memory.meetings or 0) > 1
		and " We remember your previous transmission." or ""

	if ship.mb_galaxyNavigationBeacon then
		return "AUTOMATED NAVIGATION BEACON",
			name .. " responds with an encrypted navigation handshake. "
			.. "No organic life signs are present. Complete a sensor scan, then retrieve its route telemetry."
	end
	if ship.mb_galaxySensorAnomaly then
		return "ANOMALOUS SENSOR RETURN",
			name .. " cannot establish a conventional voice channel. "
			.. "The signal is repeating an unknown pattern; complete a sensor scan before analysis."
	end
	if ship.mb_galaxyBackgroundBattle then
		if faction == "republic" then
			return "REPUBLIC BATTLE CHANNEL",
				name .. " is engaged with hostile traffic. \"Republic vessel, assist if you can. "
				.. "Complete a sensor scan and join the engagement through this channel.\""
		elseif faction == "civilian" then
			return "CIVILIAN DISTRESS CHANNEL",
				name .. " transmits through weapons fire. \"We are under attack. Republic vessel, "
				.. "please scan the hostile and join the engagement.\""
		end
		return "HOSTILE BATTLE CHANNEL",
			name .. " returns a hostile tactical burst. \"This route belongs to us. Leave now or "
			.. "join the wreckage.\""
	end

	if rare == "medical" then
		return "MEDICAL CHANNEL ESTABLISHED",
			name .. " answers on a protected relief frequency. \"Republic vessel, "
			.. "state whether you require medical supplies or engineering assistance.\""
	elseif rare == "bounty" then
		return "INDEPENDENT CHANNEL ESTABLISHED",
			name .. " answers cautiously. \"We sell information and collect contracts. "
			.. "Keep this conversation profitable and it stays peaceful.\""
	elseif rare == "smuggler" then
		return "FREIGHT CHANNEL ESTABLISHED",
			name .. " responds after a suspicious delay. \"Our manifest is registered "
			.. "and our schedule is tight. What does the Republic need?\""
	elseif rare == "diplomatic" then
		return "DIPLOMATIC CHANNEL ESTABLISHED",
			name .. " authenticates a diplomatic code. \"We welcome Republic contact. "
			.. "The surrounding routes have become increasingly dangerous.\""
	elseif rare == "defector" then
		return "CIS EMERGENCY CHANNEL",
			name .. " answers with an organic voice beneath a CIS encryption layer. "
			.. "\"Do not fire. We have fleet intelligence and request Republic protection.\""
	end

	if faction == "republic" then
		return "REPUBLIC CHANNEL ESTABLISHED",
			name .. " authenticates a Republic fleet code. \"Your signal is clear. "
			.. "State your request.\"" .. remembered
	elseif faction == "civilian" then
		return "CIVILIAN CHANNEL ESTABLISHED",
			name .. " answers on an open civilian band. \"We read you, Republic vessel. "
			.. "We're willing to exchange information.\"" .. remembered
	elseif faction == "pirate" then
		return "UNSECURED CHANNEL ESTABLISHED",
			name .. " answers with masked routing data. \"You've got our attention. "
			.. "Choose the next words carefully.\"" .. remembered
	elseif faction == "cis" then
		return "CIS CHANNEL ESTABLISHED",
			name .. " returns a hardened transmission. \"Republic vessel identified. "
			.. "Your presence has been recorded.\"" .. remembered
	end
	return "CHANNEL ESTABLISHED",
		name .. " acknowledges the transmission without recognised identification."
end

local function sendConversation(ply, ship, title, body, choices, answered)
	if not IsValid(ply) then return end
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "result",
		answered = answered ~= false,
		title = title,
		body = body,
		contact = validContact(ship) and G.ExpandedContactSnapshot(ship) or {
			entity = IsValid(ship) and ship:EntIndex() or 0,
			name = IsValid(ship) and ship:GetShipName() or "CONTACT LOST",
			faction = "neutral",
			factionName = factionNames.neutral,
			state = "lost",
		},
		choices = choices or {},
	}, ply)
end

function G.HandleHailRequest(ply, ship)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then
		MilBase.Notify(ply, "Remain at the communications terminal to transmit.", "warn")
		return
	end
	if G.Active and G.Active.choices and #G.Active.choices > 0 then
		G.SendEncounter(ply)
		return
	end
	if G.PendingHail or G.PendingScan then
		MilBase.Notify(ply, "The sensor and communications array is occupied.", "warn")
		return
	end
	if (ply.mb_nextGalaxyHail or 0) > CurTime() then
		MilBase.Notify(ply, "The communications array is cycling. Try again shortly.", "warn")
		return
	end
	if not validContact(ship) then
		MilBase.Notify(ply, "That contact is no longer inside local sensor range.", "warn")
		G.SendHailContacts(ply)
		return
	end
	if G.ShipSystemSnapshot().communications < 12 then
		MilBase.Notify(ply, "Communications systems are too damaged to transmit.", "warn")
		return
	end
	if ship.mb_galaxySalvage or ship.mb_galaxyRareType == "derelict" then
		sendConversation(ply, ship, "NO COMMUNICATIONS RESPONSE",
			"No active communications array answers the hail. Assign the contact to the Tactical Scanner before attempting recovery.",
			nil, false)
		return
	end

	G._expandedHailSequence = (G._expandedHailSequence or 0) + 1
	local token = G._expandedHailSequence
	local snapshot = G.ExpandedContactSnapshot(ship)
	G.PendingHail = {
		token = token,
		operator = ply,
		terminal = G.CommsTerminal,
		ship = ship,
	}
	ply.mb_nextGalaxyHail = CurTime()
		+ math.max(1, tonumber(gd.OutgoingHailCooldown) or 8)
	writeCompressed("MilBase_GalaxyHailContacts", {
		mode = "pending",
		title = "TRANSMITTING HAIL",
		contact = snapshot,
		body = "Broadcasting Republic identification on the strongest available frequency...",
	}, ply)
	G.AddCommsHistory("outgoing", ship, "Republic identification and hail transmitted.", ply)
	G.UpdateCommsTerminals()

	local minimum = math.max(0.1, tonumber(gd.OutgoingHailResponseDelayMin) or 0.8)
	local maximum = math.max(minimum, tonumber(gd.OutgoingHailResponseDelayMax) or 2.2)
	local signal = G.ContactSignalStrength(ship)
	local delay = math.Rand(minimum, maximum) * Lerp(signal / 100, 1.7, 0.8)
	timer.Simple(delay, function()
		local pending = G.PendingHail
		if not pending or pending.token ~= token then return end
		G.PendingHail = nil
		if not G.CommsSessionValid(ply, pending.terminal) then
			G.ReleaseCommsOperator(nil, true)
			return
		end
		if not validContact(ship) then
			sendConversation(ply, ship, "CONTACT LOST",
				"The contact left local sensor range before a channel could be established.",
				nil, false)
			G.UpdateCommsTerminals()
			return
		end

		local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
		local memory = G.ContactForShip(ship)
		local chances = gd.HailResponseChance or {}
		local chance = tonumber(chances[faction]) or tonumber(chances.neutral) or 0.7
		chance = chance + (memory.trust or 0) / 250 + (signal - 50) / 220
		if ship:GetHostile() then chance = chance - 0.08 end
		if ship:GetCombat() then chance = chance - 0.08 end
		if ship:GetShipState() == "retreating" then chance = chance - 0.22 end
		local planet = G.EnsurePlanet(G.State.currentPlanet)
		if planet then
			if faction == "civilian" or faction == "republic" then
				chance = chance + planet.republicOpinion / 500
			elseif faction == "cis" then
				chance = chance + planet.cisOpinion / 650
			end
		end
		local answered = ship.mb_galaxyHailAlwaysAnswers == true
			or math.Rand(0, 1) <= math.Clamp(chance, 0.04, 0.99)
		if not answered then
			sendConversation(ply, ship, "NO RESPONSE",
				snapshot.name .. " received the hail but did not open a channel.",
				nil, false)
			G.AddCommsHistory("incoming", ship, "Contact declined or ignored the hail.", ply)
			G.UpdateCommsTerminals()
			return
		end

		memory.meetings = (memory.meetings or 0) + 1
		memory.lastSeen = unix()
		G.SaveContactMemory(memory)
		local title, body = hailReply(ship, memory)
		local choices = G.DialogueChoicesForShip(ship)
		G.HailConversation = {
			operator = ply,
			terminal = pending.terminal,
			ship = ship,
			choices = choices,
			startedAt = CurTime(),
			expiresAt = CurTime() + 180,
		}
		sendConversation(ply, ship, title, body, choices, true)
		G.AddCommsHistory("incoming", ship, body, ply)
		local sound = tostring(gd.CommsHailResponseSound or "buttons/button15.wav")
		if sound ~= "" and IsValid(pending.terminal) then
			pending.terminal:EmitSound(sound, 68, 100, 0.75, CHAN_AUTO)
		end
		G.UpdateCommsTerminals()
	end)
end

function G.StartContactEngagement(ply, ship)
	if G.Active then return false, "Another tactical engagement is active." end
	if G.Operation then return false, "Complete the current fleet operation first." end
	if not validContact(ship) then return false, "The target has left local space." end
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	if faction ~= "pirate" and faction ~= "cis" then
		return false, "Weapons release is not authorised against that contact."
	end
	if not G.Runtime.enabled or not G.Runtime.attacks then
		return false, "Hostile Galaxy Director encounters are currently disabled."
	end
	if faction == "cis" and G.ActivePlayerCount() < math.max(1,
		tonumber(G.Runtime.minPlayersAttack) or 6) then
		return false, "Not enough active personnel are present for a CIS engagement."
	end
	local id = string.format("hail_engagement_%d_%04d", unix(), math.random(1, 9999))
	G.Active = {
		id = id,
		kind = faction == "cis" and "cis" or "pirate",
		title = faction == "cis" and "CIS SKIRMISH" or "PIRATE ENGAGEMENT",
		body = "The hailed vessel has opened fire. Defensive action is authorised.",
		source = ship:GetShipName(),
		phase = faction == "cis" and "skirmish" or "combat",
		startedAt = CurTime(),
		startedUnix = unix(),
		endsAt = CurTime() + 95,
		choices = {},
		entities = { ship },
		contactShip = ship,
		sideYaw = ship.mb_galaxySideYaw or math.Rand(0, 360),
		nextBombardment = CurTime() + 3,
		respondingPlayer = ply,
	}
	ship:SetEncounterID(id)
	ship:SetHostile(true)
	ship:SetInvulnerable(false)
	ship:SetShipState("attacking")
	G.ChangeContactTrust(ship, -15, "Republic crew declared hostile intent.")
	G.AddCommsHistory("outgoing", ship, "Weapons release warning issued.", ply)
	announce(G.Active.title .. ": " .. ship:GetShipName() .. " is attacking.",
		Color(235, 75, 60))
	G.BroadcastState()
	return true
end

local function repairShipNodes(maximum)
	local repaired = 0
	for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
		if node:GetBroken() and node.Fix then
			node:Fix()
			repaired = repaired + 1
			if repaired >= maximum then break end
		end
	end
	return repaired
end

local function intelligenceFromContact(ply, ship)
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local memory = G.ContactForShip(ship)
	local credible = faction == "republic" or faction == "civilian"
		or ship.mb_galaxyRareType == "defector"
	local confidence = credible and math.random(68, 94) or math.random(28, 72)
	confidence = math.Clamp(confidence + math.floor((memory.trust or 0) / 4), 5, 99)
	local danger = G.State.currentRisk or 0.4
	local followup = danger > 0.65 and "cis"
		or faction == "pirate" and "pirate"
		or math.Rand(0, 1) < 0.45 and "distress" or ""
	local details
	if faction == "cis" and ship.mb_galaxyRareType ~= "defector" then
		details = "The contact transmits a probable deception package containing conflicting fleet routes."
		confidence = math.min(confidence, 38)
	elseif followup == "cis" then
		details = "Multiple Separatist drive signatures were observed near the next major route."
	elseif followup == "pirate" then
		details = "Unregistered armed vessels have been stopping civilian traffic nearby."
	elseif followup == "distress" then
		details = "Civilian emergency traffic was detected deeper along the local hyperspace lane."
	else
		details = "No organised hostile fleet has been confirmed in the immediate area."
	end
	G.AddIntel("contact_report", "Report from " .. ship:GetShipName(), details,
		ship:GetShipName(), confidence, followup)
	G.ChangeContactTrust(ship, 1, "Republic crew conducted a professional intelligence exchange.")
	return details .. " Confidence assessment: " .. confidence .. "%."
end

function G.HandleDialogueAction(ply, ship, action)
	if action == "history" then
		G.SendCommsHistory(ply)
		return
	elseif action == "support" then
		local ok, message = G.CallReinforcements(ply)
		MilBase.Notify(ply, message, ok and "ok" or "warn")
		G.SendHailContacts(ply)
		return
	elseif action == "contacts" then
		G.SendHailContacts(ply)
		return
	elseif action == "planet_supply" and MilBase.Naval
	and MilBase.Naval.RequestPlanetSupplies then
		local ok, message = MilBase.Naval.RequestPlanetSupplies(ply)
		MilBase.Notify(ply, message, ok and "ok" or "warn")
		G.SendHailContacts(ply)
		return
	elseif action == "scanner_contacts" then
		G.SendScannerContacts(ply)
		return
	elseif action == "gunner_contacts" then
		G.SendGunnerContacts(ply)
		return
	elseif action == "ion_contacts" then
		G.SendOrdnanceContacts(ply, "ion")
		return
	elseif action == "torpedo_contacts" then
		G.SendOrdnanceContacts(ply, "torpedo")
		return
	elseif action == "scan" then
		G.ScanContact(ply, ship)
		return
	elseif action == "track_route" then
		G.TrackUniverseTrafficContact(ply, ship)
		return
	elseif action == "open_channel" then
		G.HandleHailRequest(ply, ship)
		return
	elseif action == "skybox_volley" then
		local ok, message = G.RequestSkyboxVolley(ply, ship)
		MilBase.Notify(ply, message, ok and "ok" or "warn")
		if ok then G.SendGunnerContacts(ply) end
		return
	elseif action == "skybox_ion" or action == "skybox_torpedo" then
		local kind = action == "skybox_ion" and "ion" or "torpedo"
		local ok, message = G.RequestSkyboxOrdnance(ply, ship, kind)
		MilBase.Notify(ply, message, ok and "ok" or "warn")
		if ok then G.SendOrdnanceContacts(ply, kind) end
		return
	elseif string.sub(action, 1, 6) == "board_" then
		if G.HandleCounterBoardDecision(ply, action) then return end
	end

	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
	if not validContact(ship) then
		MilBase.Notify(ply, "The selected contact has left local space.", "warn")
		G.SendHailContacts(ply)
		return
	end
	if action == "recover" then
		local ok, result = G.StartSalvageOperation(ply, ship)
		MilBase.Notify(ply, ok and "Recovery shuttles deployed." or result,
			ok and "ok" or "warn")
		if ok then G.SendHailContacts(ply) end
		return
	end

	local conversation = G.HailConversation
	if not conversation or conversation.operator ~= ply or conversation.ship ~= ship
	or CurTime() >= (conversation.expiresAt or 0) then
		MilBase.Notify(ply, "That channel is no longer active. Hail the contact again.", "warn")
		G.SendHailContacts(ply)
		return
	end
	local activeChoices = conversation.choices or G.DialogueChoicesForShip(ship)
	local allowed = false
	for _, choice in ipairs(activeChoices) do
		if choice.id == action then
			allowed = true
			break
		end
	end
	if not allowed then return end
	if action == "close" then
		G.HailConversation = nil
		G.SendHailContacts(ply)
		G.UpdateCommsTerminals()
		return
	end
	if action == "traffic_orders" then
		conversation.choices = trafficOrderChoices(ship)
		sendConversation(ply, ship, "REPUBLIC NAVIGATION AUTHORITY",
			"Transmit a lawful local-space directive. Civilian and Republic crews usually comply; "
			.. "pirates and CIS vessels may refuse.", conversation.choices, true)
		return
	end
	local limitedActions = {
		intel = true,
		trade = true,
		warn = true,
		offer_assistance = true,
		request_repairs = true,
		offer_escort = true,
		negotiate = true,
		surrender = true,
		counter_board = true,
		accept_defector = true,
		crew_supplies = true,
	}
	if limitedActions[action] then
		ship.mb_galaxyActionCooldowns = ship.mb_galaxyActionCooldowns or {}
		if (ship.mb_galaxyActionCooldowns[action] or 0) > CurTime() then
			sendConversation(ply, ship, "CHANNEL UPDATE",
				"\"That matter has already been addressed on this channel.\"",
				conversation.choices or G.DialogueChoicesForShip(ship), true)
			return
		end
		ship.mb_galaxyActionCooldowns[action] = CurTime() + 180
	end

	local title = "CHANNEL UPDATE"
	local body
	local inspections = MilBase.Inspections
	local faction = inspections and inspections.PublicFaction
		and inspections.PublicFaction(ship, G.ScannedShips[ship] == true)
		or ship.mb_galaxyTrueFaction or ship:GetFaction()
	if G.IsLivingUniverseDialogueAction
	and G.IsLivingUniverseDialogueAction(action)
	and G.HandleLivingUniverseDialogue then
		local handled, livingTitle, livingBody =
			G.HandleLivingUniverseDialogue(ply, ship, action)
		if handled then
			title = livingTitle or title
			body = livingBody
		end
	elseif ship.mb_galaxyBlockade
	and (action == "inspect" or action == "clear" or action == "detain") then
		local handled, result = G.HandleBlockadeDecision(ply, ship, action)
		if handled then body = result end
	elseif action == "reroute" or action == "leave_restricted" then
		local handled, result = G.HandleRestrictedAirspaceOrder(ply, ship, action)
		if handled then body = result end
	elseif action == "declare_restricted" or action == "order_reroute"
		or action == "order_depart" or action == "order_withdraw" then
		local handled, result = G.HandleTrafficOrder(ply, ship, action)
		if handled then body = result end
	elseif action == "request_status" then
		local hull = math.floor(ship:GetHull() / math.max(1, ship:GetMaxHull()) * 100)
		body = "\"Current status: " .. G.CleanText(ship:GetShipState(), 96)
			.. ". Hull integrity " .. hull .. " percent. "
			.. G.CleanText(ship.mb_galaxyRouteStatus, 160) .. ".\""
	elseif action == "reject_surrender_demand" then
		ship:SetHostile(true)
		ship:SetShipState("Republic surrender demand rejected")
		ship.mb_galaxyRouteStatus = "CIS command has marked the Republic vessel as non-compliant"
		body = "\"Republic vessel rejects CIS surrender terms.\" The droid command signal repeats a hostile target lock warning."
		title = "SURRENDER DEMAND REJECTED"
	elseif action == "request_id" then
		local claimed = ship.mb_galaxyTransponderFaction or faction
		body = "\"" .. ship:GetShipName() .. ". Registered affiliation: "
			.. (factionNames[claimed] or factionNames.neutral) .. ".\""
		if G.ScannedShips[ship] and claimed ~= faction then
			body = body .. " Republic sensors flag the stated affiliation as false."
		end
	elseif action == "destination" then
		body = "\"Our filed destination is "
			.. G.CleanText(ship.mb_galaxyDestination, 160) .. ".\""
	elseif action == "cargo" then
		if G.ScannedShips[ship] or (G.ContactForShip(ship).trust or 0) >= 20 then
			body = "\"Manifest reads " .. G.CleanText(ship.mb_galaxyCargo, 180) .. ".\""
		else
			body = "\"Routine supplies. Nothing requiring Republic attention.\""
		end
	elseif action == "intel" then
		body = intelligenceFromContact(ply, ship)
	elseif action == "trade" then
		local navalOperations = MilBase.Naval
		local opened, tradeMessage = navalOperations
			and navalOperations.OpenContactTrade
			and navalOperations.OpenContactTrade(ply, ship)
		if opened then
			G.ChangeContactTrust(ship, 5, "Republic crew opened a fair exchange.")
			G.AddRecommendation(G.State.currentPlanet, 2, -1,
				"Republic personnel completed a fair trade with local traffic.",
				operatorName(ply))
			body = tradeMessage
		else
			body = tradeMessage or "\"Our cargo exchange is currently unavailable.\""
		end
	elseif action == "warn" then
		G.ChangeContactTrust(ship, faction == "cis" and -2 or 4,
			"Republic crew issued a local danger warning.")
		body = faction == "cis"
			and "\"Your warning is irrelevant. Confederate command already controls this route.\""
			or "\"Warning received. We'll alter course and pass it to the next civilian convoy.\""
	elseif action == "offer_assistance" then
		local missing = math.max(0, ship:GetMaxHull() - ship:GetHull())
		local restored = math.min(missing, math.ceil(ship:GetMaxHull() * 0.28))
		ship:SetHull(ship:GetHull() + restored)
		G.ChangeContactTrust(ship, 9, "Republic crew supplied repairs and provisions.")
		G.AddRecommendation(G.State.currentPlanet, 3, -1,
			"Republic personnel provided aid to a passing vessel.", operatorName(ply))
		body = restored > 0
			and ("Repair teams restore " .. restored .. " hull integrity. The captain sends thanks.")
			or "The vessel needs no hull repair, but accepts reserve supplies for its journey."
	elseif action == "request_repairs" then
		if faction ~= "republic" and ship.mb_galaxyRareType ~= "medical" then
			body = "\"We are not equipped to service a Republic warship.\""
		else
			local repaired = repairShipNodes(ship.mb_galaxyRareType == "medical" and 3 or 2)
			for category, value in pairs(G.SystemDisruption) do
				G.SystemDisruption[category] = math.max(0, value - 25)
			end
			body = repaired > 0
				and ("Remote diagnostics and repair crews restore " .. repaired
					.. " damaged ship-system console(s).")
				or "The contact completes a diagnostic pass and stabilises disrupted subsystems."
		end
	elseif action == "offer_escort" then
		local ok, result = G.StartEscortOperation(ply, ship)
		if ok then
			body = "\"Escort accepted. Form up on our lead and watch the surrounding lanes.\""
			title = "ESCORT ACCEPTED"
		else
			body = result
		end
	elseif action == "join_fleet" then
		local ok, result = G.JoinRepublicFleet(ply, ship)
		body = ok and "\"Republic task force acknowledges. We are taking up formation on your ship.\""
			or result
		title = ok and "TASK FORCE JOINED" or title
	elseif action == "join_blockade" then
		local ok, result = G.JoinOrbitalBlockade(ply, ship)
		body = ok and "\"Acknowledged. The blockade group is forming on your port and starboard.\""
			or result
		title = ok and "BLOCKADE FORMATION JOINED" or title
		if ok then conversation.choices = G.DialogueChoicesForShip(ship) end
	elseif action == "leave_blockade" then
		local ok, result = G.LeaveOrbitalBlockade(ply, ship)
		body = ok and "\"Understood. Returning to the orbital perimeter.\"" or result
		title = ok and "BLOCKADE FORMATION RELEASED" or title
		if ok then conversation.choices = G.DialogueChoicesForShip(ship) end
	elseif action == "dismiss_fleet" then
		local ok, result = G.DismissRepublicFleet(
			"Republic task force released from formation by " .. operatorName(ply) .. ".")
		body = ok and "\"Understood. We are returning to independent patrol.\"" or result
		title = ok and "TASK FORCE RELEASED" or title
	elseif action == "join_battle" then
		local ok, result = G.JoinBackgroundBattle(ply, ship)
		body = ok
			and "\"Republic assistance acknowledged. Concentrate fire on the hostile contact.\""
			or result
		title = ok and "ENGAGEMENT JOINED" or title
	elseif action == "read_beacon" then
		if G.ScannedShips[ship] ~= true then
			body = "Tactical Scanner must authenticate the beacon before its route data can be read."
		elseif ship.mb_galaxyPhenomenonClaimed then
			body = "The beacon's current telemetry package has already been downloaded."
		else
			ship.mb_galaxyPhenomenonClaimed = true
			G.AddIntel("navigation", "Hyperlane navigation telemetry",
				"A navigation beacon supplied current transit timing, hazard notices and nearby route activity.",
				ship:GetShipName(), 68, math.Rand(0, 1) < 0.4 and "pirate" or "cis")
			body = "Authenticated navigation telemetry has been added to Republic route intelligence."
			title = "ROUTE DATA RECEIVED"
		end
	elseif action == "analyze_anomaly" then
		if G.ScannedShips[ship] ~= true then
			body = "The anomaly must be resolved by Tactical Scanner before a safe analysis can begin."
		elseif ship.mb_galaxyPhenomenonClaimed then
			body = "The anomaly's repeating signature has already been catalogued."
		else
			ship.mb_galaxyPhenomenonClaimed = true
			local hostile = math.Rand(0, 1) < 0.55 and "cis" or "pirate"
			G.AddIntel("anomaly", "Analysed sensor anomaly",
				"Signal analysis recovered distorted drive residue and a partial route vector from an unknown contact.",
				ship:GetShipName(), 74, hostile)
			body = "Analysis complete. The signal contained partial drive residue and a usable route vector."
			title = "ANOMALY CATALOGUED"
		end
	elseif action == "negotiate" then
		local memory = G.ContactForShip(ship)
		local chance = math.Clamp(0.55 + (memory.trust or 0) / 180
			- (G.State.currentRisk or 0.4) * 0.2, 0.18, 0.9)
		if table.Count(G.GalaxyDistress) < math.max(1,
			tonumber(gd.GalaxyMaximumVirtualDistress) or 5)
		and math.Rand(0, 1) <= chance then
			G.ChangeContactTrust(ship, 4, "A negotiated passage agreement was honoured.")
			body = "\"Terms accepted. We will clear the Republic route and hold fire.\""
			releaseExpandedShip(ship, "departing under agreement", 58)
		else
			body = "\"Negotiations are over.\" The contact powers its weapons."
			G.StartContactEngagement(ply, ship)
		end
	elseif action == "surrender" then
		local hullFactor = 1 - ship:GetHull() / math.max(1, ship:GetMaxHull())
		local strength = G.ActivePlayerCount()
			/ math.max(1, tonumber(G.Runtime.minPlayersAttack) or 6)
		local chance = math.Clamp(0.12 + hullFactor * 0.55 + strength * 0.2
			+ (G.ContactForShip(ship).trust or 0) / 300, 0.08, 0.9)
		if math.Rand(0, 1) <= chance then
			ship:SetHostile(false)
			ship:SetShipState("surrendered")
			ship:SetFlightVelocity(vector_origin)
			G.ChangeContactTrust(ship, -3, "Vessel surrendered to Republic authority.")
			body = "\"Weapons are powering down. We surrender to Republic authority.\""
			title = "SURRENDER CONFIRMED"
		else
			body = "\"Surrender rejected.\" The vessel powers its weapons."
			G.StartContactEngagement(ply, ship)
		end
	elseif action == "engage" then
		local ok, result = G.StartContactEngagement(ply, ship)
		body = ok and "Weapons release warning transmitted. The contact is engaging."
			or result
	elseif action == "counter_board" then
		local ok, result = G.StartCounterBoardOperation(ply, ship)
		body = ok and "Boarding shuttles launched. Await the strike team's breach signal."
			or result
	elseif action == "verify_defector" then
		if G.ScannedShips[ship] ~= true then
			body = "The defection cannot be authenticated without a complete sensor scan."
		else
			body = "Republic analysis confirms CIS encryption keys and matching fleet telemetry. "
				.. "The defection claim is credible."
			ship.mb_galaxyDefectorVerified = true
		end
	elseif action == "accept_defector" then
		if not ship.mb_galaxyDefectorVerified then
			body = "Fleet protocol requires sensor verification before accepting the defector."
		else
			G.ChangeContactTrust(ship, 18, "Republic protection granted to CIS defectors.")
			G.AddRecommendation(G.State.currentPlanet, 4, -4,
				"Republic forces protected CIS defectors and recovered strategic intelligence.",
				operatorName(ply))
			G.AddIntel("defector", "Verified CIS defector intelligence",
				"The defectors supplied current Separatist authentication codes and fleet routes.",
				ship:GetShipName(), 96, "cis")
			body = "\"Protection acknowledged. Transmitting our intelligence package now.\""
			ship:SetFaction("civilian")
			ship.mb_galaxyTrueFaction = "civilian"
			releaseExpandedShip(ship, "under Republic protection", 48)
		end
	end

	if not body then return end
	G.AddCommsHistory("incoming", ship, body, ply)
	if validContact(ship) and G.HailConversation
	and G.HailConversation.ship == ship then
		sendConversation(ply, ship, title, body,
			G.HailConversation.choices or G.DialogueChoicesForShip(ship), true)
	else
		G.SendHailContacts(ply)
	end
	G.BroadcastState()
end

net.Receive("MilBase_GalaxyHailAction", function(_, ply)
	if (ply.mb_nextGalaxyHailAction or 0) > CurTime() then return end
	ply.mb_nextGalaxyHailAction = CurTime() + 0.3
	local action = G.CleanText(net.ReadString(), 40)
	local ship = Entity(net.ReadUInt(16))
	G.HandleDialogueAction(ply, ship, action)
end)

function G.SpawnWreckageAt(pos, source)
	if not isvector(pos) then return nil end
	for i = #G.Wreckage, 1, -1 do
		if not IsValid(G.Wreckage[i]) then table.remove(G.Wreckage, i) end
	end
	while #G.Wreckage >= 4 do
		local removableIndex
		for index, candidate in ipairs(G.Wreckage) do
			if not IsValid(candidate) or not candidate.mb_navalSalvageReservedBy then
				removableIndex = index
				break
			end
		end
		if not removableIndex then break end
		local oldest = table.remove(G.Wreckage, removableIndex)
		if IsValid(oldest) then oldest:Remove() end
	end

	local wreck = ents.Create("mb_galaxy_ship")
	if not IsValid(wreck) then return nil end
	local sourceValid = IsValid(source)
	local sourceRole = sourceValid and source:GetRole() or "civilian"
	local model = sourceValid and source:GetModel()
		or G.ResolveShipModel and G.ResolveShipModel(sourceRole) or ""
	if not util.IsValidModel(model) then model = "models/props_debris/metal_panel02a.mdl" end
	if not util.IsValidModel(model) then model = "models/hunter/blocks/cube1x1x1.mdl" end
	local sourceName = sourceValid and source:GetShipName() or "Unknown vessel"
	local sourceScale = sourceValid and math.max(0.005, source:GetModelSize())
		or math.max(0.005, tonumber(gd.ShipModelScale
			and gd.ShipModelScale[sourceRole]) or 0.06)
	local sourceRadius = sourceValid and math.max(20, source:GetCombatRadius())
		or math.max(20, tonumber(G.MaximumRoleShipRadius
			and G.MaximumRoleShipRadius(sourceRole)) or 45)
	local sourceCapital = sourceValid and source:GetCapital() or false
	wreck:SetModel(model)
	wreck:SetPos(pos)
	wreck:SetAngles(sourceValid and source:GetAngles()
		+ Angle(math.Rand(-8, 8), math.Rand(-12, 12), math.Rand(-20, 20)) or AngleRand())
	wreck:SetShipName("Wreck of " .. sourceName)
	wreck:SetFaction("neutral")
	wreck:SetRole("salvage")
	wreck:SetEncounterID("")
	wreck:SetShipState("burning wreckage")
	wreck:SetHostile(false)
	wreck:SetCapital(sourceCapital)
	wreck:SetInvulnerable(true)
	wreck:SetModelSize(sourceScale)
	wreck:SetCombatRadius(sourceRadius)
	wreck:SetMaxHull(100)
	wreck:SetHull(100)
	wreck:SetFlightVelocity(VectorRand() * math.Rand(0.4, 1.4))
	local naval = MilBase.Config.NavalOperations or {}
	wreck:SetDieAt(CurTime() + math.max(300,
		tonumber(naval.FleetSalvageWreckLifetime) or 900))
	wreck:Spawn()
	wreck:Activate()
	wreck:SetColor(Color(112, 112, 112))
	wreck:SetNW2Bool("MBGalaxyWreckage", true)
	wreck.mb_galaxySkyboxManaged = true
	wreck.mb_galaxyHoldForPlayerDeparture = false
	wreck.mb_galaxyPlayerDeparting = true
	wreck.mb_galaxySalvage = true
	wreck.mb_galaxySurvivors = IsValid(source)
		and tonumber(source.mb_livingSurvivorCount)
		or (math.Rand(0, 1) < 0.42 and math.random(1, 6) or 0)
	wreck.mb_galaxySourceName = sourceName
	wreck.mb_livingDestroyedVesselID = sourceValid
		and source.mb_livingDestroyedVesselID or nil
	local fundingMinimum = math.max(0,
		tonumber(naval.FleetSalvageFundingMinimum) or 1800)
	local fundingMaximum = math.max(fundingMinimum,
		tonumber(naval.FleetSalvageFundingMaximum) or 6200)
	local scrapMinimum = math.max(1,
		math.floor(tonumber(naval.FleetSalvageScrapMinimum) or 18))
	local scrapMaximum = math.max(scrapMinimum,
		math.floor(tonumber(naval.FleetSalvageScrapMaximum) or 65))
	local capitalMultiplier = sourceCapital
		and math.max(1, tonumber(naval.FleetSalvageCapitalMultiplier) or 1.8) or 1
	wreck.mb_navalSalvageFunding = math.floor(math.Rand(
		fundingMinimum, fundingMaximum) * capitalMultiplier)
	wreck.mb_navalSalvageScrap = math.floor(math.random(
		scrapMinimum, scrapMaximum) * capitalMultiplier)
	G.InitializeShipIdentity(wreck, {
		trueFaction = "neutral",
		transponderFaction = "neutral",
		expansionType = "salvage",
		cargo = math.Rand(0, 1) < 0.5
			and cargoPools[math.random(#cargoPools)]
			or "damaged components and fragmented flight recorders",
		weapons = "no active weapons signatures",
	})
	G.BindShipToSWUUniverse(wreck)
	G.AmbientShips[#G.AmbientShips + 1] = wreck
	G.Wreckage[#G.Wreckage + 1] = wreck
	return wreck
end

local function activeAmbientPhenomenaCount()
	local count = 0
	for index = #G.AmbientPhenomena, 1, -1 do
		local ent = G.AmbientPhenomena[index]
		if not IsValid(ent) then
			table.remove(G.AmbientPhenomena, index)
		else
			count = count + 1
		end
	end
	return count
end

local function spawnAmbientPhenomenonContact(kind)
	local role = "salvage"
	local pos, direction, yaw = G.FindClearSkyboxEntry(math.Rand(0, 360),
		math.Rand(-220, 220), math.Rand(-180, 180), role)
	if not isvector(pos) then return nil end
	local definitions = {
		beacon = {
			model = "models/props_lab/reciever01b.mdl",
			name = "Hyperlane Navigation Beacon",
			state = "broadcasting route telemetry",
			cargo = "automated navigation telemetry and hazard notices",
			weapons = "no weapons or life signs detected",
			scale = 0.42,
		},
		anomaly = {
			model = "models/props_debris/metal_panel02a.mdl",
			name = "Unidentified Sensor Anomaly",
			state = "anomalous energy signature",
			cargo = "distorted drive residue and fragmented telemetry",
			weapons = "no coherent weapons lock detected",
			scale = 0.58,
		},
	}
	local definition = definitions[kind]
	if not definition then return nil end
	local ent = ents.Create("mb_galaxy_ship")
	if not IsValid(ent) then return nil end
	if not util.IsValidModel(definition.model) then definition.model = "models/hunter/blocks/cube1x1x1.mdl" end
	ent:SetModel(definition.model)
	ent:SetPos(pos)
	ent:SetAngles((direction * -1):Angle())
	ent:SetShipName(definition.name)
	ent:SetFaction("neutral")
	ent:SetRole(role)
	ent:SetEncounterID("")
	ent:SetShipState(definition.state)
	ent:SetHostile(false)
	ent:SetCapital(false)
	ent:SetInvulnerable(true)
	ent:SetModelSize(definition.scale)
	ent:SetMaxHull(100)
	ent:SetHull(100)
	ent:SetFlightVelocity(vector_origin)
	ent:SetDieAt(CurTime() + math.max(60, tonumber(gd.AmbientPhenomenaLifetime) or 210))
	ent:Spawn()
	ent:Activate()
	ent.mb_galaxySideYaw = yaw
	ent.mb_galaxySkyboxManaged = true
	ent.mb_galaxyHoldForPlayerDeparture = true
	ent.mb_galaxyPlayerDeparting = false
	ent.mb_galaxyPhenomenon = kind
	ent.mb_galaxyHailAlwaysAnswers = true
	ent.mb_galaxyNavigationBeacon = kind == "beacon"
	ent.mb_galaxySensorAnomaly = kind == "anomaly"
	ent:SetNWString("mb_galaxy_phenomenon", kind)
	G.InitializeShipIdentity(ent, {
		trueFaction = "neutral",
		transponderFaction = "neutral",
		expansionType = kind,
		cargo = definition.cargo,
		weapons = definition.weapons,
	})
	G.BindShipToSWUUniverse(ent)
	G.AmbientShips[#G.AmbientShips + 1] = ent
	G.AmbientPhenomena[#G.AmbientPhenomena + 1] = ent
	return ent
end

function G.SpawnDebrisField()
	local maximum = math.max(1, tonumber(gd.AmbientPhenomenaMaximum) or 3)
	local available = maximum - activeAmbientPhenomenaCount()
	if available <= 0 then return 0 end
	local origin = select(1, G.FindClearSkyboxEntry(math.Rand(0, 360),
		math.Rand(-180, 180), math.Rand(-140, 140), "salvage"))
	if not isvector(origin) then return 0 end
	local created = 0
	for index = 1, math.min(math.random(2, 3), available) do
		local offset = VectorRand() * math.Rand(45, 180)
		local pos = origin + offset
		if not G.PlanetClearanceAt(pos, 35) then pos = origin end
		local wreck = G.SpawnWreckageAt(pos)
		if IsValid(wreck) then
			wreck:SetShipName("Unmarked Debris Field " .. string.format("%03d", math.random(1, 999)))
			wreck:SetDieAt(CurTime() + math.max(60, tonumber(gd.AmbientPhenomenaLifetime) or 210))
			wreck.mb_galaxyDebrisField = true
			wreck:SetNWString("mb_galaxy_phenomenon", "debris")
			G.AmbientPhenomena[#G.AmbientPhenomena + 1] = wreck
			created = created + 1
		end
	end
	return created
end

function G.SpawnAmbientPhenomenon(kind)
	if gd.AmbientPhenomenaEnabled == false then return 0 end
	if activeAmbientPhenomenaCount() >= math.max(1,
		tonumber(gd.AmbientPhenomenaMaximum) or 3) then return 0 end
	if not kind or kind == "random" then
		local beaconChance = math.Clamp(tonumber(gd.NavigationBeaconChance) or 0.38, 0, 1)
		local anomalyChance = math.Clamp(tonumber(gd.SensorAnomalyChance) or 0.38, 0, 1)
		local roll = math.Rand(0, 1)
		kind = roll <= beaconChance and "beacon"
			or roll <= math.min(1, beaconChance + anomalyChance) and "anomaly" or "debris"
	end
	local created = kind == "debris" and G.SpawnDebrisField()
		or IsValid(spawnAmbientPhenomenonContact(kind)) and 1 or 0
	if created > 0 and IsValid(G.ScannerOperator)
	and G.ScannerSessionValid(G.ScannerOperator, G.ScannerTerminal) then
		G.SendScannerContacts(G.ScannerOperator)
	end
	return created
end

local baseOnShipDestroyed = G.OnShipDestroyed
function G.OnShipDestroyed(ship, attacker)
	local pos = IsValid(ship) and Vector(ship:GetPos()) or nil
	local eligible = IsValid(ship) and not ship.mb_galaxySalvage
		and ship:GetRole() ~= "salvage"
	local backgroundBattle = G.BackgroundBattleForShip and G.BackgroundBattleForShip(ship)
	baseOnShipDestroyed(ship, attacker)
	if backgroundBattle then
		G.ResolveBackgroundBattle(backgroundBattle,
			backgroundBattle.attacker == ship and "success" or "failure",
			backgroundBattle.attacker == ship
				and "The hostile contact was destroyed during the local space engagement."
				or "The Republic-aligned contact was destroyed during the local space engagement.")
	end
	if eligible and isvector(pos) and math.Rand(0, 1) <= 0.78 then
		timer.Simple(0.05, function()
			local wreck = G.SpawnWreckageAt(pos, ship)
			if IsValid(wreck) then
				G.AftermathUntil = CurTime()
					+ math.max(60, tonumber(gd.AftermathDuration) or 300)
				announce("Debris and possible lifepod signals detected after the engagement.",
					Color(235, 175, 70))
				G.BroadcastState()
			end
		end)
	end
end

local rareKeys = { "medical", "bounty", "smuggler", "diplomatic", "derelict", "defector" }

function G.SpawnRareContact()
	local kind = rareKeys[math.random(#rareKeys)]
	local definition = (gd.RareContactTypes or {})[kind] or {}
	local faction = definition.faction or "civilian"
	local role = faction == "cis" and "cis_scout"
		or faction == "pirate" and "pirate"
		or faction == "republic" and "republic" or "civilian"
	local opts = {
		sideYaw = math.Rand(0, 360),
		hold = true,
		faction = faction,
		trueFaction = faction,
		hostile = false,
		invulnerable = kind ~= "derelict",
		hull = kind == "derelict" and 700 or 2200,
		name = definition.name or ("Unusual " .. kind .. " contact"),
		expansionType = kind,
		manifestLegal = kind ~= "smuggler",
	}
	if kind == "smuggler" then
		opts.transponderFaction = "civilian"
		opts.cargo = contrabandPools[math.random(#contrabandPools)]
	elseif kind == "defector" then
		opts.transponderFaction = "cis"
		opts.weapons = "CIS defensive batteries powered down"
	elseif kind == "medical" then
		opts.cargo = "medical supplies, bacta and emergency repair stores"
	elseif kind == "diplomatic" then
		opts.cargo = "sealed diplomatic containers and civilian passengers"
	elseif kind == "derelict" then
		opts.cargo = "unknown cargo behind unpowered bulkheads"
		opts.weapons = "weapons systems offline"
	end
	local ship = G.SpawnShip(role, opts)
	if not IsValid(ship) then return nil end
	ship:SetDieAt(CurTime() + 210)
	if kind == "derelict" then
		ship:SetShipState("adrift")
		ship:SetHull(math.floor(ship:GetMaxHull() * 0.32))
		ship.mb_galaxySurvivors = math.Rand(0, 1) < 0.3 and math.random(1, 4) or 0
	else
		ship:SetShipState("requesting route clearance")
	end
	if G.AssignAutonomousShipMotion then
		G.AssignAutonomousShipMotion(ship, "unusual contact continuing its route")
	end
	announce("An unusual sensor contact has entered local space.",
		Color(110, 195, 235))
	G.BroadcastState()
	return ship
end

function G.SpawnCivilianConvoy()
	local group = "convoy_" .. unix() .. "_" .. math.random(100, 999)
	local count = math.random(2, 3)
	local side = math.Rand(0, 360)
	local ships = {}
	for i = 1, count do
		local ship = G.SpawnShip("civilian", {
			sideYaw = side,
			lane = (i - (count + 1) / 2) * 135,
			hold = true,
			faction = "civilian",
			trueFaction = "civilian",
			name = i == 1 and "Civilian Convoy Aurek"
				or ("Civilian Freighter " .. string.char(64 + i)),
			expansionType = i == 1 and "convoy" or nil,
			cargo = cargoPools[math.random(#cargoPools)],
		})
		if IsValid(ship) then
			ship.mb_galaxyConvoy = true
			ship.mb_galaxyConvoyGroup = group
			ship:SetShipState("awaiting escort clearance")
			ship:SetDieAt(CurTime() + 210)
			ships[#ships + 1] = ship
		end
	end
	if #ships > 0 then
		local lead = ships[1]
		local moving = G.AssignAutonomousShipMotion
			and G.AssignAutonomousShipMotion(lead, "civilian convoy route")
		if moving and G.SetShipFormationFollower then
			for index = 2, #ships do
				local follower = ships[index]
				G.SetShipFormationFollower(follower, lead,
					Vector(-150 * (index - 1),
						(index % 2 == 0 and 1 or -1) * 135,
						(index % 3 - 1) * 45), { speed = 36 })
				follower:SetShipState("travelling in civilian convoy formation")
			end
			lead:SetShipState("leading civilian convoy through local space")
		end
		announce("Civilian convoy detected on a route through local space.",
			Color(115, 215, 155))
		G.BroadcastState()
	end
	return ships
end

function G.SpawnRepublicFleetRendezvous()
	if gd.RepublicFleetRendezvousEnabled == false
	or G.ActiveRepublicFleet or G.PendingRepublicFleet then return {} end
	local group = "republic_task_force_" .. unix() .. "_" .. math.random(100, 999)
	local side = math.Rand(0, 360)
	local ships = {}
	local lead = G.SpawnShip("republic_flagship", {
		sideYaw = side,
		hold = true,
		faction = "republic",
		trueFaction = "republic",
		name = "Venator Task Force " .. string.char(math.random(65, 90)),
		hull = 5200,
		invulnerable = true,
	})
	if IsValid(lead) then
		lead.mb_galaxyRepublicFleet = true
		lead.mb_galaxyFleetLead = true
		lead.mb_galaxyFleetGroup = group
		lead:SetShipState("Republic task force holding")
		lead:SetDieAt(CurTime() + 180)
		ships[#ships + 1] = lead
	end
	local minimum = math.max(1, math.floor(tonumber(gd.RepublicFleetEscortCountMin) or 1))
	local maximum = math.max(minimum, math.floor(tonumber(gd.RepublicFleetEscortCountMax) or 3))
	for index = 1, math.random(minimum, maximum) do
		local escort = G.SpawnShip("republic", {
			sideYaw = side,
			lane = (index - (maximum + 1) / 2) * 210,
			height = (index % 2 == 0 and 1 or -1) * 95,
			hold = true,
			faction = "republic",
			trueFaction = "republic",
			name = "Republic Task Force Escort " .. string.char(64 + index),
			hull = 2600,
			invulnerable = true,
		})
		if IsValid(escort) then
			escort.mb_galaxyRepublicFleet = true
			escort.mb_galaxyFleetGroup = group
			escort:SetShipState("Republic task force holding")
			escort:SetDieAt(CurTime() + 180)
			ships[#ships + 1] = escort
		end
	end
	if #ships > 0 then
		local moving = IsValid(lead) and G.AssignAutonomousShipMotion
			and G.AssignAutonomousShipMotion(lead, "Republic task force patrol")
		if moving and G.SetShipFormationFollower then
			local followerIndex = 0
			for _, ship in ipairs(ships) do
				if ship ~= lead then
					followerIndex = followerIndex + 1
					G.SetShipFormationFollower(ship, lead,
						Vector(-210 * followerIndex,
							(followerIndex % 2 == 0 and 1 or -1) * 230,
							(followerIndex % 3 - 1) * 65), { speed = 31 })
					ship:SetShipState("patrolling in Republic task force formation")
				end
			end
			lead:SetShipState("leading Republic task force patrol")
		end
		G.PendingRepublicFleet = {
			lead = lead,
			ships = ships,
			expiresAt = CurTime() + 180,
		}
		announce("Republic task force detected in the skybox. Hail its Venator lead to request formation.",
			Color(80, 155, 240))
		G.BroadcastState()
	end
	return ships
end

function G.DismissRepublicFleet(reason, silent)
	local fleet = G.ActiveRepublicFleet
	if not fleet then return false, "No Republic task force is currently in formation." end
	for _, ship in ipairs(fleet.ships or {}) do
		if IsValid(ship) then
			ship.mb_galaxyFleetFollowing = nil
			ship.mb_galaxyFleetLead = nil
			ship.mb_galaxyRepublicFleet = nil
			ship.mb_galaxyFleetGroup = nil
			ship:SetInvulnerable(true)
			releaseExpandedShip(ship, "returning to Republic patrol", 58)
		end
	end
	G.ActiveRepublicFleet = nil
	if not silent then
		announce(reason or "Republic task force has broken formation and returned to patrol.",
			Color(80, 155, 240))
	end
	G.BroadcastState()
	return true, reason or "Republic task force dismissed."
end

function G.JoinRepublicFleet(ply, lead)
	if not validContact(lead) or not lead.mb_galaxyFleetLead then
		return false, "That ship is not a Republic task-force lead."
	end
	if G.ActiveRepublicFleet then
		if G.ActiveRepublicFleet.lead == lead then
			return false, "This Republic task force is already in formation with the ship."
		end
		return false, "Another Republic task force is already following the ship."
	end
	local group = lead.mb_galaxyFleetGroup
	local ships = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship) and ship.mb_galaxyFleetGroup == group then
			ships[#ships + 1] = ship
		end
	end
	if #ships == 0 then return false, "The Republic task force has already departed." end
	local duration = math.max(60, tonumber(gd.RepublicFleetFollowDuration) or 360)
	local fleet = {
		lead = lead,
		ships = ships,
		operator = ply,
		expiresAt = CurTime() + duration,
	}
	for _, ship in ipairs(ships) do
		ship:SetDieAt(fleet.expiresAt + 25)
		ship:SetFlightVelocity(vector_origin)
		ship.mb_galaxyFleetFollowing = true
		ship.mb_galaxyHoldForPlayerDeparture = true
		ship.mb_galaxyPlayerDeparting = false
		ship:SetShipState("escorting Republic ship")
		G.BindShipToSWUUniverse(ship)
	end
	G.ActiveRepublicFleet = fleet
	G.PendingRepublicFleet = nil
	G.AddCommsHistory("outgoing", lead,
		"Republic task force accepted a temporary formation request.", ply)
	announce("Republic task force has joined formation with the Republic ship.",
		Color(80, 155, 240))
	G.BroadcastState()
	return true, "Republic task force is now following the ship. Hail the Venator lead again to dismiss it."
end

function G.UpdateRepublicFleetFollow(now)
	local pending = G.PendingRepublicFleet
	if pending then
		local remaining = {}
		for _, ship in ipairs(pending.ships or {}) do
			if validContact(ship) then remaining[#remaining + 1] = ship end
		end
		pending.ships = remaining
		if #remaining == 0 or now >= (pending.expiresAt or 0) then
			G.PendingRepublicFleet = nil
		end
	end
	local fleet = G.ActiveRepublicFleet
	if not fleet then return end
	local validShips = {}
	for _, ship in ipairs(fleet.ships or {}) do
		if validContact(ship) then validShips[#validShips + 1] = ship end
	end
	fleet.ships = validShips
	if #validShips == 0 then
		G.ActiveRepublicFleet = nil
		return
	end
	if now >= (fleet.expiresAt or 0) then
		G.DismissRepublicFleet("Republic task force has received new patrol orders and is leaving formation.")
	end
end

local setTransitRoute

local function activeAmbientTrafficCount()
	local count = 0
	for index = #G.AmbientTrafficShips, 1, -1 do
		local ship = G.AmbientTrafficShips[index]
		if not IsValid(ship) or not ship.mb_galaxyAmbientTraffic then
			table.remove(G.AmbientTrafficShips, index)
		else
			count = count + 1
		end
	end
	return count
end

local function activePlanetTrafficCount()
	local count = 0
	for index = #G.PlanetTrafficShips, 1, -1 do
		local ship = G.PlanetTrafficShips[index]
		if not IsValid(ship) or not ship.mb_galaxyPlanetTraffic then
			table.remove(G.PlanetTrafficShips, index)
		else
			count = count + 1
		end
	end
	return count
end

local function planetTrafficName(planet)
	if IsValid(planet) and planet.GetPlanetName then
		local ok, name = pcall(planet.GetPlanetName, planet)
		if ok and isstring(name) and name ~= "" then return G.CleanText(name, 96) end
	end
	if IsValid(planet) then
		local name = planet:GetName()
		if isstring(name) and name ~= "" then return G.CleanText(name, 96) end
		if planet.GetUniversePos and G.FindNearestPlanet then
			local ok, position = pcall(planet.GetUniversePos, planet)
			local nearest = ok and isvector(position) and G.FindNearestPlanet(position) or nil
			if nearest and nearest.name then return G.CleanText(nearest.name, 96) end
		end
	end
	return G.CleanText((G.State and G.State.currentPlanet) or "local planetary surface", 96)
end

-- Find a point just above the visible side of a planet.  This is deliberately
-- outside the ship/planet collision clearance, so it looks like a descent or
-- launch corridor without allowing props to clip through a planet model.
local function findPlanetTrafficPort(role)
	if not G.GetPlanetObstacles or not G.PlanetWorldPosition or not G.PlanetObstacleRadius then
		return nil
	end
	local center = select(1, G.SkyboxFrame())
	local shipRadius = G.MaximumRoleShipRadius(role)
	local margin = math.max(0, tonumber(gd.PlanetAvoidanceMargin) or 180)
	local surfaceClearance = math.max(40, tonumber(gd.PlanetTrafficSurfaceClearance) or 280)
	local ports = {}
	for _, planet in ipairs(G.GetPlanetObstacles()) do
		local position = G.PlanetWorldPosition(planet)
		local radius = G.PlanetObstacleRadius(planet)
		if isvector(position) and radius > 0 and G.IsInsideSkybox(position) then
			local normal = center - position
			if normal:LengthSqr() < 1 then normal = VectorRand() end
			normal:Normalize()
			local point = position + normal * (radius + shipRadius + margin + surfaceClearance)
			local clear = G.PlanetClearanceAt(point, shipRadius)
			if clear and G.IsInsideSkybox(point) then
				ports[#ports + 1] = {
					planet = planet,
					name = planetTrafficName(planet),
					position = position,
					point = point,
					normal = normal,
					safeRadius = radius + shipRadius + margin + surfaceClearance,
				}
			end
		end
	end
	if #ports == 0 then return nil end
	return ports[math.random(#ports)]
end

local function trafficFactionForRole(role)
	return role == "cis_scout" and "cis" or role
end

local function choosePlanetTrafficRole()
	local roll = math.Rand(0, 1)
	if roll < 0.64 then return "civilian" end
	if roll < 0.9 then return "republic" end
	return "pirate"
end

local function trafficColor(ship)
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	return faction == "republic" and Color(70, 145, 255)
		or faction == "pirate" and Color(235, 170, 55)
		or faction == "cis" and Color(235, 65, 55) or Color(175, 220, 255)
end

local function registerPlanetTraffic(ship)
	if not IsValid(ship) then return end
	ship.mb_galaxyPlanetTraffic = true
	G.PlanetTrafficShips[#G.PlanetTrafficShips + 1] = ship
	G.AmbientTrafficShips[#G.AmbientTrafficShips + 1] = ship
end

local function routeCurveWaypoint(ship, destination)
	if gd.ShipRouteWaypointEnabled == false or not IsValid(ship)
		or not isvector(destination) then return { destination } end
	local start = ship:GetPos()
	local travel = destination - start
	local distance = travel:Length()
	if distance < 420 then return { destination } end
	local direction = travel:GetNormalized()
	local lateral = direction:Cross(Vector(0, 0, 1))
	if lateral:LengthSqr() < 0.001 then lateral = direction:Cross(Vector(0, 1, 0)) end
	if lateral:LengthSqr() < 0.001 then return { destination } end
	lateral:Normalize()
	if math.random(2) == 1 then lateral:Mul(-1) end
	local curve = math.Clamp(distance * math.max(0.04,
		tonumber(gd.ShipRouteCurveFraction) or 0.16), 100, 650)
	local vertical = math.Rand(-curve * 0.1, curve * 0.1)
	local first = start + travel * 0.34 + lateral * curve * 0.88
		+ Vector(0, 0, vertical * 0.72)
	local second = start + travel * 0.68 + lateral * curve * 0.82
		+ Vector(0, 0, vertical)
	local shipRadius = G.MaximumRoleShipRadius(ship:GetRole())
	local firstClear = G.PlanetClearanceAt(first, shipRadius)
	local secondClear = G.PlanetClearanceAt(second, shipRadius)
	if firstClear and secondClear
	and G.IsInsideSkybox(first) and G.IsInsideSkybox(second) then
		return { first, second, destination }
	end
	return { destination }
end

local function planetOrbitWaypoint(port)
	if not port or not isvector(port.position) or not isvector(port.normal) then return nil end
	local tangent = port.normal:Cross(Vector(0, 0, 1))
	if tangent:LengthSqr() < 0.001 then tangent = port.normal:Cross(Vector(0, 1, 0)) end
	if tangent:LengthSqr() < 0.001 then return nil end
	tangent:Normalize()
	if math.random(2) == 1 then tangent:Mul(-1) end
	local radial = port.normal + tangent * 0.82
	radial:Normalize()
	local orbit = port.position + radial * math.max(1, tonumber(port.safeRadius) or 1)
	local clear = G.PlanetClearanceAt(orbit, 0)
	return clear and G.IsInsideSkybox(orbit) and orbit or nil
end

local function setPlanetApproachRoute(ship, port)
	if not IsValid(ship) or not port or not isvector(port.point) then return false end
	local travel = port.point - ship:GetPos()
	if travel:LengthSqr() < 100 then return false end
	local speed = math.max(8, tonumber(gd.PlanetTrafficApproachSpeed) or 30)
	local velocity = travel:GetNormalized() * speed
	ship:SetFlightVelocity(velocity)
	ship:SetShipState("inbound to " .. port.name .. " surface corridor")
	ship.mb_galaxyAmbientTraffic = true
	ship.mb_galaxyTrafficPattern = "planet_arrival"
	ship.mb_galaxyPlanetPhase = "arrival"
	ship.mb_galaxyPlanetName = port.name
	ship.mb_galaxyPlanetPoint = Vector(port.point)
	ship.mb_galaxyRouteStatus = "descending through " .. port.name .. " orbital control"
	ship.mb_galaxyRouteKind = "planetary arrival"
	ship.mb_galaxyLastFlightVelocity = nil
	ship:SetDieAt(0)
	if G.HasSWUUniverseFrame() then
		G.UpdateShipTravelFacing(ship, velocity, SWU.Controller:GetInternalShipAngles(), 0, false)
	else
		G.UpdateShipTravelFacing(ship, velocity, angle_zero, 0, true)
	end
	if gd.HyperspaceTransitEffectsEnabled ~= false and G.EmitHyperspaceBurst then
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), velocity, trafficColor(ship), true)
	end
	if G.SetShipFlightRoute then
		local waypoints = {}
		local orbit = planetOrbitWaypoint(port)
		if isvector(orbit) then waypoints[#waypoints + 1] = orbit end
		waypoints[#waypoints + 1] = port.point
		G.SetShipFlightRoute(ship, waypoints, {
			speed = speed,
			arrivalRadius = math.max(60, tonumber(gd.PlanetTrafficArrivalRadius) or 170),
			finalStop = true,
		})
		G.UpdateShipFlightRoute(ship)
	end
	registerPlanetTraffic(ship)
	return true
end

function G.SpawnPlanetTraffic()
	if gd.PlanetTrafficEnabled == false or not G.HasSWUUniverseFrame() then return 0 end
	local maximum = math.max(1, math.floor(tonumber(gd.PlanetTrafficMaximumShips) or 4))
	if activePlanetTrafficCount() >= maximum then return 0 end
	local ambientMaximum = math.max(1, math.floor(tonumber(gd.AmbientTrafficMaximumShips) or 9))
	if activeAmbientTrafficCount() >= ambientMaximum then return 0 end

	local role = choosePlanetTrafficRole()
	local faction = trafficFactionForRole(role)
	local port = findPlanetTrafficPort(role)
	if not port then return 0 end
	local departing = math.Rand(0, 1) <= math.Clamp(tonumber(gd.PlanetTrafficTakeoffChance) or 0.48, 0, 1)
	local origin = departing and port.name or ((G.State and G.State.currentPlanet) or "the local orbital lane")
	local destination = departing and chooseKnownDestination(port.name) or port.name

	if departing then
		local exitYaw = math.Rand(0, 360)
		local exit = select(1, G.FindClearSkyboxEntry(exitYaw, math.Rand(-120, 120),
			math.Rand(-120, 120), role))
		if not isvector(exit) then return 0 end
		local ship = G.SpawnShip(role, {
			sideYaw = exitYaw + 180,
			hold = true,
			faction = faction,
			trueFaction = faction,
			invulnerable = true,
			trafficPattern = "planet_departure",
			origin = origin,
			destination = destination,
			routeStatus = "launching from " .. port.name .. " orbital control",
			routeKind = "planetary departure",
		})
		if not IsValid(ship) then return 0 end
		ship:SetPos(port.point)
		G.BindShipToSWUUniverse(ship)
		if not setTransitRoute(ship, exit,
			math.max(8, tonumber(gd.PlanetTrafficDepartureSpeed) or 38), "planet_departure", false) then
			ship:Remove()
			return 0
		end
		ship.mb_galaxyPlanetTraffic = true
		ship.mb_galaxyPlanetPhase = "departure"
		ship.mb_galaxyPlanetName = port.name
		ship.mb_galaxyRouteStatus = "departing " .. port.name .. " for " .. destination
		ship.mb_galaxyRouteKind = "planetary departure"
		if G.SetShipFlightRoute then
			local waypoints = {}
			local orbit = planetOrbitWaypoint(port)
			if isvector(orbit) then waypoints[#waypoints + 1] = orbit end
			waypoints[#waypoints + 1] = exit
			G.SetShipFlightRoute(ship, waypoints, {
				speed = math.max(8, tonumber(gd.PlanetTrafficDepartureSpeed) or 38),
				arrivalRadius = 110,
			})
			G.UpdateShipFlightRoute(ship)
		end
		G.PlanetTrafficShips[#G.PlanetTrafficShips + 1] = ship
		return 1
	end

	local sideYaw = math.Rand(0, 360)
	local ship = G.SpawnShip(role, {
		sideYaw = sideYaw,
		lane = math.Rand(-180, 180),
		height = math.Rand(-140, 140),
		hold = true,
		faction = faction,
		trueFaction = faction,
		invulnerable = true,
		trafficPattern = "planet_arrival",
		origin = origin,
		destination = destination,
		routeStatus = "cleared for descent to " .. port.name,
		routeKind = "planetary arrival",
	})
	if not IsValid(ship) then return 0 end
	if setPlanetApproachRoute(ship, port) then return 1 end
	ship:Remove()
	return 0
end

function G.UpdatePlanetTraffic(now)
	for index = #G.PlanetTrafficShips, 1, -1 do
		local ship = G.PlanetTrafficShips[index]
		if not IsValid(ship) or not ship.mb_galaxyPlanetTraffic then
			table.remove(G.PlanetTrafficShips, index)
		elseif ship.mb_galaxyPlanetPhase == "arrival" then
			local target = ship.mb_galaxyPlanetPoint
			local arrived = isvector(target) and ship:GetPos():DistToSqr(target)
				<= math.max(60, tonumber(gd.PlanetTrafficArrivalRadius) or 170) ^ 2
			if arrived and not ship.mb_galaxyPlanetLandedAt then
				ship.mb_galaxyPlanetLandedAt = now
				ship:SetFlightVelocity(vector_origin)
				ship:SetShipState("descending to " .. (ship.mb_galaxyPlanetName or "planetary surface"))
				ship.mb_galaxyRouteStatus = "cleared for final descent to "
					.. (ship.mb_galaxyPlanetName or "the planetary surface")
			elseif ship.mb_galaxyPlanetLandedAt
			and now >= ship.mb_galaxyPlanetLandedAt
				+ math.max(1, tonumber(gd.PlanetTrafficLandingHold) or 4) then
				ship:Remove()
			end
		end
	end
end

function setTransitRoute(ship, exit, speed, pattern, distant)
	if not IsValid(ship) or not isvector(exit) then return false end
	local travel = exit - ship:GetPos()
	if travel:LengthSqr() < 100 then return false end
	local velocity = travel:GetNormalized() * math.max(8, tonumber(speed) or 30)
	ship:SetFlightVelocity(velocity)
	ship:SetShipState(distant and "distant transit" or "transit")
	ship.mb_galaxyHoldForPlayerDeparture = false
	ship.mb_galaxyPlayerDeparting = true
	ship.mb_galaxyAmbientTraffic = true
	ship.mb_galaxyTrafficPattern = pattern
	ship.mb_galaxyDistantTraffic = distant == true
	ship.mb_galaxyTrafficExit = Vector(exit)
	if not ship.mb_galaxyPlanetTraffic then
		ship.mb_galaxyRouteStatus = "transiting from "
			.. G.CleanText(ship.mb_galaxyOrigin, 96) .. " to "
			.. G.CleanText(ship.mb_galaxyDestination, 128)
		ship.mb_galaxyRouteKind = "local hyperspace transit"
	end
	ship.mb_galaxyLastFlightVelocity = nil
	if G.HasSWUUniverseFrame() then
		G.UpdateShipTravelFacing(ship, velocity,
			SWU.Controller:GetInternalShipAngles(), 0, false)
	else
		G.UpdateShipTravelFacing(ship, velocity, angle_zero, 0, true)
	end
	ship:SetDieAt(ship.mb_galaxyPersistentTraffic and 0
		or CurTime() + math.max(45, travel:Length() / velocity:Length() + 24))
	if gd.HyperspaceTransitEffectsEnabled ~= false and G.EmitHyperspaceBurst
	and not ship.mb_galaxyHyperspaceArrivalShown then
		local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
		local color = faction == "republic" and Color(70, 145, 255)
			or faction == "cis" and Color(235, 65, 55)
			or faction == "pirate" and Color(235, 170, 55) or Color(175, 220, 255)
		ship.mb_galaxyHyperspaceArrivalShown = true
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), velocity, color, true)
	end
	if G.SetShipFlightRoute then
		G.SetShipFlightRoute(ship, routeCurveWaypoint(ship, exit), {
			speed = velocity:Length(),
			arrivalRadius = 110,
		})
		G.UpdateShipFlightRoute(ship)
	end
	if not ship.mb_galaxyRegisteredAmbientTraffic then
		ship.mb_galaxyRegisteredAmbientTraffic = true
		G.AmbientTrafficShips[#G.AmbientTrafficShips + 1] = ship
	end
	return true
end

--[[
	Galaxy-wide traffic simulation

	The skybox entities are only visual representations of these records.  A
	record itself never depends on a player being nearby: it has a current
	system, destination and Unix-time departure/arrival schedule.  This lets a
	ship remain at Coruscant while the Republic ship briefly visits Kamino, then
	move on naturally if the crew returns much later.
]]
local function universeTrafficEnabled()
	return gd.PersistentUniverseTrafficEnabled ~= false
		and gd.GalaxyTrafficSimulationEnabled ~= false
		and gd.AmbientTrafficEnabled ~= false
end

local universeTrafficPlanetCache = {}
local universeTrafficPlanetCacheExpires = 0
local function universeTrafficPlanets()
	local now = CurTime()
	if now < universeTrafficPlanetCacheExpires
	and #universeTrafficPlanetCache > 0 then
		return universeTrafficPlanetCache
	end
	if table.Count(G.UniversePositions or {}) == 0 and G.RefreshUniverse then G.RefreshUniverse() end
	local planets = {}
	for key, position in pairs(G.UniversePositions or {}) do
		local planet = G.Planets and G.Planets[key] or nil
		if not planet and G.EnsurePlanet then planet = G.EnsurePlanet(key) end
		if isvector(position) and planet and planet.name then
			planets[#planets + 1] = { key = key, name = planet.name, position = position }
		end
	end
	table.sort(planets, function(a, b) return a.key < b.key end)
	universeTrafficPlanetCache = planets
	universeTrafficPlanetCacheExpires = now
		+ math.max(5, tonumber(gd.GalaxyTrafficPlanetCacheSeconds) or 30)
	return planets
end

local function universeTrafficName(role)
	local names = {
		republic = { "Republic Patrol", "Republic Supply Flight", "Republic Scout" },
		cis_scout = { "Separatist Patrol", "CIS Recon Flight", "Separatist Courier" },
		civilian = { "Civilian Freighter", "Sector Merchant", "Independent Transport" },
		pirate = { "Unidentified Raider", "Freebooter", "Outer Rim Corsair" },
	}
	local pool = names[role] or names.civilian
	return pool[math.random(#pool)] .. " " .. math.random(100, 999)
end

local function universeTrafficFactionForRole(role)
	return role == "cis_scout" and "cis" or role
end

function G.NormalizeUniverseTrafficIdentity(record)
	if not istable(record) then return false end
	local changed = false
	local faction = string.lower(G.CleanText(record.faction, 24))
	local expectedRole = faction == "cis" and "cis_scout" or faction
	if expectedRole == "republic" or expectedRole == "cis_scout"
	or expectedRole == "civilian" or expectedRole == "pirate" then
		if record.role ~= expectedRole then
			record.role = expectedRole
			changed = true
		end
	end
	if G.ShipNameContradictsFaction(record.name, faction) then
		record.name = universeTrafficName(record.role)
		changed = true
	end
	return changed
end

local function chooseUniverseTrafficRole(planetKey)
	local planet = G.Planets and G.Planets[planetKey] or nil
	local allegiance = planet and planet.allegiance or "neutral"
	local roll = math.Rand(0, 1)
	if allegiance == "republic" then
		if roll < 0.46 then return "republic" end
		if roll < 0.82 then return "civilian" end
		if roll < 0.92 then return "pirate" end
		return "cis_scout"
	elseif allegiance == "cis" then
		if roll < 0.5 then return "cis_scout" end
		if roll < 0.72 then return "civilian" end
		if roll < 0.9 then return "pirate" end
		return "republic"
	end
	if roll < 0.48 then return "civilian" end
	if roll < 0.72 then return "pirate" end
	if roll < 0.87 then return "republic" end
	return "cis_scout"
end

local function universeTrafficDestination(originKey, planets)
	local choices = {}
	for _, planet in ipairs(planets or universeTrafficPlanets()) do
		if planet.key ~= originKey then choices[#choices + 1] = planet end
	end
	if #choices == 0 then return nil end
	return choices[math.random(#choices)]
end

-- Persistent economic and strategic context for the traffic records.  These
-- are intentionally lightweight data simulations: they continue when nobody
-- is present, then feed visible ships, scanner reports and route decisions.
local galaxyCommodities = {
	food = { manifest = "food and relief packages", value = 2 },
	medical = { manifest = "medical supplies", value = 5 },
	fuel = { manifest = "refined fuel cells", value = 4 },
	parts = { manifest = "replacement starship parts", value = 4 },
	industrial = { manifest = "industrial components", value = 3 },
	munitions = { manifest = "sealed Republic munitions", value = 6 },
	scrap = { manifest = "recovered hull plating and components", value = 2 },
	passengers = { manifest = "passenger berths", value = 1 },
}

local function galaxyPlanetName(key)
	local planet = key and G.Planets and G.Planets[key] or nil
	return planet and planet.name or "an unresolved system"
end

local function galaxyLaneKey(originKey, destinationKey)
	return G.CleanText(originKey, 96) .. "|" .. G.CleanText(destinationKey, 96)
end

local function markLivingGalaxyDirty()
	G.GalaxySimulationDirty = true
end

function G.AddGalaxyReport(kind, title, details, systemKey, now)
	now = math.floor(tonumber(now) or unix())
	local item = {
		id = string.format("report_%d_%06d", now, math.random(1, 999999)),
		time = now,
		kind = G.CleanText(kind, 32),
		title = G.CleanText(title, 128),
		details = G.CleanText(details, 360),
		systemKey = G.CleanText(systemKey, 96),
	}
	table.insert(G.GalaxyNews, 1, item)
	while #G.GalaxyNews > math.max(8, tonumber(gd.GalaxyNewsMaximum) or 36) do
		table.remove(G.GalaxyNews)
	end
	markLivingGalaxyDirty()
	return item
end

function G.RecentGalaxyReports(limit)
	limit = math.max(1, math.floor(tonumber(limit)
		or tonumber(gd.GalaxyNewsVisibleMaximum) or 5))
	local reports = {}
	for _, item in ipairs(G.GalaxyNews or {}) do
		if (tonumber(item.time) or 0) >= unix() - 86400 then
			reports[#reports + 1] = {
				time = tonumber(item.time) or 0,
				kind = G.CleanText(item.kind, 32),
				title = G.CleanText(item.title, 128),
				details = G.CleanText(item.details, 360),
				system = galaxyPlanetName(item.systemKey),
			}
			if #reports >= limit then break end
		end
	end
	return reports
end

function G.GalaxyEconomyFor(planetKey)
	if not planetKey or planetKey == "" then return nil end
	local economy = G.GalaxyEconomy[planetKey]
	if not istable(economy) then
		economy = { stock = {}, activity = "normal traffic" }
		G.GalaxyEconomy[planetKey] = economy
	end
	economy.stock = economy.stock or {}
	for commodity in pairs(galaxyCommodities) do
		if economy.stock[commodity] == nil then economy.stock[commodity] = math.random(38, 68) end
	end
	return economy
end

function G.GetGalaxyLane(originKey, destinationKey)
	local key = galaxyLaneKey(originKey, destinationKey)
	local lane = G.GalaxyLanes[key]
	if lane and (tonumber(lane.expiresAt) or 0) <= unix() then
		G.GalaxyLanes[key] = nil
		lane = nil
		markLivingGalaxyDirty()
	end
	return lane or {
		key = key,
		originKey = originKey,
		destinationKey = destinationKey,
		condition = "clear",
		severity = 0,
	}
end

local function chooseCommodity()
	local choices = {}
	for key in pairs(galaxyCommodities) do choices[#choices + 1] = key end
	return choices[math.random(#choices)]
end

function G.AssignUniverseTrafficLife(record, originKey, planets)
	if not istable(record) then return end
	G.NormalizeUniverseTrafficIdentity(record)
	local faction = record.faction or universeTrafficFactionForRole(record.role)
	record.homeKey = isstring(record.homeKey) and record.homeKey ~= ""
		and record.homeKey or originKey
	if faction == "civilian" then
		if not isstring(record.assignment) or record.assignment == "" then
			record.assignment = math.random(4) == 1 and "courier" or "trade"
		end
		if not isstring(record.cargoKey) or record.cargoKey == "" then record.cargoKey = chooseCommodity() end
		local cargo = galaxyCommodities[record.cargoKey] or galaxyCommodities.industrial
		if not isstring(record.cargo) or record.cargo == "" then record.cargo = cargo.manifest end
		record.cargoValue = math.max(1, tonumber(record.cargoValue) or cargo.value)
	elseif faction == "republic" or faction == "cis" then
	if not isstring(record.assignment) or record.assignment == "" then record.assignment = "patrol" end
		record.fleetID = isstring(record.fleetID) and record.fleetID ~= "" and record.fleetID
			or (faction .. "-task-force-" .. G.CleanText(record.homeKey, 48))
		if not isstring(record.cargoKey) or record.cargoKey == "" then record.cargoKey = "munitions" end
		if not isstring(record.cargo) or record.cargo == "" then
			record.cargo = faction == "republic" and "Republic fleet supplies"
				or "Separatist military stores"
		end
		record.cargoValue = math.max(1, tonumber(record.cargoValue) or 6)
	elseif faction == "pirate" then
		if not isstring(record.assignment) or record.assignment == "" then record.assignment = "raider" end
		if not isstring(record.cargoKey) or record.cargoKey == "" then record.cargoKey = "parts" end
		if not isstring(record.cargo) or record.cargo == "" then record.cargo = "unregistered salvage and contraband" end
		record.cargoValue = math.max(1, tonumber(record.cargoValue) or 5)
	else
		if not isstring(record.assignment) or record.assignment == "" then record.assignment = "transit" end
		if not isstring(record.cargoKey) or record.cargoKey == "" then record.cargoKey = chooseCommodity() end
		if not isstring(record.cargo) or record.cargo == "" then
			record.cargo = galaxyCommodities[record.cargoKey].manifest
		end
		record.cargoValue = math.max(1, tonumber(record.cargoValue) or 2)
	end
	if not G.UniversePositions[record.routeAnchorKey] then
		local destination = universeTrafficDestination(record.homeKey, planets)
		record.routeAnchorKey = destination and destination.key or record.homeKey
	end
end

function G.ChooseUniverseTrafficDestination(record, originKey, planets)
	if not istable(record) then return universeTrafficDestination(originKey, planets) end
	G.AssignUniverseTrafficLife(record, originKey, planets)
	if record.assignment == "trade" or record.assignment == "courier" then
		if originKey ~= record.homeKey and G.UniversePositions[record.homeKey] then
			return { key = record.homeKey }
		end
		-- Trade traffic favours a world with a lower stock of its cargo, making
		-- the same merchant routes visibly respond to shortages over time.
		local candidates, lowest = {}, math.huge
		for _, planet in ipairs(planets or {}) do
			if planet.key ~= originKey then
				local economy = G.GalaxyEconomyFor(planet.key)
				local stock = economy and tonumber(economy.stock[record.cargoKey]) or 50
				if stock < lowest then candidates, lowest = { planet }, stock
				elseif stock == lowest then candidates[#candidates + 1] = planet end
			end
		end
		return #candidates > 0 and candidates[math.random(#candidates)]
			or universeTrafficDestination(originKey, planets)
	elseif record.assignment == "patrol" or record.assignment == "raider" then
		if originKey ~= record.homeKey and G.UniversePositions[record.homeKey] then
			return { key = record.homeKey }
		end
		return G.UniversePositions[record.routeAnchorKey] and { key = record.routeAnchorKey }
			or universeTrafficDestination(originKey, planets)
	end
	return universeTrafficDestination(originKey, planets)
end

function G.RecordUniverseTrafficArrival(record, destinationKey, now)
	if not istable(record) or not destinationKey or destinationKey == "" then return end
	local economy = G.GalaxyEconomyFor(destinationKey)
	if not economy then return end
	local cargoKey = record.cargoKey
	if galaxyCommodities[cargoKey] then
		local maximum = math.max(20, tonumber(gd.GalaxyEconomyMaximumStock) or 100)
		economy.stock[cargoKey] = math.min(maximum,
			(tonumber(economy.stock[cargoKey]) or 50) + math.max(2, tonumber(record.cargoValue) or 2))
		economy.activity = "receiving " .. (record.cargo or galaxyCommodities[cargoKey].manifest)
	end
	if record.id and G.TrackedUniverseTraffic[record.id] then
		G.AddGalaxyReport("tracking", "Tracked contact arrived at " .. galaxyPlanetName(destinationKey),
			record.name .. " completed its " .. (record.assignment or "scheduled")
				.. " route carrying " .. (record.cargo or "registered cargo") .. ".",
			destinationKey, now)
		if (record.faction == "cis" or record.faction == "pirate") and math.random(4) == 1 then
			G.AddGalaxyReport("tracking", "Tracker intelligence intercept",
				record.name .. " exchanged a short encrypted rendezvous burst near "
					.. galaxyPlanetName(destinationKey) .. ". Follow its next leg for more intelligence.",
				destinationKey, now)
		end
	end
	local lane = G.GetGalaxyLane(record.originKey, destinationKey)
	if lane.condition == "pirate_activity" or lane.condition == "cis_interdiction" then
		local chance = math.Clamp((tonumber(gd.GalaxyDistressChance) or 0.14)
			+ (tonumber(record.cargoValue) or 1) * 0.015, 0, 0.42)
		if math.Rand(0, 1) <= chance then
			local id = string.format("distress_%d_%06d", now or unix(), math.random(1, 999999))
			G.GalaxyDistress[id] = {
				id = id,
				systemKey = destinationKey,
				laneKey = lane.key,
				cargoKey = cargoKey,
				sourceName = record.name,
				createdAt = now or unix(),
				expiresAt = (now or unix()) + math.max(120, tonumber(gd.GalaxyDistressLifetime) or 720),
			}
			G.AddGalaxyReport("distress", "Distress traffic on " .. galaxyPlanetName(destinationKey),
				record.name .. " reported trouble after crossing a "
					.. string.gsub(lane.condition, "_", " ") .. " lane.", destinationKey, now)
		end
	end
	markLivingGalaxyDirty()
end

function G.UpdateLivingGalaxySimulation(now, force)
	if not G._livingGalaxyLoaded or gd.LivingGalaxySimulationEnabled == false then return end
	now = math.floor(tonumber(now) or unix())
	if not force and now < (G.NextLivingGalaxySimulationAt or 0) then return end
	G.NextLivingGalaxySimulationAt = now
		+ math.max(10, tonumber(gd.LivingGalaxySimulationInterval) or 30)
	local planets = universeTrafficPlanets()
	if #planets < 2 then return end
	local changed = false

	for key, lane in pairs(G.GalaxyLanes or {}) do
		if not istable(lane) or (tonumber(lane.expiresAt) or 0) <= now then
			if istable(lane) and lane.condition and lane.condition ~= "clear" then
				G.AddGalaxyReport("lane", "Hyperlane reopened",
					"Traffic control reports the route from " .. galaxyPlanetName(lane.originKey)
						.. " to " .. galaxyPlanetName(lane.destinationKey) .. " is clear again.",
					lane.destinationKey, now)
			end
			G.GalaxyLanes[key] = nil
			changed = true
		end
	end

	for id, battle in pairs(G.GalaxyBattles or {}) do
		if not istable(battle) or (tonumber(battle.endsAt) or 0) <= now then
			if istable(battle) then
				local republicWins = battle.defender == "republic" and math.random(100) <= 58
					or battle.defender ~= "republic" and math.random(100) > 58
				local winner = republicWins and "Republic-aligned forces" or "hostile forces"
				G.AddGalaxyReport("battle", "Battle resolved at " .. galaxyPlanetName(battle.systemKey),
					winner .. " withdrew from the engagement after a prolonged sector battle.",
					battle.systemKey, now)
			end
			G.GalaxyBattles[id] = nil
			changed = true
		end
	end

	for id, distress in pairs(G.GalaxyDistress or {}) do
		if not istable(distress) or (tonumber(distress.expiresAt) or 0) <= now then
			if istable(distress) then
				local economy = G.GalaxyEconomyFor(distress.systemKey)
				if economy and galaxyCommodities[distress.cargoKey] then
					economy.stock[distress.cargoKey] = math.max(0,
						(tonumber(economy.stock[distress.cargoKey]) or 50) - 9)
					economy.activity = "awaiting replacement "
						.. galaxyCommodities[distress.cargoKey].manifest
				end
				G.AddGalaxyReport("distress", "Unanswered distress signal at "
					.. galaxyPlanetName(distress.systemKey),
					(distress.sourceName or "A civilian vessel")
						.. " was lost or forced to abandon its cargo. Local traffic is rerouting.",
					distress.systemKey, now)
			end
			G.GalaxyDistress[id] = nil
			changed = true
		end
	end

	local laneMinimum = math.max(120, tonumber(gd.GalaxyLaneMinimumLifetime) or 600)
	local laneMaximum = math.max(laneMinimum, tonumber(gd.GalaxyLaneMaximumLifetime) or 1800)
	if math.Rand(0, 1) <= math.Clamp(tonumber(gd.GalaxyLaneEventChance) or 0.24, 0, 1) then
		local origin = planets[math.random(#planets)]
		local destination = universeTrafficDestination(origin.key, planets)
		if destination then
			local conditions = { "pirate_activity", "cis_interdiction", "congestion", "ion_storm" }
			local condition = conditions[math.random(#conditions)]
			local key = galaxyLaneKey(origin.key, destination.key)
			if not G.GalaxyLanes[key] then
				G.GalaxyLanes[key] = {
					key = key,
					originKey = origin.key,
					destinationKey = destination.key,
					condition = condition,
					severity = math.random(1, 3),
					createdAt = now,
					expiresAt = now + math.Rand(laneMinimum, laneMaximum),
				}
				G.AddGalaxyReport("lane", "Hyperlane advisory: "
					.. string.upper(string.gsub(condition, "_", " ")),
					"Traffic between " .. origin.name .. " and " .. destination.name
						.. " is reporting " .. string.gsub(condition, "_", " ") .. ".",
					destination.key, now)
				changed = true
			end
		end
	end

	local battleLimit = math.max(1, math.floor(tonumber(gd.GalaxyMaximumVirtualBattles) or 4))
	if table.Count(G.GalaxyBattles) < battleLimit
	and math.Rand(0, 1) <= math.Clamp(tonumber(gd.GalaxyBattleCreationChance) or 0.18, 0, 1) then
		local system = planets[math.random(#planets)]
		local defender = math.random(4) == 1 and "civilian" or "republic"
		local attacker = math.random(4) == 1 and "pirate" or "cis"
		local id = string.format("battle_%d_%06d", now, math.random(1, 999999))
		local minimum = math.max(180, tonumber(gd.GalaxyBattleMinimumDuration) or 600)
		local maximum = math.max(minimum, tonumber(gd.GalaxyBattleMaximumDuration) or 1800)
		G.GalaxyBattles[id] = {
			id = id, systemKey = system.key, defender = defender, attacker = attacker,
			startedAt = now, endsAt = now + math.Rand(minimum, maximum),
		}
		G.AddGalaxyReport("battle", "Fleet contact at " .. system.name,
			string.upper(attacker) .. " and " .. string.upper(defender)
				.. " task forces are engaged near the system.", system.key, now)
		changed = true
	end

	for _, planet in ipairs(planets) do
		local economy = G.GalaxyEconomyFor(planet.key)
		local lowestKey, lowestStock
		for commodity, stock in pairs(economy.stock or {}) do
			if not lowestStock or stock < lowestStock then lowestKey, lowestStock = commodity, stock end
		end
		if lowestKey and lowestStock <= 20 then
			economy.activity = "shortage of " .. galaxyCommodities[lowestKey].manifest
		elseif G.Planets[planet.key] and G.Planets[planet.key].allegiance == "republic" then
			economy.activity = "Republic patrols and scheduled trade traffic"
		elseif G.Planets[planet.key] and G.Planets[planet.key].allegiance == "cis" then
			economy.activity = "Separatist patrols and military logistics"
		else
			economy.activity = "independent traders and frontier traffic"
		end
	end
	-- A virtual battle becomes a normal, joinable background battle only when
	-- the Republic ship enters that system. It is therefore an existing battle
	-- being observed, rather than a fight created around the player.
	local currentKey = G.PlanetKey((G.State and G.State.currentPlanet) or "")
	if G.Runtime.enabled and not G.Active and not G.Operation
	and currentKey ~= "" and G.SpawnBackgroundBattle and G.HasActiveBackgroundBattle
	and not G.HasActiveBackgroundBattle() then
		for _, battle in pairs(G.GalaxyBattles or {}) do
			if battle.systemKey == currentKey
			and now >= (tonumber(battle.nextMaterializeAt) or 0) then
				battle.nextMaterializeAt = now + 300
				if G.SpawnBackgroundBattle(battle) > 0 then
					G.AddGalaxyReport("battle", "Battle sighted at " .. galaxyPlanetName(currentKey),
						"The Republic ship entered an ongoing sector engagement. Tactical Scanner can identify and join it.",
						currentKey, now)
					changed = true
				end
				break
			end
		end
	end
	if changed then markLivingGalaxyDirty() end
	if G.GalaxySimulationDirty and now >= (G.NextLivingGalaxySaveAt or 0) then
		G.SaveLivingGalaxySimulation()
	end
end

local function universeTrafficHoldingTime()
	local minimum = math.max(15, tonumber(gd.GalaxyTrafficHoldingMinimum) or 50)
	local maximum = math.max(minimum, tonumber(gd.GalaxyTrafficHoldingMaximum) or 420)
	return math.Rand(minimum, maximum)
end

local function universeTrafficTravelTime(originKey, destinationKey)
	local origin = G.UniversePositions and G.UniversePositions[originKey] or nil
	local destination = G.UniversePositions and G.UniversePositions[destinationKey] or nil
	local minimum = math.max(20, tonumber(gd.GalaxyTrafficTravelMinimum) or 90)
	local maximum = math.max(minimum, tonumber(gd.GalaxyTrafficTravelMaximum) or 1800)
	local perUnit = math.max(0.0001, tonumber(gd.GalaxyTrafficTravelSecondsPerUnit) or 0.06)
	if isvector(origin) and isvector(destination) then
		return math.Clamp(origin:Distance(destination) * perUnit, minimum, maximum)
	end
	return math.Rand(minimum, maximum)
end

local function markUniverseTrafficDirty()
	G.UniverseTrafficDirty = true
end

function G.CreateUniverseTrafficRecord(originKey, forcedRole, now, stationed)
	now = math.floor(tonumber(now) or unix())
	local planets = universeTrafficPlanets()
	if #planets < 2 then return nil end
	local origin
	for _, candidate in ipairs(planets) do
		if candidate.key == originKey then origin = candidate break end
	end
	origin = origin or planets[math.random(#planets)]
	local role = forcedRole or chooseUniverseTrafficRole(origin.key)
	if role ~= "republic" and role ~= "cis_scout" and role ~= "civilian" and role ~= "pirate" then
		role = "civilian"
	end
	local id = string.format("traffic_%d_%06d", now, math.random(1, 999999))
	while G.UniverseTraffic[id] do id = string.format("traffic_%d_%06d", now, math.random(1, 999999)) end
	local nextDestination = universeTrafficDestination(origin.key, planets)
	local record = {
		id = id,
		name = universeTrafficName(role),
		role = role,
		faction = universeTrafficFactionForRole(role),
		state = "holding",
		locationKey = origin.key,
		originKey = origin.key,
		destinationKey = "",
		nextDestinationKey = nextDestination and nextDestination.key or "",
		bornAt = now,
		departAt = now + universeTrafficHoldingTime(),
		departedAt = 0,
		arrivalAt = 0,
		stationed = stationed == true,
	}
	G.UniverseTraffic[id] = record
	G.AssignUniverseTrafficLife(record, origin.key, planets)
	if record.stationed then
		record.assignment = "orbital_service"
		record.nextDestinationKey = ""
		record.departAt = 0
	else
		local scheduledDestination = G.ChooseUniverseTrafficDestination(record, origin.key, planets)
		record.nextDestinationKey = scheduledDestination and scheduledDestination.key
			or record.nextDestinationKey
	end
	markUniverseTrafficDirty()
	return record
end

function G.AdvanceUniverseTrafficRecord(record, now)
	if not istable(record) then return false end
	now = math.floor(tonumber(now) or unix())
	local neededLifeAssignment = not isstring(record.assignment) or record.assignment == ""
		or not isstring(record.cargoKey) or record.cargoKey == ""
		or not isstring(record.cargo) or record.cargo == ""
		or not isstring(record.homeKey) or record.homeKey == ""
		or not G.UniversePositions[record.routeAnchorKey]

	-- Most of the galaxy is between scheduled events. Avoid rebuilding or
	-- repairing an already valid vessel record until it is actually due to
	-- depart, arrive, or needs legacy data repaired.
	if not neededLifeAssignment then
		if record.stationed
		and record.state == "holding"
		and G.UniversePositions[record.locationKey]
		and record.destinationKey == ""
		and record.nextDestinationKey == ""
		and (tonumber(record.departAt) or 0) == 0 then
			return false
		end
		if record.state == "holding"
		and G.UniversePositions[record.locationKey]
		and G.UniversePositions[record.nextDestinationKey]
		and now < (tonumber(record.departAt) or 0) then
			return false
		end
		if record.state == "transit"
		and G.UniversePositions[record.originKey]
		and G.UniversePositions[record.destinationKey]
		and now < (tonumber(record.arrivalAt) or 0) then
			return false
		end
	end

	local planets = universeTrafficPlanets()
	if #planets < 2 then return false end
	G.AssignUniverseTrafficLife(record, record.locationKey or record.originKey or planets[1].key, planets)
	local changed = neededLifeAssignment
	if record.stationed then
		if not G.UniversePositions[record.locationKey] then
			record.locationKey = planets[math.random(#planets)].key
			record.originKey = record.locationKey
			changed = true
		end
		if record.state ~= "holding" or record.destinationKey ~= ""
		or record.nextDestinationKey ~= "" or (tonumber(record.departAt) or 0) ~= 0 then
			record.state = "holding"
			record.originKey = record.locationKey
			record.destinationKey = ""
			record.nextDestinationKey = ""
			record.departAt = 0
			record.departedAt = 0
			record.arrivalAt = 0
			changed = true
		end
		return changed
	end
	local loops = 0
	-- A restart can leave the server offline for many hours.  Advance the full
	-- schedule in one pass so returning after a day never revives yesterday's
	-- traffic merely because no player was nearby to tick it.
	while loops < 2048 do
		loops = loops + 1
		if record.state == "holding" then
			if not G.UniversePositions[record.locationKey] then
				record.locationKey = planets[math.random(#planets)].key
				record.originKey = record.locationKey
				local nextDestination = G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
				record.nextDestinationKey = nextDestination and nextDestination.key or ""
				record.departAt = now + universeTrafficHoldingTime()
				changed = true
			end
			if not G.UniversePositions[record.nextDestinationKey] then
				local nextDestination = G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
				record.nextDestinationKey = nextDestination and nextDestination.key or ""
				changed = true
			end
			if now < (tonumber(record.departAt) or 0) then break end
			local destination = record.nextDestinationKey and G.UniversePositions[record.nextDestinationKey]
				and { key = record.nextDestinationKey }
				or G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
			if not destination then break end
			record.originKey = record.locationKey
			record.destinationKey = destination.key
			record.nextDestinationKey = ""
			local lane = G.GetGalaxyLane(record.originKey, record.destinationKey)
			if record.faction == "civilian"
			and (lane.condition == "pirate_activity" or lane.condition == "cis_interdiction")
			and math.Rand(0, 1) <= 0.65 then
				for _ = 1, 5 do
					local reroute = universeTrafficDestination(record.originKey, planets)
					local alternative = reroute and G.GetGalaxyLane(record.originKey, reroute.key) or nil
					if reroute and alternative and alternative.condition == "clear" then
						record.destinationKey = reroute.key
						lane = alternative
						if record.id and G.TrackedUniverseTraffic[record.id] then
							G.AddGalaxyReport("tracking", "Tracked merchant rerouted",
								record.name .. " avoided a threatened lane and is now bound for "
									.. galaxyPlanetName(reroute.key) .. ".", reroute.key, now)
						end
						break
					end
				end
			end
			record.departedAt = math.floor(tonumber(record.departAt) or now)
			local travelTime = universeTrafficTravelTime(record.originKey, record.destinationKey)
			if lane.condition == "congestion" then travelTime = travelTime * 1.35
			elseif lane.condition == "ion_storm" then travelTime = travelTime * 1.6
			elseif lane.condition == "pirate_activity" or lane.condition == "cis_interdiction" then
				travelTime = travelTime * 1.15
			end
			record.arrivalAt = math.floor(record.departedAt + travelTime)
			record.state = "transit"
			changed = true
		elseif record.state == "transit" then
			if not G.UniversePositions[record.originKey]
			or not G.UniversePositions[record.destinationKey] then
				record.state = "holding"
				record.locationKey = planets[math.random(#planets)].key
				record.originKey = record.locationKey
				record.destinationKey = ""
				local nextDestination = G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
				record.nextDestinationKey = nextDestination and nextDestination.key or ""
				record.departAt = now + universeTrafficHoldingTime()
				changed = true
			elseif now < (tonumber(record.arrivalAt) or 0) then
				break
			else
				G.RecordUniverseTrafficArrival(record, record.destinationKey, now)
				record.state = "holding"
				record.locationKey = record.destinationKey
				record.originKey = record.destinationKey
				record.destinationKey = ""
				local nextDestination = G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
				record.nextDestinationKey = nextDestination and nextDestination.key or ""
				record.departAt = math.floor((tonumber(record.arrivalAt) or now)
					+ universeTrafficHoldingTime())
				record.departedAt = 0
				record.arrivalAt = 0
				changed = true
			end
		else
			record.state = "holding"
			record.locationKey = planets[math.random(#planets)].key
			record.originKey = record.locationKey
			record.destinationKey = ""
			local nextDestination = G.ChooseUniverseTrafficDestination(record, record.locationKey, planets)
			record.nextDestinationKey = nextDestination and nextDestination.key or ""
			record.departAt = now + universeTrafficHoldingTime()
			changed = true
		end
	end
	return changed
end

-- A Republic navigation order changes the real galaxy record as well as the
-- skybox actor. This prevents a directed vessel from disappearing locally and
-- immediately being recreated in the same place by the persistent simulation.
function G.ReleaseUniverseTrafficRecord(record, now)
	if not istable(record) then return false end
	now = math.floor(tonumber(now) or unix())
	local planets = universeTrafficPlanets()
	if #planets < 2 then return false end
	local originKey = record.locationKey or record.originKey
	if not G.UniversePositions[originKey] then return false end
	if record.stationed then
		record.stationed = false
		record.assignment = "transit"
		record.nextDestinationKey = ""
	end
	G.AssignUniverseTrafficLife(record, originKey, planets)
	local destination = G.ChooseUniverseTrafficDestination(record, originKey, planets)
	if not destination or not G.UniversePositions[destination.key] then return false end
	record.state = "transit"
	record.locationKey = originKey
	record.originKey = originKey
	record.destinationKey = destination.key
	record.nextDestinationKey = ""
	record.departAt = 0
	record.departedAt = now
	record.arrivalAt = now + math.floor(universeTrafficTravelTime(originKey, destination.key))
	markUniverseTrafficDirty()
	return true
end

function G.UniverseTrafficPosition(record, at)
	if not istable(record) then return nil end
	if record.state == "holding" then
		return G.UniversePositions and G.UniversePositions[record.locationKey] or nil
	end
	local origin = G.UniversePositions and G.UniversePositions[record.originKey] or nil
	local destination = G.UniversePositions and G.UniversePositions[record.destinationKey] or nil
	if not isvector(origin) or not isvector(destination) then return nil end
	local duration = math.max(1, (tonumber(record.arrivalAt) or 0)
		- (tonumber(record.departedAt) or 0))
	local fraction = math.Clamp(((tonumber(at) or unix()) - (tonumber(record.departedAt) or 0))
		/ duration, 0, 1)
	return origin + (destination - origin) * fraction
end

function G.EnsureUniverseTrafficPopulation(now, forcedRole)
	if not G._universeTrafficLoaded or not universeTrafficEnabled() then return 0 end
	local planets = universeTrafficPlanets()
	if #planets < 2 then return 0 end
	local maximum = math.max(1, math.floor(tonumber(gd.GalaxyTrafficMaximumRecords) or 120))
	local minimumPresence = math.max(0, math.floor(tonumber(gd.GalaxyTrafficMinimumSystemPresence) or 3))
	local target = math.min(maximum, #planets * (math.max(1,
		math.floor(tonumber(gd.GalaxyTrafficShipsPerPlanet) or 6)) + minimumPresence))
	local count = table.Count(G.UniverseTraffic or {})
	local created = 0
	local stationed = {}
	for _, record in pairs(G.UniverseTraffic or {}) do
		if record.stationed and record.state == "holding" and record.locationKey then
			stationed[record.locationKey] = (stationed[record.locationKey] or 0) + 1
		end
	end
	-- Every system receives a small globally seeded orbital population. These
	-- are not spawned in reaction to a player; they exist in the simulation at
	-- all times, so a newly arrived system already has service traffic in orbit.
	for _, planet in ipairs(planets) do
		while count < maximum and (stationed[planet.key] or 0) < minimumPresence do
			local record = G.CreateUniverseTrafficRecord(planet.key, nil, now, true)
			if not record then break end
			count = count + 1
			created = created + 1
			stationed[planet.key] = (stationed[planet.key] or 0) + 1
		end
	end
	while count < target do
		local planet = planets[(count % #planets) + 1]
		if not G.CreateUniverseTrafficRecord(planet.key, forcedRole, now) then break end
		count = count + 1
		created = created + 1
		-- A force role is only for a deliberate diagnostic command; do not turn
		-- it into an entire galaxy of identical ships.
		forcedRole = nil
	end
	return created
end

local function universeTrafficVisualMode(record, currentKey, now)
	if record.state == "holding" and record.locationKey == currentKey then return "holding" end
	if record.state ~= "transit" then return nil end
	local window = math.max(20, tonumber(gd.GalaxyTrafficVisibilityWindow) or 150)
	if record.originKey == currentKey and now - (tonumber(record.departedAt) or now) <= window then
		return "departure"
	end
	if record.destinationKey == currentKey and (tonumber(record.arrivalAt) or 0) - now <= window then
		return "arrival"
	end
	return nil
end

local function universeTrafficSeed(record)
	local total = 0
	for index = 1, #(record.id or "") do total = total + string.byte(record.id, index) * index end
	return total
end

local function universeTrafficEntry(record, offset)
	local seed = universeTrafficSeed(record) + (offset or 0)
	return select(1, G.FindClearSkyboxEntry(seed % 360,
		((seed * 7) % 320) - 160, ((seed * 13) % 260) - 130, record.role))
end

-- Permanent local services follow a short, safe orbital circuit.  This keeps
-- a planet from looking like it has four ships placed around it as props while
-- still keeping them close enough to read as civilian, patrol or port traffic.
local function universeTrafficServiceOrbit(record, port)
	if not port or not isvector(port.position) or not isvector(port.normal) then return nil end
	local tangent = port.normal:Cross(Vector(0, 0, 1))
	if tangent:LengthSqr() < 0.001 then tangent = port.normal:Cross(Vector(0, 1, 0)) end
	if tangent:LengthSqr() < 0.001 then return nil end
	tangent:Normalize()
	local shipRadius = G.MaximumRoleShipRadius(record.role)
	local radius = math.max(1, tonumber(port.safeRadius) or 1)
		+ math.max(90, shipRadius * 0.22)
	local phase = math.rad(universeTrafficSeed(record) % 360)
	local points = {}
	-- Eight short legs keep each chord outside the planet's clearance radius;
	-- a four-point square can otherwise cut through the collision envelope of a
	-- large SWU planet.
	for index = 0, 7 do
		local angle = phase + math.rad(index * 45)
		local direction = port.normal * math.cos(angle) + tangent * math.sin(angle)
		local point = port.position + direction * radius
		if G.PlanetClearanceAt(point, shipRadius) and G.IsInsideSkybox(point) then
			points[#points + 1] = point
		end
	end
	return #points == 8 and points or nil
end

local function setUniverseTrafficHolding(ship, record, port)
	if not IsValid(ship) then return false end
	local keepLocalPatrol = ship.mb_galaxyFlightRoute
		and (ship.mb_galaxyAutonomousPatrol or ship.mb_galaxyServiceOrbit)
	if not keepLocalPatrol then
		if G.ClearShipFlightRoute then G.ClearShipFlightRoute(ship) end
		ship:SetFlightVelocity(vector_origin)
	end
	ship:SetShipState("holding in " .. ((G.Planets[record.locationKey]
		and G.Planets[record.locationKey].name) or "local space"))
	local nextPlanet = G.Planets[record.nextDestinationKey]
	ship.mb_galaxyCargo = record.cargo or ship.mb_galaxyCargo
	ship.mb_galaxyDestination = nextPlanet and nextPlanet.name
		or (record.stationed and "local orbital service" or "pending hyperspace clearance")
	ship.mb_galaxyRouteStatus = record.stationed and "operating scheduled local orbital service"
		or nextPlanet and ("stationed in local orbit; "
		.. (record.assignment or "transit") .. " route next jumps to " .. nextPlanet.name)
		or "stationed in local orbit"
	ship.mb_galaxyRouteKind = "galaxy traffic holding"
	ship.mb_galaxyUniverseTrafficMode = "holding"
	ship:SetDieAt(0)
	if record.stationed and gd.GalaxyTrafficServiceOrbitEnabled ~= false
	and G.SetShipFlightRoute then
		port = port or findPlanetTrafficPort(record.role)
		local points = universeTrafficServiceOrbit(record, port)
		if points and not (ship.mb_galaxyServiceOrbit
		and ship.mb_galaxyFlightRoute) then
			G.SetShipFlightRoute(ship, points, {
				speed = math.max(8, tonumber(gd.GalaxyTrafficServiceOrbitSpeed) or 22),
				arrivalRadius = 95,
				loop = true,
			})
			G.UpdateShipFlightRoute(ship)
			ship.mb_galaxyServiceOrbit = true
		end
	else
		ship.mb_galaxyServiceOrbit = nil
		if G.AssignAutonomousShipMotion then
			G.AssignAutonomousShipMotion(ship, "waiting for scheduled departure")
		end
	end
	return true
end

local function beginUniverseTrafficDeparture(ship, record)
	local exit = universeTrafficEntry(record, 71)
	if not isvector(exit) then return false end
	ship.mb_galaxyUniverseTrafficMode = "departure"
	ship.mb_galaxyOrigin = (G.Planets[record.originKey] and G.Planets[record.originKey].name) or "local orbit"
	ship.mb_galaxyDestination = (G.Planets[record.destinationKey]
		and G.Planets[record.destinationKey].name) or "hyperspace route"
	ship.mb_galaxyRouteStatus = "jumping from " .. ship.mb_galaxyOrigin
		.. " to " .. ship.mb_galaxyDestination
	local lane = G.GetGalaxyLane(record.originKey, record.destinationKey)
	if lane.condition ~= "clear" then
		ship.mb_galaxyRouteStatus = ship.mb_galaxyRouteStatus .. " via "
			.. string.gsub(lane.condition, "_", " ") .. " lane"
	end
	ship.mb_galaxyRouteKind = "galaxy hyperspace departure"
	local showEffect = gd.HyperspaceTransitEffectsEnabled ~= false and G.EmitHyperspaceBurst
	if showEffect then ship.mb_galaxyHyperspaceArrivalShown = true end
	local started = setTransitRoute(ship, exit, math.Rand(34, 52), "galaxy_departure", false)
	if started and showEffect then
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), ship:GetFlightVelocity(), trafficColor(ship), false)
	end
	return started
end

local function beginUniverseTrafficArrival(ship, record, port)
	if not IsValid(ship) then return false end
	local target = port and port.point or nil
	if not isvector(target) then
		local center, radius = G.SkyboxFrame()
		local direction = ship:GetPos() - center
		if direction:LengthSqr() < 1 then direction = Vector(1, 0, 0) end
		target = center + direction:GetNormalized() * math.max(320, radius * 0.38)
	end
	local delta = target - ship:GetPos()
	if delta:LengthSqr() < 1 then return setUniverseTrafficHolding(ship, record) end
	local remaining = math.max(12, math.min(45, (tonumber(record.arrivalAt) or unix()) - unix()))
	local speed = math.Clamp(delta:Length() / remaining, 24, 140)
	ship:SetFlightVelocity(delta:GetNormalized() * speed)
	ship:SetShipState("arriving from hyperspace")
	ship.mb_galaxyRouteStatus = "arriving from "
		.. ((G.Planets[record.originKey] and G.Planets[record.originKey].name) or "deep space")
	ship.mb_galaxyRouteKind = "galaxy hyperspace arrival"
	ship.mb_galaxyUniverseTrafficMode = "arrival"
	ship:SetDieAt(0)
	if G.HasSWUUniverseFrame() then
		G.UpdateShipTravelFacing(ship, ship:GetFlightVelocity(),
			SWU.Controller:GetInternalShipAngles(), 0, false)
	end
	if gd.HyperspaceTransitEffectsEnabled ~= false and G.EmitHyperspaceBurst then
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), ship:GetFlightVelocity(), trafficColor(ship), true)
	end
	if G.SetShipFlightRoute then
		G.SetShipFlightRoute(ship, routeCurveWaypoint(ship, target), {
			speed = speed, arrivalRadius = 110, finalStop = true,
		})
		G.UpdateShipFlightRoute(ship)
	end
	return true
end

local function spawnUniverseTrafficVisual(record, mode)
	if not G.HasSWUUniverseFrame() then return nil end
	local entry = universeTrafficEntry(record, mode == "arrival" and 0 or 137)
	if not isvector(entry) then return nil end
	local faction = record.faction or universeTrafficFactionForRole(record.role)
	local ship = G.SpawnShip(record.role, {
		name = record.name,
		model = record.model,
		sizeClass = record.sizeClass,
		sideYaw = universeTrafficSeed(record) % 360,
		hold = true,
		faction = faction,
		trueFaction = faction,
		invulnerable = (MilBase.Config.LivingUniverse or {}).PersistentShipDamageEnabled == false,
		trafficPattern = "galaxy_" .. mode,
		cargo = record.cargo,
		origin = (G.Planets[record.originKey] and G.Planets[record.originKey].name) or "local system",
		destination = (G.Planets[record.destinationKey] and G.Planets[record.destinationKey].name)
			or (G.Planets[record.nextDestinationKey] and G.Planets[record.nextDestinationKey].name)
			or "local orbit",
	})
	if not IsValid(ship) then return nil end
	record.model = ship:GetModel()
	record.sizeClass = ship.GetSizeClass and ship:GetSizeClass() or record.sizeClass
	ship.mb_galaxyUniverseTrafficID = record.id
	ship.mb_galaxyUniverseTrafficMode = mode
	ship.mb_galaxyPersistentTraffic = nil
	ship.mb_galaxyAmbientTraffic = true
	ship.mb_galaxyRegisteredAmbientTraffic = true
	G.UniverseTrafficEntities[record.id] = ship
	G.AmbientTrafficShips[#G.AmbientTrafficShips + 1] = ship
	if mode == "holding" then
		local port = findPlanetTrafficPort(record.role)
		ship:SetPos((port and port.point) or entry)
		G.BindShipToSWUUniverse(ship)
		setUniverseTrafficHolding(ship, record, port)
	elseif mode == "departure" then
		local port = findPlanetTrafficPort(record.role)
		ship:SetPos((port and port.point) or entry)
		G.BindShipToSWUUniverse(ship)
		if not beginUniverseTrafficDeparture(ship, record) then ship:Remove() return nil end
	else
		ship:SetPos(entry)
		G.BindShipToSWUUniverse(ship)
		if not beginUniverseTrafficArrival(ship, record, findPlanetTrafficPort(record.role)) then
			ship:Remove()
			return nil
		end
	end
	return ship
end

function G.SyncUniverseTrafficVisuals(now)
	if G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then return end
	if not universeTrafficEnabled() or not G.Runtime.enabled or not G.HasSWUUniverseFrame() then return end
	local currentKey = G.PlanetKey((G.State and G.State.currentPlanet) or "")
	if currentKey == "" then return end
	local wanted = {}
	for _, record in pairs(G.UniverseTraffic or {}) do
		local mode = universeTrafficVisualMode(record, currentKey, now)
		if mode then wanted[#wanted + 1] = { record = record, mode = mode } end
	end
	table.sort(wanted, function(a, b)
		local priority = { holding = 1, arrival = 2, departure = 3 }
		if priority[a.mode] == priority[b.mode] then return a.record.id < b.record.id end
		return priority[a.mode] < priority[b.mode]
	end)
	local maximum = math.max(1, math.floor(tonumber(gd.GalaxyTrafficVisibleMaximum) or 7))
	while #wanted > maximum do table.remove(wanted) end
	local active = {}
	for _, item in ipairs(wanted) do
		local record, mode = item.record, item.mode
		active[record.id] = true
		local ship = G.UniverseTrafficEntities[record.id]
		if not IsValid(ship) then ship = spawnUniverseTrafficVisual(record, mode) end
		if IsValid(ship) and ship.mb_galaxyUniverseTrafficMode ~= mode then
			if mode == "departure" and ship.mb_galaxyUniverseTrafficMode == "holding" then
				beginUniverseTrafficDeparture(ship, record)
			elseif mode == "holding" and ship.mb_galaxyUniverseTrafficMode == "arrival" then
				setUniverseTrafficHolding(ship, record)
			else
				ship:Remove()
				G.UniverseTrafficEntities[record.id] = spawnUniverseTrafficVisual(record, mode)
			end
		end
	end
	for id, ship in pairs(G.UniverseTrafficEntities) do
		if not active[id] then
			if IsValid(ship) then ship:Remove() end
			G.UniverseTrafficEntities[id] = nil
		end
	end
end

function G.UpdateUniverseTraffic(now, force)
	if not G._universeTrafficLoaded or not universeTrafficEnabled() then return end
	now = math.floor(tonumber(now) or unix())
	if not force and now < (G.NextUniverseTrafficAdvanceAt or 0) then return end
	G.NextUniverseTrafficAdvanceAt = now
		+ math.max(2, tonumber(gd.GalaxyTrafficAdvanceInterval) or 5)
	local changed = false
	for _, record in pairs(G.UniverseTraffic or {}) do
		if G.NormalizeUniverseTrafficIdentity(record) then changed = true end
		if G.AdvanceUniverseTrafficRecord(record, now) then changed = true end
	end
	G.UpdateLivingGalaxySimulation(now)
	if now >= (G.NextUniverseTrafficPopulationAt or 0) then
		G.NextUniverseTrafficPopulationAt = now
			+ math.max(20, tonumber(gd.GalaxyTrafficPopulationRefresh) or 90)
		if G.EnsureUniverseTrafficPopulation(now) > 0 then changed = true end
	end
	if changed then markUniverseTrafficDirty() end
	G.SyncUniverseTrafficVisuals(now)
	if G.UniverseTrafficDirty and now >= (G.NextUniverseTrafficSaveAt or 0) then
		G.SaveUniverseTraffic()
	end
end

-- Clear the local entity reference without removing or resetting the galaxy
-- record; it will be represented again only if the ship is truly in view.
local baseOnShipRemoved = G.OnShipRemoved
function G.OnShipRemoved(ship)
	if ship and ship.mb_galaxyUniverseTrafficID then
		local id = ship.mb_galaxyUniverseTrafficID
		if G.UniverseTrafficEntities[id] == ship then G.UniverseTrafficEntities[id] = nil end
	end
	if baseOnShipRemoved then return baseOnShipRemoved(ship) end
end

local baseSetCurrentPlanet = G.SetCurrentPlanet
function G.SetCurrentPlanet(name, reason)
	local result = baseSetCurrentPlanet(name, reason)
	timer.Simple(0, function()
		if G.UpdateUniverseTraffic then G.UpdateUniverseTraffic(unix(), true) end
	end)
	return result
end

local function reenterPersistentTraffic(ship, entryYaw)
	if not IsValid(ship) or not ship.mb_galaxyPersistentTraffic
		or not G.HasSWUUniverseFrame() then return false end
	local role = ship:GetRole()
	local entry = select(1, G.FindClearSkyboxEntry(entryYaw, math.Rand(-180, 180),
		math.Rand(-150, 150), role))
	local exit = select(1, G.FindClearSkyboxEntry(entryYaw + math.Rand(125, 235),
		math.Rand(-180, 180), math.Rand(-150, 150), role))
	if not isvector(entry) or not isvector(exit) then return false end
	local origin = ship.mb_galaxyDestination
	if not isstring(origin) or origin == "" then origin = (G.State and G.State.currentPlanet) or "local space" end
	local destination = chooseKnownDestination(origin)
	ship:SetPos(entry)
	G.BindShipToSWUUniverse(ship)
	ship.mb_galaxyPersistentOffscreen = nil
	ship.mb_galaxyFormationFlight = nil
	ship.mb_galaxyPursuitMode = nil
	ship.mb_galaxyPursuitTarget = nil
	ship:ClearCombatTarget()
	ship.mb_galaxyOrigin = origin
	ship.mb_galaxyDestination = destination
	ship.mb_galaxyRouteStatus = "cleared from " .. origin .. " for " .. destination
	ship.mb_galaxyRouteKind = "persistent local transit"
	return setTransitRoute(ship, exit, math.Rand(
		math.max(8, tonumber(gd.AmbientTrafficSpeedMin) or 24),
		math.max(8, tonumber(gd.AmbientTrafficSpeedMax) or 48)), "crossing", false)
end

function G.HandlePersistentShipSkyboxExit(ship, worldPos)
	if not IsValid(ship) or not ship.mb_galaxyPersistentTraffic then return false end
	ship.mb_galaxyPersistentOffscreen = true
	ship.mb_galaxyPersistentOffscreenAt = CurTime()
	ship:SetPos(worldPos)
	if G.PlayerShipIsMoving and G.PlayerShipIsMoving() then return true end
	local center = select(1, G.SkyboxFrame())
	local delta = worldPos - center
	local yaw = delta:LengthSqr() > 1 and delta:Angle().y or math.Rand(0, 360)
	return reenterPersistentTraffic(ship, yaw + 180)
end

function G.UpdatePersistentUniverseTraffic(now)
	if gd.PersistentUniverseTrafficEnabled == false or not G.HasSWUUniverseFrame() then return end
	if G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then return end
	if G.PlayerShipIsMoving and G.PlayerShipIsMoving() then return end
	local delay = math.max(0, tonumber(gd.PersistentUniverseReentryDelay) or 2)
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if IsValid(ship) and ship.mb_galaxyPersistentTraffic
		and ship.mb_galaxyPersistentOffscreen
		and now >= (ship.mb_galaxyPersistentOffscreenAt or now) + delay then
			reenterPersistentTraffic(ship, math.Rand(0, 360))
		end
	end
end

local function strategicFaction(ship)
	return IsValid(ship) and string.lower(tostring(ship.mb_galaxyTrueFaction or ship:GetFaction() or "")) or ""
end

local function strategicShips()
	local ships = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local faction = strategicFaction(ship)
		if IsValid(ship) and (ship.mb_galaxyUniverseTrafficID or ship.mb_galaxyPersistentTraffic)
		and not ship.mb_galaxyPersistentOffscreen and not ship.mb_galaxyMapSpace
		and not ship.mb_galaxyOrbitalBlockade and not ship.mb_galaxyBlockade
		and (faction == "republic" or faction == "cis") then
			ships[#ships + 1] = ship
		end
	end
	return ships
end

local function nearestStrategicShip(ship, faction, ships)
	local nearest, nearestDistance
	for _, candidate in ipairs(ships) do
		if candidate ~= ship and strategicFaction(candidate) == faction then
			local distance = ship:GetPos():DistToSqr(candidate:GetPos())
			if not nearestDistance or distance < nearestDistance then
				nearest, nearestDistance = candidate, distance
			end
		end
	end
	return nearest, math.sqrt(nearestDistance or math.huge)
end

local function strategicStrength(position, faction, ships)
	local radius = math.max(200, tonumber(gd.StrategicPatrolSupportRange) or 1150)
	local count = 0
	for _, ship in ipairs(ships) do
		if strategicFaction(ship) == faction and ship:GetPos():DistToSqr(position) <= radius * radius then
			count = count + 1
		end
	end
	return count
end

local function setStrategicCourse(ship, targetPos, speed, state)
	if not IsValid(ship) or not isvector(targetPos) then return end
	local delta = targetPos - ship:GetPos()
	if delta:LengthSqr() <= 1 then return end
	if G.ClearShipFlightRoute then G.ClearShipFlightRoute(ship) end
	ship.mb_galaxyFormationFlight = nil
	ship:SetFlightVelocity(delta:GetNormalized() * math.max(8, tonumber(speed) or 42))
	ship:SetShipState(state)
end

local function fleeStrategicShip(ship, threatPos)
	local away = ship:GetPos() - threatPos
	if away:LengthSqr() < 1 then away = VectorRand() end
	ship:ClearCombatTarget()
	ship.mb_galaxyPursuitMode = "fleeing"
	setStrategicCourse(ship, ship:GetPos() + away:GetNormalized() * 1200,
		tonumber(gd.StrategicPatrolFleeSpeed) or 64, "outnumbered; withdrawing")
end

local function raidSupportCandidate(ship, center, maximumRange)
	if not validContact(ship) or ship:GetHostile()
	or strategicFaction(ship) ~= "republic"
	or ship.mb_galaxyPersistentOffscreen or ship.mb_galaxyPlanetLandedAt
	or ship.mb_galaxySalvage or ship.mb_destroyed then return false end
	if ship.mb_navalOwnedFleetID or ship.mb_galaxyFleetFollowing then return true end
	return ship:GetPos():DistToSqr(center) <= maximumRange * maximumRange
end

local function raidSupportDamage(ship)
	local base = math.max(1, tonumber(gd.NearbyRepublicRaidSupportDamage) or 42)
	if ship:GetCapital() then
		base = base * math.max(1,
			tonumber(gd.NearbyRepublicRaidSupportCapitalMultiplier) or 1.3)
	end
	return math.floor(base)
end

local function raidSupportCanMove(ship)
	return IsValid(ship) and not ship.mb_navalOwnedFleetID
		and not ship.mb_galaxyFleetFollowing
		and not ship.mb_galaxyOrbitalBlockade
		and not ship.mb_galaxyBlockade
end

local function raidSupportPosition(ship, targetPos, holdRange)
	local away = ship:GetPos() - targetPos
	away.z = math.Clamp(away.z, -holdRange * 0.25, holdRange * 0.25)
	if away:LengthSqr() <= 1 then
		away = Angle(0, (ship:EntIndex() * 73) % 360, 0):Forward()
	end
	return targetPos + away:GetNormalized() * holdRange
end

function G.ReleaseNearbyRepublicRaidSupport(active)
	if not active then return end
	for _, capital in ipairs(G.RaidCapitals and G.RaidCapitals(active) or {}) do
		if IsValid(capital) and capital.ClearCombatTarget then
			capital:ClearCombatTarget()
		end
	end
	for _, ship in ipairs(active.republicSupport or {}) do
		if IsValid(ship) and ship.mb_galaxyRaidSupport == active.id then
			ship:ClearCombatTarget()
			ship.mb_galaxyRaidSupport = nil
			ship.mb_galaxyPursuitMode = nil
			ship.mb_galaxyPursuitTarget = nil
			ship.mb_galaxyFlightRoute = nil
			ship.mb_galaxyFormationFlight = nil
			if ship.mb_navalOwnedFleetID or ship.mb_galaxyFleetFollowing then
				ship:SetShipState("returning to Republic fleet formation")
				ship:SetFlightVelocity(vector_origin)
				ship:SetDieAt(0)
			elseif ship.mb_galaxyOrbitalBlockade or ship.mb_galaxyBlockade then
				ship:SetShipState("resuming Republic blockade watch")
				ship:SetFlightVelocity(vector_origin)
				ship:SetDieAt(0)
			else
				ship:SetShipState("returning to Republic patrol")
				ship:SetFlightVelocity(vector_origin)
				ship.mb_galaxyAutonomousReadyAt = CurTime() + 1
				ship:SetDieAt(ship.mb_galaxyRaidSupportPersistent
					and 0 or CurTime() + 75)
			end
			ship.mb_galaxyRaidSupportPersistent = nil
		end
	end
	active.republicSupport = {}
end

function G.UpdateNearbyRepublicRaidSupport(active, now)
	if gd.NearbyRepublicRaidSupportEnabled == false or not active
	or active.kind ~= "cis_raid" then return end
	local center, skyboxRadius = G.SkyboxFrame()
	local maximumRange = math.max(skyboxRadius * 1.3,
		tonumber(gd.NearbyRepublicRaidSupportRange) or 2200)
	local maximumShips = math.max(1,
		math.floor(tonumber(gd.NearbyRepublicRaidSupportMaximum) or 6))
	active.republicSupport = active.republicSupport or {}
	local supportLookup = {}
	local support = {}
	for _, ship in ipairs(active.republicSupport) do
		if IsValid(ship) and ship.mb_galaxyRaidSupport == active.id then
			support[#support + 1] = ship
			supportLookup[ship] = true
		end
	end

	local candidates = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if not supportLookup[ship] and raidSupportCandidate(ship, center, maximumRange) then
			candidates[#candidates + 1] = ship
		end
	end
	table.sort(candidates, function(a, b)
		local aPriority = (a.mb_navalOwnedFleetID and 3 or a.mb_galaxyFleetFollowing and 2
			or a:GetCapital() and 1 or 0)
		local bPriority = (b.mb_navalOwnedFleetID and 3 or b.mb_galaxyFleetFollowing and 2
			or b:GetCapital() and 1 or 0)
		if aPriority ~= bPriority then return aPriority > bPriority end
		return a:GetPos():DistToSqr(center) < b:GetPos():DistToSqr(center)
	end)
	local added = 0
	for _, ship in ipairs(candidates) do
		if #support >= maximumShips then break end
		ship.mb_galaxyRaidSupport = active.id
		ship.mb_galaxyRaidSupportPersistent = ship:GetDieAt() == 0
		ship:SetDieAt(0)
		ship:ClearCombatTarget()
		ship.mb_galaxyPursuitMode = nil
		ship.mb_galaxyPursuitTarget = nil
		support[#support + 1] = ship
		supportLookup[ship] = true
		added = added + 1
	end
	active.republicSupport = support
	if added > 0 and not active.republicSupportAnnounced then
		active.republicSupportAnnounced = true
		announce(#support .. " nearby Republic vessel"
			.. (#support == 1 and " is" or "s are")
			.. " moving to support the flagship.", Color(80, 155, 240))
	end

	local capitals = G.RaidCapitals and G.RaidCapitals(active) or {}
	local holdRange = math.max(180,
		tonumber(gd.NearbyRepublicRaidSupportHoldRange) or 620)
	local fireInterval = math.max(1,
		tonumber(gd.NearbyRepublicRaidSupportFireInterval) or 4.2)
	for supportIndex, ship in ipairs(support) do
		local capital = capitals[((supportIndex - 1)
			% math.max(1, #capitals)) + 1]
		if not IsValid(capital) then
			ship:ClearCombatTarget()
			ship:SetShipState("responding to Republic raid alert")
			if raidSupportCanMove(ship) then
				local staging = raidSupportPosition(ship, center, holdRange)
				if ship:GetPos():DistToSqr(staging) > 90 * 90 then
					setStrategicCourse(ship, staging,
						tonumber(gd.NearbyRepublicRaidSupportSpeed) or 58,
						"moving to defend Republic flagship")
				else
					ship:SetFlightVelocity(vector_origin)
				end
			end
		else
			ship:SetCombatTarget(capital, raidSupportDamage(ship), fireInterval)
			local sameSpace = (ship.mb_galaxyMapSpace == true)
				== (capital.mb_galaxyMapSpace == true)
			if raidSupportCanMove(ship) and sameSpace then
				local staging = raidSupportPosition(ship, capital:GetPos(), holdRange)
				if ship:GetPos():DistToSqr(staging) > 100 * 100 then
					setStrategicCourse(ship, staging,
						tonumber(gd.NearbyRepublicRaidSupportSpeed) or 58,
						"closing to support range")
				else
					ship:SetFlightVelocity(vector_origin)
					ship:SetShipState("engaging CIS raid force")
				end
			else
				ship:SetShipState(sameSpace and "engaging CIS raid force"
					or "providing orbital fire support")
			end
		end
	end

	for capitalIndex, capital in ipairs(capitals) do
		if not IsValid(capital) or not capital.SetCombatTarget then continue end
		local returnTarget
		for offset = 0, math.max(0, #support - 1) do
			local ship = support[((capitalIndex + offset - 1)
				% math.max(1, #support)) + 1]
			if IsValid(ship) and not ship:GetInvulnerable()
			and (ship.mb_galaxyMapSpace == true)
				== (capital.mb_galaxyMapSpace == true) then
				returnTarget = ship
				break
			end
		end
		if IsValid(returnTarget) then
			capital:SetCombatTarget(returnTarget,
				math.max(1, tonumber(gd.NearbyRepublicRaidReturnFireDamage) or 58),
				math.max(1, tonumber(gd.NearbyRepublicRaidReturnFireInterval) or 5))
		end
	end
end

function G.UpdateStrategicPatrolAI(now)
	if not G.HasSWUUniverseFrame() then return end
	if G.Active and G.Active.kind == "cis_raid" then
		G.UpdateNearbyRepublicRaidSupport(G.Active, now)
		return
	end
	if gd.StrategicPatrolAIEnabled == false then return end
	local ships = strategicShips()
	if #ships == 0 then return end
	if G.Active or G.Operation then
		for _, ship in ipairs(ships) do
			if ship.mb_galaxyPursuitMode then ship:ClearCombatTarget() end
		end
		return
	end
	local acquireRange = math.max(300, tonumber(gd.StrategicPatrolAcquireRange) or 1500)
	local engageRange = math.max(120, tonumber(gd.StrategicPatrolEngagementRange) or 620)
	local baseRange = math.max(100, tonumber(gd.StrategicPatrolBaseAttackRange) or 360)
	local playerPos = select(1, G.SkyboxFrame())
	for _, ship in ipairs(ships) do
		if now >= (ship.mb_galaxyPursuitCooldown or 0) then
			local faction = strategicFaction(ship)
			local enemyFaction = faction == "cis" and "republic" or "cis"
			local target, distance = nearestStrategicShip(ship, enemyFaction, ships)
			local targetPos = IsValid(target) and target:GetPos() or nil
			local pursuingPlayer = false
			if faction == "cis" then
				local playerDistance = ship:GetPos():Distance(playerPos)
				if playerDistance <= acquireRange and (not targetPos or playerDistance <= distance) then
					targetPos, distance, pursuingPlayer = playerPos, playerDistance, true
				end
			end
			if not targetPos or distance > acquireRange then
				ship.mb_galaxyPursuitMode = nil
				ship.mb_galaxyPursuitTarget = nil
				ship:ClearCombatTarget()
			else
				local friendly = strategicStrength(targetPos, faction, ships)
				local enemy = strategicStrength(targetPos, enemyFaction, ships)
				if pursuingPlayer then enemy = enemy + math.max(1, tonumber(gd.StrategicPatrolPlayerStrength) or 1) end
				if friendly < enemy then
					fleeStrategicShip(ship, targetPos)
				else
					ship.mb_galaxyPursuitMode = "pursuing"
					ship.mb_galaxyPursuitTarget = IsValid(target) and target or nil
					local desiredRange = pursuingPlayer and math.max(70, baseRange * 0.7) or engageRange
					if distance > desiredRange then
						setStrategicCourse(ship, targetPos,
							tonumber(gd.StrategicPatrolCruiseSpeed) or 48,
							faction == "cis" and "pursuing Republic contact" or "intercepting CIS contact")
					elseif pursuingPlayer and distance <= baseRange then
						local canRaid = G.CanStartRaid and G.CanStartRaid(false)
						if canRaid and G.StartRaid(false, {
							sideYaw = (ship:GetPos() - playerPos):Angle().y,
							fromPursuit = true,
						}) then
							ship.mb_galaxyPursuitCooldown = now
								+ math.max(30, tonumber(gd.StrategicPatrolPostRaidCooldown) or 180)
							ship:SetFlightVelocity(vector_origin)
							ship:SetShipState("guiding CIS base assault")
						elseif not canRaid then
							ship:SetFlightVelocity(vector_origin)
							ship:SetShipState("tracking Republic ship; assault conditions unmet")
						end
					else
						ship:SetFlightVelocity(vector_origin)
						ship:SetShipState(faction == "cis" and "engaging Republic contact"
							or "engaging CIS contact")
						if IsValid(target) then
							ship:SetCombatTarget(target,
								math.max(0, tonumber(gd.StrategicPatrolDamage) or 28),
								math.max(1, tonumber(gd.StrategicPatrolFireInterval) or 4.5))
						end
					end
				end
			end
		end
	end
end

local function persistentFactionCount(faction)
	local count = 0
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if IsValid(ship) and ship.mb_galaxyPersistentTraffic
		and strategicFaction(ship) == faction then
			count = count + 1
		end
	end
	return count
end

-- Persistent orbital blockades are stored per planet, while only the one at
-- the currently visible SWU planet needs live skybox actors.  This keeps a
-- campaign-wide occupation from filling every map with capital-ship props.
local function currentBlockadePort()
	if not G.GetPlanetObstacles or not G.PlanetWorldPosition or not G.PlanetObstacleRadius then
		return nil
	end
	local currentKey = G.PlanetKey((G.State and G.State.currentPlanet) or "")
	if currentKey == "" then return nil end
	local center = select(1, G.SkyboxFrame())
	for _, planet in ipairs(G.GetPlanetObstacles()) do
		local position = G.PlanetWorldPosition(planet)
		local radius = G.PlanetObstacleRadius(planet)
		local name = planetTrafficName(planet)
		if isvector(position) and radius > 0 and G.IsInsideSkybox(position)
		and G.PlanetKey(name) == currentKey then
			local normal = center - position
			if normal:LengthSqr() < 1 then normal = Vector(0, 0, 1) end
			normal:Normalize()
			return {
				planet = planet,
				name = name,
				key = currentKey,
				position = position,
				radius = radius,
				normal = normal,
			}
		end
	end
	return nil
end

function G.GetPlanetaryBlockade(planetName)
	local key = G.PlanetKey(planetName or "")
	return key ~= "" and G.OrbitalBlockades[key] or nil
end

function G.GetCurrentOrbitalBlockade()
	return G.GetPlanetaryBlockade((G.State and G.State.currentPlanet) or "")
end

function G.SetPlanetaryBlockade(planetName, faction, persistent, actor, reason)
	faction = string.lower(tostring(faction or ""))
	if faction ~= "republic" and faction ~= "cis" then
		return false, "Blockades must belong to the Republic or CIS."
	end
	local key = G.PlanetKey(planetName or "")
	local planet = key ~= "" and G.Planets[key] or nil
	if key == "" or not planet then return false, "That planet is not registered with Galaxy Director." end
	local now = unix()
	G.OrbitalBlockades[key] = {
		planet = planet.name,
		faction = faction,
		persistent = persistent == true,
		createdAt = (G.OrbitalBlockades[key] and G.OrbitalBlockades[key].createdAt) or now,
		updatedAt = now,
		reason = G.CleanText(reason or "orbital security order", 180),
	}
	if G.ActiveOrbitalBlockade and G.ActiveOrbitalBlockade.key == key then
		for _, ship in ipairs(G.ActiveOrbitalBlockade.ships or {}) do
			if IsValid(ship) then ship:Remove() end
		end
		G.ActiveOrbitalBlockade = nil
	end
	G.SaveOrbitalBlockades()
	if G.Audit then G.Audit(actor, "established " .. faction .. " orbital blockade", planet.name) end
	G.BroadcastState()
	if G.BroadcastAdminData then G.BroadcastAdminData() end
	return true, factionNames[faction] .. " blockade registered around " .. planet.name .. "."
end

function G.ClearPlanetaryBlockade(planetName, actor)
	local key = G.PlanetKey(planetName or "")
	local blockade = key ~= "" and G.OrbitalBlockades[key] or nil
	if not blockade then return false, "No orbital blockade is registered at that planet." end
	if G.ActiveOrbitalBlockade and G.ActiveOrbitalBlockade.key == key then
		for _, ship in ipairs(G.ActiveOrbitalBlockade.ships or {}) do
			if IsValid(ship) then ship:Remove() end
		end
		G.ActiveOrbitalBlockade = nil
	end
	G.OrbitalBlockades[key] = nil
	G.SaveOrbitalBlockades()
	if G.Audit then G.Audit(actor, "cleared orbital blockade", blockade.planet) end
	G.BroadcastState()
	if G.BroadcastAdminData then G.BroadcastAdminData() end
	return true, "Orbital blockade cleared at " .. blockade.planet .. "."
end

local function removeActiveOrbitalBlockade()
	local active = G.ActiveOrbitalBlockade
	if not active then return end
	for _, ship in ipairs(active.ships or {}) do
		if IsValid(ship) then ship:Remove() end
	end
	G.ActiveOrbitalBlockade = nil
end

local function blockadeOrbitPoint(port, role, index, count)
	local centerDirection = Vector(port.normal.x, port.normal.y, port.normal.z)
	local up = Vector(0, 0, 1)
	local right = centerDirection:Cross(up)
	if right:LengthSqr() < 0.01 then right = Vector(1, 0, 0) end
	right:Normalize()
	up = right:Cross(centerDirection)
	up:Normalize()
	local angle = math.rad(((index - 1) / math.max(1, count)) * 360)
	local direction = centerDirection + right * math.cos(angle) * 0.82
		+ up * math.sin(angle) * 0.58
	direction:Normalize()
	local shipRadius = G.MaximumRoleShipRadius(role)
	local distance = port.radius + shipRadius
		+ math.max(180, tonumber(gd.PlanetAvoidanceMargin) or 180)
		+ math.max(200, tonumber(gd.BlockadeOrbitClearance) or 950)
		+ math.max(0, tonumber(gd.BlockadeShipSpacing) or 520)
			* math.max(0, count - 1) * 0.22
	local point = port.position + direction * distance
	if not G.IsInsideSkybox(point) or not G.PlanetClearanceAt(point, shipRadius) then return nil end
	return point
end

local function spawnOrbitalBlockade(blockade, port)
	local faction = blockade.faction
	local role = faction == "republic" and "republic_flagship" or "cis_capital"
	local count = faction == "republic"
		and math.max(2, math.floor(tonumber(gd.RepublicBlockadeVenators) or 3))
		or math.max(1, math.floor(tonumber(gd.CISBlockadeCapitalShips) or 2))
	local active = {
		key = port.key,
		planet = blockade.planet,
		faction = faction,
		ships = {},
		orbitPositions = {},
		spawnedAt = CurTime(),
	}
	for index = 1, count do
		local point = blockadeOrbitPoint(port, role, index, count)
		if isvector(point) then
			local ship = G.SpawnShip(role, {
				sideYaw = (point - select(1, G.SkyboxFrame())):Angle().y,
				hold = true,
				faction = faction,
				trueFaction = faction,
				invulnerable = true,
				trafficPattern = "orbital_blockade",
				origin = blockade.planet,
				destination = blockade.planet .. " orbital security zone",
				routeStatus = faction == "republic" and "holding Republic blockade perimeter"
					or "holding CIS occupation perimeter",
				routeKind = "orbital blockade",
			})
			if IsValid(ship) then
				ship:SetPos(point)
				G.BindShipToSWUUniverse(ship)
				ship:SetFlightVelocity(vector_origin)
				ship:SetDieAt(0)
				ship:SetHostile(false)
				ship.mb_galaxyOrbitalBlockade = port.key
				ship.mb_galaxyOrbitalBlockadeLead = index == 1
				ship.mb_galaxyHoldForPlayerDeparture = true
				ship.mb_galaxyBlockadeOrbitPosition = Vector(point)
				ship:SetShipState(faction == "republic" and "holding orbital blockade"
					or "enforcing CIS occupation blockade")
				active.ships[#active.ships + 1] = ship
				active.orbitPositions[#active.orbitPositions + 1] = Vector(point)
				if index == 1 then active.lead = ship end
			end
		end
	end
	if #active.ships == 0 then return nil end
	G.ActiveOrbitalBlockade = active
	announce(factionNames[faction] .. " orbital blockade has taken station around "
		.. blockade.planet .. ".", faction == "republic" and Color(80, 155, 240) or Color(235, 65, 55))
	return active
end

local function returnBlockadeToOrbit(active)
	if not active then return end
	active.formedWithPlayer = nil
	for index, ship in ipairs(active.ships or {}) do
		if IsValid(ship) then
			local point = active.orbitPositions[index]
			if isvector(point) then
				ship:SetPos(point)
				G.BindShipToSWUUniverse(ship)
			end
			ship.mb_galaxyFleetFollowing = nil
			ship.mb_galaxyHoldForPlayerDeparture = true
			ship.mb_galaxyPlayerDeparting = false
			ship:SetFlightVelocity(vector_origin)
			ship:SetShipState("holding orbital blockade")
		end
	end
end

function G.JoinOrbitalBlockade(ply, lead)
	local active = G.ActiveOrbitalBlockade
	if not active or active.faction ~= "republic" or not IsValid(lead)
		or lead ~= active.lead then
		return false, "No Republic orbital blockade is available to join."
	end
	if active.formedWithPlayer then
		return false, "This blockade group is already formed alongside the Republic ship."
	end
	local center = select(1, G.SkyboxFrame())
	local shipAngles = G.HasSWUUniverseFrame() and SWU.Controller:GetInternalShipAngles() or angle_zero
	local forward, right, up = shipAngles:Forward(), shipAngles:Right(), shipAngles:Up()
	local spacing = math.max(300, tonumber(gd.BlockadeFormationSpacing) or 900)
	for index, ship in ipairs(active.ships or {}) do
		if IsValid(ship) then
			local lateral = (index - ((#active.ships + 1) * 0.5)) * spacing
			local point = center + forward * (800 + math.abs(lateral) * 0.2)
				+ right * lateral + up * ((index % 2 == 0) and 130 or -130)
			local clear = G.IsInsideSkybox(point)
				and (not G.PlanetClearanceAt or G.PlanetClearanceAt(point, G.MaximumRoleShipRadius("republic_flagship")))
			if clear then
				ship:SetPos(point)
				G.BindShipToSWUUniverse(ship)
			end
			ship.mb_galaxyFleetFollowing = true
			ship.mb_galaxyHoldForPlayerDeparture = true
			ship.mb_galaxyPlayerDeparting = false
			ship:SetFlightVelocity(vector_origin)
			ship:SetShipState("formed on Republic blockade line")
		end
	end
	active.formedWithPlayer = true
	G.AddCommsHistory("outgoing", lead,
		"Republic orbital blockade formed alongside the Republic ship.", ply)
	G.BroadcastState()
	return true, "Blockade group has formed to port and starboard of the Republic ship."
end

function G.LeaveOrbitalBlockade(ply, lead)
	local active = G.ActiveOrbitalBlockade
	if not active or active.faction ~= "republic" or not IsValid(lead)
		or lead ~= active.lead then
		return false, "No Republic blockade formation is active."
	end
	if not active.formedWithPlayer then
		return false, "The Republic ship is not currently part of this blockade formation."
	end
	returnBlockadeToOrbit(active)
	G.AddCommsHistory("outgoing", lead,
		"Republic orbital blockade returned to its planetary perimeter.", ply)
	G.BroadcastState()
	return true, "Blockade group has returned to the planetary perimeter."
end

function G.HasRepublicRestrictedAirspace()
	local blockade = G.GetCurrentOrbitalBlockade()
	return blockade and blockade.faction == "republic"
end

local function markRestrictedAirspaceTraffic(blockadeKey)
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if IsValid(ship) and not ship.mb_galaxyOrbitalBlockade and not ship.mb_galaxyBlockade then
			local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
			if (faction == "civilian" or faction == "pirate")
			and ship.mb_galaxyRestrictedAirspace ~= blockadeKey
			and not ship.mb_galaxyRestrictedOrderAt then
				ship.mb_galaxyRestrictedAirspace = blockadeKey
				ship:SetShipState("entering Republic restricted airspace")
				ship.mb_galaxyRouteStatus = "awaiting clearance at Republic blockade perimeter"
				ship.mb_galaxyRouteKind = "restricted-airspace approach"
			end
		end
	end
end

function G.HandleRestrictedAirspaceOrder(ply, ship, action)
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	if (action ~= "reroute" and action ~= "leave_restricted")
		or (faction ~= "civilian" and faction ~= "pirate")
		or not G.HasRepublicRestrictedAirspace() then
		return false
	end
	local cooldown = math.max(20, tonumber(gd.RestrictedAirspaceOrderCooldown) or 120)
	if (ship.mb_galaxyRestrictedOrderAt or 0) + cooldown > CurTime() then
		return true, "This vessel has already received a restricted-airspace order."
	end
	ship.mb_galaxyRestrictedOrderAt = CurTime()
	local chance = faction == "civilian"
		and tonumber(gd.RestrictedAirspaceCivilianCompliance) or tonumber(gd.RestrictedAirspacePirateCompliance)
	local complies = math.Rand(0, 1) <= math.Clamp(chance or 0.5, 0, 1)
	if not complies then
		ship:SetShipState("refusing restricted-airspace order")
		ship.mb_galaxyRouteStatus = "refusing Republic blockade clearance order"
		G.ChangeContactTrust(ship, -5, "Captain refused a Republic restricted-airspace order.")
		return true, faction == "pirate"
			and "\"No Republic captain tells us where to fly. Find another target.\""
			or "\"We cannot alter course at this time. We will clear the zone when able.\""
	end
	local center = select(1, G.SkyboxFrame())
	local away = ship:GetPos() - center
	local yaw = away:LengthSqr() > 1 and away:Angle().y or math.Rand(0, 360)
	local role = ship:GetRole()
	local exit = select(1, G.FindClearSkyboxEntry(yaw, math.Rand(-120, 120),
		math.Rand(-120, 120), role))
	if not isvector(exit) or not setTransitRoute(ship, exit, math.Rand(34, 48),
		"restricted_airspace", false) then
		return true, "The captain acknowledges, but no safe departure corridor is currently available."
	end
	ship.mb_galaxyPlanetTraffic = nil
	ship.mb_galaxyOrigin = (G.State and G.State.currentPlanet) or "Republic restricted space"
	ship.mb_galaxyDestination = "a cleared civilian hyperspace corridor"
	ship.mb_galaxyRouteStatus = action == "reroute" and "rerouting around Republic blockade"
		or "departing Republic restricted airspace"
	ship.mb_galaxyRouteKind = "blockade clearance"
	ship:SetShipState("complying with Republic clearance order")
	G.ChangeContactTrust(ship, faction == "civilian" and 2 or -1,
		"Captain complied with a Republic restricted-airspace order.")
	return true, faction == "civilian"
		and "\"Clearance received. We are changing course and will avoid the blockade perimeter.\""
		or "\"Fine. We are leaving your patrol zone.\""
end

-- Local navigation authority is available through any successful hail, not
-- only while a formal orbital blockade happens to be active. It gives crews
-- practical RP control over traffic while keeping each captain's response
-- dependent on faction and the existing compliance settings.
function G.HandleTrafficOrder(ply, ship, action)
	if not IsValid(ship) then return false end
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	if action == "declare_restricted" then
		if faction ~= "civilian" and faction ~= "pirate" then
			return true, "This contact is not subject to a civilian restricted-airspace declaration."
		end
		local key = G.PlanetKey((G.State and G.State.currentPlanet) or "")
		ship.mb_galaxyRestrictedAirspace = key ~= "" and key or "local_republic_zone"
		ship:SetShipState("under Republic restricted-airspace warning")
		ship.mb_galaxyRouteStatus = "Republic navigation authority has declared the local corridor restricted"
		ship.mb_galaxyRouteKind = "Republic traffic-control warning"
		G.AddCommsHistory("outgoing", ship,
			"Republic restricted-airspace declaration transmitted.", ply)
		return true, faction == "civilian"
			and "\"Restricted-airspace warning received. Please transmit your clearance directive.\""
			or "\"We acknowledge the transmission. That does not mean we accept your authority.\""
	end
	if action ~= "order_reroute" and action ~= "order_depart" and action ~= "order_withdraw" then
		return false
	end
	local cooldown = math.max(20, tonumber(gd.TrafficOrderCooldown) or 90)
	if (ship.mb_galaxyTrafficOrderAt or 0) + cooldown > CurTime() then
		return true, "This vessel has already received a Republic navigation order."
	end
	ship.mb_galaxyTrafficOrderAt = CurTime()
	local chance = faction == "republic" and 0.99
		or faction == "civilian" and tonumber(gd.TrafficOrderCivilianCompliance)
		or faction == "pirate" and tonumber(gd.TrafficOrderPirateCompliance)
		or faction == "cis" and tonumber(gd.TrafficOrderCISCompliance) or 0.25
	if math.Rand(0, 1) > math.Clamp(chance or 0.25, 0, 1) then
		ship:SetShipState("refusing Republic navigation order")
		ship.mb_galaxyRouteStatus = "refusing a Republic traffic-control directive"
		if faction == "cis" then ship:SetHostile(true) end
		G.ChangeContactTrust(ship, -4, "Captain refused a Republic navigation order.")
		return true, faction == "cis"
			and "\"Confederate command rejects Republic authority. Surrender or be fired upon.\""
			or faction == "pirate"
			and "\"No Republic captain dictates our route.\""
			or "\"We cannot comply with that directive at this time.\""
	end

	local record = ship.mb_galaxyUniverseTrafficID
		and G.UniverseTraffic[ship.mb_galaxyUniverseTrafficID] or nil
	local rerouted = record and G.ReleaseUniverseTrafficRecord(record, unix())
	if rerouted then
		timer.Simple(0, function()
			if G.UpdateUniverseTraffic then G.UpdateUniverseTraffic(unix(), true) end
		end)
	else
		releaseExpandedShip(ship,
			action == "order_reroute" and "rerouting under Republic directive"
				or action == "order_withdraw" and "withdrawing from Republic space"
				or "clearing local space", 52)
	end
	ship.mb_galaxyRouteStatus = action == "order_reroute"
		and "rerouting under Republic navigation authority"
		or action == "order_withdraw" and "withdrawing from Republic space"
		or "clearing the local Republic corridor"
	ship.mb_galaxyRouteKind = "Republic traffic-control order"
	G.ChangeContactTrust(ship, (faction == "civilian" or faction == "republic") and 2 or -1,
		"Captain complied with a Republic navigation order.")
	return true, faction == "republic"
		and "\"Republic directive acknowledged. We are clearing the local corridor.\""
		or faction == "civilian"
		and "\"Directive received. We are changing course now.\""
		or faction == "pirate"
		and "\"Fine. We are leaving your space.\""
		or "\"Confederate vessel withdrawing under protest.\""
end

function G.UpdateOrbitalBlockades(now)
	if G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then return end
	if gd.OrbitalBlockadesEnabled == false then
		if G.ActiveOrbitalBlockade then removeActiveOrbitalBlockade() end
		return
	end
	if now < (G.NextOrbitalBlockadeCheck or 0) then return end
	G.NextOrbitalBlockadeCheck = now + 4
	local planetName = (G.State and G.State.currentPlanet) or ""
	local key = G.PlanetKey(planetName)
	local planet = key ~= "" and G.Planets[key] or nil
	if planet and planet.allegiance == "cis" and gd.CISAutomaticBlockades ~= false
		and not G.OrbitalBlockades[key] then
		G.SetPlanetaryBlockade(planet.name, "cis", true, nil, "automatic CIS occupation")
	end
	local blockade = key ~= "" and G.OrbitalBlockades[key] or nil
	if not blockade or not G.HasSWUUniverseFrame() then
		if G.ActiveOrbitalBlockade then removeActiveOrbitalBlockade() end
		return
	end
	local active = G.ActiveOrbitalBlockade
	-- Fixed orbital actors should leave with the player ship instead of being
	-- repeatedly recreated during the same hyperspace departure. They return
	-- when the next planet is reached; a deliberately joined Republic formation
	-- is the one exception and stays alongside the ship until released.
	if G.PlayerShipIsMoving and G.PlayerShipIsMoving()
	and not (active and active.formedWithPlayer) then
		return
	end
	if active and active.key ~= key then
		removeActiveOrbitalBlockade()
		active = nil
	end
	if active then
		local valid = 0
		for _, ship in ipairs(active.ships or {}) do
			if IsValid(ship) then valid = valid + 1 end
		end
		if valid >= math.max(1, #active.ships) then
			if blockade.faction == "republic" then markRestrictedAirspaceTraffic(key) end
			return
		end
		removeActiveOrbitalBlockade()
	end
	local port = currentBlockadePort()
	if port and spawnOrbitalBlockade(blockade, port) and blockade.faction == "republic" then
		markRestrictedAirspaceTraffic(key)
	end
end

function G.BackgroundBattleForShip(ship)
	if not IsValid(ship) then return nil end
	for _, battle in ipairs(G.BackgroundBattles or {}) do
		if not battle.resolved and (battle.defender == ship or battle.attacker == ship) then
			return battle
		end
	end
	return nil
end

function G.HasActiveBackgroundBattle()
	for _, battle in ipairs(G.BackgroundBattles or {}) do
		if not battle.resolved then return true end
	end
	return false
end

local function battleHullFraction(ship)
	if not IsValid(ship) then return 0 end
	return math.Clamp(ship:GetHull() / math.max(1, ship:GetMaxHull()), 0, 1)
end

function G.ResolveBackgroundBattle(battle, outcome, details)
	if not battle or battle.resolved then return end
	battle.resolved = true
	outcome = outcome == "success" and "success"
		or outcome == "failure" and "failure" or "neutral"
	details = G.CleanText(details or "The local battle dispersed beyond sensor range.", 500)

	local operation = G.Operation
	if operation and operation.kind == "background_battle"
	and operation.data and operation.data.battle == battle then
		G.ResolveOperation(outcome, details)
		return
	end

	if validContact(battle.defender) then
		releaseExpandedShip(battle.defender,
			outcome == "success" and "returning to patrol" or "withdrawing from the battle area", 72)
	end
	if validContact(battle.attacker) then
		releaseExpandedShip(battle.attacker,
			outcome == "failure" and "leaving the battle area" or "retreating", 82)
	end
	G.RecordHistory("background_battle", outcome, G.State.currentPlanet, details)
	announce(details, outcome == "success" and Color(95, 220, 135)
		or outcome == "failure" and Color(235, 70, 60) or Color(235, 175, 70))
	G.BroadcastState()
end

local function battleCanEscalateToBoarding(battle)
	if gd.BackgroundBattleBoardingEscalationEnabled == false
		or not battle or battle.boardingEscalationChecked then return false end
	if not battle.joined or not IsValid(battle.attacker) then return false end
	if (battle.attacker.mb_galaxyTrueFaction or battle.attacker:GetFaction()) ~= "cis" then return false end
	if battleHullFraction(battle.attacker) < math.Clamp(
		tonumber(gd.BackgroundBattleBoardingAttackerHullMinimum) or 0.46, 0.1, 0.95) then
		return false
	end
	if G.Active or not G.Runtime.enabled or not G.Runtime.attacks then return false end
	if G.ActivePlayerCount() < math.max(1, tonumber(G.Runtime.minPlayersAttack) or 6) then return false end
	local remaining = math.max(0, tonumber(G.Runtime.majorCooldown) or 5400)
		- (unix() - (tonumber(G.State.lastMajorAttack) or 0))
	return remaining <= 0
end

local function escalateBattleToBoarding(battle)
	if not battleCanEscalateToBoarding(battle) then return false end
	battle.boardingEscalationChecked = true
	local sideYaw = IsValid(battle.attacker) and battle.attacker.mb_galaxySideYaw or math.Rand(0, 360)
	local details = "CIS reinforcements have broken from the local battle and are launching a boarding assault. "
		.. "All hands prepare to repel boarders."
	local operation = G.Operation
	if operation and operation.kind == "background_battle"
	and operation.data and operation.data.battle == battle then
		G.ResolveOperation("neutral", details)
		battle.resolved = true
	else
		G.ResolveBackgroundBattle(battle, "neutral", details)
	end
	timer.Simple(0, function()
		if G.Active or G.Operation then return end
		G.StartRaid(false, { fromBattle = true, sideYaw = sideYaw })
	end)
	return true
end

function G.UpdateBackgroundBattles(now)
	local remaining = {}
	for _, battle in ipairs(G.BackgroundBattles or {}) do
		if not battle.resolved then
			local defenderAlive = validContact(battle.defender)
			local attackerAlive = validContact(battle.attacker)
			if battle.joined and not battle.boardingEscalationChecked
			and now >= (battle.boardingEscalationAt or math.huge) then
				battle.boardingEscalationChecked = true
				if math.Rand(0, 1) <= math.Clamp(
					tonumber(gd.BackgroundBattleBoardingEscalationChance) or 0.24, 0, 1) then
					-- Reset the check so the helper can validate the escalation and
					-- mark it permanently only when it actually takes place.
					battle.boardingEscalationChecked = nil
					escalateBattleToBoarding(battle)
				end
			end
			if not battle.resolved and not defenderAlive and not attackerAlive then
				G.ResolveBackgroundBattle(battle, "neutral",
					"Both contacts were lost during a local battle.")
			elseif not battle.resolved and not attackerAlive then
				G.ResolveBackgroundBattle(battle, "success",
					"Republic-aligned traffic has won the local space engagement.")
			elseif not battle.resolved and not defenderAlive then
				G.ResolveBackgroundBattle(battle, "failure",
					"The hostile force has defeated the local Republic-aligned contact.")
			elseif not battle.resolved and now >= (battle.endsAt or 0) then
				local defenderStrength = battleHullFraction(battle.defender)
				local attackerStrength = battleHullFraction(battle.attacker)
				if defenderStrength >= attackerStrength then
					G.ResolveBackgroundBattle(battle, "success",
						"The hostile force broke off after the local space engagement.")
				else
					G.ResolveBackgroundBattle(battle, "failure",
						"The hostile force drove the local contact from the route.")
				end
			end
		end
		if not battle.resolved then remaining[#remaining + 1] = battle end
	end
	G.BackgroundBattles = remaining
end

function G.JoinBackgroundBattle(ply, ship)
	local battle = G.BackgroundBattleForShip(ship)
	if not battle then return false, "That battle has already left local sensor range." end
	if G.Active then return false, "Priority tactical traffic must be cleared before joining this battle." end
	if G.Operation then return false, "Another fleet operation is already active." end
	if G.ScannedShips[ship] ~= true then
		return false, "Complete a sensor scan before committing the Republic ship to this engagement."
	end
	if not validContact(battle.defender) or not validContact(battle.attacker) then
		return false, "The battle has already been resolved."
	end

	local ok, operation = G.BeginOperation("background_battle", {
		title = "LOCAL SPACE ENGAGEMENT",
		body = "Republic support committed. Scan both contacts and use long-range fire control against the hostile ship.",
		phase = "engaged",
		endsAt = battle.endsAt,
		goal = 1,
		target = battle.defender,
		targets = { battle.defender },
		hostiles = { battle.attacker },
		operator = ply,
		data = { battle = battle },
	})
	if not ok then return false, operation end

	battle.joined = true
	battle.operator = ply
	if (battle.attacker.mb_galaxyTrueFaction or battle.attacker:GetFaction()) == "cis"
	and gd.BackgroundBattleBoardingEscalationEnabled ~= false then
		local minimum = math.max(10, tonumber(gd.BackgroundBattleBoardingDelayMinimum) or 38)
		local maximum = math.max(minimum, tonumber(gd.BackgroundBattleBoardingDelayMaximum) or 82)
		battle.boardingEscalationAt = CurTime() + math.Rand(minimum, maximum)
	end
	battle.defender:SetInvulnerable(false)
	battle.attacker:SetInvulnerable(false)
	battle.defender:SetShipState("fighting with Republic support")
	battle.attacker:SetShipState("engaged by Republic fire control")
	G.AddCommsHistory("outgoing", battle.defender,
		"Republic ship has joined the local engagement and authorised fire control.", ply)
	announce("Republic forces have joined a local space engagement. Long-range fire control is available.",
		Color(80, 155, 240))
	G.BroadcastState()
	return true, operation
end

function G.SpawnBackgroundBattle(context)
	if gd.BackgroundBattlesEnabled == false or G.HasActiveBackgroundBattle() then return 0 end
	local capacity = math.max(1, math.floor(tonumber(gd.AmbientTrafficMaximumShips) or 9))
	if activeAmbientTrafficCount() > capacity - 2 then return 0 end

	local sideYaw = math.Rand(0, 360)
	local exitYaw = sideYaw + (math.random(2) == 1 and 180 or -180)
	local defenderFaction = context and context.defender or (math.Rand(0, 1) < 0.64 and "republic" or "civilian")
	local defenderRole = defenderFaction == "republic" and "republic" or "civilian"
	local attackerFaction = context and context.attacker or (math.Rand(0, 1)
		< math.Clamp((G.State.currentRisk or 0.4) + 0.22, 0.3, 0.82) and "cis" or "pirate")
	local attackerRole = attackerFaction == "cis" and "cis_scout" or "pirate"
	local duration = math.max(60, tonumber(gd.BackgroundBattleDuration) or 145)
	local battle = {
		id = string.format("battle_%d_%03d", unix(), math.random(1, 999)),
		startedAt = CurTime(),
		endsAt = CurTime() + duration,
		galaxyBattle = context,
	}

	local defender = G.SpawnShip(defenderRole, {
		sideYaw = sideYaw,
		lane = -85,
		height = math.Rand(-100, 100),
		hold = true,
		faction = defenderFaction,
		trueFaction = defenderFaction,
		transponderFaction = defenderFaction,
		invulnerable = false,
		hull = defenderFaction == "republic"
			and (tonumber(gd.BackgroundBattleRepublicHull) or 3900)
			or (tonumber(gd.BackgroundBattleCivilianHull) or 2800),
		expansionType = "battle",
		trafficPattern = "engagement",
		weapons = defenderFaction == "republic" and "Republic defensive batteries engaged"
			or "emergency defensive weapons firing",
	})
	local attacker = G.SpawnShip(attackerRole, {
		sideYaw = exitYaw,
		lane = 85,
		height = math.Rand(-100, 100),
		hold = true,
		faction = attackerFaction,
		trueFaction = attackerFaction,
		transponderFaction = attackerFaction,
		hostile = true,
		invulnerable = false,
		hull = tonumber(gd.BackgroundBattleAttackerHull) or 3200,
		expansionType = "battle",
		trafficPattern = "engagement",
		weapons = attackerFaction == "cis" and "CIS turbolasers firing on local traffic"
			or "pirate cannon batteries firing on local traffic",
	})
	if not IsValid(defender) or not IsValid(attacker) then
		if IsValid(defender) then defender:Remove() end
		if IsValid(attacker) then attacker:Remove() end
		return 0
	end

	battle.defender = defender
	battle.attacker = attacker
	defender.mb_galaxyBackgroundBattle = battle
	attacker.mb_galaxyBackgroundBattle = battle
	defender:SetShipState(defenderFaction == "republic"
		and "engaged with hostile traffic" or "under hostile attack")
	attacker:SetShipState("attacking local traffic")
	local defenderExit = select(1, G.FindClearSkyboxEntry(exitYaw, -85, defender:GetPos().z, defenderRole))
	local attackerExit = select(1, G.FindClearSkyboxEntry(sideYaw, 85, attacker:GetPos().z, attackerRole))
	if not setTransitRoute(defender, defenderExit, math.Rand(28, 36), "engagement", false)
		or not setTransitRoute(attacker, attackerExit, math.Rand(30, 38), "engagement", false) then
		defender:Remove()
		attacker:Remove()
		return 0
	end
	defender:SetDieAt(battle.endsAt + 20)
	attacker:SetDieAt(battle.endsAt + 20)
	defender:SetShipState(defenderFaction == "republic"
		and "engaged with hostile traffic" or "under hostile attack")
	attacker:SetShipState("attacking local traffic")
	defender:SetCombatTarget(attacker, math.max(1, tonumber(gd.BackgroundBattleDefenderDamage) or 38), 4.2)
	attacker:SetCombatTarget(defender, math.max(1, tonumber(gd.BackgroundBattleAttackerDamage) or 54), 3.5)
	G.BackgroundBattles[#G.BackgroundBattles + 1] = battle
	if defenderFaction == "republic" then
		G.AddCommsHistory("incoming", defender,
			"Republic ship requests assistance in a local engagement.")
	else
		G.AddCommsHistory("scan", defender,
			"Local civilian battle detected. Hail the vessel if Republic intervention is intended.")
	end
	announce("A local space battle is visible on long-range sensors. Fleet can scan and join the engagement.",
		Color(235, 175, 70))
	if defenderFaction == "republic" then pingCommunications() end
	G.BroadcastState()
	return 2
end

local function chooseAmbientTrafficRole()
	local danger = G.State.currentRisk or 0.4
	local roll = math.Rand(0, 1)
	if roll < danger * 0.27 then return "cis_scout" end
	if roll < danger * 0.27 + 0.16 then return "pirate" end
	if roll < danger * 0.27 + 0.54 then return "civilian" end
	return "republic"
end

local function chooseTrafficPattern()
	local roll = math.Rand(0, 1)
	if roll <= math.Clamp(tonumber(gd.AmbientTrafficDistantChance) or 0.34, 0, 1) then
		return "distant", true
	end
	roll = math.Rand(0, 1)
	if roll <= math.Clamp(tonumber(gd.AmbientTrafficFormationChance) or 0.28, 0, 1) then
		return "formation", false
	end
	if roll <= math.Clamp(tonumber(gd.AmbientTrafficCrossingChance) or 0.62, 0, 1) then
		return "crossing", false
	end
	return "pass_by", false
end

function G.SpawnAmbientTraffic(forcedRole)
	if gd.AmbientTrafficEnabled == false then return 0 end
	-- Routine traffic is now owned by the persistent galaxy simulation.  This
	-- compatibility entry point deliberately does not create a ship at the
	-- Republic ship: it fills/advances the independent traffic population.
	if gd.GalaxyTrafficSimulationEnabled ~= false then
		if not G._universeTrafficLoaded then return 0 end
		local created = G.EnsureUniverseTrafficPopulation(unix(), forcedRole)
		G.UpdateUniverseTraffic(unix(), true)
		return created
	end
	local capacity = math.max(1, math.floor(tonumber(gd.AmbientTrafficMaximumShips) or 9))
		- activeAmbientTrafficCount()
	if gd.PersistentUniverseTrafficEnabled ~= false and G.PersistentUniverseShipCount then
		capacity = math.min(capacity, math.max(0,
			math.floor(tonumber(gd.PersistentUniverseMaximumShips) or 14)
				- G.PersistentUniverseShipCount()))
	end
	if capacity <= 0 then return 0 end
	if not forcedRole and gd.RepublicFleetRendezvousEnabled ~= false and not G.ActiveRepublicFleet
	and not G.PendingRepublicFleet
	and math.Rand(0, 1) <= math.Clamp(tonumber(gd.RepublicFleetRendezvousChance)
		or 0.16, 0, 1) then
		local taskForce = G.SpawnRepublicFleetRendezvous()
		if #taskForce > 0 then return #taskForce end
	end

	local pattern, distant = chooseTrafficPattern()
	local count = forcedRole and 1 or (pattern == "formation" and math.random(2, 3) or 1)
	count = math.min(count, capacity)
	local _, radius = G.SkyboxFrame()
	local sideYaw = math.Rand(0, 360)
	local turn
	if pattern == "distant" then
		-- Adjacent-edge routes keep background contacts far from the Republic ship.
		turn = math.Rand(50, 105)
	elseif pattern == "crossing" then
		turn = math.Rand(105, 245)
	else
		turn = math.Rand(65, 130)
	end
	if math.random(2) == 1 then turn = -turn end
	local exitYaw = sideYaw + turn
	local laneScale = distant and math.Clamp(tonumber(gd.AmbientTrafficDistantLaneFraction)
		or 0.24, 0.08, 0.4) or 0.07
	local heightScale = distant and math.Clamp(tonumber(gd.AmbientTrafficDistantHeightFraction)
		or 0.18, 0.05, 0.35) or 0.08
	local laneBase = math.Rand(-radius * laneScale, radius * laneScale)
	local heightBase = math.Rand(-radius * heightScale, radius * heightScale)
	local speedMin = math.max(8, tonumber(gd.AmbientTrafficSpeedMin) or 24)
	local speedMax = math.max(speedMin, tonumber(gd.AmbientTrafficSpeedMax) or 48)
	if distant then
		speedMin = speedMin * 0.72
		speedMax = speedMax * 0.9
	end

	local created = 0
	for index = 1, count do
		local role = forcedRole or chooseAmbientTrafficRole()
		local variant = G.ResolveShipVariant and G.ResolveShipVariant(role) or nil
		local sizeClass = variant and variant.sizeClass
			or G.ShipSizeClass and G.ShipSizeClass(role) or "light"
		local spacing = G.ShipFormationSpacing and G.ShipFormationSpacing(sizeClass) or 130
		local lane = laneBase + (index - (count + 1) / 2) * math.max(72, spacing)
		local height = heightBase + (index - (count + 1) / 2)
			* math.max(36, spacing * 0.42)
		local faction = role == "cis_scout" and "cis" or role
		local origin = (G.State and G.State.currentPlanet) or "the local orbital lane"
		local destination = chooseKnownDestination(origin)
		local exit = select(1, G.FindClearSkyboxEntry(exitYaw, lane, height,
			role, sizeClass))
		if isvector(exit) then
			local ship = G.SpawnShip(role, {
				sideYaw = sideYaw,
				lane = lane,
				height = height,
				model = variant and variant.model or nil,
				sizeClass = sizeClass,
				hold = true,
				faction = faction,
				trueFaction = faction,
				invulnerable = true,
				persistentTraffic = gd.PersistentUniverseTrafficEnabled ~= false,
				trafficPattern = pattern,
				distantTraffic = distant,
				origin = origin,
				destination = destination,
				routeStatus = "cleared from " .. origin .. " for " .. destination,
				routeKind = "local hyperspace transit",
			})
			if setTransitRoute(ship, exit, math.Rand(speedMin, speedMax), pattern, distant) then
				if pattern == "formation" and IsValid(formationLeader)
				and G.SetShipFormationFollower then
					local row = index - 1
					local leaderSpacing = G.ShipFormationSpacing
						and G.ShipFormationSpacing(formationLeader:GetSizeClass()) or 130
					local formationSpacing = math.max(spacing, leaderSpacing)
					G.SetShipFormationFollower(ship, formationLeader,
						Vector(-formationSpacing * 0.9 * row,
							(row % 2 == 0 and 1 or -1) * formationSpacing,
							(row % 3 - 1) * formationSpacing * 0.38),
						{ speed = speedMax })
					ship.mb_galaxyRouteStatus = "holding formation with "
						.. formationLeader:GetShipName() .. " en route to " .. destination
				elseif pattern == "formation" then
					formationLeader = ship
				end
				created = created + 1
			elseif IsValid(ship) then
				ship:Remove()
			end
		end
	end
	return created
end

local baseSpawnAmbientFlight = G.SpawnAmbientFlight
function G.SpawnAmbientFlight()
	if not G.Runtime.enabled or not G.Runtime.encounters then
		return baseSpawnAmbientFlight()
	end
	if G.Operation or G.Active then
		G.ScheduleNextAmbient()
		return
	end
	if G.HasActiveBackgroundBattle() then
		G.ScheduleNextAmbient()
		if gd.AmbientTrafficEnabled ~= false then G.SpawnAmbientTraffic() end
		return
	end
	if G.AftermathUntil and CurTime() < G.AftermathUntil
	and math.Rand(0, 1) > math.Clamp(tonumber(gd.AftermathTrafficMultiplier)
		or 0.45, 0, 1) then
		G.ScheduleNextAmbient()
		return
	end
	if CurTime() >= (G._nextSpecialTraffic or 0)
	and math.Rand(0, 1) <= math.Clamp(tonumber(gd.SpecialTrafficChance) or 0.28, 0, 1) then
		G.ScheduleNextAmbient()
		G._nextSpecialTraffic = CurTime()
			+ math.max(60, tonumber(gd.SpecialTrafficMinimumInterval) or 240)
		local roll = math.Rand(0, 1)
		if (G.State.currentRisk or 0.4) >= 0.55 and roll < 0.28 then
			G.StartBlockadeOperation(nil)
		elseif roll < 0.62 then
			G.SpawnCivilianConvoy()
		else
			G.SpawnRareContact()
		end
		return
	end
	if gd.AmbientPhenomenaEnabled ~= false
	and CurTime() >= (G.NextAmbientPhenomenonAt or 0) then
		G.NextAmbientPhenomenonAt = CurTime()
			+ math.max(60, tonumber(gd.AmbientPhenomenaMinimumInterval) or 180)
		if math.Rand(0, 1) <= math.Clamp(tonumber(gd.AmbientPhenomenaChance) or 0.24, 0, 1)
		and G.SpawnAmbientPhenomenon("random") > 0 then
			G.ScheduleNextAmbient()
			return
		end
	end
	if G.Runtime.attacks and gd.BackgroundBattlesEnabled ~= false
	and CurTime() >= (G.NextBackgroundBattleAt or 0) then
		G.NextBackgroundBattleAt = CurTime()
			+ math.max(60, tonumber(gd.BackgroundBattleMinimumInterval) or 240)
		if math.Rand(0, 1) <= math.Clamp(tonumber(gd.BackgroundBattleChance) or 0.24, 0, 1)
		and G.SpawnBackgroundBattle() > 0 then
			G.ScheduleNextAmbient()
			return
		end
	end
	if gd.AmbientTrafficEnabled == false then return baseSpawnAmbientFlight() end
	G.ScheduleNextAmbient()
	G.SpawnAmbientTraffic()
end

local encounterProfiles = {
	civilian = {
		{
			id = "trade_run",
			title = "CIVILIAN MERCHANT TRANSIT",
			body = "A merchant freighter is crossing the local route with time-sensitive cargo. The captain requests clearance, trade, or an updated threat report.",
			source = "Civilian merchant captain",
			followup = "pirate",
			intelTitle = "Merchant route warning",
			intelDetails = "The merchant reports armed ships stopping traffic along a nearby trade lane.",
		},
		{
			id = "refugee_run",
			title = "CIVILIAN REFUGEE TRANSIT",
			body = "An overloaded civilian transport is moving displaced families away from the frontier. Its captain asks whether the Republic route is safe.",
			source = "Civilian relief coordinator",
			followup = "distress",
			intelTitle = "Refugee corridor report",
			intelDetails = "The relief transport reports a vulnerable civilian corridor requiring Republic attention.",
			recommendation = 3,
		},
		{
			id = "damaged_freighter",
			title = "DAMAGED CIVILIAN FREIGHTER",
			body = "A freighter with unstable drive telemetry is attempting to cross the system. The crew can share what damaged them if the channel is handled carefully.",
			source = "Civilian freighter bridge",
			followup = "cis",
			intelTitle = "Freighter damage report",
			intelDetails = "The freighter's crew reports Separatist signatures near the route where its systems were damaged.",
			recommendation = 2,
		},
	},
	republic = {
		{
			id = "patrol_sweep",
			title = "REPUBLIC PATROL SWEEP",
			body = "A Republic patrol is sweeping across the sector boundary and offers a secure intelligence exchange before continuing its route.",
			source = "Republic patrol command",
			followup = "cis",
			intelTitle = "Patrol sweep report",
			intelDetails = "Republic patrol sensors identified an organised CIS movement beyond the next route marker.",
		},
		{
			id = "relief_mission",
			title = "REPUBLIC RELIEF MISSION",
			body = "A Republic support vessel is delivering medical stores and spare parts. It can offer field repairs or request supplies for civilians ahead.",
			source = "Republic relief detachment",
			followup = "distress",
			intelTitle = "Relief corridor update",
			intelDetails = "Republic relief crews detected civilian emergency traffic deeper along the protected route.",
		},
		{
			id = "damaged_patrol",
			title = "DAMAGED REPUBLIC PATROL",
			body = "A Republic patrol reports battle damage after a skirmish and needs to exchange threat data before it can safely resume its assigned sweep.",
			source = "Republic patrol command",
			followup = "pirate",
			intelTitle = "Patrol after-action report",
			intelDetails = "The damaged patrol traced its attackers to unregistered pirate traffic near the local route.",
			recommendation = 2,
		},
	},
	pirate = {
		{
			id = "toll",
			title = "PIRATE TOLL DEMAND",
			body = "An armed independent vessel has moved across the lane and demands payment for passage. Weapons are charged, but its captain is still talking.",
			source = "Unknown pirate captain",
			followup = "pirate",
			intelTitle = "Pirate toll network",
			intelDetails = "The pirate captain's traffic data identifies other raiders operating the same toll route.",
		},
		{
			id = "ransom",
			title = "PIRATE RANSOM CHANNEL",
			body = "A pirate crew claims to be holding civilian cargo and offers a negotiation channel. The claim may be leverage, a genuine hostage situation, or a trap.",
			source = "Encrypted pirate transmission",
			followup = "distress",
			intelTitle = "Ransom coordinates",
			intelDetails = "Encrypted route data points to a civilian emergency signal left by the pirate crew.",
		},
		{
			id = "ambush",
			title = "PIRATE INTERCEPT",
			body = "A pirate vessel shadows the route with its weapons masked. It has opened a channel, but its position suggests a planned intercept.",
			source = "Masked pirate channel",
			followup = "cis",
			intelTitle = "Intercept telemetry",
			intelDetails = "The pirate's navigation data includes a recent Separatist fleet signature near the interception point.",
		},
	},
	distress = {
		{
			id = "under_fire",
			title = "CIVILIAN VESSEL UNDER FIRE",
			body = "A civilian transport reports incoming weapons fire and failing shields. Its emergency beacon requests an immediate Republic response.",
			source = "Civilian emergency beacon",
			followup = "pirate",
			intelTitle = "Distress route report",
			intelDetails = "The rescued crew recorded pirate movement through the adjacent civilian lane.",
		},
		{
			id = "medical_emergency",
			title = "MEDICAL DISTRESS SIGNAL",
			body = "A civilian ship reports wounded passengers and a failing life-support system while hostile signatures close on its position.",
			source = "Civilian medical emergency beacon",
			followup = "cis",
			intelTitle = "Medical distress telemetry",
			intelDetails = "Emergency telemetry captures a Separatist patrol signature moving through the distressed ship's route.",
			recommendation = 3,
		},
	},
	cis = {
		{
			id = "cis_recon",
			title = "CIS RECONNAISSANCE CONTACT",
			body = "A Separatist scout has entered the local route on a probing course and is transmitting the Republic ship's position to its command network.",
			source = "Republic tactical sensors",
		},
	},
}

function G.AssignEncounterProfile(active)
	if gd.EncounterProfilesEnabled == false or not active then return nil end
	local options = encounterProfiles[active.kind]
	if not options or #options == 0 then return nil end
	local profile = options[math.random(#options)]
	active.encounterProfile = profile.id
	active.encounterProfileName = G.EncounterProfileNames[profile.id] or profile.title
	active.encounterFollowup = profile.followup
	active.encounterProfileDetails = profile.intelDetails
	active.encounterProfileIntelTitle = profile.intelTitle
	active.encounterProfileRecommendation = profile.recommendation
	active.title = profile.title or active.title
	active.body = profile.body or active.body
	active.source = profile.source or active.source
	if IsValid(active.contactShip) then
		active.contactShip.mb_galaxyEncounterProfile = profile.id
		if profile.id == "refugee_run" then
			active.contactShip.mb_galaxyCargo = "civilian passengers, relief supplies and personal effects"
		elseif profile.id == "damaged_freighter" then
			active.contactShip.mb_galaxyCargo = "damaged freight containers and emergency repair stores"
		elseif profile.id == "relief_mission" then
			active.contactShip.mb_galaxyCargo = "medical supplies, bacta and field repair equipment"
		end
	end
	return profile
end

function G.ApplyEncounterProfileConsequence(active, outcome)
	if not active or active.encounterProfileApplied or outcome ~= "success" then return end
	active.encounterProfileApplied = true
	local reporter = IsValid(active.contactShip) and active.contactShip:GetShipName()
		or active.source or "Local contact"
	local recommendation = math.floor(tonumber(active.encounterProfileRecommendation) or 0)
	if recommendation ~= 0 then
		G.AddRecommendation(G.State.currentPlanet, recommendation, -1,
			"Republic forces handled the " .. string.lower(active.encounterProfileName
				or "local contact") .. " professionally.",
			active.responder or "Republic crew")
	end
	if active.encounterFollowup and active.encounterFollowup ~= ""
	and math.Rand(0, 1) <= math.Clamp(tonumber(gd.EncounterProfileFollowupChance)
			or 0.5, 0, 1) then
		G.AddIntel("encounter_report",
			active.encounterProfileIntelTitle or "Local route report",
			active.encounterProfileDetails or "The contact supplied new route intelligence.",
			reporter, math.random(62, 91), active.encounterFollowup)
	end
end

local baseResolveEncounterWithProfile = G.ResolveEncounter
function G.ResolveEncounter(outcome, details)
	local active = G.Active
	if active then G.ApplyEncounterProfileConsequence(active, outcome) end
	return baseResolveEncounterWithProfile(outcome, details)
end

local baseStartEncounter = G.StartEncounter
function G.StartEncounter(kind, forced, opts)
	local ok, result = baseStartEncounter(kind, forced, opts)
	if ok and G.Active == result then
		G.AssignEncounterProfile(result)
		if kind == "distress" then
			table.insert(result.choices, 1, {
				id = "analyze",
				label = "ANALYZE DISTRESS SIGNAL",
			})
			if not result.forced and G.Runtime.attacks
			and math.Rand(0, 1) <= math.Clamp(tonumber(gd.FakeDistressChance) or 0.22, 0, 1) then
				result.fakeDistress = true
			end
		end
		G.SendEncounter()
		G.BroadcastState()
	end
	return ok, result
end

local baseHandleEncounterResponse = G.HandleEncounterResponse
function G.HandleEncounterResponse(ply, encounterID, response)
	local active = G.Active
	if active and active.id == encounterID and active.encounterProfile then
		active.encounterProfileResponse = response
	end
	if active and active.id == encounterID and active.kind == "distress"
	and active.phase == "contact" and response == "analyze" then
		if G.CommsOperator ~= ply or not G.CommsSessionValid(ply, G.CommsTerminal)
		or active.responded or active.signalAnalyzed then return end
		if G.ShipSystemSnapshot().sensors < 10 then
			MilBase.Notify(ply, "The tactical sensor array is offline.", "warn")
			return
		end
		active.signalAnalyzed = true
		for index = #active.choices, 1, -1 do
			if active.choices[index].id == "analyze" then table.remove(active.choices, index) end
		end
		local sensorCondition = G.ShipSystemSnapshot().sensors
		local detectionChance = math.Clamp(0.35 + sensorCondition / 170, 0.35, 0.94)
		active.fakeRevealed = active.fakeDistress
			and math.Rand(0, 1) <= detectionChance
		if active.fakeRevealed then
			active.body = "Signal analysis detects a repeating civilian recording, masked drive emissions and inconsistent coordinates. The distress call is almost certainly an ambush."
			for _, choice in ipairs(active.choices) do
				if choice.id == "accept" then choice.label = "SPRING COUNTER-AMBUSH" end
			end
		else
			active.body = active.fakeDistress
				and "The damaged signal cannot be fully authenticated. No definite transponder mismatch is resolved."
				or "Signal analysis confirms matching civilian transponder, life-support and damage telemetry."
		end
		G.AddCommsHistory("scan", nil,
			active.fakeRevealed and "False distress beacon identified before interception."
				or "Distress beacon analysis completed without a confirmed anomaly.", ply)
		G.SendEncounter(ply)
		G.BroadcastState()
		return
	end
	if active and active.id == encounterID and active.fakeDistress and response == "accept" then
		if not G.Runtime.attacks then
			active.fakeDistress = nil
			return baseHandleEncounterResponse(ply, encounterID, response)
		end
		if G.CommsOperator ~= ply or not G.CommsSessionValid(ply, G.CommsTerminal)
		or active.responded then return end
		active.responded = true
		active.responder = operatorName(ply)
		active.respondingPlayer = ply
		active.choices = {}
		G.SendEncounter()
		active.contactShip = G.SpawnShip("pirate", {
			sideYaw = active.sideYaw,
			hold = true,
			encounterID = active.id,
			faction = "pirate",
			trueFaction = "pirate",
			transponderFaction = "civilian",
			hostile = false,
			hull = active.fakeRevealed and 1500 or 2100,
			name = "Distress Beacon Vessel",
			expansionType = "smuggler",
			manifestLegal = false,
		})
		if not IsValid(active.contactShip) then
			G.ResolveEncounter("neutral",
				"The distress source disappears before a safe intercept course can be established.")
			return
		end
		G.AddCommsHistory("incoming", active.contactShip,
			"The civilian distress signal was revealed as a pirate ambush.", ply)
		G.StartPirateAttack(active, active.fakeRevealed
			and "Republic analysis exposed the false beacon. The prepared crew has caught the pirate ambushers at a disadvantage."
			or "The distress beacon was false. Pirate vessels are moving to ambush the Republic ship.")
		G.Audit(ply, "answered false distress signal", active.id)
		return
	end
	return baseHandleEncounterResponse(ply, encounterID, response)
end

local baseStartDistressBattle = G.StartDistressBattle
function G.StartDistressBattle(active)
	baseStartDistressBattle(active)
	if G.Active ~= active or active.phase ~= "rescue"
	or not IsValid(active.civilianShip) or math.Rand(0, 1) > 0.34 then return end
	local ship = active.civilianShip
	ship:SetModel(G.ResolveShipModel("republic"))
	ship:SetFaction("republic")
	ship:SetRole("republic")
	ship:SetShipName("Damaged Republic Patrol")
	ship:SetModelSize(tonumber((gd.ShipModelScale or {}).republic) or 0.07)
	G.ClampShipModelScale(ship, "republic")
	ship.mb_galaxyTrueFaction = "republic"
	ship.mb_galaxyTransponderFaction = "republic"
	ship.mb_galaxyContactKey = nil
	G.ContactForShip(ship)
	active.distressFriendlyFaction = "republic"
	active.title = "REPUBLIC PATROL RESCUE"
	active.body = "Protect the damaged Republic patrol until its engineers restore a safe hyperspace vector."
	announce("The distress source is a damaged Republic patrol under hostile attack.",
		Color(80, 155, 240))
	G.BroadcastState()
end

local baseResolveDroidNPC = G.ResolveDroidNPC
function G.ResolveDroidNPC(npcType)
	if npcType ~= nil then return baseResolveDroidNPC(npcType) end
	local variant = G._boardingWaveVariant
	if variant == "heavy" or variant == "commando" then
		local npcList = list.Get("NPC") or {}
		local needles = variant == "heavy"
			and { "b2", "super battle droid", "heavy battle droid" }
			or { "bx", "commando droid", "droid commando" }
		for class, data in pairs(npcList) do
			local haystack = string.lower(class .. " " .. tostring(data.Name or "")
				.. " " .. tostring(data.Category or ""))
			for _, needle in ipairs(needles) do
				if string.find(haystack, needle, 1, true) then
					return class, istable(data.Weapons) and data.Weapons[1] or nil
				end
			end
		end
	end
	return baseResolveDroidNPC()
end

local function chooseBoardingVariant()
	local total = 0
	local entries = {}
	for id, data in pairs(gd.BoardingWaveVariants or {}) do
		local weight = math.max(0, tonumber(data.weight) or 0)
		total = total + weight
		entries[#entries + 1] = { id = id, data = data, ceiling = total }
	end
	if total <= 0 then return "assault", { label = "B1 ASSAULT WAVE", health = 1 } end
	local roll = math.Rand(0, total)
	for _, entry in ipairs(entries) do
		if roll <= entry.ceiling then return entry.id, entry.data end
	end
	return entries[#entries].id, entries[#entries].data
end

local baseSpawnBoardingWave = G.SpawnBoardingWave
function G.SpawnBoardingWave(active)
	local previousCount = #(active and active.npcs or {})
	local variant, definition = chooseBoardingVariant()
	G._boardingWaveVariant = variant
	local spawned = baseSpawnBoardingWave(active)
	G._boardingWaveVariant = nil
	if G.Active ~= active or spawned <= 0 then return spawned end

	active.waveVariant = variant
	active.waveVariantName = definition.label or string.upper(variant)
	active.body = "CIS boarding action underway. Current contact: "
		.. active.waveVariantName .. " across "
		.. math.max(1, #(active.breachZones or {})) .. " breach fronts."
	for index = previousCount + 1, #(active.npcs or {}) do
		local npc = active.npcs[index]
		if IsValid(npc) then
			if not npc.mb_galaxyBoardingHealthApplied then
				local healthMultiplier = math.max(0.5, tonumber(definition.health) or 1)
				npc:SetMaxHealth(math.max(1,
					math.floor(npc:GetMaxHealth() * healthMultiplier)))
				npc:SetHealth(math.max(1,
					math.floor(npc:Health() * healthMultiplier)))
			end
			npc.mb_galaxyBoardingVariant = variant
			if variant == "commando" and npc.SetCurrentWeaponProficiency then
				npc:SetCurrentWeaponProficiency(WEAPON_PROFICIENCY_VERY_GOOD)
			elseif variant == "saboteur" or variant == "demolition" then
				npc.mb_galaxySaboteur = true
			end
		end
	end
	if variant == "saboteur" or variant == "demolition" then
		timer.Simple(math.max(8, tonumber(gd.BoardingSabotageDelay) or 28), function()
			if G.Active ~= active or active.phase ~= "boarding" then return end
			local survivingSaboteur = false
			for _, npc in ipairs(active.npcs or {}) do
				if IsValid(npc) and npc:Health() > 0 and npc.mb_galaxySaboteur then
					survivingSaboteur = true
					break
				end
			end
			if not survivingSaboteur then return end
			if variant == "demolition" then
				active.integrity = math.max(0, (active.integrity or 100) - math.random(8, 16))
				announce("A surviving droid demolition team detonated charges inside the ship.",
					Color(235, 70, 55))
				if active.integrity <= 0 then
					G.ResolveRaid("cis",
						"Droid demolition teams destroyed critical internal compartments.")
					return
				end
			end
			local nodes = {}
			for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
				if not node:GetBroken() then nodes[#nodes + 1] = node end
			end
			local node = #nodes > 0 and nodes[math.random(#nodes)] or nil
			if IsValid(node) and node.Break then
				node:Break(G.PrimaryRaidCapital
					and G.PrimaryRaidCapital(active) or game.GetWorld())
			end
			G.DamageShipSystem(math.random(2) == 1 and "sensors" or "communications",
				25, "a CIS sabotage team reached internal control relays")
		end)
	end
	G.BroadcastState()
	return spawned
end

local baseBombardMainShip = G.BombardMainShip
function G.BombardMainShip(active, heavy)
	baseBombardMainShip(active, heavy)
	if G.Active ~= active then return end
	local shields = G.ShipSystemSnapshot().shields
	if active.kind == "cis_raid" and active.integrity and shields < 60 then
		local bleed = (heavy and 2.5 or 0.8) * (1 - shields / 100)
		active.integrity = math.max(0, active.integrity - bleed)
		if active.integrity <= 0 then
			G.ResolveRaid("cis",
				"CIS bombardment penetrated the failed shield network and destroyed critical compartments.")
			return
		end
	end
	local chance = heavy and 0.42 or 0.16
	if math.Rand(0, 1) <= chance then
		local systems = { "sensors", "communications", "weapons", "shields" }
		G.DamageShipSystem(systems[math.random(#systems)],
			heavy and math.random(15, 28) or math.random(6, 14),
			"CIS weapons impact")
	end
end

local baseRequestCapitalVolley = G.RequestCapitalVolley
function G.RequestCapitalVolley(ply, encounterID)
	if G.ShipSystemSnapshot().weapons < 15 then
		MilBase.Notify(ply,
			"Capital weapons control is disrupted. Engineering must restore the fire-control network.",
			"warn")
		return
	end
	return baseRequestCapitalVolley(ply, encounterID)
end

local baseCanStartEncounter = G.CanStartEncounter
function G.CanStartEncounter(forced)
	if G.Operation then return false, "A fleet operation is already active." end
	return baseCanStartEncounter(forced)
end

local baseCanStartRaid = G.CanStartRaid
function G.CanStartRaid(forced)
	if G.Operation then return false, "A fleet operation is already active." end
	return baseCanStartRaid(forced)
end

local basePublicSnapshot = G.PublicSnapshot
function G.PublicSnapshot()
	local snapshot = basePublicSnapshot()
	snapshot.operation = operationSnapshot(G.Operation)
	snapshot.shipSystems = G.ShipSystemSnapshot()
	snapshot.support = {
		charges = G.Support.charges or 0,
		maximum = math.max(1, tonumber(gd.ReinforcementMaximum) or 3),
		pending = G.Support.pending == true,
		nextRecharge = G.Support.nextRecharge or 0,
	}
	snapshot.aftermathUntil = G.AftermathUntil or 0
	snapshot.intelRecords = {}
	for index, item in ipairs(G.IntelRecords) do
		if index > 5 then break end
		if (item.expires or 0) > unix() then
			snapshot.intelRecords[#snapshot.intelRecords + 1] = item
		end
	end
	snapshot.intelLead = G.IntelLead and {
		kind = G.IntelLead.kind,
		source = G.IntelLead.source,
		readyAt = G.IntelLead.readyAt,
		expiresAt = G.IntelLead.expiresAt,
	} or nil
	snapshot.galaxyReports = G.RecentGalaxyReports and G.RecentGalaxyReports(3) or {}
	local currentEconomy = G.GalaxyEconomyFor and G.GalaxyEconomyFor(
		G.PlanetKey((G.State and G.State.currentPlanet) or "")) or nil
	snapshot.systemActivity = currentEconomy and G.CleanText(currentEconomy.activity, 120) or ""
	snapshot.comms = snapshot.comms or {}
	snapshot.comms.scanning = G.PendingScan ~= nil
	snapshot.comms.conversation = G.HailConversation
		and IsValid(G.HailConversation.ship)
		and G.HailConversation.ship:GetShipName() or ""
	if snapshot.active and G.Active then
		snapshot.active.waveVariant = G.Active.waveVariant
		snapshot.active.waveVariantName = G.Active.waveVariantName
		snapshot.active.encounterProfile = G.Active.encounterProfile
		snapshot.active.encounterProfileName = G.Active.encounterProfileName
	end
	return snapshot
end

local baseUpdateCommsTerminals = G.UpdateCommsTerminals
function G.UpdateCommsTerminals()
	baseUpdateCommsTerminals()
	local active = G.Active
	if active and active.choices and #active.choices > 0 then return end
	local status, contact
	if G.PendingScan and IsValid(G.PendingScan.ship) then
		status = "ACTIVE SENSOR SCAN"
		contact = G.PendingScan.ship:GetShipName()
	elseif G.HailConversation and IsValid(G.HailConversation.ship)
	and CurTime() < (G.HailConversation.expiresAt or 0) then
		status = "CHANNEL OPEN"
		contact = G.HailConversation.ship:GetShipName()
	end
	if not status then return end
	for _, terminal in ipairs(ents.FindByClass("mb_galaxy_comms")) do
		if IsValid(terminal) then
			terminal:SetChannelStatus(status)
			terminal:SetContactName(G.CleanText(contact, 96))
		end
	end
end

local baseReleaseCommsOperator = G.ReleaseCommsOperator
function G.ReleaseCommsOperator(reason, silent)
	G.PendingScan = nil
	G.HailConversation = nil
	return baseReleaseCommsOperator(reason, silent)
end

local baseSendEncounter = G.SendEncounter
function G.SendEncounter(target)
	local active = G.Active
	if active and active.choices and #active.choices > 0 then
		G.PendingScan = nil
		G.HailConversation = nil
	end
	return baseSendEncounter(target)
end

local baseOnShipLeftSkybox = G.OnShipLeftSkybox
function G.OnShipLeftSkybox(ship)
	if IsValid(ship) and ship.mb_galaxyHyperspaceArrivalShown
	and gd.HyperspaceTransitEffectsEnabled ~= false and G.EmitHyperspaceBurst then
		local velocity = ship:GetFlightVelocity()
		if velocity:LengthSqr() > 0 then
			local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
			local color = faction == "republic" and Color(70, 145, 255)
				or faction == "cis" and Color(235, 65, 55)
				or faction == "pirate" and Color(235, 170, 55) or Color(175, 220, 255)
			G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), velocity, color, false)
		end
	end
	local operation = G.Operation
	if operation and operation.kind == "escort" then
		for _, target in ipairs(operation.targets or {}) do
			if target == ship then
				G.ResolveOperation("success",
					"The escorted convoy reached its hyperspace departure corridor.")
				break
			end
		end
	end
	return baseOnShipLeftSkybox(ship)
end

timer.Create("MilBase.GalaxyExpansionThink", 1, 0, function()
	if gd.LivingUniverseExpansion == false then return end
	local now = CurTime()
	local nowTime = unix()
	if (not G.Runtime.enabled or not G.Runtime.attacks) and G.HasActiveBackgroundBattle() then
		for _, battle in ipairs(G.BackgroundBattles or {}) do
			G.ResolveBackgroundBattle(battle, "neutral",
				"Local battle contacts dispersed when Galaxy Director attacks were disabled.")
		end
		G.UpdateBackgroundBattles(now)
	end
	if G.Operation and not G.Runtime.enabled then
		G.CancelOperation("Galaxy Director disabled during the fleet operation.")
		return
	end

	if G.HailConversation and (not IsValid(G.HailConversation.operator)
	or not IsValid(G.HailConversation.ship)
	or now >= (G.HailConversation.expiresAt or 0)) then
		G.HailConversation = nil
		G.UpdateCommsTerminals()
	end
	if G.Runtime.enabled and gd.AmbientCommsChatterEnabled ~= false
	and now >= (G.NextAmbientCommsChatterAt or 0) then
		local minimum = math.max(20, tonumber(gd.AmbientCommsChatterMinimumInterval) or 70)
		local maximum = math.max(minimum, tonumber(gd.AmbientCommsChatterMaximumInterval) or 135)
		G.NextAmbientCommsChatterAt = now + math.Rand(minimum, maximum)
		G.SendAmbientCommsChatter()
	end
	if G.Runtime.enabled and gd.PlanetTrafficEnabled ~= false
	and now >= (G.NextPlanetTrafficAt or 0) then
		local minimum = math.max(20, tonumber(gd.PlanetTrafficMinimumInterval) or 45)
		local maximum = math.max(minimum, tonumber(gd.PlanetTrafficMaximumInterval) or 85)
		G.NextPlanetTrafficAt = now + math.Rand(minimum, maximum)
		-- Galaxy traffic already provides arrivals and departures at this planet.
		-- Keep SpawnPlanetTraffic for a deliberate diagnostic command, but do not
		-- fabricate local ships on a timer while the galaxy simulation is active.
		if gd.GalaxyTrafficSimulationEnabled ~= false then
			G.UpdateUniverseTraffic(nowTime, true)
		elseif not G.Active and not G.Operation then
			G.SpawnPlanetTraffic()
		end
	end
	G.UpdatePlanetTraffic(now)
	if G.Runtime.enabled and gd.AmbientTrafficEnabled ~= false
	and gd.GalaxyTrafficSimulationEnabled ~= false
	and now >= (G.NextPersistentTrafficMaintenanceAt or 0) then
		G.NextPersistentTrafficMaintenanceAt = now + 12
		G.UpdateUniverseTraffic(nowTime)
	end

	if nowTime >= (G.Support.nextRecharge or 0) then
		local maximum = math.max(1, tonumber(gd.ReinforcementMaximum) or 3)
		if (G.Support.charges or 0) < maximum then
			G.Support.charges = G.Support.charges + 1
			G.Support.nextRecharge = nowTime
				+ math.max(60, tonumber(gd.ReinforcementRechargeTime) or 1800)
			G.SaveExpansionState()
			G.BroadcastState()
		else
			G.Support.nextRecharge = nowTime
				+ math.max(60, tonumber(gd.ReinforcementRechargeTime) or 1800)
		end
	end

	if not G.Active then
		for category, value in pairs(G.SystemDisruption) do
			if value > 0 then G.SystemDisruption[category] = math.max(0, value - 0.45) end
		end
	end

	local brokenNodes = 0
	for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
		if node:GetBroken() then brokenNodes = brokenNodes + 1 end
	end
	if G._lastBrokenShipNodes and brokenNodes < G._lastBrokenShipNodes then
		for category, value in pairs(G.SystemDisruption) do
			G.SystemDisruption[category] = math.max(0, value - 18)
		end
		G.BroadcastState()
	end
	G._lastBrokenShipNodes = brokenNodes

	for index = #G.IntelRecords, 1, -1 do
		if (G.IntelRecords[index].expires or 0) <= nowTime then
			table.remove(G.IntelRecords, index)
		end
	end

	local lead = G.IntelLead
	if lead and now >= (lead.expiresAt or 0) then
		G.IntelLead = nil
	elseif lead and now >= (lead.readyAt or math.huge)
	and not G.Active and not G.Operation then
		G.IntelLead = nil
		if lead.kind == "blockade" then
			G.StartBlockadeOperation(nil)
		elseif lead.kind == "cis" or lead.kind == "pirate"
		or lead.kind == "distress" then
			local ok = G.StartEncounter(lead.kind, false, {
				reason = "intelligence chain from " .. tostring(lead.source),
			})
			if ok then
				announce("A previously reported contact has appeared on tactical sensors.",
					Color(235, 175, 70))
			end
		end
	end

	G.UpdateRepublicFleetFollow(now)
	G.UpdateOrbitalBlockades(now)
	G.UpdateUniverseTraffic(nowTime)
	G.UpdateStrategicPatrolAI(now)
	G.UpdateBackgroundBattles(now)

	local operation = G.Operation
	if not operation then return end
	if operation.kind == "escort" then
		if operation.data and operation.data.skyboxEscort then
			G.UpdateSkyboxEscortOperation(operation, now)
			if G.Operation ~= operation then return end
		elseif operation.data and operation.data.mapSpace then
			G.UpdateMapEscortOperation(operation, now)
			if G.Operation ~= operation then return end
		else
			local survivors = 0
			for _, ship in ipairs(operation.targets or {}) do
				if validContact(ship) then survivors = survivors + 1 end
			end
			operation.progress = survivors
			if survivors <= 0 then
				G.ResolveOperation("failure", "The escorted convoy was destroyed.")
				return
			end
			local hostiles = 0
			for _, ship in ipairs(operation.hostiles or {}) do
				if validContact(ship) then hostiles = hostiles + 1 end
			end
			if operation.data.attackersSpawned and hostiles <= 0
			and now >= operation.startedAt + 22 then
				G.ResolveOperation("success",
					"Republic forces protected the convoy and drove off every attacker.")
				return
			end
			if now >= operation.endsAt then
				G.ResolveOperation("success",
					"The convoy completed its jump calculations and escaped the dangerous route.")
				return
			end
		end
	elseif operation.kind == "blockade" then
		for _, record in pairs(operation.data.decisions or {}) do
			if record.ship and not validContact(record.ship) and not record.decided then
				record.decided = "lost"
				operation.progress = (operation.progress or 0) + 1
				operation.mistakes = (operation.mistakes or 0) + 1
			end
		end
		if operation.progress >= operation.goal then
			G.ResolveOperation((operation.mistakes or 0) <= 1 and "success" or "failure",
				"Blockade inspection complete: " .. (operation.score or 0)
					.. " correct decision(s), " .. (operation.mistakes or 0)
					.. " error(s).")
			return
		end
		if now >= operation.endsAt then
			G.ResolveOperation((operation.mistakes or 0) <= 1 and "success" or "failure",
				"Blockade window closed with " .. (operation.progress or 0)
				.. "/" .. operation.goal .. " contacts processed.")
			return
		end
	elseif operation.kind == "salvage" then
		if not validContact(operation.target) then
			G.ResolveOperation("failure", "The wreckage field dispersed before recovery completed.")
			return
		end
		if now >= operation.endsAt then
			G.ResolveOperation("success",
				(operation.data.survivors or 0) > 0
					and ("Recovery teams rescued " .. operation.data.survivors
						.. " survivor(s) and secured the flight recorder.")
					or "Recovery teams secured cargo and a damaged flight recorder from the wreck.")
			return
		end
	elseif operation.kind == "counter_board" then
		if not validContact(operation.target) then
			G.ResolveOperation("failure",
				"The hostile vessel was lost before boarding teams could withdraw.")
			return
		end
		if operation.phase == "approach"
		and now >= (operation.data.decisionAt or math.huge) then
			G.SendCounterBoardDecision(operation)
		elseif operation.phase == "evacuation" and now >= operation.endsAt then
			G.ResolveOperation("success",
				"Republic boarding teams returned safely with the captured objective.")
			return
		elseif now >= (operation.data.selfDestructAt or math.huge) then
			local target = operation.target
			G.ResolveOperation("failure",
				"The hostile reactor overloaded before the boarding team completed evacuation.")
			if IsValid(target) then
				target:SetInvulnerable(false)
				target:DestroyShip(game.GetWorld())
			end
			return
		end
	elseif operation.kind == "background_battle" then
		-- Resolution is owned by UpdateBackgroundBattles so a player can join
		-- without replacing the ongoing ambient battle with a scripted timer.
		if not operation.data or not operation.data.battle then
			G.ResolveOperation("neutral", "The local battle could no longer be tracked.")
			return
		end
	end
	G.BroadcastState()
end)

local function consoleAllowed(ply)
	return not IsValid(ply) or G.IsStaff(ply)
end

concommand.Add("mb_galaxy_special", function(ply, _, args)
	if not consoleAllowed(ply) then return end
	local kind = string.lower(tostring(args[1] or "rare"))
	local orbital = kind == "orbital_republic" or kind == "orbital_cis"
		or kind == "clear_orbital_blockade"
	if (G.Active or G.Operation) and not orbital then
		if IsValid(ply) then MilBase.Notify(ply, "Clear the active Galaxy event first.", "warn") end
		return
	end
	local result
	if kind == "convoy" then
		result = #G.SpawnCivilianConvoy() > 0
	elseif kind == "blockade" then
		result = G.StartBlockadeOperation(IsValid(ply) and ply or nil)
	elseif kind == "orbital_republic" then
		result = G.SetPlanetaryBlockade(G.State.currentPlanet, "republic", true,
			IsValid(ply) and ply or nil, "staff-created Republic blockade")
	elseif kind == "orbital_cis" then
		result = G.SetPlanetaryBlockade(G.State.currentPlanet, "cis", true,
			IsValid(ply) and ply or nil, "staff-created CIS occupation")
	elseif kind == "clear_orbital_blockade" then
		result = G.ClearPlanetaryBlockade(G.State.currentPlanet, IsValid(ply) and ply or nil)
	elseif kind == "wreckage" then
		local center = select(1, G.SkyboxFrame())
		result = IsValid(G.SpawnWreckageAt(center + VectorRand() * 220))
	elseif kind == "traffic" then
		result = G.SpawnAmbientTraffic() > 0
	elseif kind == "planet" or kind == "planettraffic" then
		result = G.SpawnPlanetTraffic() > 0
	elseif kind == "battle" then
		result = G.SpawnBackgroundBattle() > 0
	elseif kind == "beacon" or kind == "anomaly" or kind == "debris" then
		result = G.SpawnAmbientPhenomenon(kind) > 0
	else
		result = IsValid(G.SpawnRareContact())
	end
	if IsValid(ply) then
		MilBase.Notify(ply, result and "Special Galaxy contact created."
			or "The contact could not find a safe local approach.", result and "ok" or "warn")
	end
end)

concommand.Add("mb_galaxy_blockade", function(ply, _, args)
	if not consoleAllowed(ply) then return end
	local command = string.lower(tostring(args[1] or ""))
	local planet = G.CleanText(table.concat(args, " ", 2), 96)
	if planet == "" then planet = G.State.currentPlanet end
	local ok, message
	if command == "republic" or command == "cis" then
		ok, message = G.SetPlanetaryBlockade(planet, command, true,
			IsValid(ply) and ply or nil, "manual orbital blockade order")
	elseif command == "clear" or command == "remove" then
		ok, message = G.ClearPlanetaryBlockade(planet, IsValid(ply) and ply or nil)
	else
		ok, message = false, "Use republic, cis, or clear; optionally follow it with a planet name."
	end
	if IsValid(ply) then
		MilBase.Notify(ply, message, ok and "ok" or "warn")
	else
		MsgN("[Galaxy Director] " .. tostring(message))
	end
end)

concommand.Add("mb_galaxy_damage_system", function(ply, _, args)
	if not consoleAllowed(ply) then return end
	local category = string.lower(tostring(args[1] or "sensors"))
	local allowed = {
		sensors = true, communications = true, weapons = true, shields = true,
	}
	if not allowed[category] then return end
	G.DamageShipSystem(category, math.Clamp(tonumber(args[2]) or 25, 1, 100),
		"diagnostic test")
end)

concommand.Add("mb_galaxy_support_reset", function(ply)
	if not consoleAllowed(ply) then return end
	G.Support.charges = math.max(1, tonumber(gd.ReinforcementMaximum) or 3)
	G.Support.pending = nil
	G.Support.nextRecharge = unix()
		+ math.max(60, tonumber(gd.ReinforcementRechargeTime) or 1800)
	G.SaveExpansionState()
	G.BroadcastState()
end)

hook.Add("PostCleanupMap", "MilBase.GalaxyExpansionMapCleanup", function()
	G.Operation = nil
	G.ActiveRepublicFleet = nil
	G.PendingRepublicFleet = nil
	G.PendingScan = nil
	G.HailConversation = nil
	G.AftermathUntil = 0
	G.Wreckage = {}
	G.AmbientPhenomena = {}
	G.NextAmbientPhenomenonAt = 0
	G.NextAmbientCommsChatterAt = 0
	G.PlanetTrafficShips = {}
	G.NextPlanetTrafficAt = 0
	G.NextPersistentTrafficMaintenanceAt = 0
	for _, ship in pairs(G.UniverseTrafficEntities or {}) do
		if IsValid(ship) then ship:Remove() end
	end
	G.UniverseTrafficEntities = {}
	G.BackgroundBattles = {}
	G.NextBackgroundBattleAt = 0
	G.ActiveOrbitalBlockade = nil
	G.NextOrbitalBlockadeCheck = 0
	for category in pairs(G.SystemDisruption) do G.SystemDisruption[category] = 0 end
	timer.Simple(1, function()
		if G.State and G.State.ready then G.BroadcastState() end
	end)
end)

hook.Add("ShutDown", "MilBase.GalaxyExpansionShutdown", function()
	if G._expansionDatabaseInitializing then
		G.SaveExpansionState()
		G.SaveOrbitalBlockades()
		G.SaveUniverseTraffic()
		G.SaveTrackedUniverseTraffic()
		G.SaveLivingGalaxySimulation()
	end
end)
