--[[
	Advanced Jedi progression for MilBase x LSCS.

	Adds rank/alignment gates, active Force loadouts, presets, trials,
	Master-Padawan relationships, workbenches, holocrons, audit snapshots,
	rollback, and character/faction Force sensitivity.
]]

if MilBase._LSCSAdvancedLoaded then return end
MilBase._LSCSAdvancedLoaded = true

local cfg = MilBase.Config.LSCS or {}
if cfg.Enabled == false then return end

local MBLSCS = MilBase.LSCS
if not MBLSCS then return end

local PLAYER = FindMetaTable("Player")

local function advancedState(ply)
	if SERVER then
		return {
			alignment = ply.mb_lscsAlignment or 0,
			active = ply.mb_lscsActive or {},
			presets = ply.mb_lscsPresets or {},
			trials = ply.mb_lscsTrials or {},
			discoveries = ply.mb_lscsDiscoveries or {},
			lastRespec = ply.mb_lscsLastRespec or 0,
		}
	end
	if ply == LocalPlayer() then return MBLSCS.AdvancedState or {} end
	return {}
end

function PLAYER:MBLSCSAlignment()
	return self:GetNWInt("mb_lscs_alignment", 0)
end

function MBLSCS.AlignmentName(value)
	value = tonumber(value) or 0
	if value >= 60 then return "Light Side Paragon" end
	if value >= 20 then return "Light Side" end
	if value <= -60 then return "Dark Side Corrupted" end
	if value <= -20 then return "Dark Side" end
	return "Balanced"
end

function MBLSCS.ActiveCount(ply)
	local state = advancedState(ply)
	local count = 0
	for id, enabled in pairs(state.active or {}) do
		if enabled and MBLSCS.Nodes[id] and MBLSCS.Nodes[id].active then count = count + 1 end
	end
	return count
end

function MBLSCS.IsLoadoutClass(class)
	for _, id in ipairs(MBLSCS.ManagedItems[class] or {}) do
		if MBLSCS.Nodes[id] and MBLSCS.Nodes[id].active then return true end
	end
	return false
end

function MBLSCS.ShouldEquipClass(ply, class)
	local state = advancedState(ply)
	for _, id in ipairs(MBLSCS.ManagedItems[class] or {}) do
		local node = MBLSCS.Nodes[id]
		if node and node.active and state.active and state.active[id] then
			local allowed = MBLSCS.CanLearnAdvanced(ply, node)
			if allowed then return true end
		end
	end
	return false
end

function MBLSCS.CanLearnAdvanced(ply, node)
	if not IsValid(ply) or not node then return false, "Invalid Jedi profile" end
	if not ply:MBIsJedi() then return false, "Jedi faction required" end
	local state = advancedState(ply)
	local alignment = SERVER and (ply.mb_lscsAlignment or 0) or ply:MBLSCSAlignment()
	local level = ply:MBJediLevel()

	if node.minJediLevel and level < node.minJediLevel then
		local title = (cfg.JediLevels or {})[node.minJediLevel] or ("Jedi level " .. node.minJediLevel)
		return false, title .. " rank required"
	end
	if node.minAlignment and alignment < node.minAlignment then
		return false, "Requires Light alignment " .. node.minAlignment
	end
	if node.maxAlignment and alignment > node.maxAlignment then
		return false, "Requires Dark alignment " .. node.maxAlignment
	end
	if node.trial and not ((state.trials or {}).completed or {})[node.trial] then
		local trial = (cfg.Trials or {})[node.trial]
		return false, (trial and trial.name or node.trial) .. " required"
	end
	if node.holocron and not (state.discoveries or {})[node.holocron] then
		local holocron = (cfg.Holocrons or {})[node.holocron]
		return false, (holocron and holocron.name or node.holocron) .. " required"
	end
	return true
end

function MBLSCS.AdvancedRequirementsText(node)
	local result = {}
	if node.minJediLevel then
		result[#result + 1] = (cfg.JediLevels or {})[node.minJediLevel] or ("Jedi level " .. node.minJediLevel)
	end
	if node.minAlignment then result[#result + 1] = "Light alignment " .. node.minAlignment end
	if node.maxAlignment then result[#result + 1] = "Dark alignment " .. node.maxAlignment end
	if node.trial then
		local trial = (cfg.Trials or {})[node.trial]
		result[#result + 1] = trial and trial.name or node.trial
	end
	if node.holocron then
		local holocron = (cfg.Holocrons or {})[node.holocron]
		result[#result + 1] = holocron and holocron.name or node.holocron
	end
	if node.active then result[#result + 1] = "Uses one active Force slot" end
	return result
end

-- World entities ---------------------------------------------------------

local WORKBENCH = {
	Type = "anim", Base = "base_anim", PrintName = "Jedi Saber Workbench",
	Category = "MilBase", Spawnable = false, AdminOnly = true,
}

function WORKBENCH:Initialize()
	if not SERVER then return end
	self:SetModel(cfg.WorkbenchModel or "models/props_combine/combine_interface001.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then phys:EnableMotion(false) end
end

function WORKBENCH:Use(ply)
	if SERVER and IsValid(ply) and ply:IsPlayer() and MBLSCS.ActivateWorkbench then
		MBLSCS.ActivateWorkbench(ply, self)
	end
end

if CLIENT then
	function WORKBENCH:Draw()
		self:DrawModel()
		local pos = self:GetPos() + Vector(0, 0, self:OBBMaxs().z + 10)
		local ang = LocalPlayer():EyeAngles()
		ang:RotateAroundAxis(ang:Forward(), 90)
		ang:RotateAroundAxis(ang:Right(), 90)
		cam.Start3D2D(pos, Angle(0, ang.y, 90), 0.1)
			draw.SimpleTextOutlined("JEDI WORKBENCH", "MB.Tab", 0, 0, Color(100, 190, 255),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		cam.End3D2D()
	end
end

scripted_ents.Register(WORKBENCH, "mb_lscs_workbench")

local HOLOCRON = {
	Type = "anim", Base = "base_anim", PrintName = "Jedi Holocron",
	Category = "MilBase", Spawnable = false, AdminOnly = true,
}

function HOLOCRON:Initialize()
	if not SERVER then return end
	self:SetModel(cfg.HolocronModel or "models/props_lab/reciever01b.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then phys:EnableMotion(false) end
end

function HOLOCRON:SetHolocronID(id)
	self:SetNWString("mb_holocron_id", tostring(id or ""))
end

function HOLOCRON:GetHolocronID()
	return self:GetNWString("mb_holocron_id", "")
end

function HOLOCRON:Use(ply)
	if SERVER and IsValid(ply) and ply:IsPlayer() and MBLSCS.DiscoverHolocron then
		MBLSCS.DiscoverHolocron(ply, self:GetHolocronID())
	end
end

if CLIENT then
	function HOLOCRON:Draw()
		local def = (cfg.Holocrons or {})[self:GetHolocronID()] or {}
		local col = def.color or Color(120, 190, 255)
		render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
		self:DrawModel()
		render.SetColorModulation(1, 1, 1)
	end
end

scripted_ents.Register(HOLOCRON, "mb_lscs_holocron")

if CLIENT then return end

-- Persistence ------------------------------------------------------------

util.AddNetworkString("MilBase_LSCSAdvancedSync")
util.AddNetworkString("MilBase_LSCSAdvancedAction")
util.AddNetworkString("MilBase_LSCSMentorRequest")
util.AddNetworkString("MilBase_LSCSWorkbenchOpen")
util.AddNetworkString("MilBase_LSCSAdvancedAdmin")
util.AddNetworkString("MilBase_LSCSAdvancedAdminState")
util.AddNetworkString("MilBase_LSCSAuditRows")

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_lscs_advanced (
	steamid VARCHAR(32) PRIMARY KEY,
	alignment INTEGER,
	active_powers TEXT,
	presets TEXT,
	trials TEXT,
	discoveries TEXT,
	force_sensitive INTEGER,
	last_respec INTEGER
)]])

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_lscs_mentors (
	padawan VARCHAR(32) PRIMARY KEY,
	master VARCHAR(32),
	created INTEGER
)]])

MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_lscs_world ("
	.. "id " .. MilBase.DB.AutoIncPK() .. ", map_name VARCHAR(128), kind VARCHAR(32), data VARCHAR(128), "
	.. "x REAL, y REAL, z REAL, pitch REAL, yaw REAL, roll REAL )")

MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_lscs_audit ("
	.. "id " .. MilBase.DB.AutoIncPK() .. ", time INTEGER, actor_sid VARCHAR(32), actor_name VARCHAR(128), "
	.. "target_sid VARCHAR(32), action VARCHAR(255), before_state TEXT, after_state TEXT )")

local function decodeTable(raw, fallback)
	local decoded = util.JSONToTable(tostring(raw or ""))
	return istable(decoded) and decoded or (fallback or {})
end

local function cloneTable(value)
	return decodeTable(util.TableToJSON(value or {}), {})
end

local function normaliseAdvanced(ply)
	ply.mb_lscsAlignment = math.Clamp(math.floor(tonumber(ply.mb_lscsAlignment) or 0), -100, 100)
	ply.mb_lscsActive = istable(ply.mb_lscsActive) and ply.mb_lscsActive or {}
	ply.mb_lscsPresets = istable(ply.mb_lscsPresets) and ply.mb_lscsPresets or {}
	ply.mb_lscsTrials = istable(ply.mb_lscsTrials) and ply.mb_lscsTrials or {}
	ply.mb_lscsTrials.completed = istable(ply.mb_lscsTrials.completed) and ply.mb_lscsTrials.completed or {}
	ply.mb_lscsTrials.progress = istable(ply.mb_lscsTrials.progress) and ply.mb_lscsTrials.progress or {}
	ply.mb_lscsTrials.ready = istable(ply.mb_lscsTrials.ready) and ply.mb_lscsTrials.ready or {}
	ply.mb_lscsDiscoveries = istable(ply.mb_lscsDiscoveries) and ply.mb_lscsDiscoveries or {}
	ply.mb_lscsLastRespec = math.max(0, math.floor(tonumber(ply.mb_lscsLastRespec) or 0))
end

function MBLSCS.SyncAdvanced(ply)
	if not IsValid(ply) then return end
	normaliseAdvanced(ply)
	ply:SetNWInt("mb_lscs_alignment", ply.mb_lscsAlignment)
	ply:SetNWBool("mb_lscs_force_sensitive", ply.mb_lscsForceSensitive == true)
	ply:SetNWString("mb_lscs_mentor", ply.mb_lscsMentorSID or "")
	ply:SetNWString("mb_lscs_trial", ply.mb_lscsTrials.active or "")
	ply:SetNWInt("mb_lscs_trial_progress", tonumber(ply.mb_lscsTrials.progress[ply.mb_lscsTrials.active or ""]) or 0)
	local readyTrial = ""
	for id, ready in pairs(ply.mb_lscsTrials.ready or {}) do if ready then readyTrial = id break end end
	ply:SetNWString("mb_lscs_trial_ready", readyTrial)
	ply:SetNWBool("mb_lscs_advanced_loaded", ply.mb_lscsAdvancedLoaded == true)

	net.Start("MilBase_LSCSAdvancedSync")
		net.WriteTable({
			alignment = ply.mb_lscsAlignment,
			active = ply.mb_lscsActive,
			presets = ply.mb_lscsPresets,
			trials = ply.mb_lscsTrials,
			discoveries = ply.mb_lscsDiscoveries,
			lastRespec = ply.mb_lscsLastRespec,
			mentor = ply.mb_lscsMentorSID or "",
		})
	net.Send(ply)
end

MBLSCS.AdvancedSaves = MBLSCS.AdvancedSaves or {}

function MBLSCS.SaveAdvanced(ply)
	if not IsValid(ply) or not ply.mb_lscsAdvancedLoaded then return end
	normaliseAdvanced(ply)
	local sid64 = ply:MBCharacterKey()
	local query = string.format(
		"REPLACE INTO frontier_lscs_advanced (steamid, alignment, active_powers, presets, trials, discoveries, force_sensitive, last_respec) VALUES (%s, %d, %s, %s, %s, %s, %d, %d)",
		MilBase.SQLStr(sid64), ply.mb_lscsAlignment,
		MilBase.SQLStr(util.TableToJSON(ply.mb_lscsActive)),
		MilBase.SQLStr(util.TableToJSON(ply.mb_lscsPresets)),
		MilBase.SQLStr(util.TableToJSON(ply.mb_lscsTrials)),
		MilBase.SQLStr(util.TableToJSON(ply.mb_lscsDiscoveries)),
		ply.mb_lscsForceSensitive == true and 1 or 0, ply.mb_lscsLastRespec)
	local state = MBLSCS.AdvancedSaves[sid64] or { busy = false }
	MBLSCS.AdvancedSaves[sid64] = state
	state.pending = query
	if state.busy then return end

	local writeNext
	writeNext = function()
		local nextQuery = state.pending
		if not nextQuery then
			state.busy = false
			MBLSCS.AdvancedSaves[sid64] = nil
			return
		end
		state.pending = nil
		state.busy = true
		local function finished()
			state.busy = false
			writeNext()
		end
		MilBase.DB.Query(nextQuery, finished, finished)
	end
	writeNext()
end

function MBLSCS.EnsureActiveLoadout(ply)
	if not IsValid(ply) or not ply.mb_lscsAdvancedLoaded or not ply.mb_lscsProgressLoaded then return end
	if ply.mb_lscsNeedsLoadoutMigration and not ply.mb_fullyLoaded then return end
	local changed = false
	for id in pairs(ply.mb_lscsActive or {}) do
		local node = MBLSCS.Nodes[id]
		if not node or not node.active or not (ply.mb_lscsUnlocked or {})[id] then
			ply.mb_lscsActive[id] = nil
			changed = true
		end
	end
	if ply.mb_lscsNeedsLoadoutMigration and table.Count(ply.mb_lscsActive) == 0 then
		for _, id in ipairs(MBLSCS.NodeOrder) do
			local node = MBLSCS.Nodes[id]
			if node.active and (ply.mb_lscsUnlocked or {})[id]
			and MBLSCS.ActiveCount(ply) < (cfg.ForceSlots or 4) then
				local allowed = MBLSCS.CanLearnAdvanced(ply, node)
				if allowed then
					ply.mb_lscsActive[id] = true
					changed = true
				end
			end
		end
	end
	if ply.mb_lscsNeedsLoadoutMigration then
		ply.mb_lscsNeedsLoadoutMigration = nil
		changed = true
	end
	if changed then
		MBLSCS.SyncAdvanced(ply)
		MBLSCS.SaveAdvanced(ply)
	end
	MBLSCS.ReconcileItems(ply, false)
end

function MBLSCS.AutoEquipNode(ply, id)
	local node = MBLSCS.Nodes[id]
	if not IsValid(ply) or not ply.mb_lscsAdvancedLoaded or not node or not node.active then return end
	if not MBLSCS.AtWorkbench or not MBLSCS.AtWorkbench(ply) then return end
	if MBLSCS.ActiveCount(ply) >= (cfg.ForceSlots or 4) then return end
	local allowed = MBLSCS.CanLearnAdvanced(ply, node)
	if not allowed then return end
	ply.mb_lscsActive[id] = true
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
end

function MBLSCS.OnBaseProgressLoaded(ply)
	MBLSCS.EnsureActiveLoadout(ply)
end

function MBLSCS.LoadAdvanced(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	local sid = MilBase.SQLStr(key)
	MilBase.DB.Query("SELECT * FROM frontier_lscs_advanced WHERE steamid = " .. sid, function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		local row = rows[1]
		ply.mb_lscsAlignment = row and tonumber(row.alignment) or 0
		ply.mb_lscsActive = decodeTable(row and row.active_powers, {})
		ply.mb_lscsPresets = decodeTable(row and row.presets, {})
		ply.mb_lscsTrials = decodeTable(row and row.trials, {})
		ply.mb_lscsDiscoveries = decodeTable(row and row.discoveries, {})
		ply.mb_lscsForceSensitive = row and tonumber(row.force_sensitive) ~= 0 or false
		ply.mb_lscsLastRespec = row and tonumber(row.last_respec) or 0
		ply.mb_lscsNeedsLoadoutMigration = not row
		normaliseAdvanced(ply)

		MilBase.DB.Query("SELECT master FROM frontier_lscs_mentors WHERE padawan = " .. sid, function(mentorRows)
			if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			ply.mb_lscsMentorSID = mentorRows[1] and tostring(mentorRows[1].master or "") or ""
			ply.mb_lscsAdvancedLoaded = true
			MBLSCS.SyncAdvanced(ply)
			MBLSCS.EnsureActiveLoadout(ply)
			MBLSCS.ApplySkills(ply, false)
			if not row then MBLSCS.SaveAdvanced(ply) end
		end)
	end)
end

-- Audit snapshots --------------------------------------------------------

function MBLSCS.CaptureSnapshot(ply)
	if not IsValid(ply) then return {} end
	local inventory = {}
	if ply.lscsGetInventory and ply.lscsGetEquipped then
		local equipped = ply:lscsGetEquipped()
		for index, class in pairs(ply:lscsGetInventory()) do
			local state = -1
			if equipped[index] == true then state = 1 elseif equipped[index] == false then state = 0 end
			inventory[#inventory + 1] = {
				index = math.Clamp(math.floor(tonumber(index) or 1), 1, 127),
				class = string.sub(tostring(class or ""), 1, 128), equipped = state,
			}
		end
		table.sort(inventory, function(a, b) return a.index < b.index end)
	end
	return cloneTable({
		points = ply.mb_lscsPoints or 0,
		milestones = ply.mb_lscsMilestones or 0,
		unlocked = ply.mb_lscsUnlocked or {},
		access = ply.mb_lscsAccess ~= false,
		alignment = ply.mb_lscsAlignment or 0,
		active = ply.mb_lscsActive or {},
		presets = ply.mb_lscsPresets or {},
		trials = ply.mb_lscsTrials or {},
		discoveries = ply.mb_lscsDiscoveries or {},
		forceSensitive = ply.mb_lscsForceSensitive == true,
		lastRespec = ply.mb_lscsLastRespec or 0,
		mentor = ply.mb_lscsMentorSID or "",
		inventory = inventory,
	})
end

function MBLSCS.RecordAudit(actor, target, action, before)
	if not IsValid(target) then return end
	before = before or MBLSCS.CaptureSnapshot(target)
	local after = MBLSCS.CaptureSnapshot(target)
	local actorSID = IsValid(actor) and actor:SteamID64() or "SYSTEM"
	local actorName = IsValid(actor) and actor:MBName() or "SYSTEM"
	MilBase.DB.Insert(string.format(
		"INSERT INTO frontier_lscs_audit (time, actor_sid, actor_name, target_sid, action, before_state, after_state) VALUES (%d, %s, %s, %s, %s, %s, %s)",
		os.time(), MilBase.SQLStr(actorSID), MilBase.SQLStr(actorName), MilBase.SQLStr(target:MBCharacterKey()),
		MilBase.SQLStr(string.sub(tostring(action or "profile update"), 1, 255)),
		MilBase.SQLStr(util.TableToJSON(before)), MilBase.SQLStr(util.TableToJSON(after))), function()
			local keep = math.max(10, math.floor(tonumber(cfg.AuditRetention) or 50))
			MilBase.DB.Run("DELETE FROM frontier_lscs_audit WHERE target_sid = " .. MilBase.SQLStr(target:MBCharacterKey())
				.. " AND id NOT IN (SELECT id FROM (SELECT id FROM frontier_lscs_audit WHERE target_sid = "
				.. MilBase.SQLStr(target:MBCharacterKey()) .. " ORDER BY id DESC LIMIT " .. keep .. ") AS kept)")
	end)
end

local function saveMentor(ply)
	local sid = MilBase.SQLStr(ply:MBCharacterKey())
	if ply.mb_lscsMentorSID and ply.mb_lscsMentorSID ~= "" then
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_lscs_mentors (padawan, master, created) VALUES (%s, %s, %d)",
			sid, MilBase.SQLStr(ply.mb_lscsMentorSID), os.time()))
	else
		MilBase.DB.Run("DELETE FROM frontier_lscs_mentors WHERE padawan = " .. sid)
	end
end

function MBLSCS.ApplySnapshot(ply, snapshot)
	if not IsValid(ply) or not istable(snapshot) then return false end
	ply.mb_lscsPoints = math.Clamp(math.floor(tonumber(snapshot.points) or 0), 0, cfg.MaxPoints or 9999)
	ply.mb_lscsMilestones = math.max(0, math.floor(tonumber(snapshot.milestones) or 0))
	ply.mb_lscsUnlocked = istable(snapshot.unlocked) and snapshot.unlocked or {}
	ply.mb_lscsAccess = snapshot.access ~= false
	ply.mb_lscsAlignment = tonumber(snapshot.alignment) or 0
	ply.mb_lscsActive = istable(snapshot.active) and snapshot.active or {}
	ply.mb_lscsPresets = istable(snapshot.presets) and snapshot.presets or {}
	ply.mb_lscsTrials = istable(snapshot.trials) and snapshot.trials or {}
	ply.mb_lscsDiscoveries = istable(snapshot.discoveries) and snapshot.discoveries or {}
	ply.mb_lscsForceSensitive = snapshot.forceSensitive == true
	ply.mb_lscsLastRespec = tonumber(snapshot.lastRespec) or 0
	ply.mb_lscsMentorSID = tostring(snapshot.mentor or "")
	normaliseAdvanced(ply)
	saveMentor(ply)
	if istable(snapshot.inventory) and ply.lscsWipeInventory and ply.lscsAddInventory then
		ply.mb_lscsRestoring = true
		ply:lscsWipeInventory()
		for _, saved in ipairs(snapshot.inventory) do
			local class = tostring(saved.class or "")
			local equip
			if tonumber(saved.equipped) == 1 then equip = true elseif tonumber(saved.equipped) == 0 then equip = false end
			if class ~= "" and MBLSCS.ClassToItem(class) then
				ply:lscsAddInventory(class, equip, math.Clamp(math.floor(tonumber(saved.index) or 1), 1, 127))
			end
		end
		ply.mb_lscsRestoring = nil
		ply.mb_lscsInventoryRestored = true
		if ply.lscsSyncInventory then ply:lscsSyncInventory() end
	end
	if MBLSCS.SyncProgress then MBLSCS.SyncProgress(ply) end
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.ApplySkills(ply, false)
	MBLSCS.ReconcileItems(ply, true)
	if ply:MBLSCSAccess() then MBLSCS.TryCraftSaber(ply, true) end
	MBLSCS.SaveProgress(ply)
	MBLSCS.SaveAdvanced(ply)
	MBLSCS.QueueInventorySave(ply)
	return true
end

-- Alignment, trials, and discoveries -----------------------------------

function MBLSCS.AdjustAlignment(ply, amount, reason, actor)
	if not IsValid(ply) or not ply.mb_lscsAdvancedLoaded then return end
	amount = math.Clamp(math.floor(tonumber(amount) or 0), -100, 100)
	if amount == 0 then return end
	local before = MBLSCS.CaptureSnapshot(ply)
	local old = ply.mb_lscsAlignment or 0
	ply.mb_lscsAlignment = math.Clamp(old + amount, -100, 100)
	if ply.mb_lscsAlignment == old then return end
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
	MBLSCS.ApplySkills(ply, false)
	MBLSCS.ReconcileItems(ply, false)
	if actor ~= ply or math.abs(amount) >= 5 then
		MBLSCS.RecordAudit(actor, ply, reason or ("alignment " .. amount), before)
	end
end

local function completeTrial(ply, id, actor)
	local def = (cfg.Trials or {})[id]
	if not def or (ply.mb_lscsTrials.completed or {})[id] then return end
	local before = MBLSCS.CaptureSnapshot(ply)
	ply.mb_lscsTrials.completed[id] = os.time()
	ply.mb_lscsTrials.ready[id] = nil
	if ply.mb_lscsTrials.active == id then ply.mb_lscsTrials.active = nil end
	ply.mb_lscsAlignment = math.Clamp((ply.mb_lscsAlignment or 0) + (def.rewardAlignment or 0), -100, 100)
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
	MBLSCS.ApplySkills(ply, false)
	MBLSCS.RecordAudit(actor, ply, "completed " .. def.name, before)
	MilBase.Notify(ply, def.name .. " completed.")
end

function MBLSCS.TrialEvent(ply, eventName, key, amount)
	if not IsValid(ply) or not ply.mb_lscsAdvancedLoaded or not ply:MBIsJedi() then return end
	local id = ply.mb_lscsTrials.active
	local def = id and (cfg.Trials or {})[id] or nil
	if not def or def.event ~= eventName then return end
	if def.match and not def.match[key] then return end
	amount = math.max(1, math.floor(tonumber(amount) or 1))
	local progress = math.min(def.target or 1, (tonumber(ply.mb_lscsTrials.progress[id]) or 0) + amount)
	ply.mb_lscsTrials.progress[id] = progress
	if progress >= (def.target or 1) then
		if def.mentorApproval == false then
			completeTrial(ply, id)
		else
			ply.mb_lscsTrials.ready[id] = true
			ply.mb_lscsTrials.active = nil
			MilBase.Notify(ply, def.name .. " is ready for Master or staff approval.")
			for _, master in ipairs(player.GetAll()) do
				if master:MBCharacterKey() == (ply.mb_lscsMentorSID or "") then
					MilBase.Notify(master, ply:MBName() .. " is ready to complete " .. def.name .. ".")
				end
			end
		end
	end
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
end

function MBLSCS.DiscoverHolocron(ply, id)
	local def = (cfg.Holocrons or {})[id]
	if not def or not IsValid(ply) then return end
	if not ply:MBIsForceSensitive() then MilBase.Notify(ply, "The holocron remains silent.") return end
	if not ply.mb_lscsAdvancedLoaded then return end
	if ply.mb_lscsDiscoveries[id] then MilBase.Notify(ply, "You have already studied this holocron.") return end
	local before = MBLSCS.CaptureSnapshot(ply)
	ply.mb_lscsDiscoveries[id] = os.time()
	MBLSCS.TrialEvent(ply, "holocron", id, 1)
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
	MBLSCS.RecordAudit(ply, ply, "discovered " .. def.name, before)
	MilBase.Notify(ply, def.name .. " has been added to your Jedi profile.")
end

-- Workbench and presets --------------------------------------------------

function MBLSCS.AtWorkbench(ply)
	return IsValid(ply) and (ply.mb_lscsWorkbenchUntil or 0) > CurTime()
		and IsValid(ply.mb_lscsWorkbench) and ply.mb_lscsWorkbench:GetClass() == "mb_lscs_workbench"
		and ply:GetPos():DistToSqr(ply.mb_lscsWorkbench:GetPos()) <= 256 * 256
end

function MBLSCS.ActivateWorkbench(ply, entity)
	if not ply:MBIsForceSensitive() then MilBase.Notify(ply, "The Jedi controls do not respond to you.") return end
	ply.mb_lscsWorkbench = entity
	ply.mb_lscsWorkbenchUntil = CurTime() + (cfg.WorkbenchUseTime or 120)
	ply:SetNWFloat("mb_lscs_workbench_until", ply.mb_lscsWorkbenchUntil)
	net.Start("MilBase_LSCSWorkbenchOpen")
	net.Send(ply)
	MilBase.Notify(ply, ply:MBIsJedi() and "Jedi workbench access granted." or "Your Force potential is recorded, but Jedi training is required.")
end

local function inventoryIndexForClass(ply, class)
	if not ply.lscsGetInventory then return nil end
	for index, itemClass in pairs(ply:lscsGetInventory()) do
		if itemClass == class then return index end
	end
end

local function equippedSaberClasses(ply)
	local result = {}
	if not MBLSCS.IsInstalled() or not ply.lscsGetInventory or not ply.lscsGetEquipped then return result end
	local equipped = ply:lscsGetEquipped()
	for index, class in pairs(ply:lscsGetInventory()) do
		local item = MBLSCS.ClassToItem(class)
		if item and (item.type == "hilt" or item.type == "crystal") and isbool(equipped[index]) then
			local side = equipped[index] and "right" or "left"
			result[side .. (item.type == "hilt" and "Hilt" or "Crystal")] = class
		end
	end
	return result
end

local function equipSaberClass(ply, class, hand, wantedType)
	if not class or class == "" or not MBLSCS.IsInstalled() then return false end
	local item = MBLSCS.ClassToItem(class)
	local index = inventoryIndexForClass(ply, class)
	if not item or item.type ~= wantedType or not index or not ply.lscsEquipItem then return false end
	-- Stock LSCS never leaves two parts of one type equipped in the same hand;
	-- clear the slot first or lscsBuildPlayerInfo picks an arbitrary winner.
	if ply.lscsClearEquipped then ply:lscsClearEquipped(wantedType, hand) end
	ply:lscsEquipItem(index, hand)
	return true
end

local function validSaberClass(ply, class, wantedType)
	if not class or class == "" or not MBLSCS.IsInstalled() then return false end
	local item = MBLSCS.ClassToItem(class)
	return item and item.type == wantedType and inventoryIndexForClass(ply, class) ~= nil
end

local function loadPreset(ply, preset)
	if not istable(preset) then return false end
	ply.mb_lscsActive = {}
	for _, id in ipairs(preset.powers or {}) do
		local node = MBLSCS.Nodes[id]
		if node and node.active and (ply.mb_lscsUnlocked or {})[id]
		and MBLSCS.ActiveCount(ply) < (cfg.ForceSlots or 4)
		and MBLSCS.CanLearnAdvanced(ply, node) then
			ply.mb_lscsActive[id] = true
		end
	end
	if MBLSCS.AtWorkbench(ply) then
		-- Restore the preset's exact saber state: hands the preset stored as
		-- empty must end up empty, so clear both hands before re-equipping.
		if ply.lscsClearEquipped then
			ply:lscsClearEquipped("hilt")
			ply:lscsClearEquipped("crystal")
		end
		equipSaberClass(ply, preset.rightHilt, true, "hilt")
		equipSaberClass(ply, preset.rightCrystal, true, "crystal")
		equipSaberClass(ply, preset.leftHilt, false, "hilt")
		equipSaberClass(ply, preset.leftCrystal, false, "crystal")
		if not MBLSCS.TryCraftSaber(ply, true) then ply:StripWeapon("weapon_lscs") end
		MBLSCS.QueueInventorySave(ply)
	end
	MBLSCS.SyncAdvanced(ply)
	MBLSCS.SaveAdvanced(ply)
	MBLSCS.ReconcileItems(ply, false)
	return true
end

-- Mentorship -------------------------------------------------------------

local function setMentor(padawan, master)
	padawan.mb_lscsMentorSID = IsValid(master) and master:MBCharacterKey() or ""
	saveMentor(padawan)
	MBLSCS.SyncAdvanced(padawan)
	if IsValid(master) then MBLSCS.SyncAdvanced(master) end
end

local function canMaster(ply)
	return IsValid(ply) and ply:MBIsJedi() and ply:MBJediLevel() >= (cfg.MasterLevel or 4)
end

-- Player actions ---------------------------------------------------------

net.Receive("MilBase_LSCSAdvancedAction", function(_, ply)
	if (ply.mb_lscsNextAdvancedAction or 0) > CurTime() then return end
	ply.mb_lscsNextAdvancedAction = CurTime() + 0.2
	local action = string.sub(net.ReadString() or "", 1, 32)
	local target = net.ReadEntity()
	local arg = string.sub(net.ReadString() or "", 1, 1024)
	if not ply.mb_lscsAdvancedLoaded then return end

	if action == "toggle_power" then
		if not ply:MBLSCSAccess() then return end
		if not MBLSCS.AtWorkbench(ply) then MilBase.Notify(ply, "Use a Jedi workbench to change Force powers.") return end
		local node = MBLSCS.Nodes[arg]
		if not node or not node.active or not (ply.mb_lscsUnlocked or {})[arg] then return end
		if not ply.mb_lscsActive[arg] then
			local allowed, reason = MBLSCS.CanLearnAdvanced(ply, node)
			if not allowed then MilBase.Notify(ply, reason) return end
		end
		local before = MBLSCS.CaptureSnapshot(ply)
		if ply.mb_lscsActive[arg] then
			ply.mb_lscsActive[arg] = nil
		elseif MBLSCS.ActiveCount(ply) >= (cfg.ForceSlots or 4) then
			MilBase.Notify(ply, "All active Force slots are in use.") return
		else
			ply.mb_lscsActive[arg] = true
		end
		MBLSCS.SyncAdvanced(ply)
		MBLSCS.SaveAdvanced(ply)
		MBLSCS.ReconcileItems(ply, false)
		MBLSCS.RecordAudit(ply, ply, "changed active Force loadout", before)
	elseif action == "preset_save" then
		if not ply:MBLSCSAccess() then return end
		if not MBLSCS.AtWorkbench(ply) then MilBase.Notify(ply, "Use a Jedi workbench to save a preset.") return end
		local before = MBLSCS.CaptureSnapshot(ply)
		local slot, name = string.match(arg, "^(%d+)|(.+)$")
		slot = math.Clamp(math.floor(tonumber(slot) or 0), 1, cfg.PresetSlots or 3)
		name = string.sub(string.Trim(name or ("Preset " .. slot)), 1, 32)
		local powers = {}
		for _, id in ipairs(MBLSCS.NodeOrder) do if ply.mb_lscsActive[id] then powers[#powers + 1] = id end end
		local saber = equippedSaberClasses(ply)
		ply.mb_lscsPresets[tostring(slot)] = {
			name = name ~= "" and name or ("Preset " .. slot), powers = powers,
			rightHilt = saber.rightHilt, rightCrystal = saber.rightCrystal,
			leftHilt = saber.leftHilt, leftCrystal = saber.leftCrystal,
		}
		MBLSCS.SyncAdvanced(ply)
		MBLSCS.SaveAdvanced(ply)
		MBLSCS.RecordAudit(ply, ply, "saved Jedi preset " .. slot, before)
		MilBase.Notify(ply, "Saved Jedi preset " .. slot .. ".")
	elseif action == "preset_load" then
		if not ply:MBLSCSAccess() then return end
		if not MBLSCS.AtWorkbench(ply) then MilBase.Notify(ply, "Use a Jedi workbench to load a preset.") return end
		local before = MBLSCS.CaptureSnapshot(ply)
		local preset = ply.mb_lscsPresets[tostring(math.floor(tonumber(arg) or 0))]
		if not loadPreset(ply, preset) then MilBase.Notify(ply, "That preset is empty.") return end
		MBLSCS.RecordAudit(ply, ply, "loaded Jedi preset", before)
		MilBase.Notify(ply, "Jedi preset loaded.")
	elseif action == "craft" or action == "craft_hand" then
		if not ply:MBLSCSAccess() then return end
		if not MBLSCS.AtWorkbench(ply) then MilBase.Notify(ply, "Connect to a Jedi workbench before assembling a saber.") return end
		local before = MBLSCS.CaptureSnapshot(ply)
		local parts = string.Explode("|", arg)
		local hilt, crystal, side = parts[1], parts[2], parts[3]
		local hand = side == "left" and false or true
		if not validSaberClass(ply, hilt, "hilt") or not validSaberClass(ply, crystal, "crystal") then
			MilBase.Notify(ply, "Select a hilt and crystal from your LSCS inventory.") return
		end
		equipSaberClass(ply, hilt, hand, "hilt")
		equipSaberClass(ply, crystal, hand, "crystal")
		if MBLSCS.TryCraftSaber(ply, true) and ply:HasWeapon("weapon_lscs") then
			MBLSCS.QueueInventorySave(ply)
			MBLSCS.RecordAudit(ply, ply, "assembled " .. (hand and "right" or "left") .. "-hand lightsaber", before)
			MilBase.Notify(ply, (hand and "Right" or "Left") .. "-hand lightsaber assembled.")
		else
			MilBase.Notify(ply, "LSCS could not assemble that saber. Check the equipped parts and server console.")
		end
	elseif action == "clear_hand" then
		if not ply:MBLSCSAccess() then return end
		if not MBLSCS.AtWorkbench(ply) then MilBase.Notify(ply, "Connect to a Jedi workbench before changing your saber.") return end
		if not ply.lscsClearEquipped then return end
		local hand = arg ~= "left"
		local before = MBLSCS.CaptureSnapshot(ply)
		ply:lscsClearEquipped("hilt", hand)
		ply:lscsClearEquipped("crystal", hand)
		MBLSCS.TryCraftSaber(ply, true)
		MBLSCS.QueueInventorySave(ply)
		MBLSCS.RecordAudit(ply, ply, "cleared " .. (hand and "right" or "left") .. "-hand lightsaber", before)
		MilBase.Notify(ply, (hand and "Right" or "Left") .. "-hand saber slot cleared.")
	elseif action == "respec" then
		if not MBLSCS.AtWorkbench(ply) or not ply:MBLSCSAccess() then return end
		local remaining = (ply.mb_lscsLastRespec or 0) + (cfg.RespecCooldown or 21600) - os.time()
		if remaining > 0 then MilBase.Notify(ply, "Respec available in " .. math.ceil(remaining / 60) .. " minute(s).") return end
		local before = MBLSCS.CaptureSnapshot(ply)
		local refund = 0
		for id in pairs(ply.mb_lscsUnlocked or {}) do refund = refund + ((MBLSCS.Nodes[id] or {}).cost or 0) end
		ply.mb_lscsUnlocked = {}
		ply.mb_lscsActive = {}
		ply.mb_lscsPoints = math.Clamp((ply.mb_lscsPoints or 0) + refund, 0, cfg.MaxPoints or 9999)
		ply.mb_lscsLastRespec = os.time()
		if MBLSCS.SyncProgress then MBLSCS.SyncProgress(ply) end
		MBLSCS.SyncAdvanced(ply)
		MBLSCS.SaveProgress(ply)
		MBLSCS.SaveAdvanced(ply)
		MBLSCS.ApplySkills(ply, false)
		MBLSCS.ReconcileItems(ply, true)
		MBLSCS.RecordAudit(ply, ply, "self-respec with " .. refund .. " points refunded", before)
		MilBase.Notify(ply, "Skill tree reset; " .. refund .. " point(s) refunded.")
	elseif action == "trial_start" then
		local def = (cfg.Trials or {})[arg]
		if not def or not ply:MBIsJedi() or ply:MBJediLevel() < (def.minLevel or 1) then return end
		if ply.mb_lscsTrials.completed[arg] then MilBase.Notify(ply, "That trial is already complete.") return end
		ply.mb_lscsTrials.active = arg
		ply.mb_lscsTrials.progress[arg] = tonumber(ply.mb_lscsTrials.progress[arg]) or 0
		if def.event == "holocron" then ply.mb_lscsTrials.progress[arg] = table.Count(ply.mb_lscsDiscoveries) end
		MBLSCS.SyncAdvanced(ply)
		MBLSCS.SaveAdvanced(ply)
		MilBase.Notify(ply, def.name .. " started.")
		if ply.mb_lscsTrials.progress[arg] >= (def.target or 1) then MBLSCS.TrialEvent(ply, def.event, "", 1) end
	elseif action == "mentor_request" then
		if not IsValid(target) or not canMaster(target) or not ply:MBIsJedi() then return end
		if ply:MBJediLevel() > (cfg.PadawanMaxLevel or 2) then MilBase.Notify(ply, "Only Initiates and Padawans may request a Master.") return end
		if (ply.mb_lscsMentorSID or "") ~= "" then MilBase.Notify(ply, "You already have a Master.") return end
		target.mb_lscsMentorRequests = target.mb_lscsMentorRequests or {}
		target.mb_lscsMentorRequests[ply:MBCharacterKey()] = CurTime() + 60
		net.Start("MilBase_LSCSMentorRequest") net.WriteEntity(ply) net.Send(target)
		MilBase.Notify(ply, "Mentorship request sent to " .. target:MBName() .. ".")
	elseif action == "mentor_accept" then
		if not IsValid(target) or not canMaster(ply) then return end
		local expires = (ply.mb_lscsMentorRequests or {})[target:MBCharacterKey()] or 0
		if expires < CurTime() or target:MBJediLevel() > (cfg.PadawanMaxLevel or 2) then return end
		if (target.mb_lscsMentorSID or "") ~= "" then MilBase.Notify(ply, "That Jedi already has a Master.") return end
		local before = MBLSCS.CaptureSnapshot(target)
		setMentor(target, ply)
		ply.mb_lscsMentorRequests[target:MBCharacterKey()] = nil
		MBLSCS.RecordAudit(ply, target, "accepted Master-Padawan bond", before)
		MilBase.Notify(ply, target:MBName() .. " is now your Padawan.")
		MilBase.Notify(target, ply:MBName() .. " has accepted you as a Padawan.")
	elseif action == "mentor_decline" then
		if IsValid(target) and ply.mb_lscsMentorRequests then ply.mb_lscsMentorRequests[target:MBCharacterKey()] = nil end
	elseif action == "mentor_end" then
		local padawan = IsValid(target) and target or ply
		local permitted = padawan == ply or padawan.mb_lscsMentorSID == ply:MBCharacterKey()
		if not permitted then return end
		local before = MBLSCS.CaptureSnapshot(padawan)
		setMentor(padawan)
		MBLSCS.RecordAudit(ply, padawan, "ended Master-Padawan bond", before)
		MilBase.Notify(padawan, "The Master-Padawan bond has ended.")
	elseif action == "trial_approve" then
		if not IsValid(target) or not target.mb_lscsAdvancedLoaded or not target.mb_lscsTrials then return end
		local permitted = canMaster(ply) and target.mb_lscsMentorSID == ply:MBCharacterKey()
		if not permitted or not (target.mb_lscsTrials.ready or {})[arg] then return end
		completeTrial(target, arg, ply)
	end
end)

-- LSCS enforcement and progression events -------------------------------

hook.Add("LSCS:OnPlayerForceUse", "MilBase.LSCSAdvancedLoadout", function(ply, _, item)
	if not IsValid(ply) or not ply:MBLSCSAccess() then return false end
	local class = istable(item) and item.class or tostring(item or "")
	local nodeID
	for _, id in ipairs(MBLSCS.ManagedItems[class] or {}) do
		if MBLSCS.Nodes[id] and MBLSCS.Nodes[id].active then nodeID = id break end
	end
	if nodeID then
		if not (ply.mb_lscsActive or {})[nodeID] then
			if (ply.mb_lscsNextLoadoutNotice or 0) < CurTime() then
				ply.mb_lscsNextLoadoutNotice = CurTime() + 2
				MilBase.Notify(ply, "That power is not in your active Force loadout.")
			end
			return false
		end
		local allowed, reason = MBLSCS.CanLearnAdvanced(ply, MBLSCS.Nodes[nodeID])
		if not allowed then MilBase.Notify(ply, reason) return false end
	elseif istable(item) and item.type == "force" and cfg.AllowUnmanagedForcePowers ~= true then
		MilBase.Notify(ply, "That Force power is not registered in the MilBase skill tree.")
		return false
	end

	ply.mb_lscsAlignmentCooldowns = ply.mb_lscsAlignmentCooldowns or {}
	local shift = tonumber((cfg.PowerAlignmentShift or {})[class]) or 0
	if shift ~= 0 and (ply.mb_lscsAlignmentCooldowns[class] or 0) <= CurTime() then
		ply.mb_lscsAlignmentCooldowns[class] = CurTime() + 5
		MBLSCS.AdjustAlignment(ply, shift, "used " .. class, ply)
	end
	MBLSCS.TrialEvent(ply, "force_use", class, 1)
end)

local function repairExternalLoadoutChange(ply, item)
	if not IsValid(ply) or ply.mb_lscsReconciling or not item or item.type ~= "force" then return end
	if not MBLSCS.IsLoadoutClass(item.class or "") then return end
	timer.Simple(0, function()
		if IsValid(ply) then MBLSCS.ReconcileItems(ply, false) end
	end)
end

hook.Add("LSCS:OnPlayerEquippedItem", "MilBase.LSCSAdvancedEquipGuard", repairExternalLoadoutChange)
hook.Add("LSCS:OnPlayerUnEquippedItem", "MilBase.LSCSAdvancedUnequipGuard", repairExternalLoadoutChange)

hook.Add("EntityTakeDamage", "MilBase.LSCSTrialSaberHits", function(target, dmg)
	local attacker = dmg:GetAttacker()
	if not IsValid(attacker) or not attacker:IsPlayer() or not attacker:MBLSCSAccess() then return end
	if not MBLSCS.IsSaberDamage(dmg) then return end
	if (attacker.mb_lscsNextTrialHit or 0) > CurTime() then return end
	attacker.mb_lscsNextTrialHit = CurTime() + 0.15
	MBLSCS.TrialEvent(attacker, "saber_hit", "", 1)
end)

-- Persistent world placement --------------------------------------------

MBLSCS.WorldEntities = MBLSCS.WorldEntities or {}

local function spawnWorldEntity(kind, data, pos, ang, id)
	local class = kind == "holocron" and "mb_lscs_holocron" or "mb_lscs_workbench"
	local ent = ents.Create(class)
	if not IsValid(ent) then return end
	ent:SetPos(pos)
	ent:SetAngles(ang)
	if class == "mb_lscs_holocron" then ent:SetHolocronID(data) end
	ent:Spawn()
	ent:Activate()
	ent.mb_lscsWorldID = tonumber(id)
	MBLSCS.WorldEntities[#MBLSCS.WorldEntities + 1] = ent
	return ent
end

function MBLSCS.LoadWorldEntities()
	for _, ent in ipairs(MBLSCS.WorldEntities) do if IsValid(ent) then ent:Remove() end end
	MBLSCS.WorldEntities = {}
	MilBase.DB.Query("SELECT * FROM frontier_lscs_world WHERE map_name = " .. MilBase.SQLStr(game.GetMap()), function(rows)
		for _, row in ipairs(rows) do
			spawnWorldEntity(row.kind, row.data,
				Vector(tonumber(row.x) or 0, tonumber(row.y) or 0, tonumber(row.z) or 0),
				Angle(tonumber(row.pitch) or 0, tonumber(row.yaw) or 0, tonumber(row.roll) or 0), row.id)
		end
	end)
end

hook.Add("InitPostEntity", "MilBase.LSCSWorldLoad", function() timer.Simple(1, MBLSCS.LoadWorldEntities) end)
hook.Add("PostCleanupMap", "MilBase.LSCSWorldReload", function() timer.Simple(1, MBLSCS.LoadWorldEntities) end)

local function canPlaceWorld(ply)
	return IsValid(ply) and (ply:IsListenServerHost() or ply:MBStaffLevel() >= (cfg.AdminLevel or 3))
end

local function placeWorld(ply, kind, data)
	if not canPlaceWorld(ply) then MilBase.Notify(ply, "You do not have permission to place Jedi objects.") return end
	local tr = ply:GetEyeTrace()
	local pos = tr.HitPos + tr.HitNormal * 8
	local ang = Angle(0, ply:EyeAngles().y + 180, 0)
	MilBase.DB.Insert(string.format(
		"INSERT INTO frontier_lscs_world (map_name, kind, data, x, y, z, pitch, yaw, roll) VALUES (%s, %s, %s, %.4f, %.4f, %.4f, %.4f, %.4f, %.4f)",
		MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(kind), MilBase.SQLStr(data or ""),
		pos.x, pos.y, pos.z, ang.p, ang.y, ang.r), function(id)
			if IsValid(ply) then
				spawnWorldEntity(kind, data, pos, ang, id)
				MilBase.Notify(ply, kind == "holocron" and "Persistent holocron placed." or "Persistent Jedi workbench placed.")
			end
	end)
end

MilBase.RegisterChatCommand("jediworkbench", {
	help = "(Staff) Place a persistent Jedi workbench where you are aiming.",
	func = function(ply) placeWorld(ply, "workbench", "") end,
})

MilBase.RegisterChatCommand("jediholocron", {
	help = "(Staff) Place a persistent holocron: /jediholocron <guardian|consular|sentinel|shadow>",
	func = function(ply, args)
		if not canPlaceWorld(ply) then MilBase.Notify(ply, "You do not have permission to place Jedi objects.") return end
		local id = string.lower(args[1] or "")
		if not (cfg.Holocrons or {})[id] then MilBase.Notify(ply, "Unknown holocron id.") return end
		placeWorld(ply, "holocron", id)
	end,
})

MilBase.RegisterChatCommand("jediclearworld", {
	help = "(Staff) Remove all persistent Jedi workbenches and holocrons on this map.",
	func = function(ply)
		if not canPlaceWorld(ply) then MilBase.Notify(ply, "You do not have permission to remove Jedi objects.") return end
		MilBase.DB.Run("DELETE FROM frontier_lscs_world WHERE map_name = " .. MilBase.SQLStr(game.GetMap()))
		for _, ent in ipairs(MBLSCS.WorldEntities) do if IsValid(ent) then ent:Remove() end end
		MBLSCS.WorldEntities = {}
		MilBase.Notify(ply, "Cleared persistent Jedi world objects for this map.")
	end,
})

MilBase.RegisterChatCommand("jediremoveworld", {
	help = "(Staff) Permanently remove the Jedi workbench or holocron you are aiming at.",
	func = function(ply)
		if not canPlaceWorld(ply) then MilBase.Notify(ply, "You do not have permission to remove Jedi objects.") return end
		local ent = ply:GetEyeTrace().Entity
		if not IsValid(ent) or not ent.mb_lscsWorldID then MilBase.Notify(ply, "Aim at a persistent Jedi world object.") return end
		if ent:GetClass() ~= "mb_lscs_workbench" and ent:GetClass() ~= "mb_lscs_holocron" then return end
		MilBase.DB.Run("DELETE FROM frontier_lscs_world WHERE id = " .. math.floor(ent.mb_lscsWorldID))
		ent:Remove()
		MilBase.Notify(ply, "Persistent Jedi world object removed.")
	end,
})

-- Staff management and rollback ----------------------------------------

local function canAdmin(actor)
	return IsValid(actor) and (actor:IsListenServerHost() or actor:MBStaffLevel() >= (cfg.AdminLevel or 3))
end

local function canAdminTarget(actor, target)
	return actor:IsListenServerHost() or actor == target or target:MBStaffLevel() < actor:MBStaffLevel()
end

local function sendAuditRows(actor, target)
	MilBase.DB.Query("SELECT id, time, actor_name, action FROM frontier_lscs_audit WHERE target_sid = "
		.. MilBase.SQLStr(target:MBCharacterKey()) .. " ORDER BY id DESC LIMIT "
		.. math.max(10, math.floor(tonumber(cfg.AuditRetention) or 50)), function(rows)
		if not IsValid(actor) then return end
		net.Start("MilBase_LSCSAuditRows") net.WriteEntity(target) net.WriteTable(rows or {}) net.Send(actor)
	end)
end

local function sendAdminState(actor, target)
	if not canAdmin(actor) or not IsValid(target) then return end
	net.Start("MilBase_LSCSAdvancedAdminState")
		net.WriteEntity(target)
		net.WriteTable({
			alignment = target.mb_lscsAlignment or 0,
			forceSensitive = target.mb_lscsForceSensitive == true,
			jedi = target:MBIsJedi(), level = target:MBJediLevel(),
			mentor = target.mb_lscsMentorSID or "",
			trials = target.mb_lscsTrials or {}, discoveries = target.mb_lscsDiscoveries or {},
			active = target.mb_lscsActive or {}, lastRespec = target.mb_lscsLastRespec or 0,
		})
	net.Send(actor)
	sendAuditRows(actor, target)
end

net.Receive("MilBase_LSCSAdvancedAdmin", function(_, actor)
	if not canAdmin(actor) or (actor.mb_lscsNextAdvancedAdmin or 0) > CurTime() then return end
	actor.mb_lscsNextAdvancedAdmin = CurTime() + 0.2
	local action = string.sub(net.ReadString() or "", 1, 32)
	local target = net.ReadEntity()
	local arg = string.sub(net.ReadString() or "", 1, 128)
	if not IsValid(target) or not target:IsPlayer() then return end
	if action == "request" then sendAdminState(actor, target) return end
	if not canAdminTarget(actor, target) or not target.mb_lscsAdvancedLoaded then return end

	local before = MBLSCS.CaptureSnapshot(target)
	if action == "alignment_add" then
		target.mb_lscsAlignment = math.Clamp((target.mb_lscsAlignment or 0) + math.Clamp(tonumber(arg) or 0, -100, 100), -100, 100)
	elseif action == "alignment_set" then
		target.mb_lscsAlignment = math.Clamp(math.floor(tonumber(arg) or 0), -100, 100)
	elseif action == "sensitive" then
		target.mb_lscsForceSensitive = arg == "1"
	elseif action == "trial_start" then
		local def = (cfg.Trials or {})[arg]
		if not def then return end
		target.mb_lscsTrials.completed[arg] = nil
		target.mb_lscsTrials.ready[arg] = nil
		target.mb_lscsTrials.progress[arg] = 0
		target.mb_lscsTrials.active = arg
	elseif action == "trial_complete" then
		if (cfg.Trials or {})[arg] then completeTrial(target, arg, actor) sendAdminState(actor, target) return end
	elseif action == "trial_reset" then
		if not (cfg.Trials or {})[arg] then return end
		target.mb_lscsTrials.completed[arg] = nil
		target.mb_lscsTrials.ready[arg] = nil
		target.mb_lscsTrials.progress[arg] = nil
		if target.mb_lscsTrials.active == arg then target.mb_lscsTrials.active = nil end
	elseif action == "mentor_end" then
		setMentor(target)
	elseif action == "respec_ready" then
		target.mb_lscsLastRespec = 0
	elseif action == "rollback" then
		local auditID = math.max(0, math.floor(tonumber(arg) or 0))
		MilBase.DB.Query("SELECT before_state FROM frontier_lscs_audit WHERE id = " .. auditID
			.. " AND target_sid = " .. MilBase.SQLStr(target:MBCharacterKey()) .. " LIMIT 1", function(rows)
			if not IsValid(actor) or not IsValid(target) or not rows[1] then return end
			local rollbackBefore = MBLSCS.CaptureSnapshot(target)
			local snapshot = decodeTable(rows[1].before_state, nil)
			if MBLSCS.ApplySnapshot(target, snapshot) then
				MBLSCS.RecordAudit(actor, target, "rolled back audit #" .. auditID, rollbackBefore)
				MilBase.Notify(actor, "Jedi profile rolled back.")
				if actor ~= target then MilBase.Notify(target, "Your Jedi profile was rolled back by staff.") end
				sendAdminState(actor, target)
			end
		end)
		return
	else
		return
	end

	MBLSCS.SyncAdvanced(target)
	MBLSCS.SaveAdvanced(target)
	MBLSCS.ApplySkills(target, false)
	MBLSCS.ReconcileItems(target, false)
	MBLSCS.RecordAudit(actor, target, action, before)
	if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " changed Jedi profile " .. action .. " for " .. MilBase.LogTag(target), actor, target) end
	MilBase.Notify(actor, "Jedi profile updated: " .. string.Replace(action, "_", " ") .. ".")
	if actor ~= target then MilBase.Notify(target, "Your Jedi profile was updated by staff.") end
	sendAdminState(actor, target)
end)

hook.Add("PlayerInitialSpawn", "MilBase.LSCSAdvancedLoad", function(ply)
	ply:SetNWBool("mb_lscs_advanced_loaded", false)
	MBLSCS.LoadAdvanced(ply)
end)

hook.Add("MilBase.PlayerLoaded", "MilBase.LSCSAdvancedFactionReady", function(ply)
	timer.Simple(0, function()
		if not IsValid(ply) then return end
		if ply.mb_lscsAdvancedLoaded then
			MBLSCS.SyncAdvanced(ply)
			MBLSCS.EnsureActiveLoadout(ply)
		end
		MBLSCS.ApplySkills(ply, true)
		MBLSCS.ReconcileItems(ply, false)
	end)
end)

hook.Add("PlayerDisconnected", "MilBase.LSCSAdvancedSave", function(ply)
	MBLSCS.SaveAdvanced(ply)
end)

hook.Add("ShutDown", "MilBase.LSCSAdvancedSaveAll", function()
	for _, ply in ipairs(player.GetAll()) do MBLSCS.SaveAdvanced(ply) end
end)
