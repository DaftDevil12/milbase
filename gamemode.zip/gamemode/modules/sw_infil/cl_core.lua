surface.CreateFont("SWInfil_Title", {
    font = "Roboto Condensed",
    size = 28,
    weight = 800,
    extended = true
})

surface.CreateFont("SWInfil_Small", {
    font = "Roboto Condensed",
    size = 18,
    weight = 500,
    extended = true
})

surface.CreateFont("SWInfil_Prompt", {
    font = "Roboto Condensed",
    size = 42,
    weight = 900,
    extended = true
})

local function replicatedFloat(name, fallback)
    local convar = GetConVar(name)
    if not convar then return fallback end
    return convar:GetFloat()
end

local function replicatedBool(name, fallback)
    local convar = GetConVar(name)
    if not convar then return fallback end
    return convar:GetBool()
end

local function cameraOffset()
    return Vector(
        replicatedFloat("sw_infil_camera_forward", SWInfil.CameraOffset.x),
        replicatedFloat("sw_infil_camera_right", SWInfil.CameraOffset.y),
        replicatedFloat("sw_infil_camera_up", SWInfil.CameraOffset.z)
    )
end

local function bodyOffset()
    return Vector(0, 0, replicatedFloat("sw_infil_anchor_up", SWInfil.RideAnchorOffset.z))
end

net.Receive("sw_infil_seats_sync", function()
    local count = net.ReadUInt(6)
    local seats = {}

    for index = 1, count do
        seats[index] = {
            pos = net.ReadVector(),
            ang = net.ReadAngle()
        }
    end

    SWInfil.Seats = seats
end)

net.Receive("sw_infil_skybox_begin", function()
    SWInfil.SkyboxState = {
        entryPos = net.ReadVector(),
        entryAng = net.ReadAngle(),
        started = net.ReadFloat(),
        duration = net.ReadFloat(),
        model = net.ReadString(),
        prompt = net.ReadString(),
        skyStartPos = net.ReadVector(),
        skyStartAng = net.ReadAngle(),
        skyMidPos = net.ReadVector(),
        skyMidAng = net.ReadAngle(),
        skyFinishPos = net.ReadVector(),
        skyFinishAng = net.ReadAngle(),
        customSkybox = net.ReadBool()
    }
end)

net.Receive("sw_infil_skybox_end", function()
    SWInfil.SkyboxState = nil
end)

SWInfil.SpawnRoutes = SWInfil.SpawnRoutes or {}

net.Receive("sw_infil_spawns_sync", function()
    local count = net.ReadUInt(6)
    local routes = {}

    for index = 1, count do
        routes[index] = {
            id = net.ReadString(),
            name = net.ReadString(),
            startPos = net.ReadVector(),
            startAng = net.ReadAngle(),
            landPos = net.ReadVector(),
            landAng = net.ReadAngle()
        }
    end

    SWInfil.SpawnRoutes = routes
end)

local spawnMenuFrame

local function selectSpawnPreview(route)
    SWInfil.SpawnPreviewRoute = route
end

local function sendSpawnSelection(routeID)
    net.Start("sw_infil_spawn_select")
        net.WriteString(routeID or "")
    net.SendToServer()
end

local function closeSpawnMenu(sendCancel)
    if IsValid(spawnMenuFrame) then
        spawnMenuFrame.SWInfilClosing = true
        spawnMenuFrame:Close()
    end

    spawnMenuFrame = nil
    SWInfil.SpawnMenuOpen = false
    SWInfil.SpawnPreviewRoute = nil

    if sendCancel then
        sendSpawnSelection("cancel")
    end
end

local function spawnPreviewView(fov)
    local route = SWInfil.SpawnPreviewRoute
    if not route then return nil end

    local landPos = route.landPos or vector_origin
    local landAng = route.landAng or angle_zero
    local cameraPos = landPos
        - landAng:Forward() * 720
        + landAng:Right() * 360
        + Vector(0, 0, 300)
    local lookTarget = landPos + Vector(0, 0, 40)

    return {
        origin = cameraPos,
        angles = (lookTarget - cameraPos):Angle(),
        fov = math.Clamp((fov or 75) + 8, 75, 95),
        drawviewer = false
    }
end

local fallbackUI = {
    bg = Color(6, 6, 7, 240),
    panel = Color(10, 10, 11, 215),
    raised = Color(255, 198, 60, 10),
    hover = Color(255, 198, 60, 25),
    outline = Color(255, 198, 60, 50),
    accent = Color(255, 198, 60),
    text = Color(240, 238, 230),
    dim = Color(170, 162, 140),
    faint = Color(112, 106, 92),
    ok = Color(150, 205, 125),
    danger = Color(220, 80, 70)
}

local function hasMilBaseUI()
    return MilBase and MilBase.UI and MilBase.DrawPanelBF2 and MilBase.DrawBrackets and MilBase.DrawIcon
end

local function swUI()
    return (MilBase and MilBase.UI) or fallbackUI
end

local function uiColor(color, alpha)
    if not color then return Color(255, 255, 255, alpha or 255) end
    return Color(color.r, color.g, color.b, alpha or color.a or 255)
end

local function uiFont(milbaseFont, fallbackFont)
    return hasMilBaseUI() and milbaseFont or fallbackFont
end

local function playUISound(id)
    if MilBase and MilBase.PlayUISound then
        MilBase.PlayUISound(id)
    elseif id == "select" then
        surface.PlaySound("ui/buttonclickrelease.wav")
    elseif id == "hover" then
        surface.PlaySound("ui/buttonrollover.wav")
    end
end

local function drawDeploymentPanel(x, y, w, h, opts)
    opts = opts or {}

    if hasMilBaseUI() then
        MilBase.DrawPanelBF2(x, y, w, h, opts)
        return
    end

    surface.SetDrawColor(opts.color or fallbackUI.panel)
    surface.DrawRect(x, y, w, h)

    if opts.outline ~= false then
        surface.SetDrawColor(opts.outlineColor or fallbackUI.outline)
        surface.DrawOutlinedRect(x, y, w, h)
    end

    if opts.accent then
        surface.SetDrawColor(opts.accent)
        surface.DrawRect(x, y, 3, h)
    end
end

local function paintDeploymentButton(self, w, h, label, accent, font)
    local ui = swUI()
    local hovered = self:IsHovered()
    local enabled = self:IsEnabled()
    local fill = enabled and ui.raised or Color(255, 255, 255, 4)

    if hovered and enabled then
        fill = uiColor(accent or ui.accent, 46)
    end

    drawDeploymentPanel(0, 0, w, h, {
        cut = 8,
        color = fill,
        accent = enabled and (accent or ui.accent) or nil
    })

    if hovered and enabled and hasMilBaseUI() then
        MilBase.DrawBrackets(3, 3, w - 6, h - 6, accent or ui.accent, 9)
    end

    draw.SimpleText(label, font or uiFont("MB.Tab", "SWInfil_Title"), w / 2, h / 2 - 1,
        enabled and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function openSpawnMenu()
    local routes = SWInfil.SpawnRoutes or {}
    if #routes <= 0 then
        chat.AddText(Color(255, 120, 90), "[LAAT Infil] No LAAT spawn routes are configured.")
        return
    end

    closeSpawnMenu(false)

    SWInfil.SpawnMenuOpen = true
    selectSpawnPreview(routes[1])

    local ui = swUI()
    local margin = math.floor(ScrW() * 0.055)
    local sidebarW = math.min(470, math.max(390, math.floor(ScrW() * 0.34)))
    local bottomH = 44

    local frame = vgui.Create("DFrame")
    spawnMenuFrame = frame
    frame:SetSize(ScrW(), ScrH())
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame.Paint = function(self, w, h)
        if hasMilBaseUI() then
            if not MilBase.DrawIcon(ui.art and ui.art.scoreboard, 0, 0, w, h) then
                if MilBase.DrawBlur then
                    MilBase.DrawBlur(self, 6)
                end
            end
        else
            surface.SetDrawColor(0, 0, 0, 220)
            surface.DrawRect(0, 0, w, h)
        end

        surface.SetDrawColor(0, 0, 0, 168)
        surface.DrawRect(0, 0, w, h)

        drawDeploymentPanel(margin, 24, sidebarW, h - 24 - bottomH - 14, {
            cut = 10,
            color = Color(8, 8, 9, 224),
            accent = ui.accent
        })

        if hasMilBaseUI() and ui.art and ui.art.bf2 then
            MilBase.DrawIcon(ui.art.bf2.hex, margin + 18, 46, 15, 15, ui.accent)
            MilBase.DrawIcon(ui.art.bf2.underline, margin + 18, 98, sidebarW - 36, 16)
        end

        draw.SimpleText("LAAT DEPLOYMENT", uiFont("MB.Huge", "SWInfil_Prompt"),
            margin + 42, 33, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("SELECT INSERTION ZONE", uiFont("MB.Small", "SWInfil_Small"),
            margin + 22, 94, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Camera feed previews the selected landing area.", uiFont("MB.Tiny", "SWInfil_Small"),
            margin + 22, 116, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        local route = SWInfil.SpawnPreviewRoute
        local cardW = math.min(520, math.floor(w * 0.36))
        local cardH = 108
        local cardX = w - margin - cardW
        local cardY = h - bottomH - cardH - 26

        drawDeploymentPanel(cardX, cardY, cardW, cardH, {
            cut = 10,
            color = Color(6, 6, 7, 178),
            accent = ui.accent
        })

        if route then
            draw.SimpleText("ACTIVE CAMERA", uiFont("MB.Tiny", "SWInfil_Small"),
                cardX + 18, cardY + 15, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText(string.upper(route.name or route.id or "LANDING ZONE"), uiFont("MB.Big", "SWInfil_Title"),
                cardX + 18, cardY + 34, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("LZ ID: " .. string.upper(route.id or "spawn"), uiFont("MB.Small", "SWInfil_Small"),
                cardX + 18, cardY + 72, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        else
            draw.SimpleText("NO LANDING ZONE SELECTED", uiFont("MB.Big", "SWInfil_Title"),
                cardX + 18, cardY + 37, ui.danger, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end

        surface.SetDrawColor(0, 0, 0, 178)
        surface.DrawRect(0, h - bottomH, w, bottomH)
        surface.SetDrawColor(uiColor(ui.accent, 70))
        surface.DrawRect(0, h - bottomH, w, 1)

        draw.SimpleText("ESC / SPAWN NORMALLY cancels LAAT insertion", uiFont("MB.Tiny", "SWInfil_Small"),
            margin + 18, h - bottomH / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    frame.OnClose = function(self)
        if not self.SWInfilClosing then
            closeSpawnMenu(true)
        end
    end
    frame.Think = function()
        if gui.IsGameUIVisible() then
            gui.HideGameUI()
            closeSpawnMenu(true)
        end
    end

    local list = vgui.Create("DScrollPanel", frame)
    list:SetPos(margin + 20, 148)
    list:SetSize(sidebarW - 40, ScrH() - 286)

    local deploy = vgui.Create("DButton", frame)
    deploy:SetPos(margin + 20, ScrH() - bottomH - 82)
    deploy:SetSize(math.floor((sidebarW - 48) * 0.56), 48)
    deploy:SetText("")
    deploy.Paint = function(self, w, h)
        paintDeploymentButton(self, w, h, "DEPLOY HERE", ui.ok, uiFont("MB.Tab", "SWInfil_Title"))
    end
    deploy.DoClick = function()
        local route = SWInfil.SpawnPreviewRoute
        if not route then return end

        playUISound("select")

        if IsValid(frame) then
            frame.SWInfilClosing = true
        end

        sendSpawnSelection(route.id)
        closeSpawnMenu(false)
    end

    local cancel = vgui.Create("DButton", frame)
    cancel:SetPos(margin + 28 + deploy:GetWide(), ScrH() - bottomH - 82)
    cancel:SetSize(sidebarW - 48 - deploy:GetWide(), 48)
    cancel:SetText("")
    cancel.Paint = function(self, w, h)
        paintDeploymentButton(self, w, h, "SPAWN NORMALLY", ui.dim, uiFont("MB.Small", "SWInfil_Small"))
    end
    cancel.DoClick = function()
        playUISound("select")
        closeSpawnMenu(true)
    end

    for _, route in ipairs(routes) do
        local button = list:Add("DButton")
        button:SetTall(66)
        button:Dock(TOP)
        button:DockMargin(0, 0, 0, 8)
        button:SetText("")
        button.Paint = function(self, w, h)
            local selected = SWInfil.SpawnPreviewRoute == route
            local hovered = self:IsHovered()
            local fill = selected and uiColor(ui.accent, 32) or Color(0, 0, 0, hovered and 126 or 92)

            drawDeploymentPanel(0, 0, w, h, {
                cut = 8,
                color = fill,
                accent = selected and ui.accent or uiColor(ui.accent, 42)
            })

            if (selected or hovered) and hasMilBaseUI() then
                MilBase.DrawBrackets(3, 3, w - 6, h - 6, selected and ui.accent or ui.dim, 9)
            end

            draw.SimpleText(string.upper(route.name or route.id or "LANDING ZONE"), uiFont("MB.Med", "SWInfil_Title"),
                16, 10, selected and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
            draw.SimpleText("LZ ID  " .. string.upper(route.id or "spawn"), uiFont("MB.Tiny", "SWInfil_Small"),
                17, 38, selected and ui.accent or ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        end
        button.DoClick = function()
            playUISound("select")
            selectSpawnPreview(route)
        end
    end
end

net.Receive("sw_infil_spawn_menu", function()
    timer.Simple(0, openSpawnMenu)
end)

local function activeState()
    local state = SWInfil.ClientState
    if not state then return nil end

    if not IsValid(state.ent) then
        SWInfil.ClientState = nil
        return nil
    end

    return state
end

net.Receive("sw_infil_begin", function()
    SWInfil.SkyboxState = nil
    closeSpawnMenu(false)

    SWInfil.ClientState = {
        ent = net.ReadEntity(),
        seat = net.ReadUInt(6),
        look = Angle(0, 0, 0),
        started = CurTime(),
        skipSent = false
    }
end)

net.Receive("sw_infil_end", function()
    SWInfil.ClientState = nil
end)

hook.Add("CreateMove", "SWInfil_CreateMove", function(cmd)
    local state = activeState()
    if not state then return end

    local look = state.look or Angle(0, 0, 0)
    local pitchLimit = replicatedFloat("sw_infil_look_pitch", 65)
    local yawLimit = replicatedFloat("sw_infil_look_yaw", 140)

    look.p = math.Clamp(look.p + cmd:GetMouseY() * 0.03, -pitchLimit, pitchLimit)
    look.y = math.Clamp(look.y - cmd:GetMouseX() * 0.03, -yawLimit, yawLimit)
    look.r = 0
    state.look = look

    local wantsSkip = bit.band(cmd:GetButtons(), IN_JUMP) ~= 0
    local allowSkip = GetConVar("sw_infil_allow_skip")
    if wantsSkip and not state.skipSent and CurTime() - state.started > 1.1 and allowSkip and allowSkip:GetBool() then
        state.skipSent = true
        net.Start("sw_infil_skip")
        net.SendToServer()
    end

    cmd:ClearMovement()
    cmd:ClearButtons()
end)

hook.Add("CalcView", "SWInfil_CalcView", function(ply, origin, angles, fov)
    if SWInfil.SpawnMenuOpen and SWInfil.SpawnPreviewRoute then
        return spawnPreviewView(fov)
    end

    local state = activeState()
    if not state then return end

    local seatPos, seatAng = SWInfil.GetSeatWorld(state.ent, state.seat, CurTime())
    local cameraBase = LocalToWorld(cameraOffset(), angle_zero, seatPos, seatAng)
    local _, lookAng = LocalToWorld(vector_origin, state.look or angle_zero, vector_origin, seatAng)
    local phase = SWInfil.GetPhase(state.ent, CurTime())
    local shake = phase == "landed" and 0.35 or 1.25
    local now = CurTime()
    local cameraPos = cameraBase
        + seatAng:Right() * math.sin(now * 27.5) * shake
        + seatAng:Up() * math.sin(now * 34.0) * shake * 0.5

    return {
        origin = cameraPos,
        angles = lookAng,
        fov = math.Clamp((fov or 75) + 7, 75, 90),
        drawviewer = false
    }
end)

hook.Add("ShouldDrawLocalPlayer", "SWInfil_HideLocalPlayer", function()
    if activeState() then return false end
end)

hook.Add("PreDrawViewModel", "SWInfil_HideViewModel", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    if activeState() or ply:GetNWBool("SWInfilSkyboxWaiting") or ply:GetNWBool("SWInfilChoosingSpawn") then
        return true
    end
end)

local hiddenHud = {
    CHudHealth = true,
    CHudBattery = true,
    CHudAmmo = true,
    CHudSecondaryAmmo = true,
    CHudCrosshair = true
}

hook.Add("HUDShouldDraw", "SWInfil_HideHUD", function(name)
    local ply = LocalPlayer()
    local waiting = IsValid(ply) and (ply:GetNWBool("SWInfilSkyboxWaiting") or ply:GetNWBool("SWInfilChoosingSpawn"))

    if (activeState() or waiting) and hiddenHud[name] then
        return false
    end
end)

hook.Add("HUDPaint", "SWInfil_HUD", function()
    local state = activeState()
    local w, h = ScrW(), ScrH()
    local ui = swUI()

    local ply = LocalPlayer()
    if IsValid(ply) and ply:GetNWBool("SWInfilSkyboxWaiting") then
        local sky = SWInfil.SkyboxState or {}
        local prompt = sky.prompt and sky.prompt ~= "" and sky.prompt or "LAAT Flying IN"
        local elapsed = CurTime() - (sky.started or CurTime())
        local dotCount = math.floor(CurTime() * 2) % 4
        local dots = string.rep(".", dotCount)
        local boxW = math.min(680, math.floor(w * 0.48))
        local boxX = math.floor((w - boxW) * 0.5)

        drawDeploymentPanel(boxX, 18, boxW, 74, {
            cut = 10,
            color = Color(0, 0, 0, 188),
            accent = ui.accent
        })

        draw.SimpleText(string.upper(prompt .. dots), uiFont("MB.Big", "SWInfil_Prompt"),
            w * 0.5, 29, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        if sky.duration and sky.duration > 0 then
            local fraction = math.Clamp(elapsed / sky.duration, 0, 1)
            local barW = boxW - 40
            local barX = boxX + 20
            surface.SetDrawColor(255, 255, 255, 18)
            surface.DrawRect(barX, 72, barW, 4)
            surface.SetDrawColor(ui.accent)
            surface.DrawRect(barX, 72, math.floor(barW * fraction), 4)
        end
    end

    if not state then return end

    local phase = SWInfil.GetPhase(state.ent, CurTime())
    local status = "Inbound to the landing zone"
    if phase == "landed" then
        status = "Doors open - disembark on command"
    elseif phase == "departure" then
        status = "Deploying from LAAT"
    end

    drawDeploymentPanel(24, 18, 430, 50, {
        cut = 8,
        color = Color(0, 0, 0, 178),
        accent = ui.accent
    })
    draw.SimpleText("LAAT TACTICAL INFILTRATION", uiFont("MB.Med", "SWInfil_Title"),
        42, 31, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

    drawDeploymentPanel(24, h - 68, math.min(560, w - 48), 44, {
        cut = 8,
        color = Color(0, 0, 0, 178),
        accent = phase == "landed" and ui.ok or ui.accent
    })
    draw.SimpleText(string.upper(status), uiFont("MB.Small", "SWInfil_Small"),
        42, h - 46, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    local allowSkip = GetConVar("sw_infil_allow_skip")
    if allowSkip and allowSkip:GetBool() and CurTime() - state.started > 1.1 then
        local hint = state.skipSent and "Skipping..." or "Press SPACE to skip"
        drawDeploymentPanel(w - 250, h - 68, 226, 44, {
            cut = 8,
            color = Color(0, 0, 0, 156),
            accent = ui.dim
        })
        draw.SimpleText(string.upper(hint), uiFont("MB.Small", "SWInfil_Small"),
            w - 42, h - 46, ui.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
end)

local function holdingToolMode(mode)
    local ply = LocalPlayer()
    if not IsValid(ply) then return false end

    local weapon = ply:GetActiveWeapon()
    return IsValid(weapon)
        and weapon:GetClass() == "gmod_tool"
        and weapon.GetMode
        and weapon:GetMode() == mode
end

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawRoutePreview", function()
    if not holdingToolMode("sw_infil_route") then return end
    if not GetGlobalBool("SWInfilRouteValid", false) then return end

    local startPos = GetGlobalVector("SWInfilRouteStart", vector_origin)
    local landPos = GetGlobalVector("SWInfilRouteLand", vector_origin)

    render.SetColorMaterial()
    render.DrawLine(startPos, landPos, Color(100, 190, 255, 230), true)
    render.DrawWireframeBox(startPos, angle_zero, Vector(-42, -42, -42), Vector(42, 42, 42), Color(80, 160, 255, 255), true)
    render.DrawWireframeBox(landPos, angle_zero, Vector(-58, -58, -18), Vector(58, 58, 18), Color(90, 255, 150, 255), true)
end)

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawSpawnMenuPreview", function(_, bDrawingSkybox)
    if bDrawingSkybox then return end
    if not SWInfil.SpawnMenuOpen then return end

    local route = SWInfil.SpawnPreviewRoute
    if not route then return end

    local startPos = route.startPos or vector_origin
    local landPos = route.landPos or vector_origin
    local landAng = route.landAng or angle_zero

    render.SetColorMaterial()
    render.DrawLine(startPos, landPos, Color(100, 190, 255, 245), true)
    render.DrawWireframeBox(landPos, landAng, Vector(-160, -160, -12), Vector(160, 160, 18), Color(90, 255, 150, 255), true)
    render.DrawLine(landPos + Vector(0, 0, 12), landPos + landAng:Forward() * 220 + Vector(0, 0, 12), Color(255, 230, 90, 255), true)
end)

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawSkyboxFlightPreview", function()
    if not holdingToolMode("sw_infil_skybox") then return end
    if not GetGlobalBool("SWInfilSkyboxRouteValid", false) then return end

    local startPos = GetGlobalVector("SWInfilSkyboxStart", vector_origin)
    local finishPos = GetGlobalVector("SWInfilSkyboxFinish", vector_origin)
    local hasMid = GetGlobalBool("SWInfilSkyboxHasMid", false)
    local midPos = hasMid and GetGlobalVector("SWInfilSkyboxMid", (startPos + finishPos) * 0.5) or (startPos + finishPos) * 0.5

    render.SetColorMaterial()
    render.DrawLine(startPos, midPos, Color(110, 170, 255, 235), true)
    render.DrawLine(midPos, finishPos, Color(110, 255, 190, 235), true)

    local lastPos = startPos
    for step = 1, 24 do
        local raw = step / 24
        local p1 = startPos + Angle(0, GetGlobalFloat("SWInfilSkyboxStartYaw", 0), 0):Forward() * math.Clamp(startPos:Distance(finishPos) * 0.32, 300, 2600)
        local pos = SWInfil.CubicBezier(startPos, p1, midPos, finishPos, SWInfil.SmootherStep(raw))
        render.DrawLine(lastPos, pos, Color(255, 230, 90, 210), true)
        lastPos = pos
    end

    render.DrawWireframeBox(startPos, angle_zero, Vector(-70, -70, -70), Vector(70, 70, 70), Color(80, 160, 255, 255), true)
    render.DrawWireframeBox(midPos, angle_zero, Vector(-52, -52, -52), Vector(52, 52, 52), Color(255, 230, 90, 255), true)
    render.DrawWireframeBox(finishPos, angle_zero, Vector(-70, -70, -24), Vector(70, 70, 24), Color(90, 255, 150, 255), true)
end)

local skyboxLAAT
local fallbackVisibleModel = "models/props_junk/PopCan01a.mdl"

local function smootherStep(value)
    local t = math.Clamp(value, 0, 1)
    return t * t * t * (t * (t * 6 - 15) + 10)
end

local function resolveSkyboxModel(model)
    if model and model ~= "" and util.IsValidModel(model) then
        return model
    end

    if SWInfil.DefaultModel and SWInfil.DefaultModel ~= "" and util.IsValidModel(SWInfil.DefaultModel) then
        return SWInfil.DefaultModel
    end

    return fallbackVisibleModel
end

local function getSkyboxModel(model)
    local resolvedModel = resolveSkyboxModel(model)

    if IsValid(skyboxLAAT) and skyboxLAAT.SWInfilModel == resolvedModel then
        return skyboxLAAT
    end

    if IsValid(skyboxLAAT) then
        skyboxLAAT:Remove()
    end

    skyboxLAAT = ClientsideModel(resolvedModel, RENDERGROUP_BOTH)
    if not IsValid(skyboxLAAT) then return nil end

    skyboxLAAT.SWInfilModel = resolvedModel
    skyboxLAAT:SetNoDraw(true)

    if skyboxLAAT.SetRenderBounds then
        skyboxLAAT:SetRenderBounds(Vector(-12000, -12000, -12000), Vector(12000, 12000, 12000))
    end

    return skyboxLAAT
end

local function skyboxWorldPath(state)
    local duration = math.max(state.duration or 0.01, 0.01)
    local raw = math.Clamp((CurTime() - (state.started or CurTime())) / duration, 0, 1)
    local startPos = state.skyStartPos or vector_origin
    local startAng = state.skyStartAng or angle_zero
    local midPos = state.skyMidPos or ((startPos + (state.skyFinishPos or state.entryPos or vector_origin)) * 0.5)
    local finishPos = state.skyFinishPos or state.entryPos or vector_origin
    local finishAng = state.skyFinishAng or state.entryAng or angle_zero
    local distance = startPos:Distance(finishPos)
    local p1 = startPos + startAng:Forward() * math.Clamp(distance * 0.32, 300, 2600)
    local p2 = midPos
    local pos, flightAng = SWInfil.GetBankedBezierTransform(startPos, p1, p2, finishPos, raw, startAng, smootherStep((raw - 0.70) / 0.30))
    local settle = smootherStep((raw - 0.78) / 0.22)

    flightAng = LerpAngle(settle, flightAng, finishAng)
    flightAng.p = flightAng.p - math.sin(raw * math.pi) * 3

    return pos, flightAng, raw
end

local function drawSkyboxStateModel(state, drawInSkybox, scaleOverride)
    if not state then return false end
    local model = getSkyboxModel(state.model or SWInfil.DefaultModel)

    local worldPos, worldAng = skyboxWorldPath(state)
    local drawPos = worldPos
    local modelScale = scaleOverride or replicatedFloat("sw_infil_skybox_model_scale", 0.045)
    local customSkybox = state.customSkybox == true

    if drawInSkybox then
        local info = game.Get3DSkyboxInfo()

        if customSkybox then
            drawPos = worldPos
        elseif info and info.origin and info.scale and info.scale ~= 0 then
            drawPos = info.origin + worldPos * (1 / info.scale)
        else
            drawPos = EyePos() + EyeAngles():Forward() * 8000 + Vector(0, 0, 1400)
        end
    else
        local minMapScale = replicatedFloat("sw_infil_skybox_map_min_scale", 0.35)
        modelScale = math.max(scaleOverride or replicatedFloat("sw_infil_skybox_world_fallback_scale", 0.45), minMapScale)

        if customSkybox and not state.rawWorldFallback then
            local info = game.Get3DSkyboxInfo()

            if info and info.origin and info.scale and info.scale ~= 0 then
                drawPos = (worldPos - info.origin) * info.scale
            end
        end
    end

    local ignoreDepth = (not drawInSkybox) and replicatedBool("sw_infil_skybox_map_ignore_z", true)
    if ignoreDepth and cam.IgnoreZ then
        cam.IgnoreZ(true)
    end

    if not IsValid(model) then
        render.SetColorMaterial()
        render.DrawWireframeBox(drawPos, worldAng, Vector(-260, -150, -70) * modelScale, Vector(260, 150, 90) * modelScale, Color(255, 80, 80, 255), true)

        if ignoreDepth and cam.IgnoreZ then
            cam.IgnoreZ(false)
        end

        return false
    end

    local matrix = Matrix()
    matrix:Scale(Vector(modelScale, modelScale, modelScale))

    model:EnableMatrix("RenderMultiply", matrix)
    model:SetPos(drawPos)
    model:SetAngles(worldAng)
    model:SetRenderOrigin(drawPos)
    model:SetRenderAngles(worldAng)
    model:SetupBones()
    model:DrawModel()
    model:SetRenderOrigin()
    model:SetRenderAngles()

    if ignoreDepth and cam.IgnoreZ then
        cam.IgnoreZ(false)
    end

    return true
end

local function drawSkyboxLAAT(drawInSkybox)
    local state = SWInfil.SkyboxState
    if not state then return end

    if CurTime() > (state.started or 0) + (state.duration or 0) + 1 then
        SWInfil.SkyboxState = nil
        return
    end

    drawSkyboxStateModel(state, drawInSkybox)
end

hook.Add("PostDrawSkyBox", "SWInfil_DrawSkyboxLAAT", function()
    drawSkyboxLAAT(true)
end)

hook.Add("PostDraw2DSkyBox", "SWInfil_DrawSkyboxLAATFallback", function()
    if game.Get3DSkyboxInfo() then return end
    drawSkyboxLAAT(true)
end)

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawSkyboxLAATWorldFallback", function(_, bDrawingSkybox)
    if bDrawingSkybox then return end
    if not SWInfil.SkyboxState then return end
    drawSkyboxLAAT(false)
end)

local function configuredSkyboxModel()
    local convar = GetConVar("sw_infil_model")
    local model = convar and convar:GetString() or SWInfil.DefaultModel
    return resolveSkyboxModel(model)
end

local function buildSkyboxToolPreviewState(looping)
    if not GetGlobalBool("SWInfilSkyboxRouteValid", false) then return nil end

    local startPos = GetGlobalVector("SWInfilSkyboxStart", vector_origin)
    local finishPos = GetGlobalVector("SWInfilSkyboxFinish", vector_origin)
    local startAng = Angle(0, GetGlobalFloat("SWInfilSkyboxStartYaw", 0), 0)
    local finishAng = Angle(0, GetGlobalFloat("SWInfilSkyboxFinishYaw", startAng.y), 0)
    local hasMid = GetGlobalBool("SWInfilSkyboxHasMid", false)
    local midPos = hasMid and GetGlobalVector("SWInfilSkyboxMid", (startPos + finishPos) * 0.5) or (startPos + finishPos) * 0.5
    local midAng = Angle(0, GetGlobalFloat("SWInfilSkyboxMidYaw", startAng.y), 0)
    local duration = math.max(replicatedFloat("sw_infil_skybox_time", 4), 0.5)
    local started = CurTime()

    if looping then
        started = CurTime() - (CurTime() % duration)
    end

    return {
        started = started,
        duration = duration,
        model = configuredSkyboxModel(),
        prompt = "LAAT Flying IN",
        skyStartPos = startPos,
        skyStartAng = startAng,
        skyMidPos = midPos,
        skyMidAng = midAng,
        skyFinishPos = finishPos,
        skyFinishAng = finishAng,
        entryPos = finishPos,
        entryAng = finishAng,
        customSkybox = true,
        rawWorldFallback = true
    }
end

hook.Add("PostDrawSkyBox", "SWInfil_DrawSkyboxLAATToolSkyboxPreview", function()
    if not holdingToolMode("sw_infil_skybox") then return end

    local state = buildSkyboxToolPreviewState(true)
    if not state then return end

    drawSkyboxStateModel(state, true, replicatedFloat("sw_infil_skybox_model_scale", 0.045))
end)

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawSkyboxLAATToolPreview", function(_, bDrawingSkybox)
    if bDrawingSkybox then return end
    if not holdingToolMode("sw_infil_skybox") then return end

    local state = buildSkyboxToolPreviewState(true)
    if not state then return end

    local scale = replicatedFloat("sw_infil_skybox_world_fallback_scale", 0.45)
    drawSkyboxStateModel(state, false, scale)
end)

concommand.Add("sw_infil_skybox_preview", function()
    local state = buildSkyboxToolPreviewState(false)
    if not state then
        chat.AddText(Color(255, 120, 90), "[LAAT Infil] Set a skybox start and finish point first.")
        return
    end

    state.started = CurTime()
    SWInfil.SkyboxState = state
    chat.AddText(Color(120, 220, 255), "[LAAT Infil] Playing local mini LAAT preview.")
end)

local passengerModels = {}

local function cleanupPassengerModels()
    for _, model in pairs(passengerModels) do
        if IsValid(model) then
            model:Remove()
        end
    end

    passengerModels = {}
end

local function choosePassengerSequence(model)
    local names = {
        "idle_all_01",
        "idle_passive",
        "idle",
        "idle_all",
        "idle_subtle"
    }

    for _, name in ipairs(names) do
        local sequence = model:LookupSequence(name)
        if sequence and sequence >= 0 then
            return sequence
        end
    end

    local sequence = model:SelectWeightedSequence(ACT_HL2MP_IDLE_PASSIVE)
    if sequence and sequence >= 0 then return sequence end

    sequence = model:SelectWeightedSequence(ACT_HL2MP_IDLE)
    if sequence and sequence >= 0 then return sequence end
end

local function applyPassengerStandSequence(proxy)
    local sequence = choosePassengerSequence(proxy)
    if not sequence or sequence < 0 then return end

    if proxy.SWInfilSequence ~= sequence then
        proxy:ResetSequence(sequence)
        proxy:SetCycle(0)
        proxy:SetPlaybackRate(1)
        proxy.SWInfilSequence = sequence
    end
end

local function syncPassengerAppearance(proxy, ply)
    proxy:SetSkin(ply:GetSkin() or 0)
    proxy:SetModelScale(ply:GetModelScale() or 1, 0)

    if proxy.SetPlayerColor and ply.GetPlayerColor then
        proxy:SetPlayerColor(ply:GetPlayerColor())
    end

    local groups = ply:GetNumBodyGroups() or 0
    for group = 0, groups - 1 do
        proxy:SetBodygroup(group, ply:GetBodygroup(group) or 0)
    end

    local subMaterials = ply:GetMaterials() or {}
    for index = 0, #subMaterials do
        local material = ply:GetSubMaterial(index)
        if material and material ~= "" then
            proxy:SetSubMaterial(index, material)
        end
    end
end

local function preparePassengerModel(ply)
    local key = ply:EntIndex()
    local modelPath = ply:GetModel()
    if modelPath == "" or not util.IsValidModel(modelPath) then return nil end

    local proxy = passengerModels[key]
    if IsValid(proxy) and proxy.SWInfilModel == modelPath then
        syncPassengerAppearance(proxy, ply)
        applyPassengerStandSequence(proxy)
        return proxy
    end

    if IsValid(proxy) then
        proxy:Remove()
    end

    proxy = ClientsideModel(modelPath, RENDERGROUP_TRANSLUCENT)
    if not IsValid(proxy) then return nil end

    proxy.SWInfilModel = modelPath
    proxy:SetNoDraw(true)
    proxy:SetRenderMode(RENDERMODE_NORMAL)
    syncPassengerAppearance(proxy, ply)
    applyPassengerStandSequence(proxy)

    passengerModels[key] = proxy
    return proxy
end

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawPassengerModels", function()
    local showConVar = GetConVar("sw_infil_show_passengers")
    if showConVar and not showConVar:GetBool() then
        cleanupPassengerModels()
        return
    end

    local localPlayer = LocalPlayer()
    local activeVehicle

    if IsValid(localPlayer) and localPlayer:GetNWBool("SWInfilActive") then
        activeVehicle = localPlayer:GetNWEntity("SWInfilVehicle")
    end

    local seen = {}

    for _, ply in ipairs(player.GetAll()) do
        if ply ~= localPlayer and ply:GetNWBool("SWInfilActive") then
            local vehicle = ply:GetNWEntity("SWInfilVehicle")
            if IsValid(vehicle) and (not IsValid(activeVehicle) or activeVehicle == vehicle) then
                local seatIndex = ply:GetNWInt("SWInfilSeat", 0)
                if seatIndex > 0 then
                    local proxy = preparePassengerModel(ply)
                    if IsValid(proxy) then
                        local seatPos, seatAng = SWInfil.GetSeatWorld(vehicle, seatIndex, CurTime())
                        local bodyPos = LocalToWorld(bodyOffset(), angle_zero, seatPos, seatAng)

                        proxy:SetPos(bodyPos)
                        proxy:SetAngles(Angle(0, seatAng.y, 0))
                        proxy:FrameAdvance(FrameTime())
                        proxy:SetupBones()
                        proxy:DrawModel()

                        seen[ply:EntIndex()] = true
                    end
                end
            end
        end
    end

    for key, model in pairs(passengerModels) do
        if not seen[key] and IsValid(model) then
            model:Remove()
            passengerModels[key] = nil
        end
    end
end)

local seatGhosts = {}

local function cleanupSeatGhosts()
    for _, ghost in pairs(seatGhosts) do
        if IsValid(ghost) then
            ghost:Remove()
        end
    end

    seatGhosts = {}
end

local function ghostModelPath()
    local convar = GetConVar("sw_infil_ghost_model")
    local model = convar and convar:GetString() or ""

    if model == "" or not util.IsValidModel(model) then
        local ply = LocalPlayer()
        model = IsValid(ply) and ply:GetModel() or "models/player/Group01/male_07.mdl"
    end

    return model
end

local function prepareGhost(index, model)
    local ghost = seatGhosts[index]
    if IsValid(ghost) and ghost.SWInfilModel == model then
        return ghost
    end

    if IsValid(ghost) then
        ghost:Remove()
    end

    ghost = ClientsideModel(model, RENDERGROUP_TRANSLUCENT)
    if not IsValid(ghost) then return nil end

    ghost.SWInfilModel = model
    ghost:SetNoDraw(true)
    ghost:SetRenderMode(RENDERMODE_TRANSALPHA)
    ghost:SetColor(Color(120, 210, 255, 155))

    local sequence = ghost:LookupSequence("idle_all_01")
    if not sequence or sequence < 0 then
        sequence = ghost:SelectWeightedSequence(ACT_HL2MP_IDLE_PASSIVE)
    end

    if sequence and sequence >= 0 then
        ghost:ResetSequence(sequence)
    end

    seatGhosts[index] = ghost
    return ghost
end

hook.Add("PostDrawTranslucentRenderables", "SWInfil_DrawSeatEditorGhosts", function()
    if not holdingToolMode("sw_infil_seats") then
        cleanupSeatGhosts()
        return
    end

    local preview = GetGlobalEntity("SWInfilSeatPreview", NULL)
    if not IsValid(preview) then return end

    local seats = SWInfil.Seats or {}
    local model = ghostModelPath()
    local body = bodyOffset()
    local camera = cameraOffset()

    render.SetColorMaterial()

    for index, seat in ipairs(seats) do
        local ghost = prepareGhost(index, model)
        local seatPos, seatAng = LocalToWorld(seat.pos, seat.ang, preview:GetPos(), preview:GetAngles())
        local bodyPos = LocalToWorld(body, angle_zero, seatPos, seatAng)
        local cameraPos = LocalToWorld(camera, angle_zero, seatPos, seatAng)

        render.DrawWireframeBox(bodyPos, seatAng, Vector(-12, -12, 0), Vector(12, 12, 72), Color(120, 210, 255, 210), true)
        render.DrawWireframeBox(cameraPos, seatAng, Vector(-4, -4, -4), Vector(4, 4, 4), Color(255, 230, 90, 255), true)
        render.DrawLine(bodyPos + Vector(0, 0, 36), bodyPos + seatAng:Forward() * 42 + Vector(0, 0, 36), Color(255, 230, 90, 230), true)

        if IsValid(ghost) then
            ghost:SetPos(bodyPos)
            ghost:SetAngles(Angle(0, seatAng.y, 0))
            ghost:FrameAdvance(FrameTime())
            ghost:SetupBones()

            render.SetBlend(0.48)
            ghost:DrawModel()
            render.SetBlend(1)
        end
    end

    for index, ghost in pairs(seatGhosts) do
        if index > #seats and IsValid(ghost) then
            ghost:Remove()
            seatGhosts[index] = nil
        end
    end
end)

hook.Add("ShutDown", "SWInfil_CleanupSeatGhosts", cleanupSeatGhosts)
hook.Add("OnReloaded", "SWInfil_CleanupSeatGhostsReload", cleanupSeatGhosts)
hook.Add("ShutDown", "SWInfil_CleanupPassengerModels", cleanupPassengerModels)
hook.Add("OnReloaded", "SWInfil_CleanupPassengerModelsReload", cleanupPassengerModels)

local function cleanupSkyboxLAAT()
    if IsValid(skyboxLAAT) then
        skyboxLAAT:Remove()
    end

    skyboxLAAT = nil
end

hook.Add("ShutDown", "SWInfil_CleanupSkyboxLAAT", cleanupSkyboxLAAT)
hook.Add("OnReloaded", "SWInfil_CleanupSkyboxLAATReload", cleanupSkyboxLAAT)
