--[[
	Encryption Relay logic (mb_relay_dish + mb_relay_terminal).

	High Command presses E on the terminal to run a decrypt minigame (requires a
	working antenna) and gain TEMPORARY access to the Encrypted channel (see
	sh_comms.lua). Both entities are destructible (sabotage charges / weapons)
	and repairable by engineers - the rank-and-file sabotage the relay to keep
	their encrypted net secret; engineers rebuild it to restore command oversight.
]]

local cfg = MilBase.Config
cfg.RelayHealth = cfg.RelayHealth or 300
cfg.RelayDishModel = cfg.RelayDishModel or "models/props_combine/combine_interface001.mdl"
cfg.RelayTerminalModel = cfg.RelayTerminalModel or "models/props_lab/monitor01b.mdl"

local RELAY = { mb_relay_dish = true, mb_relay_terminal = true }
local function isRelay(e) return IsValid(e) and RELAY[e:GetClass()] end

-- Is there a working antenna on the map (needed to hack the terminal)?
local function dishUp()
	for _, e in ipairs(ents.FindByClass("mb_relay_dish")) do
		if not e:GetBroken() then return true end
	end
	return false
end
MilBase.RelayOperational = dishUp

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_RelayHack")
	util.AddNetworkString("MilBase_RelayHackDone")

	local function isEngineer(ply) return ply:MBHasCert("engineer") or ply:IsAdmin() end
	-- Who can decrypt the Hostile Net by hacking the terminal: High Command + staff.
	local function canTap(ply)
		return (MilBase.CommsIsHighCommand and MilBase.CommsIsHighCommand(ply))
			or (MilBase.CommsIsStaff and MilBase.CommsIsStaff(ply))
	end

	function MilBase.RelayUse(self, ply)
		if not IsValid(ply) or not ply:IsPlayer() then return end

		if self:GetBroken() then
			if isEngineer(ply) and MilBase.FindEngItem and MilBase.FindEngItem(ply, "repair") then
				self:Repair()
				MilBase.Notify(ply, "Relay repaired.")
			else
				MilBase.Notify(ply, "The relay is destroyed - an engineer with a Repair Kit must fix it.")
			end
			return
		end

		if self:GetClass() == "mb_relay_dish" then
			MilBase.Notify(ply, "Relay antenna operational.")
			return
		end

		-- Terminal: only High Command / staff hack, and only with a live antenna.
		if not canTap(ply) then
			MilBase.Notify(ply, "Only High Command or staff can slice the relay terminal.")
			return
		end
		if not dishUp() then
			MilBase.Notify(ply, "No signal - the relay antenna is down.")
			return
		end

		net.Start("MilBase_RelayHack")
			net.WriteEntity(self)
		net.Send(ply)
	end

	net.Receive("MilBase_RelayHackDone", function(_, ply)
		local term = net.ReadEntity()
		if not IsValid(term) or term:GetClass() ~= "mb_relay_terminal" then return end
		if term:GetBroken() or not dishUp() or not canTap(ply) then return end
		if term:GetPos():DistToSqr(ply:GetPos()) > 220 * 220 then return end

		MilBase.GrantDecrypt(ply, cfg.EncryptedDecryptTime)

		-- Tip off the enemy that their encrypted net was intercepted.
		for _, p in ipairs(player.GetAll()) do
			if (MilBase.IsEventEnemy and MilBase.IsEventEnemy(p)) or p:GetNWBool("mb_eventmode", false) then
				MilBase.Notify(p, "! Hostile Net intercepted - your comms are being decrypted !")
			end
		end
	end)

	-- Destructible: real damage chips health; a saboteur's charge blast counts.
	hook.Add("EntityTakeDamage", "MilBase.RelayDamage", function(ent, dmg)
		if not isRelay(ent) or ent:GetBroken() then return end
		ent.mb_hp = (ent.mb_hp or (cfg.RelayHealth or 300)) - dmg:GetDamage()
		if ent.mb_hp <= 0 then ent:Break() end
	end)

	-- Quick admin spawn (also spawnable from the game master's RP Entities).
	MilBase.RegisterChatCommand("relay", {
		help = "(Admin) Spawn an encryption relay (antenna + terminal) at your aim.",
		func = function(ply)
			if not ply:IsAdmin() then
				MilBase.Notify(ply, "Admins only.")
				return
			end
			local tr = ply:GetEyeTrace()

			local dish = ents.Create("mb_relay_dish")
			dish:SetPos(tr.HitPos + tr.HitNormal * 6)
			dish:SetAngles(ply:EyeAngles())
			dish:Spawn()

			local term = ents.Create("mb_relay_terminal")
			term:SetPos(tr.HitPos + ply:GetRight() * 70 + tr.HitNormal * 6)
			term:SetAngles(ply:EyeAngles())
			term:Spawn()

			MilBase.Notify(ply, "Encryption relay spawned (antenna + terminal).")
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: the decrypt minigame
--------------------------------------------------------------------------

net.Receive("MilBase_RelayHack", function()
	local term = net.ReadEntity()
	if not IsValid(term) then return end

	MilBase.OpenCodeMinigame({
		title = "DECRYPTING RELAY",
		subtitle = "Break the encryption to tap the encrypted channel.",
		color = Color(160, 100, 220),
		lines = MilBase.GenCodeLines(7),
		valid = function()
			return IsValid(term) and not term:GetBroken()
				and term:GetPos():DistToSqr(LocalPlayer():GetPos()) < 220 * 220
		end,
		onSuccess = function()
			net.Start("MilBase_RelayHackDone")
				net.WriteEntity(term)
			net.SendToServer()
		end,
	})
end)
