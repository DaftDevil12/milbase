--[[
	Persistent daily duty orders.

	Assignments and progress are authoritative on the server, stored through the
	MilBase database adapter, and exposed through a small API so other modules can
	award progress without knowing how persistence or rewards work.
]]

local cfg = MilBase.Config
MilBase.DailyQuests = MilBase.DailyQuests or {}
MilBase.DailyQuests.Players = MilBase.DailyQuests.Players or {}

local NET_SYNC = "MilBase_DailyQuests_Sync"
local NET_NOTICE = "MilBase_DailyQuests_Notice"
local NET_REQUEST = "MilBase_DailyQuests_Request"
local NET_CLAIM = "MilBase_DailyQuests_Claim"
local NET_OPEN = "MilBase_DailyQuests_OpenF4"

local function clampInt(value, minimum, maximum)
	value = math.floor(tonumber(value or 0) or 0)
	if minimum then value = math.max(minimum, value) end
	if maximum then value = math.min(maximum, value) end
	return value
end

local function clampNumber(value, minimum, maximum)
	value = tonumber(value or 0) or 0
	if minimum then value = math.max(minimum, value) end
	if maximum then value = math.min(maximum, value) end
	return value
end

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function definitionsByID()
	local out = {}
	for _, definition in ipairs(cfg.DailyQuestDefinitions or {}) do
		if istable(definition) and trim(definition.id) ~= "" then
			out[definition.id] = definition
		end
	end
	return out
end

function MilBase.DailyQuestDayKey(timestamp)
	local resetHour = clampInt(cfg.DailyQuestResetHourUTC or 0, 0, 23)
	local shifted = (tonumber(timestamp) or os.time()) - resetHour * 3600
	return os.date("!%Y-%m-%d", shifted)
end

function MilBase.DailyQuestSecondsUntilReset(timestamp)
	local resetHour = clampInt(cfg.DailyQuestResetHourUTC or 0, 0, 23)
	local shifted = (tonumber(timestamp) or os.time()) - resetHour * 3600
	local utc = os.date("!*t", shifted)
	local elapsed = utc.hour * 3600 + utc.min * 60 + utc.sec
	return math.max(1, 86400 - elapsed)
end

local function safeColor(definition)
	local color = definition and definition.color
	if IsColor(color) then return Color(color.r, color.g, color.b, color.a or 255) end
	return Color(255, 198, 60)
end

local function questPayloadEntry(entry, definition)
	definition = definition or {}
	local target = math.max(1, clampInt(entry.target or definition.target_min or 1, 1))
	local progress = clampNumber(entry.progress or 0, 0, target)
	return {
		id = entry.id,
		name = definition.name or entry.id or "Daily Order",
		description = definition.description or "",
		event = definition.event or "",
		target = target,
		progress = progress,
		complete = progress >= target,
		claimed = entry.claimed == true,
		completed_at = clampInt(entry.completed_at or 0, 0),
		reward_xp = clampInt(definition.reward_xp or 0, 0),
		reward_credits = clampInt(definition.reward_credits or 0, 0),
		reward_item = trim(definition.reward_item),
		reward_item_amount = clampInt(definition.reward_item_amount or 1, 1),
		color = safeColor(definition),
	}
end

function MilBase.DailyQuestBuildPayload(ply)
	local state = IsValid(ply) and MilBase.DailyQuests.Players[ply:SteamID64()] or nil
	local definitions = definitionsByID()
	local quests = {}
	for _, entry in ipairs(state and state.quests or {}) do
		local definition = definitions[entry.id]
		if definition then quests[#quests + 1] = questPayloadEntry(entry, definition) end
	end
	return {
		disabled = cfg.DailyQuestsEnabled == false,
		day = state and state.day or MilBase.DailyQuestDayKey(),
		reset_in = MilBase.DailyQuestSecondsUntilReset(),
		loaded = state ~= nil,
		quests = quests,
	}
end

if SERVER then
	util.AddNetworkString(NET_SYNC)
	util.AddNetworkString(NET_NOTICE)
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_CLAIM)
	util.AddNetworkString(NET_OPEN)

	local TABLE_NAME = "frontier_daily_quests"

	local function createTable()
		MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. TABLE_NAME .. " ("
			.. "steamid VARCHAR(32) PRIMARY KEY, quest_day VARCHAR(16), quest_data TEXT, updated_at INTEGER)")
	end
	createTable()
	hook.Add("MilBase.DBReady", "MilBase.DailyQuests.CreateTable", createTable)

	local function canUseDefinition(ply, definition)
		if not istable(definition) or trim(definition.id) == "" then return false end
		if definition.cert and (not ply.MBHasCert or not ply:MBHasCert(definition.cert)) then return false end
		if istable(definition.factions) and #definition.factions > 0 then
			local factionID = ply.MBFactionID and ply:MBFactionID() or ""
			local faction = ply.MBFaction and ply:MBFaction()
			local factionName = faction and faction.name or ""
			local matched = false
			for _, value in ipairs(definition.factions) do
				if tostring(value) == factionID or tostring(value) == factionName then matched = true break end
			end
			if not matched then return false end
		end
		return true
	end

	local function makeRNG(seedText)
		local state = tonumber(util.CRC(seedText or "daily")) or 1
		state = math.max(1, state % 2147483647)
		return function(minimum, maximum)
			state = (state * 48271) % 2147483647
			local fraction = state / 2147483647
			return minimum + math.floor(fraction * (maximum - minimum + 1))
		end
	end

	local function generateAssignments(ply, day, salt)
		local rng = makeRNG(ply:SteamID64() .. ":" .. day .. ":" .. tostring(salt or 0))
		local available = {}
		for _, definition in ipairs(cfg.DailyQuestDefinitions or {}) do
			if canUseDefinition(ply, definition) then available[#available + 1] = definition end
		end

		local assignments = {}
		local usedIDs, usedGroups = {}, {}
		local wanted = math.Clamp(clampInt(cfg.DailyQuestCount or 3, 1, 8), 1, math.max(1, #available))
		while #assignments < wanted do
			local candidates = {}
			for _, definition in ipairs(available) do
				local group = trim(definition.group)
				if not usedIDs[definition.id] and (group == "" or not usedGroups[group]) then
					candidates[#candidates + 1] = definition
				end
			end
			if #candidates == 0 then
				for _, definition in ipairs(available) do
					if not usedIDs[definition.id] then candidates[#candidates + 1] = definition end
				end
			end
			if #candidates == 0 then break end

			local definition = candidates[rng(1, #candidates)]
			local minimum = clampInt(definition.target_min or definition.target or 1, 1)
			local maximum = clampInt(definition.target_max or definition.target or minimum, minimum)
			assignments[#assignments + 1] = {
				id = definition.id,
				target = rng(minimum, maximum),
				progress = 0,
				claimed = false,
				completed_at = 0,
			}
			usedIDs[definition.id] = true
			if trim(definition.group) ~= "" then usedGroups[definition.group] = true end
		end
		return assignments
	end

	local function encodeState(state)
		return util.TableToJSON({ quests = state.quests or {}, reroll = state.reroll or 0 }, false) or "{}"
	end

	local function saveState(ply, immediate)
		if not (IsValid(ply) and ply:IsPlayer()) then return end
		local state = MilBase.DailyQuests.Players[ply:SteamID64()]
		if not state then return end
		state.dirty = nil
		state.last_save = CurTime()
		MilBase.DB.Run(string.format(
			"REPLACE INTO %s (steamid, quest_day, quest_data, updated_at) VALUES (%s,%s,%s,%d)",
			TABLE_NAME, MilBase.SQLStr(ply:SteamID64()), MilBase.SQLStr(state.day),
			MilBase.SQLStr(encodeState(state)), os.time()))
	end

	local function sendSync(ply)
		if not IsValid(ply) then return end
		net.Start(NET_SYNC)
			net.WriteTable(MilBase.DailyQuestBuildPayload(ply))
		net.Send(ply)
	end
	MilBase.DailyQuestSync = sendSync

	local function sendNotice(ply, kind, text)
		if not IsValid(ply) then return end
		net.Start(NET_NOTICE)
			net.WriteString(kind or "progress")
			net.WriteString(text or "")
		net.Send(ply)
	end

	local function installState(ply, day, data)
		local state = {
			day = day,
			quests = istable(data and data.quests) and data.quests or {},
			reroll = clampInt(data and data.reroll or 0, 0),
			loaded_at = CurTime(),
		}
		local definitions = definitionsByID()
		local clean = {}
		for _, entry in ipairs(state.quests) do
			local definition = istable(entry) and definitions[entry.id]
			if definition then
				local target = clampInt(entry.target or definition.target_min or 1, 1)
				clean[#clean + 1] = {
					id = entry.id,
					target = target,
					progress = clampNumber(entry.progress or 0, 0, target),
					claimed = entry.claimed == true,
					completed_at = clampInt(entry.completed_at or 0, 0),
				}
			end
		end
		state.quests = clean
		MilBase.DailyQuests.Players[ply:SteamID64()] = state
		ply.mb_dailyQuestLoading = nil
		sendSync(ply)
		return state
	end

	local function createFreshState(ply, reroll)
		local day = MilBase.DailyQuestDayKey()
		local state = installState(ply, day, {
			quests = generateAssignments(ply, day, reroll or 0),
			reroll = reroll or 0,
		})
		saveState(ply, true)
		return state
	end

	local function ensureCurrentDay(ply)
		local state = MilBase.DailyQuests.Players[ply:SteamID64()]
		local day = MilBase.DailyQuestDayKey()
		if state and state.day ~= day then
			state = createFreshState(ply, 0)
			sendNotice(ply, "reset", "New daily duty orders are now available.")
		end
		return state
	end

	local function loadPlayer(ply, callback)
		if not (IsValid(ply) and ply:IsPlayer()) then return end
		local existing = ensureCurrentDay(ply)
		if existing then if callback then callback(existing) end return end
		if ply.mb_dailyQuestLoading then
			timer.Simple(0.25, function() if IsValid(ply) then loadPlayer(ply, callback) end end)
			return
		end
		ply.mb_dailyQuestLoading = true
		MilBase.DB.Query("SELECT quest_day, quest_data FROM " .. TABLE_NAME
			.. " WHERE steamid = " .. MilBase.SQLStr(ply:SteamID64()) .. " LIMIT 1", function(rows)
			if not IsValid(ply) then return end
			local row = rows and rows[1]
			local today = MilBase.DailyQuestDayKey()
			local decoded = row and util.JSONToTable(row.quest_data or "") or nil
			if row and row.quest_day == today and istable(decoded) then
				local state = installState(ply, today, decoded)
				if #state.quests == 0 then createFreshState(ply, state.reroll or 0) end
			else
				createFreshState(ply, 0)
			end
			if callback then callback(MilBase.DailyQuests.Players[ply:SteamID64()]) end
		end, function()
			if IsValid(ply) then
				ply.mb_dailyQuestLoading = nil
				createFreshState(ply, 0)
				if callback then callback(MilBase.DailyQuests.Players[ply:SteamID64()]) end
			end
		end)
	end
	MilBase.DailyQuestLoadPlayer = loadPlayer

	function MilBase.DailyQuestGetPayload(ply, callback)
		if cfg.DailyQuestsEnabled == false then
			if callback then callback({ loaded = true, disabled = true, day = MilBase.DailyQuestDayKey(), reset_in = MilBase.DailyQuestSecondsUntilReset(), quests = {} }) end
			return
		end
		loadPlayer(ply, function()
			if IsValid(ply) and callback then callback(MilBase.DailyQuestBuildPayload(ply)) end
		end)
	end

	local function markDirty(ply, state, immediate)
		state.dirty = true
		sendSync(ply)
		if immediate then saveState(ply, true) end
	end

	function MilBase.DailyQuestProgress(ply, eventName, amount, context)
		if cfg.DailyQuestsEnabled == false or not (IsValid(ply) and ply:IsPlayer()) then return 0 end
		amount = math.max(0, tonumber(amount or 1) or 0)
		if amount <= 0 then return 0 end
		local state = ensureCurrentDay(ply)
		if not state then
			loadPlayer(ply, function()
				if IsValid(ply) then MilBase.DailyQuestProgress(ply, eventName, amount, context) end
			end)
			return 0
		end
		local definitions = definitionsByID()
		local changed = 0
		for _, entry in ipairs(state.quests) do
			local definition = definitions[entry.id]
			if definition and definition.event == eventName and not entry.claimed then
				local old = clampNumber(entry.progress or 0, 0)
				local target = clampInt(entry.target or 1, 1)
				entry.progress = clampNumber(old + amount, 0, target)
				if entry.progress > old then
					changed = changed + (entry.progress - old)
					if old < target and entry.progress >= target then
						entry.completed_at = os.time()
						sendNotice(ply, "complete", (definition.name or "Daily order") .. " complete. Claim the reward in F4 → Daily Orders.")
					end
				end
			end
		end
		if changed > 0 then markDirty(ply, state, false) end
		return changed
	end

	local function grantReward(ply, definition)
		local granted = {}
		local xp = clampInt(definition.reward_xp or 0, 0)
		local credits = clampInt(definition.reward_credits or 0, 0)
		if xp > 0 and MilBase.AwardXP then
			granted.xp = MilBase.AwardXP(ply, xp)
		end
		if credits > 0 and MilBase.AwardCredits then
			granted.credits = MilBase.AwardCredits(ply, credits)
		end
		local item = trim(definition.reward_item)
		if item ~= "" and MilBase.GiveItem then
			local amount = clampInt(definition.reward_item_amount or 1, 1, 100)
			MilBase.GiveItem(ply, item, amount)
			granted.item, granted.item_amount = item, amount
		end
		if MilBase.SaveProgress then MilBase.SaveProgress(ply) end
		return granted
	end

	function MilBase.DailyQuestClaim(ply, questID)
		if not (IsValid(ply) and ply:IsPlayer()) then return false, "Invalid player." end
		local state = ensureCurrentDay(ply)
		if not state then loadPlayer(ply) return false, "Daily orders are still loading." end
		local definitions = definitionsByID()
		for _, entry in ipairs(state.quests) do
			if entry.id == questID then
				local definition = definitions[entry.id]
				if not definition then return false, "Quest definition no longer exists." end
				if entry.claimed then return false, "That reward has already been claimed." end
				if clampNumber(entry.progress or 0, 0) < clampInt(entry.target or 1, 1) then return false, "That order is not complete." end
				entry.claimed = true
				local reward = grantReward(ply, definition)
				markDirty(ply, state, true)
				local parts = {}
				if reward.xp and reward.xp > 0 then parts[#parts + 1] = reward.xp .. " XP" end
				if reward.credits and reward.credits > 0 then parts[#parts + 1] = cfg.CurrencySymbol .. reward.credits end
				if reward.item then parts[#parts + 1] = reward.item_amount .. "x " .. reward.item end
				local rewardText = #parts > 0 and table.concat(parts, ", ") or "order completion recorded"
				MilBase.Notify(ply, "Daily reward claimed: " .. rewardText .. ".", "ok")
				return true
			end
		end
		return false, "Daily order not found."
	end

	function MilBase.DailyQuestReroll(ply, actor)
		if not (IsValid(ply) and ply:IsPlayer()) then return false, "Player not found." end
		local state = ensureCurrentDay(ply)
		local nextReroll = clampInt(state and state.reroll or 0, 0) + 1
		installState(ply, MilBase.DailyQuestDayKey(), {
			quests = generateAssignments(ply, MilBase.DailyQuestDayKey(), nextReroll),
			reroll = nextReroll,
		})
		saveState(ply, true)
		MilBase.Notify(ply, "Your daily duty orders were rerolled by " .. (IsValid(actor) and actor:Nick() or "console") .. ".", "warn")
		return true
	end

	local function staffAllowed(ply)
		if not IsValid(ply) then return true end
		if game.SinglePlayer() or ply:IsSuperAdmin() then return true end
		return ply.MBStaffLevel and ply:MBStaffLevel() >= clampInt(cfg.DailyQuestStaffLevel or 4, 1)
	end

	local function resolveTarget(argument, fallback)
		if trim(argument) == "" then return fallback end
		return MilBase.FindPlayer and MilBase.FindPlayer(argument) or nil
	end

	concommand.Add("mb_daily_reroll", function(actor, _, args)
		if not staffAllowed(actor) then return end
		local target = resolveTarget(table.concat(args or {}, " "), actor)
		local ok, err = MilBase.DailyQuestReroll(target, actor)
		if IsValid(actor) and not ok then MilBase.Notify(actor, err or "Unable to reroll daily orders.", "warn") end
	end)

	concommand.Add("mb_daily_reset", function(actor, _, args)
		if not staffAllowed(actor) then return end
		local target = resolveTarget(table.concat(args or {}, " "), actor)
		if not IsValid(target) then if IsValid(actor) then MilBase.Notify(actor, "Player not found.", "warn") end return end
		MilBase.DailyQuests.Players[target:SteamID64()] = nil
		createFreshState(target, 0)
		MilBase.Notify(target, "Your daily duty orders were reset by " .. (IsValid(actor) and actor:Nick() or "console") .. ".", "warn")
	end)

	net.Receive(NET_REQUEST, function(_, ply)
		if (ply.mb_nextDailyQuestRequest or 0) > CurTime() then return end
		ply.mb_nextDailyQuestRequest = CurTime() + 0.25
		MilBase.DailyQuestGetPayload(ply, function()
			if IsValid(ply) then sendSync(ply) end
		end)
	end)

	net.Receive(NET_CLAIM, function(_, ply)
		if (ply.mb_nextDailyQuestClaim or 0) > CurTime() then return end
		ply.mb_nextDailyQuestClaim = CurTime() + 0.4
		local ok, err = MilBase.DailyQuestClaim(ply, trim(net.ReadString()))
		if not ok then MilBase.Notify(ply, err or "Unable to claim that reward.", "warn") end
		sendSync(ply)
	end)

	local function openDailyOrders(ply)
		net.Start(NET_OPEN)
		net.Send(ply)
	end

	MilBase.RegisterChatCommand("daily", {
		help = "Open F4 Daily Orders.",
		func = openDailyOrders,
	})
	MilBase.RegisterChatCommand("quests", {
		help = "Open F4 Daily Orders.",
		func = openDailyOrders,
	})

	hook.Add("MilBase.PlayerLoaded", "MilBase.DailyQuests.Load", function(ply)
		timer.Simple(0, function() if IsValid(ply) then loadPlayer(ply) end end)
	end)
	hook.Add("PlayerInitialSpawn", "MilBase.DailyQuests.LoadFallback", function(ply)
		timer.Simple(5, function() if IsValid(ply) then loadPlayer(ply) end end)
	end)
	hook.Add("PlayerDisconnected", "MilBase.DailyQuests.Save", function(ply)
		saveState(ply, true)
		MilBase.DailyQuests.Players[ply:SteamID64()] = nil
	end)
	hook.Add("ShutDown", "MilBase.DailyQuests.SaveAll", function()
		for _, ply in ipairs(player.GetAll()) do saveState(ply, true) end
	end)

	timer.Create("MilBase.DailyQuests.Tick", math.max(10, clampInt(cfg.DailyQuestPlaytimeTickSeconds or 60, 10)), 0, function()
		for _, ply in ipairs(player.GetAll()) do
			if ply:Alive() and not ply:IsTimingOut() then
				MilBase.DailyQuestProgress(ply, "play_minutes", (cfg.DailyQuestPlaytimeTickSeconds or 60) / 60)
			else
				ensureCurrentDay(ply)
			end
		end
	end)

	timer.Create("MilBase.DailyQuests.Flush", math.max(5, clampInt(cfg.DailyQuestProgressSaveSeconds or 15, 5)), 0, function()
		for _, ply in ipairs(player.GetAll()) do
			local state = MilBase.DailyQuests.Players[ply:SteamID64()]
			if state and state.dirty then saveState(ply, false) end
		end
	end)

	local function resolveAttackerPlayer(attacker, inflictor)
		if IsValid(attacker) and attacker:IsPlayer() then return attacker end
		if IsValid(attacker) and attacker.GetDriver then
			local driver = attacker:GetDriver()
			if IsValid(driver) and driver:IsPlayer() then return driver end
		end
		for _, entity in ipairs({ attacker, inflictor }) do
			if IsValid(entity) and entity.GetOwner then
				local owner = entity:GetOwner()
				if IsValid(owner) and owner:IsPlayer() then return owner end
			end
		end
	end

	hook.Add("OnNPCKilled", "MilBase.DailyQuests.NPCKill", function(npc, attacker, inflictor)
		local ply = resolveAttackerPlayer(attacker, inflictor)
		if not IsValid(ply) then return end

		if cfg.DailyQuestCountSelfSpawnedNPCKills == false and IsValid(npc) and npc.GetCreator then
			local creator = npc:GetCreator()
			if IsValid(creator) and creator == ply then return end
		end

		if cfg.DailyQuestCountFriendlyNPCKills == false and IsValid(npc) and npc.Disposition then
			local ok, disposition = pcall(npc.Disposition, npc, ply)
			if ok and disposition == D_LI then return end
		end

		MilBase.DailyQuestProgress(ply, "combat_kills", 1)
	end)

	hook.Add("PlayerDeath", "MilBase.DailyQuests.EventEnemyKill", function(victim, inflictor, attacker)
		if not (MilBase.IsEventEnemy and MilBase.IsEventEnemy(victim)) then return end
		local ply = resolveAttackerPlayer(attacker, inflictor)
		if IsValid(ply) and ply ~= victim then MilBase.DailyQuestProgress(ply, "combat_kills", 1) end
	end)

	hook.Add("MilBase.PlayerHealed", "MilBase.DailyQuests.Healing", function(healer, patient, amount)
		if IsValid(healer) and healer ~= patient then
			MilBase.DailyQuestProgress(healer, "heal_points", math.max(1, tonumber(amount or 0) or 0))
		end
	end)

	hook.Add("MilBase.EngineeringRepairCompleted", "MilBase.DailyQuests.Repairs", function(engineer, _, amount, action)
		if IsValid(engineer) and action == "repair" then
			MilBase.DailyQuestProgress(engineer, "repair_points", math.max(1, tonumber(amount or 0) or 0))
		end
	end)

	hook.Add("MilBase.ObjectiveCompleted", "MilBase.DailyQuests.Objectives", function(objective)
		for _, ply in ipairs(player.GetAll()) do
			if ply:Alive() and (not objective.faction or objective.faction == "" or objective.faction == "all" or ply:MBFactionID() == objective.faction) then
				MilBase.DailyQuestProgress(ply, "objectives", 1)
			end
		end
	end)
else
	MilBase.DailyQuests.ClientState = MilBase.DailyQuests.ClientState or {
		loaded = false,
		day = MilBase.DailyQuestDayKey(),
		reset_in = MilBase.DailyQuestSecondsUntilReset(),
		quests = {},
	}

	net.Receive(NET_SYNC, function()
		local payload = net.ReadTable() or MilBase.DailyQuests.ClientState
		payload.received_at = RealTime()
		MilBase.DailyQuests.ClientState = payload
		hook.Run("MilBase.DailyQuestsUpdated", payload)
	end)

	net.Receive(NET_NOTICE, function()
		local kind = net.ReadString()
		local text = net.ReadString()
		if MilBase.Notify then MilBase.Notify(text, kind == "complete" and "ok" or "info") end
		hook.Run("MilBase.DailyQuestNotice", kind, text)
	end)

	function MilBase.DailyQuestClientPayload()
		local payload = table.Copy(MilBase.DailyQuests.ClientState or {})
		payload.reset_in = math.max(0, clampInt(payload.reset_in or 0, 0) - math.floor(RealTime() - (payload.received_at or RealTime())))
		return payload
	end

	local function requestDailyState()
		net.Start(NET_REQUEST)
		net.SendToServer()
	end

	local function claimDailyReward(id)
		net.Start(NET_CLAIM)
			net.WriteString(tostring(id or ""))
		net.SendToServer()
	end

	net.Receive(NET_OPEN, function()
		if MilBase.OpenMenu then MilBase.OpenMenu("DAILY ORDERS") end
	end)

	local function resetText(seconds)
		seconds = math.max(0, math.floor(tonumber(seconds or 0) or 0))
		local hours = math.floor(seconds / 3600)
		local minutes = math.floor((seconds % 3600) / 60)
		return string.format("%02dh %02dm", hours, minutes)
	end

	local function rewardText(quest)
		local rewards = {}
		if tonumber(quest.reward_xp or 0) > 0 then rewards[#rewards + 1] = tostring(quest.reward_xp) .. " XP" end
		if tonumber(quest.reward_credits or 0) > 0 then
			rewards[#rewards + 1] = tostring(cfg.CurrencySymbol or "CR ") .. tostring(quest.reward_credits)
		end
		if trim(quest.reward_item) ~= "" then
			local item = MilBase.Items and MilBase.Items[quest.reward_item]
			rewards[#rewards + 1] = tostring(quest.reward_item_amount or 1) .. "x "
				.. ((item and item.name) or tostring(quest.reward_item))
		end
		return #rewards > 0 and table.concat(rewards, "  •  ") or "Completion recorded"
	end

	local function buildDailyOrdersTab(content)
		local ui = MilBase.UI
		local host = vgui.Create("DPanel", content)
		host:Dock(FILL)
		host.Paint = nil
		local hookID = "MilBase.DailyOrdersF4." .. tostring(host)

		local function render(payload)
			if not IsValid(host) then return end
			host:Clear()
			payload = payload or MilBase.DailyQuestClientPayload()
			local scroll = vgui.Create("DScrollPanel", host)
			scroll:Dock(FILL)

			local header = vgui.Create("DPanel", scroll)
			header:Dock(TOP)
			header:SetTall(118)
			header:DockMargin(0, 0, 8, 12)
			local receivedAt = payload.received_at or RealTime()
			header.Paint = function(_, w, h)
				MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, accent = ui.accent })
				draw.SimpleText("DAILY DUTY ORDERS", "MB.Big", 20, 17, ui.text)
				draw.SimpleText("Complete your assigned duties and claim each reward before the daily reset.",
					"MB.Small", 20, 55, ui.dim)
				draw.SimpleText("ORDER DATE  " .. tostring(payload.day or ""), "MB.Tiny", 20, 84, ui.faint)
				local remaining = math.max(0, (tonumber(payload.reset_in or 0) or 0) - (RealTime() - receivedAt))
				draw.SimpleText("RESET IN  " .. resetText(remaining), "MB.Med", w - 20, 24,
					ui.accent, TEXT_ALIGN_RIGHT)
			end

			if payload.disabled then
				local panel = vgui.Create("DPanel", scroll)
				panel:Dock(TOP); panel:SetTall(92); panel:DockMargin(0, 0, 8, 8)
				panel.Paint = function(_, w, h)
					MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = ui.danger })
					draw.SimpleText("DAILY ORDERS DISABLED", "MB.Med", 18, h / 2, ui.danger,
						TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				return
			end

			if not payload.loaded then
				local panel = vgui.Create("DPanel", scroll)
				panel:Dock(TOP); panel:SetTall(92); panel:DockMargin(0, 0, 8, 8)
				panel.Paint = function(_, w, h)
					MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = ui.warn })
					draw.SimpleText("LOADING PERSONAL ORDERS…", "MB.Med", 18, h / 2, ui.warn,
						TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				return
			end

			if #(payload.quests or {}) == 0 then
				local panel = vgui.Create("DPanel", scroll)
				panel:Dock(TOP); panel:SetTall(100); panel:DockMargin(0, 0, 8, 8)
				panel.Paint = function(_, w, h)
					MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8 })
					draw.SimpleText("NO ORDERS ASSIGNED", "MB.Med", 18, 30, ui.dim)
					draw.SimpleText("Ask staff to run mb_daily_reset if this persists.", "MB.Small", 18, 62, ui.faint)
				end
				return
			end

			for _, quest in ipairs(payload.quests or {}) do
				local accent = IsColor(quest.color) and quest.color or ui.accent
				local target = math.max(1, tonumber(quest.target or 1) or 1)
				local progress = math.Clamp(tonumber(quest.progress or 0) or 0, 0, target)
				local complete = quest.complete == true or progress >= target
				local claimed = quest.claimed == true
				local panel = vgui.Create("DPanel", scroll)
				panel:Dock(TOP)
				panel:SetTall(164)
				panel:DockMargin(0, 0, 8, 10)
				local claim
				panel.Paint = function(_, w, h)
					local statusColor = claimed and ui.faint or (complete and ui.ok or accent)
					MilBase.DrawPanelBF2(0, 0, w, h, { cut = 9, accent = statusColor })
					draw.SimpleText(string.upper(quest.name or "DAILY ORDER"), "MB.Med", 18, 15, ui.text)
					draw.SimpleText(quest.description or "", "MB.Small", 18, 45, ui.dim)
					local status = claimed and "REWARD CLAIMED" or (complete and "ORDER COMPLETE"
						or (math.floor(progress) .. " / " .. math.floor(target)))
					draw.SimpleText(status, "MB.Small", 18, 78, statusColor)
					MilBase.DrawBar(18, 105, math.max(100, w - 36), 8, progress / target, statusColor)
					draw.SimpleText("REWARD  " .. rewardText(quest), "MB.Tiny", 18, 130, ui.dim)
				end
				if complete and not claimed then
					claim = vgui.Create("DButton", panel)
					claim:SetText("CLAIM REWARD")
					claim:SetSize(160, 36)
					claim.DoClick = function()
						claim:SetEnabled(false)
						claimDailyReward(quest.id)
					end
					panel.PerformLayout = function(_, w, h) claim:SetPos(w - 178, h - 47) end
				end
			end
		end

		hook.Add("MilBase.DailyQuestsUpdated", hookID, render)
		host.OnRemove = function() hook.Remove("MilBase.DailyQuestsUpdated", hookID) end
		render(MilBase.DailyQuestClientPayload())
		requestDailyState()
	end

	if cfg.DailyQuestF4TabEnabled ~= false and MilBase.AddMenuTab then
		MilBase.AddMenuTab("DAILY ORDERS", 30, buildDailyOrdersTab, function()
			return cfg.DailyQuestsEnabled ~= false
		end)
	end
end
