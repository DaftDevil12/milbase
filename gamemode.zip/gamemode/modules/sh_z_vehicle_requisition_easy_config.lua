--[[
    Vehicle Requisition Easy Config layer.

    Adds an easier staff configuration UI on top of sh_vehicle_requisition.lua:
    setup wizard, auto-detect, reference dropdowns, warnings, permission tester,
    terminal filters, presets, backups, and live reload.
]]

MilBase.VehicleReq = MilBase.VehicleReq or {}
local VR = MilBase.VehicleReq

local NET_OPEN = "MilBase_VehicleReq_EasyConfigOpen"
local NET_ACTION = "MilBase_VehicleReq_EasyConfigAction"

local function trim(v)
    return string.Trim(tostring(v or ""))
end

local function lower(v)
    return string.lower(trim(v))
end

local function splitList(value)
    local out = {}
    value = trim(value)
    if value == "" then return out end
    for part in string.gmatch(value, "([^,;|]+)") do
        part = trim(part)
        if part ~= "" then out[#out + 1] = part end
    end
    return out
end

local function listHas(listText, candidates)
    local list = splitList(listText)
    if #list == 0 then return true end

    local wanted = {}
    for _, c in ipairs(candidates or {}) do
        c = lower(c)
        if c ~= "" then wanted[c] = true end
    end

    for _, token in ipairs(list) do
        token = lower(token)
        if token == "*" or token == "all" or wanted[token] then return true end
    end
    return false
end

local function vehicleTokens(v)
    if not v then return {} end
    return { tostring(v.id or ""), v.name or "", v.entityClass or "", v.category or "" }
end

local function spawnTokens(sp)
    if not sp then return {} end
    return { tostring(sp.id or ""), sp.name or "" }
end

local function notify(ply, msg, kind)
    if MilBase and MilBase.Notify then MilBase.Notify(ply, msg, kind or "ok") end
end

local function canConfigure(ply)
    if game.SinglePlayer() then return true end
    if not IsValid(ply) then return false end
    if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
    return VR.CanStaffConfigure and VR.CanStaffConfigure(ply)
end

-- Terminal filters are saved as settings but applied here so the original
-- terminal code does not need to know about every UI option.
if not VR.EasyTerminalFiltersWrapped then
    VR.EasyTerminalFiltersWrapped = true

    local baseBuildTerminalData = VR.BuildTerminalData
    VR.BuildTerminalData = function(ply)
        local data = baseBuildTerminalData and baseBuildTerminalData(ply) or { vehicles = {}, spawns = {} }
        local s = VR.Settings or {}
        data.terminalName = trim(s.terminal_name) ~= "" and trim(s.terminal_name) or "Vehicle Requisition Terminal"
        data.terminalHelp = trim(s.terminal_help) ~= "" and trim(s.terminal_help) or "Select a vehicle, spawn, and mission reason."

        local allowedVehicleText = trim(s.terminal_allowed_vehicles)
        if allowedVehicleText ~= "" then
            local filtered = {}
            for _, vehicle in ipairs(data.vehicles or {}) do
                if listHas(allowedVehicleText, vehicleTokens(vehicle)) then filtered[#filtered + 1] = vehicle end
            end
            data.vehicles = filtered
        end

        local allowedSpawnText = trim(s.terminal_allowed_spawns)
        if allowedSpawnText ~= "" then
            local filtered = {}
            for _, spawn in ipairs(data.spawns or {}) do
                if listHas(allowedSpawnText, spawnTokens(spawn)) then filtered[#filtered + 1] = spawn end
            end
            data.spawns = filtered
        end

        local allowedFactionText = trim(s.terminal_allowed_factions)
        if allowedFactionText ~= "" and IsValid(ply) then
            local faction = ply.MBFaction and ply:MBFaction() or nil
            local factionID = ply.MBFactionID and ply:MBFactionID() or ""
            if not listHas(allowedFactionText, { factionID, faction and faction.name or "" }) then
                data.terminalBlocked = true
                data.blockReason = "Your faction cannot use this terminal."
                data.vehicles = {}
                data.spawns = {}
            end
        end

        return data
    end
end

if SERVER and not VR.EasyTerminalSubmitWrapped and VR.SubmitRequest then
    VR.EasyTerminalSubmitWrapped = true
    local baseSubmitRequest = VR.SubmitRequest
    VR.SubmitRequest = function(ply, vehicleID, spawnID, reason)
        local s = VR.Settings or {}
        local vehicle = VR.GetVehicle and VR.GetVehicle(vehicleID) or nil
        local spawn = VR.GetSpawn and VR.GetSpawn(spawnID) or nil
        if trim(s.terminal_allowed_factions) ~= "" and IsValid(ply) then
            local faction = ply.MBFaction and ply:MBFaction() or nil
            local factionID = ply.MBFactionID and ply:MBFactionID() or ""
            if not listHas(s.terminal_allowed_factions, { factionID, faction and faction.name or "" }) then
                notify(ply, "Your faction cannot use this terminal.", "warn")
                return false
            end
        end
        if trim(s.terminal_allowed_vehicles) ~= "" and not listHas(s.terminal_allowed_vehicles, vehicleTokens(vehicle)) then
            notify(ply, "This terminal does not allow that vehicle.", "warn")
            return false
        end
        if trim(s.terminal_allowed_spawns) ~= "" and not listHas(s.terminal_allowed_spawns, spawnTokens(spawn)) then
            notify(ply, "This terminal does not allow that spawn.", "warn")
            return false
        end
        return baseSubmitRequest(ply, vehicleID, spawnID, reason)
    end
end

if SERVER then
    util.AddNetworkString(NET_OPEN)
    util.AddNetworkString(NET_ACTION)

    if not VR.EasySuppressOldAdminWrapped and VR.OpenAdminMenu then
        VR.EasySuppressOldAdminWrapped = true
        local baseOpenAdminMenu = VR.OpenAdminMenu
        VR.OpenAdminMenu = function(ply)
            if VR.EasySuppressOldAdmin == ply then return end
            return baseOpenAdminMenu(ply)
        end
    end

    local function withSuppressedOldAdmin(ply, fn)
        VR.EasySuppressOldAdmin = ply
        local ok, err = pcall(fn)
        timer.Simple(0.5, function()
            if VR.EasySuppressOldAdmin == ply then VR.EasySuppressOldAdmin = nil end
        end)
        if not ok then ErrorNoHalt("[VehicleReq EasyConfig] " .. tostring(err) .. "\n") end
        return ok
    end

    local function sqlText(v) return MilBase.SQLStr(trim(v)) end
    local function sqlInt(v) return math.floor(tonumber(v or 0) or 0) end
    local function activeInt(v) if v == false or v == 0 or v == "0" then return 0 end return 1 end
    local backupDir = "milbase/vehicle_req_backups"

    local extraSettings = {
        terminal_name = "Vehicle Requisition Terminal",
        terminal_help = "Select a vehicle, spawn, and mission reason.",
        terminal_allowed_vehicles = "",
        terminal_allowed_spawns = "",
        terminal_allowed_factions = "",
    }

    local function syncTerminalGlobals()
        local s = VR.Settings or {}
        SetGlobalString("mb_vreq_terminal_name", trim(s.terminal_name) ~= "" and trim(s.terminal_name) or extraSettings.terminal_name)
        SetGlobalString("mb_vreq_terminal_help", trim(s.terminal_help) ~= "" and trim(s.terminal_help) or extraSettings.terminal_help)
    end

    hook.Add("InitPostEntity", "MilBase.VehicleReq.EasyTerminalGlobals", function()
        timer.Simple(1, syncTerminalGlobals)
    end)
    hook.Add("MilBase.DBReady", "MilBase.VehicleReq.EasyTerminalGlobals", function()
        timer.Simple(1, syncTerminalGlobals)
    end)

    local function saveSetting(key, value)
        VR.Settings = VR.Settings or table.Copy(VR.DefaultSettings or {})
        VR.Settings[key] = trim(value)
        MilBase.DB.Run(string.format(
            "REPLACE INTO frontier_vehicle_req_settings (setting_key, setting_value) VALUES (%s, %s)",
            MilBase.SQLStr(key), MilBase.SQLStr(trim(value))
        ))
    end

    local function saveEasySettings(ply, data)
        data = istable(data) and data or {}
        for key, fallback in pairs(extraSettings) do
            saveSetting(key, data[key] ~= nil and data[key] or fallback)
        end
        syncTerminalGlobals()
        notify(ply, "Terminal configuration saved.", "ok")
        VR.EasyOpen(ply)
    end

    local function vehicleMatchesSpawn(v, sp)
        if not sp then return false end
        local rule = trim(sp.vehicles)
        if rule == "" then return true end
        return listHas(rule, vehicleTokens(v))
    end

    local function collectWarnings()
        local warnings = {}
        local vehicleCount, spawnCount = 0, 0

        for _, v in pairs(VR.Vehicles or {}) do
            vehicleCount = vehicleCount + 1
            if trim(v.name) == "" then warnings[#warnings + 1] = { level = "warn", text = "A vehicle has no display name." } end
            if trim(v.entityClass) == "" then
                warnings[#warnings + 1] = { level = "danger", text = "Vehicle '" .. tostring(v.name or v.id) .. "' has no entity class." }
            end
            if tonumber(v.active or 1) == 0 then
                warnings[#warnings + 1] = { level = "info", text = "Vehicle '" .. tostring(v.name or v.id) .. "' is disabled." }
            else
                local hasSpawn = false
                for _, sp in pairs(VR.Spawns or {}) do
                    if tonumber(sp.active or 1) == 1 and vehicleMatchesSpawn(v, sp) then hasSpawn = true break end
                end
                if not hasSpawn then
                    warnings[#warnings + 1] = { level = "danger", text = "Vehicle '" .. tostring(v.name or v.id) .. "' has no active allowed spawn." }
                end
            end
        end

        for _, sp in pairs(VR.Spawns or {}) do
            spawnCount = spawnCount + 1
            if trim(sp.name) == "" then warnings[#warnings + 1] = { level = "warn", text = "A spawn has no name." } end
            if tonumber(sp.active or 1) == 0 then
                warnings[#warnings + 1] = { level = "info", text = "Spawn '" .. tostring(sp.name or sp.id) .. "' is disabled." }
            end
            local vehRule = splitList(sp.vehicles)
            if #vehRule > 0 then
                for _, token in ipairs(vehRule) do
                    local found = false
                    for _, v in pairs(VR.Vehicles or {}) do
                        if listHas(token, vehicleTokens(v)) then found = true break end
                    end
                    if not found then
                        warnings[#warnings + 1] = { level = "warn", text = "Spawn '" .. tostring(sp.name or sp.id) .. "' allows unknown vehicle token '" .. token .. "'." }
                    end
                end
            end
        end

        if vehicleCount == 0 then warnings[#warnings + 1] = { level = "danger", text = "No vehicles are configured yet." } end
        if spawnCount == 0 then warnings[#warnings + 1] = { level = "danger", text = "No vehicle spawns are configured yet. Use the Toolgun or Spawns tab." } end
        if #warnings == 0 then warnings[#warnings + 1] = { level = "ok", text = "No configuration warnings found." } end
        return warnings
    end

    local function collectRefs()
        local refs = { factions = {}, certs = {}, rankGroups = {}, players = {}, categories = {} }
        refs.rankGroups = {
            { id = "trooper", name = "Trooper / Enlisted" },
            { id = "nco", name = "NCO" },
            { id = "officer", name = "Officer" },
            { id = "commander", name = "Commander" },
        }

        if MilBase.FactionOrder then
            for _, id in ipairs(MilBase.FactionOrder) do
                local faction = MilBase.GetFaction and MilBase.GetFaction(id) or (MilBase.Factions and MilBase.Factions[id])
                refs.factions[#refs.factions + 1] = { id = id, name = (faction and faction.name) or id }
            end
        elseif MilBase.Factions then
            for id, faction in pairs(MilBase.Factions) do
                refs.factions[#refs.factions + 1] = { id = id, name = (faction and faction.name) or id }
            end
        end

        if MilBase.CertOrder then
            for _, id in ipairs(MilBase.CertOrder) do
                local cert = MilBase.Certs and MilBase.Certs[id]
                refs.certs[#refs.certs + 1] = { id = id, name = (cert and cert.name) or id }
            end
        elseif MilBase.Certs then
            for id, cert in pairs(MilBase.Certs) do
                refs.certs[#refs.certs + 1] = { id = id, name = (cert and cert.name) or id }
            end
        end

        local seenCats = {}
        for _, v in pairs(VR.Vehicles or {}) do
            local cat = trim(v.category)
            if cat ~= "" and not seenCats[lower(cat)] then
                seenCats[lower(cat)] = true
                refs.categories[#refs.categories + 1] = cat
            end
        end
        table.sort(refs.categories)

        for _, p in ipairs(player.GetAll()) do
            refs.players[#refs.players + 1] = { name = p:Nick(), rpName = p.MBName and p:MBName() or p:Nick(), steamid = p:SteamID64() }
        end
        table.sort(refs.players, function(a, b) return lower(a.rpName) < lower(b.rpName) end)

        return refs
    end

    local function collectBackups()
        file.CreateDir(backupDir)
        local files = file.Find(backupDir .. "/*.json", "DATA") or {}
        table.sort(files, function(a, b) return a > b end)
        local out = {}
        for _, name in ipairs(files) do
            out[#out + 1] = { name = name, path = backupDir .. "/" .. name }
        end
        return out
    end

    local function buildEasyData(extra)
        local data = VR.AdminData and VR.AdminData() or { settings = {}, vehicles = {}, spawns = {} }
        data.refs = collectRefs()
        data.warnings = collectWarnings()
        data.backups = collectBackups()
        data.presets = {
            { id = "pilot", name = "Pilot Vehicle", category = "Air", certs = "Pilot", rankGroups = "", factions = "", minRank = 0 },
            { id = "navy", name = "Republic Navy Vehicle", category = "Navy", certs = "Pilot", rankGroups = "", factions = "Republic Navy", minRank = 0 },
            { id = "officer", name = "Officer Vehicle", category = "Officer", certs = "", rankGroups = "officer,commander", factions = "", minRank = 0 },
            { id = "event", name = "Event Vehicle", category = "Event", certs = "", rankGroups = "", factions = "", minRank = 0 },
            { id = "ground", name = "Ground Vehicle", category = "Ground", certs = "Driver", rankGroups = "", factions = "", minRank = 0 },
        }
        if istable(extra) then
            for k, v in pairs(extra) do data[k] = v end
        end
        return data
    end

    function VR.EasyOpen(ply, extra)
        if not canConfigure(ply) then notify(ply, "Staff only.", "warn") return end
        net.Start(NET_OPEN)
            net.WriteTable(buildEasyData(extra))
        net.Send(ply)
    end

    local function detectLookedVehicle(ply)
        local tr = ply:GetEyeTrace()
        local ent = tr and tr.Entity
        if not IsValid(ent) or ent:IsPlayer() or ent:GetClass() == "worldspawn" then
            return nil, "Look at a spawned vehicle/entity first."
        end

        local class = ent:GetClass()
        local nice = class:gsub("^gmod_", ""):gsub("^lvs_", ""):gsub("^sw_", ""):gsub("_", " ")
        nice = string.Trim(string.upper(string.sub(nice, 1, 1)) .. string.sub(nice, 2))
        return {
            name = nice ~= "" and nice or class,
            entityClass = class,
            category = ent:IsVehicle() and "Ground" or "General",
            model = ent:GetModel() or "",
        }
    end

    local function playerBySearch(value)
        value = lower(value)
        if value == "" then return nil end
        for _, p in ipairs(player.GetAll()) do
            if lower(p:SteamID64()) == value or lower(p:Nick()) == value or (p.MBName and lower(p:MBName()) == value) then return p end
        end
        for _, p in ipairs(player.GetAll()) do
            if string.find(lower(p:Nick()), value, 1, true) or (p.MBName and string.find(lower(p:MBName()), value, 1, true)) then return p end
        end
    end

    local function permissionTest(ply, data)
        data = istable(data) and data or {}
        local target = playerBySearch(data.player or "")
        local vehicle = VR.GetVehicle and VR.GetVehicle(data.vehicleID) or nil
        local spawn = VR.GetSpawn and VR.GetSpawn(data.spawnID) or nil
        local result = { ok = false, lines = {} }

        if not IsValid(target) then
            result.lines[#result.lines + 1] = { ok = false, text = "Player not found." }
            return result
        end
        if not vehicle then
            result.lines[#result.lines + 1] = { ok = false, text = "Vehicle not found." }
            return result
        end
        if not spawn then
            result.lines[#result.lines + 1] = { ok = false, text = "Spawn not found." }
            return result
        end

        result.player = target.MBName and target:MBName() or target:Nick()
        result.vehicle = vehicle.name
        result.spawn = spawn.name

        local ok, reason = VR.CanUseVehicle(target, vehicle)
        result.lines[#result.lines + 1] = { ok = ok, text = ok and "Player can use this vehicle." or ("Vehicle denied: " .. tostring(reason)) }
        local ok2, reason2 = VR.CanUseSpawn(target, spawn, vehicle)
        result.lines[#result.lines + 1] = { ok = ok2, text = ok2 and "Player can use this spawn." or ("Spawn denied: " .. tostring(reason2)) }
        result.ok = ok and ok2
        if result.ok then result.lines[#result.lines + 1] = { ok = true, text = "Final result: request would be allowed." } end
        return result
    end

    local function backupPayload()
        local vehicles, spawns, terminals = {}, {}, {}
        for _, v in pairs(VR.Vehicles or {}) do vehicles[#vehicles + 1] = table.Copy(v) end
        for _, sp in pairs(VR.Spawns or {}) do
            local copy = table.Copy(sp)
            copy.pos = util.TypeToString(sp.pos or vector_origin)
            copy.ang = util.TypeToString(sp.ang or angle_zero)
            spawns[#spawns + 1] = copy
        end
        for _, terminal in pairs(VR.Terminals or {}) do
            local copy = table.Copy(terminal)
            copy.ent = nil
            copy.pos = util.TypeToString(terminal.pos or vector_origin)
            copy.ang = util.TypeToString(terminal.ang or angle_zero)
            terminals[#terminals + 1] = copy
        end
        return {
            created = os.time(),
            map = game.GetMap(),
            settings = table.Copy(VR.Settings or {}),
            vehicles = vehicles,
            spawns = spawns,
            terminals = terminals,
        }
    end

    local function createBackup(ply)
        file.CreateDir(backupDir)
        local name = os.date("%Y%m%d_%H%M%S") .. "_" .. game.GetMap() .. ".json"
        file.Write(backupDir .. "/" .. name, util.TableToJSON(backupPayload(), true) or "{}")
        notify(ply, "Backup created: " .. name, "ok")
        VR.EasyOpen(ply)
    end

    local function restoreBackup(ply, name)
        name = string.GetFileFromFilename(trim(name))
        if name == "" then notify(ply, "Select a backup first.", "warn") return end
        local raw = file.Read(backupDir .. "/" .. name, "DATA")
        if not raw then notify(ply, "Backup not found.", "warn") return end
        local data = util.JSONToTable(raw or "")
        if not istable(data) then notify(ply, "Backup is invalid.", "danger") return end

        MilBase.DB.Run("DELETE FROM frontier_vehicle_req_settings")
        MilBase.DB.Run("DELETE FROM frontier_vehicle_req_vehicles")
        MilBase.DB.Run("DELETE FROM frontier_vehicle_req_spawns WHERE map = " .. MilBase.SQLStr(game.GetMap()))
        MilBase.DB.Run("DELETE FROM frontier_vehicle_req_terminals WHERE map = " .. MilBase.SQLStr(game.GetMap()))

        for key, value in pairs(data.settings or {}) do
            MilBase.DB.Run(string.format("REPLACE INTO frontier_vehicle_req_settings (setting_key, setting_value) VALUES (%s, %s)", MilBase.SQLStr(key), MilBase.SQLStr(tostring(value or ""))))
        end

        for _, v in ipairs(data.vehicles or {}) do
            MilBase.DB.Run(string.format(
                "INSERT INTO frontier_vehicle_req_vehicles (name, entity_class, category, factions, certs, require_all, min_rank, max_rank, rank_groups, active) VALUES (%s, %s, %s, %s, %s, %d, %d, %d, %s, %d)",
                sqlText(v.name), sqlText(v.entityClass), sqlText(v.category), sqlText(v.factions), sqlText(v.certs), sqlInt(v.requireAll), sqlInt(v.minRank), sqlInt(v.maxRank), sqlText(v.rankGroups), activeInt(v.active)
            ))
        end

        for _, sp in ipairs(data.spawns or {}) do
            local pos = isvector(sp.pos) and sp.pos or util.StringToType(tostring(sp.pos or ""), "Vector")
            local ang = isangle(sp.ang) and sp.ang or util.StringToType(tostring(sp.ang or ""), "Angle")
            if not isvector(pos) then pos = vector_origin end
            if not isangle(ang) then ang = angle_zero end
            MilBase.DB.Run(string.format(
                "INSERT INTO frontier_vehicle_req_spawns (map, name, pos, ang, vehicles, factions, certs, require_all, min_rank, max_rank, rank_groups, active) VALUES (%s, %s, %s, %s, %s, %s, %s, %d, %d, %d, %s, %d)",
                MilBase.SQLStr(game.GetMap()), sqlText(sp.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), sqlText(sp.vehicles), sqlText(sp.factions), sqlText(sp.certs), sqlInt(sp.requireAll), sqlInt(sp.minRank), sqlInt(sp.maxRank), sqlText(sp.rankGroups), activeInt(sp.active)
            ))
        end

        for _, terminal in ipairs(data.terminals or {}) do
            local pos = isvector(terminal.pos) and terminal.pos or util.StringToType(tostring(terminal.pos or ""), "Vector")
            local ang = isangle(terminal.ang) and terminal.ang or util.StringToType(tostring(terminal.ang or ""), "Angle")
            if not isvector(pos) then pos = vector_origin end
            if not isangle(ang) then ang = angle_zero end
            MilBase.DB.Run(string.format(
                "INSERT INTO frontier_vehicle_req_terminals (map, name, pos, ang, active) VALUES (%s, %s, %s, %s, %d)",
                MilBase.SQLStr(game.GetMap()), sqlText(terminal.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), activeInt(terminal.active)
            ))
        end

        timer.Simple(0.25, function()
            if VR.ReloadAll then VR.ReloadAll(function()
                if IsValid(ply) then syncTerminalGlobals(); notify(ply, "Backup restored and reloaded.", "ok"); VR.EasyOpen(ply) end
            end) end
        end)
    end

    local function bulkVehicleUpdate(ply, data)
        data = istable(data) and data or {}
        local category = trim(data.category)
        if category == "" then notify(ply, "Choose a category to bulk edit.", "warn") return end
        local count = 0
        for id, v in pairs(VR.Vehicles or {}) do
            if lower(v.category) == lower(category) then
                local update = table.Copy(v)
                if data.factions ~= nil then update.factions = trim(data.factions) end
                if data.certs ~= nil then update.certs = trim(data.certs) end
                if data.rankGroups ~= nil then update.rankGroups = trim(data.rankGroups) end
                if data.minRank ~= nil then update.minRank = sqlInt(data.minRank) end
                if data.maxRank ~= nil then update.maxRank = sqlInt(data.maxRank) end
                withSuppressedOldAdmin(ply, function() VR.UpdateVehicle(ply, id, update) end)
                count = count + 1
            end
        end
        notify(ply, "Bulk updated " .. count .. " vehicle(s).", "ok")
        VR.EasyOpen(ply)
    end

    net.Receive(NET_ACTION, function(_, ply)
        if not canConfigure(ply) then return end
        local action = net.ReadString()
        local data = net.ReadTable() or {}

        if action == "open" or action == "reload" then
            if action == "reload" and VR.ReloadAll then
                VR.ReloadAll(function() if IsValid(ply) then notify(ply, "Vehicle requisition config reloaded.", "ok") VR.EasyOpen(ply) end end)
            else
                VR.EasyOpen(ply)
            end
        elseif action == "settings" then
            if VR.SaveSettings then withSuppressedOldAdmin(ply, function() VR.SaveSettings(ply, data) end) else VR.EasyOpen(ply) end
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "terminal_settings" then
            saveEasySettings(ply, data)
        elseif action == "vehicle_add" then
            withSuppressedOldAdmin(ply, function() VR.AddVehicle(ply, data) end)
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "vehicle_update" then
            withSuppressedOldAdmin(ply, function() VR.UpdateVehicle(ply, data.id, data) end)
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "vehicle_delete" then
            withSuppressedOldAdmin(ply, function() VR.DeleteVehicle(ply, data.id) end)
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "spawn_update" then
            withSuppressedOldAdmin(ply, function() VR.UpdateSpawn(ply, data.id, data) end)
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "spawn_delete" then
            withSuppressedOldAdmin(ply, function() VR.DeleteSpawn(ply, data.id) end)
            timer.Simple(0.15, function() if IsValid(ply) then VR.EasyOpen(ply) end end)
        elseif action == "detect_vehicle" then
            local detected, err = detectLookedVehicle(ply)
            if not detected then notify(ply, err or "Could not detect entity.", "warn") end
            VR.EasyOpen(ply, { detectedVehicle = detected })
        elseif action == "permission_test" then
            VR.EasyOpen(ply, { permissionTest = permissionTest(ply, data) })
        elseif action == "backup_create" then
            createBackup(ply)
        elseif action == "backup_restore" then
            restoreBackup(ply, data.name)
        elseif action == "bulk_vehicle_update" then
            bulkVehicleUpdate(ply, data)
        end
    end)

    MilBase.RegisterChatCommand("vehreqconfig", {
        help = "Open the easy Vehicle Requisition setup menu.",
        func = function(ply) VR.EasyOpen(ply) end,
    })
    MilBase.RegisterChatCommand("vehreqsetup", {
        help = "Open the easy Vehicle Requisition setup wizard.",
        func = function(ply) VR.EasyOpen(ply) end,
    })
    MilBase.RegisterChatCommand("vehreqeasy", {
        help = "Open the easy Vehicle Requisition setup menu.",
        func = function(ply) VR.EasyOpen(ply) end,
    })

    concommand.Add("mb_vehicle_req_easy_config", function(ply)
        if IsValid(ply) then VR.EasyOpen(ply) end
    end)

    return
end

------------------------------------------------------------------------
-- Client UI
------------------------------------------------------------------------

local function ui()
    return (MilBase and MilBase.UI) or {
        bg = Color(6, 6, 7, 240), panel = Color(10, 10, 11, 218), raised = Color(255, 198, 60, 10),
        hover = Color(255, 198, 60, 25), outline = Color(255, 198, 60, 50), accent = Color(255, 198, 60),
        text = Color(240, 238, 230), dim = Color(170, 162, 140), faint = Color(112, 106, 92), ok = Color(150, 205, 125), danger = Color(220, 80, 70), warn = Color(255, 215, 135),
    }
end

local function font(name, fallback)
    return (MilBase and MilBase.UI and name) or fallback or "DermaDefault"
end

local function drawPanel(x, y, w, h, opts)
    if MilBase and MilBase.DrawPanelBF2 then
        MilBase.DrawPanelBF2(x, y, w, h, opts)
    else
        surface.SetDrawColor((opts and opts.color) or ui().panel)
        surface.DrawRect(x, y, w, h)
        surface.SetDrawColor((opts and opts.outlineColor) or ui().outline)
        surface.DrawOutlinedRect(x, y, w, h)
    end
end

local function play(id)
    if MilBase and MilBase.PlayUISound then MilBase.PlayUISound(id) end
end

local function writeEasy(action, data)
    net.Start(NET_ACTION)
        net.WriteString(action)
        net.WriteTable(data or {})
    net.SendToServer()
end

local function styledButton(parent, text, color, click)
    local b = vgui.Create("DButton", parent)
    b:SetText("")
    b.DoClick = function()
        play("select")
        if click then click(b) end
    end
    b.Paint = function(self, w, h)
        local c = color or ui().accent
        drawPanel(0, 0, w, h, { cut = 8, color = self:IsHovered() and Color(c.r, c.g, c.b, 42) or ui().raised, accent = c })
        draw.SimpleText(text, font("MB.Tab", "DermaDefaultBold"), w / 2, h / 2, ui().text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    return b
end

local function addLabel(parent, text, x, y, w)
    local l = vgui.Create("DLabel", parent)
    l:SetText(text)
    l:SetFont(font("MB.Tiny", "DermaDefaultBold"))
    l:SetTextColor(ui().accent)
    l:SetPos(x, y)
    l:SetSize(w or 160, 18)
    return l
end

local function addEntry(parent, x, y, w, value)
    local e = vgui.Create("DTextEntry", parent)
    e:SetPos(x, y)
    e:SetSize(w, 24)
    e:SetText(tostring(value or ""))
    return e
end

local function addCheck(parent, text, x, y, checked)
    local c = vgui.Create("DCheckBoxLabel", parent)
    c:SetText(text)
    c:SetTextColor(ui().text)
    c:SetPos(x, y)
    c:SetValue(checked and 1 or 0)
    c:SizeToContents()
    return c
end

local function choiceText(name, id)
    if trim(id) == "" then return name end
    return tostring(name) .. "  [" .. tostring(id) .. "]"
end

local function selectedLine(list)
    local line = list:GetSelectedLine()
    return line and list:GetLine(line) or nil
end

local function setEntryAppend(entry, token)
    token = trim(token)
    if token == "" then return end
    local cur = trim(entry:GetValue())
    if cur == "" then entry:SetText(token) return end
    for _, part in ipairs(splitList(cur)) do
        if lower(part) == lower(token) then return end
    end
    entry:SetText(cur .. "," .. token)
end

local function addRefPicker(parent, refs, x, y, label, entry)
    addLabel(parent, label, x, y, 210)
    local combo = vgui.Create("DComboBox", parent)
    combo:SetPos(x, y + 22)
    combo:SetSize(210, 24)
    combo:SetValue("Pick from server data...")
    for _, ref in ipairs(refs or {}) do combo:AddChoice(choiceText(ref.name, ref.id), ref.id) end
    local add = styledButton(parent, "ADD", ui().accent, function()
        local _, data = combo:GetSelected()
        setEntryAppend(entry, data or "")
    end)
    add:SetPos(x + 216, y + 22)
    add:SetSize(62, 24)
end

local function vehicleByID(data, id)
    for _, v in ipairs(data.vehicles or {}) do if tonumber(v.id) == tonumber(id) then return v end end
end

local function spawnByID(data, id)
    for _, sp in ipairs(data.spawns or {}) do if tonumber(sp.id) == tonumber(id) then return sp end end
end

local easyFrame
function VR.OpenEasyConfigUI(data)
    data = data or {}
    if IsValid(easyFrame) then easyFrame:Remove() end
    local U = ui()

    easyFrame = vgui.Create("DFrame")
    easyFrame:SetSize(math.min(1120, ScrW() - 70), math.min(740, ScrH() - 70))
    easyFrame:Center()
    easyFrame:SetTitle("")
    easyFrame:MakePopup()
    easyFrame:ShowCloseButton(false)
    easyFrame.Paint = function(self, w, h)
        if MilBase and MilBase.DrawBlur then MilBase.DrawBlur(self, 4) end
        drawPanel(0, 0, w, h, { cut = 12, color = Color(6, 6, 7, 240), accent = U.accent })
        draw.SimpleText("VEHICLE REQUISITION EASY CONFIG", font("MB.Title", "DermaLarge"), 24, 18, U.text)
        draw.SimpleText("Live staff setup: wizard, vehicles, spawns, terminal rules, warnings, tester and backups", font("MB.Tiny", "DermaDefault"), 26, 60, U.dim)
    end

    local close = styledButton(easyFrame, "CLOSE", U.danger, function() easyFrame:Remove() end)
    close:SetSize(110, 34)
    close:SetPos(easyFrame:GetWide() - 130, 24)

    local reload = styledButton(easyFrame, "LIVE RELOAD", U.ok, function() writeEasy("reload", {}) end)
    reload:SetSize(135, 34)
    reload:SetPos(easyFrame:GetWide() - 276, 24)

    local sheet = vgui.Create("DPropertySheet", easyFrame)
    sheet:SetPos(22, 92)
    sheet:SetSize(easyFrame:GetWide() - 44, easyFrame:GetTall() - 114)

    --------------------------------------------------------------------
    -- Wizard
    --------------------------------------------------------------------
    local wizard = vgui.Create("DScrollPanel", sheet)
    local s = data.settings or {}
    addLabel(wizard, "1. OD priority factions", 20, 18, 240)
    local odPriority = addEntry(wizard, 20, 42, 420, s.od_priority_factions or "Republic Navy")
    addLabel(wizard, "2. Allowed non-priority factions", 20, 78, 300)
    local odAllowed = addEntry(wizard, 20, 102, 420, s.od_allowed_factions or "")
    addLabel(wizard, "3. Officer rank groups", 20, 138, 240)
    local odGroups = addEntry(wizard, 20, 162, 420, s.od_rank_groups or "officer,commander")
    addLabel(wizard, "4. Request cooldown seconds", 20, 198, 250)
    local cooldown = addEntry(wizard, 20, 222, 120, s.request_cooldown or "8")
    addLabel(wizard, "5. Staff config level", 170, 198, 220)
    local staffLevel = addEntry(wizard, 170, 222, 120, s.staff_level or "3")
    addLabel(wizard, "6. Pad clear radius", 20, 258, 180)
    local padRadius = addEntry(wizard, 20, 282, 120, s.pad_clear_radius or "80")
    addLabel(wizard, "7. Pad clear height", 170, 258, 180)
    local padHeight = addEntry(wizard, 170, 282, 120, s.pad_clear_height or "96")
    local worldHull = vgui.Create("DCheckBoxLabel", wizard)
    worldHull:SetPos(320, 282)
    worldHull:SetText("Strict world hull check")
    worldHull:SetTextColor(U.text)
    worldHull:SetValue(tostring(s.world_hull_check or "0") == "1" and 1 or 0)
    worldHull:SizeToContents()

    addRefPicker(wizard, data.refs and data.refs.factions, 500, 40, "Add faction to priority", odPriority)
    addRefPicker(wizard, data.refs and data.refs.factions, 500, 110, "Add faction to allowed", odAllowed)
    addRefPicker(wizard, data.refs and data.refs.rankGroups, 500, 180, "Add rank group", odGroups)

    local saveOD = styledButton(wizard, "SAVE OD SETUP", U.ok, function()
        writeEasy("settings", {
            od_priority_factions = odPriority:GetValue(),
            od_allowed_factions = odAllowed:GetValue(),
            od_rank_groups = odGroups:GetValue(),
            request_cooldown = cooldown:GetValue(),
            staff_level = staffLevel:GetValue(),
            pad_clear_radius = padRadius:GetValue(),
            pad_clear_height = padHeight:GetValue(),
            world_hull_check = worldHull:GetChecked() and "1" or "0",
        })
    end)
    saveOD:SetPos(20, 334)
    saveOD:SetSize(180, 38)

    local detectHelp = vgui.Create("DLabel", wizard)
    detectHelp:SetPos(20, 398)
    detectHelp:SetSize(900, 80)
    detectHelp:SetWrap(true)
    detectHelp:SetTextColor(U.dim)
    detectHelp:SetFont(font("MB.Small", "DermaDefault"))
    detectHelp:SetText("Fast setup: spawn one of your vehicles, look directly at it, then click Auto Detect on the Vehicles tab. Place pads with the Vehicle Requisition Spawn Toolgun, then use the Spawns tab to edit restrictions. If pads falsely say blocked, keep Strict world hull check off and lower the pad clear radius/height.")
    sheet:AddSheet("Setup Wizard", wizard, "icon16/wand.png")

    --------------------------------------------------------------------
    -- Vehicles
    --------------------------------------------------------------------
    local vehiclesTab = vgui.Create("DPanel", sheet)
    vehiclesTab.Paint = nil
    local vehList = vgui.Create("DListView", vehiclesTab)
    vehList:SetPos(12, 44)
    vehList:SetSize(430, sheet:GetTall() - 104)
    vehList:AddColumn("ID"):SetFixedWidth(42)
    vehList:AddColumn("Name")
    vehList:AddColumn("Class")
    vehList:AddColumn("Category")

    local searchVeh = addEntry(vehiclesTab, 12, 12, 260, "")
    searchVeh:SetPlaceholderText("Search vehicles...")

    local function fillVehicles(filter)
        vehList:Clear()
        filter = lower(filter or "")
        for _, v in ipairs(data.vehicles or {}) do
            local hay = lower((v.name or "") .. " " .. (v.entityClass or "") .. " " .. (v.category or ""))
            if filter == "" or string.find(hay, filter, 1, true) then
                local line = vehList:AddLine(v.id, v.name, v.entityClass, v.category)
                line.Data = v
            end
        end
    end
    fillVehicles("")
    searchVeh.OnChange = function(self) fillVehicles(self:GetValue()) end

    local x = 470
    addLabel(vehiclesTab, "Name", x, 14); local vName = addEntry(vehiclesTab, x, 36, 220, "")
    addLabel(vehiclesTab, "Entity class", x + 240, 14); local vClass = addEntry(vehiclesTab, x + 240, 36, 220, "")
    addLabel(vehiclesTab, "Category", x, 70); local vCat = addEntry(vehiclesTab, x, 92, 220, "General")
    addLabel(vehiclesTab, "Allowed factions", x + 240, 70); local vFactions = addEntry(vehiclesTab, x + 240, 92, 220, "")
    addLabel(vehiclesTab, "Required certs", x, 126); local vCerts = addEntry(vehiclesTab, x, 148, 220, "")
    addLabel(vehiclesTab, "Rank groups", x + 240, 126); local vGroups = addEntry(vehiclesTab, x + 240, 148, 220, "")
    addLabel(vehiclesTab, "Min rank", x, 182); local vMinRank = addEntry(vehiclesTab, x, 204, 90, "0")
    addLabel(vehiclesTab, "Max rank", x + 110, 182); local vMaxRank = addEntry(vehiclesTab, x + 110, 204, 90, "0")
    local vRequireAll = addCheck(vehiclesTab, "Require every listed cert", x + 225, 204, false)
    local vActive = addCheck(vehiclesTab, "Active", x + 225, 230, true)

    local selectedVehicle = 0
    local function collectVehicle()
        return {
            id = selectedVehicle,
            name = vName:GetValue(),
            entityClass = vClass:GetValue(),
            category = vCat:GetValue(),
            factions = vFactions:GetValue(),
            certs = vCerts:GetValue(),
            rankGroups = vGroups:GetValue(),
            minRank = vMinRank:GetValue(),
            maxRank = vMaxRank:GetValue(),
            requireAll = vRequireAll:GetChecked(),
            active = vActive:GetChecked(),
        }
    end
    local function applyVehicle(v)
        v = v or {}
        selectedVehicle = tonumber(v.id or 0) or 0
        vName:SetText(v.name or "")
        vClass:SetText(v.entityClass or "")
        vCat:SetText(v.category or "General")
        vFactions:SetText(v.factions or "")
        vCerts:SetText(v.certs or "")
        vGroups:SetText(v.rankGroups or "")
        vMinRank:SetText(tostring(v.minRank or 0))
        vMaxRank:SetText(tostring(v.maxRank or 0))
        vRequireAll:SetValue(tonumber(v.requireAll or 0) == 1 and 1 or 0)
        vActive:SetValue(tonumber(v.active or 1) == 1 and 1 or 0)
    end
    vehList.OnRowSelected = function(_, _, line) applyVehicle(line.Data) end
    if data.detectedVehicle then applyVehicle(data.detectedVehicle) end

    addRefPicker(vehiclesTab, data.refs and data.refs.factions, x, 260, "Add faction", vFactions)
    addRefPicker(vehiclesTab, data.refs and data.refs.certs, x + 310, 260, "Add cert", vCerts)
    addRefPicker(vehiclesTab, data.refs and data.refs.rankGroups, x, 330, "Add rank group", vGroups)

    local preset = vgui.Create("DComboBox", vehiclesTab)
    preset:SetPos(x + 310, 352)
    preset:SetSize(220, 24)
    preset:SetValue("Apply preset...")
    for _, p in ipairs(data.presets or {}) do preset:AddChoice(p.name, p) end
    preset.OnSelect = function(_, _, _, p)
        if not istable(p) then return end
        vCat:SetText(p.category or vCat:GetValue())
        vFactions:SetText(p.factions or "")
        vCerts:SetText(p.certs or "")
        vGroups:SetText(p.rankGroups or "")
        vMinRank:SetText(tostring(p.minRank or 0))
    end

    local detectBtn = styledButton(vehiclesTab, "AUTO DETECT LOOKED ENTITY", U.warn, function() writeEasy("detect_vehicle", {}) end)
    detectBtn:SetPos(x, 418); detectBtn:SetSize(245, 36)
    local addBtn = styledButton(vehiclesTab, "ADD NEW", U.ok, function() local d = collectVehicle(); d.id = nil; writeEasy("vehicle_add", d) end)
    addBtn:SetPos(x, 464); addBtn:SetSize(120, 36)
    local updateBtn = styledButton(vehiclesTab, "UPDATE", U.accent, function() if selectedVehicle > 0 then writeEasy("vehicle_update", collectVehicle()) else MilBase.Notify("Select a vehicle first.") end end)
    updateBtn:SetPos(x + 130, 464); updateBtn:SetSize(120, 36)
    local copyBtn = styledButton(vehiclesTab, "COPY AS NEW", U.ok, function() local d = collectVehicle(); d.id = nil; d.name = d.name .. " Copy"; writeEasy("vehicle_add", d) end)
    copyBtn:SetPos(x + 260, 464); copyBtn:SetSize(130, 36)
    local delBtn = styledButton(vehiclesTab, "DELETE", U.danger, function() if selectedVehicle > 0 then writeEasy("vehicle_delete", { id = selectedVehicle }) else MilBase.Notify("Select a vehicle first.") end end)
    delBtn:SetPos(x + 400, 464); delBtn:SetSize(110, 36)
    sheet:AddSheet("Vehicles", vehiclesTab, "icon16/car.png")

    --------------------------------------------------------------------
    -- Spawns
    --------------------------------------------------------------------
    local spawnsTab = vgui.Create("DPanel", sheet)
    spawnsTab.Paint = nil
    local spList = vgui.Create("DListView", spawnsTab)
    spList:SetPos(12, 44)
    spList:SetSize(430, sheet:GetTall() - 104)
    spList:AddColumn("ID"):SetFixedWidth(42)
    spList:AddColumn("Name")
    spList:AddColumn("Allowed vehicles")
    local searchSp = addEntry(spawnsTab, 12, 12, 260, "")
    searchSp:SetPlaceholderText("Search spawns...")
    local function fillSpawns(filter)
        spList:Clear()
        filter = lower(filter or "")
        for _, sp in ipairs(data.spawns or {}) do
            local hay = lower((sp.name or "") .. " " .. (sp.vehicles or ""))
            if filter == "" or string.find(hay, filter, 1, true) then
                local line = spList:AddLine(sp.id, sp.name, trim(sp.vehicles) ~= "" and sp.vehicles or "Any")
                line.Data = sp
            end
        end
    end
    fillSpawns("")
    searchSp.OnChange = function(self) fillSpawns(self:GetValue()) end

    local sx = 470
    addLabel(spawnsTab, "Name", sx, 14); local spName = addEntry(spawnsTab, sx, 36, 220, "")
    addLabel(spawnsTab, "Allowed vehicles", sx + 240, 14); local spVehicles = addEntry(spawnsTab, sx + 240, 36, 220, "")
    addLabel(spawnsTab, "Allowed factions", sx, 70); local spFactions = addEntry(spawnsTab, sx, 92, 220, "")
    addLabel(spawnsTab, "Required certs", sx + 240, 70); local spCerts = addEntry(spawnsTab, sx + 240, 92, 220, "")
    addLabel(spawnsTab, "Rank groups", sx, 126); local spGroups = addEntry(spawnsTab, sx, 148, 220, "")
    addLabel(spawnsTab, "Min rank", sx, 182); local spMinRank = addEntry(spawnsTab, sx, 204, 90, "0")
    addLabel(spawnsTab, "Max rank", sx + 110, 182); local spMaxRank = addEntry(spawnsTab, sx + 110, 204, 90, "0")
    local spRequireAll = addCheck(spawnsTab, "Require every listed cert", sx + 225, 204, false)
    local spActive = addCheck(spawnsTab, "Active", sx + 225, 230, true)
    local selectedSpawn = 0
    local function applySpawn(sp)
        sp = sp or {}; selectedSpawn = tonumber(sp.id or 0) or 0
        spName:SetText(sp.name or "")
        spVehicles:SetText(sp.vehicles or "")
        spFactions:SetText(sp.factions or "")
        spCerts:SetText(sp.certs or "")
        spGroups:SetText(sp.rankGroups or "")
        spMinRank:SetText(tostring(sp.minRank or 0))
        spMaxRank:SetText(tostring(sp.maxRank or 0))
        spRequireAll:SetValue(tonumber(sp.requireAll or 0) == 1 and 1 or 0)
        spActive:SetValue(tonumber(sp.active or 1) == 1 and 1 or 0)
    end
    local function collectSpawn()
        return { id = selectedSpawn, name = spName:GetValue(), vehicles = spVehicles:GetValue(), factions = spFactions:GetValue(), certs = spCerts:GetValue(), rankGroups = spGroups:GetValue(), minRank = spMinRank:GetValue(), maxRank = spMaxRank:GetValue(), requireAll = spRequireAll:GetChecked(), active = spActive:GetChecked() }
    end
    spList.OnRowSelected = function(_, _, line) applySpawn(line.Data) end

    addRefPicker(spawnsTab, data.vehicles, sx, 260, "Add allowed vehicle", spVehicles)
    addRefPicker(spawnsTab, data.refs and data.refs.factions, sx + 310, 260, "Add faction", spFactions)
    addRefPicker(spawnsTab, data.refs and data.refs.certs, sx, 330, "Add cert", spCerts)
    addRefPicker(spawnsTab, data.refs and data.refs.rankGroups, sx + 310, 330, "Add rank group", spGroups)

    local spUpdate = styledButton(spawnsTab, "UPDATE SPAWN", U.accent, function() if selectedSpawn > 0 then writeEasy("spawn_update", collectSpawn()) else MilBase.Notify("Select a spawn first.") end end)
    spUpdate:SetPos(sx, 430); spUpdate:SetSize(150, 36)
    local spDelete = styledButton(spawnsTab, "DELETE", U.danger, function() if selectedSpawn > 0 then writeEasy("spawn_delete", { id = selectedSpawn }) else MilBase.Notify("Select a spawn first.") end end)
    spDelete:SetPos(sx + 160, 430); spDelete:SetSize(120, 36)
    local spHelp = vgui.Create("DLabel", spawnsTab)
    spHelp:SetPos(sx, 486); spHelp:SetSize(500, 80); spHelp:SetWrap(true); spHelp:SetFont(font("MB.Tiny", "DermaDefault")); spHelp:SetTextColor(U.dim)
    spHelp:SetText("Create/move spawn positions with the Toolgun: Star Wars RP → Vehicle Requisition Spawn. This tab edits access rules, names, and active state.")
    sheet:AddSheet("Spawns", spawnsTab, "icon16/world.png")

    --------------------------------------------------------------------
    -- Terminal
    --------------------------------------------------------------------
    local terminalTab = vgui.Create("DPanel", sheet)
    terminalTab.Paint = nil
    addLabel(terminalTab, "Terminal display name", 20, 20, 260)
    local terminalName = addEntry(terminalTab, 20, 44, 420, s.terminal_name or "Vehicle Requisition Terminal")
    addLabel(terminalTab, "Terminal help text", 20, 84, 260)
    local terminalHelp = addEntry(terminalTab, 20, 108, 620, s.terminal_help or "Select a vehicle, spawn, and mission reason.")
    addLabel(terminalTab, "Allowed vehicles/categories/classes/IDs for all terminals", 20, 148, 450)
    local terminalVehicles = addEntry(terminalTab, 20, 172, 620, s.terminal_allowed_vehicles or "")
    addLabel(terminalTab, "Allowed spawns/names/IDs for all terminals", 20, 212, 380)
    local terminalSpawns = addEntry(terminalTab, 20, 236, 620, s.terminal_allowed_spawns or "")
    addLabel(terminalTab, "Allowed terminal factions", 20, 276, 260)
    local terminalFactions = addEntry(terminalTab, 20, 300, 620, s.terminal_allowed_factions or "")
    addRefPicker(terminalTab, data.vehicles, 680, 148, "Add vehicle filter", terminalVehicles)
    addRefPicker(terminalTab, data.spawns, 680, 218, "Add spawn filter", terminalSpawns)
    addRefPicker(terminalTab, data.refs and data.refs.factions, 680, 288, "Add faction filter", terminalFactions)
    local saveTerminal = styledButton(terminalTab, "SAVE TERMINAL RULES", U.ok, function()
        writeEasy("terminal_settings", {
            terminal_name = terminalName:GetValue(),
            terminal_help = terminalHelp:GetValue(),
            terminal_allowed_vehicles = terminalVehicles:GetValue(),
            terminal_allowed_spawns = terminalSpawns:GetValue(),
            terminal_allowed_factions = terminalFactions:GetValue(),
        })
    end)
    saveTerminal:SetPos(20, 360); saveTerminal:SetSize(210, 38)
    sheet:AddSheet("Terminal", terminalTab, "icon16/application_view_list.png")

    --------------------------------------------------------------------
    -- Tester
    --------------------------------------------------------------------
    local tester = vgui.Create("DPanel", sheet)
    tester.Paint = nil
    addLabel(tester, "Player", 20, 20)
    local playerCombo = vgui.Create("DComboBox", tester); playerCombo:SetPos(20, 44); playerCombo:SetSize(300, 26); playerCombo:SetValue("Select online player...")
    for _, p in ipairs(data.refs and data.refs.players or {}) do playerCombo:AddChoice(p.rpName or p.name, p.steamid) end
    addLabel(tester, "Vehicle", 20, 88)
    local vehicleCombo = vgui.Create("DComboBox", tester); vehicleCombo:SetPos(20, 112); vehicleCombo:SetSize(300, 26); vehicleCombo:SetValue("Select vehicle...")
    for _, v in ipairs(data.vehicles or {}) do vehicleCombo:AddChoice(choiceText(v.name, v.id), v.id) end
    addLabel(tester, "Spawn", 20, 156)
    local spawnCombo = vgui.Create("DComboBox", tester); spawnCombo:SetPos(20, 180); spawnCombo:SetSize(300, 26); spawnCombo:SetValue("Select spawn...")
    for _, sp in ipairs(data.spawns or {}) do spawnCombo:AddChoice(choiceText(sp.name, sp.id), sp.id) end
    local testBtn = styledButton(tester, "TEST PERMISSION", U.ok, function()
        local _, playerData = playerCombo:GetSelected()
        local _, vehicleID = vehicleCombo:GetSelected()
        local _, spawnID = spawnCombo:GetSelected()
        writeEasy("permission_test", { player = playerData or "", vehicleID = vehicleID or 0, spawnID = spawnID or 0 })
    end)
    testBtn:SetPos(20, 230); testBtn:SetSize(180, 38)
    local result = vgui.Create("DLabel", tester)
    result:SetPos(370, 44); result:SetSize(600, 420); result:SetWrap(true); result:SetFont(font("MB.Small", "DermaDefault")); result:SetTextColor(U.text)
    if data.permissionTest then
        local lines = {}
        lines[#lines + 1] = "Result for " .. tostring(data.permissionTest.player or "unknown") .. ":"
        for _, line in ipairs(data.permissionTest.lines or {}) do
            lines[#lines + 1] = (line.ok and "✓ " or "✗ ") .. tostring(line.text)
        end
        result:SetText(table.concat(lines, "\n"))
    else
        result:SetText("Select a player, vehicle, and spawn to see exactly why access passes or fails.")
    end
    sheet:AddSheet("Tester", tester, "icon16/tick.png")

    --------------------------------------------------------------------
    -- Warnings
    --------------------------------------------------------------------
    local warnings = vgui.Create("DPanel", sheet)
    warnings.Paint = nil
    local warnList = vgui.Create("DListView", warnings)
    warnList:SetPos(12, 12); warnList:SetSize(sheet:GetWide() - 50, sheet:GetTall() - 90)
    warnList:AddColumn("Level"):SetFixedWidth(90)
    warnList:AddColumn("Warning")
    for _, w in ipairs(data.warnings or {}) do warnList:AddLine(string.upper(w.level or "info"), w.text or "") end
    local warnReload = styledButton(warnings, "REFRESH WARNINGS", U.ok, function() writeEasy("reload", {}) end)
    warnReload:SetPos(12, sheet:GetTall() - 66); warnReload:SetSize(180, 36)
    sheet:AddSheet("Warnings", warnings, "icon16/error.png")

    --------------------------------------------------------------------
    -- Bulk / Backups
    --------------------------------------------------------------------
    local backup = vgui.Create("DPanel", sheet)
    backup.Paint = nil
    addLabel(backup, "Bulk edit vehicles by category", 20, 16, 300)
    local catCombo = vgui.Create("DComboBox", backup); catCombo:SetPos(20, 42); catCombo:SetSize(220, 26); catCombo:SetValue("Select category...")
    for _, cat in ipairs(data.refs and data.refs.categories or {}) do catCombo:AddChoice(cat, cat) end
    addLabel(backup, "Set factions", 260, 16); local bulkFactions = addEntry(backup, 260, 42, 220, "")
    addLabel(backup, "Set certs", 500, 16); local bulkCerts = addEntry(backup, 500, 42, 220, "")
    addLabel(backup, "Set rank groups", 740, 16); local bulkGroups = addEntry(backup, 740, 42, 220, "")
    local bulkBtn = styledButton(backup, "APPLY BULK EDIT", U.warn, function()
        local _, cat = catCombo:GetSelected()
        writeEasy("bulk_vehicle_update", { category = cat or "", factions = bulkFactions:GetValue(), certs = bulkCerts:GetValue(), rankGroups = bulkGroups:GetValue() })
    end)
    bulkBtn:SetPos(20, 82); bulkBtn:SetSize(180, 36)

    local backupList = vgui.Create("DListView", backup)
    backupList:SetPos(20, 170); backupList:SetSize(520, sheet:GetTall() - 230)
    backupList:AddColumn("Backup file")
    for _, b in ipairs(data.backups or {}) do
        local line = backupList:AddLine(b.name)
        line.Backup = b
    end
    local makeBackup = styledButton(backup, "CREATE BACKUP", U.ok, function() writeEasy("backup_create", {}) end)
    makeBackup:SetPos(570, 170); makeBackup:SetSize(170, 38)
    local restoreBackup = styledButton(backup, "RESTORE SELECTED", U.danger, function()
        local line = selectedLine(backupList)
        if not line or not line.Backup then MilBase.Notify("Select a backup first.") return end
        Derma_Query("Restore this backup? This replaces current vehicle requisition config for this map.", "Restore Backup", "Restore", function()
            writeEasy("backup_restore", { name = line.Backup.name })
        end, "Cancel")
    end)
    restoreBackup:SetPos(570, 220); restoreBackup:SetSize(170, 38)
    sheet:AddSheet("Bulk / Backups", backup, "icon16/database_save.png")
end

net.Receive(NET_OPEN, function()
    VR.OpenEasyConfigUI(net.ReadTable() or {})
end)

-- Improve the existing player terminal by using the terminal title/help from
-- the easy config if the original terminal UI is already loaded.
if not VR.EasyTerminalUIWrapped then
    VR.EasyTerminalUIWrapped = true
    local baseOpenTerminalUI = VR.OpenTerminalUI
    if baseOpenTerminalUI then
        VR.OpenTerminalUI = function(data)
            data = data or {}
            if data.terminalBlocked and MilBase and MilBase.Notify then
                MilBase.Notify(data.blockReason or "You cannot use this terminal.", "warn")
                return
            end
            baseOpenTerminalUI(data)
        end
    end
end
