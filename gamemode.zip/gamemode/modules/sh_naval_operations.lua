if MilBase.NavalOperationsSharedLoaded then return end
MilBase.NavalOperationsSharedLoaded = true

MilBase.Naval = MilBase.Naval or {}
local N = MilBase.Naval
local naval = MilBase.Config.NavalOperations or {}

N.ResourceOrder = {
	"funding", "supplies", "fuel", "munitions", "medical", "repair",
}
N.ResourceLabels = {
	funding = "FUNDING",
	supplies = "SUPPLIES",
	fuel = "FUEL",
	munitions = "MUNITIONS",
	medical = "MEDICAL",
	repair = "REPAIR PARTS",
}
N.PowerLabels = {
	engines = "ENGINES",
	maneuvering = "MANOEUVRING",
	shields = "SHIELDS",
	weapons = "WEAPONS",
	sensors = "SENSORS",
	communications = "COMMS",
	life_support = "LIFE SUPPORT",
}

function N.IsNavy(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	local factionID = ply.MBFactionID and tostring(ply:MBFactionID()) or ""
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local factionName = faction and tostring(faction.name or "") or ""
	local ids = naval.ConsoleFactionIDs or {}
	local names = naval.ConsoleFactionNames or {}
	return ids[factionID] == true or ids[string.lower(factionID)] == true
		or names[factionName] == true
end

function N.CanUseConsole(ply)
	return N.IsNavy(ply) and ply:Alive()
end

function N.IsNavalOfficer(ply)
	if not N.CanUseConsole(ply) then return false end
	local rank = ply.MBRankIndex and tonumber(ply:MBRankIndex()) or 0
	return rank >= math.max(1, tonumber(naval.CommandMinimumRankIndex) or 8)
end

function N.CleanKey(value)
	return string.lower(string.Trim(tostring(value or ""))):gsub("[^%w_%-]", "")
end

function N.VehicleCost(vehicle)
	vehicle = vehicle or {}
	local haystack = string.lower(table.concat({
		tostring(vehicle.name or ""),
		tostring(vehicle.entityClass or ""),
		tostring(vehicle.category or ""),
	}, " "))
	local chosen
	for _, entry in ipairs(naval.VehicleCosts or {}) do
		if entry.token and string.find(haystack, string.lower(entry.token), 1, true) then
			chosen = entry
			break
		end
	end
	chosen = chosen or naval.DefaultVehicleCost or {}
	local out = {}
	for _, key in ipairs(N.ResourceOrder) do
		out[key] = math.max(0, math.floor(tonumber(chosen[key]) or 0))
	end
	return out
end

function N.FormatCost(cost, compact)
	local parts = {}
	for _, key in ipairs(N.ResourceOrder) do
		local amount = math.floor(tonumber(cost and cost[key]) or 0)
		if amount > 0 then
			parts[#parts + 1] = compact
				and ((key == "funding" and "CR" or string.upper(string.sub(key, 1, 3))) .. " " .. amount)
				or ((N.ResourceLabels[key] or string.upper(key)) .. ": " .. amount)
		end
	end
	return table.concat(parts, compact and "  " or " | ")
end

function N.PowerFactorForAllocation(key, assigned)
	assigned = math.Clamp(tonumber(assigned) or 0, 0, 100)
	if assigned <= 0 then return 0 end
	local baseline = math.max(1, tonumber(naval.InitialPower and naval.InitialPower[key]) or 14)
	-- The configured initial allocation is normal output. Above it gives a modest boost;
	-- below it degrades smoothly, while an explicit zero takes the system offline.
	return math.Clamp(assigned / baseline, 0.15, 1.35)
end

function N.PowerFactor(key)
	if not SERVER or not N.State or not N.State.power then return 1 end
	return N.PowerFactorForAllocation(key, N.State.power[key])
end
