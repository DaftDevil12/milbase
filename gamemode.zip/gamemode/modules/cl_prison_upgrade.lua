-- Client feedback for prison alarms, surveillance cameras and movement diagnostics.
if not CLIENT or MilBase._PrisonUpgradeClientLoaded then return end
MilBase._PrisonUpgradeClientLoaded = true

local P = MilBase.Prison
P.ClientAlarm = P.ClientAlarm or { active = false }

net.Receive("MilBase_Prison_Alert", function()
	local previous = P.ClientAlarm and P.ClientAlarm.active
	P.ClientAlarm = net.ReadTable() or { active = false }
	if P.ClientAlarm.active and not previous then
		surface.PlaySound("ambient/alarms/klaxon1.wav")
	end
end)

local function speechLines(text, maximumCharacters)
	local lines, current = {}, ""
	for word in string.gmatch(tostring(text or ""), "%S+") do
		local candidate = current == "" and word or (current .. " " .. word)
		if #candidate > maximumCharacters and current ~= "" then
			lines[#lines + 1] = current
			current = word
			if #lines >= 3 then break end
		else
			current = candidate
		end
	end
	if current ~= "" and #lines < 3 then lines[#lines + 1] = current end
	if #lines == 0 then lines[1] = "..." end
	return lines
end

net.Receive("MilBase_Prison_Speech", function()
	local ent = net.ReadEntity()
	local prisonerName = net.ReadString()
	local languageName = net.ReadString()
	local text = net.ReadString()
	local understood = net.ReadBool()
	local translatorName = net.ReadString()
	local translated = translatorName ~= ""
	local colour = not understood and Color(220, 130, 75)
		or translated and Color(105, 205, 155)
		or Color(105, 185, 235)

	if IsValid(ent) then
		ent.mb_prisonSpeech = {
			name = prisonerName,
			language = languageName,
			text = text,
			lines = speechLines(text, 58),
			understood = understood,
			translator = translatorName,
			colour = colour,
			expires = CurTime() + math.max(2,
				tonumber((MilBase.Config.Prison or {}).LanguageSpeechDuration) or 6),
		}
	end

	local tag = "[" .. string.upper(languageName) .. "] "
	if translated then
		chat.AddText(colour, tag, Color(175, 215, 190),
			"[Translated by " .. translatorName .. "] ", color_white,
			prisonerName .. ": " .. text)
	elseif understood then
		chat.AddText(colour, tag, color_white, prisonerName .. ": " .. text)
	else
		chat.AddText(colour, tag, Color(220, 130, 75),
			"[UNTRANSLATED] ", color_white, prisonerName .. ": " .. text)
	end
end)

hook.Add("PostDrawTranslucentRenderables", "MilBase.Prison.LanguageSpeech", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	for _, ent in ipairs(ents.FindByClass("mb_prisoner")) do
		local speech = ent.mb_prisonSpeech
		if speech and speech.expires > CurTime()
		and lp:GetPos():DistToSqr(ent:GetPos()) <= 900 * 900 then
			local fade = math.Clamp((speech.expires - CurTime()) / 0.6, 0, 1)
			local lines = speech.lines or { speech.text or "..." }
			local width = 620
			local height = 54 + #lines * 24
			local pos = ent:WorldSpaceCenter() + Vector(0, 0, 76)
			local ang = Angle(0, lp:EyeAngles().y - 90, 90)
			cam.Start3D2D(pos, ang, 0.045)
				surface.SetDrawColor(3, 8, 14, math.floor(230 * fade))
				surface.DrawRect(-width * 0.5, -height, width, height)
				local c = speech.colour or Color(105, 185, 235)
				surface.SetDrawColor(c.r, c.g, c.b, math.floor(245 * fade))
				surface.DrawOutlinedRect(-width * 0.5, -height, width, height, 3)
				local state = not speech.understood and "UNTRANSLATED"
					or speech.translator ~= "" and ("TRANSLATED BY " .. speech.translator)
					or "UNDERSTOOD"
				draw.SimpleText(string.upper(speech.language or "LANGUAGE") .. " - " .. state,
					(MilBase.UI and "MB.Tiny") or "DermaDefaultBold", 0, -height + 17,
					Color(c.r, c.g, c.b, math.floor(255 * fade)),
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				for index, line in ipairs(lines) do
					draw.SimpleText(line, (MilBase.UI and "MB.Small") or "DermaDefault",
						0, -height + 40 + (index - 1) * 24,
						Color(235, 240, 245, math.floor(255 * fade)),
						TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			cam.End3D2D()
		elseif speech then
			ent.mb_prisonSpeech = nil
		end
	end
end)

hook.Add("HUDPaint", "MilBase.Prison.AlarmHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not P.CanUse(lp) then return end
	local alarm = P.ClientAlarm or {}
	if not alarm.active then return end
	local pulse = 0.72 + math.sin(CurTime() * 5) * 0.18
	local colour = Color(220, 64, 54, math.floor(235 * pulse))
	local width, height = math.min(620, ScrW() - 80), 54
	local x, y = (ScrW() - width) * 0.5, 36
	surface.SetDrawColor(5, 8, 13, 225)
	surface.DrawRect(x, y, width, height)
	surface.SetDrawColor(colour)
	surface.DrawOutlinedRect(x, y, width, height, 3)
	draw.SimpleText("PRISON ALARM  •  " .. string.upper(tostring(alarm.reason or "SECURITY ALERT")),
		(MilBase.UI and "MB.Small") or "DermaDefaultBold", ScrW() * 0.5, y + 18,
		colour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("ZONE: " .. string.upper(tostring(alarm.zone or "FACILITY")),
		(MilBase.UI and "MB.Tiny") or "DermaDefault", ScrW() * 0.5, y + 39,
		Color(210, 218, 228), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

local cameraFrame
function P.OpenCameraFeed(camera)
	if not istable(camera) or not isvector(camera.pos) or not isangle(camera.ang) then return end
	if IsValid(cameraFrame) then cameraFrame:Remove() end
	local frame = vgui.Create("DFrame")
	cameraFrame = frame
	frame:SetSize(math.min(900, ScrW() - 80), math.min(620, ScrH() - 80))
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Paint = function(self, w, h)
		if MilBase.DrawBlur then MilBase.DrawBlur(self, 2) end
		surface.SetDrawColor(2, 6, 10, 248)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(70, 170, 235)
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		draw.SimpleText("PRISON SURVEILLANCE  •  " .. string.upper(camera.name or "CAMERA"),
			(MilBase.UI and "MB.Small") or "DermaDefaultBold", 18, 19,
			Color(224, 232, 242), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local close = vgui.Create("DButton", frame)
	close:SetText("CLOSE FEED")
	close:SetSize(110, 30)
	close.DoClick = function() frame:Remove() end
	local view = vgui.Create("DPanel", frame)
	view.Paint = function(self, w, h)
		local sx, sy = self:LocalToScreen(0, 0)
		local clipping = DisableClipping(true)
		render.RenderView({
			origin = camera.pos,
			angles = camera.ang,
			x = sx,
			y = sy,
			w = w,
			h = h,
			fov = tonumber(camera.fov) or 78,
			drawviewmodel = false,
			drawhud = false,
			dopostprocess = false,
		})
		DisableClipping(clipping)
		surface.SetDrawColor(70, 170, 235, 180)
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		surface.DrawLine(w * 0.5 - 12, h * 0.5, w * 0.5 + 12, h * 0.5)
		surface.DrawLine(w * 0.5, h * 0.5 - 12, w * 0.5, h * 0.5 + 12)
		draw.SimpleText(os.date("%H:%M:%S") .. "  •  "
			.. string.upper(tostring(camera.zone or "FACILITY")),
			(MilBase.UI and "MB.Tiny") or "DermaDefault", 12, h - 22,
			Color(190, 225, 245), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	frame.PerformLayout = function(self, w, h)
		close:SetPos(w - 128, 12)
		view:SetPos(16, 58)
		view:SetSize(w - 32, h - 76)
	end
end

hook.Add("PostDrawTranslucentRenderables", "MilBase.Prison.NavigationDebug", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:GetNWBool("mb_prison_debug", false) then return end
	render.SetColorMaterial()
	for _, row in ipairs(P.ClientLayout or {}) do
		if row.kind == "path_node" then
			render.DrawWireframeSphere(row.pos, 12, 8, 8, Color(90, 205, 255, 210), true)
		end
	end
	for _, ent in ipairs(ents.FindByClass("mb_prisoner")) do
		local target = ent:GetNWVector("mb_prison_target", vector_origin)
		if target ~= vector_origin then
			render.DrawLine(ent:WorldSpaceCenter(), target + Vector(0, 0, 16),
				Color(255, 198, 60, 230), true)
			render.DrawWireframeSphere(target, 10, 8, 8, Color(255, 198, 60, 230), true)
		end
	end
end)
