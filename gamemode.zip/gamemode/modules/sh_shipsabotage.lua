--[[
	Ship sabotage & repair: the mechanics behind the two SWU attack surfaces.

	  mb_hackconsole - a saboteur slices it (code minigame) to softly force
	                   engines + hyperdrive fully offline; an engineer types a
	                   recovery code to restore them.
	  mb_shippart    - a saboteur's planted charge destroys it; an engineer
	                   repairs it in three stages: WELD (in-world torch seam,
	                   handled by the shared weld in sh_engevents) -> RE-WIRE
	                   (wire minigame) -> FIX CIRCUITS (sequence minigame).

	The offline/degraded consequences themselves live in sh_shipsystems.lua
	(RefreshShipSystems counts parts and reacts to hacked consoles).
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_HackConsoleGame")
	util.AddNetworkString("MilBase_HackConsoleResult")
	util.AddNetworkString("MilBase_ShipPartGame")
	util.AddNetworkString("MilBase_ShipPartAdvance")

	function MilBase.OnConsoleHacked(console, by)
		MilBase.ChatMsg(nil, Color(120, 200, 140), "[SLICER] ", color_white,
			(IsValid(by) and by:MBName() or "Someone")
			.. " hacked a security console — engines & hyperdrive OFFLINE!")
	end

	function MilBase.OnShipPartDestroyed(part)
		MilBase.ChatMsg(nil, Color(220, 90, 70), "[SABOTAGE] ", color_white,
			"A ship part was destroyed! Engineers to repair stations.")
	end

	-- Result of the hack / reset minigame (re-validated here).
	net.Receive("MilBase_HackConsoleResult", function(_, ply)
		local console = net.ReadEntity()
		local isFix = net.ReadBool()
		if not IsValid(console) or console:GetClass() ~= "mb_hackconsole" then return end
		if not ply:Alive() then return end
		if console:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end
		if (ply.mb_hackOpen or 0) > CurTime() - 1.5 then return end -- minigame took time

		if isFix then
			if not console:GetHacked() then return end
			if not (ply:MBHasCert("engineer") or ply:IsAdmin()) then return end
			console:Unhack(ply)
			if MilBase.EngIncidentFixed then
				MilBase.EngIncidentFixed(ply, "reset a hacked security console")
			end
		else
			if console:GetHacked() or cfg.HackConsolesEnabled == false then return end
			if not (ply:MBHasCert("saboteur") or ply:IsAdmin()) then return end
			console:Hack(ply)
		end
	end)

	-- One repair stage of a ship part completed.
	net.Receive("MilBase_ShipPartAdvance", function(_, ply)
		local part = net.ReadEntity()
		if not IsValid(part) or part:GetClass() ~= "mb_shippart" then return end
		if not ply:Alive() or not part:GetDestroyed() then return end
		if not (ply:MBHasCert("engineer") or ply:IsAdmin()) then return end
		if part:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end
		if (ply.mb_partOpen or 0) > CurTime() - 1.5 then return end

		local stage = part:GetStage()
		if stage == 2 then
			part:SetStage(3)
			MilBase.Notify(ply, "Re-wired — now FIX THE CIRCUITS (press E).")
		elseif stage == 3 then
			part:SetDestroyed(false)
			part:SetStage(0)
			part:SetColor(color_white)
			part:EmitSound("items/suitchargeok1.wav", 75)
			if MilBase.RefreshShipSystems then MilBase.RefreshShipSystems() end
			if MilBase.EngIncidentFixed then
				MilBase.EngIncidentFixed(ply, "brought a ship part back online")
			end
		end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: minigames + HUD prompts / weld seam
--------------------------------------------------------------------------

net.Receive("MilBase_HackConsoleGame", function()
	local console = net.ReadEntity()
	local isFix = net.ReadBool()
	if not IsValid(console) then return end

	local function valid()
		return IsValid(console) and console:GetHacked() == isFix
			and console:GetPos():DistToSqr(LocalPlayer():GetPos()) < 150 * 150
	end
	local function done()
		net.Start("MilBase_HackConsoleResult")
			net.WriteEntity(console)
			net.WriteBool(isFix)
		net.SendToServer()
	end

	if isFix then
		MilBase.OpenCodeMinigame({
			title = "SECURITY RESET",
			subtitle = "Type the recovery code to purge the intrusion.",
			lines = MilBase.GenCodeLines(4),
			valid = valid, onSuccess = done,
		})
	else
		MilBase.OpenCodeMinigame({
			title = "SLICING SECURITY",
			subtitle = "Break the console's encryption to lock the crew out.",
			color = Color(120, 200, 140),
			lines = MilBase.GenCodeLines(6),
			valid = valid, onSuccess = done,
		})
	end
end)

net.Receive("MilBase_ShipPartGame", function()
	local part = net.ReadEntity()
	if not IsValid(part) then return end
	local stage = part:GetStage()
	local lp = LocalPlayer()
	local eng = lp:MBHasCert("engineer") or lp:IsAdmin()

	local function valid()
		return IsValid(part) and part:GetDestroyed() and part:GetStage() == stage
			and part:GetPos():DistToSqr(LocalPlayer():GetPos()) < 150 * 150
	end
	local function done()
		net.Start("MilBase_ShipPartAdvance")
			net.WriteEntity(part)
		net.SendToServer()
	end

	if stage == 2 then
		MilBase.OpenWireMinigame({
			title = "PART RE-WIRE",
			subtitle = "Reconnect the severed control lines.",
			wires = eng and 3 or 5,
			valid = valid, onSuccess = done,
		})
	elseif stage == 3 then
		MilBase.OpenSequenceMinigame({
			title = "CIRCUIT REPAIR",
			subtitle = "Restore the firing order to reboot the part.",
			length = eng and 3 or 5,
			valid = valid, onSuccess = done,
		})
	end
end)

local STAGE_TXT = { [1] = "WELD THE SEAM", [2] = "RE-WIRE  [E]", [3] = "FIX CIRCUITS  [E]" }

hook.Add("HUDPaint", "MilBase.ShipSabotageHUD", function()
	if MilBase.InEventView and MilBase.InEventView() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end

	local ui = MilBase.UI
	local eng = lp:MBHasCert("engineer") or lp:IsAdmin()
	local sab = lp:MBHasCert("saboteur") or lp:IsAdmin()

	-- Hackable security consoles.
	for _, c in ipairs(ents.FindByClass("mb_hackconsole")) do
		local dist = lp:GetPos():Distance(c:GetPos())
		if dist > (eng and 600 or 300) then continue end
		local screen = (c:GetPos() + Vector(0, 0, 20)):ToScreen()
		if not screen.visible then continue end

		if c:GetHacked() then
			draw.SimpleTextOutlined("⚠ SECURITY HACKED", "MB.Small", screen.x, screen.y - 10,
				ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
			if eng and dist < 160 then
				draw.SimpleTextOutlined("PRESS [E] TO RESET", "MB.Tiny", screen.x, screen.y + 8,
					ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
			end
		elseif sab and dist < 160 then
			draw.SimpleTextOutlined("[E] HACK CONSOLE", "MB.Tiny", screen.x, screen.y + 8,
				Color(120, 200, 140), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end
	end

	-- Destroyed ship parts: stage prompts, plus the in-world weld seam at stage 1.
	local torch = MilBase.HoldingTorch and MilBase.HoldingTorch(lp)
	for _, part in ipairs(ents.FindByClass("mb_shippart")) do
		if not part:GetDestroyed() then continue end

		local center = part:LocalToWorld(part:OBBCenter())
		local dist = lp:GetPos():Distance(center)
		if dist > (eng and 600 or 300) then continue end

		if part:GetStage() == 1 and torch and dist < 150 and MilBase.DrawWeldSeam then
			MilBase.DrawWeldSeam(part)
		end

		local screen = (center + Vector(0, 0, 24)):ToScreen()
		if not screen.visible then continue end

		draw.SimpleTextOutlined("⚠ PART DAMAGED", "MB.Small", screen.x, screen.y - 12,
			ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

		if dist < 170 then
			local st = part:GetStage()
			local txt = STAGE_TXT[st] or ""
			local col = ui.dim
			if st == 1 then
				if not torch then txt = "EQUIP REPAIR TOOL TO WELD" else col = ui.accent end
			end
			draw.SimpleTextOutlined("STAGE " .. st .. "/3: " .. txt, "MB.Tiny",
				screen.x, screen.y + 6, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end
	end
end)
