if not SERVER then return end
if not MilBase or not MilBase.Naval or not MilBase.Galaxy then return end
if MilBase.Naval.SkyboxPilotLoaded then return end
MilBase.Naval.SkyboxPilotLoaded = true

local N = MilBase.Naval
local G = MilBase.Galaxy
local naval = MilBase.Config.NavalOperations or {}

local NET_START = "MilBase_SkyboxPilot_Start"
local NET_STOP = "MilBase_SkyboxPilot_Stop"
local NET_INPUT = "MilBase_SkyboxPilot_Input"
local NET_EXIT = "MilBase_SkyboxPilot_Exit"
local NET_COMMS = "MilBase_SkyboxPilot_Comms"
local NET_FEEDBACK = "MilBase_SkyboxPilot_Feedback"
util.AddNetworkString(NET_START)
util.AddNetworkString(NET_STOP)
util.AddNetworkString(NET_INPUT)
util.AddNetworkString(NET_EXIT)
util.AddNetworkString(NET_COMMS)
util.AddNetworkString(NET_FEEDBACK)

local FLAG_FIRE = 1
local FLAG_BOOST = 2
local FLAG_BRAKE = 4
local FLAG_LOCK = 8
local FLAG_CYCLE = 16
local FLAG_ADVANCED = 32
local FLAG_ORDER = 64
local FLAG_CYCLE_FRIENDLY = 128
local FLAG_THREAT = 256
local FLAG_SECONDARY = 512
local FLAG_WING_ORDER = 1024
local FLAG_RETURN_ASSIST = 2048
local FLAG_COLLISION_OFF = 4096

local PILOT_ORDERS = {
	[1] = { id = "hail", label = "HAIL / IDENTIFY" },
	[2] = { id = "follow", label = "FOLLOW MY LEAD" },
	[3] = { id = "form_left", label = "FORM ON MY LEFT" },
	[4] = { id = "form_right", label = "FORM ON MY RIGHT" },
	[5] = { id = "hold", label = "HOLD POSITION" },
	[6] = { id = "leave", label = "LEAVE THE AREA" },
	[7] = { id = "break_off", label = "BREAK OFF ATTACK" },
	[8] = { id = "warn", label = "FINAL WARNING" },
	[9] = { id = "surrender", label = "HEAVE TO / SURRENDER" },
}

local WING_ORDERS = {
	[1] = { id = "tight", label = "TIGHT FORMATION" },
	[2] = { id = "wide", label = "WIDE FORMATION" },
	[3] = { id = "attack_target", label = "ATTACK MY TARGET" },
	[4] = { id = "cover", label = "COVER ME" },
	[5] = { id = "break_engage", label = "BREAK AND ENGAGE" },
	[6] = { id = "regroup", label = "REGROUP" },
	[7] = { id = "return", label = "RETURN TO CARRIER" },
	[8] = { id = "split_pairs", label = "SPLIT INTO PAIRS" },
}

local TARGET_SUBSYSTEMS = { "hull", "engines", "weapons", "shields" }
local ASSIST_MODES = { "combat", "cruise", "formation" }


N.SkyboxPilotControls = N.SkyboxPilotControls or {}

local function profileFor(id)
	local profiles = naval.SkyboxPilotProfiles or {}
	local source = profiles[id] or profiles.default or {}
	return {
		label = tostring(source.label or "STARFIGHTER"),
		maximumSpeed = math.max(20, tonumber(source.maximumSpeed) or 195),
		cruiseThrottle = math.Clamp(tonumber(source.cruiseThrottle) or 0.58, 0, 1),
		boostMultiplier = math.Clamp(tonumber(source.boostMultiplier) or 1.18, 1, 1.75),
		accelerate = math.max(10, tonumber(source.accelerate) or 82),
		brake = math.max(10, tonumber(source.brake) or 118),
		airBrake = math.max(10, tonumber(source.airBrake) or 225),
		jerk = math.max(20, tonumber(source.jerk) or 190),
		steering = math.max(10, tonumber(source.steering) or 54),
		bank = math.max(0, tonumber(source.bank) or 15),
		manualBank = math.max(0, tonumber(source.manualBank) or 42),
		bankRate = math.max(10, tonumber(source.bankRate) or 82),
		turnThrottle = math.Clamp(tonumber(source.turnThrottle) or 0.72, 0.1, 1),
		lowSpeedControl = math.Clamp(tonumber(source.lowSpeedControl) or 0.42, 0.15, 1),
		highSpeedControl = math.Clamp(tonumber(source.highSpeedControl) or 0.88, 0.25, 1),
		weaponDamage = math.max(1, tonumber(source.weaponDamage) or 26),
		fireInterval = math.max(0.06, tonumber(source.fireInterval) or 0.16),
		weaponRange = math.max(300, tonumber(source.weaponRange) or 4200),
		weaponCone = math.Clamp(tonumber(source.weaponCone) or 7, 1, 35),
		lockCone = math.Clamp(tonumber(source.lockCone)
			or tonumber(naval.SkyboxPilotTargetLockCone) or 20, 3, 60),
		projectileSpeed = math.max(200, tonumber(source.projectileSpeed) or 1450),
		weaponConvergence = math.max(300, tonumber(source.weaponConvergence) or 1800),
		weaponHeatPerShot = math.Clamp(tonumber(source.weaponHeatPerShot) or 0.075, 0.01, 0.5),
		weaponHeatCoolRate = math.Clamp(tonumber(source.weaponHeatCoolRate) or 0.24, 0.02, 2),
		weaponHeatResume = math.Clamp(tonumber(source.weaponHeatResume) or 0.55, 0.05, 0.95),
		muzzleSeparation = math.Clamp(tonumber(source.muzzleSeparation) or 0.34, 0, 1.5),
		muzzleForward = math.Clamp(tonumber(source.muzzleForward) or 0.48, -0.5, 1.5),
		optimalTurnMin = math.Clamp(tonumber(source.optimalTurnMin) or 0.36, 0.05, 0.9),
		optimalTurnMax = math.Clamp(tonumber(source.optimalTurnMax) or 0.78, 0.1, 1.2),
		boostDrain = math.Clamp(tonumber(source.boostDrain) or 0.24, 0.03, 1),
		boostRecharge = math.Clamp(tonumber(source.boostRecharge) or 0.16, 0.02, 1),
		missileDamage = math.max(1, tonumber(source.missileDamage) or 110),
		missileRange = math.max(500, tonumber(source.missileRange) or 6000),
		missileCooldown = math.max(1, tonumber(source.missileCooldown) or 6),
		missileAmmo = math.max(0, math.floor(tonumber(source.missileAmmo) or 4)),
		missileFlightTime = math.Clamp(tonumber(source.missileFlightTime) or 1.15, 0.35, 4),
		subsystemDamage = math.Clamp(tonumber(source.subsystemDamage) or 0.055, 0.005, 0.4),
	}
end

local function flightProfile(profile, speedFraction, braking)
	speedFraction = math.Clamp(tonumber(speedFraction) or 0, 0, 1.5)
	local controlScale
	if speedFraction < 0.32 then
		controlScale = Lerp(speedFraction / 0.32, profile.lowSpeedControl, 1)
	elseif speedFraction > 0.82 then
		controlScale = Lerp(math.Clamp((speedFraction - 0.82) / 0.38, 0, 1),
			1, profile.highSpeedControl)
	else
		controlScale = 1
	end
	return {
		accelerate = profile.accelerate,
		brake = braking and profile.airBrake or profile.brake,
		jerk = profile.jerk,
		steering = profile.steering * controlScale,
		bank = profile.bank,
		manualBank = profile.manualBank,
		bankRate = profile.bankRate,
		turnThrottle = profile.turnThrottle,
	}
end

local function findPilotShip(squadron)
	for _, ship in ipairs(squadron and squadron.visuals or {}) do
		if IsValid(ship) and ship:GetClass() == "mb_galaxy_ship"
		and not ship.mb_destroyed and not IsValid(ship.mb_skyboxPilot) then
			return ship
		end
	end
	return nil
end

local function currentPilotName(squadron)
	local names, firstPilot = {}, nil
	for _, ship in ipairs(squadron and squadron.visuals or {}) do
		local pilot = IsValid(ship) and ship.mb_skyboxPilot or nil
		if IsValid(pilot) then
			names[#names + 1] = pilot:Nick()
			firstPilot = firstPilot or pilot
		end
	end
	return table.concat(names, ", "), firstPilot
end
N.SkyboxPilotName = currentPilotName

local function notifyStop(ply, reason)
	if not IsValid(ply) then return end
	net.Start(NET_STOP)
		net.WriteString(string.sub(tostring(reason or ""), 1, 180))
	net.Send(ply)
end

local function clearPilotNetwork(ship)
	if not IsValid(ship) then return end
	ship:SetNW2Entity("MBSkyboxPilot", NULL)
	ship:SetNW2Entity("MBSkyboxPilotTarget", NULL)
	ship:SetNW2Entity("MBSkyboxPilotSoftTarget", NULL)
	ship:SetNW2Float("MBSkyboxPilotThrottle", 0)
	ship:SetNW2Float("MBSkyboxPilotHeat", 0)
	ship:SetNW2Float("MBSkyboxPilotBoundary", 0)
	ship:SetNW2Float("MBSkyboxPilotBoundaryDistance", 0)
	ship:SetNW2Bool("MBSkyboxPilotBoost", false)
	ship:SetNW2Bool("MBSkyboxPilotBrake", false)
	ship:SetNW2Bool("MBSkyboxPilotAdvanced", false)
	ship:SetNW2Bool("MBSkyboxPilotLocked", false)
	ship:SetNW2Bool("MBSkyboxPilotCanFire", false)
	ship:SetNW2Bool("MBSkyboxPilotOverheated", false)
	ship:SetNW2Bool("MBSkyboxPilotIncomingLock", false)
	ship:SetNW2Bool("MBSkyboxPilotReturnAssist", false)
	ship:SetNW2Bool("MBSkyboxPilotCritical", false)
	ship:SetNW2Float("MBSkyboxPilotBoostReserve", 0)
	ship:SetNW2Float("MBSkyboxPilotCollision", 0)
	ship:SetNW2Float("MBSkyboxPilotMissileCooldown", 0)
	ship:SetNW2Int("MBSkyboxPilotMissiles", 0)
	ship:SetNW2Int("MBSkyboxPilotAssistMode", 1)
	ship:SetNW2Int("MBSkyboxPilotTargetSubsystem", 1)
	ship:SetNW2Vector("MBSkyboxPilotLeadPoint", vector_origin)
end

local function shipDisplayName(ship)
	if not IsValid(ship) then return "UNKNOWN CONTACT" end
	local name = ship.GetShipName and ship:GetShipName() or ship:GetClass()
	name = string.Trim(tostring(name or "UNKNOWN CONTACT"))
	return name ~= "" and name or "UNKNOWN CONTACT"
end

local function sendPilotRadio(ply, source, title, body, tone, duration)
	if not IsValid(ply) then return end
	net.Start(NET_COMMS)
		net.WriteEntity(IsValid(source) and source or NULL)
		net.WriteString(string.sub(tostring(title or "INCOMING TRANSMISSION"), 1, 96))
		net.WriteString(string.sub(tostring(body or ""), 1, 420))
		net.WriteString(string.sub(tostring(tone or "info"), 1, 16))
		net.WriteFloat(math.Clamp(tonumber(duration) or 5.5, 2, 12))
	net.Send(ply)
end
N.SendSkyboxPilotRadio = sendPilotRadio


local function sendPilotFeedback(ply, kind, label)
	if not IsValid(ply) then return end
	net.Start(NET_FEEDBACK)
		net.WriteString(string.sub(tostring(kind or "info"), 1, 16))
		net.WriteString(string.sub(tostring(label or ""), 1, 120))
	net.Send(ply)
end

local function ensureShipSystems(ship)
	if not IsValid(ship) then return nil end
	ship.mb_skyboxSystems = ship.mb_skyboxSystems or {
		engines = 1,
		controls = 1,
		weapons = 1,
		shields = 1,
	}
	for key, value in pairs(ship.mb_skyboxSystems) do
		ship.mb_skyboxSystems[key] = math.Clamp(tonumber(value) or 1, 0, 1)
	end
	return ship.mb_skyboxSystems
end

local function networkShipSystems(ship)
	if not IsValid(ship) then return end
	local systems = ensureShipSystems(ship)
	ship:SetNW2Float("MBSkyboxSystemEngines", systems.engines)
	ship:SetNW2Float("MBSkyboxSystemControls", systems.controls)
	ship:SetNW2Float("MBSkyboxSystemWeapons", systems.weapons)
	ship:SetNW2Float("MBSkyboxSystemShields", systems.shields)
	ship.mb_galaxyShieldRegenMultiplier = 0.15 + systems.shields * 0.85
	ship.mb_galaxyWeaponIntervalMultiplier = 1 + (1 - systems.weapons) * 1.75
end

local function systemForHit(ship, position)
	if not IsValid(ship) or not isvector(position) then return "controls" end
	local localPos = ship:WorldToLocal(position)
	local radius = math.max(8, ship:GetCombatRadius())
	if localPos.x < -radius * 0.16 then return "engines" end
	if math.abs(localPos.y) > radius * 0.22 then return "weapons" end
	if localPos.x > radius * 0.22 then return "controls" end
	return "shields"
end

local function applySystemDamage(ship, system, amount)
	if not IsValid(ship) then return 1 end
	local systems = ensureShipSystems(ship)
	if system == "hull" then return 1 end
	if system == "shields" and ship:GetMaxShield() <= 0 then system = "controls" end
	if systems[system] == nil then system = "controls" end
	systems[system] = math.Clamp(systems[system] - math.max(0, tonumber(amount) or 0), 0, 1)
	networkShipSystems(ship)
	return systems[system]
end

local function effectiveSystem(ship, key)
	local systems = ensureShipSystems(ship)
	return systems and math.Clamp(tonumber(systems[key]) or 1, 0, 1) or 1
end

function N.StopSkyboxPiloting(ply, reason, silent)
	local control = N.SkyboxPilotControls[ply]
	if not control then return false, "No skybox craft is under your control" end
	N.SkyboxPilotControls[ply] = nil
	if IsValid(ply) then
		ply.mb_skyboxPilotControl = nil
		ply:SetNW2Entity("MBSkyboxPilotShip", NULL)
		ply:SetNW2String("MBSkyboxPilotSquadron", "")
	end

	local ship = control.ship
	if IsValid(ship) then
		ship.mb_galaxyPilotControlled = nil
		ship.mb_skyboxPilot = nil
		ship.mb_galaxyPilotProfile = control.oldProfile
		ship.mb_galaxyPilotRollTarget = nil
		ship.mb_galaxyPilotManualMode = nil
		ship.mb_galaxyHoldForPlayerDeparture = control.oldHold
		ship.mb_galaxyPlayerDeparting = control.oldDeparting
		clearPilotNetwork(ship)
		ship:SetShipState(control.oldState or "returning to squadron control")
		if control.oldDieAt and control.oldDieAt > 0 then
			ship:SetDieAt(control.oldDieAt)
		end
	end

	if IsValid(ply) and not control.wasFrozen then ply:Freeze(false) end
	if IsValid(ply) then
		if not silent then notifyStop(ply, reason or "Skybox flight control released.") end
		if N.AddLog then
			N.AddLog("flight", "Skybox pilot released",
				ply:Nick() .. " released " .. tostring(control.squadronName or control.id)
					.. " remote flight control.", ply)
		end
	end

	timer.Simple(0, function()
		if IsValid(ship) and N.ApplySquadronMission then
			N.ApplySquadronMission(control.id)
		elseif IsValid(ship) and G.AssignAutonomousShipMotion then
			ship:SetFlightVelocity(vector_origin)
			G.AssignAutonomousShipMotion(ship, "pilot released")
		end
	end)
	return true, reason or "Skybox flight control released"
end

function N.StartSkyboxPiloting(ply, id)
	if naval.SkyboxPilotEnabled == false then
		return false, "Skybox pilot control is disabled"
	end
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then
		return false, "A living pilot is required"
	end
	if N.CanUseConsole and not N.CanUseConsole(ply) then
		return false, "Republic Navy credentials are required"
	end
	if ply:InVehicle() then return false, "Exit your current vehicle first" end

	id = N.CleanKey and N.CleanKey(id) or string.lower(tostring(id or ""))
	local squadron = N.State and N.State.squadrons and N.State.squadrons[id]
	if not squadron then return false, "Unknown squadron" end
	if N.SkyboxPilotControls[ply] then
		if N.SkyboxPilotControls[ply].id == id then
			return N.StopSkyboxPiloting(ply, "Skybox flight control released.")
		end
		N.StopSkyboxPiloting(ply, "Switching remote craft.", true)
	end

	local ship = findPilotShip(squadron)
	if not IsValid(ship) then
		if #(squadron.visuals or {}) > 0 then
			return false, "Every deployed " .. squadron.name
				.. " craft already has a remote pilot"
		end
		return false, "Launch " .. squadron.name .. " before taking remote control"
	end
	local profile = profileFor(id)
	local initialVelocity = isvector(ship.mb_galaxyActualWorldVelocity)
		and ship.mb_galaxyActualWorldVelocity or ship:GetFlightVelocity()
	local initialAim = initialVelocity:LengthSqr() > 1
		and initialVelocity:Angle() or ship:GetAngles()
	initialAim.r = 0
	local control = {
		ship = ship,
		id = id,
		squadronName = squadron.name,
		profile = profile,
		aim = initialAim,
		throttle = profile.cruiseThrottle,
		fire = false,
		boost = false,
		brake = false,
		advanced = false,
		roll = 0,
		selectedOrder = 1,
		selectedWingOrder = 1,
		assistMode = 1,
		returnAssist = false,
		collisionAssist = true,
		targetSubsystem = 1,
		boostReserve = 1,
		missiles = profile.missileAmmo,
		heat = 0,
		overheated = false,
		lastInput = CurTime(),
		lastThink = CurTime(),
		nextShot = CurTime(),
		nextThreatScan = 0,
		wasFrozen = ply:IsFrozen(),
		oldProfile = ship.mb_galaxyPilotProfile,
		oldHold = ship.mb_galaxyHoldForPlayerDeparture,
		oldDeparting = ship.mb_galaxyPlayerDeparting,
		oldState = ship:GetShipState(),
		oldDieAt = ship:GetDieAt(),
	}
	N.SkyboxPilotControls[ply] = control
	ply.mb_skyboxPilotControl = control
	ply:SetNW2Entity("MBSkyboxPilotShip", ship)
	ply:SetNW2String("MBSkyboxPilotSquadron", id)

	ship.mb_galaxyPilotControlled = true
	ship.mb_skyboxPilot = ply
	ship.mb_galaxyPilotProfile = flightProfile(profile, 0.5, false)
	ship.mb_galaxyHoldForPlayerDeparture = true
	ship.mb_galaxyPlayerDeparting = false
	ship:SetNW2Entity("MBSkyboxPilot", ply)
	ship:SetNW2Float("MBSkyboxPilotThrottle", profile.cruiseThrottle)
	ship:SetNW2Float("MBSkyboxPilotBoostReserve", 1)
	ship:SetNW2Int("MBSkyboxPilotMissiles", profile.missileAmmo)
	ship:SetNW2Int("MBSkyboxPilotAssistMode", 1)
	ship:SetNW2Int("MBSkyboxPilotTargetSubsystem", 1)
	ensureShipSystems(ship)
	networkShipSystems(ship)
	ship:SetDieAt(0)
	ship:SetShipState("player-controlled " .. string.lower(profile.label))
	if ship.ClearCombatTarget then ship:ClearCombatTarget() end
	ship.mb_galaxyFormationFlight = nil
	if G.ClearShipFlightRoute then G.ClearShipFlightRoute(ship) end
	ply:Freeze(true)

	net.Start(NET_START)
		net.WriteEntity(ship)
		net.WriteString(id)
		net.WriteFloat(profile.cruiseThrottle)
		net.WriteString(profile.label)
	net.Send(ply)

	if N.AddLog then
		N.AddLog("flight", "Skybox pilot linked",
			ply:Nick() .. " assumed remote control of " .. squadron.name
				.. " craft " .. tostring(ship.mb_navalCraftNumber or 1) .. ".", ply)
	end
	return true, "Remote " .. profile.label
		.. " linked. Mouse aim enabled; W/S throttle, CTRL brake, A/D roll, RMB lock, R/T/Y target, M mode, ALT free-look, B assist, X/V orders, E exits."
end

function N.ToggleSkyboxPiloting(ply, id)
	local current = N.SkyboxPilotControls[ply]
	if current and current.id == (N.CleanKey and N.CleanKey(id) or id) then
		return N.StopSkyboxPiloting(ply, "Skybox flight control released.")
	end
	return N.StartSkyboxPiloting(ply, id)
end

local function shipFaction(ship)
	return string.lower(tostring(IsValid(ship)
		and (ship.mb_galaxyTrueFaction or ship:GetFaction()) or ""))
end

local function validContact(ship, target)
	return IsValid(ship) and IsValid(target) and target ~= ship
		and target:GetClass() == "mb_galaxy_ship" and not target.mb_destroyed
		and target:GetHull() > 0
end

local function contactCandidates(ship, aim, range)
	local candidates = {}
	if not IsValid(ship) then return candidates end
	local origin = ship:WorldSpaceCenter()
	local direction = isangle(aim) and aim:Forward() or ship:GetForward()
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, target) then
			local delta = target:WorldSpaceCenter() - origin
			local distance = delta:Length()
			if distance > 1 and distance <= range then
				local normal = delta / distance
				candidates[#candidates + 1] = {
					entity = target,
					distance = distance,
					dot = direction:Dot(normal),
					index = target:EntIndex(),
				}
			end
		end
	end
	table.sort(candidates, function(a, b)
		local aScore = a.dot * 3 - a.distance / math.max(range, 1)
		local bScore = b.dot * 3 - b.distance / math.max(range, 1)
		if math.abs(aScore - bScore) < 0.001 then return a.index < b.index end
		return aScore > bScore
	end)
	return candidates
end

local function contactTarget(ship, aim, range, cone)
	local minimumDot = math.cos(math.rad(cone))
	for _, candidate in ipairs(contactCandidates(ship, aim, range)) do
		if candidate.dot >= minimumDot then return candidate.entity end
	end
	return nil
end

local function contactIsHostile(ship, target)
	if not validContact(ship, target) then return false end
	local faction = shipFaction(target)
	return target:GetHostile() or faction == "cis" or faction == "pirate"
end

local function contactIsFriendly(ship, target)
	if not validContact(ship, target) then return false end
	local faction = shipFaction(target)
	return faction == "republic" or faction == "civilian" or faction == "neutral"
end

local function cycleContactTarget(control, filter)
	local ship = control.ship
	if not IsValid(ship) then return nil end
	local range = math.max(control.profile.weaponRange,
		math.max(500, tonumber(naval.SkyboxPilotTargetCycleRange) or 7000))
	local candidates = {}
	for _, candidate in ipairs(contactCandidates(ship, control.aim, range)) do
		if not filter or filter(ship, candidate.entity) then
			candidates[#candidates + 1] = candidate
		end
	end
	if #candidates == 0 then return nil end
	local currentIndex = 0
	for index, candidate in ipairs(candidates) do
		if candidate.entity == control.lockedTarget then
			currentIndex = index
			break
		end
	end
	return candidates[currentIndex % #candidates + 1].entity
end

local function nearestThreat(control)
	local ship = control.ship
	if not IsValid(ship) then return nil end
	if validContact(ship, control.lastAttacker) then return control.lastAttacker end
	local best, bestScore
	local range = math.max(500, tonumber(naval.SkyboxPilotTargetCycleRange) or 7000)
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, target) then
			local attacking = target.mb_combatTarget == ship
				or target:GetNW2Entity("MBSkyboxPilotTarget") == ship
			local hostile = contactIsHostile(ship, target)
			if attacking or hostile then
				local distance = ship:GetPos():Distance(target:GetPos())
				if distance <= range then
					local score = (attacking and 100000 or 0) - distance
					if not bestScore or score > bestScore then
						best, bestScore = target, score
					end
				end
			end
		end
	end
	return best
end

local function setLockedTarget(control, target)
	control.lockedTarget = validContact(control.ship, target) and target or nil
end

local function targetVelocity(target)
	if not IsValid(target) then return vector_origin end
	if isvector(target.mb_galaxyActualWorldVelocity) then
		return Vector(target.mb_galaxyActualWorldVelocity)
	end
	local velocity = target:GetFlightVelocity()
	return isvector(velocity) and Vector(velocity) or vector_origin
end

local function shipVelocity(ship)
	if not IsValid(ship) then return vector_origin end
	if isvector(ship.mb_galaxyActualWorldVelocity) then
		return Vector(ship.mb_galaxyActualWorldVelocity)
	end
	local velocity = ship:GetFlightVelocity()
	return isvector(velocity) and Vector(velocity) or vector_origin
end

local function interceptPoint(ship, target, projectileSpeed)
	if not IsValid(ship) or not IsValid(target) then return vector_origin end
	local origin = ship:WorldSpaceCenter()
	local targetPosition = target:WorldSpaceCenter()
	local relativePosition = targetPosition - origin
	local relativeVelocity = targetVelocity(target) - shipVelocity(ship)
	local speed = math.max(1, tonumber(projectileSpeed) or 1450)
	local a = relativeVelocity:Dot(relativeVelocity) - speed * speed
	local b = 2 * relativePosition:Dot(relativeVelocity)
	local c = relativePosition:Dot(relativePosition)
	local time = 0
	if math.abs(a) < 0.0001 then
		if math.abs(b) > 0.0001 then time = -c / b end
	else
		local discriminant = b * b - 4 * a * c
		if discriminant >= 0 then
			local root = math.sqrt(discriminant)
			local first = (-b - root) / (2 * a)
			local second = (-b + root) / (2 * a)
			if first > 0 and second > 0 then
				time = math.min(first, second)
			elseif first > 0 then
				time = first
			elseif second > 0 then
				time = second
			end
		end
	end
	time = math.Clamp(time, 0, 6)
	return targetPosition + targetVelocity(target) * time
end

local function travelForward(ship)
	local velocity = shipVelocity(ship)
	if velocity:LengthSqr() > 4 then return velocity:GetNormalized() end
	return ship:GetForward()
end

local function weaponContact(ship, profile)
	if not IsValid(ship) then return nil, vector_origin end
	local origin = ship:WorldSpaceCenter()
	local forward = travelForward(ship)
	local minimumDot = math.cos(math.rad(profile.weaponCone))
	local bestTarget, bestLead, bestScore = nil, vector_origin, -math.huge
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, target) then
			local lead = interceptPoint(ship, target, profile.projectileSpeed)
			local delta = lead - origin
			local distance = delta:Length()
			if distance > 1 and distance <= profile.weaponRange then
				delta:Mul(1 / distance)
				local dot = forward:Dot(delta)
				if dot >= minimumDot then
					local score = dot * 4 - distance / math.max(profile.weaponRange, 1)
					if score > bestScore then
						bestScore = score
						bestTarget = target
						bestLead = lead
					end
				end
			end
		end
	end
	return bestTarget, bestLead
end

local function boundaryDirection(ship, desired)
	if not IsValid(ship) or not G.SkyboxFrame then return desired, 0, 0 end
	local center, _, mins, maxs = G.SkyboxFrame()
	local pos = ship:GetPos()
	local margin = math.max(60, tonumber(naval.SkyboxPilotBoundaryMargin) or 260)
	local nearest = math.min(pos.x - mins.x, maxs.x - pos.x,
		pos.y - mins.y, maxs.y - pos.y, pos.z - mins.z, maxs.z - pos.z)
	local pressure = math.Clamp(1 - nearest / margin, 0, 1)
	if pressure <= 0 then return desired, 0, math.max(0, nearest) end
	local inward = center - pos
	if inward:LengthSqr() <= 1 then return desired, pressure, math.max(0, nearest) end
	inward:Normalize()
	local strength = math.Clamp(tonumber(naval.SkyboxPilotBoundaryStrength) or 0.88, 0.1, 1)
	local blend = math.Clamp(pressure * pressure * strength, 0, 0.95)
	local corrected = LerpVector(blend, desired, inward)
	if corrected:LengthSqr() <= 0.001 then
		return inward, pressure, math.max(0, nearest)
	end
	corrected:Normalize()
	return corrected, pressure, math.max(0, nearest)
end

local function nearestFriendlyCapital(ship)
	local best, bestDistance
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, target) and shipFaction(target) == "republic"
		and target:GetCapital() then
			local distance = ship:GetPos():DistToSqr(target:GetPos())
			if not bestDistance or distance < bestDistance then
				best, bestDistance = target, distance
			end
		end
	end
	return best
end

local function assistedFormationVector(control, requestedSpeed)
	local ship = control.ship
	local leader = validContact(ship, control.lockedTarget) and control.lockedTarget or nil
	if not IsValid(leader) or not contactIsFriendly(ship, leader) then return nil end
	local spacing = (math.max(8, ship:GetCombatRadius())
		+ math.max(8, leader:GetCombatRadius())) * 2.2 + 55
	local desiredPosition = leader:WorldSpaceCenter() - leader:GetForward() * spacing
		+ leader:GetRight() * spacing * 0.48
	local delta = desiredPosition - ship:WorldSpaceCenter()
	if delta:LengthSqr() <= 4 then return leader:GetForward(), math.min(requestedSpeed, targetVelocity(leader):Length()) end
	local catchup = math.Clamp(delta:Length() / math.max(spacing * 2, 1), 0, 1)
	return delta:GetNormalized(), math.max(targetVelocity(leader):Length(), requestedSpeed * (0.55 + catchup * 0.45))
end

local function returnAssistVector(control, requestedSpeed)
	local ship = control.ship
	local carrier = nearestFriendlyCapital(ship)
	if not IsValid(carrier) then
		local center = G.SkyboxFrame and select(1, G.SkyboxFrame()) or vector_origin
		local delta = center - ship:GetPos()
		return delta:LengthSqr() > 1 and delta:GetNormalized() or ship:GetForward(), requestedSpeed * 0.72
	end
	local spacing = math.max(180, carrier:GetCombatRadius() * 1.55)
	local desiredPosition = carrier:WorldSpaceCenter() - carrier:GetForward() * spacing
		+ carrier:GetUp() * math.max(35, carrier:GetCombatRadius() * 0.18)
	local delta = desiredPosition - ship:WorldSpaceCenter()
	local distance = delta:Length()
	if distance <= math.max(35, ship:GetCombatRadius() * 2.2) then
		return carrier:GetForward(), math.min(45, targetVelocity(carrier):Length() + 10), true
	end
	return delta:GetNormalized(), math.min(requestedSpeed, math.max(50, distance * 0.48)), false
end

local function collisionAvoidance(ship, desired, speed)
	if not IsValid(ship) then return desired, 0 end
	local radius = math.max(10, ship:GetCombatRadius())
	local lookAhead = math.max(radius * 5, math.max(40, speed) * 1.35)
	local origin = ship:WorldSpaceCenter()
	local pressure = 0
	local correction = Vector(desired)
	local trace = util.TraceHull({
		start = origin,
		endpos = origin + desired * lookAhead,
		mins = Vector(-radius * 0.35, -radius * 0.35, -radius * 0.35),
		maxs = Vector(radius * 0.35, radius * 0.35, radius * 0.35),
		mask = MASK_SOLID_BRUSHONLY,
		filter = ship,
	})
	if trace.Hit then
		pressure = math.max(pressure, 1 - trace.Fraction)
		correction:Add(trace.HitNormal * (1.4 + pressure * 2.4))
	end
	if G.PlanetClearanceAt
	and not G.PlanetClearanceAt(origin + desired * lookAhead, radius) then
		pressure = math.max(pressure, 0.8)
		local center = G.SkyboxFrame and select(1, G.SkyboxFrame()) or origin
		local inward = center - origin
		if inward:LengthSqr() > 1 then
			inward:Normalize()
			correction:Add(inward * 2.4)
		end
	end
	for _, target in ipairs(ents.FindInSphere(origin, lookAhead)) do
		if validContact(ship, target) then
			local delta = target:WorldSpaceCenter() - origin
			local distance = math.max(1, delta:Length())
			local combined = radius + math.max(8, target:GetCombatRadius()) + 35
			local ahead = desired:Dot(delta / distance)
			if ahead > 0.15 and distance < combined * 3.2 then
				local localPressure = math.Clamp(1 - (distance - combined) / math.max(combined * 2.2, 1), 0, 1)
				pressure = math.max(pressure, localPressure)
				correction:Sub((delta / distance) * localPressure * 2.8)
			end
		end
	end
	if correction:LengthSqr() <= 0.001 then return desired, pressure end
	correction:Normalize()
	return correction, pressure
end

local function muzzleOrigins(ship, profile)
	local center = ship:WorldSpaceCenter()
	local radius = math.max(8, ship:GetCombatRadius())
	local forward = ship:GetForward()
	local right = ship:GetRight()
	local front = center + forward * radius * profile.muzzleForward
	local separation = radius * profile.muzzleSeparation
	if separation <= 0.5 then return { front } end
	return { front - right * separation, front + right * separation }
end

local function clearShipOrders(ship)
	if not IsValid(ship) then return end
	ship.mb_galaxyFormationFlight = nil
	if G.ClearShipFlightRoute then G.ClearShipFlightRoute(ship) end
end

local function defensiveDamage(ship)
	if not IsValid(ship) then return 18, 2.8 end
	local faction = shipFaction(ship)
	local capital = ship:GetCapital()
	if faction == "cis" then return capital and 80 or 34, capital and 3.2 or 1.9 end
	if faction == "pirate" then return capital and 62 or 28, capital and 3.6 or 2.2 end
	if faction == "republic" then return capital and 70 or 30, capital and 3.4 or 2.1 end
	return capital and 48 or 20, capital and 4 or 2.8
end

local function makeShipDefend(target, attacker, state)
	if not validContact(attacker, target) then return false end
	clearShipOrders(target)
	local damage, interval = defensiveDamage(target)
	local faction = shipFaction(target)
	if faction == "cis" or faction == "pirate" then target:SetHostile(true) end
	target:SetDieAt(0)
	target.mb_galaxyHoldForPlayerDeparture = true
	target.mb_galaxyPlayerDeparting = false
	target:SetCombatTarget(attacker, damage, interval)
	target:SetShipState(state or "returning fire")
	target.mb_skyboxCommandedBy = nil
	return true
end

local function commandShipLeave(target, reason)
	if not IsValid(target) then return false end
	clearShipOrders(target)
	if target.ClearCombatTarget then target:ClearCombatTarget() end
	target:SetShipState(reason or "departing under orders")
	target.mb_galaxyHoldForPlayerDeparture = false
	target.mb_galaxyPlayerDeparting = true
	local center = G.SkyboxFrame and select(1, G.SkyboxFrame()) or vector_origin
	local away = target:GetPos() - center
	if away:LengthSqr() < 1 then away = target:GetForward() end
	away.z = away.z + math.Rand(-0.12, 0.12) * math.max(away:Length(), 1)
	away:Normalize()
	local speed = target:GetCapital() and 62 or 88
	target:SetFlightVelocity(away * speed)
	target:SetDieAt(CurTime() + math.max(12,
		tonumber(naval.SkyboxPilotOrderedDepartureTime) or 24))
	return true
end

local function pilotAggressionState(target, attacker)
	target.mb_skyboxPilotAggression = target.mb_skyboxPilotAggression or {}
	local key = IsValid(attacker) and attacker:EntIndex() or 0
	local state = target.mb_skyboxPilotAggression[key]
	if not state then
		state = { hits = 0, damage = 0, phase = "none", firstAt = CurTime() }
		target.mb_skyboxPilotAggression[key] = state
	end
	return state
end

local function reactToPilotHit(ply, attacker, target, damage)
	if not IsValid(ply) or not validContact(attacker, target) then return end
	local state = pilotAggressionState(target, attacker)
	state.hits = (state.hits or 0) + 1
	state.damage = (state.damage or 0) + math.max(0, tonumber(damage) or 0)
	state.lastAt = CurTime()
	local faction = shipFaction(target)
	local name = shipDisplayName(target)
	local hullThreshold = target:GetMaxHull() * math.Clamp(
		tonumber(naval.SkyboxPilotFriendlyFireDamageThreshold) or 0.12, 0.02, 0.8)
	local hitThreshold = math.max(2, math.floor(
		tonumber(naval.SkyboxPilotFriendlyFireHitThreshold) or 3))

	if faction == "cis" then
		if state.phase ~= "defending" then
			state.phase = "defending"
			makeShipDefend(target, attacker, "engaging Republic attacker")
			sendPilotRadio(ply, target, "CIS HOSTILE RESPONSE",
				name .. ': "Republic aggression confirmed. All batteries, destroy that fighter."',
				"hostile", 6)
		end
		return
	end

	if faction == "pirate" then
		if state.phase ~= "defending" then
			state.phase = "defending"
			makeShipDefend(target, attacker, "retaliating against Republic fighter")
			sendPilotRadio(ply, target, "PIRATE RETALIATION",
				name .. ': "Bad choice, Republic. Gunners, light them up!"', "hostile", 6)
		end
		return
	end

	if faction == "republic" then
		if state.hits >= hitThreshold or state.damage >= hullThreshold then
			if state.phase ~= "defending" then
				state.phase = "defending"
				makeShipDefend(target, attacker, "defending against rogue Republic fighter")
				sendPilotRadio(ply, target, "FRIENDLY FIRE — WEAPONS FREE",
					name .. ': "You ignored a direct cease-fire order. We are defending ourselves."',
					"hostile", 7)
			end
		elseif state.phase == "none" then
			state.phase = "warned"
			target:SetShipState("issuing friendly-fire warning")
			sendPilotRadio(ply, target, "REPUBLIC CEASE-FIRE ORDER",
				name .. ': "Republic fighter, cease fire immediately! Confirm weapons safe."',
				"warning", 6)
		elseif state.phase == "warned" and state.hits == 2 then
			sendPilotRadio(ply, target, "FINAL REPUBLIC WARNING",
				name .. ': "This is your final warning. Break off or we will return fire."',
				"warning", 6)
		end
		return
	end

	-- Civilian and unidentified traffic either panic and flee or use whatever
	-- defensive weapons they have. Continued attacks always trigger self-defence.
	local defendChance = math.Clamp(tonumber(naval.SkyboxPilotCivilianDefenseChance)
		or 0.35, 0, 1)
	local shouldDefend = state.hits >= 2 or target:GetCombat()
		or target:GetCapital() or math.Rand(0, 1) <= defendChance
	if shouldDefend then
		if state.phase ~= "defending" then
			state.phase = "defending"
			makeShipDefend(target, attacker, "civilian crew defending themselves")
			sendPilotRadio(ply, target, "CIVILIAN DISTRESS CHANNEL",
				name .. ': "Stop shooting! We are defending ourselves—keep away from us!"',
				"distress", 7)
		end
	elseif state.phase == "none" then
		state.phase = "fleeing"
		commandShipLeave(target, "fleeing Republic weapons fire")
		sendPilotRadio(ply, target, "CIVILIAN DISTRESS CHANNEL",
			name .. ': "Republic fighter, stop! We are civilians! We are leaving—do not fire!"',
			"distress", 7)
	end
end

local function followerOffset(leader, follower)
	local count = 0
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local formation = IsValid(ship) and ship.mb_galaxyFormationFlight or nil
		if formation and formation.leader == leader then count = count + 1 end
	end
	local leaderRadius = math.max(10, leader:GetCombatRadius())
	local followerRadius = math.max(10, follower:GetCombatRadius())
	local spacing = (leaderRadius + followerRadius) * math.max(1.4,
		tonumber(naval.SkyboxPilotOrderFormationSpacing) or 2.4) + 70
	local row = math.floor(count / 2)
	local side = count % 2 == 0 and -1 or 1
	return Vector(-spacing * (1 + row * 0.55), side * spacing * 0.72,
		(row % 2 == 0 and 0.12 or -0.12) * spacing)
end

local function commandShipFollow(target, leader, offsetOverride)
	if not validContact(leader, target) or not G.SetShipFormationFollower then return false end
	clearShipOrders(target)
	if target.ClearCombatTarget then target:ClearCombatTarget() end
	target:SetHostile(false)
	target:SetDieAt(0)
	target.mb_galaxyHoldForPlayerDeparture = true
	target.mb_galaxyPlayerDeparting = false
	target.mb_skyboxCommandedBy = leader
	G.SetShipFormationFollower(target, leader, isvector(offsetOverride) and offsetOverride or followerOffset(leader, target), {
		positionGain = 0.3,
		maximumCatchup = 0.8,
		deadband = 20,
	})
	target:SetShipState("following Republic squadron lead")
	return true
end

local function commandShipHold(target)
	if not IsValid(target) then return false end
	clearShipOrders(target)
	if target.ClearCombatTarget then target:ClearCombatTarget() end
	target:SetHostile(false)
	target:SetFlightVelocity(vector_origin)
	target.mb_galaxyHoldForPlayerDeparture = true
	target.mb_galaxyPlayerDeparting = false
	target.mb_skyboxCommandedBy = nil
	target:SetShipState("holding position by Republic order")
	return true
end

local function commandShipBreakOff(target)
	if not IsValid(target) then return false end
	clearShipOrders(target)
	if target.ClearCombatTarget then target:ClearCombatTarget() end
	target:SetHostile(false)
	target.mb_skyboxCommandedBy = nil
	target:SetShipState("breaking off engagement")
	target:SetFlightVelocity(vector_origin)
	timer.Simple(0, function()
		if IsValid(target) and G.AssignAutonomousShipMotion then
			G.AssignAutonomousShipMotion(target, "remote pilot break-off order")
		end
	end)
	return true
end

local function orderReply(ply, target, title, body, tone)
	sendPilotRadio(ply, target, title, shipDisplayName(target) .. ': "' .. body .. '"',
		tone or "info", 6)
end

local function handlePilotOrder(ply, control, orderIndex)
	if not IsValid(ply) or not control or not IsValid(control.ship) then return end
	if CurTime() < (control.nextOrderAt or 0) then return end
	control.nextOrderAt = CurTime() + math.max(0.4,
		tonumber(naval.SkyboxPilotOrderCooldown) or 1.1)
	local order = PILOT_ORDERS[math.Clamp(math.floor(tonumber(orderIndex) or 1), 1,
		#PILOT_ORDERS)] or PILOT_ORDERS[1]
	local range = math.max(600, tonumber(naval.SkyboxPilotCommsRange) or 8500)
	local target = validContact(control.ship, control.lockedTarget) and control.lockedTarget
		or contactTarget(control.ship, control.aim, range,
			math.max(control.profile.lockCone, 26))
	if not validContact(control.ship, target) then
		sendPilotRadio(ply, nil, "NO COMMUNICATION TARGET",
			"Lock or aim at a ship inside communications range before transmitting an order.",
			"warning", 4)
		return
	end
	if control.ship:GetPos():DistToSqr(target:GetPos()) > range * range then
		sendPilotRadio(ply, target, "CONTACT OUT OF RANGE",
			shipDisplayName(target) .. " is outside the remote fighter communications envelope.",
			"warning", 4)
		return
	end

	local faction = shipFaction(target)
	local hostile = target:GetHostile() or target:GetCombat()
	local hullFraction = target:GetHull() / math.max(1, target:GetMaxHull())

	if order.id == "hail" then
		if faction == "republic" then
			orderReply(ply, target, "REPUBLIC CHANNEL", "Republic identification confirmed. We read you, flight lead.", "republic")
		elseif faction == "civilian" or faction == "neutral" then
			orderReply(ply, target, "CIVILIAN CHANNEL", hostile and "We hear you, but your weapons are making us nervous!" or "We read you, Republic fighter. State your intentions.", "civilian")
		elseif faction == "pirate" then
			orderReply(ply, target, "PIRATE CHANNEL", "You have our attention. Make it quick.", "pirate")
		else
			orderReply(ply, target, "CIS CHANNEL", "Republic fighter identified. Your surrender is requested.", "hostile")
		end
		return
	end

	if order.id == "warn" then
		if faction == "republic" then
			orderReply(ply, target, "REPUBLIC CHANNEL", "Warning received. Confirm your target identification and keep weapons safe.", "warning")
		elseif faction == "civilian" or faction == "neutral" then
			orderReply(ply, target, "CIVILIAN CHANNEL", "Understood! We are altering course and clearing your flight path.", "distress")
			commandShipLeave(target, "clearing area after Republic warning")
		elseif faction == "pirate" then
			orderReply(ply, target, "PIRATE CHANNEL", hullFraction <= 0.5 and "Message received. We are considering our options." or "Save the speech, Republic. We are not afraid of you.", "pirate")
		else
			makeShipDefend(target, control.ship, "responding to Republic threat")
			orderReply(ply, target, "CIS CHANNEL", "Threat logged. Confederate weapons are authorised to respond.", "hostile")
		end
		return
	end

	if faction == "cis" then
		if order.id == "surrender" and hullFraction <= 0.18 then
			commandShipLeave(target, "withdrawing after combat disablement")
			orderReply(ply, target, "CIS WITHDRAWAL", "This unit is combat ineffective. Disengaging under protest.", "warning")
		else
			makeShipDefend(target, control.ship, "rejecting Republic command")
			orderReply(ply, target, "CIS COMMAND REJECTED", "Negative. Confederate units do not accept Republic orders. Engaging.", "hostile")
		end
		return
	end

	if faction == "pirate" then
		local mayWithdraw = hullFraction <= 0.48
			and (order.id == "leave" or order.id == "break_off" or order.id == "surrender")
		if mayWithdraw then
			if order.id == "leave" or order.id == "surrender" then
				commandShipLeave(target, order.id == "surrender" and "surrendering to Republic fighter" or "withdrawing under Republic pressure")
			else commandShipBreakOff(target) end
			orderReply(ply, target, "PIRATE COMPLIANCE", order.id == "surrender"
				and "Weapons cold. We surrender—do not fire." or "Fine. This score is not worth dying for.", "pirate")
		else
			makeShipDefend(target, control.ship, "attacking Republic flight lead")
			orderReply(ply, target, "PIRATE COMMAND REJECTED", "You do not give us orders, Republic. Weapons free!", "hostile")
		end
		return
	end

	if faction == "civilian" or faction == "neutral" then
		if hostile and order.id ~= "leave" and order.id ~= "break_off" then
			orderReply(ply, target, "CIVILIAN REFUSAL", "Not while you are firing on us! Break away!", "distress")
			return
		end
		if order.id == "follow" then commandShipFollow(target, control.ship)
		elseif order.id == "form_left" then commandShipFollow(target, control.ship,
			Vector(-180, -190, 20))
		elseif order.id == "form_right" then commandShipFollow(target, control.ship,
			Vector(-180, 190, 20))
		elseif order.id == "hold" then commandShipHold(target)
		elseif order.id == "leave" then commandShipLeave(target, "departing on Republic safety order")
		elseif order.id == "break_off" then commandShipBreakOff(target)
		elseif order.id == "surrender" then commandShipHold(target) end
		local replies = {
			follow = "Understood. We will form up behind you.",
			form_left = "Moving to your port side.",
			form_right = "Moving to your starboard side.",
			hold = "Holding position. Please keep the route clear.",
			leave = "Acknowledged. We are leaving the area now.",
			break_off = "Breaking off and disengaging.",
			surrender = "Weapons cold. We are holding position.",
		}
		orderReply(ply, target, "CIVILIAN ACKNOWLEDGEMENT", replies[order.id] or "Acknowledged.", "civilian")
		return
	end

	-- Republic traffic accepts lawful squadron traffic control, unless it has
	-- already escalated against a rogue pilot.
	local aggression = target.mb_skyboxPilotAggression
	local againstPilot = aggression and aggression[control.ship:EntIndex()]
	if againstPilot and againstPilot.phase == "defending"
	and order.id ~= "leave" and order.id ~= "break_off" then
		orderReply(ply, target, "REPUBLIC COMMAND REFUSED", "Disarm and break away first. You are marked as a friendly-fire threat.", "warning")
		return
	end
	if order.id == "follow" then commandShipFollow(target, control.ship)
	elseif order.id == "form_left" then commandShipFollow(target, control.ship,
		Vector(-190, -210, 25))
	elseif order.id == "form_right" then commandShipFollow(target, control.ship,
		Vector(-190, 210, 25))
	elseif order.id == "hold" then commandShipHold(target)
	elseif order.id == "leave" then commandShipLeave(target, "redeploying by squadron order")
	elseif order.id == "break_off" then commandShipBreakOff(target)
	elseif order.id == "surrender" then
		orderReply(ply, target, "REPUBLIC COMMAND REFUSED", "Republic vessels do not surrender to friendly traffic control.", "warning")
		return
	end
	local replies = {
		follow = "Copy, flight lead. Moving into formation.",
		form_left = "Copy. Forming on your port side.",
		form_right = "Copy. Forming on your starboard side.",
		hold = "Roger. Holding present position.",
		leave = "Order received. Clearing the local battlespace.",
		break_off = "Weapons safe. Breaking off engagement.",
	}
	orderReply(ply, target, "REPUBLIC ACKNOWLEDGEMENT", replies[order.id] or "Order acknowledged.", "republic")
end

local function wingmenFor(control)
	local result = {}
	local squadron = N.State and N.State.squadrons and N.State.squadrons[control.id]
	for _, ship in ipairs(squadron and squadron.visuals or {}) do
		if IsValid(ship) and ship ~= control.ship and not ship.mb_destroyed then
			result[#result + 1] = ship
		end
	end
	return result
end

local function nearestHostileTo(ship, ignore)
	local best, distance
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, target) and target ~= ignore and contactIsHostile(ship, target) then
			local candidate = ship:GetPos():DistToSqr(target:GetPos())
			if not distance or candidate < distance then best, distance = target, candidate end
		end
	end
	return best
end

local function handleWingOrder(ply, control, orderIndex)
	if not IsValid(ply) or not control or not IsValid(control.ship) then return end
	if CurTime() < (control.nextWingOrderAt or 0) then return end
	control.nextWingOrderAt = CurTime() + math.max(0.5,
		tonumber(naval.SkyboxPilotWingOrderCooldown) or 1.2)
	local order = WING_ORDERS[math.Clamp(math.floor(tonumber(orderIndex) or 1), 1,
		#WING_ORDERS)] or WING_ORDERS[1]
	local wingmen = wingmenFor(control)
	if #wingmen == 0 then
		sendPilotFeedback(ply, "denied", "No unoccupied wingmen are available for that order.")
		return
	end
	local leader = control.ship
	local locked = validContact(leader, control.lockedTarget) and control.lockedTarget or nil
	local spacingScale = order.id == "tight" and 0.72 or order.id == "wide" and 1.55 or 1

	if order.id == "attack_target" and (not IsValid(locked) or not contactIsHostile(leader, locked)) then
		sendPilotFeedback(ply, "denied", "Lock a hostile contact before ordering an attack.")
		return
	end

	for index, wingman in ipairs(wingmen) do
		if order.id == "attack_target" then
			clearShipOrders(wingman)
			wingman:SetCombatTarget(locked, math.max(16, control.profile.weaponDamage * 0.8),
				math.max(0.8, control.profile.fireInterval * 8))
			wingman:SetShipState("attacking flight lead target")
		elseif order.id == "cover" then
			local threat = nearestThreat(control) or nearestHostileTo(leader)
			if IsValid(threat) then
				clearShipOrders(wingman)
				wingman:SetCombatTarget(threat, math.max(16, control.profile.weaponDamage * 0.75),
					math.max(0.9, control.profile.fireInterval * 9))
				wingman:SetShipState("covering flight lead")
			else
				commandShipFollow(wingman, leader,
					Vector(-135 - index * 35, (index % 2 == 0 and 1 or -1) * 125, 15))
			end
		elseif order.id == "break_engage" then
			local hostile = nearestHostileTo(wingman)
			if IsValid(hostile) then
				clearShipOrders(wingman)
				wingman:SetCombatTarget(hostile, math.max(15, control.profile.weaponDamage * 0.72),
					math.max(0.9, control.profile.fireInterval * 9))
				wingman:SetShipState("breaking to engage")
			end
		elseif order.id == "return" then
			commandShipLeave(wingman, "returning to carrier under flight lead order")
		elseif order.id == "split_pairs" then
			local pairLeader = index > 1 and index % 2 == 0 and wingmen[index - 1] or leader
			commandShipFollow(wingman, pairLeader,
				Vector(-150, (index % 2 == 0 and 1 or -1) * 145, (index % 3 - 1) * 28))
			wingman:SetShipState("flying split-pair formation")
		else
			local spacing = (115 + index * 42) * spacingScale
			local side = index % 2 == 0 and 1 or -1
			commandShipFollow(wingman, leader,
				Vector(-spacing, side * spacing * 0.82, ((index - 1) % 3 - 1) * 24))
			wingman:SetShipState(order.id == "regroup" and "regrouping on flight lead"
				or order.id == "wide" and "holding wide formation" or "holding tight formation")
		end
	end
	sendPilotRadio(ply, leader, "SQUADRON COMMAND",
		string.upper(control.squadronName or control.id) .. " acknowledges: " .. order.label .. ".",
		"republic", 4.5)
end

local function applyTargetSubsystemDamage(control, target, rawDamage)
	if not control or not IsValid(target) then return end
	local key = TARGET_SUBSYSTEMS[math.Clamp(control.targetSubsystem or 1, 1, #TARGET_SUBSYSTEMS)]
	if key == "hull" then return end
	local fraction = control.profile.subsystemDamage
		* math.Clamp(math.max(1, rawDamage) / math.max(1, control.profile.weaponDamage), 0.4, 5)
	local remaining = applySystemDamage(target, key, fraction)
	if key == "engines" and remaining < 0.55 then
		target:SetFlightVelocity(target:GetFlightVelocity() * (0.55 + remaining * 0.45))
		if remaining <= 0.12 then target:SetShipState("engines disabled") end
	elseif key == "weapons" and remaining <= 0.12 and target.ClearCombatTarget then
		target:ClearCombatTarget()
		target:SetShipState("weapons disabled")
	elseif key == "shields" and remaining <= 0.12 then
		target.mb_galaxyShieldRegenMultiplier = 0.08
		target:SetShipState("shield generator disabled")
	end
end

local function firePilotWeapons(ship, control, target, leadPoint, canHit)
	local profile = control.profile
	local faction = shipFaction(ship)
	local color = faction == "republic" and Color(70, 145, 255)
		or faction == "pirate" and Color(235, 170, 55) or Color(235, 65, 55)
	local forward = travelForward(ship)
	local endPoint = ship:WorldSpaceCenter() + forward
		* math.min(profile.weaponRange, profile.weaponConvergence)
	if canHit and IsValid(target) and isvector(leadPoint) then
		endPoint = leadPoint + VectorRand() * math.max(1, target:GetCombatRadius() * 0.08)
	end
	local systems = ensureShipSystems(ship)
	local origins = muzzleOrigins(ship, profile)
	if systems.weapons < 0.28 and #origins > 1 then origins = { origins[1] } end
	for _, origin in ipairs(origins) do
		if G.EmitLaser then G.EmitLaser(origin, endPoint, color, 3) end
	end
	if not canHit or not IsValid(target) then return end
	local beforeShield = target:GetShield()
	local beforeHull = target:GetHull()
	local damageScale = 0.45 + systems.weapons * 0.55
	local damage = profile.weaponDamage * damageScale
	reactToPilotHit(ship.mb_skyboxPilot, ship, target, damage)
	applyTargetSubsystemDamage(control, target, damage)
	local info = DamageInfo()
	info:SetDamage(damage)
	info:SetAttacker(ship)
	info:SetInflictor(ship)
	info:SetDamagePosition(endPoint)
	info:SetDamageType(DMG_ENERGYBEAM)
	target:TakeDamageInfo(info)
	timer.Simple(0, function()
		local pilot = ship.mb_skyboxPilot
		if not IsValid(pilot) then return end
		if not IsValid(target) or target.mb_destroyed or target:GetHull() <= 0 then
			sendPilotFeedback(pilot, "kill", shipDisplayName(target))
		elseif beforeShield > target:GetShield() then
			sendPilotFeedback(pilot, "shield", "")
		elseif beforeHull > target:GetHull() then
			sendPilotFeedback(pilot, "hull", "")
		end
	end)
end

local function launchPilotMissile(ply, control)
	local ship = control.ship
	local target = control.lockedTarget
	local profile = control.profile
	if not validContact(ship, target) or not contactIsHostile(ship, target) then
		sendPilotFeedback(ply, "denied", "Lock a hostile target before launching ordnance.")
		return
	end
	if control.missiles <= 0 then
		sendPilotFeedback(ply, "denied", "No secondary ordnance remains.")
		return
	end
	if CurTime() < (control.nextMissileAt or 0) then
		sendPilotFeedback(ply, "denied", "Secondary weapon is still cycling.")
		return
	end
	local distance = ship:GetPos():Distance(target:GetPos())
	if distance > profile.missileRange then
		sendPilotFeedback(ply, "denied", "Target is outside missile range.")
		return
	end
	control.missiles = control.missiles - 1
	control.nextMissileAt = CurTime() + profile.missileCooldown
	ship:SetNW2Int("MBSkyboxPilotMissiles", control.missiles)
	ship:SetNW2Float("MBSkyboxPilotMissileCooldown", control.nextMissileAt)
	sendPilotFeedback(ply, "missile", shipDisplayName(target))
	local startPosition = ship:WorldSpaceCenter() + ship:GetForward() * ship:GetCombatRadius()
	local token = tostring(ship:EntIndex()) .. "_" .. tostring(CurTime())
	local steps = 9
	for step = 1, steps do
		timer.Simple(profile.missileFlightTime * step / steps, function()
			if not IsValid(ship) or not IsValid(target) then return end
			local fraction = step / steps
			local destination = target:WorldSpaceCenter()
			local point = LerpVector(fraction, startPosition, destination)
				+ VectorRand() * (1 - fraction) * 16
			local previous = LerpVector(math.max(0, fraction - 1 / steps), startPosition, destination)
			if G.EmitLaser then G.EmitLaser(previous, point, Color(255, 185, 70), 5) end
			if step < steps then return end
			local beforeShield = target:GetShield()
			local beforeHull = target:GetHull()
			reactToPilotHit(ply, ship, target, profile.missileDamage)
			applyTargetSubsystemDamage(control, target, profile.missileDamage)
			local info = DamageInfo()
			info:SetDamage(profile.missileDamage)
			info:SetAttacker(ship)
			info:SetInflictor(ship)
			info:SetDamagePosition(target:WorldSpaceCenter())
			info:SetDamageType(DMG_BLAST)
			target:TakeDamageInfo(info)
			timer.Simple(0, function()
				if not IsValid(ply) then return end
				if not IsValid(target) or target.mb_destroyed or target:GetHull() <= 0 then
					sendPilotFeedback(ply, "kill", shipDisplayName(target))
				elseif beforeShield > target:GetShield() then
					sendPilotFeedback(ply, "shield", "")
				elseif beforeHull > target:GetHull() then
					sendPilotFeedback(ply, "hull", "")
				end
			end)
		end)
	end
end

local function scanIncomingLock(ship)
	if not IsValid(ship) then return false end
	for _, attacker in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validContact(ship, attacker)
		and (attacker.mb_combatTarget == ship
			or attacker:GetNW2Entity("MBSkyboxPilotTarget") == ship) then
			return true
		end
	end
	return false
end

net.Receive(NET_INPUT, function(_, ply)
	local control = N.SkyboxPilotControls[ply]
	if not control then return end
	local aim = net.ReadAngle()
	local throttle = net.ReadFloat()
	local flags = net.ReadUInt(16)
	local roll = net.ReadInt(8) / 127
	local selectedOrder = net.ReadUInt(4)
	local selectedWingOrder = net.ReadUInt(4)
	local assistMode = net.ReadUInt(2)
	local targetSubsystem = net.ReadUInt(3)
	if not isangle(aim) then return end
	control.aim = Angle(
		math.Clamp(tonumber(aim.p) or 0, -86, 86),
		math.NormalizeAngle(tonumber(aim.y) or 0),
		0
	)
	control.throttle = math.Clamp(tonumber(throttle) or 0, 0, 1)
	control.fire = bit.band(flags, FLAG_FIRE) ~= 0
	control.boost = bit.band(flags, FLAG_BOOST) ~= 0
	control.brake = bit.band(flags, FLAG_BRAKE) ~= 0
	control.advanced = bit.band(flags, FLAG_ADVANCED) ~= 0
	control.returnAssist = bit.band(flags, FLAG_RETURN_ASSIST) ~= 0
	control.collisionAssist = bit.band(flags, FLAG_COLLISION_OFF) == 0
	control.roll = math.Clamp(tonumber(roll) or 0, -1, 1)
	control.selectedOrder = math.Clamp(math.floor(tonumber(selectedOrder) or 1), 1,
		#PILOT_ORDERS)
	control.selectedWingOrder = math.Clamp(math.floor(tonumber(selectedWingOrder) or 1), 1,
		#WING_ORDERS)
	control.assistMode = math.Clamp(math.floor(tonumber(assistMode) or 1), 1,
		#ASSIST_MODES)
	control.targetSubsystem = math.Clamp(math.floor(tonumber(targetSubsystem) or 1), 1,
		#TARGET_SUBSYSTEMS)
	control.lastInput = CurTime()

	if bit.band(flags, FLAG_THREAT) ~= 0 then
		setLockedTarget(control, nearestThreat(control))
	elseif bit.band(flags, FLAG_CYCLE_FRIENDLY) ~= 0 then
		setLockedTarget(control, cycleContactTarget(control, contactIsFriendly))
	elseif bit.band(flags, FLAG_CYCLE) ~= 0 then
		setLockedTarget(control, cycleContactTarget(control, contactIsHostile))
	elseif bit.band(flags, FLAG_LOCK) ~= 0 then
		if IsValid(control.lockedTarget) then
			setLockedTarget(control, nil)
		else
			setLockedTarget(control, contactTarget(control.ship, control.aim,
				math.max(control.profile.weaponRange,
					tonumber(naval.SkyboxPilotTargetCycleRange) or 7000),
				control.profile.lockCone))
		end
	end
	if bit.band(flags, FLAG_SECONDARY) ~= 0 then
		launchPilotMissile(ply, control)
	end
	if bit.band(flags, FLAG_ORDER) ~= 0 then
		handlePilotOrder(ply, control, control.selectedOrder)
	end
	if bit.band(flags, FLAG_WING_ORDER) ~= 0 then
		handleWingOrder(ply, control, control.selectedWingOrder)
	end
end)

net.Receive(NET_EXIT, function(_, ply)
	N.StopSkyboxPiloting(ply, "Skybox flight control released.")
end)

hook.Add("Think", "MilBase.Naval.SkyboxPilotThink", function()
	local now = CurTime()
	for ply, control in pairs(N.SkyboxPilotControls) do
		local ship = control.ship
		if not IsValid(ply) or not ply:Alive() or not IsValid(ship)
		or ship.mb_destroyed then
			N.StopSkyboxPiloting(ply, "Remote craft link lost.", not IsValid(ply))
		else
			local dt = math.Clamp(now - (control.lastThink or now), 0, 0.1)
			control.lastThink = now
			local profile = control.profile
			local timedOut = now - (control.lastInput or 0)
				> math.max(0.2, tonumber(naval.SkyboxPilotInputTimeout) or 1)
			local throttle = timedOut and 0 or control.throttle
			local braking = not timedOut and control.brake
			local systems = ensureShipSystems(ship)
			local hullFraction = ship:GetHullFraction()
			local critical = hullFraction <= math.Clamp(
				tonumber(naval.SkyboxPilotCriticalHullFraction) or 0.12, 0.03, 0.35)
			if critical then control.returnAssist = true end

			control.boostReserve = math.Clamp(tonumber(control.boostReserve) or 1, 0, 1)
			local wantsBoost = not timedOut and control.boost and not braking
			local boosting = wantsBoost and control.boostReserve > 0.04
				and systems.engines > 0.12
			if boosting then
				control.boostReserve = math.max(0,
					control.boostReserve - profile.boostDrain * dt)
			else
				control.boostReserve = math.min(1,
					control.boostReserve + profile.boostRecharge * dt)
			end

			local engineFactor = 0.32 + systems.engines * 0.68
			local controlFactor = 0.38 + systems.controls * 0.62
			local weaponFactor = 0.42 + systems.weapons * 0.58
			local maximumSpeed = profile.maximumSpeed * engineFactor
			local speed = shipVelocity(ship):Length()
			local speedFraction = speed / math.max(maximumSpeed, 1)
			local pilotProfile = flightProfile(profile, speedFraction, braking)
			pilotProfile.accelerate = pilotProfile.accelerate * engineFactor
			pilotProfile.jerk = pilotProfile.jerk * (0.55 + systems.engines * 0.45)
			pilotProfile.steering = pilotProfile.steering * controlFactor
			pilotProfile.bankRate = pilotProfile.bankRate * controlFactor
			if control.assistMode == 2 then
				pilotProfile.steering = pilotProfile.steering * 0.72
				pilotProfile.bank = pilotProfile.bank * 0.55
			elseif control.assistMode == 3 then
				pilotProfile.steering = pilotProfile.steering * 0.84
			end
			ship.mb_galaxyPilotProfile = pilotProfile
			ship.mb_galaxyPilotManualMode = control.advanced == true
			ship.mb_galaxyPilotRollTarget = control.roll * profile.manualBank * controlFactor

			local requestedSpeed = maximumSpeed * throttle
			if boosting then requestedSpeed = requestedSpeed * profile.boostMultiplier end
			if braking then
				requestedSpeed = math.min(requestedSpeed,
					maximumSpeed * math.Clamp(throttle * 0.22, 0, 0.22))
			end
			local desired = control.aim:Forward()
			local assistDocked = false
			if control.returnAssist then
				desired, requestedSpeed, assistDocked = returnAssistVector(control, requestedSpeed)
			elseif control.assistMode == 3 then
				local formationDirection, formationSpeed = assistedFormationVector(control, requestedSpeed)
				if isvector(formationDirection) then
					desired, requestedSpeed = formationDirection, formationSpeed
				end
			end
			if systems.controls < 0.35 then
				local drift = (1 - systems.controls) * 0.12
				desired = desired + ship:GetRight() * math.sin(now * 2.7) * drift
					+ ship:GetUp() * math.cos(now * 2.1) * drift * 0.65
				desired:Normalize()
			end
			if control.collisionAssist then
				desired, control.collisionPressure = collisionAvoidance(ship, desired, requestedSpeed)
			else
				control.collisionPressure = 0
			end
			desired, control.boundaryPressure, control.boundaryDistance
				= boundaryDirection(ship, desired)
			ship:SetFlightVelocity(desired * requestedSpeed)
			ship:SetShipState(control.returnAssist and (assistDocked
				and "holding carrier recovery position" or "returning under flight assist")
				or "player-controlled " .. string.lower(profile.label))

			if not validContact(ship, control.lockedTarget) then control.lockedTarget = nil end
			local softTarget = contactTarget(ship, control.aim,
				profile.weaponRange, profile.lockCone)
			local target = IsValid(control.lockedTarget) and control.lockedTarget or softTarget
			local leadPoint = IsValid(target)
				and interceptPoint(ship, target, profile.projectileSpeed) or vector_origin
			local weaponTarget, weaponLead = weaponContact(ship, profile)
			local canFire = IsValid(weaponTarget) and systems.weapons > 0.08

			if control.overheated and control.heat <= profile.weaponHeatResume then
				control.overheated = false
			end
			if now - (control.lastShot or 0) > profile.fireInterval * 1.15 then
				control.heat = math.max(0, (control.heat or 0)
					- profile.weaponHeatCoolRate * weaponFactor * dt)
			end
			if not timedOut and control.fire and not control.overheated
			and canFire and now >= (control.nextShot or 0) then
				control.nextShot = now + profile.fireInterval
					* (1 + (1 - systems.weapons) * 0.8)
				control.lastShot = now
				control.heat = math.Clamp((control.heat or 0)
					+ profile.weaponHeatPerShot * (1 + (1 - systems.weapons) * 0.9), 0, 1)
				if control.heat >= 1 then control.overheated = true end
				ship.mb_navalSquadron = control.id
				firePilotWeapons(ship, control, weaponTarget, weaponLead, canFire)
			end

			if now >= (control.nextThreatScan or 0) then
				control.nextThreatScan = now + 0.3
				control.incomingLock = scanIncomingLock(ship)
			end
			networkShipSystems(ship)
			ship:SetNW2Float("MBSkyboxPilotThrottle", throttle)
			ship:SetNW2Float("MBSkyboxPilotHeat", control.heat or 0)
			ship:SetNW2Float("MBSkyboxPilotBoundary", control.boundaryPressure or 0)
			ship:SetNW2Float("MBSkyboxPilotBoundaryDistance", control.boundaryDistance or 0)
			ship:SetNW2Float("MBSkyboxPilotCollision", control.collisionPressure or 0)
			ship:SetNW2Float("MBSkyboxPilotBoostReserve", control.boostReserve or 0)
			ship:SetNW2Bool("MBSkyboxPilotBoost", boosting)
			ship:SetNW2Bool("MBSkyboxPilotBrake", braking)
			ship:SetNW2Bool("MBSkyboxPilotAdvanced", control.advanced == true)
			ship:SetNW2Bool("MBSkyboxPilotReturnAssist", control.returnAssist == true)
			ship:SetNW2Bool("MBSkyboxPilotCritical", critical)
			ship:SetNW2Bool("MBSkyboxPilotLocked", IsValid(control.lockedTarget))
			ship:SetNW2Bool("MBSkyboxPilotCanFire", canFire)
			ship:SetNW2Bool("MBSkyboxPilotOverheated", control.overheated == true)
			ship:SetNW2Bool("MBSkyboxPilotIncomingLock", control.incomingLock == true)
			ship:SetNW2Int("MBSkyboxPilotAssistMode", control.assistMode or 1)
			ship:SetNW2Int("MBSkyboxPilotTargetSubsystem", control.targetSubsystem or 1)
			ship:SetNW2Int("MBSkyboxPilotMissiles", control.missiles or 0)
			ship:SetNW2Float("MBSkyboxPilotMissileCooldown", control.nextMissileAt or 0)
			ship:SetNW2Entity("MBSkyboxPilotTarget", IsValid(target) and target or NULL)
			ship:SetNW2Entity("MBSkyboxPilotSoftTarget", IsValid(softTarget) and softTarget or NULL)
			ship:SetNW2Vector("MBSkyboxPilotLeadPoint",
				IsValid(target) and leadPoint or vector_origin)
		end
	end
end)

hook.Add("EntityTakeDamage", "MilBase.Naval.SkyboxPilotDamageDirection", function(ent, dmg)
	if not IsValid(ent) or ent:GetClass() ~= "mb_galaxy_ship"
	or not IsValid(ent.mb_skyboxPilot) then return end
	local position = dmg:GetDamagePosition()
	if not isvector(position) or position == vector_origin then
		local attacker = dmg:GetAttacker()
		position = IsValid(attacker) and attacker:WorldSpaceCenter()
			or ent:WorldSpaceCenter() - ent:GetForward() * 100
	end
	ent:SetNW2Vector("MBSkyboxPilotLastHitPos", position)
	ent:SetNW2Float("MBSkyboxPilotLastHitAt", CurTime())
	local pilot = ent.mb_skyboxPilot
	local control = N.SkyboxPilotControls[pilot]
	if control then
		local attacker = dmg:GetAttacker()
		if validContact(ent, attacker) then control.lastAttacker = attacker end
		local scale = math.Clamp(math.max(0, dmg:GetDamage())
			/ math.max(1, ent:GetMaxHull()), 0.004, 0.16)
		local system = systemForHit(ent, position)
		local remaining = applySystemDamage(ent, system, scale * 2.8)
		if remaining <= 0.2 and CurTime() >= (control.nextSystemWarning or 0) then
			control.nextSystemWarning = CurTime() + 4
			sendPilotRadio(pilot, ent, "DAMAGE CONTROL",
				string.upper(system) .. " CRITICAL — handling degradation detected.",
				"warning", 4.5)
		end
	end
end)

hook.Add("PlayerDeath", "MilBase.Naval.SkyboxPilotDeath", function(ply)
	if N.SkyboxPilotControls[ply] then
		N.StopSkyboxPiloting(ply, "Remote pilot link terminated.", true)
	end
end)

hook.Add("PlayerDisconnected", "MilBase.Naval.SkyboxPilotDisconnect", function(ply)
	if N.SkyboxPilotControls[ply] then
		N.StopSkyboxPiloting(ply, "Remote pilot disconnected.", true)
	end
end)

hook.Add("EntityRemoved", "MilBase.Naval.SkyboxPilotShipRemoved", function(ent)
	local ply = ent.mb_skyboxPilot
	if not IsValid(ply) then return end
	timer.Simple(0, function()
		if IsValid(ply) and N.SkyboxPilotControls[ply]
		and N.SkyboxPilotControls[ply].ship == ent then
			N.StopSkyboxPiloting(ply, "Remote craft destroyed or lost.")
		end
	end)
end)
