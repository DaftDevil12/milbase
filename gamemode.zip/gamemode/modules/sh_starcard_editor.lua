-- Persistent Star Card creator/editor for the staff menu.

local cfg = MilBase.Config
local EDIT_LEVEL = tonumber(cfg.StarCardEditorLevel) or 4
local NET_REQUEST = "MilBase_StarCardEditorRequest"
local NET_SYNC = "MilBase_StarCardEditorSync"
local NET_ACTION = "MilBase_StarCardEditorAction"
local MAX_RAW = 256 * 1024

local function trim(value) return string.Trim(tostring(value or "")) end
local function list(source)
	local out, seen = {}, {}
	for _, value in ipairs(istable(source) and source or {}) do
		value = trim(value)
		if value ~= "" and not seen[value] then out[#out + 1], seen[value] = value, true end
	end
	return out
end

function MilBase.StarCardToEditable(card)
	if not istable(card) then return nil end
	return {
		id = trim(card.id), name = trim(card.name), desc = tostring(card.desc or ""),
		rarity = trim(card.rarity), faction = trim(card.faction), cert = trim(card.cert),
		health = math.floor(tonumber(card.health) or 0), armor = math.floor(tonumber(card.armor) or 0),
		loadout = list(card.loadout), issue = MilBase.CopyCountMap(card.issue, 1000),
		attachments = MilBase.CopyCountMap(card.attachments, 1000),
		grantsText = tostring(card.grantsText or ""),
	}
end

MilBase.StarCardFileDefaults = MilBase.StarCardFileDefaults or {}
if not MilBase._StarCardFileDefaultsCaptured then
	for _, id in ipairs(MilBase.StarCardOrder or {}) do
		local card = MilBase.GetStarCard(id)
		if card then local copy = table.Copy(card); copy.id = nil; MilBase.StarCardFileDefaults[id] = copy end
	end
	MilBase._StarCardFileDefaultsCaptured = true
end

local function cleanText(value, label, minLength, maxLength)
	value = trim(value)
	value = string.gsub(value, "[%z\1-\8\11\12\14-\31]", "")
	if #value < (minLength or 0) then return nil, label .. " is required." end
	if #value > maxLength then return nil, label .. " is too long." end
	return value
end
local function validateList(source, label, maxItems, maxLength)
	if not istable(source) then return nil, label .. " must be a list." end
	local out = list(source)
	if #out > maxItems then return nil, label .. " has too many entries." end
	for _, value in ipairs(out) do if #value > maxLength then return nil, label .. " entry is too long." end end
	return out
end
local function validateMap(source, label, maxLength)
	local out = MilBase.CopyCountMap(source, 1000)
	if table.Count(out) > 64 then return nil, label .. " has too many entries." end
	for id in pairs(out) do if #id > maxLength then return nil, label .. " id is too long." end end
	return out
end

local function validateCard(source, allowUnknown)
	if not istable(source) then return nil, "Malformed Star Card data." end
	local out, err = {}
	out.id, err = cleanText(source.id, "Card id", 1, 48)
	if not out.id then return nil, err end
	out.id = string.lower(out.id)
	if not string.match(out.id, "^[%w_%-]+$") then return nil, "Card id may contain only letters, numbers, underscores and hyphens." end
	out.name, err = cleanText(source.name, "Name", 1, 80); if not out.name then return nil, err end
	out.desc, err = cleanText(source.desc or "", "Description", 0, 1200); if not out.desc then return nil, err end
	out.grantsText, err = cleanText(source.grantsText or "", "Extra grants text", 0, 240); if not out.grantsText then return nil, err end
	out.rarity = string.lower(trim(source.rarity))
	if not MilBase.CardRarity[out.rarity] then return nil, "Rarity must be common, rare, epic or legendary." end
	out.faction = string.lower(trim(source.faction)); if out.faction == "" then out.faction = nil end
	out.cert = string.lower(trim(source.cert)); if out.cert == "" then out.cert = nil end
	if out.faction and not string.match(out.faction, "^[%w_%-]+$") then return nil, "Invalid faction id." end
	if out.cert and not string.match(out.cert, "^[%w_%-]+$") then return nil, "Invalid certification id." end
	if not allowUnknown and out.faction and not MilBase.GetFaction(out.faction) then return nil, "Unknown faction: " .. out.faction end
	if not allowUnknown and out.cert and not MilBase.Certs[out.cert] then return nil, "Unknown certification: " .. out.cert end
	out.health = math.Clamp(math.floor(tonumber(source.health) or 0), 0, 1000)
	out.armor = math.Clamp(math.floor(tonumber(source.armor) or 0), 0, 255)
	out.loadout, err = validateList(source.loadout or {}, "Loadout", 64, 128); if not out.loadout then return nil, err end
	out.issue, err = validateMap(source.issue or {}, "Issue", 96); if not out.issue then return nil, err end
	out.attachments, err = validateMap(source.attachments or {}, "Attachments", 128); if not out.attachments then return nil, err end
	return out
end

if SERVER then
	util.AddNetworkString(NET_REQUEST); util.AddNetworkString(NET_SYNC); util.AddNetworkString(NET_ACTION)
	local STAR_CARD_TABLE_SQL = [[CREATE TABLE IF NOT EXISTS frontier_starcard_definitions (
		id VARCHAR(64) PRIMARY KEY, data TEXT, source VARCHAR(16),
		updated_by VARCHAR(32), updated_at INTEGER
	)]]
	MilBase.StarCardEditorOverrides = MilBase.StarCardEditorOverrides or {}
	local function canEdit(ply) return IsValid(ply) and (ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL) end

	local function payload()
		local definitions, meta = {}, {}
		for _, id in ipairs(MilBase.StarCardOrder or {}) do
			local card = MilBase.GetStarCard(id)
			if card then
				definitions[#definitions + 1] = MilBase.StarCardToEditable(card)
				meta[id] = { file = MilBase.StarCardFileDefaults[id] ~= nil,
					overridden = MilBase.StarCardEditorOverrides[id] == true }
			end
		end
		return { definitions = definitions, meta = meta }
	end
	local function sendSync(target)
		local compressed = util.Compress(util.TableToJSON(payload()) or "{}")
		if not compressed then return end
		net.Start(NET_SYNC); net.WriteUInt(#compressed, 20); net.WriteData(compressed, #compressed)
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	MilBase.SyncStarCardDefinitions = sendSync

	local function preserveServerFields(id, clean)
		local default = MilBase.StarCardFileDefaults[id]
		if default and isfunction(default.apply) then clean.apply = default.apply end
		return clean
	end
	local function refreshUsers(id)
		for _, ply in ipairs(player.GetAll()) do
			for _, equipped in ipairs(ply.mb_equipped or {}) do
				if equipped == id then
					if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end
					MilBase.Notify(ply, "An equipped Star Card was updated; full loadout changes apply on your next spawn.", "warn")
					break
				end
			end
		end
	end
	local function saveCard(actor, source)
		local clean, err = validateCard(source)
		if not clean then return false, err end
		local existed = MilBase.GetStarCard(clean.id) ~= nil
		if not existed and #MilBase.StarCardOrder >= 512 then return false, "Star Card limit reached." end
		preserveServerFields(clean.id, clean)
		MilBase.RegisterStarCard(clean.id, clean)
		MilBase.StarCardEditorOverrides[clean.id] = true
		local stored = MilBase.StarCardToEditable(clean)
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_starcard_definitions (id, data, source, updated_by, updated_at) VALUES (%s, %s, %s, %s, %d)",
			MilBase.SQLStr(clean.id), MilBase.SQLStr(util.TableToJSON(stored)),
			MilBase.SQLStr(MilBase.StarCardFileDefaults[clean.id] and "override" or "custom"),
			MilBase.SQLStr(actor:SteamID64()), os.time()))
		refreshUsers(clean.id); sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. (existed and " updated Star Card " or " created Star Card ") .. clean.id, actor) end
		return true, existed and "Star Card updated." or "Star Card created."
	end
	local function resetCard(actor, id)
		local default = MilBase.StarCardFileDefaults[id]
		if not default then return false, "That card has no file default." end
		MilBase.RegisterStarCard(id, table.Copy(default)); MilBase.StarCardEditorOverrides[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_starcard_definitions WHERE id = " .. MilBase.SQLStr(id))
		refreshUsers(id); sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " reset Star Card " .. id, actor) end
		return true, "Star Card reset to its file definition."
	end
	local function deleteCard(actor, id, done)
		if MilBase.StarCardFileDefaults[id] then done(false, "File cards must be reset, not deleted.") return end
		if not MilBase.GetStarCard(id) then done(false, "Unknown Star Card.") return end
		MilBase.DB.Query("SELECT steamid FROM frontier_unlocks WHERE card = " .. MilBase.SQLStr(id) .. " LIMIT 1", function(rows)
			if rows and rows[1] then done(false, "Cannot delete: at least one character has unlocked this card.") return end
			MilBase.DB.Query("SELECT steamid FROM frontier_progress WHERE equipped LIKE " .. MilBase.SQLStr("%" .. id .. "%") .. " LIMIT 1", function(equippedRows)
				if equippedRows and equippedRows[1] then done(false, "Cannot delete: at least one character has this card equipped.") return end
				MilBase.RemoveStarCard(id); MilBase.StarCardEditorOverrides[id] = nil
				MilBase.DB.Run("DELETE FROM frontier_starcard_definitions WHERE id = " .. MilBase.SQLStr(id)); sendSync()
				if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " deleted Star Card " .. id, actor) end
				done(true, "Custom Star Card deleted.")
			end)
		end)
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if (ply.mb_nextStarCardDefinitionRequest or 0) > CurTime() then return end
		ply.mb_nextStarCardDefinitionRequest = CurTime() + 1
		sendSync(ply)
	end)
	net.Receive(NET_ACTION, function(_, ply)
		if not canEdit(ply) or (ply.mb_nextStarCardEditorAction or 0) > CurTime() then return end
		ply.mb_nextStarCardEditorAction = CurTime() + 0.2
		local action = net.ReadString()
		if action == "save" then
			local length = net.ReadUInt(20); if length <= 0 or length > MAX_RAW then return end
			local raw = util.Decompress(net.ReadData(length) or ""); if not raw or #raw > MAX_RAW then return end
			local ok, message = saveCard(ply, util.JSONToTable(raw)); MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "reset" then
			local ok, message = resetCard(ply, string.lower(trim(net.ReadString()))); MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "delete" then
			deleteCard(ply, string.lower(trim(net.ReadString())), function(ok, message) if IsValid(ply) then MilBase.Notify(ply, message, ok and "ok" or "warn") end end)
		end
	end)

	local function loadOverrides()
		MilBase.DB.Query("SELECT id, data FROM frontier_starcard_definitions", function(rows)
			rows = rows or {}; table.sort(rows, function(a,b) return tostring(a.id or "") < tostring(b.id or "") end)
			for _, row in ipairs(rows) do
				local clean = validateCard(util.JSONToTable(row.data or ""), true)
				if clean and clean.id == tostring(row.id or "") then
					preserveServerFields(clean.id, clean); MilBase.RegisterStarCard(clean.id, clean); MilBase.StarCardEditorOverrides[clean.id] = true
				end
			end
			sendSync()
		end)
	end
	MilBase.DB.Query(STAR_CARD_TABLE_SQL, loadOverrides, function(err)
		MsgC(Color(255, 100, 90), "[MilBase Star Cards] Could not create editor table: ",
			color_white, tostring(err), "\n")
	end)
	hook.Add("PlayerInitialSpawn", "MilBase.StarCardEditorSync", function(ply) timer.Simple(2, function() if IsValid(ply) then sendSync(ply) end end) end)
	return
end

-- Client -----------------------------------------------------------------

MilBase.StarCardEditorMeta = MilBase.StarCardEditorMeta or {}
net.Receive(NET_SYNC, function()
	local length = net.ReadUInt(20); local raw = util.Decompress(net.ReadData(length) or "")
	local data = raw and util.JSONToTable(raw) or {}
	MilBase.StarCards, MilBase.StarCardOrder = {}, {}
	for _, card in ipairs(data.definitions or {}) do MilBase.RegisterStarCard(card.id, card) end
	MilBase.StarCardEditorMeta = istable(data.meta) and data.meta or {}
	hook.Run("MilBase.StarCardEditorUpdated")
end)
local function sendAction(action, value)
	net.Start(NET_ACTION); net.WriteString(action)
	if action == "save" then
		local compressed = util.Compress(util.TableToJSON(value) or "{}") or ""
		net.WriteUInt(#compressed, 20); net.WriteData(compressed, #compressed)
	else net.WriteString(tostring(value or "")) end
	net.SendToServer()
end
local function splitList(raw)
	local out = {}
	for value in string.gmatch(tostring(raw or ""), "[^,\n]+") do value = trim(value); if value ~= "" then out[#out + 1] = value end end
	return out
end
local function parseMap(raw)
	local out = {}
	for value in string.gmatch(tostring(raw or ""), "[^,\n]+") do
		local id, amount = string.match(value, "^%s*([^=:%s]+)%s*[=:]%s*(%d+)%s*$")
		if id then out[id] = tonumber(amount) or 1 end
	end
	return out
end
local function mapText(map)
	local rows = {}; for id, amount in SortedPairs(map or {}) do rows[#rows + 1] = id .. "=" .. amount end
	return table.concat(rows, ", ")
end

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["STAR CARD EDITOR"] = true
MilBase.AddMenuTab("STAR CARD EDITOR", 94.5, function(content)
	local selectedID, fields = nil, {}
	local left = vgui.Create("DPanel", content); left:Dock(LEFT); left:SetWide(270); left:DockMargin(0,0,12,0); left.Paint = function(_,w,h) MilBase.PaintPanel(w,h) end
	local newButton = vgui.Create("DButton", left); newButton:Dock(TOP); newButton:SetTall(38); newButton:SetText("NEW STAR CARD")
	local listPanel = vgui.Create("DScrollPanel", left); listPanel:Dock(FILL); listPanel:DockMargin(8,8,8,8)
	local form = vgui.Create("DScrollPanel", content); form:Dock(FILL)
	local function label(text) local l=vgui.Create("DLabel",form); l:Dock(TOP); l:SetTall(20); l:SetFont("MB.Tiny"); l:SetText(text); l:SetTextColor(MilBase.UI.dim); l:DockMargin(0,5,0,2) end
	local function entry(key,title,multi) label(title); local e=vgui.Create("DTextEntry",form); e:Dock(TOP); e:SetTall(multi and 72 or 30); e:SetMultiline(multi==true); fields[key]=e end
	entry("id","ID (immutable after creation)"); entry("name","DISPLAY NAME"); entry("desc","DESCRIPTION",true)
	entry("rarity","RARITY: common / rare / epic / legendary"); entry("faction","OPTIONAL FACTION ID"); entry("cert","OPTIONAL CERTIFICATION ID")
	entry("health","BONUS MAX HEALTH"); entry("armor","SPAWN ARMOR BONUS"); entry("loadout","WEAPON CLASSES (comma separated)",true)
	entry("issue","ISSUED ITEMS (item=amount)",true); entry("attachments","ARCCW ATTACHMENTS (attachment=amount)",true); entry("grantsText","OPTIONAL EXTRA TOOLTIP TEXT")
	local actions=vgui.Create("DPanel",form); actions:Dock(TOP); actions:SetTall(46); actions.Paint=nil; actions:DockMargin(0,10,0,0)
	local save=vgui.Create("DButton",actions); save:SetText("SAVE"); save:SetSize(120,36); save:SetPos(0,5)
	local reset=vgui.Create("DButton",actions); reset:SetText("RESET TO FILE"); reset:SetSize(140,36); reset:SetPos(128,5)
	local delete=vgui.Create("DButton",actions); delete:SetText("DELETE CUSTOM"); delete:SetSize(140,36); delete:SetPos(276,5)
	local function load(card)
		card=card or {id="",name="",desc="",rarity="common",faction="",cert="",health=0,armor=0,loadout={},issue={},attachments={},grantsText=""}
		fields.id:SetText(card.id or ""); fields.id:SetEditable(selectedID==nil); fields.name:SetText(card.name or ""); fields.desc:SetText(card.desc or "")
		fields.rarity:SetText(card.rarity or "common"); fields.faction:SetText(card.faction or ""); fields.cert:SetText(card.cert or "")
		fields.health:SetText(tostring(card.health or 0)); fields.armor:SetText(tostring(card.armor or 0)); fields.loadout:SetText(table.concat(card.loadout or {},", "))
		fields.issue:SetText(mapText(card.issue)); fields.attachments:SetText(mapText(card.attachments)); fields.grantsText:SetText(card.grantsText or "")
		local meta=selectedID and MilBase.StarCardEditorMeta[selectedID] or {}; reset:SetEnabled(meta.file==true and meta.overridden==true); delete:SetEnabled(selectedID~=nil and meta.file~=true)
	end
	local function selectCard(id) selectedID=id; load(MilBase.StarCardToEditable(MilBase.GetStarCard(id))) end
	local function rebuild()
		listPanel:Clear()
		for _,id in ipairs(MilBase.StarCardOrder or {}) do local card=MilBase.GetStarCard(id); local b=listPanel:Add("DButton"); b:Dock(TOP); b:SetTall(38); b:DockMargin(0,0,0,4); b:SetText((card and card.name or id).."  ["..id.."]"); b.DoClick=function() selectCard(id) end end
		if selectedID and MilBase.GetStarCard(selectedID) then selectCard(selectedID) else load(nil) end
	end
	newButton.DoClick=function() selectedID=nil; load(nil) end
	save.DoClick=function() sendAction("save",{id=selectedID or fields.id:GetValue(),name=fields.name:GetValue(),desc=fields.desc:GetValue(),rarity=fields.rarity:GetValue(),faction=fields.faction:GetValue(),cert=fields.cert:GetValue(),health=tonumber(fields.health:GetValue()),armor=tonumber(fields.armor:GetValue()),loadout=splitList(fields.loadout:GetValue()),issue=parseMap(fields.issue:GetValue()),attachments=parseMap(fields.attachments:GetValue()),grantsText=fields.grantsText:GetValue()}) end
	reset.DoClick=function() if selectedID then Derma_Query("Restore this card's Lua definition?","Reset Star Card","RESET",function() sendAction("reset",selectedID) end,"CANCEL") end end
	delete.DoClick=function() if selectedID then Derma_Query("Permanently delete this custom Star Card?","Delete Star Card","DELETE",function() sendAction("delete",selectedID); selectedID=nil end,"CANCEL") end end
	local hookID="MilBase.StarCardEditorPanel."..tostring(content); hook.Add("MilBase.StarCardEditorUpdated",hookID,rebuild); content.OnRemove=function() hook.Remove("MilBase.StarCardEditorUpdated",hookID) end
	net.Start(NET_REQUEST); net.SendToServer(); rebuild()
end, function(ply) return ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL end)

hook.Add("InitPostEntity", "MilBase.RequestStarCardDefinitions", function()
	timer.Simple(1, function() net.Start(NET_REQUEST); net.SendToServer() end)
end)
hook.Add("OnReloaded", "MilBase.RequestStarCardDefinitionsReload", function()
	timer.Simple(0.5, function() net.Start(NET_REQUEST); net.SendToServer() end)
end)
