--[[
	Persistent regiment rosters for the unified datapad.

	Every character slot has its own membership history. The current faction is
	active; former factions are retained as archived memberships. Existing
	certification and jail tables remain the source of truth for qualifications
	and arrests, while this module owns roster activity, promotion dates and
	disciplinary strikes.
]]

if MilBase.RegimentRosterLoaded then return end
MilBase.RegimentRosterLoaded = true

local cfg = MilBase.Config
local Roster = MilBase.RegimentRoster or {}
MilBase.RegimentRoster = Roster

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function clean(value, maximum)
	return string.sub(trim(value), 1, maximum or 128)
end

local function timeNow()
	return os.time()
end

local function rankCanPromote(ply)
	if not IsValid(ply) or not ply.MBRank then return false end
	local rank = ply:MBRank()
	return rank and rank.canPromote == true
end

local function officerAccess(ply)
	if rankCanPromote(ply) then return true end
	if not (IsValid(ply) and MilBase.DatapadRankGroup) then return false end
	local _, weight = MilBase.DatapadRankGroup(ply)
	return tonumber(weight or 0) >= 3
end

function MilBase.DatapadRosterIsNavy(ply)
	if not IsValid(ply) then return false end
	local allowed = cfg.DatapadRosterNavyFactions or { ["Navy"] = true }
	local faction = ply.MBFaction and ply:MBFaction()
	local factionID = ply.MBFactionID and ply:MBFactionID() or ""
	return allowed[factionID] == true or (faction and allowed[faction.name] == true)
end

function Roster.CanView(ply)
	return IsValid(ply) and (ply:IsSuperAdmin() or officerAccess(ply)
		or MilBase.DatapadRosterIsNavy(ply))
end

function Roster.CanEditFaction(ply, factionID)
	if not IsValid(ply) then return false end
	if ply:IsSuperAdmin() then return true end
	if MilBase.DatapadRosterIsNavy(ply) then
		return cfg.DatapadRosterNavyEditRequiresOfficer == false or rankCanPromote(ply)
	end
	return rankCanPromote(ply) and ply:MBFactionID() == factionID
end

local function characterAccountID(characterID)
	return string.match(tostring(characterID or ""), "^([^:]+)") or tostring(characterID or "")
end

local function factionForRequest(ply, requested)
	requested = clean(requested, 64)
	if (MilBase.DatapadRosterIsNavy(ply) or ply:IsSuperAdmin()) and MilBase.GetFaction(requested) then
		return requested
	end
	return ply:MBFactionID()
end

local function onlineCharacter(characterID)
	for _, target in ipairs(player.GetAll()) do
		if target.MBCharacterKey and target:MBCharacterKey() == characterID then return target end
	end
end

local function actorName(actor)
	if not IsValid(actor) then return "SYSTEM" end
	return actor.MBName and actor:MBName() or actor:Nick()
end

if SERVER then
	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_regiment_roster (
		character_id VARCHAR(48),
		account_steamid VARCHAR(32),
		faction_id VARCHAR(64),
		rp_name TEXT,
		steam_name TEXT,
		rank_index INTEGER,
		rank_name TEXT,
		last_active INTEGER,
		last_promoted INTEGER,
		last_arrested INTEGER,
		joined_at INTEGER,
		archived_at INTEGER,
		status VARCHAR(16),
		updated_at INTEGER,
		updated_by TEXT,
		PRIMARY KEY (faction_id, character_id)
	)]])

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_regiment_strikes ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "character_id VARCHAR(48), faction_id VARCHAR(64), reason TEXT, "
		.. "issued_by_id VARCHAR(32), issued_by_name TEXT, created_at INTEGER, "
		.. "active INTEGER, voided_at INTEGER, voided_by_name TEXT)")

	local function membershipValues(ply, factionID)
		local faction = MilBase.GetFaction(factionID)
		local rankIndex = ply:MBRankIndex()
		local rank = faction and faction.ranks[math.Clamp(rankIndex, 1, #faction.ranks)]
		return {
			characterID = ply:MBCharacterKey(),
			accountID = ply:SteamID64(),
			factionID = factionID,
			rpName = ply.MBRawName and ply:MBRawName() or ply:MBName(),
			steamName = ply:Nick(),
			rankIndex = rankIndex,
			rankName = rank and rank.name or "Unknown",
		}
	end

	local function insertMembership(values, joinedAt, lastActive, lastPromoted, lastArrested)
		MilBase.DB.Run(string.format(
			"INSERT INTO frontier_regiment_roster "
				.. "(character_id, account_steamid, faction_id, rp_name, steam_name, rank_index, rank_name, "
				.. "last_active, last_promoted, last_arrested, joined_at, archived_at, status, updated_at, updated_by) "
				.. "VALUES (%s, %s, %s, %s, %s, %d, %s, %d, %d, %d, %d, 0, 'active', %d, %s)",
			MilBase.SQLStr(values.characterID),
			MilBase.SQLStr(values.accountID),
			MilBase.SQLStr(values.factionID),
			MilBase.SQLStr(values.rpName),
			MilBase.SQLStr(values.steamName),
			values.rankIndex,
			MilBase.SQLStr(values.rankName),
			tonumber(lastActive or 0) or 0,
			tonumber(lastPromoted or 0) or 0,
			tonumber(lastArrested or 0) or 0,
			tonumber(joinedAt or timeNow()) or timeNow(),
			timeNow(),
			MilBase.SQLStr(values.updatedBy or "SYSTEM")
		))
	end

	function Roster.SyncPlayer(ply, actor, promoted)
		if not IsValid(ply) or not ply.mb_dataLoaded then return end
		local values = membershipValues(ply, ply:MBFactionID())
		values.updatedBy = actorName(actor)
		local stamp = timeNow()
		local characterSQL = MilBase.SQLStr(values.characterID)
		local factionSQL = MilBase.SQLStr(values.factionID)

		MilBase.DB.Run("UPDATE frontier_regiment_roster SET status = 'archived', archived_at = " .. stamp
			.. ", last_active = " .. stamp
			.. ", updated_at = " .. stamp .. ", updated_by = " .. MilBase.SQLStr(values.updatedBy)
			.. " WHERE character_id = " .. characterSQL .. " AND faction_id <> " .. factionSQL
			.. " AND status = 'active'")

		MilBase.DB.Query("SELECT * FROM frontier_regiment_roster WHERE character_id = "
			.. characterSQL .. " AND faction_id = " .. factionSQL .. " LIMIT 1", function(rows)
			if not IsValid(ply) or ply:MBCharacterKey() ~= values.characterID
			or ply:MBFactionID() ~= values.factionID then return end
			local row = rows[1]
			if not row then
				insertMembership(values, stamp, stamp, promoted and stamp or 0, 0)
				return
			end
			local promotedSQL = promoted and (", last_promoted = " .. stamp) or ""
			MilBase.DB.Run("UPDATE frontier_regiment_roster SET "
				.. "account_steamid = " .. MilBase.SQLStr(values.accountID)
				.. ", rp_name = " .. MilBase.SQLStr(values.rpName)
				.. ", steam_name = " .. MilBase.SQLStr(values.steamName)
				.. ", rank_index = " .. values.rankIndex
				.. ", rank_name = " .. MilBase.SQLStr(values.rankName)
				.. ", last_active = " .. stamp
				.. promotedSQL
				.. ", archived_at = 0, status = 'active', updated_at = " .. stamp
				.. ", updated_by = " .. MilBase.SQLStr(values.updatedBy)
				.. " WHERE character_id = " .. characterSQL .. " AND faction_id = " .. factionSQL)
		end)
	end

	local function updateLastActive(ply)
		if not IsValid(ply) or not ply.mb_dataLoaded then return end
		MilBase.DB.Run("UPDATE frontier_regiment_roster SET last_active = " .. timeNow()
			.. ", rp_name = " .. MilBase.SQLStr(ply.MBRawName and ply:MBRawName() or ply:MBName())
			.. ", steam_name = " .. MilBase.SQLStr(ply:Nick())
			.. ", updated_at = " .. timeNow()
			.. " WHERE character_id = " .. MilBase.SQLStr(ply:MBCharacterKey())
			.. " AND faction_id = " .. MilBase.SQLStr(ply:MBFactionID()))
	end

	function MilBase.RosterRecordArrest(target, arrestedAt, officer)
		if not IsValid(target) then return end
		local stamp = tonumber(arrestedAt or timeNow()) or timeNow()
		MilBase.DB.Run("UPDATE frontier_regiment_roster SET last_arrested = " .. stamp
			.. ", updated_at = " .. timeNow()
			.. ", updated_by = " .. MilBase.SQLStr(actorName(officer))
			.. " WHERE character_id = " .. MilBase.SQLStr(target:MBCharacterKey())
			.. " AND faction_id = " .. MilBase.SQLStr(target:MBFactionID()))
	end

	hook.Add("MilBase.PlayerLoaded", "MilBase.RegimentRoster.SyncLoaded", function(ply)
		Roster.SyncPlayer(ply)
	end)

	hook.Add("MilBase.FactionChanged", "MilBase.RegimentRoster.TrackFaction", function(ply, _, _, actor)
		Roster.SyncPlayer(ply, actor, false)
	end)

	hook.Add("MilBase.RankChanged", "MilBase.RegimentRoster.TrackRank", function(ply, oldRank, newRank, actor)
		Roster.SyncPlayer(ply, actor, tonumber(newRank or 0) > tonumber(oldRank or 0))
	end)

	hook.Add("PlayerDisconnected", "MilBase.RegimentRoster.LastActive", updateLastActive)

	timer.Create("MilBase.RegimentRoster.Activity", 120, 0, function()
		for _, ply in ipairs(player.GetAll()) do updateLastActive(ply) end
	end)

	local function factionPayload()
		local out = {}
		for _, id in ipairs(MilBase.FactionOrder or {}) do
			local faction = MilBase.GetFaction(id)
			if faction then out[#out + 1] = { id = id, name = faction.name } end
		end
		return out
	end

	local function rankPayload(faction)
		local out = {}
		for index, rank in ipairs(faction.ranks or {}) do
			out[#out + 1] = { index = index, name = rank.name or ("Rank " .. index) }
		end
		return out
	end

	local function certPayload(factionID)
		local out = {}
		for _, id in ipairs(MilBase.CertOrder or {}) do
			local cert = MilBase.Certs[id]
			if cert and MilBase.CertAllowedForFaction(cert, factionID) then
				out[#out + 1] = { id = id, name = cert.name or id }
			end
		end
		return out
	end

	local function canEditRecord(ply, factionID, record)
		if not Roster.CanEditFaction(ply, factionID) or record.status ~= "active" then return false end
		if ply:IsSuperAdmin() then return true end
		if record.character_id == ply:MBCharacterKey() then return false end
		if factionID == ply:MBFactionID() then
			return ply:MBRankIndex() > tonumber(record.rank_index or 1)
		end
		return MilBase.DatapadRosterIsNavy(ply)
	end

	local function bootstrapMembership(record)
		local values = {
			characterID = record.character_id,
			accountID = record.account_steamid,
			factionID = record.faction_id,
			rpName = record.rp_name,
			steamName = record.steam_name,
			rankIndex = record.rank_index,
			rankName = record.rank_name,
			updatedBy = "ROSTER IMPORT",
		}
		insertMembership(values, 0, record.last_active or 0, 0, record.last_arrested or 0)
	end

	local function applySearchAndLimit(records, query, filter)
		query = string.lower(clean(query, 64))
		filter = string.lower(clean(filter, 16))
		if filter ~= "active" and filter ~= "archive" then filter = "all" end
		local out = {}
		for _, record in ipairs(records) do
			local statusMatch = filter == "all"
				or (filter == "active" and record.status == "active")
				or (filter == "archive" and record.status == "archived")
			local haystack = string.lower(table.concat({
				record.rp_name or "", record.steam_name or "", record.rank_name or "",
				record.account_steamid or "", record.character_id or "",
			}, " "))
			if statusMatch and (query == "" or string.find(haystack, query, 1, true)) then
				out[#out + 1] = record
			end
		end
		table.sort(out, function(a, b)
			if a.status ~= b.status then return a.status == "active" end
			if a.online ~= b.online then return a.online == true end
			if tonumber(a.rank_index or 0) ~= tonumber(b.rank_index or 0) then
				return tonumber(a.rank_index or 0) > tonumber(b.rank_index or 0)
			end
			return string.lower(a.rp_name or "") < string.lower(b.rp_name or "")
		end)
		local maximum = cfg.DatapadRosterMaxResults or 80
		while #out > maximum do table.remove(out) end
		return out, filter
	end

	local function enrichAndSend(ply, factionID, records, state, sendData)
		if not IsValid(ply) then return end
		local faction = MilBase.GetFaction(factionID)
		if not faction then return end
		local characterIDs, accountIDs, byCharacter = {}, {}, {}
		for _, record in ipairs(records) do
			characterIDs[#characterIDs + 1] = MilBase.SQLStr(record.character_id)
			accountIDs[record.account_steamid] = true
			byCharacter[record.character_id] = record
			record.certs = {}
			record.strikes = {}
			record.active_strikes = 0
			record.can_edit = canEditRecord(ply, factionID, record)
		end
		local selected = byCharacter[state.selectedID or ""] or records[1]
		state.selectedID = selected and selected.character_id or ""

		local payload = {
			faction_id = factionID,
			faction_name = faction.name,
			factions = factionPayload(),
			can_choose_faction = MilBase.DatapadRosterIsNavy(ply) or ply:IsSuperAdmin(),
			can_edit_faction = Roster.CanEditFaction(ply, factionID),
			ranks = rankPayload(faction),
			certifications = certPayload(factionID),
			records = records,
			query = state.query,
			filter = state.filter,
			selected_id = state.selectedID,
		}

		if #records == 0 then
			sendData(ply, "regiment_roster", "state", payload)
			return
		end

		local inCharacters = table.concat(characterIDs, ",")
		local function finish()
			if IsValid(ply) then sendData(ply, "regiment_roster", "state", payload) end
		end

		local function loadCertifications()
			if not selected then finish() return end
			MilBase.DB.Query("SELECT cert FROM frontier_certs WHERE steamid = "
				.. MilBase.SQLStr(selected.character_id), function(certRows)
				for _, row in ipairs(certRows or {}) do
					local cert = MilBase.Certs[row.cert]
					if cert then
						selected.certs[#selected.certs + 1] = {
							id = row.cert,
							name = cert.name or row.cert,
						}
					end
				end
				finish()
			end, finish)
		end

		local function loadSelectedStrikeHistory()
			if not selected then loadCertifications() return end
			MilBase.DB.Query("SELECT * FROM frontier_regiment_strikes WHERE faction_id = "
				.. MilBase.SQLStr(factionID) .. " AND character_id = "
				.. MilBase.SQLStr(selected.character_id)
				.. " ORDER BY created_at DESC LIMIT 30", function(strikeRows)
				for _, row in ipairs(strikeRows or {}) do
					selected.strikes[#selected.strikes + 1] = {
						id = tonumber(row.id or 0) or 0,
						reason = row.reason or "",
						issued_by_name = row.issued_by_name or "Unknown",
						created_at = tonumber(row.created_at or 0) or 0,
						active = tonumber(row.active or 0) == 1,
						voided_at = tonumber(row.voided_at or 0) or 0,
						voided_by_name = row.voided_by_name or "",
					}
				end
				loadCertifications()
			end, loadCertifications)
		end

		local function loadStrikeCounts()
			MilBase.DB.Query("SELECT character_id, COUNT(*) AS n FROM frontier_regiment_strikes "
				.. "WHERE faction_id = " .. MilBase.SQLStr(factionID)
				.. " AND active = 1 AND character_id IN (" .. inCharacters .. ") "
				.. "GROUP BY character_id", function(strikeRows)
				for _, row in ipairs(strikeRows or {}) do
					local record = byCharacter[tostring(row.character_id or "")]
					if record then record.active_strikes = tonumber(row.n or 0) or 0 end
				end
				loadSelectedStrikeHistory()
			end, loadSelectedStrikeHistory)
		end

		local accountSQL = {}
		for accountID in pairs(accountIDs) do accountSQL[#accountSQL + 1] = MilBase.SQLStr(accountID) end
		if #accountSQL == 0 then loadStrikeCounts() return end
		MilBase.DB.Query("SELECT steamid, MAX(created_at) AS last_arrested FROM frontier_jail_records "
			.. "WHERE steamid IN (" .. table.concat(accountSQL, ",") .. ") GROUP BY steamid", function(arrestRows)
			local arrests = {}
			for _, row in ipairs(arrestRows or {}) do
				arrests[tostring(row.steamid or "")] = tonumber(row.last_arrested or 0) or 0
			end
			for _, record in ipairs(records) do
				record.last_arrested = math.max(tonumber(record.last_arrested or 0) or 0,
					arrests[record.account_steamid] or 0)
			end
			loadStrikeCounts()
		end, loadStrikeCounts)
	end

	local function sendRoster(ply, data, sendData)
		if not Roster.CanView(ply) then return end
		local factionID = factionForRequest(ply, data.faction_id)
		local faction = MilBase.GetFaction(factionID)
		if not faction then return end
		local state = {
			query = clean(data.query, 64),
			filter = clean(data.filter, 16),
			selectedID = clean(data.selected_id, 48),
		}

		MilBase.DB.Query("SELECT * FROM frontier_regiment_roster WHERE faction_id = "
			.. MilBase.SQLStr(factionID), function(membershipRows)
			MilBase.DB.Query("SELECT steamid, name, faction, `rank` FROM frontier_players WHERE faction = "
				.. MilBase.SQLStr(factionID), function(playerRows)
				local recordsByCharacter = {}
				for _, row in ipairs(membershipRows or {}) do
					local characterID = tostring(row.character_id or "")
					if characterID ~= "" then
						recordsByCharacter[characterID] = {
							character_id = characterID,
							account_steamid = tostring(row.account_steamid or characterAccountID(characterID)),
							faction_id = factionID,
							rp_name = row.rp_name or "Unknown",
							steam_name = row.steam_name or "",
							rank_index = tonumber(row.rank_index or 1) or 1,
							rank_name = row.rank_name or "Unknown",
							last_active = tonumber(row.last_active or 0) or 0,
							last_promoted = tonumber(row.last_promoted or 0) or 0,
							last_arrested = tonumber(row.last_arrested or 0) or 0,
							joined_at = tonumber(row.joined_at or 0) or 0,
							archived_at = tonumber(row.archived_at or 0) or 0,
							status = row.status == "active" and "active" or "archived",
							updated_by = row.updated_by or "",
							online = false,
						}
					end
				end

				for _, row in ipairs(playerRows or {}) do
					local characterID = tostring(row.steamid or "")
					local rankIndex = math.Clamp(tonumber(row.rank or 1) or 1, 1, #faction.ranks)
					local rank = faction.ranks[rankIndex]
					local record = recordsByCharacter[characterID]
					local imported = record == nil
					record = record or {
						character_id = characterID,
						account_steamid = characterAccountID(characterID),
						faction_id = factionID,
						last_active = 0,
						last_promoted = 0,
						last_arrested = 0,
						joined_at = 0,
						archived_at = 0,
						updated_by = "ROSTER IMPORT",
						online = false,
					}
					record.rp_name = trim(row.name) ~= "" and row.name or record.rp_name or record.account_steamid
					record.rank_index = rankIndex
					record.rank_name = rank and rank.name or "Unknown"
					record.status = "active"
					record.archived_at = 0
					recordsByCharacter[characterID] = record
					if imported then bootstrapMembership(record) end
				end

				for _, target in ipairs(player.GetAll()) do
					if target.MBFactionID and target:MBFactionID() == factionID and target.mb_dataLoaded then
						local characterID = target:MBCharacterKey()
						local record = recordsByCharacter[characterID]
						if record then
							local rank = target:MBRank()
							record.account_steamid = target:SteamID64()
							record.rp_name = target.MBRawName and target:MBRawName() or target:MBName()
							record.steam_name = target:Nick()
							record.rank_index = target:MBRankIndex()
							record.rank_name = rank and rank.name or record.rank_name
							record.last_active = timeNow()
							record.status = "active"
							record.online = true
						end
					end
				end

				local allRecords = {}
				for _, record in pairs(recordsByCharacter) do allRecords[#allRecords + 1] = record end
				local records, resolvedFilter = applySearchAndLimit(allRecords, state.query, state.filter)
				state.filter = resolvedFilter
				enrichAndSend(ply, factionID, records, state, sendData)
			end)
		end)
	end

	local function loadActiveRecord(characterID, factionID, callback)
		MilBase.DB.Query("SELECT steamid, name, faction, `rank` FROM frontier_players WHERE steamid = "
			.. MilBase.SQLStr(characterID) .. " LIMIT 1", function(rows)
			local row = rows[1]
			if not row or row.faction ~= factionID then callback(nil) return end
			local faction = MilBase.GetFaction(factionID)
			local rankIndex = math.Clamp(tonumber(row.rank or 1) or 1, 1, #faction.ranks)
			callback({
				character_id = characterID,
				account_steamid = characterAccountID(characterID),
				faction_id = factionID,
				rp_name = row.name or characterID,
				rank_index = rankIndex,
				rank_name = faction.ranks[rankIndex].name,
				status = "active",
			})
		end)
	end

	local function deny(ply, message)
		MilBase.Notify(ply, message or "Roster action denied.", "warn")
	end

	local function authorizeRecord(ply, data, callback)
		local factionID = factionForRequest(ply, data.faction_id)
		local characterID = clean(data.character_id, 48)
		if characterID == "" or not MilBase.GetFaction(factionID) then deny(ply, "Invalid roster member.") return end
		loadActiveRecord(characterID, factionID, function(record)
			if not IsValid(ply) then return end
			if not record then deny(ply, "That member is archived or no longer belongs to this regiment.") return end
			if not canEditRecord(ply, factionID, record) then deny(ply, "You cannot edit that member's record.") return end
			callback(record, factionID)
		end)
	end

	local function updateRosterRank(ply, data, sendData)
		authorizeRecord(ply, data, function(record, factionID)
			local faction = MilBase.GetFaction(factionID)
			local newRank = math.floor(tonumber(data.rank_index or 0) or 0)
			if not faction.ranks[newRank] then deny(ply, "Invalid rank for that regiment.") return end
			if not ply:IsSuperAdmin() and factionID == ply:MBFactionID() and newRank >= ply:MBRankIndex() then
				deny(ply, "You cannot assign your own rank or a higher rank.")
				return
			end
			if newRank == record.rank_index then sendRoster(ply, data, sendData) return end
			local promoted = newRank > record.rank_index
			local target = onlineCharacter(record.character_id)
			if IsValid(target) then
				MilBase.SetRank(target, newRank, ply)
			else
				MilBase.DB.Run("UPDATE frontier_players SET `rank` = " .. newRank
					.. " WHERE steamid = " .. MilBase.SQLStr(record.character_id)
					.. " AND faction = " .. MilBase.SQLStr(factionID))
				local promotedSQL = promoted and (", last_promoted = " .. timeNow()) or ""
				MilBase.DB.Run("UPDATE frontier_regiment_roster SET rank_index = " .. newRank
					.. ", rank_name = " .. MilBase.SQLStr(faction.ranks[newRank].name)
					.. promotedSQL .. ", updated_at = " .. timeNow()
					.. ", updated_by = " .. MilBase.SQLStr(actorName(ply))
					.. " WHERE character_id = " .. MilBase.SQLStr(record.character_id)
					.. " AND faction_id = " .. MilBase.SQLStr(factionID))
			end
			MilBase.Notify(ply, (promoted and "Promoted " or "Updated ")
				.. (record.rp_name or "member") .. " to " .. faction.ranks[newRank].name .. ".", "ok")
			if MilBase.Log then
				MilBase.Log("roster", MilBase.LogTag(ply) .. " set roster rank for "
					.. record.character_id .. " to " .. faction.ranks[newRank].name, ply, target)
			end
			sendRoster(ply, data, sendData)
		end)
	end

	local function updateRosterCert(ply, data, grant, sendData)
		authorizeRecord(ply, data, function(record, factionID)
			local certID = string.lower(clean(data.cert_id, 64))
			local cert = MilBase.Certs[certID]
			if not cert or not MilBase.CertAllowedForFaction(cert, factionID) then
				deny(ply, "That certification is not valid for this regiment.")
				return
			end
			local target = onlineCharacter(record.character_id)
			if IsValid(target) then
				local changed
				if grant then changed = MilBase.GrantCert(target, certID)
				else changed = MilBase.RevokeCert(target, certID) end
				if changed == false then
					deny(ply, grant and "That member already has this certification."
						or "That member does not have this certification.")
					sendRoster(ply, data, sendData)
					return
				end
			elseif grant then
				MilBase.DB.Run("REPLACE INTO frontier_certs (steamid, cert) VALUES ("
					.. MilBase.SQLStr(record.character_id) .. ", " .. MilBase.SQLStr(certID) .. ")")
			else
				MilBase.DB.Run("DELETE FROM frontier_certs WHERE steamid = "
					.. MilBase.SQLStr(record.character_id) .. " AND cert = " .. MilBase.SQLStr(certID))
			end
			MilBase.Notify(ply, (grant and "Granted " or "Revoked ") .. (cert.name or certID)
				.. (grant and " to " or " from ") .. (record.rp_name or "member") .. ".", "ok")
			if MilBase.Log then
				MilBase.Log("roster", MilBase.LogTag(ply) .. (grant and " granted " or " revoked ")
					.. certID .. " for " .. record.character_id, ply, target)
			end
			sendRoster(ply, data, sendData)
		end)
	end

	local function addStrike(ply, data, sendData)
		authorizeRecord(ply, data, function(record, factionID)
			local reason = clean(data.reason, cfg.DatapadRosterStrikeReasonMax or 240)
			if #reason < 3 then deny(ply, "Enter a reason for the strike.") return end
			MilBase.DB.Insert("INSERT INTO frontier_regiment_strikes "
				.. "(character_id, faction_id, reason, issued_by_id, issued_by_name, created_at, active, voided_at, voided_by_name) VALUES ("
				.. MilBase.SQLStr(record.character_id) .. ", " .. MilBase.SQLStr(factionID) .. ", "
				.. MilBase.SQLStr(reason) .. ", " .. MilBase.SQLStr(ply:SteamID64()) .. ", "
				.. MilBase.SQLStr(actorName(ply)) .. ", " .. timeNow() .. ", 1, 0, '')", function()
					if not IsValid(ply) then return end
					MilBase.Notify(ply, "Strike recorded for " .. (record.rp_name or "member") .. ".", "ok")
					if MilBase.Log then
						MilBase.Log("roster", MilBase.LogTag(ply) .. " issued a strike to "
							.. record.character_id .. ": " .. reason, ply, onlineCharacter(record.character_id))
					end
					sendRoster(ply, data, sendData)
				end)
		end)
	end

	local function voidStrike(ply, data, sendData)
		authorizeRecord(ply, data, function(record, factionID)
			local strikeID = math.max(0, math.floor(tonumber(data.strike_id or 0) or 0))
			if strikeID < 1 then deny(ply, "Invalid strike record.") return end
			MilBase.DB.Run("UPDATE frontier_regiment_strikes SET active = 0, voided_at = "
				.. timeNow() .. ", voided_by_name = " .. MilBase.SQLStr(actorName(ply))
				.. " WHERE id = " .. strikeID .. " AND active = 1 AND character_id = "
				.. MilBase.SQLStr(record.character_id) .. " AND faction_id = " .. MilBase.SQLStr(factionID))
			MilBase.Notify(ply, "Strike marked as resolved.", "ok")
			sendRoster(ply, data, sendData)
		end)
	end

	function MilBase.RosterHandleDatapadRequest(ply, action, data, sendData)
		if not Roster.CanView(ply) then deny(ply, "Roster access denied.") return end
		data = istable(data) and data or {}
		action = tostring(action or "list")
		if action == "set_rank" then updateRosterRank(ply, data, sendData)
		elseif action == "grant_cert" then updateRosterCert(ply, data, true, sendData)
		elseif action == "revoke_cert" then updateRosterCert(ply, data, false, sendData)
		elseif action == "add_strike" then addStrike(ply, data, sendData)
		elseif action == "void_strike" then voidStrike(ply, data, sendData)
		else sendRoster(ply, data, sendData) end
	end

	return
end

--------------------------------------------------------------------------
-- Client: embedded datapad application
--------------------------------------------------------------------------

local function dateOrNever(api, stamp, neverText)
	stamp = tonumber(stamp or 0) or 0
	return stamp > 0 and api.dateText(stamp) or (neverText or "Not recorded")
end

function MilBase.BuildRegimentRosterDatapad(parent, request, api)
	local state = {
		query = "",
		filter = "active",
		factionID = "",
		selectedID = "",
		payload = nil,
	}

	local function send(action, extra)
		extra = extra or {}
		extra.query = state.query
		extra.filter = state.filter
		extra.faction_id = state.factionID
		extra.selected_id = state.selectedID
		request("regiment_roster", action or "list", extra)
	end

	local render
	render = function(payload)
		if not IsValid(parent) then return end
		state.payload = payload or {}
		state.query = tostring(payload.query or state.query or "")
		state.filter = tostring(payload.filter or state.filter or "active")
		state.factionID = tostring(payload.faction_id or state.factionID or "")
		state.selectedID = tostring(payload.selected_id or state.selectedID or "")
		parent:Clear()

		local u = api.ui()
		local controls = api.section(parent, "REGIMENT PERSONNEL DATABASE", 96)
		local controlRow = vgui.Create("DPanel", controls)
		controlRow:Dock(FILL)
		controlRow:DockMargin(12, 39, 12, 10)
		controlRow.Paint = nil

		if payload.can_choose_faction then
			local faction = vgui.Create("DComboBox", controlRow)
			faction:Dock(LEFT)
			faction:SetWide(190)
			faction:DockMargin(0, 0, 8, 0)
			faction:SetValue(payload.faction_name or state.factionID)
			for _, entry in ipairs(payload.factions or {}) do
				faction:AddChoice(entry.name or entry.id, entry.id, entry.id == state.factionID)
			end
			faction.OnSelect = function(_, _, _, id)
				state.factionID = tostring(id or "")
				state.selectedID = ""
				send("list")
			end
		end

		local filter = vgui.Create("DComboBox", controlRow)
		filter:Dock(LEFT)
		filter:SetWide(120)
		filter:DockMargin(0, 0, 8, 0)
		local filterNames = { active = "Active", archive = "Archive", all = "All Members" }
		filter:SetValue(filterNames[state.filter] or "Active")
		filter:AddChoice("Active", "active")
		filter:AddChoice("Archive", "archive")
		filter:AddChoice("All Members", "all")
		filter.OnSelect = function(_, _, _, id)
			state.filter = tostring(id or "active")
			state.selectedID = ""
			send("list")
		end

		local refresh = api.btn(controlRow, "REFRESH", u.accent, function() send("list") end)
		refresh:Dock(RIGHT)
		refresh:SetWide(100)

		local search = vgui.Create("DTextEntry", controlRow)
		search:Dock(FILL)
		search:DockMargin(0, 0, 8, 0)
		search:SetPaintBackground(false)
		search:SetFont(api.font("MB.Small", "DermaDefault"))
		search:SetPlaceholderText("Search name, rank, Steam ID or character...")
		search:SetValue(state.query)
		search.Paint = api.paintEntry
		search.OnEnter = function(self)
			state.query = self:GetValue() or ""
			state.selectedID = ""
			send("list")
		end

		local records = payload.records or {}
		local selectedRecord
		for _, record in ipairs(records) do
			if record.character_id == state.selectedID then selectedRecord = record break end
		end
		if not selectedRecord and records[1] then
			selectedRecord = records[1]
			state.selectedID = selectedRecord.character_id
		end

		local main = vgui.Create("DPanel", parent)
		main:Dock(FILL)
		main.Paint = nil
		local list = vgui.Create("DScrollPanel", main)
		list:Dock(LEFT)
		list:SetWide(360)
		list:DockMargin(0, 0, 10, 0)
		local details = vgui.Create("DScrollPanel", main)
		details:Dock(FILL)
		main.PerformLayout = function(self, w)
			list:SetWide(math.Clamp(math.floor(w * 0.39), 300, 430))
		end

		if #records == 0 then
			local empty = api.section(list, "", 82)
			empty.Paint = function(self, w, h)
				api.drawPanel(0, 0, w, h, { cut = 7, color = Color(255, 255, 255, 4), accent = u.outline })
				draw.SimpleText("NO MATCHING PERSONNEL", api.font("MB.Small", "DermaDefaultBold"),
					12, 18, u.faint)
				draw.SimpleText("Try another search or roster filter.", api.font("MB.Tiny", "DermaDefault"),
					12, 45, u.dim)
			end
		end

		for _, entry in ipairs(records) do
			local record = entry
			local row = vgui.Create("DButton", list)
			row:Dock(TOP)
			row:SetTall(76)
			row:DockMargin(0, 0, 0, 6)
			row:SetText("")
			row.Paint = function(self, w, h)
				local chosen = state.selectedID == record.character_id
				local accent = record.status == "archived" and u.faint
					or (record.online and u.ok or u.accent)
				api.drawPanel(0, 0, w, h, {
					cut = 7,
					color = chosen and Color(accent.r, accent.g, accent.b, 35)
						or (self:IsHovered() and u.hover or Color(255, 255, 255, 4)),
					accent = accent,
				})
				api.drawFitText(record.rp_name or "Unknown", api.font("MB.Small", "DermaDefaultBold"),
					12, 9, u.text, w - 105)
				api.drawFitText(record.rank_name or "Unknown rank", api.font("MB.Tiny", "DermaDefault"),
					12, 33, u.dim, w - 24)
				local status = record.status == "archived" and "ARCHIVED"
					or (record.online and "ONLINE" or "OFFLINE")
				draw.SimpleText(status, api.font("MB.Tiny", "DermaDefaultBold"), w - 10, 11,
					accent, TEXT_ALIGN_RIGHT)
				draw.SimpleText((tonumber(record.active_strikes or 0) or 0) .. " ACTIVE STRIKES",
					api.font("MB.Tiny", "DermaDefault"), 12, 55,
					(record.active_strikes or 0) > 0 and u.danger or u.faint)
			end
			row.DoClick = function()
				state.selectedID = record.character_id
				send("list")
			end
		end

		if not selectedRecord then return end
		local record = selectedRecord

		local identity = api.section(details, "PERSONNEL RECORD", 198)
		identity.Paint = function(self, w, h)
			local accent = record.status == "archived" and u.faint or u.accent
			api.drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 125), accent = accent })
			api.drawFitText(record.rp_name or "Unknown", api.font("MB.Big", "DermaLarge"),
				14, 36, u.text, w - 150)
			draw.SimpleText(string.upper(record.status or "active"), api.font("MB.Small", "DermaDefaultBold"),
				w - 14, 44, accent, TEXT_ALIGN_RIGHT)
			local lines = {
				"Rank: " .. (record.rank_name or "Unknown"),
				"Regiment: " .. (payload.faction_name or record.faction_id or "Unknown"),
				"Steam name: " .. ((record.steam_name ~= "" and record.steam_name) or "Not recorded"),
				"Account: " .. (record.account_steamid or "Unknown"),
				"Character record: " .. (record.character_id or "Unknown"),
			}
			for index, line in ipairs(lines) do
				api.drawFitText(line, api.font("MB.Tiny", "DermaDefault"),
					16, 72 + ((index - 1) * 22), index <= 2 and u.text or u.dim, w - 32)
			end
		end

		local history = api.section(details, "SERVICE HISTORY", 148)
		history.Paint = function(self, w, h)
			api.drawPanel(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 115), accent = u.outline })
			local left = {
				"Last active: " .. dateOrNever(api, record.last_active, "Not recorded yet"),
				"Last promoted: " .. dateOrNever(api, record.last_promoted, "No promotion recorded"),
				"Last arrested: " .. dateOrNever(api, record.last_arrested, "No arrest recorded"),
			}
			local right = {
				"Joined roster: " .. dateOrNever(api, record.joined_at, "Imported record"),
				"Archived: " .. dateOrNever(api, record.archived_at, "Not archived"),
				"Active strikes: " .. tostring(record.active_strikes or 0),
			}
			for index, line in ipairs(left) do
				api.drawFitText(line, api.font("MB.Tiny", "DermaDefault"),
					16, 42 + ((index - 1) * 27), u.dim, math.max(120, (w * 0.5) - 24))
			end
			for index, line in ipairs(right) do
				api.drawFitText(line, api.font("MB.Tiny", "DermaDefault"),
					math.floor(w * 0.52), 42 + ((index - 1) * 27),
					index == 3 and (record.active_strikes > 0 and u.danger or u.ok) or u.dim,
					math.max(120, (w * 0.48) - 18))
			end
		end

		if record.can_edit then
			local rankPanel = api.section(details, "RANK CONTROL", 112)
			local rankInner = vgui.Create("DPanel", rankPanel)
			rankInner:Dock(FILL)
			rankInner:DockMargin(14, 42, 14, 14)
			rankInner.Paint = nil
			local rankChoice = vgui.Create("DComboBox", rankInner)
			rankChoice:Dock(FILL)
			rankChoice:DockMargin(0, 0, 8, 0)
			rankChoice:SetValue(record.rank_name or "Select rank")
			local chosenRank = tonumber(record.rank_index or 1) or 1
			for _, rank in ipairs(payload.ranks or {}) do
				rankChoice:AddChoice(rank.name, rank.index, rank.index == chosenRank)
			end
			rankChoice.OnSelect = function(_, _, _, index) chosenRank = tonumber(index) or chosenRank end
			local apply = api.btn(rankInner, "APPLY RANK", u.warn, function()
				send("set_rank", { character_id = record.character_id, rank_index = chosenRank })
			end)
			apply:Dock(RIGHT)
			apply:SetWide(140)
		end

		local certHeight = 105 + (#(record.certs or {}) * 42)
		if record.can_edit then certHeight = certHeight + 48 end
		local certPanel = api.section(details, "CERTIFICATIONS", math.max(120, certHeight))
		local certInner = vgui.Create("DPanel", certPanel)
		certInner:Dock(FILL)
		certInner:DockMargin(14, 42, 14, 12)
		certInner.Paint = nil
		if record.can_edit then
			local certRow = vgui.Create("DPanel", certInner)
			certRow:Dock(TOP)
			certRow:SetTall(38)
			certRow:DockMargin(0, 0, 0, 8)
			certRow.Paint = nil
			local certChoice = vgui.Create("DComboBox", certRow)
			certChoice:Dock(FILL)
			certChoice:DockMargin(0, 0, 8, 0)
			certChoice:SetValue("Select certification")
			local chosenCert = ""
			for _, cert in ipairs(payload.certifications or {}) do certChoice:AddChoice(cert.name, cert.id) end
			certChoice.OnSelect = function(_, _, _, id) chosenCert = tostring(id or "") end
			local grant = api.btn(certRow, "GRANT", u.ok, function()
				if chosenCert ~= "" then
					send("grant_cert", { character_id = record.character_id, cert_id = chosenCert })
				end
			end)
			grant:Dock(RIGHT)
			grant:SetWide(100)
		end
		if #(record.certs or {}) == 0 then
			local none = vgui.Create("DLabel", certInner)
			none:Dock(TOP)
			none:SetTall(30)
			none:SetFont(api.font("MB.Tiny", "DermaDefault"))
			none:SetTextColor(u.faint)
			none:SetText("No certifications recorded.")
		end
		for _, entry in ipairs(record.certs or {}) do
			local cert = entry
			local certRow = vgui.Create("DPanel", certInner)
			certRow:Dock(TOP)
			certRow:SetTall(36)
			certRow:DockMargin(0, 0, 0, 6)
			certRow.Paint = function(self, w, h)
				api.drawPanel(0, 0, w, h, { cut = 5, color = Color(255, 255, 255, 4), accent = u.ok })
				api.drawFitText(cert.name or cert.id, api.font("MB.Tiny", "DermaDefaultBold"),
					10, 10, u.text, w - (record.can_edit and 100 or 20))
			end
			if record.can_edit then
				local revoke = api.btn(certRow, "REVOKE", u.danger, function()
					send("revoke_cert", { character_id = record.character_id, cert_id = cert.id })
				end)
				revoke:Dock(RIGHT)
				revoke:SetWide(88)
			end
		end

		local strikeHeight = 108 + (#(record.strikes or {}) * 62)
		if record.can_edit then strikeHeight = strikeHeight + 48 end
		local strikePanel = api.section(details, "DISCIPLINARY STRIKES", math.max(125, strikeHeight))
		local strikeInner = vgui.Create("DPanel", strikePanel)
		strikeInner:Dock(FILL)
		strikeInner:DockMargin(14, 42, 14, 12)
		strikeInner.Paint = nil
		if record.can_edit then
			local strikeRow = vgui.Create("DPanel", strikeInner)
			strikeRow:Dock(TOP)
			strikeRow:SetTall(38)
			strikeRow:DockMargin(0, 0, 0, 8)
			strikeRow.Paint = nil
			local reason = vgui.Create("DTextEntry", strikeRow)
			reason:Dock(FILL)
			reason:DockMargin(0, 0, 8, 0)
			reason:SetPaintBackground(false)
			reason:SetFont(api.font("MB.Small", "DermaDefault"))
			reason:SetPlaceholderText("Reason for strike...")
			reason.Paint = api.paintEntry
			local issue = api.btn(strikeRow, "ISSUE STRIKE", u.danger, function()
				send("add_strike", { character_id = record.character_id, reason = reason:GetValue() })
			end)
			issue:Dock(RIGHT)
			issue:SetWide(130)
		end
		if #(record.strikes or {}) == 0 then
			local none = vgui.Create("DLabel", strikeInner)
			none:Dock(TOP)
			none:SetTall(30)
			none:SetFont(api.font("MB.Tiny", "DermaDefault"))
			none:SetTextColor(u.ok)
			none:SetText("No disciplinary strikes recorded.")
		end
		for _, entry in ipairs(record.strikes or {}) do
			local strike = entry
			local strikeRow = vgui.Create("DPanel", strikeInner)
			strikeRow:Dock(TOP)
			strikeRow:SetTall(56)
			strikeRow:DockMargin(0, 0, 0, 6)
			strikeRow.Paint = function(self, w, h)
				local accent = strike.active and u.danger or u.faint
				api.drawPanel(0, 0, w, h, { cut = 5, color = Color(255, 255, 255, 4), accent = accent })
				api.drawFitText(strike.reason or "No reason", api.font("MB.Tiny", "DermaDefaultBold"),
					10, 8, strike.active and u.text or u.dim, w - (strike.active and record.can_edit and 105 or 20))
				local foot = "Issued by " .. (strike.issued_by_name or "Unknown") .. " - "
					.. dateOrNever(api, strike.created_at)
				if not strike.active then
					foot = foot .. " - RESOLVED by " .. (strike.voided_by_name or "Unknown")
				end
				api.drawFitText(foot, api.font("MB.Tiny", "DermaDefault"),
					10, 32, u.faint, w - 20)
			end
			if strike.active and record.can_edit then
				local resolve = api.btn(strikeRow, "RESOLVE", u.ok, function()
					send("void_strike", { character_id = record.character_id, strike_id = strike.id })
				end)
				resolve:Dock(RIGHT)
				resolve:SetWide(94)
			end
		end
	end

	api.setHandler(render)
	send("list")
end
