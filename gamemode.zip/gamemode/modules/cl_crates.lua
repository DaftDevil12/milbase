--[[
	CRATES tab: spend credits to open crates and unlock Star Cards,
	attachments/gear (items), boosters and credits. Rewards reveal in a
	Battlefront-style card flip.
]]

if SERVER then return end

local cfg = MilBase.Config

local iconCache = {}
local function itemIcon(path)
	if not path then return nil end
	iconCache[path] = iconCache[path] or Material(path, "smooth")
	return iconCache[path]
end

-- Crate tier -> colour (icon art lives in MilBase.UI.art.bf2.crateTiers).
local TIER_COLORS = {
	[1] = Color(200, 140, 90),   -- bronze
	[2] = Color(205, 205, 215),  -- silver
	[3] = Color(255, 198, 60),   -- gold
	[4] = Color(185, 120, 230),  -- legendary
}
local function crateTier(crate)
	return crate.tier or (crate.cost >= 1000 and 3 or crate.cost >= 600 and 2 or 1)
end

--------------------------------------------------------------------------
-- Reward reveal
--------------------------------------------------------------------------

local function showReveal(crate, results)
	local ui = MilBase.UI

	local n = #results
	local cw, ch = 190, 250
	local gap = 16
	local totalW = n * cw + (n - 1) * gap + 60
	local frame = vgui.Create("DPanel")
	frame:SetSize(math.max(totalW, 380), ch + 120)
	frame:Center()
	frame:MakePopup()

	local born = SysTime()
	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, ui.accent, 14)
		local tier = crateTier(crate)
		MilBase.DrawIcon(ui.art.bf2.crateTiers[tier], w / 2 - 132, 4, 30, 30,
			TIER_COLORS[tier] or ui.accent)
		draw.SimpleText(string.upper(crate.name) .. " — REWARDS", "MB.Tab", w / 2, 16,
			ui.text, TEXT_ALIGN_CENTER)

		local startX = (w - (n * cw + (n - 1) * gap)) / 2
		for i, r in ipairs(results) do
			-- Staggered reveal.
			if SysTime() - born < (i - 1) * 0.18 then continue end

			local x = startX + (i - 1) * (cw + gap)
			local y = 56

			if r.type == "card" then
				local card = MilBase.GetStarCard(r.id)
				if card then
					MilBase.PaintStarCard(x, y, cw, ch, card, { unlocked = true })
					draw.SimpleText("NEW STAR CARD", "MB.Tiny", x + cw / 2, y + ch + 6,
						MilBase.CardRarity.legendary.color, TEXT_ALIGN_CENTER)
				end
			else
				MilBase.DrawPanelBF2(x, y, cw, ch, { cut = 8, accent = ui.accent })
				local label, sub, icon

				if r.type == "item" then
					local def = MilBase.Items[r.id]
					label = def and def.name or r.id
					sub = "x" .. (r.amount or 1)
					icon = def and def.icon
				elseif r.type == "attachment" then
					local def = ArcCW and ArcCW.AttachmentTable and ArcCW.AttachmentTable[r.id]
					label = MilBase.ArcCWAttachmentName(r.id)
					sub = "ARCCW ATTACHMENT  x" .. (r.amount or 1)
					icon = def and def.Icon
				elseif r.type == "weapon" then
					label = MilBase.WeaponDisplayName(r.id)
					sub = "PERMANENT WEAPON"
				elseif r.type == "credits" then
					label = "+" .. r.amount
					sub = string.upper(cfg.CurrencyName or "credits")
				elseif r.type == "booster" then
					label = "x" .. string.format("%.2g", r.mult) .. " BOOSTER"
					sub = math.floor((r.duration or 0) / 60) .. " MIN"
				end

				if icon then
					local material = isstring(icon) and itemIcon(icon) or icon
					if material then
						surface.SetDrawColor(255, 255, 255, 235)
						surface.SetMaterial(material)
						surface.DrawTexturedRect(x + cw / 2 - 36, y + ch / 2 - 50, 72, 72)
					end
				elseif r.type == "credits" then
					MilBase.DrawDiamond(x + cw / 2, y + ch / 2 - 24, 20, ui.accent)
				end

				draw.SimpleText(label or "?", "MB.Med", x + cw / 2, y + ch - 54,
					ui.text, TEXT_ALIGN_CENTER)
				draw.SimpleText(sub or "", "MB.Tiny", x + cw / 2, y + ch - 30,
					ui.dim, TEXT_ALIGN_CENTER)
			end
		end

		draw.SimpleText("CLICK TO CONTINUE", "MB.Tiny", w / 2, h - 22, ui.faint, TEXT_ALIGN_CENTER)
	end

	frame.OnMousePressed = function(self) self:Remove() end
	frame.Think = function(self)
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() end
	end

	MilBase.PlayUISound("notify")
end

net.Receive("MilBase_CrateResult", function()
	local id = net.ReadString()
	local results = net.ReadTable() or {}
	local crate = MilBase.GetCrate(id)
	if crate then showReveal(crate, results) end
end)

--------------------------------------------------------------------------
-- The tab
--------------------------------------------------------------------------

local function lootSummary(crate)
	local kinds = {}
	for _, e in ipairs(crate.loot) do
		local k = e.type == "card" and "Star Cards" or e.type == "item" and "Gear"
			or e.type == "attachment" and "Attachments" or e.type == "weapon" and "Weapons"
			or e.type == "booster" and "Boosters" or "Credits"
		kinds[k] = true
	end
	local out = {}
	for k in pairs(kinds) do out[#out + 1] = k end
	return table.concat(out, "  •  ")
end

MilBase.AddMenuTab("CRATES", 26, function(content)
	local ui = MilBase.UI
	local ply = LocalPlayer()

	local header = vgui.Create("DPanel", content)
	header:Dock(TOP)
	header:SetTall(30)
	header:DockMargin(0, 0, 0, 8)
	header.Paint = function(self, w, h)
		draw.SimpleText("REQUISITION", "MB.Tab", 2, 0, ui.text)
		MilBase.DrawIcon(ui.art.bf2.accentBar, 2, 23, 150, 3)
		MilBase.DrawDiamond(w - 120, 12, 6, ui.accent)
		draw.SimpleText(ply:MBMoney() .. " " .. string.upper(cfg.CurrencyName or "credits"),
			"MB.Small", w - 106, 12, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	for _, id in ipairs(MilBase.CrateOrder) do
		local crate = MilBase.GetCrate(id)

		local card = vgui.Create("DPanel", scroll)
		card:Dock(TOP)
		card:SetTall(84)
		card:DockMargin(0, 0, 8, 8)
		local tier = crateTier(crate)
		local tcol = TIER_COLORS[tier] or ui.accent
		card.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = tcol })

			-- Tier badge: crate icon in a chamfered frame, left side.
			local bs, bx = 60, 14
			local by = (h - bs) / 2
			MilBase.DrawIcon(ui.art.bf2.itemFrame, bx, by, bs, bs,
				Color(tcol.r, tcol.g, tcol.b, 120))
			MilBase.DrawIcon(ui.art.bf2.crateTiers[tier], bx + 6, by + 4, bs - 12, bs - 12, tcol)

			local tx = bx + bs + 14
			draw.SimpleText(string.upper(crate.name), "MB.Med", tx, 10, ui.text)
			draw.SimpleText(string.upper(lootSummary(crate)), "MB.Tiny", tx, 36, ui.dim)
			draw.SimpleText(crate.rewards .. " reward(s) per open", "MB.Tiny", tx, 54, ui.faint)

			-- Tier pips.
			for i = 1, tier do
				MilBase.DrawIcon(ui.art.bf2.star, tx + (i - 1) * 15, 70, 11, 11, tcol)
			end
		end

		local open = vgui.Create("DButton", card)
		open:SetSize(150, 56)
		open:SetPos(0, 14) -- positioned in PerformLayout
		open:SetText("")
		card.PerformLayout = function(self, w, h)
			open:SetPos(w - 166, 14)
		end
		open.Paint = function(self, w, h)
			local afford = ply:MBMoney() >= crate.cost
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 6,
				color = self:IsHovered() and afford and ui.hover or Color(0, 0, 0, 130),
				outlineColor = afford and ui.accent or ui.outline,
			})
			draw.SimpleText("OPEN", "MB.Small", w / 2, h / 2 - 10,
				afford and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			MilBase.DrawIcon(ui.art.bf2.chevron, w - 20, h / 2 - 9, 16, 16,
				afford and ui.accent or ui.faint)
			draw.SimpleText(cfg.CurrencySymbol .. " " .. crate.cost, "MB.Tiny", w / 2, h / 2 + 12,
				afford and ui.accent or ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		open.DoClick = function()
			if ply:MBMoney() < crate.cost then
				MilBase.Notify(ply, "Not enough " .. (cfg.CurrencyName or "credits") .. ".")
				return
			end
			net.Start("MilBase_OpenCrate")
				net.WriteString(id)
			net.SendToServer()
			MilBase.PlayUISound("select")
		end
	end
end)
