--[[
	STAR CARDS tab: equip your unlocked star cards (Battlefront loadout
	cards) into cfg.StarCardSlots slots. Cards you can't use yet (locked,
	or wrong faction/cert) are shown greyed. Effects apply on next spawn.
]]

if SERVER then return end

local cfg = MilBase.Config

MilBase.LocalUnlocked = MilBase.LocalUnlocked or {}

net.Receive("MilBase_Unlocks", function()
	MilBase.LocalUnlocked = net.ReadTable() or {}
end)

local function localEquipped()
	local out = {}
	for id in string.gmatch(LocalPlayer():GetNWString("mb_equipped", ""), "([^,]+)") do
		out[#out + 1] = id
	end
	return out
end

local function isEquipped(id)
	for _, cid in ipairs(localEquipped()) do if cid == id then return true end end
	return false
end

local function sendEquip(slot, id)
	net.Start("MilBase_EquipCard")
		net.WriteUInt(slot, 4)
		net.WriteString(id or "")
	net.SendToServer()
end

--------------------------------------------------------------------------
-- Shared card painter (reused by the crate reveal)
--------------------------------------------------------------------------

-- opts: unlocked, equipped, hovered, faded (unusable)
function MilBase.PaintStarCard(x, y, w, h, card, opts)
	opts = opts or {}
	local ui = MilBase.UI
	local rar = MilBase.CardRarity[card.rarity] or MilBase.CardRarity.common
	local edge = opts.faded and Color(90, 90, 90) or rar.color

	-- Rarity bloom behind a hovered card.
	if opts.hovered and not opts.faded then
		MilBase.DrawIcon(ui.art.bf2.glow, x - 18, y - 18, w + 36, h + 36,
			Color(edge.r, edge.g, edge.b, 45))
	end

	MilBase.DrawPanelBF2(x, y, w, h, {
		cut = 8,
		color = Color(10, 11, 13, 235),
		outlineColor = Color(edge.r, edge.g, edge.b, opts.hovered and 230 or 150),
	})

	-- Holographic scanline wash; rarity frame on portrait cards only (the
	-- chamfer would distort on the wide equipped-slot cards, so guard by aspect).
	MilBase.DrawIcon(ui.art.bf2.scanlines, x + 3, y + 3, w - 6, h - 6, Color(255, 255, 255, 10))
	if h > w then
		MilBase.DrawIcon(ui.art.bf2.cardFrame, x, y, w, h,
			Color(edge.r, edge.g, edge.b, opts.hovered and 235 or 160))
	end

	-- Rarity strip along the top.
	surface.SetDrawColor(edge.r, edge.g, edge.b, opts.faded and 90 or 200)
	surface.DrawRect(x + 4, y + 4, w - 8, 3)

	local txtCol = opts.faded and ui.faint or ui.text
	draw.SimpleText(string.upper(card.name), "MB.Small", x + 10, y + 16, txtCol)

	-- Rarity gem + label.
	MilBase.DrawIcon(ui.art.bf2.rarityGem, x + 9, y + 31, 14, 14,
		opts.faded and ui.faint or edge)
	draw.SimpleText(string.upper(rar.name), "MB.Tiny", x + 28, y + 34,
		opts.faded and ui.faint or edge)

	-- Wrapped description.
	local words = string.Explode(" ", card.desc or "")
	surface.SetFont("MB.Tiny")
	local line, ly = "", y + 54
	for _, word in ipairs(words) do
		local test = line == "" and word or (line .. " " .. word)
		if surface.GetTextSize(test) > w - 20 then
			draw.SimpleText(line, "MB.Tiny", x + 10, ly, ui.dim)
			line, ly = word, ly + 14
		else
			line = test
		end
		if ly > y + h - 40 then break end
	end
	if line ~= "" then draw.SimpleText(line, "MB.Tiny", x + 10, ly, ui.dim) end

	-- Grants line at the bottom.
	local grants = MilBase.CardGrantsText(card)
	if grants ~= "" then
		draw.SimpleText(string.upper(grants), "MB.Tiny", x + 10, y + h - 22,
			opts.faded and ui.faint or ui.warn)
	end

	if opts.equipped then
		MilBase.DrawBrackets(x + 2, y + 2, w - 4, h - 4, ui.accent, 10)
		draw.SimpleText("EQUIPPED", "MB.Tiny", x + w - 10, y + 16, ui.accent, TEXT_ALIGN_RIGHT)
	elseif opts.unlocked == false then
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(x + 1, y + 1, w - 2, h - 2)
		draw.SimpleText("LOCKED", "MB.Small", x + w / 2, y + h / 2, ui.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

--------------------------------------------------------------------------
-- The tab
--------------------------------------------------------------------------

MilBase.AddMenuTab("STAR CARDS", 22, function(content)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local slots = cfg.StarCardSlots or 3

	-- Equip-slot row.
	local slotRow = vgui.Create("DPanel", content)
	slotRow:Dock(TOP)
	slotRow:SetTall(120)
	slotRow:DockMargin(0, 0, 0, 10)
	slotRow.Paint = function(self, w, h)
		draw.SimpleText("EQUIPPED  (" .. #localEquipped() .. " / " .. slots .. ")",
			"MB.Tab", 4, 2, ui.text)
		MilBase.DrawIcon(ui.art.bf2.accentBar, 4, 25, 150, 3)
		draw.SimpleText("XP " .. ply:GetNWInt("mb_xp", 0), "MB.Small", w, 6, ui.dim, TEXT_ALIGN_RIGHT)

		local bexp = ply:GetNWInt("mb_booster_expires", 0)
		if bexp > os.time() then
			draw.SimpleText(string.format("BOOSTER x%.2g  %dm left",
				ply:GetNWFloat("mb_booster_mult", 1), math.ceil((bexp - os.time()) / 60)),
				"MB.Tiny", w, 26, MilBase.CardRarity.legendary.color, TEXT_ALIGN_RIGHT)
		end

		local eq = localEquipped()
		local cw, ch = 150, 84
		for i = 1, slots do
			local sx = 4 + (i - 1) * (cw + 8)
			local sy = 30
			local id = eq[i]
			local card = id and MilBase.GetStarCard(id)
			if card then
				MilBase.PaintStarCard(sx, sy, cw, ch, card, { unlocked = true })
			else
				MilBase.DrawPanelBF2(sx, sy, cw, ch, { cut = 6, color = Color(0, 0, 0, 120) })
				MilBase.DrawIcon(ui.art.bf2.hexHollow, sx + cw / 2 - 13, sy + ch / 2 - 30,
					26, 26, ui.faint)
				draw.SimpleText("EMPTY SLOT " .. i, "MB.Tiny", sx + cw / 2, sy + ch / 2 + 6,
					ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
	end
	slotRow.OnMousePressed = function(self, code)
		if code ~= MOUSE_LEFT then return end
		local mx, my = self:CursorPos()
		if my < 30 or my > 114 then return end -- only the slot cards, not the header
		local i = math.floor((mx - 4) / (150 + 8)) + 1
		local eq = localEquipped()
		if eq[i] then
			sendEquip(i, "")
			MilBase.PlayUISound("select")
		end
	end

	-- Available cards grid.
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local grid = vgui.Create("DIconLayout", scroll)
	grid:Dock(FILL)
	grid:SetSpaceX(8)
	grid:SetSpaceY(8)

	local function equip(id)
		if isEquipped(id) then
			local eq = localEquipped()
			for s, cid in ipairs(eq) do if cid == id then sendEquip(s, "") break end end
		else
			local eq = localEquipped()
			if #eq >= slots then
				MilBase.Notify(ply, "Loadout full - unequip a card first.")
				return
			end
			sendEquip(#eq + 1, id)
		end
		MilBase.PlayUISound("select")
	end

	for _, id in ipairs(MilBase.StarCardOrder) do
		local card = MilBase.GetStarCard(id)
		-- Only show cards this soldier could ever use (faction / cert).
		if MilBase.CardAvailable(ply, card) then
			local unlocked = MilBase.LocalUnlocked[id] == true

			local btn = grid:Add("DButton")
			btn:SetSize(168, 200)
			btn:SetText("")
			btn.Paint = function(self, w, h)
				MilBase.PaintStarCard(0, 0, w, h, card, {
					unlocked = unlocked,
					equipped = isEquipped(id),
					hovered = self:IsHovered(),
				})
			end
			btn.DoClick = function()
				if unlocked then equip(id)
				else MilBase.Notify(ply, "That card is locked - find it in a crate.") end
			end
		end
	end
end)
