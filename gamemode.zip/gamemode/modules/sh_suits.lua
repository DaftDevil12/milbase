--[[
	Sealed suits & atmosphere (life support).

	/sealsuit (Combat Engineers only) - "** X seals their suit" - toggles
	your suit seal and gives you an oxygen meter: a sealed suit breathes
	from its tank (cfg.SuitOxygenTime seconds), refilled by unsealing in
	normal atmosphere.

	While a hull breach is ACTIVE (see /engspot), the area around it
	(cfg.BreachVacuumRadius) is venting: unprotected soldiers burn through
	their lung air (cfg.LungAirTime) and then suffocate. A sealed suit
	keeps you alive as long as the tank lasts.
]]

local cfg = MilBase.Config

local function inVacuum(ply)
	local radius = cfg.BreachVacuumRadius or 0
	if radius <= 0 then return false end

	for _, breach in ipairs(ents.FindByClass("mb_breach")) do
		if breach:GetBreached()
		and breach:GetPos():DistToSqr(ply:GetPos()) < radius * radius then
			return true
		end
	end
	return false
end

local function isEngineer(ply)
	return ply:MBHasCert("engineer") or ply:IsAdmin()
end

-- Sealing your suit is a self-menu action (hold [G]). Engineers only.
MilBase.RegisterSelfAction("sealsuit", {
	name = function(lp)
		return lp:GetNWBool("mb_sealed", false) and "Unseal Suit" or "Seal Suit"
	end,
	order = 15,
	visible = function(lp) return isEngineer(lp) end,
	run = function(ply)
		if not isEngineer(ply) then return end
		if not ply:Alive() or ply:GetNWBool("mb_wounded", false) then return end
		if ply:GetNWBool("mb_cuffed", false) then
			MilBase.Notify(ply, "You are restrained.")
			return
		end

		local sealed = not ply:GetNWBool("mb_sealed", false)
		ply:SetNWBool("mb_sealed", sealed)
		ply:EmitSound("ambient/machines/steam_release_1.wav", 60, sealed and 110 or 95, 0.5)
		MilBase.TalkRanged(ply, cfg.TalkRange, Color(190, 170, 220),
			"** " .. ply:MBName() .. (sealed and " seals their suit" or " unseals their suit"))
	end,
})

if SERVER then

	--------------------------------------------------------------------
	-- Oxygen tick
	--------------------------------------------------------------------

	local TICK = 0.5
	local nextTick = 0

	hook.Add("Think", "MilBase.SuitOxygen", function()
		if CurTime() < nextTick then return end
		nextTick = CurTime() + TICK

		local maxO2 = cfg.SuitOxygenTime or 300

		for _, ply in ipairs(player.GetAll()) do
			if not ply:Alive() then continue end

			local oxygen = ply:GetNWFloat("mb_oxygen", maxO2)
			local sealed = ply:GetNWBool("mb_sealed", false)
			local vacuum = inVacuum(ply)

			if sealed then
				-- Breathing from the tank.
				oxygen = oxygen - TICK
			elseif vacuum then
				-- Raw lungs in vacuum: the meter empties in LungAirTime.
				oxygen = oxygen - TICK * (maxO2 / math.max(cfg.LungAirTime or 25, 1))
			else
				-- Fresh air: recover fast.
				oxygen = math.min(maxO2, oxygen + TICK * 15)
			end

			if oxygen <= 0 then
				oxygen = 0

				if sealed and not vacuum then
					-- Tank's dry but the air is fine: pop the seal.
					ply:SetNWBool("mb_sealed", false)
					MilBase.Notify(ply, "Suit tank depleted - seal released.")
				else
					-- Suffocating (engine plays drowning pain sounds).
					local dmg = DamageInfo()
					dmg:SetDamage((cfg.SuffocationDamage or 6) * TICK)
					dmg:SetAttacker(game.GetWorld())
					dmg:SetInflictor(game.GetWorld())
					dmg:SetDamageType(DMG_DROWN)
					ply:TakeDamageInfo(dmg)
				end
			end

			ply:SetNWFloat("mb_oxygen", oxygen)
		end
	end)

	-- Fresh spawn, fresh lungs.
	hook.Add("PlayerSpawn", "MilBase.SuitReset", function(ply)
		ply:SetNWBool("mb_sealed", false)
		ply:SetNWFloat("mb_oxygen", cfg.SuitOxygenTime or 300)
	end)

else -- CLIENT

	local COL_O2 = Color(110, 190, 220)

	hook.Add("HUDPaint", "MilBase.SuitHUD", function()
		if MilBase.InEventView() then return end
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then return end

		local ui = MilBase.UI
		local sealed = lp:GetNWBool("mb_sealed", false)
		local vacuum = inVacuum(lp)
		if not sealed and not vacuum then return end

		-- Oxygen meter (top left)
		local maxO2 = cfg.SuitOxygenTime or 300
		local oxygen = lp:GetNWFloat("mb_oxygen", maxO2)
		local frac = math.Clamp(oxygen / maxO2, 0, 1)

		local x, y, w, h = 20, 24, 210, 46
		MilBase.DrawPanelBF2(x, y, w, h, {
			cut = 8,
			accent = frac > 0.25 and COL_O2 or ui.danger,
		})

		draw.SimpleText(sealed and "SUIT SEALED" or "OXYGEN", "MB.Tiny",
			x + 12, y + 6, sealed and COL_O2 or ui.warn)
		draw.SimpleText(math.ceil(oxygen) .. "s", "MB.Small",
			x + w - 12, y + 5, frac > 0.25 and ui.text or ui.danger, TEXT_ALIGN_RIGHT)
		MilBase.DrawBar(x + 12, y + h - 16, w - 24, 6, frac,
			frac > 0.25 and COL_O2 or ui.danger)

		-- Venting warning for the unprotected
		if vacuum and not sealed then
			local pulse = 160 + 95 * math.sin(RealTime() * 5)
			local text = (lp:MBHasCert("engineer") or lp:IsAdmin())
				and "ATMOSPHERE VENTING — SEAL YOUR SUIT (HOLD [G])"
				or "ATMOSPHERE VENTING — EVACUATE THE AREA"

			draw.SimpleTextOutlined(text, "MB.Med", ScrW() / 2, ScrH() * 0.3,
				Color(220, 80, 80, pulse), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
				1, Color(0, 0, 0, pulse))
		end
	end)

end
