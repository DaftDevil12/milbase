-- Lightweight live diagnostics for separating server stalls from real RTT.

if not SERVER or MilBase._PerformanceMonitorLoaded then return end
MilBase._PerformanceMonitorLoaded = true

MilBase.Performance = MilBase.Performance or {}
local P = MilBase.Performance

P.windowStarted = SysTime()
P.lastFrameAt = SysTime()
P.frameTotal = 0
P.frameCount = 0
P.frameMaximum = 0
P.slow33 = 0
P.slow50 = 0
P.lateFrames = 0
P.majorHitches = 0
P.network = P.network or {}
P.lastWindow = P.lastWindow or nil

local function copyNetwork(source)
	local result = {}
	for key, value in pairs(source or {}) do
		result[key] = {
			count = tonumber(value.count) or 0,
			rawBytes = tonumber(value.rawBytes) or 0,
			compressedBytes = tonumber(value.compressedBytes) or 0,
			recipientBytes = tonumber(value.recipientBytes) or 0,
		}
	end
	return result
end

local function resetWindow(now)
	P.windowStarted = now
	P.frameTotal = 0
	P.frameCount = 0
	P.frameMaximum = 0
	P.slow33 = 0
	P.slow50 = 0
	P.lateFrames = 0
	P.majorHitches = 0
	P.network = {}
end

local function finishWindow(now)
	local duration = math.max(0.001, now - P.windowStarted)
	P.lastWindow = {
		duration = duration,
		frameTotal = P.frameTotal,
		frameCount = P.frameCount,
		frameMaximum = P.frameMaximum,
		slow33 = P.slow33,
		slow50 = P.slow50,
		lateFrames = P.lateFrames,
		majorHitches = P.majorHitches,
		network = copyNetwork(P.network),
	}
	resetWindow(now)
end

function P.RecordNetwork(name, rawBytes, compressedBytes, recipients)
	name = tostring(name or "unknown")
	local item = P.network[name] or {
		count = 0,
		rawBytes = 0,
		compressedBytes = 0,
		recipientBytes = 0,
	}
	P.network[name] = item
	rawBytes = math.max(0, tonumber(rawBytes) or 0)
	compressedBytes = math.max(0, tonumber(compressedBytes) or 0)
	recipients = math.max(0, tonumber(recipients) or 0)
	item.count = item.count + 1
	item.rawBytes = item.rawBytes + rawBytes
	item.compressedBytes = item.compressedBytes + compressedBytes
	item.recipientBytes = item.recipientBytes + compressedBytes * recipients
end

hook.Add("Think", "MilBase.PerformanceMonitor", function()
	local now = SysTime()
	local elapsed = now - (P.lastFrameAt or now)
	P.lastFrameAt = now
	if elapsed > 0 and elapsed < 2 then
		P.frameTotal = P.frameTotal + elapsed
		P.frameCount = P.frameCount + 1
		P.frameMaximum = math.max(P.frameMaximum, elapsed)
		if elapsed >= 0.033 then P.slow33 = P.slow33 + 1 end
		if elapsed >= 0.050 then P.slow50 = P.slow50 + 1 end
		local tickInterval = math.max(0.001, engine.TickInterval())
		if elapsed >= math.max(0.033, tickInterval * 1.5) then
			P.lateFrames = P.lateFrames + 1
		end
		if elapsed >= math.max(0.075, tickInterval * 2.5) then
			P.majorHitches = P.majorHitches + 1
		end
	end
	if now - P.windowStarted >= 60 then finishWindow(now) end
end)

local function currentWindow()
	if P.frameCount >= 10 then
		return {
			duration = math.max(0.001, SysTime() - P.windowStarted),
			frameTotal = P.frameTotal,
			frameCount = P.frameCount,
			frameMaximum = P.frameMaximum,
			slow33 = P.slow33,
			slow50 = P.slow50,
			lateFrames = P.lateFrames,
			majorHitches = P.majorHitches,
			network = copyNetwork(P.network),
		}
	end
	return P.lastWindow or {
		duration = 1,
		frameTotal = 0,
		frameCount = 0,
		frameMaximum = 0,
		slow33 = 0,
		slow50 = 0,
		lateFrames = 0,
		majorHitches = 0,
		network = {},
	}
end

local function convarValue(name)
	local variable = GetConVar(name)
	return variable and variable:GetString() or "unset"
end

local function diagnosticSnapshot()
	local window = currentWindow()
	local averageFrame = window.frameCount > 0
		and window.frameTotal / window.frameCount or 0
	local players = player.GetAll()
	local pingTotal = 0
	for _, ply in ipairs(players) do pingTotal = pingTotal + math.max(0, ply:Ping()) end
	local averagePing = #players > 0 and pingTotal / #players or 0
	local tickInterval = math.max(0.001, engine.TickInterval())
	local galaxy = MilBase.Galaxy or {}
	local living = MilBase.LivingUniverse or {}
	return {
		window = window,
		averageFrame = averageFrame,
		effectiveFPS = averageFrame > 0 and 1 / averageFrame or 0,
		engineTickInterval = tickInterval,
		engineTickrate = 1 / tickInterval,
		players = #players,
		averagePing = averagePing,
		entities = #ents.GetAll(),
		galaxyShips = #ents.FindByClass("mb_galaxy_ship"),
		trafficRecords = table.Count(galaxy.UniverseTraffic or {}),
		livingProfiles = table.Count(living.Vessels or {}),
		livingDirty = table.Count(living.Dirty or {}),
		databaseQueue = MilBase.DB and MilBase.DB.QueueDepth
			and MilBase.DB.QueueDepth() or 0,
	}
end

local function formatKilobytes(bytes)
	return string.format("%.1f KB", math.max(0, tonumber(bytes) or 0) / 1024)
end

local function printSnapshot(snapshot, recipient)
	local window = snapshot.window
	local function emit(message)
		MsgN(message)
		if IsValid(recipient) then
			recipient:PrintMessage(HUD_PRINTCONSOLE, message)
		end
	end
	emit("[MilBase Performance] Last " .. string.format("%.1f", window.duration)
		.. "s: avg frame " .. string.format("%.2f", snapshot.averageFrame * 1000)
		.. "ms, max " .. string.format("%.2f", window.frameMaximum * 1000)
		.. "ms, effective " .. string.format("%.1f", snapshot.effectiveFPS)
		.. " FPS, configured tickrate " .. string.format("%.1f", snapshot.engineTickrate) .. ".")
	emit("[MilBase Performance] Slow frames: >=33ms " .. window.slow33
		.. ", >=50ms " .. window.slow50
		.. ", late for this tickrate " .. (window.lateFrames or 0)
		.. ", major hitches " .. (window.majorHitches or 0)
		.. ". Players " .. snapshot.players
		.. ", average reported ping " .. string.format("%.1f", snapshot.averagePing) .. "ms.")
	emit("[MilBase Performance] Entities " .. snapshot.entities
		.. ", galaxy actors " .. snapshot.galaxyShips
		.. ", virtual traffic " .. snapshot.trafficRecords
		.. ", living profiles " .. snapshot.livingProfiles
		.. ", pending life saves " .. snapshot.livingDirty
		.. ", DB queue " .. snapshot.databaseQueue .. ".")
	for name, item in SortedPairs(window.network or {}) do
		emit("[MilBase Performance] Net " .. name .. ": " .. item.count
			.. " sends, " .. formatKilobytes(item.compressedBytes)
			.. " compressed, " .. formatKilobytes(item.recipientBytes)
			.. " after recipient fan-out.")
	end
	emit("[MilBase Performance] Rates: sv_minrate=" .. convarValue("sv_minrate")
		.. " sv_maxrate=" .. convarValue("sv_maxrate")
		.. " sv_minupdaterate=" .. convarValue("sv_minupdaterate")
		.. " sv_maxupdaterate=" .. convarValue("sv_maxupdaterate") .. ".")
	local lateLimit = math.max(5, math.floor(window.frameCount * 0.01))
	local averageOverBudget = snapshot.averageFrame
		>= math.max(0.033, snapshot.engineTickInterval * 1.25)
	if averageOverBudget
	or (window.lateFrames or 0) >= lateLimit
	or (window.majorHitches or 0) >= 3 then
		emit("[MilBase Performance] Assessment: server frame stalls are contributing to latency.")
	elseif snapshot.averagePing >= 80 then
		emit("[MilBase Performance] Assessment: server frame time is healthy; high ping is more likely host location, routing, Wi-Fi, rate limits or uplink saturation.")
	else
		emit("[MilBase Performance] Assessment: server frame time and reported latency are currently healthy.")
	end
end

concommand.Add("mb_performance_status", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	local snapshot = diagnosticSnapshot()
	printSnapshot(snapshot, ply)
	if IsValid(ply) then
		MilBase.Notify(ply,
			"Performance printed to console: "
				.. string.format("%.1fms frame / %.0fms average ping",
					snapshot.averageFrame * 1000, snapshot.averagePing),
			snapshot.averageFrame >= 0.033 and "warn" or "info")
	end
end)

concommand.Add("mb_performance_reset", function(ply)
	if IsValid(ply) and not ply:IsAdmin() then return end
	resetWindow(SysTime())
	P.lastFrameAt = SysTime()
	P.lastWindow = nil
	if IsValid(ply) then MilBase.Notify(ply, "Performance window reset.", "ok") end
end)
