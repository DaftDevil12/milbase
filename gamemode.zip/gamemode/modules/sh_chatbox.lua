--[[
	Custom chatbox, structured like Helix's:

	One persistent panel (created once, never rebuilt per keypress) sized
	ScrW*0.4 x ScrH*0.375 at the bottom left, with a tab strip, a
	scrollable message history, and a text entry at the bottom. Pressing
	Y activates it (MakePopup + focus), U activates squad mode (/s).
	Messages fade out after a few seconds when the box is closed; while
	open the backdrop blurs and you can scroll the history.

	Everything routes through the normal chat pipeline: commands work,
	colored output (IC/radio/OOC/announcements) is captured via a
	chat.AddText detour, engine messages via ChatText.
]]

local cfg = MilBase.Config

if SERVER then

	util.AddNetworkString("MilBase_ChatSend")

	net.Receive("MilBase_ChatSend", function(_, ply)
		if (ply.mb_lastChat or 0) > CurTime() - 0.4 then return end
		ply.mb_lastChat = CurTime()

		local text = string.Trim(string.sub(net.ReadString(), 1, 200))
		local teamChat = net.ReadBool()
		if text == "" then return end

		-- Team chat key = squad radio unless the player typed a command or
		-- used the global staff-alert prefix.
		local reportPrefix = tostring(cfg.ReportPrefix or "@")
		local isReport = reportPrefix ~= ""
			and string.sub(text, 1, #reportPrefix) == reportPrefix
		if teamChat and string.sub(text, 1, 1) ~= "/" and not isReport then
			text = "/s " .. text
		end

		hook.Run("PlayerSay", ply, text, teamChat)
	end)

	return
end

--------------------------------------------------------------------------
-- Client
--------------------------------------------------------------------------

surface.CreateFont("MB.Chat", { font = "D-DIN", size = 18, weight = 500 })

local LINE_H = 18
local FADE_AT, FADE_OUT = 10, 2 -- seconds visible, seconds fading

local chatbox

-- Sent-message history (persists across chatbox rebuilds); UP/DOWN cycles it.
local sentHistory = {}

-- :code: -> symbol. Limited to glyphs the engine font stack can render
-- (BMP dingbats/arrows); full colour emoji aren't drawable in surface text.
local EMOJI = {
	smile = "☺", sad = "☹", heart = "♥", star = "★", check = "✓", tick = "✓",
	cross = "✗", no = "✗", yes = "✓", warn = "⚠", skull = "☠", dead = "☠",
	fire = "▲", note = "♪", music = "♪", sun = "☀", up = "▲", down = "▼",
	right = "►", left = "◄", arrow = "➤", dot = "•", ok = "✔", cool = "B)",
	salute = "o7",
}

local function expandEmoji(s)
	return (string.gsub(s, ":(%w+):", function(key)
		return EMOJI[string.lower(key)] or (":" .. key .. ":")
	end))
end

-- Which comms tab a message belongs to (by its "[CHANNEL] " prefix). Anything
-- that isn't a comms channel (IC, OOC, squad, engine) is "local".
local function messageTab(parts)
	for _, p in ipairs(parts) do
		if isstring(p) then
			local tag = string.match(p, "^%s*%[(.-)%]")
			if tag then
				local up = string.upper(tag)
				for id, ch in pairs(MilBase.CommChannels or {}) do
					if ch.radio and string.upper(ch.name) == up then return id end
				end
			end
			return "local"
		end
	end
	return "local"
end

local function isVerifiedRoll(parts)
	for _, part in ipairs(parts) do
		if isstring(part) and string.match(part, "^%s*%[VERIFIED ROLL%]") then
			return true
		end
	end
	return false
end

--------------------------------------------------------------------------
-- Word wrapping: chat.AddText args -> lines of {color, text} runs
--------------------------------------------------------------------------

local function wrapParts(parts, maxW)
	surface.SetFont("MB.Chat")

	local lines = {}
	local run = {}
	local width = 0
	local color = Color(235, 235, 235)

	local function pushLine()
		table.insert(lines, run)
		run = {}
		width = 0
	end

	for _, part in ipairs(parts) do
		if istable(part) and part.r and part.g and part.b then
			color = Color(part.r, part.g, part.b)
		elseif isentity(part) then
			local name = IsValid(part) and part:IsPlayer() and part:Nick() or tostring(part)
			table.insert(run, { color = color, text = name })
			width = width + surface.GetTextSize(name)
		elseif isstring(part) then
			part = expandEmoji(part)
			for token in string.gmatch(part, "%S+%s*") do
				local tw = surface.GetTextSize(token)

				if width + tw > maxW and width > 0 then pushLine() end

				while tw > maxW do -- hard-break words longer than the box
					local fit = token
					while #fit > 1 and surface.GetTextSize(fit) > maxW do
						fit = string.sub(fit, 1, #fit - 1)
					end
					table.insert(run, { color = color, text = fit })
					pushLine()
					token = string.sub(token, #fit + 1)
					tw = surface.GetTextSize(token)
				end

				table.insert(run, { color = color, text = token })
				width = width + tw
			end
		end
	end

	if #run > 0 or #lines == 0 then table.insert(lines, run) end
	return lines
end

--------------------------------------------------------------------------
-- The persistent chatbox panel (Helix structure)
--------------------------------------------------------------------------

local function createChatbox()
	if IsValid(chatbox) then chatbox:Remove() end

	local ui = MilBase.UI
	local w = math.floor(ScrW() * 0.4)
	local h = math.floor(ScrH() * 0.375)

	local frame = vgui.Create("EditablePanel")
	chatbox = frame
	frame:SetSize(w, h)
	-- Raised off the bottom edge so it clears the HUD / ammo counter.
	frame:SetPos(math.floor(ScrW() * 0.0125), ScrH() - h - math.floor(ScrH() * 0.15))
	frame.active = false
	frame.activeTab = "all" -- comms tab filter / send target

	frame.Paint = function(self, pw, ph)
		if not self.active then return end

		MilBase.DrawBlur(self, 2)
		surface.SetDrawColor(25, 27, 30, 120)
		surface.DrawRect(0, 0, pw, ph)
	end

	-- Message history
	local history = vgui.Create("DScrollPanel", frame)
	history:SetPos(4, 30)
	history:SetSize(w - 8, h - 30 - 36)
	frame.history = history

	local vbar = history:GetVBar()
	vbar:SetWide(6)
	vbar.Paint = function() end
	vbar.btnUp.Paint = function() end
	vbar.btnDown.Paint = function() end
	vbar.btnGrip.Paint = function(_, gw, gh)
		surface.SetDrawColor(255, 255, 255, frame.active and 35 or 0)
		surface.DrawRect(0, 0, gw, gh)
	end

	-- DScrollPanel updates its canvas size one layout pass after a new docked
	-- child is added. Scrolling immediately can therefore use the previous
	-- CanvasSize and leave the newest message below the visible area. Run the
	-- scroll after layout and confirm it once more on the following frame.
	function frame:ScrollToLatest(child)
		self.chatScrollGeneration = (self.chatScrollGeneration or 0) + 1
		local generation = self.chatScrollGeneration

		local function scrollNow()
			if not IsValid(frame) or generation ~= frame.chatScrollGeneration
			or not IsValid(history) then return end

			local canvas = history:GetCanvas()
			if IsValid(canvas) then canvas:InvalidateLayout(true) end
			history:InvalidateLayout(true)
			history:PerformLayout()

			if IsValid(child) and history.ScrollToChild then
				history:ScrollToChild(child)
			end

			local bar = history:GetVBar()
			if IsValid(bar) then bar:SetScroll(bar.CanvasSize or 0) end
		end

		timer.Simple(0, scrollNow)
		timer.Simple(0.05, scrollNow)
	end

	-- Entry (hidden until the box is active)
	local entry = vgui.Create("DTextEntry", frame)
	entry:SetPos(4, h - 32)
	entry:SetSize(w - 8, 28)
	entry:SetFont("MB.Chat")
	entry:SetMaximumCharCount(200)
	entry:SetTabbingDisabled(true)
	entry:SetVisible(false)
	frame.entry = entry

	entry.Paint = function(self, pw, ph)
		MilBase.DrawPanelBF2(0, 0, pw, ph, {
			cut = 6,
			color = Color(0, 0, 0, 150),
		})

		local label, col
		if frame.teamChat then
			label, col = "SQUAD", Color(120, 190, 120)
		elseif frame.activeCmd then
			local ch = MilBase.CommChannels[frame.activeTab]
			label = ch and string.upper(ch.name) or frame.activeTab
			col = ch and ch.color or ui.accent
		end
		if label then
			draw.SimpleText(label, "MB.Tiny", pw - 8, ph / 2, col,
				TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		self:DrawTextEntryText(ui.text, ui.dim, ui.text)
	end

	-- Comms tab strip (built from the channels you can speak on).
	local tabStrip = vgui.Create("DPanel", frame)
	frame.tabStrip = tabStrip
	tabStrip:SetPos(0, 0)
	tabStrip:SetSize(w, 26)
	tabStrip:SetVisible(false)
	tabStrip.Paint = function(_, pw, ph)
		surface.SetDrawColor(0, 0, 0, 110)
		surface.DrawRect(0, 0, pw, ph)
	end

	function frame:ApplyFilter()
		-- Tabs organise the full history while chat is open. Once it closes,
		-- restore every tab so new messages remain visible as a live HUD feed.
		local filter = self.active and self.activeTab or "all"
		for _, msg in ipairs(history:GetCanvas():GetChildren()) do
			msg:SetVisible(filter == "all" or msg.tab == filter)
		end
		self:ScrollToLatest()
	end

	function frame:BuildTabs()
		tabStrip:Clear()

		local tabs = { { id = "all", label = "ALL", color = ui.text } }
		local lp = LocalPlayer()
		if IsValid(lp) then
			for _, id in ipairs(MilBase.CommOrder or {}) do
				local ch = MilBase.CommChannels[id]
				if ch.radio and ch.canSpeak and ch.canSpeak(lp) then
					tabs[#tabs + 1] = {
						id = id,
						label = string.upper(ch.cmds and ch.cmds[1] or ch.name),
						color = ch.color,
						cmd = ch.cmds and ch.cmds[1],
					}
				end
			end
		end

		-- Fall back to ALL if the active tab is no longer available.
		local have = false
		for _, t in ipairs(tabs) do if t.id == self.activeTab then have = true end end
		if not have then self.activeTab, self.activeCmd = "all", nil end

		surface.SetFont("MB.Tiny")
		local x = 0
		for _, t in ipairs(tabs) do
			local bw = surface.GetTextSize(t.label) + 20
			local btn = vgui.Create("DButton", tabStrip)
			btn:SetPos(x, 0) btn:SetSize(bw, 26) btn:SetText("")
			btn.Paint = function(_, pw, ph)
				local sel = frame.activeTab == t.id
				if sel then
					surface.SetDrawColor(255, 255, 255, 22)
					surface.DrawRect(0, 0, pw, ph)
				end
				draw.SimpleText(t.label, "MB.Tiny", pw / 2, ph / 2,
					sel and t.color or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				if sel then
					surface.SetDrawColor(t.color)
					surface.DrawRect(0, ph - 2, pw, 2)
				end
			end
			btn.DoClick = function()
				frame.activeTab, frame.activeCmd = t.id, t.cmd
				frame:ApplyFilter()
				if frame.active and IsValid(frame.entry) then frame.entry:RequestFocus() end
			end
			x = x + bw
		end
	end

	local function send()
		local text = string.Trim(entry:GetValue() or "")
		if text ~= "" then
			-- On a comms tab, route the message through that channel's command.
			if frame.activeCmd and not frame.teamChat and string.sub(text, 1, 1) ~= "/" then
				text = "/" .. frame.activeCmd .. " " .. text
			end

			net.Start("MilBase_ChatSend")
				net.WriteString(string.sub(text, 1, 200))
				net.WriteBool(frame.teamChat or false)
			net.SendToServer()

			-- Remember it for arrow-key recall (no consecutive dupes).
			if sentHistory[#sentHistory] ~= text then
				sentHistory[#sentHistory + 1] = text
				while #sentHistory > 30 do table.remove(sentHistory, 1) end
			end
		end
		frame:SetActive(false)
	end

	-- Cycle the entry through previously-sent messages (UP/DOWN).
	local function recall(dir)
		if #sentHistory == 0 then return end
		frame.histIndex = math.Clamp((frame.histIndex or #sentHistory + 1) + dir,
			1, #sentHistory + 1)

		local msg = sentHistory[frame.histIndex] or ""
		frame.entry:SetText(msg)
		frame.entry:SetCaretPos(#msg)
	end

	entry.OnKeyCodeTyped = function(self, code)
		if code == KEY_ENTER or code == KEY_PAD_ENTER then
			send()
			return true
		elseif code == KEY_ESCAPE then
			frame:SetActive(false)
			gui.HideGameUI()
			return true
		elseif code == KEY_UP then
			recall(-1)
			return true
		elseif code == KEY_DOWN then
			recall(1)
			return true
		end
	end

	function frame:SetActive(active, teamChat)
		self.active = active
		self.teamChat = teamChat or false

		if active then
			self:BuildTabs() -- refresh in case rank / joint ops changed
			self.tabStrip:SetVisible(true)

			self:MakePopup()
			self:SetMouseInputEnabled(true)
			self:SetKeyboardInputEnabled(true)

			self.histIndex = nil -- ↑ starts from the newest sent message

			entry:SetVisible(true)
			entry:SetText("")
			entry:RequestFocus()

			self:ScrollToLatest()
		else
			self.tabStrip:SetVisible(false)
			entry:SetVisible(false)
			entry:SetText("")

			self:SetMouseInputEnabled(false)
			self:SetKeyboardInputEnabled(false)
			self:KillFocus()
		end

		self:ApplyFilter()
	end

	function frame:AddMessage(parts)
		local msg = vgui.Create("DPanel", history)
		msg:Dock(TOP)
		msg:DockMargin(4, 0, 8, 2)
		msg.created = CurTime()
		msg.tab = messageTab(parts) -- which comms tab this belongs to
		msg.verifiedRoll = isVerifiedRoll(parts)
		msg.runs = wrapParts(parts, history:GetWide() - (msg.verifiedRoll and 42 or 26))
		msg:SetTall(#msg.runs * LINE_H + (msg.verifiedRoll and 10 or 2))

		-- A selected tab filters only the open history. The closed HUD feed
		-- always shows fresh messages, including the sender's own reply.
		if self.active and self.activeTab ~= "all" and msg.tab ~= self.activeTab then
			msg:SetVisible(false)
		end

		msg.Paint = function(pnl, pw, ph)
			local alpha = 255
			if not frame.active then
				local age = CurTime() - pnl.created
				if age > FADE_AT + FADE_OUT then return end
				if age > FADE_AT then
					alpha = 255 * (1 - (age - FADE_AT) / FADE_OUT)
				end
			end

			local textX, textY = 0, 0
			if pnl.verifiedRoll then
				local fade = alpha / 255
				surface.SetDrawColor(255, 198, 60, math.floor(34 * fade))
				surface.DrawRect(0, 0, pw, ph)
				surface.SetDrawColor(255, 198, 60, math.floor(220 * fade))
				surface.DrawRect(0, 0, 3, ph)
				surface.DrawOutlinedRect(0, 0, pw, ph)
				textX, textY = 9, 4
			end

			surface.SetFont("MB.Chat")
			for li, line in ipairs(pnl.runs) do
				local lx = textX
				for _, run in ipairs(line) do
					draw.SimpleTextOutlined(run.text, "MB.Chat", lx, textY + (li - 1) * LINE_H,
						Color(run.color.r, run.color.g, run.color.b, alpha),
						TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, alpha * 0.8))
					lx = lx + surface.GetTextSize(run.text)
				end
			end
		end

		-- Trim old messages.
		local kids = history:GetCanvas():GetChildren()
		if #kids > 120 then kids[1]:Remove() end

		-- Stick to the newest entry even while the chatbox is already open.
		self:ScrollToLatest(msg)

		surface.PlaySound(msg.verifiedRoll and "buttons/button14.wav" or "common/talk.wav")
	end

	frame:SetActive(false)
end

hook.Add("InitPostEntity", "MilBase.Chatbox", createChatbox)
hook.Add("OnScreenSizeChanged", "MilBase.Chatbox", createChatbox)

-- Autorefresh mid-session: rebuild immediately.
if IsValid(LocalPlayer()) then
	createChatbox()
end

--------------------------------------------------------------------------
-- Capture everything that would go to the default chat
--------------------------------------------------------------------------

local origAddText = chat.AddText

function chat.AddText(...)
	origAddText(...) -- keeps console logging

	if not IsValid(chatbox) then createChatbox() end
	if IsValid(chatbox) then chatbox:AddMessage({ ... }) end
end

function chat.GetChatBoxPos()
	if IsValid(chatbox) then return chatbox:GetPos() end
	return math.floor(ScrW() * 0.0125), math.floor(ScrH() * 0.5625)
end

function chat.GetChatBoxSize()
	if IsValid(chatbox) then return chatbox:GetSize() end
	return math.floor(ScrW() * 0.4), math.floor(ScrH() * 0.375)
end

-- Engine messages: connect/disconnect/name changes, plus server
-- PrintMessage(HUD_PRINTTALK) text from admin addons.
hook.Add("ChatText", "MilBase.Chatbox", function(_, _, text, messageType)
	if not IsValid(chatbox) then createChatbox() end
	if IsValid(chatbox) then
		chatbox:AddMessage({ messageType == "chat" and Color(235, 235, 235)
			or Color(150, 155, 165), text })
	end
	return true
end)

hook.Add("HUDShouldDraw", "MilBase.HideDefaultChat", function(name)
	if name == "CHudChat" then return false end
end)

--------------------------------------------------------------------------
-- Open on the chat binds
--------------------------------------------------------------------------

hook.Add("PlayerBindPress", "MilBase.ChatOpen", function(_, bind, pressed)
	if not pressed then return end

	if string.find(bind, "messagemode2", 1, true) then
		if not IsValid(chatbox) then createChatbox() end
		chatbox:SetActive(true, true)
		return true
	elseif string.find(bind, "messagemode", 1, true) then
		if not IsValid(chatbox) then createChatbox() end
		chatbox:SetActive(true, false)
		return true
	end
end)
