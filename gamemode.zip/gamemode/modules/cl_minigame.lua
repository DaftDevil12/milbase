--[[
	Shared "type the code" minigame.

	MilBase.OpenCodeMinigame({
		title, subtitle,          -- header text
		lines = { "...", ... },   -- code lines to type (or omit for random)
		color,                    -- accent color
		valid  = function() ... end,   -- return false to auto-abort
		onSuccess = function() ... end,-- all lines typed
	})

	Used by the engineering terminal repair and the LVS slicer. Type each
	displayed line exactly; correct characters go bright, mistakes go red,
	and finishing a line advances to the next.
]]

if SERVER then return end

surface.CreateFont("MB.Mono",      { font = "Consolas", size = 21, weight = 500 })
surface.CreateFont("MB.MonoSmall", { font = "Consolas", size = 16, weight = 400 })

local CODE_POOL = {
	"sudo override --core",
	"decrypt seed 0x4F2A",
	"bypass firewall.node",
	"inject payload::run",
	"mount /dev/relay0",
	"kill -9 lockdaemon",
	"set flags 0b1011",
	"route pkt gateway",
	"exec reboot --force",
	"unlock sector 7",
	"patch memblock 1F",
	"commit and sync",
	"scan ports 22 80",
	"grant access root",
	"purge cache --all",
	"spoof mac addr",
	"trace uplink node",
	"flush auth token",
}

function MilBase.GenCodeLines(n)
	local pool = table.Copy(CODE_POOL)
	local out = {}
	for _ = 1, math.min(n or 4, #pool) do
		out[#out + 1] = table.remove(pool, math.random(#pool))
	end
	return out
end

local activeGame

function MilBase.OpenCodeMinigame(opts)
	if IsValid(activeGame) then activeGame:Remove() end

	local ui = MilBase.UI
	local lines = opts.lines or MilBase.GenCodeLines(4)
	local accent = opts.color or ui.accent
	local index = 1

	local lineH, topY = 27, 64

	-- DFrame handles popup keyboard focus reliably (unlike a bare DPanel).
	local frame = vgui.Create("DFrame")
	activeGame = frame
	frame:SetSize(580, topY + #lines * lineH + 40)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(true)
	frame.OnRemove = function() if activeGame == frame then activeGame = nil end end

	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, accent, 12)

		draw.SimpleText(opts.title or "TERMINAL ACCESS", "MB.Tab", 16, 10, ui.text)
		draw.SimpleText(opts.subtitle or "Type the sequence to continue.",
			"MB.Tiny", 16, 40, ui.dim)

		-- Completed and upcoming lines (the current line is the entry below).
		surface.SetFont("MB.Mono")
		for i, line in ipairs(lines) do
			if i ~= index then
				draw.SimpleText((i < index and "> " or "  ") .. line, "MB.Mono",
					24, topY + (i - 1) * lineH,
					i < index and Color(120, 200, 140) or Color(72, 77, 82))
			end
		end

		draw.SimpleText("LINE " .. math.min(index, #lines) .. " / " .. #lines
			.. "   •   BACKSPACE to correct   •   ESC to abort", "MB.Tiny",
			16, h - 24, ui.faint)
	end

	-- A real, visible, focused text entry (custom-painted for the colour).
	local entry = vgui.Create("DTextEntry", frame)
	entry:SetFont("MB.Mono")
	entry:SetAllowNonAsciiCharacters(true)
	entry:SetPaintBackground(false)

	local function placeEntry()
		entry:SetPos(24, topY + (index - 1) * lineH)
		entry:SetSize(frame:GetWide() - 48, lineH)
	end
	placeEntry()

	entry.Paint = function(self, w, h)
		local target = lines[index] or ""
		local typed = self:GetValue()

		surface.SetFont("MB.Mono")
		surface.SetTextColor(accent)
		surface.SetTextPos(0, 3)
		surface.DrawText("> ")

		local cx = surface.GetTextSize("> ")
		for ci = 1, #target do
			local ch = target:sub(ci, ci)
			local col = Color(95, 100, 106)
			if ci <= #typed then
				col = (typed:sub(ci, ci) == ch) and Color(235, 238, 242) or Color(220, 80, 70)
			end
			surface.SetTextColor(col)
			surface.SetTextPos(cx, 3)
			surface.DrawText(ch)
			cx = cx + surface.GetTextSize(ch)
		end

		if RealTime() % 1 < 0.5 then
			local caretX = surface.GetTextSize("> " .. target:sub(1, math.min(#typed, #target)))
			surface.SetDrawColor(accent)
			surface.DrawRect(caretX, 3, 2, 20)
		end
	end

	entry:RequestFocus()

	-- Poll the typed value each frame (robust - doesn't rely on OnChange).
	frame.Think = function(self)
		if not entry:HasFocus() then entry:RequestFocus() end

		local target = lines[index]
		if target and entry:GetValue() == target then
			index = index + 1
			entry:SetText("")
			surface.PlaySound("buttons/button16.wav")
			if index > #lines then
				if opts.onSuccess then opts.onSuccess() end
				self:Remove()
				return
			end
			placeEntry()
		end

		if opts.valid and not opts.valid() then self:Remove() return end
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() end
	end

	return frame
end

--------------------------------------------------------------------------
-- Themed repair minigames (used by the SWU ship-system consoles). Each takes
-- the same { title, subtitle, color, valid, onSuccess } contract as
-- OpenCodeMinigame, so a caller can pick a different one per console.
--------------------------------------------------------------------------

local function baseGameFrame(w, h)
	if IsValid(activeGame) then activeGame:Remove() end
	local frame = vgui.Create("DFrame")
	activeGame = frame
	frame:SetSize(w, h)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame.OnRemove = function() if activeGame == frame then activeGame = nil end end
	return frame
end

-- REWIRE: connect each left port to the right port of the matching colour.
function MilBase.OpenWireMinigame(opts)
	local ui = MilBase.UI
	local accent = opts.color or ui.accent
	local n = math.Clamp(opts.wires or 5, 2, 7)

	local palette = {
		Color(220, 80, 70), Color(90, 170, 240), Color(150, 205, 125),
		Color(240, 200, 70), Color(200, 120, 220), Color(90, 210, 205),
		Color(240, 150, 80),
	}
	-- right port i carries colour rightIds[i]; match when it equals the held left id.
	local rightIds = {}
	for i = 1, n do rightIds[i] = i end
	for i = n, 2, -1 do
		local j = math.random(i)
		rightIds[i], rightIds[j] = rightIds[j], rightIds[i]
	end

	local W, H = 520, 96 + n * 50
	local frame = baseGameFrame(W, H)

	local topY, rowH, R = 84, 50, 14
	local leftX, rightX = 64, W - 64
	local function nodePos(side, i)
		return (side == "L" and leftX or rightX), topY + (i - 0.5) * rowH
	end

	local connected, rightUsed, selLeft, flash = {}, {}, nil, 0

	local function hit(mx, my)
		for i = 1, n do
			local lx, ly = nodePos("L", i)
			if math.abs(mx - lx) <= R + 6 and math.abs(my - ly) <= R + 6 then return "L", i end
			local rx, ry = nodePos("R", i)
			if math.abs(mx - rx) <= R + 6 and math.abs(my - ry) <= R + 6 then return "R", i end
		end
	end

	frame.OnMousePressed = function(self)
		local mx, my = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
		local side, i = hit(mx, my)
		if not side then return end

		if side == "L" then
			if connected[i] then return end
			selLeft = i
			surface.PlaySound("buttons/button16.wav")
		elseif selLeft and not rightUsed[i] then
			if rightIds[i] == selLeft then
				connected[selLeft], rightUsed[i], selLeft = i, true, nil
				surface.PlaySound("buttons/button17.wav")
				if table.Count(connected) >= n then
					if opts.onSuccess then opts.onSuccess() end
					self:Remove()
				end
			else
				flash, selLeft = RealTime() + 0.3, nil
				surface.PlaySound("buttons/combine_button_locked.wav")
			end
		end
	end

	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, RealTime() < flash and ui.danger or accent, 12)
		draw.SimpleText(opts.title or "REWIRE CONDUIT", "MB.Tab", 16, 10, ui.text)
		draw.SimpleText(opts.subtitle or "Connect each line to its matching colour.",
			"MB.Tiny", 16, 40, ui.dim)

		for li, ri in pairs(connected) do
			local lx, ly = nodePos("L", li)
			local rx, ry = nodePos("R", ri)
			surface.SetDrawColor(palette[li])
			for o = -1, 1 do surface.DrawLine(lx, ly + o, rx, ry + o) end
		end

		if selLeft then
			local lx, ly = nodePos("L", selLeft)
			local mx, my = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
			local c = palette[selLeft]
			surface.SetDrawColor(c.r, c.g, c.b, 180)
			surface.DrawLine(lx, ly, mx, my)
		end

		for i = 1, n do
			local lx, ly = nodePos("L", i)
			draw.RoundedBox(4, lx - R, ly - R, R * 2, R * 2, palette[i])
			if selLeft == i then
				surface.SetDrawColor(255, 255, 255, 230)
				surface.DrawOutlinedRect(lx - R - 2, ly - R - 2, R * 2 + 4, R * 2 + 4)
			end

			local rx, ry = nodePos("R", i)
			local rc = palette[rightIds[i]]
			draw.RoundedBox(4, rx - R, ry - R, R * 2, R * 2,
				rightUsed[i] and rc or Color(rc.r, rc.g, rc.b, 95))
		end

		draw.SimpleText(table.Count(connected) .. " / " .. n .. " LINES  •  ESC to abort",
			"MB.Tiny", 16, h - 24, ui.faint)
	end

	frame.Think = function(self)
		if opts.valid and not opts.valid() then self:Remove() return end
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() end
	end
	return frame
end

-- REACTOR: click to lock the core marker while it sits inside the safe band.
function MilBase.OpenReactorMinigame(opts)
	local ui = MilBase.UI
	local accent = opts.color or ui.accent
	local need = math.Clamp(opts.locks or 4, 1, 8)

	local W, H = 540, 235
	local frame = baseGameFrame(W, H)

	local barX, barW, barY, barH = 40, W - 80, 116, 34
	local hits, speed, gz0, gzw, flash = 0, 1, 0, 0.2, 0

	local function newZone()
		gzw = math.max(0.08, math.Rand(0.20, 0.28) - hits * 0.02)
		gz0 = math.Rand(0.04, 0.96 - gzw)
		speed = 0.9 + hits * 0.14
	end
	newZone()

	local function markerFrac() return 0.5 + 0.5 * math.sin(RealTime() * speed * 2.2) end

	frame.OnMousePressed = function(self)
		local m = markerFrac()
		if m >= gz0 and m <= gz0 + gzw then
			hits = hits + 1
			surface.PlaySound("buttons/button17.wav")
			if hits >= need then
				if opts.onSuccess then opts.onSuccess() end
				self:Remove()
				return
			end
			newZone()
		else
			hits, flash = math.max(0, hits - 1), RealTime() + 0.35
			surface.PlaySound("buttons/combine_button_locked.wav")
		end
	end

	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, RealTime() < flash and ui.danger or accent, 12)
		draw.SimpleText(opts.title or "REACTOR STABILISATION", "MB.Tab", 16, 10, ui.text)
		draw.SimpleText(opts.subtitle or "Click when the core marker is in the safe band.",
			"MB.Tiny", 16, 40, ui.dim)

		surface.SetDrawColor(0, 0, 0, 190)
		surface.DrawRect(barX, barY, barW, barH)
		if RealTime() < flash then
			surface.SetDrawColor(220, 80, 70, 70)
			surface.DrawRect(barX, barY, barW, barH)
		end
		surface.SetDrawColor(90, 200, 120, 210)
		surface.DrawRect(barX + gz0 * barW, barY, gzw * barW, barH)

		local mx = barX + markerFrac() * barW
		surface.SetDrawColor(255, 255, 255)
		surface.DrawRect(mx - 2, barY - 8, 4, barH + 16)
		surface.SetDrawColor(255, 255, 255, 45)
		surface.DrawOutlinedRect(barX, barY, barW, barH)

		for i = 1, need do
			surface.SetDrawColor(i <= hits and accent or Color(70, 74, 80))
			surface.DrawRect(barX + (i - 1) * 22, barY + barH + 18, 16, 8)
		end
		draw.SimpleText("STABILISED  " .. hits .. " / " .. need, "MB.Tiny",
			barX, barY + barH + 34, ui.faint)
		draw.SimpleText("CLICK to vent   •   ESC to abort", "MB.Tiny", 16, h - 24, ui.faint)
	end

	frame.Think = function(self)
		if opts.valid and not opts.valid() then self:Remove() return end
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() end
	end
	return frame
end

-- SEQUENCE: watch the alignment pattern flash, then repeat it on the pads.
function MilBase.OpenSequenceMinigame(opts)
	local ui = MilBase.UI
	local accent = opts.color or ui.accent
	local len = math.Clamp(opts.length or 5, 3, 8)

	local seq = {}
	for i = 1, len do seq[i] = math.random(4) end

	local W, H = 440, 330
	local frame = baseGameFrame(W, H)

	local padColors = {
		Color(220, 80, 70), Color(90, 170, 240),
		Color(150, 205, 125), Color(240, 200, 70),
	}
	local cell, gap, gx, gy = 112, 12, 102, 64
	local function padRect(i)
		local c, r = (i - 1) % 2, math.floor((i - 1) / 2)
		return gx + c * (cell + gap), gy + r * (cell + gap), cell, cell
	end

	local phase, showIdx, nextShow, lit, litUntil, inputIdx =
		"show", 1, RealTime() + 0.7, 0, 0, 1

	frame.Think = function(self)
		if opts.valid and not opts.valid() then self:Remove() return end
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() return end

		if phase == "show" and RealTime() >= nextShow then
			if showIdx > #seq then
				phase, lit = "input", 0
			else
				lit, litUntil = seq[showIdx], RealTime() + 0.4
				nextShow, showIdx = RealTime() + 0.62, showIdx + 1
				surface.PlaySound("buttons/button17.wav")
			end
		end
		if RealTime() > litUntil and phase ~= "show" then lit = 0 end
	end

	frame.OnMousePressed = function(self)
		if phase ~= "input" then return end
		local mx, my = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
		for i = 1, 4 do
			local x, y, cw, ch = padRect(i)
			if mx >= x and mx <= x + cw and my >= y and my <= y + ch then
				lit, litUntil = i, RealTime() + 0.25
				if seq[inputIdx] == i then
					inputIdx = inputIdx + 1
					surface.PlaySound("buttons/button17.wav")
					if inputIdx > #seq then
						if opts.onSuccess then opts.onSuccess() end
						self:Remove()
					end
				else
					surface.PlaySound("buttons/combine_button_locked.wav")
					phase, showIdx, inputIdx, nextShow = "show", 1, 1, RealTime() + 0.5
				end
				break
			end
		end
	end

	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, accent, 12)
		draw.SimpleText(opts.title or "ALIGNMENT SEQUENCE", "MB.Tab", 16, 10, ui.text)
		draw.SimpleText(phase == "show" and "Memorise the alignment sequence..."
			or (opts.subtitle or "Repeat the sequence."), "MB.Tiny", 16, 40, ui.dim)

		for i = 1, 4 do
			local x, y, cw, ch = padRect(i)
			local c = padColors[i]
			local on = (lit == i and RealTime() < litUntil)
			draw.RoundedBox(8, x, y, cw, ch, Color(c.r, c.g, c.b, on and 255 or 60))
			if on then
				surface.SetDrawColor(255, 255, 255, 230)
				surface.DrawOutlinedRect(x, y, cw, ch, 2)
			end
		end

		draw.SimpleText(phase == "input" and ("STEP " .. inputIdx .. " / " .. #seq) or "WATCH",
			"MB.Tiny", 16, h - 24, ui.faint)
	end
	return frame
end
