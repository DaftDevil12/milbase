if not SERVER or MilBase.NavalOperationsServerLoaded then return end
MilBase.NavalOperationsServerLoaded = true

local cfg = MilBase.Config
local naval = cfg.NavalOperations or {}
if naval.Enabled == false then return end

local N = MilBase.Naval
local G = MilBase.Galaxy
local NET_STATE = "MilBase_Naval_State"
local NET_POWER_OPEN = "MilBase_Naval_PowerOpen"
local NET_POWER_APPLY = "MilBase_Naval_PowerApply"
local NET_POWER_CLOSE = "MilBase_Naval_PowerClose"
local NET_CONSOLE_OPEN = "MilBase_Naval_ConsoleOpen"
local NET_CONSOLE_ACTION = "MilBase_Naval_ConsoleAction"
local SCREEN_TABLE = "frontier_naval_surface_screens"
local POWER_CONSOLE_TABLE = "frontier_naval_power_consoles"
local ZONE_TABLE = "frontier_naval_restricted_zones"
util.AddNetworkString(NET_STATE)
util.AddNetworkString(NET_POWER_OPEN)
util.AddNetworkString(NET_POWER_APPLY)
util.AddNetworkString(NET_POWER_CLOSE)
util.AddNetworkString(NET_CONSOLE_OPEN)
util.AddNetworkString(NET_CONSOLE_ACTION)

local function playerName(ply)
	if not IsValid(ply) then return "SHIP COMPUTER" end
	return ply.MBName and ply:MBName() or ply:Nick()
end

local function mapKey()
	return string.lower(game.GetMap() or "unknown")
end

local function copyNumbers(source, defaults, maximums)
	local out = {}
	for key, fallback in pairs(defaults or {}) do
		out[key] = math.Clamp(math.floor(tonumber(source and source[key]) or fallback or 0),
			0, math.max(0, tonumber(maximums and maximums[key]) or 999999999))
	end
	return out
end

N.State = N.State or {
	resources = copyNumbers(nil, naval.InitialResources, naval.ResourceMaximums),
	power = copyNumbers(nil, naval.InitialPower, {}),
	watches = {},
	logs = {},
	incidents = {},
	rescues = {},
	squadrons = {},
	ewMode = "passive",
	transponderMode = "active",
	fleetOrder = "independent operations",
	trafficNotice = "NORMAL TRANSIT",
	restrictedZones = {},
	interceptTarget = 0,
	revision = 1,
}
N.State.restrictedZones = N.State.restrictedZones or {}
N.State.transponderMode = N.State.transponderMode or "active"
N.State.interceptTarget = tonumber(N.State.interceptTarget) or 0
for id, definition in pairs(naval.Squadrons or {}) do
	N.State.squadrons[id] = N.State.squadrons[id] or {
		id = id,
		name = definition.name or id,
		craft = definition.craft or "fighter",
		total = tonumber(definition.total) or 0,
		ready = tonumber(definition.total) or 0,
		order = "standby",
		status = "READY",
	}
	local squadron = N.State.squadrons[id]
	squadron.id = id
	squadron.name = squadron.name or definition.name or id
	squadron.craft = squadron.craft or definition.craft or "fighter"
	squadron.total = math.max(0,
		tonumber(squadron.total) or tonumber(definition.total) or 0)
	squadron.ready = math.Clamp(tonumber(squadron.ready) or squadron.total,
		0, squadron.total)
	squadron.order = squadron.order or "standby"
	squadron.status = squadron.status or "READY"
	squadron.roe = squadron.roe or "confirmed_hostiles"
	squadron.formation = squadron.formation or "vee"
	squadron.pilots = math.max(0, tonumber(squadron.pilots) or squadron.total)
	squadron.condition = math.Clamp(tonumber(squadron.condition) or 100, 0, 100)
	squadron.fuel = math.Clamp(tonumber(squadron.fuel) or 100, 0, 100)
	squadron.ammunition = math.Clamp(tonumber(squadron.ammunition) or 100, 0, 100)
	squadron.morale = math.Clamp(tonumber(squadron.morale) or 100, 0, 100)
	squadron.experience = math.max(0, tonumber(squadron.experience) or 0)
	squadron.kills = math.max(0, tonumber(squadron.kills) or 0)
	squadron.losses = math.max(0, tonumber(squadron.losses) or 0)
	squadron.deployedCraft = math.max(0, tonumber(squadron.deployedCraft) or 0)
end

local dirtyAt
local function touch()
	N.State.revision = (tonumber(N.State.revision) or 0) + 1
	dirtyAt = CurTime() + math.max(0.1, tonumber(naval.StateSaveDelay) or 2)
end

local function sqlNumber(key)
	return math.floor(tonumber(N.State.resources[key]) or 0)
end

function N.SaveState()
	if not MilBase.DB then return end
	dirtyAt = nil
	local p = N.State.power
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_naval_state "
		.. "(map_key,funding,supplies,fuel,munitions,medical,repair,"
		.. "p_engines,p_manoeuvring,p_shields,p_weapons,p_sensors,p_comms,p_life,ew_mode,fleet_order,updated_at) "
		.. "VALUES (%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s,%d)",
		MilBase.SQLStr(mapKey()),
		sqlNumber("funding"), sqlNumber("supplies"), sqlNumber("fuel"),
		sqlNumber("munitions"), sqlNumber("medical"), sqlNumber("repair"),
		math.floor(p.engines or 0), math.floor(p.maneuvering or 0),
		math.floor(p.shields or 0), math.floor(p.weapons or 0),
		math.floor(p.sensors or 0), math.floor(p.communications or 0),
		math.floor(p.life_support or 0),
		MilBase.SQLStr(N.State.ewMode or "passive"),
		MilBase.SQLStr(N.State.fleetOrder or "independent operations"),
		os.time()
	))
	for id, squadron in pairs(N.State.squadrons or {}) do
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_naval_squadrons "
			.. "(map_key,squadron_id,squadron_name,craft,total,ready,orders,status,roe,"
			.. "target_name,condition_pct,fuel_pct,ammo_pct,morale_pct,experience,kills,losses,"
			.. "mission_started,updated_at) VALUES "
			.. "(%s,%s,%s,%s,%d,%d,%s,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d)",
			MilBase.SQLStr(mapKey()), MilBase.SQLStr(id),
			MilBase.SQLStr(squadron.name or id),
			MilBase.SQLStr(squadron.craft or "fighter"),
			math.max(0, math.floor(tonumber(squadron.total) or 0)),
			math.max(0, math.floor(tonumber(squadron.ready) or 0)),
			MilBase.SQLStr(squadron.order or "standby"),
			MilBase.SQLStr(squadron.status or "READY"),
			MilBase.SQLStr(squadron.roe or "confirmed_hostiles"),
			MilBase.SQLStr(squadron.targetName or ""),
			math.Clamp(math.floor(tonumber(squadron.condition) or 100), 0, 100),
			math.Clamp(math.floor(tonumber(squadron.fuel) or 100), 0, 100),
			math.Clamp(math.floor(tonumber(squadron.ammunition) or 100), 0, 100),
			math.Clamp(math.floor(tonumber(squadron.morale) or 100), 0, 100),
			math.max(0, math.floor(tonumber(squadron.experience) or 0)),
			math.max(0, math.floor(tonumber(squadron.kills) or 0)),
			math.max(0, math.floor(tonumber(squadron.losses) or 0)),
			math.max(0, math.floor(tonumber(squadron.missionStarted) or 0)),
			os.time()
		))
	end
end

local function initDatabase()
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_naval_state ("
		.. "map_key VARCHAR(96) PRIMARY KEY, funding INTEGER NOT NULL DEFAULT 0,"
		.. "supplies INTEGER NOT NULL DEFAULT 0, fuel INTEGER NOT NULL DEFAULT 0,"
		.. "munitions INTEGER NOT NULL DEFAULT 0, medical INTEGER NOT NULL DEFAULT 0,"
		.. "repair INTEGER NOT NULL DEFAULT 0, p_engines INTEGER NOT NULL DEFAULT 18,"
		.. "p_manoeuvring INTEGER NOT NULL DEFAULT 10, p_shields INTEGER NOT NULL DEFAULT 18,"
		.. "p_weapons INTEGER NOT NULL DEFAULT 16, p_sensors INTEGER NOT NULL DEFAULT 14,"
		.. "p_comms INTEGER NOT NULL DEFAULT 8, p_life INTEGER NOT NULL DEFAULT 16,"
		.. "ew_mode VARCHAR(24) NOT NULL DEFAULT 'passive',"
		.. "fleet_order VARCHAR(96) NOT NULL DEFAULT 'independent operations',"
		.. "updated_at INTEGER NOT NULL DEFAULT 0)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_naval_log ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map_key VARCHAR(96) NOT NULL,"
		.. "created_at INTEGER NOT NULL, category VARCHAR(32) NOT NULL,"
		.. "title VARCHAR(128) NOT NULL, detail TEXT NOT NULL, actor VARCHAR(96) NOT NULL)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. SCREEN_TABLE .. " ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map_key VARCHAR(96) NOT NULL,"
		.. "pos_x DOUBLE NOT NULL, pos_y DOUBLE NOT NULL, pos_z DOUBLE NOT NULL,"
		.. "ang_p DOUBLE NOT NULL, ang_y DOUBLE NOT NULL, ang_r DOUBLE NOT NULL,"
		.. "screen_scale DOUBLE NOT NULL DEFAULT 0.135)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. POWER_CONSOLE_TABLE .. " ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map_key VARCHAR(96) NOT NULL,"
		.. "pos_x DOUBLE NOT NULL, pos_y DOUBLE NOT NULL, pos_z DOUBLE NOT NULL,"
		.. "ang_p DOUBLE NOT NULL, ang_y DOUBLE NOT NULL, ang_r DOUBLE NOT NULL,"
		.. "screen_scale DOUBLE NOT NULL DEFAULT 0.105)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. ZONE_TABLE .. " ("
		.. "zone_id VARCHAR(64) PRIMARY KEY, map_key VARCHAR(96) NOT NULL,"
		.. "planet_key VARCHAR(128) NOT NULL, zone_name VARCHAR(96) NOT NULL,"
		.. "centre_x DOUBLE NOT NULL DEFAULT 0, centre_y DOUBLE NOT NULL DEFAULT 0,"
		.. "radius DOUBLE NOT NULL DEFAULT 0.65, created_at INTEGER NOT NULL,"
		.. "expires_at INTEGER NOT NULL DEFAULT 0, created_by VARCHAR(96) NOT NULL)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_naval_squadrons ("
		.. "map_key VARCHAR(96) NOT NULL, squadron_id VARCHAR(64) NOT NULL,"
		.. "squadron_name VARCHAR(96) NOT NULL, craft VARCHAR(96) NOT NULL,"
		.. "total INTEGER NOT NULL DEFAULT 0, ready INTEGER NOT NULL DEFAULT 0,"
		.. "orders VARCHAR(64) NOT NULL DEFAULT 'standby',"
		.. "status VARCHAR(96) NOT NULL DEFAULT 'READY',"
		.. "roe VARCHAR(64) NOT NULL DEFAULT 'confirmed_hostiles',"
		.. "target_name VARCHAR(128) NOT NULL DEFAULT '',"
		.. "condition_pct INTEGER NOT NULL DEFAULT 100,"
		.. "fuel_pct INTEGER NOT NULL DEFAULT 100,"
		.. "ammo_pct INTEGER NOT NULL DEFAULT 100,"
		.. "morale_pct INTEGER NOT NULL DEFAULT 100,"
		.. "experience INTEGER NOT NULL DEFAULT 0,"
		.. "kills INTEGER NOT NULL DEFAULT 0,"
		.. "losses INTEGER NOT NULL DEFAULT 0,"
		.. "mission_started INTEGER NOT NULL DEFAULT 0,"
		.. "updated_at INTEGER NOT NULL DEFAULT 0,"
		.. "PRIMARY KEY (map_key,squadron_id))")

	MilBase.DB.Query("SELECT * FROM frontier_naval_state WHERE map_key="
		.. MilBase.SQLStr(mapKey()) .. " LIMIT 1", function(rows)
		local row = rows and rows[1]
		if row then
			for _, key in ipairs(N.ResourceOrder) do
				N.State.resources[key] = math.Clamp(tonumber(row[key])
					or N.State.resources[key] or 0, 0,
					tonumber(naval.ResourceMaximums and naval.ResourceMaximums[key]) or 999999999)
			end
			N.State.power = {
				engines = tonumber(row.p_engines) or 18,
				maneuvering = tonumber(row.p_manoeuvring) or 10,
				shields = tonumber(row.p_shields) or 18,
				weapons = tonumber(row.p_weapons) or 16,
				sensors = tonumber(row.p_sensors) or 14,
				communications = tonumber(row.p_comms) or 8,
				life_support = tonumber(row.p_life) or 16,
			}
			N.State.ewMode = tostring(row.ew_mode or "passive")
			N.State.fleetOrder = tostring(row.fleet_order or "independent operations")
		else
			N.SaveState()
		end
		touch()
		if MilBase.RefreshShipSystems then MilBase.RefreshShipSystems() end
	end)
	MilBase.DB.Query("SELECT * FROM frontier_naval_log WHERE map_key="
		.. MilBase.SQLStr(mapKey()) .. " ORDER BY id DESC LIMIT "
		.. math.max(1, tonumber(naval.LogLimit) or 24), function(rows)
		N.State.logs = {}
		for _, row in ipairs(rows or {}) do
			N.State.logs[#N.State.logs + 1] = {
				id = tonumber(row.id) or 0,
				time = tonumber(row.created_at) or 0,
				category = tostring(row.category or ""),
				title = tostring(row.title or ""),
				detail = tostring(row.detail or ""),
				actor = tostring(row.actor or ""),
			}
		end
	end)
	MilBase.DB.Query("SELECT * FROM " .. ZONE_TABLE .. " WHERE map_key="
		.. MilBase.SQLStr(mapKey()) .. " ORDER BY created_at ASC", function(rows)
		N.State.restrictedZones = {}
		local now = os.time()
		for _, row in ipairs(rows or {}) do
			local expiresAt = tonumber(row.expires_at) or 0
			if expiresAt <= 0 or expiresAt > now then
				N.State.restrictedZones[tostring(row.zone_id or "")] = {
					id = tostring(row.zone_id or ""),
					planetKey = tostring(row.planet_key or "deep space"),
					name = tostring(row.zone_name or "RESTRICTED AREA"),
					x = tonumber(row.centre_x) or 0,
					y = tonumber(row.centre_y) or 0,
					radius = tonumber(row.radius) or 0.65,
					createdAt = tonumber(row.created_at) or now,
					expiresAt = expiresAt,
					createdBy = tostring(row.created_by or "REPUBLIC NAVY"),
					violations = {},
				}
			else
				MilBase.DB.Run("DELETE FROM " .. ZONE_TABLE .. " WHERE zone_id="
					.. MilBase.SQLStr(tostring(row.zone_id or "")))
			end
		end
		touch()
	end)
	MilBase.DB.Query("SELECT * FROM frontier_naval_squadrons WHERE map_key="
		.. MilBase.SQLStr(mapKey()), function(rows)
		for _, row in ipairs(rows or {}) do
			local id = N.CleanKey(row.squadron_id)
			local squadron = N.State.squadrons[id]
			if squadron then
				squadron.name = tostring(row.squadron_name or squadron.name)
				squadron.craft = tostring(row.craft or squadron.craft)
				squadron.total = math.max(0, tonumber(row.total) or squadron.total)
				squadron.pilots = squadron.total
				-- A restart safely recovers surviving craft to the carrier.
				squadron.ready = squadron.total
				squadron.order = "standby"
				squadron.status = "READY"
				squadron.roe = tostring(row.roe or "confirmed_hostiles")
				squadron.targetName = ""
				squadron.targetIndex = 0
				squadron.condition = math.Clamp(tonumber(row.condition_pct) or 100, 0, 100)
				squadron.fuel = math.Clamp(tonumber(row.fuel_pct) or 100, 0, 100)
				squadron.ammunition = math.Clamp(tonumber(row.ammo_pct) or 100, 0, 100)
				squadron.morale = math.Clamp(tonumber(row.morale_pct) or 100, 0, 100)
				squadron.experience = math.max(0, tonumber(row.experience) or 0)
				squadron.kills = math.max(0, tonumber(row.kills) or 0)
				squadron.losses = math.max(0, tonumber(row.losses) or 0)
				squadron.deployedCraft = 0
			end
		end
		touch()
	end)
end
hook.Add("Initialize", "MilBase.Naval.Database", initDatabase)

function N.AddLog(category, title, detail, actor)
	local entry = {
		time = os.time(),
		category = string.sub(tostring(category or "operations"), 1, 32),
		title = string.sub(tostring(title or "Ship entry"), 1, 128),
		detail = string.sub(tostring(detail or ""), 1, 1800),
		actor = string.sub(isstring(actor) and actor or playerName(actor), 1, 96),
	}
	table.insert(N.State.logs, 1, entry)
	while #N.State.logs > (tonumber(naval.LogLimit) or 24) do table.remove(N.State.logs) end
	MilBase.DB.Run("INSERT INTO frontier_naval_log "
		.. "(map_key,created_at,category,title,detail,actor) VALUES ("
		.. MilBase.SQLStr(mapKey()) .. "," .. entry.time .. ","
		.. MilBase.SQLStr(entry.category) .. "," .. MilBase.SQLStr(entry.title) .. ","
		.. MilBase.SQLStr(entry.detail) .. "," .. MilBase.SQLStr(entry.actor) .. ")")
	touch()
	return entry
end

function N.CanAfford(cost)
	for key, amount in pairs(cost or {}) do
		if (tonumber(N.State.resources[key]) or 0) < (tonumber(amount) or 0) then
			return false, N.ResourceLabels[key] or string.upper(key)
		end
	end
	return true
end

function N.ChangeResources(delta, reason, actor, silent)
	for key, amount in pairs(delta or {}) do
		if N.State.resources[key] ~= nil then
			local maximum = tonumber(naval.ResourceMaximums and naval.ResourceMaximums[key]) or 999999999
			N.State.resources[key] = math.Clamp(math.floor(N.State.resources[key]
				+ (tonumber(amount) or 0)), 0, maximum)
		end
	end
	if not silent then N.AddLog("logistics", reason or "Stores adjusted", N.FormatCost(delta), actor) end
	touch()
end

function N.Spend(cost, reason, actor)
	local ok, missing = N.CanAfford(cost)
	if not ok then return false, "Insufficient " .. string.lower(missing or "resources") end
	local delta = {}
	for key, amount in pairs(cost or {}) do delta[key] = -(tonumber(amount) or 0) end
	N.ChangeResources(delta, reason or "Operational expenditure", actor, true)
	N.AddLog("logistics", reason or "Operational expenditure", N.FormatCost(cost), actor)
	return true
end

function N.GetVehicleCost(vehicle)
	return N.VehicleCost(vehicle)
end

function N.ReserveVehicle(vehicle, requester, spawn)
	local cost = N.VehicleCost(vehicle)
	local ok, err = N.Spend(cost, "Vehicle issued: " .. tostring(vehicle.name or vehicle.entityClass),
		requester)
	if not ok then return nil, err end
	return {
		cost = cost,
		vehicleName = tostring(vehicle.name or vehicle.entityClass or "vehicle"),
		vehicleClass = tostring(vehicle.entityClass or ""),
		requesterName = playerName(requester),
		requesterSteamID = IsValid(requester) and requester:SteamID64() or "",
		spawnID = tonumber(spawn and spawn.id) or 0,
		spawnName = tostring(spawn and spawn.name or "vehicle pad"),
		issuedAt = os.time(),
	}
end

function N.RefundVehicleAllocation(allocation, condition, reason, actor)
	if not allocation or allocation.refunded then return false end
	allocation.refunded = true
	condition = math.Clamp(tonumber(condition) or 1, 0, 1)
	local refund = {}
	for key, amount in pairs(allocation.cost or {}) do
		local rate = tonumber(naval.VehicleReturnRefund and naval.VehicleReturnRefund[key]) or 0
		refund[key] = math.floor((tonumber(amount) or 0) * rate * condition)
	end
	N.ChangeResources(refund, reason or ("Vehicle returned: " .. allocation.vehicleName), actor, true)
	N.AddLog("logistics", reason or ("Vehicle returned: " .. allocation.vehicleName),
		"Recovered " .. N.FormatCost(refund) .. " at " .. math.floor(condition * 100) .. "% condition.", actor)
	return true
end

function N.RegisterRequisitionedVehicle(ent, allocation)
	if not IsValid(ent) or not allocation then return end
	N.RequisitionedVehicles = N.RequisitionedVehicles
		or setmetatable({}, { __mode = "k" })
	ent.MilBaseNavalAllocation = allocation
	ent.MilBaseNavalReturnSince = nil
	N.RequisitionedVehicles[ent] = true
end

local function vehicleEmpty(ent)
	if ent.GetDriver and IsValid(ent:GetDriver()) then return false end
	for _, ply in ipairs(player.GetAll()) do
		if ply:InVehicle() and (ply:GetVehicle() == ent or ply:GetVehicle():GetParent() == ent) then return false end
	end
	return true
end

local function vehicleCondition(ent)
	local maximum = ent.GetMaxHealth and tonumber(ent:GetMaxHealth()) or 0
	local health = ent.Health and tonumber(ent:Health()) or maximum
	if maximum <= 0 and ent.GetHP and ent.GetMaxHP then
		maximum, health = tonumber(ent:GetMaxHP()) or 0, tonumber(ent:GetHP()) or 0
	end
	if maximum <= 0 then return 1 end
	return math.Clamp(health / maximum, 0, 1)
end

local function nearReturnPad(ent)
	local VR = MilBase.VehicleReq
	if not VR or not VR.Spawns then return false end
	local radius = tonumber(naval.VehicleReturnRadius) or 230
	for _, spawn in pairs(VR.Spawns) do
		if tonumber(spawn.active or 1) == 1 and isvector(spawn.pos)
		and ent:GetPos():DistToSqr(spawn.pos) <= radius * radius then return true end
	end
	return false
end

timer.Create("MilBase.Naval.VehicleReturns", 1, 0, function()
	for ent in pairs(N.RequisitionedVehicles or {}) do
		if not IsValid(ent) then
			N.RequisitionedVehicles[ent] = nil
			continue
		end
		local allocation = ent.MilBaseNavalAllocation
		if not allocation or allocation.refunded then
			N.RequisitionedVehicles[ent] = nil
			continue
		end
		local speed = ent.GetVelocity and ent:GetVelocity():Length() or 999
		local safe = nearReturnPad(ent) and vehicleEmpty(ent)
			and speed <= (tonumber(naval.VehicleReturnSpeed) or 18)
			and vehicleCondition(ent) >= (tonumber(naval.VehicleReturnMinimumCondition) or 0.2)
		if safe then
			ent.MilBaseNavalReturnSince = ent.MilBaseNavalReturnSince or CurTime()
			if CurTime() - ent.MilBaseNavalReturnSince >= (tonumber(naval.VehicleReturnHoldTime) or 10) then
				local condition = vehicleCondition(ent)
				N.RefundVehicleAllocation(allocation, condition,
					"Vehicle safely recovered: " .. allocation.vehicleName)
				for _, ply in ipairs(player.GetAll()) do
					if ply:SteamID64() == allocation.requesterSteamID then
						MilBase.Notify(ply, allocation.vehicleName
							.. " recovered. Usable stores were returned to ship inventory.", "ok")
						break
					end
				end
				ent.MilBaseNavalReturned = true
				ent:Remove()
			end
		else
			ent.MilBaseNavalReturnSince = nil
		end
	end
end)

hook.Add("EntityRemoved", "MilBase.Naval.VehicleLoss", function(ent)
	local allocation = ent.MilBaseNavalAllocation
	if N.RequisitionedVehicles then N.RequisitionedVehicles[ent] = nil end
	if not allocation or allocation.refunded or ent.MilBaseNavalReturned then return end
	timer.Simple(0, function()
		N.AddLog("logistics", "Vehicle lost: " .. allocation.vehicleName,
			"Issued to " .. allocation.requesterName .. ". Stores were not recovered.", "SHIP COMPUTER")
	end)
end)

local function commandAllowed(ply, station)
	if not IsValid(ply) then return true end
	if not N.CanUseConsole(ply) then return false end
	local key = N.CleanKey(station)
	local watch = N.State.watches[key]
	if watch and watch.steamID == ply:SteamID64() then return true end
	return N.IsNavalOfficer(ply) and key == "command"
end
N.CommandAllowed = commandAllowed

function N.TakeWatch(ply, station)
	if not IsValid(ply) then return false, "A player is required to take a watch" end
	if not N.CanUseConsole(ply) then
		return false, "Republic Navy credentials are required to operate bridge stations"
	end
	station = N.CleanKey(station)
	local valid = false
	for _, key in ipairs(naval.WatchStations or {}) do
		if N.CleanKey(key) == station then valid = true break end
	end
	if not valid then return false, "Unknown station" end
	local occupied = N.State.watches[station]
	if occupied and occupied.steamID ~= ply:SteamID64() then
		for _, online in ipairs(player.GetAll()) do
			if online:SteamID64() == occupied.steamID then
				return false, station:gsub("_", " ") .. " is already manned by " .. occupied.name
			end
		end
	end
	for key, watch in pairs(N.State.watches) do
		if watch.steamID == ply:SteamID64() then N.State.watches[key] = nil end
	end
	N.State.watches[station] = {
		name = playerName(ply), steamID = ply:SteamID64(), since = os.time(),
	}
	N.AddLog("watch", "Watch assumed: " .. string.upper(station),
		playerName(ply) .. " has taken the station.", ply)
	return true
end

hook.Add("PlayerDisconnected", "MilBase.Naval.RelieveWatch", function(ply)
	for key, watch in pairs(N.State.watches) do
		if watch.steamID == ply:SteamID64() then
			N.State.watches[key] = nil
			N.AddLog("watch", "Watch automatically relieved: " .. string.upper(key),
				tostring(watch.name or playerName(ply)) .. " left the ship.", "SHIP COMPUTER")
		end
	end
end)

local function powerDistributionSummary(distribution)
	local parts = {}
	for _, key in ipairs(naval.PowerSystems or {}) do
		parts[#parts + 1] = (N.PowerLabels[key] or string.upper(key))
			.. " " .. math.floor(tonumber(distribution[key]) or 0) .. "%"
	end
	return table.concat(parts, " | ")
end

function N.ValidatePowerDistribution(distribution)
	if not istable(distribution) then return false, "Invalid power distribution" end
	local capacity = math.max(1, math.floor(tonumber(naval.PowerCapacity) or 100))
	local systemMaximum = math.Clamp(math.floor(tonumber(naval.PowerSystemMaximum) or 60),
		1, capacity)
	local total, clean = 0, {}
	for _, key in ipairs(naval.PowerSystems or {}) do
		local amount = tonumber(distribution[key])
		if not amount then return false, "Missing allocation for " .. (N.PowerLabels[key] or key) end
		amount = math.Clamp(math.floor(amount), 0, systemMaximum)
		clean[key] = amount
		total = total + amount
	end
	local lifeMinimum = math.max(0, math.floor(tonumber(naval.PowerLifeSupportMinimum) or 8))
	if (clean.life_support or 0) < lifeMinimum then
		return false, "Life support requires at least " .. lifeMinimum .. "% power"
	end
	if total > capacity then
		return false, "Power allocation exceeds reactor capacity by " .. (total - capacity) .. "%"
	end
	return true, clean, total
end

function N.ApplyPowerDistribution(ply, distribution, source)
	if IsValid(ply) and not N.CanUseConsole(ply) then
		return false, "Republic Navy credentials are required"
	end
	if not commandAllowed(ply, "engineering") then return false, "Engineering watch required" end
	if IsValid(source) then
		if source:GetClass() ~= "mb_naval_power_console" then
			return false, "Invalid power console"
		end
		if source:GetOperator() ~= ply then return false, "This console is not assigned to you" end
		local range = math.max(100, tonumber(naval.PowerConsoleUseRange) or 700)
		if ply:GetPos():DistToSqr(source:GetPos()) > range * range then
			return false, "Remain at the power distribution console"
		end
	end
	if IsValid(ply) and (ply.mb_navalPowerChangeAt or 0) > CurTime() then
		return false, "Reactor controls are still cycling"
	end
	local ok, clean, total = N.ValidatePowerDistribution(distribution)
	if not ok then return false, clean end
	local changed = false
	for _, key in ipairs(naval.PowerSystems or {}) do
		if (tonumber(N.State.power[key]) or 0) ~= clean[key] then changed = true end
	end
	if not changed then return false, "Power distribution is already set to those values" end
	N.State.power = clean
	if IsValid(ply) then
		ply.mb_navalPowerChangeAt = CurTime()
			+ math.max(0.1, tonumber(naval.PowerChangeCooldown) or 0.5)
	end
	N.AddLog("engineering", "Reactor distribution changed",
		powerDistributionSummary(clean) .. " | RESERVE "
			.. (math.max(1, tonumber(naval.PowerCapacity) or 100) - total) .. "%", ply)
	if IsValid(source) then source:EmitSound("buttons/combine_button1.wav", 60, 108, 0.55) end
	if MilBase.RefreshShipSystems then MilBase.RefreshShipSystems() end
	N.Broadcast()
	return true, "Power distribution applied. Reactor load " .. total .. "%."
end

local function setPower(ply, system, amount)
	system = N.CleanKey(system)
	if system == "manoeuvring" then system = "maneuvering" end
	if not N.State.power[system] then return false, "Unknown power system" end
	amount = tonumber(amount)
	if not amount then return false, "Enter a power percentage" end
	local distribution = table.Copy(N.State.power)
	distribution[system] = amount
	return N.ApplyPowerDistribution(ply, distribution)
end

local function engineeringConsoleAccess(ply)
	if commandAllowed(ply, "engineering") then return true end
	local occupied = N.State.watches.engineering
	if occupied and occupied.steamID ~= ply:SteamID64() then
		for _, online in ipairs(player.GetAll()) do
			if online:SteamID64() == occupied.steamID then
				return false, "Engineering watch is held by " .. tostring(occupied.name or "another officer")
			end
		end
	end
	return N.TakeWatch(ply, "engineering")
end

function N.ReleasePowerConsole(console, ply)
	if not console or not console.GetClass
	or console:GetClass() ~= "mb_naval_power_console" then return end
	if IsValid(ply) and console:GetOperator() ~= ply then return end
	local operator = console:GetOperator()
	if IsValid(operator) then operator.mb_navalPowerConsole = nil end
	if IsValid(console) then console:SetOperator(NULL) end
end

function N.UsePowerConsole(ply, console)
	if not IsValid(ply) or not ply:IsPlayer() or not IsValid(console)
	or console:GetClass() ~= "mb_naval_power_console" then return false end
	if (console.mb_nextUse or 0) > CurTime() then return false end
	console.mb_nextUse = CurTime() + 0.35
	local range = math.max(100, tonumber(naval.PowerConsoleUseRange) or 700)
	if ply:GetPos():DistToSqr(console:GetPos()) > range * range then return false end
	if not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		console:EmitSound("buttons/button10.wav", 55, 92, 0.5)
		return false
	end
	local operator = console:GetOperator()
	if IsValid(operator) and operator ~= ply then
		MilBase.Notify(ply, "Power distribution is operated by " .. playerName(operator) .. ".", "warn")
		return false
	end
	local allowed, reason = engineeringConsoleAccess(ply)
	if not allowed then
		MilBase.Notify(ply, reason or "Engineering watch required.", "warn")
		return false
	end
	for _, other in ipairs(ents.FindByClass("mb_naval_power_console")) do
		if other ~= console and other:GetOperator() == ply then N.ReleasePowerConsole(other, ply) end
	end
	console:SetOperator(ply)
	ply.mb_navalPowerConsole = console
	net.Start(NET_POWER_OPEN)
		net.WriteEntity(console)
	net.Send(ply)
	console:EmitSound("buttons/button14.wav", 55, 105, 0.45)
	return true
end

net.Receive(NET_POWER_APPLY, function(_, ply)
	local console = net.ReadEntity()
	local distribution = {}
	for _, key in ipairs(naval.PowerSystems or {}) do
		distribution[key] = net.ReadUInt(7)
	end
	if not IsValid(console) or console:GetClass() ~= "mb_naval_power_console" then
		MilBase.Notify(ply, "Use a valid power distribution console.", "warn")
		return
	end
	local ok, message = N.ApplyPowerDistribution(ply, distribution, console)
	MilBase.Notify(ply, tostring(message or (ok and "Power distribution applied." or "Order denied.")),
		ok and "ok" or "warn")
end)

net.Receive(NET_POWER_CLOSE, function(_, ply)
	local console = net.ReadEntity()
	N.ReleasePowerConsole(console, ply)
end)

hook.Add("PlayerDisconnected", "MilBase.Naval.ReleasePowerOperator", function(ply)
	local console = ply.mb_navalPowerConsole
	if IsValid(console) then N.ReleasePowerConsole(console, ply) end
end)
hook.Add("PlayerDeath", "MilBase.Naval.ReleasePowerOperatorDeath", function(ply)
	local console = ply.mb_navalPowerConsole
	if IsValid(console) then N.ReleasePowerConsole(console, ply) end
end)
timer.Create("MilBase.Naval.PowerConsoleOperators", 1, 0, function()
	local range = math.max(100, tonumber(naval.PowerConsoleUseRange) or 700)
	for _, console in ipairs(ents.FindByClass("mb_naval_power_console")) do
		local operator = console:GetOperator()
		if IsValid(operator) and (not operator:Alive()
		or operator:GetPos():DistToSqr(console:GetPos()) > range * range) then
			N.ReleasePowerConsole(console, operator)
		end
	end
end)

local function setEW(ply, mode)
	mode = N.CleanKey(mode)
	if not (naval.EWModes or {})[mode] then return false, "Unknown EW mode" end
	if not commandAllowed(ply, "tactical") then return false, "Tactical watch required" end
	N.State.ewMode = mode
	N.AddLog("tactical", "Electronic warfare mode",
		"EW suite set to " .. string.upper(mode) .. ".", ply)
	touch()
	return true
end

--------------------------------------------------------------------------
-- Linked hangar groups and physical flight paths
--------------------------------------------------------------------------

local HANGAR_DATA_DIRECTORY = "milbase/naval_hangars"
local HANGAR_DATA_FILE = HANGAR_DATA_DIRECTORY .. "/" .. mapKey() .. ".json"

local function cleanHangarKey(value)
	local key = N.CleanKey(value)
	return key ~= "" and key or N.CleanKey(naval.SquadronDefaultHangarGroup or "main")
end

local function vectorRecord(value)
	return {
		x = tonumber(value and value.x) or 0,
		y = tonumber(value and value.y) or 0,
		z = tonumber(value and value.z) or 0,
	}
end

local function angleRecord(value)
	return {
		p = tonumber(value and value.p) or 0,
		y = tonumber(value and value.y) or 0,
		r = tonumber(value and value.r) or 0,
	}
end

local function recordVector(value)
	return istable(value) and Vector(tonumber(value.x) or 0,
		tonumber(value.y) or 0, tonumber(value.z) or 0) or nil
end

local function recordAngle(value)
	return istable(value) and Angle(tonumber(value.p) or 0,
		tonumber(value.y) or 0, tonumber(value.r) or 0) or angle_zero
end

local function loadHangarConfiguration()
	file.CreateDir("milbase")
	file.CreateDir(HANGAR_DATA_DIRECTORY)
	local decoded
	if file.Exists(HANGAR_DATA_FILE, "DATA") then
		decoded = util.JSONToTable(file.Read(HANGAR_DATA_FILE, "DATA") or "")
	end
	N.HangarConfig = istable(decoded) and decoded or {}
	N.HangarConfig.groups = istable(N.HangarConfig.groups)
		and N.HangarConfig.groups or {}
	N.HangarConfig.assignments = istable(N.HangarConfig.assignments)
		and N.HangarConfig.assignments or table.Copy(naval.SquadronHangarAssignments or {})
end

local function saveHangarConfiguration()
	if not N.HangarConfig then return false end
	file.CreateDir("milbase")
	file.CreateDir(HANGAR_DATA_DIRECTORY)
	file.Write(HANGAR_DATA_FILE, util.TableToJSON(N.HangarConfig, true) or "{}")
	return true
end
N.SaveHangarConfiguration = saveHangarConfiguration

loadHangarConfiguration()
N.HangarRuntime = N.HangarRuntime or {}

local function hangarGroup(groupKey, create)
	groupKey = cleanHangarKey(groupKey)
	local group = N.HangarConfig.groups[groupKey]
	if not group and create then
		group = {
			id = groupKey,
			name = string.upper(groupKey:gsub("_", " ")),
			doors = {},
			launch = {},
			returnPath = {},
		}
		N.HangarConfig.groups[groupKey] = group
	end
	if group then
		group.doors = istable(group.doors) and group.doors or {}
		group.launch = istable(group.launch) and group.launch or {}
		group.returnPath = istable(group.returnPath) and group.returnPath or {}
	end
	return group, groupKey
end

local function linkableHangarDoor(ent)
	if not IsValid(ent) or ent:IsPlayer() or ent:IsNPC() or ent:IsWorld() then return false end
	if MilBase.IsLinkableDoor and MilBase.IsLinkableDoor(ent) then return true end
	return string.find(string.lower(ent:GetClass()), "door", 1, true) ~= nil
end

local function doorRecord(ent)
	local mapID = ent.MapCreationID and tonumber(ent:MapCreationID()) or -1
	return {
		mapID = mapID and mapID >= 0 and mapID or -1,
		class = ent:GetClass(),
		name = ent:GetName() or "",
		model = ent:GetModel() or "",
		pos = vectorRecord(ent:GetPos()),
	}
end

local function matchingDoorRecord(record, ent)
	if not record or not IsValid(ent) then return false end
	local mapID = ent.MapCreationID and tonumber(ent:MapCreationID()) or -1
	if tonumber(record.mapID) and tonumber(record.mapID) >= 0
	and mapID == tonumber(record.mapID) then return true end
	local pos = recordVector(record.pos)
	return tostring(record.class or "") == ent:GetClass()
		and isvector(pos) and pos:DistToSqr(ent:GetPos()) <= 4
end

local function resolveDoor(record)
	if not istable(record) then return nil end
	local mapID = tonumber(record.mapID) or -1
	if mapID >= 0 and ents.GetMapCreatedEntity then
		local ent = ents.GetMapCreatedEntity(mapID)
		if linkableHangarDoor(ent) then return ent end
	end
	local name = string.Trim(tostring(record.name or ""))
	if name ~= "" then
		for _, ent in ipairs(ents.FindByName(name)) do
			if linkableHangarDoor(ent)
			and (record.class == "" or ent:GetClass() == record.class) then return ent end
		end
	end
	local pos = recordVector(record.pos)
	if isvector(pos) then
		local best, distance
		for _, ent in ipairs(ents.FindInSphere(pos, 128)) do
			if linkableHangarDoor(ent)
			and (tostring(record.class or "") == "" or ent:GetClass() == record.class) then
				local candidate = ent:GetPos():DistToSqr(pos)
				if not distance or candidate < distance then
					best, distance = ent, candidate
				end
			end
		end
		return best
	end
end

function N.ResolveHangarDoors(groupKey)
	local group = hangarGroup(groupKey, false)
	local result, seen = {}, {}
	for _, record in ipairs(group and group.doors or {}) do
		local ent = resolveDoor(record)
		if IsValid(ent) and not seen[ent] then
			seen[ent] = true
			result[#result + 1] = ent
		end
	end
	return result
end

function N.ToggleHangarDoor(groupKey, ent)
	if not linkableHangarDoor(ent) then return false, "Aim at a linkable hangar door" end
	local group, key = hangarGroup(groupKey, true)
	for index, record in ipairs(group.doors) do
		if matchingDoorRecord(record, ent) then
			table.remove(group.doors, index)
			saveHangarConfiguration()
			return true, "Door removed from " .. string.upper(key)
				.. " (" .. #group.doors .. " linked)"
		end
	end
	group.doors[#group.doors + 1] = doorRecord(ent)
	saveHangarConfiguration()
	return true, "Door linked to " .. string.upper(key)
		.. " (" .. #group.doors .. " linked)"
end

function N.AddHangarNode(groupKey, pathKind, pos, ang)
	if not isvector(pos) then return false, "A valid flight-path position is required" end
	local group, key = hangarGroup(groupKey, true)
	pathKind = N.CleanKey(pathKind)
	local field = pathKind == "return" or pathKind == "recovery"
		and "returnPath" or pathKind == "launch" and "launch" or nil
	if not field then return false, "Path must be launch or return" end
	group[field][#group[field] + 1] = {
		pos = vectorRecord(pos),
		ang = angleRecord(ang or angle_zero),
	}
	saveHangarConfiguration()
	return true, string.upper(key) .. " " .. string.upper(pathKind)
		.. " node " .. #group[field] .. " recorded"
end

function N.ClearHangarSetup(groupKey, part)
	local group, key = hangarGroup(groupKey, false)
	if not group then return false, "Unknown hangar group" end
	part = N.CleanKey(part)
	if part == "doors" then
		group.doors = {}
	elseif part == "launch" then
		group.launch = {}
	elseif part == "return" or part == "recovery" then
		group.returnPath = {}
	elseif part == "all" then
		N.HangarConfig.groups[key] = nil
	else
		return false, "Clear doors, launch, return or all"
	end
	saveHangarConfiguration()
	return true, string.upper(key) .. " " .. string.upper(part) .. " configuration cleared"
end

function N.AssignSquadronHangar(squadronID, groupKey)
	squadronID, groupKey = N.CleanKey(squadronID), cleanHangarKey(groupKey)
	if not N.State.squadrons[squadronID] then return false, "Unknown squadron" end
	hangarGroup(groupKey, true)
	N.HangarConfig.assignments[squadronID] = groupKey
	saveHangarConfiguration()
	return true, N.State.squadrons[squadronID].name .. " assigned to "
		.. string.upper(groupKey)
end

local function hangarPath(groupKey, mode)
	local group = hangarGroup(groupKey, false)
	if not group then return {} end
	local records = mode == "return" and group.returnPath or group.launch
	local points = {}
	for _, record in ipairs(records or {}) do
		local pos = recordVector(record.pos)
		if isvector(pos) then points[#points + 1] = pos end
	end
	if mode == "return" and #points < 2 then
		for index = #(group.launch or {}), 1, -1 do
			local pos = recordVector(group.launch[index].pos)
			if isvector(pos) then points[#points + 1] = pos end
		end
	end
	return points
end
N.HangarPath = hangarPath

local function hangarRuntime(groupKey)
	groupKey = cleanHangarKey(groupKey)
	N.HangarRuntime[groupKey] = N.HangarRuntime[groupKey] or {
		id = groupKey,
		state = "SEALED",
		message = "Flight deck secure",
		doorsOpen = false,
		token = 0,
		activeCraft = 0,
		expectedCraft = 0,
		completedCraft = 0,
		operationActive = false,
		queue = {},
	}
	N.HangarRuntime[groupKey].queue = N.HangarRuntime[groupKey].queue or {}
	return N.HangarRuntime[groupKey], groupKey
end

local function processHangarQueue(groupKey)
	local runtime, key = hangarRuntime(groupKey)
	if runtime.operationActive or #runtime.queue == 0 then return end
	local queued = table.remove(runtime.queue, 1)
	if not queued or not isfunction(queued.callback) then
		processHangarQueue(key)
		return
	end
	runtime.state = "QUEUED OPERATION"
	runtime.message = tostring(queued.label or "Preparing next flight operation")
	timer.Simple(0.6, function()
		local current = N.HangarRuntime[key]
		if not current or current.operationActive then return end
		queued.callback()
	end)
end

local function releaseHangarOperation(groupKey)
	local runtime, key = hangarRuntime(groupKey)
	runtime.operationActive = false
	runtime.expectedCraft = math.max(0, tonumber(runtime.expectedCraft) or 0)
	runtime.completedCraft = runtime.expectedCraft
	processHangarQueue(key)
end

local function queueHangarOperation(groupKey, label, callback)
	local runtime, key = hangarRuntime(groupKey)
	if not runtime.operationActive then
		runtime.operationActive = true
		return false, 0
	end
	runtime.queue[#runtime.queue + 1] = {
		label = tostring(label or "Flight operation"),
		callback = callback,
	}
	touch()
	return true, #runtime.queue
end

-- Public entry point for other systems that need to share the same linked
-- doors and flight corridor as squadron launch/recovery. The callback runs
-- immediately when the deck is free, or later when its queue slot reaches the
-- front. The caller should finish by closing the hangar (which releases the
-- operation) or by calling ReleaseExternalHangarOperation after an abort.
function N.RequestExternalHangarOperation(groupKey, label, callback)
	if not isfunction(callback) then return false, 0, "A callback is required" end
	local function runQueuedCallback()
		local runtime = hangarRuntime(groupKey)
		-- The built-in squadron queue re-enters its launch/recovery function and
		-- reacquires the lock there. External callbacks run directly, so acquire
		-- the operation lock here before handing over the deck.
		runtime.operationActive = true
		local ok, err = pcall(callback)
		if not ok then
			releaseHangarOperation(groupKey)
			ErrorNoHalt("[MilBase Naval] External hangar operation failed: "
				.. tostring(err) .. "\n")
		end
	end
	local queued, position = queueHangarOperation(groupKey, label, runQueuedCallback)
	if not queued then
		local ok, err = pcall(callback)
		if not ok then
			releaseHangarOperation(groupKey)
			ErrorNoHalt("[MilBase Naval] External hangar operation failed: "
				.. tostring(err) .. "\n")
			return false, 0, "failed"
		end
	end
	return true, position, queued and "queued" or "started"
end

function N.ReleaseExternalHangarOperation(groupKey)
	releaseHangarOperation(groupKey)
	return true
end

local function operateDoor(ent, input)
	if not IsValid(ent) then return false end
	if input == "Open" then ent:Fire("Unlock", "", 0) end
	ent:Fire(input, "", 0)
	return true
end

local function angleMotionDistance(first, second)
	if not isangle(first) or not isangle(second) then return 0 end
	return math.max(
		math.abs(math.AngleDifference(second.p, first.p)),
		math.abs(math.AngleDifference(second.y, first.y)),
		math.abs(math.AngleDifference(second.r, first.r)))
end

function N.OpenHangar(groupKey, reason, callback)
	local runtime, key = hangarRuntime(groupKey)
	runtime.token = runtime.token + 1
	local token = runtime.token
	local doors = N.ResolveHangarDoors(key)
	local started = CurTime()
	local minimumDelay = #doors > 0 and math.max(0.2,
		tonumber(naval.HangarDoorOpenDelay) or 3) or 0.15
	local settleTime = math.max(0.15,
		tonumber(naval.HangarDoorOpenSettleTime) or 0.8)
	local pollInterval = math.max(0.05,
		tonumber(naval.HangarDoorOpenPollInterval) or 0.1)
	local positionEpsilon = math.max(0.01,
		tonumber(naval.HangarDoorMotionPositionEpsilon) or 0.2)
	local angleEpsilon = math.max(0.01,
		tonumber(naval.HangarDoorMotionAngleEpsilon) or 0.15)
	local timeout = math.max(minimumDelay + settleTime,
		tonumber(naval.HangarDoorOperationTimeout) or 18)
	local samples = {}
	runtime.state = "OPENING"
	runtime.message = tostring(reason or "Preparing flight deck")
	runtime.blockedBy = ""
	runtime.doorsOpen = false
	for _, door in ipairs(doors) do
		if IsValid(door) then
			samples[door] = {
				pos = door:GetPos(),
				ang = door:GetAngles(),
				lastMotion = started,
			}
			operateDoor(door, "Open")
		end
	end

	local function finishOpen(timedOut)
		local current = N.HangarRuntime[key]
		if not current or current.token ~= token then return end
		current.doorsOpen = true
		current.state = #doors > 0 and "OPEN" or "UNCONFIGURED"
		if #doors <= 0 then
			current.message = "No linked doors; using remote launch fallback"
		elseif timedOut then
			current.message = "Hangar door opening timed out; flight path released"
		else
			current.message = "Hangar doors fully open"
		end
		if isfunction(callback) then callback(current, #doors) end
		touch()
	end

	local function checkOpen()
		local current = N.HangarRuntime[key]
		if not current or current.token ~= token then return end
		local now = CurTime()
		local allSettled = now - started >= minimumDelay
		for door, sample in pairs(samples) do
			if not IsValid(door) then continue end
			local pos, ang = door:GetPos(), door:GetAngles()
			local moved = pos:DistToSqr(sample.pos) > positionEpsilon * positionEpsilon
				or angleMotionDistance(sample.ang, ang) > angleEpsilon
			if moved then
				sample.lastMotion = now
				sample.pos = pos
				sample.ang = ang
			end
			if now - sample.lastMotion < settleTime then allSettled = false end
		end
		if allSettled then
			finishOpen(false)
		elseif now - started >= timeout then
			finishOpen(true)
		else
			timer.Simple(pollInterval, checkOpen)
		end
	end

	timer.Simple(#doors > 0 and pollInterval or minimumDelay, checkOpen)
	touch()
	return true
end

local function hangarDoorBlocker(groupKey, doors)
	local doorSet = {}
	for _, door in ipairs(doors) do doorSet[door] = true end
	local padding = math.max(16, tonumber(naval.HangarDoorSafetyPadding) or 72)
	local expand = Vector(padding, padding, padding)
	for _, door in ipairs(doors) do
		if not IsValid(door) then continue end
		local mins, maxs = door:WorldSpaceAABB()
		for _, ent in ipairs(ents.FindInBox(mins - expand, maxs + expand)) do
			local class = IsValid(ent) and ent:GetClass() or ""
			if doorSet[ent] or not IsValid(ent) or ent:IsWorld()
			or ent:GetSolid() == SOLID_NONE
				and class ~= "mb_squadron_craft"
				and class ~= "mb_inspection_ship" then
				continue
			end
			local physical = ent:IsPlayer() or ent:IsNPC() or ent:IsVehicle()
				or class == "mb_squadron_craft"
				or class == "mb_inspection_ship"
				or ent:GetMoveType() == MOVETYPE_VPHYSICS
			if physical then return ent end
		end
	end
end

function N.CloseHangar(groupKey, reason, force)
	local runtime, key = hangarRuntime(groupKey)
	runtime.token = runtime.token + 1
	local token = runtime.token
	local doors = N.ResolveHangarDoors(key)
	local started = CurTime()
	runtime.state = "CLOSING"
	runtime.message = tostring(reason or "Securing flight deck")

	local function attempt()
		local current = N.HangarRuntime[key]
		if not current or current.token ~= token then return end
		local blocker = not force and hangarDoorBlocker(key, doors) or nil
		if IsValid(blocker) then
			current.state = "BLOCKED"
			current.blockedBy = blocker:IsPlayer() and playerName(blocker)
				or blocker:GetClass()
			current.message = "Doorway obstruction: " .. current.blockedBy
			timer.Simple(math.max(0.25,
				tonumber(naval.HangarDoorSafetyRetry) or 1), attempt)
			touch()
			return
		end
		for _, door in ipairs(doors) do operateDoor(door, "Close") end
		current.state = "CLOSING"
		current.blockedBy = ""
		timer.Simple(#doors > 0 and math.max(0.4,
			tonumber(naval.HangarDoorCloseDelay) or 1.5) or 0.1, function()
			local latest = N.HangarRuntime[key]
			if not latest or latest.token ~= token then return end
			latest.doorsOpen = false
			latest.state = #doors > 0 and "SEALED" or "UNCONFIGURED"
			latest.message = #doors > 0 and "Flight deck secure; hangar doors sealed"
				or "No linked hangar doors"
			releaseHangarOperation(key)
			touch()
		end)
	end
	timer.Simple(math.max(0, tonumber(naval.HangarDoorCloseDelay) or 1.5), attempt)
	touch()
	return true
end

function N.StopHangarDoors(groupKey)
	local runtime, key = hangarRuntime(groupKey)
	runtime.token = runtime.token + 1
	for _, door in ipairs(N.ResolveHangarDoors(key)) do operateDoor(door, "Stop") end
	runtime.state = "HALTED"
	runtime.message = "Emergency door stop engaged"
	touch()
	return true
end

function N.ShowHangarSetup(ply, groupKey)
	local group, key = hangarGroup(groupKey, false)
	if not group then return false, "Unknown hangar group" end
	local duration = 15
	for _, door in ipairs(N.ResolveHangarDoors(key)) do
		debugoverlay.BoxAngles(door:GetPos(), door:OBBMins(), door:OBBMaxs(),
			door:GetAngles(), duration, Color(255, 190, 55, 30))
	end
	for _, mode in ipairs({ "launch", "return" }) do
		local points = hangarPath(key, mode)
		local color = mode == "launch" and Color(70, 180, 255)
			or Color(90, 255, 150)
		for index, point in ipairs(points) do
			debugoverlay.Sphere(point, 18, duration, color, true)
			debugoverlay.Text(point + Vector(0, 0, 24),
				string.upper(mode) .. " " .. index, duration, false)
			if index > 1 then
				debugoverlay.Line(points[index - 1], point, duration, color, true)
			end
		end
	end
	return true, string.upper(key) .. " setup displayed for " .. duration .. " seconds"
end

local function squadronModel(id)
	local valid = {}
	for _, model in ipairs((naval.SquadronVisualModels or {})[id] or {}) do
		if util.IsValidModel(model) then valid[#valid + 1] = model end
	end
	return valid[1]
end

local function missionDefinition(order)
	return (naval.SquadronMissionDefinitions or {})[order]
end

local function missionLabel(order)
	local definition = missionDefinition(order)
	return definition and definition.label or tostring(order or "standby"):gsub("_", " ")
end

local function cleanSquadronVisuals(squadron)
	squadron.visuals = squadron.visuals or {}
	for index = #squadron.visuals, 1, -1 do
		if not IsValid(squadron.visuals[index]) then
			table.remove(squadron.visuals, index)
		end
	end
	return squadron.visuals
end

local function targetRadiusScale(ent, targetRadius)
	if not IsValid(ent) then return 1 end
	local mins, maxs = ent:GetModelRenderBounds()
	local native = isvector(mins) and isvector(maxs)
		and math.max(mins:Length(), maxs:Length()) or 0
	if native <= 0 and util.GetModelBounds then
		mins, maxs = util.GetModelBounds(ent:GetModel())
		native = isvector(mins) and isvector(maxs)
			and math.max(mins:Length(), maxs:Length()) or 0
	end
	local scale = native > 0 and math.Clamp(math.max(1, targetRadius) / native,
		0.001, 2) or math.max(0.001, tonumber(naval.SquadronVisualScale) or 0.012)
	if ent.SetVisualScale then ent:SetVisualScale(scale) end
	if ent.SetModelSize then ent:SetModelSize(scale) end
	ent:SetModelScale(scale, 0.000001)
	if isvector(mins) and isvector(maxs) then
		ent:SetCollisionBounds(mins * scale, maxs * scale)
		if ent.SetCombatRadius then ent:SetCombatRadius(math.max(4, native * scale)) end
	end
	return scale
end

local function fixedVisualScale(ent, requestedScale)
	if not IsValid(ent) then return 1 end
	local scale = math.Clamp(tonumber(requestedScale) or 1, 0.001, 8)
	local mins, maxs = ent:GetModelRenderBounds()
	if (not isvector(mins) or not isvector(maxs)) and util.GetModelBounds then
		mins, maxs = util.GetModelBounds(ent:GetModel())
	end
	if ent.SetVisualScale then ent:SetVisualScale(scale) end
	if ent.SetModelSize then ent:SetModelSize(scale) end
	ent:SetModelScale(scale, 0.000001)
	if isvector(mins) and isvector(maxs) then
		ent:SetCollisionBounds(mins * scale, maxs * scale)
		if ent.SetCombatRadius then
			local native = math.max(mins:Length(), maxs:Length())
			ent:SetCombatRadius(math.max(4, native * scale))
		end
	end
	return scale
end

local function squadronContactByIndex(entIndex)
	local ship = Entity(math.floor(tonumber(entIndex) or -1))
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return nil end
	return ship
end

local function squadronTarget(squadron)
	local ent = squadronContactByIndex(squadron and squadron.targetIndex)
	return IsValid(ent) and ent or nil
end

local function nearestHostile(origin)
	local best, distance
	for _, candidate in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local faction = candidate.mb_galaxyTrueFaction or candidate:GetFaction()
		if candidate:GetHostile() or faction == "cis" or faction == "pirate" then
			local candidateDistance = isvector(origin)
				and candidate:GetPos():DistToSqr(origin) or 0
			if not distance or candidateDistance < distance then
				best, distance = candidate, candidateDistance
			end
		end
	end
	return best
end

local function friendlyCapital()
	for _, candidate in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local faction = candidate.mb_galaxyTrueFaction or candidate:GetFaction()
		if faction == "republic" and candidate:GetCapital()
		and not candidate.mb_navalSquadron then return candidate end
	end
end

local function attackerFor(ship)
	for _, candidate in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if candidate.mb_combatTarget == ship then return candidate end
	end
end

local function restrictedZoneViolation()
	for _, candidate in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if tostring(candidate.mb_navalRestrictedZone or "") ~= "" then return candidate end
	end
end

local function startEscortedDeparture(squadron, target)
	if not IsValid(target) or squadron.escortDepartureStarted then return end
	squadron.escortDepartureStarted = true
	local centre, radius = G.SkyboxFrame()
	local outward = target:GetPos() - centre
	outward.z = outward.z * 0.25
	if outward:LengthSqr() < 1 then outward = target:GetForward() end
	outward:Normalize()
	if G.ClearShipFlightRoute then G.ClearShipFlightRoute(target) end
	target.mb_galaxyHoldForPlayerDeparture = false
	target.mb_galaxyPlayerDeparting = true
	target:SetShipState("departing system under Republic escort")
	target:SetFlightVelocity(outward * 42)
	target:SetDieAt(CurTime() + math.max(35, (tonumber(radius) or 1800) / 32))
end

local function formationOffset(index, distance, formation)
	local row = math.floor((index - 1) / 2) + 1
	local side = index % 2 == 0 and 1 or -1
	if formation == "line" then
		return Vector(-distance * 0.25,
			(index - 1.5) * distance, 0)
	elseif formation == "column" then
		return Vector(-distance * index, 0, 0)
	elseif formation == "echelon_left" then
		return Vector(-distance * index, -distance * index * 0.72, 0)
	elseif formation == "echelon_right" then
		return Vector(-distance * index, distance * index * 0.72, 0)
	elseif formation == "diamond" then
		local diamond = {
			Vector(-distance, 0, 0),
			Vector(-distance * 2, distance, 0),
			Vector(-distance * 2, -distance, 0),
			Vector(-distance * 3, 0, 0),
		}
		return diamond[((index - 1) % #diamond) + 1]
	elseif formation == "screen" then
		return Vector(-distance * 0.4,
			(index - 1.5) * distance * 1.7,
			(index % 2 == 0 and 1 or -1) * distance * 0.25)
	end
	return Vector(-distance * row, side * distance * 0.7 * row,
		(index % 3 - 1) * distance * 0.18)
end

local function applySquadronMission(id, squadron)
	if not G then return end
	local order = squadron.order or "patrol"
	local target = squadronTarget(squadron)
	local roe = squadron.roe or "confirmed_hostiles"
	local weaponsHeld = roe == "weapons_hold"
	local returnFireOnly = roe == "return_fire"
	if order == "close_escort" and not IsValid(target) then target = friendlyCapital() end
	if IsValid(target) and (order == "escort" or order == "convoy") then
		startEscortedDeparture(squadron, target)
	end
	local visuals = cleanSquadronVisuals(squadron)
	for index, ship in ipairs(visuals) do
		if not IsValid(ship) then continue end
		ship.mb_galaxyFormationFlight = nil
		ship:SetCombat(false)
		if ship.ClearCombatTarget then ship:ClearCombatTarget() end
		ship:SetShipState(squadron.name .. ": "
			.. string.lower(missionLabel(order)))

		local combatTarget
		if not weaponsHeld and (order == "attack" or order == "intercept"
		or order == "disable" or order == "boarding_cover") then
			combatTarget = target
		elseif not weaponsHeld and (order == "defend" or order == "screen"
		or order == "cap" or order == "blockade") then
			combatTarget = nearestHostile(IsValid(target)
				and target:GetPos() or ship:GetPos())
		end
		if returnFireOnly then combatTarget = attackerFor(ship) end
		if roe == "restricted_zone" and not IsValid(combatTarget) then
			combatTarget = restrictedZoneViolation()
		end
		if roe == "avoid_capitals" and IsValid(combatTarget)
		and combatTarget:GetCapital() then combatTarget = nil end

		if IsValid(combatTarget) and ship.SetCombatTarget then
			local damage = order == "disable" and 15
				or order == "boarding_cover" and 42 or 34
			ship:SetCombat(true)
			ship:SetCombatTarget(combatTarget, damage,
				order == "intercept" and 1.35 or 1.75)
			ship.mb_navalDisableFire = order == "disable"
			if index > 1 and IsValid(visuals[1])
			and G.SetShipFormationFollower then
				G.SetShipFormationFollower(ship, visuals[1],
					formationOffset(index, math.max(82,
					tonumber(naval.SquadronCombatFormationSpacing) or 160),
					squadron.formation), {
						positionGain = 0.36,
						maximumCatchup = 0.95,
						deadband = 10,
					})
			elseif G.AssignAutonomousShipMotion and not ship.mb_galaxyFlightRoute then
				ship:SetFlightVelocity(vector_origin)
				G.AssignAutonomousShipMotion(ship,
					squadron.name .. " combat manoeuvring")
			end
		elseif IsValid(target) and (order == "escort" or order == "convoy"
		or order == "shadow" or order == "defend"
		or order == "close_escort") and G.SetShipFormationFollower then
			local distance = order == "shadow"
				and math.max(190, tonumber(naval.SquadronShadowFormationSpacing) or 270)
				or math.max(95, tonumber(naval.SquadronEscortFormationSpacing) or 175)
			G.SetShipFormationFollower(ship, target,
				formationOffset(index, distance, squadron.formation), {
					positionGain = 0.3,
					maximumCatchup = 0.8,
					deadband = 12,
				})
		elseif index > 1 and IsValid(visuals[1])
		and G.SetShipFormationFollower then
			G.SetShipFormationFollower(ship, visuals[1],
				formationOffset(index, math.max(75,
				tonumber(naval.SquadronFormationSpacing) or 145),
				squadron.formation), {
					positionGain = 0.34,
					maximumCatchup = 0.9,
					deadband = 10,
				})
		elseif G.AssignAutonomousShipMotion then
			ship:SetFlightVelocity(vector_origin)
			G.AssignAutonomousShipMotion(ship, squadron.name .. " "
				.. string.lower(missionLabel(order)))
		end
	end
	touch()
end

function N.ApplySquadronMission(id)
	id = N.CleanKey(id)
	local squadron = N.State.squadrons[id]
	if not squadron then return false end
	applySquadronMission(id, squadron)
	return true
end

local function spawnSquadronSkyVisual(id, squadron, number, bearing)
	if not G or not G.SpawnShip then return nil end
	local visuals = cleanSquadronVisuals(squadron)
	local maximum = math.min(math.max(1,
		tonumber(naval.SquadronMaximumVisuals) or 3),
		math.max(1, tonumber(squadron.total) or 1))
	if #visuals >= maximum then return nil end
	local model = squadronModel(id)
	local ship = G.SpawnShip("republic", {
		faction = "republic",
		name = squadron.name .. " " .. tostring(number or (#visuals + 1)),
		state = "forming after carrier launch",
		speed = math.Rand(70, 95),
		lifetime = 900,
		hull = 450,
		model = model,
		sideYaw = tonumber(bearing),
	})
	if not IsValid(ship) then return nil end
	local radii = naval.SquadronSkyboxTargetRadius or {}
	targetRadiusScale(ship, tonumber(radii[id]) or tonumber(radii.default) or 16)
	ship:SetCapital(false)
	ship.mb_navalSquadron = id
	ship.mb_navalCraftNumber = tonumber(number) or #visuals + 1
	ship:SetDieAt(0)
	visuals[#visuals + 1] = ship
	return ship
end

local function launchBearing(points)
	if #points < 2 then return nil end
	local direction = points[#points] - points[#points - 1]
	return direction:LengthSqr() > 0.001 and direction:Angle().y or nil
end

local function squadronMapModelScale(id, model, mins, maxs)
	if naval.SquadronMapFullScale ~= false then
		return math.Clamp(tonumber(naval.SquadronMapVisualScale) or 1, 0.001, 8)
	end
	local nativeRadius = isvector(mins) and isvector(maxs)
		and math.max(mins:Length(), maxs:Length()) or 0
	local radii = naval.SquadronMapTargetRadius or {}
	local target = tonumber(radii[id]) or tonumber(radii.default) or 58
	if nativeRadius > 0 then
		return math.Clamp(math.max(1, target) / nativeRadius, 0.001, 2)
	end
	return math.max(0.001, tonumber(naval.SquadronVisualScale) or 0.012)
end

local function squadronMapSeparationDistance(id)
	local minimum = math.max(64,
		tonumber(naval.SquadronMapMinimumSeparation) or 720)
	local model = squadronModel(id)
	if not model or not util.GetModelBounds then return minimum end
	local mins, maxs = util.GetModelBounds(model)
	if not isvector(mins) or not isvector(maxs) then return minimum end
	local dimensions = maxs - mins
	local hullSpan = math.max(math.abs(dimensions.x),
		math.abs(dimensions.y), math.abs(dimensions.z))
	local scale = squadronMapModelScale(id, model, mins, maxs)
	local multiplier = math.max(1,
		tonumber(naval.SquadronMapHullSpacingMultiplier) or 1.55)
	local clearance = math.max(0,
		tonumber(naval.SquadronMapHullClearance) or 180)
	return math.max(minimum, hullSpan * scale * multiplier + clearance)
end

local function accelerationTravelTime(distance, speed, acceleration)
	distance = math.max(0, tonumber(distance) or 0)
	speed = math.max(80, tonumber(speed) or 520)
	acceleration = math.max(40, tonumber(acceleration) or 260)
	local accelerationTime = speed / acceleration
	local accelerationDistance = 0.5 * acceleration * accelerationTime * accelerationTime
	if distance <= accelerationDistance then
		return math.sqrt((2 * distance) / acceleration)
	end
	return accelerationTime + (distance - accelerationDistance) / speed
end

local function squadronRouteSpacing(id, mode)
	local configured = mode == "return"
		and (tonumber(naval.SquadronRecoverySpacing) or 3)
		or (tonumber(naval.SquadronLaunchSpacing) or 2.75)
	local travel = accelerationTravelTime(squadronMapSeparationDistance(id),
		tonumber(naval.SquadronMapFlightSpeed) or 520,
		tonumber(naval.SquadronMapFlightAcceleration) or 260)
	local interval = math.max(configured,
		travel + math.max(0, tonumber(naval.SquadronMapSpacingBuffer) or 0.35))
	return math.min(interval, math.max(configured,
		tonumber(naval.SquadronMapMaximumRouteSpacing) or 7))
end

local function spawnPhysicalSquadronCraft(id, squadron, number, route, mode, callback)
	if #route < 2 then return nil end
	local craft = ents.Create("mb_squadron_craft")
	if not IsValid(craft) then return nil end
	local model = squadronModel(id)
	if model then craft:SetModel(model) end
	craft:SetSquadronID(id)
	craft:SetCraftName(squadron.name .. " " .. number)
	craft:SetFlightMode(mode)
	if naval.SquadronMapFullScale ~= false then
		fixedVisualScale(craft, tonumber(naval.SquadronMapVisualScale) or 1)
	else
		local radii = naval.SquadronMapTargetRadius or {}
		targetRadiusScale(craft,
			tonumber(radii[id]) or tonumber(radii.default) or 58)
	end
	craft:SetPos(route[1])
	craft:Spawn()
	craft:Activate()
	craft.mb_navalSquadron = id
	craft.mb_navalCraftNumber = number
	local ok = craft:SetFlightRoute(route, {
		speed = tonumber(naval.SquadronMapFlightSpeed) or 520,
		acceleration = tonumber(naval.SquadronMapFlightAcceleration) or 260,
		turnRate = tonumber(naval.SquadronMapFlightTurnRate) or 2.6,
		arrivalRadius = 24,
		onComplete = callback,
	})
	if not ok then craft:Remove() return nil end
	return craft
end

local function finishSquadronLaunch(id, squadron, groupKey, token)
	if squadron.operationToken ~= token then return end
	squadron.physicalCraft = {}
	squadron.status = string.upper(missionLabel(squadron.order))
	squadron.missionStarted = os.time()
	local runtime = hangarRuntime(groupKey)
	runtime.activeCraft = 0
	runtime.completedCraft = runtime.expectedCraft
	applySquadronMission(id, squadron)
	N.CloseHangar(groupKey,
		"All squadron craft clear; sealing main hangar")
	N.AddLog("flight", squadron.name .. " launch complete",
		squadron.deployedCraft .. " craft transferred to local-space operations. "
			.. "Hangar closure authorised.", "FLIGHT OPERATIONS")
	touch()
end

local function beginSquadronLaunch(id, squadron)
	local assignment = N.HangarConfig.assignments[id]
		or (naval.SquadronHangarAssignments or {})[id]
		or naval.SquadronDefaultHangarGroup or "main"
	local groupKey = cleanHangarKey(assignment)
	local route = hangarPath(groupKey, "launch")
	local launchCount = math.min(
		math.max(0, math.floor(tonumber(squadron.ready) or 0)),
		math.max(1, math.floor(tonumber(naval.SquadronMaximumPhysicalCraft) or 8)))
	if launchCount <= 0 then return false, "No squadron craft are ready" end
	local queued, queuePosition = queueHangarOperation(groupKey,
		squadron.name .. " launch", function()
			if N.State.squadrons[id] == squadron then beginSquadronLaunch(id, squadron) end
		end)
	if queued then
		squadron.status = "QUEUED FOR LAUNCH"
		return true, squadron.name .. " queued for launch at "
			.. string.upper(groupKey) .. " (position " .. queuePosition .. ")"
	end
	squadron.operationToken = (tonumber(squadron.operationToken) or 0) + 1
	local token = squadron.operationToken
	squadron.status = "OPENING HANGAR"
	squadron.deployedCraft = launchCount
	squadron.ready = math.max(0, squadron.ready - launchCount)
	squadron.fuel = math.max(0, (tonumber(squadron.fuel) or 100) - 8)
	if squadron.order == "attack" or squadron.order == "intercept"
	or squadron.order == "disable" or squadron.order == "boarding_cover" then
		squadron.ammunition = math.max(0, (tonumber(squadron.ammunition) or 100) - 12)
	end

	if naval.SquadronPhysicalLaunchEnabled == false or #route < 2 then
		for number = 1, launchCount do
			spawnSquadronSkyVisual(id, squadron, number)
		end
		squadron.status = string.upper(missionLabel(squadron.order))
		squadron.missionStarted = os.time()
		applySquadronMission(id, squadron)
		N.AddLog("flight", squadron.name .. " remote launch",
			"No configured map flight path was available; squadron entered local-space operations directly.",
			"FLIGHT OPERATIONS")
		releaseHangarOperation(groupKey)
		return true, "Squadron deployed. Configure " .. string.upper(groupKey)
			.. " launch nodes for a physical hangar departure."
	end

	local runtime = hangarRuntime(groupKey)
	runtime.expectedCraft = launchCount
	runtime.completedCraft = 0
	runtime.activeCraft = 0
	N.OpenHangar(groupKey, squadron.name .. " launch requested", function(_, doorCount)
		if squadron.operationToken ~= token then return end
		squadron.status = "LAUNCHING"
		squadron.physicalCraft = {}
		local completed = 0
		local bearing = launchBearing(route)
		local function transitioned(number)
			if squadron.operationToken ~= token then return end
			completed = completed + 1
			runtime.completedCraft = completed
			runtime.activeCraft = math.max(0, runtime.activeCraft - 1)
			spawnSquadronSkyVisual(id, squadron, number,
				bearing and bearing + (number - (launchCount + 1) * 0.5) * 2.4)
			if completed >= launchCount then
				finishSquadronLaunch(id, squadron, groupKey, token)
			else
				touch()
			end
		end
		local launchSpacing = squadronRouteSpacing(id, "launch")
		for number = 1, launchCount do
			timer.Simple((number - 1) * launchSpacing, function()
					if squadron.operationToken ~= token then return end
					local craft = spawnPhysicalSquadronCraft(id, squadron,
						number, route, "launch", function()
							transitioned(number)
						end)
					if IsValid(craft) then
						squadron.physicalCraft[#squadron.physicalCraft + 1] = craft
						runtime.activeCraft = runtime.activeCraft + 1
					else
						transitioned(number)
					end
				end)
		end
		if doorCount <= 0 then
			N.AddLog("flight", "Hangar doors not linked",
				string.upper(groupKey)
					.. " has a route but no linked door entities. Craft launch continued.",
				"FLIGHT OPERATIONS")
		end
		touch()
	end)
	return true, squadron.name .. " launch sequence started"
end

local function finishSquadronRecovery(id, squadron, groupKey, token)
	if squadron.operationToken ~= token then return end
	for _, ship in ipairs(cleanSquadronVisuals(squadron)) do
		if IsValid(ship) and ship.GetHullFraction then
			squadron.condition = math.min(tonumber(squadron.condition) or 100,
				math.floor(ship:GetHullFraction() * 100))
		end
	end
	for _, ship in ipairs(cleanSquadronVisuals(squadron)) do
		if IsValid(ship) then
			ship.mb_navalRecovered = true
			ship:Remove()
		end
	end
	squadron.visuals = {}
	squadron.physicalCraft = {}
	squadron.deployedCraft = 0
	squadron.order = "standby"
	squadron.targetIndex = 0
	squadron.targetName = ""
	local damage = math.max(0, 100 - (tonumber(squadron.condition) or 100))
	if damage > 1 then
		local duration = math.max(
			tonumber(naval.SquadronMaintenanceMinimum) or 12,
			math.ceil(damage
				* (tonumber(naval.SquadronMaintenanceSecondsPerDamage) or 2)))
		squadron.ready = 0
		squadron.status = "MAINTENANCE"
		squadron.repairReadyAt = os.time() + duration
	else
		squadron.ready = squadron.total
		squadron.status = "READY"
		squadron.repairReadyAt = 0
		squadron.condition = 100
		squadron.fuel = 100
		squadron.ammunition = 100
	end
	local runtime = hangarRuntime(groupKey)
	runtime.activeCraft = 0
	runtime.completedCraft = runtime.expectedCraft
	N.CloseHangar(groupKey,
		"All returning craft landed; sealing main hangar")
	N.AddLog("flight", squadron.name .. " recovered",
		squadron.total .. " surviving craft landed. "
			.. (squadron.status == "MAINTENANCE"
				and ("Maintenance turnaround "
					.. math.max(0, squadron.repairReadyAt - os.time()) .. " seconds.")
				or "Squadron returned to ready status.")
			.. " Hangar closure authorised.",
		"FLIGHT OPERATIONS")
	touch()
end

local function beginSquadronRecovery(id, squadron)
	local assignment = N.HangarConfig.assignments[id]
		or (naval.SquadronHangarAssignments or {})[id]
		or naval.SquadronDefaultHangarGroup or "main"
	local groupKey = cleanHangarKey(assignment)
	local route = hangarPath(groupKey, "return")
	local recoveryCount = math.max(0, math.floor(tonumber(squadron.deployedCraft) or 0))
	if recoveryCount <= 0 then recoveryCount = #cleanSquadronVisuals(squadron) end
	if recoveryCount <= 0 then
		squadron.order = "standby"
		squadron.status = "READY"
		squadron.ready = squadron.total
		return true, squadron.name .. " is already aboard"
	end
	local queued, queuePosition = queueHangarOperation(groupKey,
		squadron.name .. " recovery", function()
			if N.State.squadrons[id] == squadron then beginSquadronRecovery(id, squadron) end
		end)
	if queued then
		squadron.status = "QUEUED FOR RECOVERY"
		return true, squadron.name .. " queued for recovery at "
			.. string.upper(groupKey) .. " (position " .. queuePosition .. ")"
	end
	squadron.operationToken = (tonumber(squadron.operationToken) or 0) + 1
	local token = squadron.operationToken
	squadron.status = "RETURN VECTOR"
	for _, ship in ipairs(cleanSquadronVisuals(squadron)) do
		if not IsValid(ship) then continue end
		ship:SetShipState("recovering to Republic carrier")
		ship:SetCombat(false)
		if ship.ClearCombatTarget then ship:ClearCombatTarget() end
		ship.mb_galaxyFormationFlight = nil
		ship:SetFlightVelocity(ship:GetForward() * 110)
	end

	local runtime = hangarRuntime(groupKey)
	runtime.expectedCraft = recoveryCount
	runtime.completedCraft = 0
	runtime.activeCraft = 0
	N.OpenHangar(groupKey, squadron.name .. " recovery requested", function()
		if squadron.operationToken ~= token then return end
		if naval.SquadronPhysicalLaunchEnabled == false or #route < 2 then
			timer.Simple(4, function()
				finishSquadronRecovery(id, squadron, groupKey, token)
			end)
			return
		end
		squadron.status = "RECOVERING"
		squadron.physicalCraft = {}
		local completed = 0
		local visuals = cleanSquadronVisuals(squadron)
		local function landed()
			if squadron.operationToken ~= token then return end
			completed = completed + 1
			runtime.completedCraft = completed
			runtime.activeCraft = math.max(0, runtime.activeCraft - 1)
			if completed >= recoveryCount then
				finishSquadronRecovery(id, squadron, groupKey, token)
			else
				touch()
			end
		end
		local recoverySpacing = squadronRouteSpacing(id, "return")
		for number = 1, recoveryCount do
			timer.Simple((number - 1) * recoverySpacing, function()
					if squadron.operationToken ~= token then return end
					local skyShip = visuals[((number - 1) % math.max(1, #visuals)) + 1]
					if IsValid(skyShip) then
						skyShip.mb_navalRecovered = true
						if G and G.EmitHyperspaceBurst then
							G.EmitHyperspaceBurst(skyShip:GetPos(), skyShip:GetForward(),
								Color(75, 145, 255), false)
						end
						skyShip:Remove()
					end
					local craft = spawnPhysicalSquadronCraft(id, squadron,
						number, route, "return", landed)
					if IsValid(craft) then
						squadron.physicalCraft[#squadron.physicalCraft + 1] = craft
						runtime.activeCraft = runtime.activeCraft + 1
					else
						landed()
					end
				end)
		end
		touch()
	end)
	return true, squadron.name .. " recovery sequence started"
end

local function setSquadronROE(ply, id, roe)
	id, roe = N.CleanKey(id), N.CleanKey(roe)
	local squadron = N.State.squadrons[id]
	if not squadron then return false, "Unknown squadron" end
	if not (naval.SquadronROE or {})[roe] then return false, "Unknown rules of engagement" end
	if not commandAllowed(ply, "flight_control") then
		return false, "Flight control watch required"
	end
	squadron.roe = roe
	applySquadronMission(id, squadron)
	N.AddLog("flight", squadron.name .. " rules of engagement",
		string.upper((naval.SquadronROE[roe].label or roe)), ply)
	return true, squadron.name .. " ROE set to "
		.. string.upper(naval.SquadronROE[roe].label or roe)
end

local function setSquadronFormation(ply, id, formation)
	id, formation = N.CleanKey(id), N.CleanKey(formation)
	local squadron = N.State.squadrons[id]
	if not squadron then return false, "Unknown squadron" end
	if not (naval.SquadronFormations or {})[formation] then
		return false, "Unknown squadron formation"
	end
	if not commandAllowed(ply, "flight_control") then
		return false, "Flight control watch required"
	end
	squadron.formation = formation
	applySquadronMission(id, squadron)
	N.AddLog("flight", squadron.name .. " formation",
		string.upper(naval.SquadronFormations[formation].label or formation), ply)
	return true, squadron.name .. " forming "
		.. string.upper(naval.SquadronFormations[formation].label or formation)
end

local function orderSquadron(ply, id, order, requestedTarget)
	id, order = N.CleanKey(id), N.CleanKey(order)
	local squadron = N.State.squadrons[id]
	local definition = missionDefinition(order)
	local cost = naval.SquadronOrderCost and naval.SquadronOrderCost[order]
	if not squadron then return false, "Unknown squadron" end
	if not definition or not cost then return false, "Unknown squadron order" end
	if not commandAllowed(ply, "flight_control") then
		return false, "Flight control watch required"
	end
	if squadron.status == "LAUNCHING" or squadron.status == "OPENING HANGAR" then
		return false, "Squadron launch sequence is still in progress"
	end
	if squadron.status == "RECOVERING" or squadron.status == "RETURN VECTOR" then
		return false, "Squadron recovery sequence is still in progress"
	end
	if squadron.status == "QUEUED FOR LAUNCH"
	or squadron.status == "QUEUED FOR RECOVERY" then
		return false, "Squadron is already queued for a hangar operation"
	end
	if order ~= "recall"
	and math.max(0, tonumber(squadron.deployedCraft) or 0) <= 0
	and #cleanSquadronVisuals(squadron) == 0
	and math.max(0, tonumber(squadron.ready) or 0) <= 0 then
		return false, squadron.status == "MAINTENANCE"
			and ("Squadron maintenance completes in "
				.. math.max(0, (tonumber(squadron.repairReadyAt) or os.time())
					- os.time()) .. " seconds")
			or "No squadron craft are ready"
	end
	if order == "recall" then
		N.AddLog("flight", squadron.name .. " recalled",
			"Return-to-carrier vector transmitted.", ply)
		return beginSquadronRecovery(id, squadron)
	end
	if order == "ready_five" then
		if math.max(0, tonumber(squadron.deployedCraft) or 0) > 0
		or #cleanSquadronVisuals(squadron) > 0 then
			return false, "Recall the deployed squadron before assigning Ready Five"
		end
		squadron.order = "ready_five"
		squadron.status = "READY FIVE"
		squadron.targetIndex = 0
		squadron.targetName = ""
		N.AddLog("flight", squadron.name .. " assigned Ready Five",
			"Pilots are strapped in and cleared for immediate emergency launch.", ply)
		return true, squadron.name .. " is standing Ready Five"
	end
	if G and G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then
		return false, "Squadrons cannot launch while the carrier is in hyperspace"
	end

	local target
	if definition.target then
		local targetIndex = tonumber(requestedTarget) or 0
		if targetIndex <= 0 then
			targetIndex = tonumber(N.State.interceptTarget) or 0
		end
		target = squadronContactByIndex(targetIndex)
		if not IsValid(target) then
			return false, "Select a valid contact on the tactical display first"
		end
		local faction = target.mb_galaxyTrueFaction or target:GetFaction()
		if (order == "attack" or order == "intercept" or order == "disable"
		or order == "boarding_cover") and faction == "republic" then
			return false, "Republic contacts cannot be designated as hostile targets"
		end
		squadron.targetIndex = target:EntIndex()
		squadron.targetName = target:GetShipName()
	else
		squadron.targetIndex = 0
		squadron.targetName = ""
	end

	local ok, err = N.Spend(cost,
		squadron.name .. " ordered to " .. string.lower(missionLabel(order)), ply)
	if not ok then return false, err end
	squadron.order = order
	squadron.escortDepartureStarted = false
	squadron.missionStarted = os.time()
	local deployed = math.max(0, tonumber(squadron.deployedCraft) or 0) > 0
		or #cleanSquadronVisuals(squadron) > 0
	if deployed then
		squadron.status = string.upper(missionLabel(order))
		applySquadronMission(id, squadron)
		N.AddLog("flight", squadron.name .. " retasked",
			string.upper(missionLabel(order))
				.. (IsValid(target) and (" | TARGET " .. target:GetShipName()) or ""), ply)
		return true, squadron.name .. " retasked to " .. missionLabel(order)
	end

	local launched, message = beginSquadronLaunch(id, squadron)
	if not launched then
		N.ChangeResources(cost, "Squadron launch cancelled; stores restored", ply, true)
		return false, message
	end
	N.AddLog("flight", squadron.name .. " order",
		string.upper(missionLabel(order))
			.. (IsValid(target) and (" | TARGET " .. target:GetShipName()) or "")
			.. " | ROE " .. string.upper(squadron.roe:gsub("_", " ")), ply)
	return true, message
end
N.OrderSquadron = orderSquadron
N.SetSquadronROE = setSquadronROE
N.SetSquadronFormation = setSquadronFormation

timer.Create("MilBase.Naval.SquadronOperations", 1, 0, function()
	for id, squadron in pairs(N.State.squadrons or {}) do
		cleanSquadronVisuals(squadron)
		for _, ship in ipairs(squadron.visuals) do
			if IsValid(ship) and ship.GetHullFraction then
				squadron.condition = math.min(tonumber(squadron.condition) or 100,
					math.floor(ship:GetHullFraction() * 100))
			end
		end
		if squadron.status == "MAINTENANCE"
		and os.time() >= (tonumber(squadron.repairReadyAt) or math.huge) then
			squadron.status = "READY"
			squadron.ready = squadron.total
			squadron.condition = 100
			squadron.fuel = 100
			squadron.ammunition = 100
			squadron.repairReadyAt = 0
			N.AddLog("flight", squadron.name .. " maintenance complete",
				"Repairs, refuelling and rearming complete. Squadron returned to flight status.",
				"FLIGHT OPERATIONS")
		end
		if squadron.order == "disable" then
			local target = squadronTarget(squadron)
			if IsValid(target) and target.GetHullFraction
			and target:GetHullFraction() <= 0.3 then
				for _, ship in ipairs(squadron.visuals) do
					if IsValid(ship) and ship.ClearCombatTarget then ship:ClearCombatTarget() end
				end
				squadron.status = "TARGET DISABLED"
				N.AddLog("flight", squadron.name .. " mission complete",
					tostring(squadron.targetName or "Target")
						.. " reduced to minimum combat capability.", "FLIGHT OPERATIONS")
				squadron.order = "shadow"
				applySquadronMission(id, squadron)
			end
		elseif missionDefinition(squadron.order)
		and missionDefinition(squadron.order).target
		and not IsValid(squadronTarget(squadron))
		and squadron.status ~= "RETURN VECTOR"
		and squadron.status ~= "RECOVERING"
		and math.max(0, tonumber(squadron.deployedCraft) or 0) > 0 then
			if squadron.order == "escort" or squadron.order == "convoy" then
				squadron.status = "ESCORT COMPLETE"
				N.AddLog("flight", squadron.name .. " escort complete",
					tostring(squadron.targetName or "Protected contact")
						.. " has cleared the local system. Squadron returning to carrier.",
					"FLIGHT OPERATIONS")
				beginSquadronRecovery(id, squadron)
			else
				squadron.status = "TARGET LOST"
				for _, ship in ipairs(squadron.visuals) do
					if IsValid(ship) and ship.ClearCombatTarget then ship:ClearCombatTarget() end
					if IsValid(ship) and G and G.AssignAutonomousShipMotion then
						G.AssignAutonomousShipMotion(ship, "target lost holding pattern")
					end
				end
			end
		end
	end
end)

if G and G.OnShipDestroyed and not N.mb_squadronDestroyedWrapped then
	N.mb_squadronDestroyedWrapped = true
	local baseOnShipDestroyed = G.OnShipDestroyed
	G.OnShipDestroyed = function(ship, attacker)
		if IsValid(attacker) and attacker.mb_navalSquadron then
			local squadron = N.State.squadrons[attacker.mb_navalSquadron]
			if squadron then
				squadron.kills = (tonumber(squadron.kills) or 0) + 1
				squadron.experience = (tonumber(squadron.experience) or 0) + 12
				touch()
			end
		end
		return baseOnShipDestroyed(ship, attacker)
	end
end

hook.Add("EntityRemoved", "MilBase.Naval.SquadronLoss", function(ent)
	local id = ent.mb_navalSquadron
	if not id or not ent.mb_destroyed or ent.mb_navalRecovered then return end
	timer.Simple(0, function()
		local squadron = N.State.squadrons[id]
		if not squadron then return end
		squadron.total = math.max(0, (tonumber(squadron.total) or 0) - 1)
		squadron.pilots = math.min(squadron.total,
			math.max(0, (tonumber(squadron.pilots) or squadron.total + 1) - 1))
		squadron.ready = math.min(squadron.total,
			math.max(0, tonumber(squadron.ready) or 0))
		squadron.deployedCraft = math.max(0,
			(tonumber(squadron.deployedCraft) or 0) - 1)
		squadron.losses = (tonumber(squadron.losses) or 0) + 1
		squadron.morale = math.max(0, (tonumber(squadron.morale) or 100) - 8)
		squadron.condition = math.max(0, (tonumber(squadron.condition) or 100) - 5)
		if squadron.total <= 0 then squadron.status = "SQUADRON LOST" end
		N.AddLog("flight", squadron.name .. " casualty",
			"One " .. squadron.craft .. " was destroyed during "
				.. string.lower(missionLabel(squadron.order)) .. ".", "FLIGHT OPERATIONS")
	end)
end)

local function orderFleet(ply, order)
	order = N.CleanKey(order)
	local valid = {
		hold = true, form = true, screen = true, engage = true,
		withdraw = true, protect = true, rescue = true,
	}
	if not valid[order] then return false, "Unknown fleet order" end
	if not commandAllowed(ply, "command") then return false, "Command watch required" end
	N.State.fleetOrder = order
	if G then
		for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
			local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
			if faction ~= "republic" then continue end
			ship:SetShipState("fleet order: " .. order)
			if order == "hold" then
				ship:SetFlightVelocity(vector_origin)
			elseif order == "withdraw" then
				ship:SetFlightVelocity(ship:GetForward() * 70)
			elseif G.AssignAutonomousShipMotion then
				G.AssignAutonomousShipMotion(ship, "Republic fleet order " .. order)
			end
		end
	end
	N.AddLog("command", "Fleet order: " .. string.upper(order),
		"Order transmitted to friendly vessels in local space.", ply)
	touch()
	return true
end

local function trafficOrder(ply, entIndex, order)
	if not commandAllowed(ply, "traffic_control") then return false, "Traffic control watch required" end
	local ship = Entity(tonumber(entIndex) or -1)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return false, "Contact not found" end
	order = N.CleanKey(order)
	if not ({ hold = true, reroute = true, clear = true, leave = true, withdraw = true })[order] then
		return false, "Use hold, reroute, clear or leave"
	end
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	if faction == "cis" then
		ship:SetHostile(true)
		ship:SetShipState("rejecting Republic traffic authority")
		N.AddLog("traffic", "Traffic order rejected",
			ship:GetShipName() .. " identified as CIS and refused the transmission.", ply)
		return false, "CIS contact rejects Republic traffic authority"
	end
	if faction == "pirate" and math.Rand(0, 1) < 0.32 then
		ship:SetShipState("ignoring Republic traffic control")
		N.AddLog("traffic", "Traffic order ignored",
			ship:GetShipName() .. " refused to alter course.", ply)
		return false, "Pirate contact ignored the order"
	end
	if order == "hold" then
		ship:SetFlightVelocity(vector_origin)
		ship:SetShipState("holding by Republic traffic control")
	elseif order == "reroute" or order == "clear" then
		ship:SetShipState(order == "clear" and "cleared through Republic space" or "rerouting")
		if G and G.AssignAutonomousShipMotion then G.AssignAutonomousShipMotion(ship, "traffic control " .. order) end
	elseif order == "leave" or order == "withdraw" then
		local centre = G and G.SkyboxFrame and select(1, G.SkyboxFrame()) or vector_origin
		local direction = ship:GetPos() - centre
		if direction:LengthSqr() < 1 then direction = ship:GetForward() end
		ship:SetFlightVelocity(direction:GetNormalized() * 90)
		ship:SetShipState("leaving restricted space")
	end
	N.State.trafficNotice = string.upper(order) .. " — " .. ship:GetShipName()
	N.AddLog("traffic", "Traffic order issued",
		string.upper(order) .. " to " .. ship:GetShipName() .. ".", ply)
	return true
end

local function currentPlanetKey()
	local value = G and G.State and G.State.currentPlanet or "Deep Space"
	value = string.lower(string.Trim(tostring(value or "Deep Space")))
	return value ~= "" and value or "deep space"
end

local function contactByIndex(entIndex)
	local ship = Entity(math.floor(tonumber(entIndex) or -1))
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return nil end
	return ship
end

local function shipFaction(ship)
	return IsValid(ship)
		and string.lower(tostring(ship.mb_galaxyTrueFaction or ship:GetFaction() or "neutral"))
		or "neutral"
end

function N.InterceptSolution(ship)
	if not IsValid(ship) then return nil end
	local centre = G and G.SkyboxFrame and select(1, G.SkyboxFrame()) or vector_origin
	local relative = ship:GetPos() - centre
	local velocity = ship.GetFlightVelocity and ship:GetFlightVelocity() or vector_origin
	local speed = math.max(1, tonumber(naval.InterceptSpeed) or 120)
	local a = velocity:Dot(velocity) - speed * speed
	local b = 2 * relative:Dot(velocity)
	local c = relative:Dot(relative)
	local time
	if math.abs(a) < 0.001 then
		if math.abs(b) > 0.001 then time = -c / b end
	else
		local discriminant = b * b - 4 * a * c
		if discriminant >= 0 then
			local root = math.sqrt(discriminant)
			local first = (-b - root) / (2 * a)
			local second = (-b + root) / (2 * a)
			if first > 0 and second > 0 then time = math.min(first, second)
			elseif first > 0 then time = first
			elseif second > 0 then time = second end
		end
	end
	time = math.Clamp(tonumber(time) or relative:Length() / speed, 0,
		math.max(10, tonumber(naval.InterceptMaximumSeconds) or 600))
	local predicted = relative + velocity * time
	local angle = predicted:Angle()
	local radius = 1
	if G and G.SkyboxFrame then
		local _, frameRadius = G.SkyboxFrame()
		radius = frameRadius
	end
	radius = math.max(1, tonumber(radius) or 1)
	return {
		target = ship:EntIndex(),
		name = ship:GetShipName(),
		seconds = math.Round(time),
		distance = math.Round(relative:Length()),
		bearing = math.Round(math.NormalizeAngle(angle.y)),
		elevation = math.Round(math.NormalizeAngle(angle.p)),
		x = math.Clamp(predicted.x / radius, -1.25, 1.25),
		y = math.Clamp(predicted.y / radius, -1.25, 1.25),
		closingSpeed = math.Round(speed),
	}
end

local function setIntercept(ply, entIndex)
	if not commandAllowed(ply, "navigation") and not commandAllowed(ply, "command") then
		return false, "Navigation or command watch required"
	end
	local ship = contactByIndex(entIndex)
	if not ship then return false, "Contact is no longer available" end
	N.State.interceptTarget = ship:EntIndex()
	local solution = N.InterceptSolution(ship)
	N.AddLog("navigation", "Intercept solution plotted",
		ship:GetShipName() .. " | bearing " .. tostring(solution and solution.bearing or 0)
			.. " | intercept " .. tostring(solution and solution.seconds or 0) .. " seconds.", ply)
	touch()
	return true, "Intercept solution plotted for " .. ship:GetShipName() .. "."
end

local function setTransponder(ply, mode)
	mode = N.CleanKey(mode)
	if not (naval.TransponderModes or {})[mode] then return false, "Unknown transponder mode" end
	if not commandAllowed(ply, "communications")
	and not commandAllowed(ply, "traffic_control")
	and not commandAllowed(ply, "tactical")
	and not commandAllowed(ply, "command") then
		return false, "Communications, traffic control, tactical or command watch required"
	end
	N.State.transponderMode = mode
	N.AddLog("iff", "Flagship transponder changed",
		"Republic naval transponder set to " .. string.upper(mode:gsub("_", " ")) .. ".", ply)
	touch()
	return true, "Transponder set to " .. string.upper(mode:gsub("_", " ")) .. "."
end

local function challengeContact(ply, entIndex, automatic)
	if not automatic and not commandAllowed(ply, "traffic_control")
	and not commandAllowed(ply, "tactical") and not commandAllowed(ply, "command") then
		return false, "Traffic control, tactical or command watch required"
	end
	local ship = contactByIndex(entIndex)
	if not ship then return false, "Contact is no longer available" end
	if not automatic and (ply.mb_navalIFFAt or 0) > CurTime() then
		return false, "IFF challenge array is cycling"
	end
	if IsValid(ply) then
		ply.mb_navalIFFAt = CurTime() + math.max(0.5,
			tonumber(naval.IFFChallengeCooldown) or 2)
	end
	local faction = shipFaction(ship)
	local status, detail
	if faction == "republic" then
		status, detail = "AUTHENTICATED", "Republic naval registry and encryption confirmed."
	elseif faction == "cis" then
		status, detail = "HOSTILE", "Confederate military transponder signature confirmed."
		ship:SetHostile(true)
	elseif faction == "pirate" then
		if math.Rand(0, 1) < 0.45 then
			status, detail = "FALSE ID", "Registry checksum does not match the transmitted vessel identity."
		else
			status, detail = "UNVERIFIED", "Contact declined authenticated registry exchange."
		end
	elseif faction == "civilian" then
		if math.Rand(0, 1) < 0.12 then
			status, detail = "SUSPECT", "Civilian registry responds, but cargo and route codes are inconsistent."
		else
			status, detail = "CIVILIAN VERIFIED", "Civil registry and declared route confirmed."
		end
	else
		status, detail = "UNIDENTIFIED", "No recognised transponder response received."
	end
	ship.mb_navalIFF = {
		status = status,
		detail = detail,
		challengedAt = os.time(),
	}
	if not automatic then
		N.AddLog("iff", "IFF challenge: " .. status,
			ship:GetShipName() .. " — " .. detail, ply)
	end
	touch()
	return true, ship:GetShipName() .. ": " .. status .. "."
end

local function assignDamageControl(ply, incidentID, priority)
	if not commandAllowed(ply, "engineering") and not commandAllowed(ply, "command") then
		return false, "Engineering or command watch required"
	end
	local incident = N.State.incidents[tostring(incidentID or "")]
	if not incident or incident.status == "SEALED" then return false, "Damage incident is no longer open" end
	priority = math.Clamp(math.floor(tonumber(priority) or 2), 1, 3)
	incident.priority = priority
	incident.assignment = "TEAM DISPATCHED"
	incident.assignedBy = playerName(ply)
	incident.assignedAt = os.time()
	N.AddLog("damage", "Repair team dispatched",
		string.upper(tostring(incident.system or "ship system")) .. " assigned priority "
			.. priority .. ". Physical repairs are still required.", ply)
	touch()
	return true, "Damage-control team dispatched. Physical repairs remain required."
end

local function zoneDuration(durationID)
	durationID = N.CleanKey(durationID)
	for _, entry in ipairs(naval.RestrictedZoneDurations or {}) do
		if N.CleanKey(entry.id) == durationID then
			return math.max(0, math.floor(tonumber(entry.seconds) or 0)), tostring(entry.label or durationID)
		end
	end
	return nil
end

local function persistRestrictedZone(zone)
	if not zone or not MilBase.DB then return end
	MilBase.DB.Run("REPLACE INTO " .. ZONE_TABLE
		.. " (zone_id,map_key,planet_key,zone_name,centre_x,centre_y,radius,"
		.. "created_at,expires_at,created_by) VALUES ("
		.. MilBase.SQLStr(zone.id) .. "," .. MilBase.SQLStr(mapKey()) .. ","
		.. MilBase.SQLStr(zone.planetKey) .. "," .. MilBase.SQLStr(zone.name) .. ","
		.. tonumber(zone.x or 0) .. "," .. tonumber(zone.y or 0) .. ","
		.. tonumber(zone.radius or 0.65) .. "," .. math.floor(zone.createdAt or os.time())
		.. "," .. math.floor(zone.expiresAt or 0) .. ","
		.. MilBase.SQLStr(zone.createdBy or "REPUBLIC NAVY") .. ")")
end

local function createRestrictedZone(ply, name, radiusValue, durationID)
	if naval.RestrictedZonesEnabled == false then return false, "Restricted zones are disabled" end
	if not commandAllowed(ply, "traffic_control") and not commandAllowed(ply, "command") then
		return false, "Traffic control or command watch required"
	end
	if table.Count(N.State.restrictedZones or {}) >= math.max(1,
		tonumber(naval.RestrictedZoneMaximum) or 8) then
		return false, "Maximum number of restricted zones reached"
	end
	name = string.Trim(tostring(name or "")):gsub("[%c]", "")
	if name == "" then name = "REPUBLIC CONTROLLED SPACE" end
	name = string.sub(name, 1, 64)
	local radius = tonumber(radiusValue) or tonumber(naval.RestrictedZoneDefaultRadius) or 0.65
	if radius > 1 then radius = radius / 100 end
	radius = math.Clamp(radius,
		tonumber(naval.RestrictedZoneMinimumRadius) or 0.15,
		tonumber(naval.RestrictedZoneMaximumRadius) or 1)
	local seconds, durationLabel = zoneDuration(durationID)
	if seconds == nil then return false, "Unknown restricted-zone duration" end
	local id = tostring(os.time()) .. "_" .. tostring(math.random(1000, 9999))
	local zone = {
		id = id,
		planetKey = currentPlanetKey(),
		name = string.upper(name),
		x = 0,
		y = 0,
		radius = radius,
		createdAt = os.time(),
		expiresAt = seconds > 0 and os.time() + seconds or 0,
		createdBy = playerName(ply),
		violations = {},
	}
	N.State.restrictedZones[id] = zone
	persistRestrictedZone(zone)
	N.State.trafficNotice = zone.name .. " DECLARED"
	N.AddLog("traffic", "Restricted navigation zone declared",
		zone.name .. " around " .. string.upper(zone.planetKey) .. " | radius "
			.. math.Round(zone.radius * 100) .. "% | " .. durationLabel
			.. ". Republic vessels authorised; all other traffic challenged.", ply)
	touch()
	return true, zone.name .. " is now restricted Republic-controlled space."
end

local function removeRestrictedZone(ply, zoneID)
	if not commandAllowed(ply, "traffic_control") and not commandAllowed(ply, "command") then
		return false, "Traffic control or command watch required"
	end
	zoneID = tostring(zoneID or "")
	local zone = N.State.restrictedZones[zoneID]
	if not zone then return false, "Restricted zone not found" end
	N.State.restrictedZones[zoneID] = nil
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if ship.mb_navalRestrictedZone == zoneID then ship.mb_navalRestrictedZone = nil end
	end
	MilBase.DB.Run("DELETE FROM " .. ZONE_TABLE .. " WHERE zone_id=" .. MilBase.SQLStr(zoneID))
	N.State.trafficNotice = "NORMAL TRANSIT"
	N.AddLog("traffic", "Restricted navigation zone lifted",
		zone.name .. " at " .. string.upper(zone.planetKey) .. " has been cancelled.", ply)
	touch()
	return true, zone.name .. " has been lifted."
end

local function notifyNavy(message, kind)
	for _, ply in ipairs(player.GetHumans()) do
		if N.IsNavy(ply) then MilBase.Notify(ply, message, kind or "warn") end
	end
end

local function enforceRestrictedZones()
	if naval.RestrictedZonesEnabled == false or not G or not G.SkyboxFrame then return end
	local now = os.time()
	local planetKey = currentPlanetKey()
	local centre, skyboxRadius = G.SkyboxFrame()
	skyboxRadius = math.max(1, tonumber(skyboxRadius) or 1)
	for id, zone in pairs(N.State.restrictedZones or {}) do
		if (zone.expiresAt or 0) > 0 and now >= zone.expiresAt then
			N.State.restrictedZones[id] = nil
			for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
				if ship.mb_navalRestrictedZone == id then ship.mb_navalRestrictedZone = nil end
			end
			MilBase.DB.Run("DELETE FROM " .. ZONE_TABLE .. " WHERE zone_id="
				.. MilBase.SQLStr(id))
			N.AddLog("traffic", "Restricted zone expired",
				zone.name .. " at " .. string.upper(zone.planetKey) .. " returned to normal transit.",
				"SHIP COMPUTER")
			continue
		end
		zone.violations = zone.violations or {}
		if zone.planetKey ~= planetKey then continue end
		local zoneCentre = centre + Vector((zone.x or 0) * skyboxRadius,
			(zone.y or 0) * skyboxRadius, 0)
		local worldRadius = math.max(50, (tonumber(zone.radius) or 0.65) * skyboxRadius)
		local active = {}
		for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
			if ship.mb_galaxyPersistentOffscreen or ship.mb_galaxyMapSpace then continue end
			local delta = ship:GetPos() - zoneCentre
			local inside = Vector(delta.x, delta.y, 0):LengthSqr() <= worldRadius * worldRadius
			local entID = ship:EntIndex()
			local faction = shipFaction(ship)
			if faction == "republic" then
				if inside and not ship.mb_navalIFF then
					ship.mb_navalIFF = {
						status = "AUTHENTICATED",
						detail = "Republic naval registry and encryption confirmed.",
						challengedAt = now,
					}
				end
				continue
			end
			if not inside then
				zone.violations[tostring(entID)] = nil
				if ship.mb_navalRestrictedZone == id then ship.mb_navalRestrictedZone = nil end
				continue
			end
			active[tostring(entID)] = true
			local violation = zone.violations[tostring(entID)]
			if not violation then
				challengeContact(nil, entID, true)
				violation = {
					entIndex = entID,
					name = ship:GetShipName(),
					faction = faction,
					status = faction == "cis" and "HOSTILE INCURSION" or "CHALLENGED",
					warnedAt = now,
					deadline = now + math.max(2,
						tonumber(naval.RestrictedZoneWarningSeconds) or 7),
				}
				zone.violations[tostring(entID)] = violation
				ship.mb_navalRestrictedZone = id
				if faction == "cis" then
					ship:SetHostile(true)
					ship:SetShipState("breaching Republic restricted space")
					notifyNavy("CIS INCURSION — " .. ship:GetShipName()
						.. " entered " .. zone.name .. ".", "warn")
					N.AddLog("traffic", "Hostile restricted-zone incursion",
						ship:GetShipName() .. " crossed " .. zone.name .. ".", "SENSORS")
				else
					ship:SetShipState("challenged at Republic restricted boundary")
					notifyNavy(ship:GetShipName() .. " has been ordered to leave "
						.. zone.name .. ".", "warn")
				end
			elseif faction ~= "cis" and not violation.resolved and now >= violation.deadline then
				local chance = faction == "pirate"
					and (tonumber(naval.RestrictedZonePirateCompliance) or 0.4)
					or (tonumber(naval.RestrictedZoneCivilianCompliance) or 0.9)
				violation.resolved = true
				violation.compliant = math.Rand(0, 1) <= chance
				if violation.compliant then
					local away = ship:GetPos() - zoneCentre
					if away:LengthSqr() <= 1 then away = ship:GetForward() end
					ship:SetFlightVelocity(away:GetNormalized()
						* math.max(20, tonumber(naval.RestrictedZoneDepartureSpeed) or 82))
					ship:SetShipState("complying with Republic exclusion order")
					violation.status = "REROUTING"
				else
					violation.status = "NON-COMPLIANT"
					ship:SetShipState("ignoring Republic restricted-space order")
					if faction == "pirate" then ship:SetHostile(true) end
					notifyNavy(ship:GetShipName() .. " is refusing the exclusion order.", "warn")
					N.AddLog("traffic", "Restricted-zone order refused",
						ship:GetShipName() .. " remains inside " .. zone.name .. ".", "TRAFFIC CONTROL")
				end
			elseif faction ~= "cis" and violation.resolved and violation.compliant then
				local away = ship:GetPos() - zoneCentre
				if away:LengthSqr() <= 1 then away = ship:GetForward() end
				ship:SetFlightVelocity(away:GetNormalized()
					* math.max(20, tonumber(naval.RestrictedZoneDepartureSpeed) or 82))
			elseif faction ~= "cis" and violation.resolved and not violation.compliant
			and faction ~= "pirate"
			and now >= violation.deadline
				+ math.max(2, tonumber(naval.RestrictedZoneWarningSeconds) or 7) then
				local away = ship:GetPos() - zoneCentre
				if away:LengthSqr() <= 1 then away = ship:GetForward() end
				ship:SetFlightVelocity(away:GetNormalized()
					* math.max(20, tonumber(naval.RestrictedZoneDepartureSpeed) or 82))
				ship:SetShipState("escorted from Republic restricted space")
				violation.compliant = true
				violation.status = "ESCORTED OUT"
			end
			if ship:GetHostile() then
				local nearest, nearestDistance
				for _, escort in ipairs(ents.FindByClass("mb_galaxy_ship")) do
					if shipFaction(escort) ~= "republic" or escort == ship then continue end
					local distance = escort:GetPos():DistToSqr(ship:GetPos())
					if not nearestDistance or distance < nearestDistance then
						nearest, nearestDistance = escort, distance
					end
				end
				if IsValid(nearest) and nearest.SetCombatTarget then
					nearest:SetShipState("intercepting restricted-zone violator")
					nearest:SetCombatTarget(ship, 30, 4.2)
				end
			end
		end
		for entID in pairs(zone.violations) do
			if not active[entID] then zone.violations[entID] = nil end
		end
	end
end
timer.Create("MilBase.Naval.RestrictedZones",
	math.max(0.5, tonumber(naval.RestrictedZoneCheckInterval) or 2), 0,
	enforceRestrictedZones)

local function launchRescue(ply, id)
	id = tonumber(id) or 0
	local mission = N.State.rescues[id]
	if not mission or mission.status ~= "AWAITING RESPONSE" then return false, "Rescue mission unavailable" end
	if not commandAllowed(ply, "flight_control") and not commandAllowed(ply, "medical") then
		return false, "Flight control or medical watch required"
	end
	local cost = naval.SquadronOrderCost.rescue or {}
	local ok, err = N.Spend(cost, "Search and rescue launched", ply)
	if not ok then return false, err end
	mission.status = "RESCUE TEAM EN ROUTE"
	mission.launchedAt = CurTime()
	N.AddLog("rescue", "SAR launched: " .. mission.name, mission.detail, ply)
	timer.Simple(math.Rand(25, 45), function()
		if N.State.rescues[id] ~= mission then return end
		mission.status = "SURVIVORS RECOVERED"
		mission.completedAt = os.time()
		N.ChangeResources({ funding = math.random(400, 1200), medical = math.random(5, 18) },
			"SAR recovery award", "REPUBLIC COMMAND", true)
		N.AddLog("rescue", "SAR complete: " .. mission.name,
			"Survivors recovered and transferred to medical.", "SHIP COMPUTER")
	end)
	return true
end

local nextRescueID = 1
local observedDistress = setmetatable({}, { __mode = "k" })
local observedDamage = {}
local function observeWorld()
	if #player.GetHumans() == 0 then return end
	local activeDamage = {}
	for _, class in ipairs({ "mb_shipnode", "mb_shippart", "mb_breach", "mb_terminal" }) do
		for _, ent in ipairs(ents.FindByClass(class)) do
			local broken = class == "mb_shipnode" and ent.GetBroken and ent:GetBroken()
				or class == "mb_shippart" and ent.GetDestroyed and ent:GetDestroyed()
				or class == "mb_breach" and ent.GetBreached and ent:GetBreached()
				or class == "mb_terminal" and ent.GetBroken and ent:GetBroken()
			if broken then
				local key = class .. ":" .. ent:EntIndex()
				activeDamage[key] = true
				if not observedDamage[key] then
					observedDamage[key] = true
					local system = ent.GetSystemName and ent:GetSystemName() or ""
					if system == "" then system = class:gsub("^mb_", ""):gsub("_", " ") end
					N.State.incidents[key] = {
						id = key, system = system, status = "OPEN",
						severity = class == "mb_breach" and "CRITICAL" or "DAMAGED",
						opened = os.time(),
					}
					N.AddLog("damage", "Damage control incident",
						string.upper(system) .. " requires an engineering team.", "SHIP COMPUTER")
				elseif N.State.incidents[key]
				and N.State.incidents[key].severity ~= "CRITICAL"
				and os.time() - (N.State.incidents[key].opened or os.time())
					>= (tonumber(naval.DamageEscalationInterval) or 90) then
					N.State.incidents[key].severity = "CRITICAL"
					N.AddLog("damage", "Uncontained damage escalating",
						string.upper(N.State.incidents[key].system or "SHIP SYSTEM")
							.. " has not been repaired.", "SHIP COMPUTER")
				end
			end
		end
	end
	for key in pairs(observedDamage) do
		if not activeDamage[key] then
			observedDamage[key] = nil
			if N.State.incidents[key] then
				N.State.incidents[key].status = "SEALED"
				N.State.incidents[key].closed = os.time()
				N.AddLog("damage", "Damage control complete",
					key .. " has been repaired and returned to service.", "ENGINEERING")
			end
		end
	end
	for key, incident in pairs(N.State.incidents) do
		if incident.status == "SEALED" and os.time() - (incident.closed or os.time()) > 300 then
			N.State.incidents[key] = nil
		end
	end

	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local state = string.lower(ship:GetShipState() or "")
		local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
		if (faction == "republic" or faction == "civilian")
		and (state:find("disabled", 1, true) or state:find("distress", 1, true)
			or state:find("adrift", 1, true)) and not observedDistress[ship] then
			observedDistress[ship] = true
			local id = nextRescueID
			nextRescueID = id + 1
			N.State.rescues[id] = {
				id = id, name = ship:GetShipName(), detail = ship:GetShipState(),
				status = "AWAITING RESPONSE", created = os.time(), entIndex = ship:EntIndex(),
			}
			N.AddLog("rescue", "Distress beacon detected",
				ship:GetShipName() .. " requires search and rescue support.", "SENSORS")
		end
	end
	for id, mission in pairs(N.State.rescues) do
		local age = os.time() - (mission.created or os.time())
		if mission.status == "AWAITING RESPONSE"
		and age > (tonumber(naval.RescueLifetime) or 900) then
			mission.status = "SIGNAL LOST"
			mission.completedAt = os.time()
			N.AddLog("rescue", "Distress signal lost: " .. mission.name,
				"No rescue team reached the vessel before its beacon failed.", "SHIP COMPUTER")
		elseif mission.completedAt and os.time() - mission.completedAt > 900 then
			N.State.rescues[id] = nil
		end
	end
end
timer.Create("MilBase.Naval.Observe", 5, 0, observeWorld)

local function navigationSnapshot()
	local nav = {
		planet = G and G.State and G.State.currentPlanet or "Deep Space",
		destination = G and G.PendingDestination or "",
		risk = G and G.State and tonumber(G.State.currentRisk) or 0,
		throttle = 0, targetThrottle = 0, hyperspace = false,
	}
	if istable(SWU) and IsValid(SWU.Controller) then
		local ctrl = SWU.Controller
		if ctrl.GetCurrentShipAcceleration then nav.throttle = tonumber(ctrl:GetCurrentShipAcceleration()) or 0 end
		if ctrl.GetTargetShipAcceleration then nav.targetThrottle = tonumber(ctrl:GetTargetShipAcceleration()) or 0 end
		nav.hyperspace = N.HyperspaceActive == true
		if ctrl.GetHyperspace then nav.hyperspace = nav.hyperspace or ctrl:GetHyperspace() == true end
		if ctrl.GetShipPos then
			local pos = ctrl:GetShipPos()
			if isvector(pos) then nav.universe = { x = math.Round(pos.x), y = math.Round(pos.y), z = math.Round(pos.z) } end
		end
	end
	return nav
end

hook.Add("SWU.OnHyperspaceStateChange", "MilBase.Naval.HyperspaceTelemetry",
	function(_, newState)
		N.HyperspaceActive = tonumber(newState) ~= 0
	end)

local function contactSnapshot()
	local contacts = {}
	local centre, radius = vector_origin, 1
	if G and G.SkyboxFrame then centre, radius = G.SkyboxFrame() end
	radius = math.max(1, tonumber(radius) or 1)
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if #contacts >= (tonumber(naval.MaximumContacts) or 48) then break end
		local delta = ship:GetPos() - centre
		local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
		contacts[#contacts + 1] = {
			id = ship:EntIndex(),
			name = ship:GetShipName(),
			faction = faction,
			role = ship:GetRole(),
			state = ship:GetShipState(),
			hostile = ship:GetHostile(),
			x = math.Clamp(delta.x / radius, -1, 1),
			y = math.Clamp(delta.y / radius, -1, 1),
			vx = math.Clamp(ship:GetFlightVelocity().x / 150, -1, 1),
			vy = math.Clamp(ship:GetFlightVelocity().y / 150, -1, 1),
			hull = ship:GetHullFraction(),
			shield = ship.GetShieldFraction and ship:GetShieldFraction() or 0,
			speed = math.Round(ship:GetFlightVelocity():Length()),
			iff = ship.mb_navalIFF and tostring(ship.mb_navalIFF.status or "") or "",
			iffDetail = ship.mb_navalIFF and tostring(ship.mb_navalIFF.detail or "") or "",
			restrictedZone = tostring(ship.mb_navalRestrictedZone or ""),
		}
	end
	return contacts
end

local function zoneSnapshot()
	local out = {}
	for _, zone in pairs(N.State.restrictedZones or {}) do
		local violations = {}
		for _, violation in pairs(zone.violations or {}) do
			violations[#violations + 1] = table.Copy(violation)
		end
		table.sort(violations, function(a, b)
			return tostring(a.name or "") < tostring(b.name or "")
		end)
		out[#out + 1] = {
			id = zone.id,
			planetKey = zone.planetKey,
			name = zone.name,
			x = zone.x,
			y = zone.y,
			radius = zone.radius,
			createdAt = zone.createdAt,
			expiresAt = zone.expiresAt,
			createdBy = zone.createdBy,
			violations = violations,
			localZone = zone.planetKey == currentPlanetKey(),
		}
	end
	table.sort(out, function(a, b)
		if a.localZone ~= b.localZone then return a.localZone end
		return tostring(a.name or "") < tostring(b.name or "")
	end)
	return out
end

local function hangarSnapshot()
	local deployed, damaged = 0, 0
	for ent in pairs(N.RequisitionedVehicles or {}) do
		if IsValid(ent) then
			deployed = deployed + 1
			if vehicleCondition(ent) < 0.5 then damaged = damaged + 1 end
		end
	end
	local groups = {}
	for key, group in pairs(N.HangarConfig and N.HangarConfig.groups or {}) do
		local runtime = hangarRuntime(key)
		groups[#groups + 1] = {
			id = key,
			name = group.name or string.upper(key:gsub("_", " ")),
			doorsLinked = #(group.doors or {}),
			doorsResolved = #N.ResolveHangarDoors(key),
			launchNodes = #(group.launch or {}),
			returnNodes = #(group.returnPath or {}) > 0
				and #(group.returnPath or {}) or #(group.launch or {}),
			state = runtime.state,
			message = runtime.message,
			doorsOpen = runtime.doorsOpen == true,
			blockedBy = runtime.blockedBy or "",
			activeCraft = tonumber(runtime.activeCraft) or 0,
			expectedCraft = tonumber(runtime.expectedCraft) or 0,
			completedCraft = tonumber(runtime.completedCraft) or 0,
			queuedOperations = #(runtime.queue or {}),
		}
	end
	table.sort(groups, function(a, b) return tostring(a.name) < tostring(b.name) end)
	return {
		deployedVehicles = deployed,
		damagedVehicles = damaged,
		returningVehicles = 0,
		groups = groups,
	}
end

function N.BuildSnapshot()
	local incidents = {}
	for _, incident in pairs(N.State.incidents) do incidents[#incidents + 1] = table.Copy(incident) end
	table.sort(incidents, function(a, b) return (a.opened or 0) > (b.opened or 0) end)
	local rescues = {}
	for _, mission in pairs(N.State.rescues) do rescues[#rescues + 1] = table.Copy(mission) end
	table.sort(rescues, function(a, b) return (a.id or 0) > (b.id or 0) end)
	local squadrons = {}
	for id, squadron in pairs(N.State.squadrons) do
		local target = squadronTarget(squadron)
		local visuals = cleanSquadronVisuals(squadron)
		local lead = visuals[1]
		local missionRange = IsValid(target) and IsValid(lead)
			and math.floor(lead:GetPos():Distance(target:GetPos())) or 0
		local missionSpeed = IsValid(lead)
			and math.max(1, lead:GetFlightVelocity():Length()) or 1
		local pilotName, pilotEntity = "", nil
		if N.SkyboxPilotName then
			pilotName, pilotEntity = N.SkyboxPilotName(squadron)
		end
		squadrons[id] = {
			id = id,
			name = squadron.name,
			craft = squadron.craft,
			total = squadron.total,
			ready = squadron.ready,
			order = squadron.order,
			status = squadron.status,
			deployed = squadron.visuals and #squadron.visuals or 0,
			deployedCraft = tonumber(squadron.deployedCraft) or 0,
			roe = squadron.roe,
			targetIndex = tonumber(squadron.targetIndex) or 0,
			targetName = squadron.targetName or "",
			condition = tonumber(squadron.condition) or 100,
			fuel = tonumber(squadron.fuel) or 100,
			ammunition = tonumber(squadron.ammunition) or 100,
			morale = tonumber(squadron.morale) or 100,
			experience = tonumber(squadron.experience) or 0,
			kills = tonumber(squadron.kills) or 0,
			losses = tonumber(squadron.losses) or 0,
			pilots = tonumber(squadron.pilots) or squadron.total,
			formation = squadron.formation or "vee",
			maintenanceRemaining = math.max(0,
				(tonumber(squadron.repairReadyAt) or 0) - os.time()),
			missionElapsed = math.max(0,
				os.time() - (tonumber(squadron.missionStarted) or os.time())),
			missionRange = missionRange,
			missionETA = missionRange > 0 and math.ceil(missionRange / missionSpeed) or 0,
			pilotName = tostring(pilotName or ""),
			pilotEntity = IsValid(pilotEntity) and pilotEntity:EntIndex() or 0,
			hangar = N.HangarConfig.assignments[id]
				or (naval.SquadronHangarAssignments or {})[id]
				or naval.SquadronDefaultHangarGroup or "main",
		}
	end
	local interceptShip = contactByIndex(N.State.interceptTarget)
	return {
		revision = N.State.revision,
		resources = table.Copy(N.State.resources),
		fleet = {
			groundVehicleCapacity = N.FleetVehicleCapacity
				and N.FleetVehicleCapacity() or 0,
			shipCount = N.FleetState and table.Count(N.FleetState.ships or {}) or 0,
			regimentalTier = N.RegimentalUnlockedTier
				and N.RegimentalUnlockedTier() or 1,
			formation = N.FleetState and N.FleetState.formation or "vee",
			formationRange = N.FleetState and N.FleetState.formationRange or 10,
		},
		power = table.Copy(N.State.power),
		watches = table.Copy(N.State.watches),
		logs = table.Copy(N.State.logs),
		incidents = incidents,
		rescues = rescues,
		squadrons = squadrons,
		hangar = hangarSnapshot(),
		ewMode = N.State.ewMode,
		transponderMode = N.State.transponderMode,
		fleetOrder = N.State.fleetOrder,
		trafficNotice = N.State.trafficNotice,
		navigation = navigationSnapshot(),
		contacts = contactSnapshot(),
		intercept = N.InterceptSolution(interceptShip),
		restrictedZones = zoneSnapshot(),
		serverTime = os.time(),
	}
end

function N.Broadcast(target)
	if not IsValid(target) and #player.GetHumans() == 0 then return end
	local json = util.TableToJSON(N.BuildSnapshot(), false)
	local compressed = util.Compress(json or "{}")
	if not compressed then return end
	net.Start(NET_STATE)
		net.WriteUInt(#compressed, 32)
		net.WriteData(compressed, #compressed)
	if IsValid(target) then net.Send(target) else net.Broadcast() end
end
timer.Create("MilBase.Naval.Broadcast", tonumber(naval.StateBroadcastInterval) or 1.25, 0, N.Broadcast)
hook.Add("PlayerInitialSpawn", "MilBase.Naval.InitialState", function(ply)
	timer.Simple(3, function() if IsValid(ply) then N.Broadcast(ply) end end)
end)
hook.Add("Think", "MilBase.Naval.DelayedSave", function()
	if dirtyAt and CurTime() >= dirtyAt then N.SaveState() end
end)
hook.Add("ShutDown", "MilBase.Naval.Save", function() if dirtyAt then N.SaveState() end end)

-- Connect naval power/EW to the existing live Galaxy combat and scanner.
if G and G.ShipSystemSnapshot and not G.mb_navalSystemsWrapped then
	local base = G.ShipSystemSnapshot
	G.ShipSystemSnapshot = function(...)
		local systems = base(...)
		if not istable(systems) then return systems end
		local mapping = {
			sensors = "sensors",
			communications = "communications",
			weapons = "weapons",
			engines = "engines",
			maneuver = "maneuvering",
			hyperdrive = "engines",
			shields = "shields",
		}
		for system, powerKey in pairs(mapping) do
			systems[system] = math.Clamp(math.floor((tonumber(systems[system]) or 0)
				* N.PowerFactor(powerKey)), 0, 100)
		end
		return systems
	end
	G.mb_navalSystemsWrapped = true
end
if G and G.ContactSignalStrength and not G.mb_navalSignalWrapped then
	local base = G.ContactSignalStrength
	G.ContactSignalStrength = function(ship)
		local mode = (naval.EWModes or {})[N.State.ewMode] or {}
		return base(ship) * N.PowerFactor("sensors") * (tonumber(mode.sensorMultiplier) or 1)
	end
	G.mb_navalSignalWrapped = true
end
if G and G.ShipFire and not G.mb_navalFireWrapped then
	local base = G.ShipFire
	G.ShipFire = function(ship, target, damage)
		local faction = IsValid(ship) and (ship.mb_galaxyTrueFaction or ship:GetFaction()) or ""
		if faction == "republic" then
			damage = (tonumber(damage) or 0) * N.PowerFactor("weapons")
		elseif N.State.ewMode == "jamming" then
			damage = (tonumber(damage) or 0) * 0.72
		end
		return base(ship, target, damage)
	end
	G.mb_navalFireWrapped = true
end
if G and G.TryStartRandomEncounter and not G.mb_navalMaskWrapped then
	local base = G.TryStartRandomEncounter
	G.TryStartRandomEncounter = function(reason, ...)
		if N.State.ewMode == "mask"
		and (reason == "timer" or reason == "arrival")
		and math.Rand(0, 1) < 0.4 then
			if G.ScheduleNextEncounter then G.ScheduleNextEncounter("signature mask") end
			return false, "Electronic signature mask prevented local detection."
		end
		return base(reason, ...)
	end
	G.mb_navalMaskWrapped = true
end

-- Engineering incidents remain physical: players still weld breaches and
-- repair the existing consoles. Completed work now consumes persistent parts.
timer.Simple(0, function()
	if not MilBase.EngIncidentFixed or MilBase.mb_navalRepairWrapped then return end
	local base = MilBase.EngIncidentFixed
	MilBase.EngIncidentFixed = function(ply, verb, ...)
		local cost = math.min(tonumber(naval.DamageRepairCost) or 30,
			tonumber(N.State.resources.repair) or 0)
		if cost > 0 then
			N.ChangeResources({ repair = -cost }, "Damage control parts consumed", ply, true)
		end
		N.AddLog("damage", "Engineering repair completed",
			tostring(verb or "Ship system restored") .. " | " .. cost .. " repair parts used.", ply)
		return base(ply, verb, ...)
	end
	MilBase.mb_navalRepairWrapped = true
end)

timer.Create("MilBase.Naval.EWDrain", tonumber(naval.EWDrainInterval) or 60, 0, function()
	local mode = (naval.EWModes or {})[N.State.ewMode] or {}
	local drain = tonumber(mode.drain) or 0
	if drain <= 0 then return end
	if N.State.resources.fuel < drain then
		N.State.ewMode = "passive"
		N.AddLog("tactical", "EW suite returned to passive",
			"Insufficient fuel cells for sustained electronic warfare.", "SHIP COMPUTER")
	else
		N.ChangeResources({ fuel = -drain }, "EW suite consumption", "SHIP COMPUTER", true)
	end
end)

local function respond(ply, ok, message)
	if IsValid(ply) then MilBase.Notify(ply, tostring(message or (ok and "Order accepted." or "Order denied.")),
		ok and "ok" or "warn") end
end

local commands = {}
commands.watch = function(ply, args) return N.TakeWatch(ply, args[1]) end
commands.watchleave = function(ply)
	if not IsValid(ply) then return false, "A player is required to leave a watch" end
	for key, watch in pairs(N.State.watches) do
		if watch.steamID == ply:SteamID64() then
			N.State.watches[key] = nil
			N.AddLog("watch", "Watch relieved: " .. string.upper(key), playerName(ply) .. " left station.", ply)
			return true
		end
	end
	return false, "You do not hold a watch"
end
commands.power = function(ply, args) return setPower(ply, args[1], args[2]) end
commands.ew = function(ply, args) return setEW(ply, args[1]) end
commands.squadron = function(ply, args)
	return orderSquadron(ply, args[1], args[2], args[3])
end
commands.squadronroe = function(ply, args)
	return setSquadronROE(ply, args[1], args[2])
end
commands.squadronformation = function(ply, args)
	return setSquadronFormation(ply, args[1], args[2])
end
commands.pilot = function(ply, args)
	if not N.ToggleSkyboxPiloting then return false, "Skybox pilot module is unavailable" end
	return N.ToggleSkyboxPiloting(ply, args[1])
end
commands.unpilot = function(ply)
	if not N.StopSkyboxPiloting then return false, "Skybox pilot module is unavailable" end
	return N.StopSkyboxPiloting(ply, "Skybox flight control released.")
end
commands.fleetorder = function(ply, args) return orderFleet(ply, args[1]) end
commands.traffic = function(ply, args) return trafficOrder(ply, args[1], args[2]) end
commands.rescue = function(ply, args) return launchRescue(ply, args[1]) end
commands.intercept = function(ply, args) return setIntercept(ply, args[1]) end
commands.iff = function(ply, args) return challengeContact(ply, args[1], false) end
commands.transponder = function(ply, args) return setTransponder(ply, args[1]) end
commands.damagecontrol = function(ply, args)
	return assignDamageControl(ply, args[1], args[2])
end
commands.restrict = function(ply, args)
	return createRestrictedZone(ply, table.concat(args, " ", 3), args[1], args[2])
end
commands.restrictremove = function(ply, args)
	return removeRestrictedZone(ply, args[1])
end
commands.captainslog = function(ply, args)
	if not commandAllowed(ply, "command") then return false, "Command watch required" end
	local text = string.Trim(table.concat(args, " "))
	if text == "" then return false, "Enter a log message" end
	N.AddLog("captain", "Captain's log", text, ply)
	return true
end
commands.aar = function(ply, args)
	if not commandAllowed(ply, "command") then return false, "Command watch required" end
	local text = string.Trim(table.concat(args, " "))
	if text == "" then return false, "Enter an after-action report" end
	N.AddLog("aar", "After-action report", text, ply)
	return true
end
commands.navalstatus = function(ply)
	local r = N.State.resources
	return true, "Stores — " .. N.FormatCost(r)
end

commands.hangar = function(ply, args)
	if not commandAllowed(ply, "flight_control") then
		return false, "Flight control watch required"
	end
	local group, operation = cleanHangarKey(args[1]), N.CleanKey(args[2])
	local runtime = hangarRuntime(group)
	if operation ~= "stop"
	and (runtime.operationActive
		or (tonumber(runtime.expectedCraft) or 0)
			> (tonumber(runtime.completedCraft) or 0)) then
		return false, "An automatic flight-deck operation currently owns this hangar"
	end
	if operation == "open" then
		N.OpenHangar(group, "Manual Flight Operations command")
		return true, string.upper(group) .. " hangar opening"
	elseif operation == "close" then
		N.CloseHangar(group, "Manual Flight Operations command")
		return true, string.upper(group) .. " hangar closing when clear"
	elseif operation == "stop" then
		N.StopHangarDoors(group)
		return true, string.upper(group) .. " hangar doors stopped"
	end
	return false, "Use open, close or stop"
end
commands.hangarlink = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	return N.ToggleHangarDoor(args[1], ply:GetEyeTrace().Entity)
end
commands.hangarnode = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	return N.AddHangarNode(args[1], args[2],
		ply:GetPos() + Vector(0, 0, 54), Angle(0, ply:EyeAngles().y, 0))
end
commands.hangarclear = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	return N.ClearHangarSetup(args[1], args[2])
end
commands.hangarassign = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	return N.AssignSquadronHangar(args[1], args[2])
end
commands.hangarshow = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	return N.ShowHangarSetup(ply, args[1])
end
commands.hangartest = function(ply, args)
	if not IsValid(ply) or not ply:IsAdmin() then return false, "Administrator required" end
	local group, operation = cleanHangarKey(args[1]), N.CleanKey(args[2])
	if operation == "open" then
		N.OpenHangar(group, "Hangar configuration test")
		return true, string.upper(group) .. " doors opening"
	elseif operation == "close" then
		N.CloseHangar(group, "Hangar configuration test")
		return true, string.upper(group) .. " doors closing when clear"
	elseif operation == "stop" then
		N.StopHangarDoors(group)
		return true, string.upper(group) .. " doors stopped"
	end
	return false, "Use open, close or stop"
end

function N.SendCICConsole(ply, console, feedback, feedbackOK)
	if not IsValid(ply) or not N.CanUseConsole(ply) then return false end
	local payload = {
		state = N.BuildSnapshot(),
		console = IsValid(console) and console:EntIndex() or 0,
		feedback = tostring(feedback or ""),
		feedbackOK = feedbackOK == true,
	}
	local json = util.TableToJSON(payload, false) or "{}"
	local compressed = util.Compress(json)
	if not compressed then return false end
	net.Start(NET_CONSOLE_OPEN)
		net.WriteUInt(#compressed, 32)
		net.WriteData(compressed, #compressed)
	net.Send(ply)
	return true
end

net.Receive(NET_CONSOLE_ACTION, function(_, ply)
	if not IsValid(ply) or not ply:Alive() then return end
	if (ply.mb_navalConsoleActionAt or 0) > CurTime() then return end
	ply.mb_navalConsoleActionAt = CurTime()
		+ math.max(0.1, tonumber(naval.ConsoleActionCooldown) or 0.3)
	local console = net.ReadEntity()
	local action = N.CleanKey(net.ReadString())
	local first = string.sub(net.ReadString(), 1, 128)
	local second = string.sub(net.ReadString(), 1, 128)
	local third = string.sub(net.ReadString(), 1, 128)
	if not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		return
	end
	if not IsValid(console) or console:GetClass() ~= "mb_naval_cic_screen" then
		MilBase.Notify(ply, "Use a valid CIC console.", "warn")
		return
	end
	local range = math.max(100, tonumber(naval.ConsoleUseRange) or 700)
	if ply:GetPos():DistToSqr(console:GetPos()) > range * range then
		MilBase.Notify(ply, "Remain at the CIC console.", "warn")
		return
	end
	local ok, message
	if action == "set_page" then
		console:SetPage(math.Clamp(math.floor(tonumber(first) or 0), 0, 5))
		ok, message = true, ""
	elseif action == "watch" then
		ok, message = N.TakeWatch(ply, first)
	elseif action == "squadron" then
		ok, message = orderSquadron(ply, first, second, third)
	elseif action == "squadron_roe" then
		ok, message = setSquadronROE(ply, first, second)
	elseif action == "squadron_formation" then
		ok, message = setSquadronFormation(ply, first, second)
	elseif action == "squadron_pilot" then
		if N.ToggleSkyboxPiloting then
			ok, message = N.ToggleSkyboxPiloting(ply, first)
		else
			ok, message = false, "Skybox pilot module is unavailable"
		end
	elseif action == "hangar" then
		ok, message = commands.hangar(ply, { first, second })
	elseif action == "intercept" then
		ok, message = setIntercept(ply, first)
	elseif action == "iff" then
		ok, message = challengeContact(ply, first, false)
	elseif action == "transponder" then
		ok, message = setTransponder(ply, first)
	elseif action == "damage" then
		ok, message = assignDamageControl(ply, first, second)
	elseif action == "zone_create" then
		ok, message = createRestrictedZone(ply, first, second, third)
	elseif action == "zone_remove" then
		ok, message = removeRestrictedZone(ply, first)
	elseif action == "traffic" then
		ok, message = trafficOrder(ply, first, second)
	else
		ok, message = false, "Unknown CIC command"
	end
	if message and message ~= "" then
		MilBase.Notify(ply, message, ok and "ok" or "warn")
	end
	if ok then N.Broadcast() end
	N.SendCICConsole(ply, console, message, ok)
end)

hook.Add("PlayerSay", "MilBase.Naval.ChatCommands", function(ply, text)
	local raw = string.Trim(tostring(text or ""))
	local command, tail = raw:match("^/([%w_]+)%s*(.*)$")
	command = command and string.lower(command)
	local handler = command and commands[command]
	if not handler then return end
	local setupCommand = command == "hangarlink" or command == "hangarnode"
		or command == "hangarclear" or command == "hangarassign"
		or command == "hangarshow" or command == "hangartest"
	if setupCommand and not ply:IsAdmin() then
		respond(ply, false, "Administrator required")
		return ""
	elseif not setupCommand and not N.CanUseConsole(ply) then
		respond(ply, false, "Republic Navy credentials are required")
		return ""
	end
	local args = {}
	for token in string.gmatch(tail or "", "%S+") do args[#args + 1] = token end
	local ok, message = handler(ply, args)
	respond(ply, ok, message)
	return ""
end)

for name, handler in pairs(commands) do
	concommand.Add("mb_naval_" .. name, function(ply, _, args)
		local setupCommand = name == "hangarlink" or name == "hangarnode"
			or name == "hangarclear" or name == "hangarassign"
			or name == "hangarshow" or name == "hangartest"
		if IsValid(ply) and setupCommand and not ply:IsAdmin() then
			respond(ply, false, "Administrator required")
			return
		elseif IsValid(ply) and not setupCommand and not N.CanUseConsole(ply) then
			respond(ply, false, "Republic Navy credentials are required")
			return
		end
		local ok, message = handler(ply, args or {})
		respond(ply, ok, message)
	end)
end

local function clampScreenScale(value)
	return math.Clamp(tonumber(value) or tonumber(naval.ScreenScale) or 0.135,
		tonumber(naval.ScreenMinimumScale) or 0.025,
		tonumber(naval.ScreenMaximumScale) or 0.4)
end

local function projectedPlacementMatches(posA, angA, posB, angB)
	if not isvector(posA) or not isvector(posB)
	or not isangle(angA) or not isangle(angB) then return false end
	local positionTolerance = math.max(0.25,
		tonumber(naval.ScreenDuplicatePositionTolerance) or 6)
	if posA:DistToSqr(posB) > positionTolerance * positionTolerance then return false end
	local angleTolerance = math.Clamp(
		tonumber(naval.ScreenDuplicateAngleTolerance) or 3, 0.1, 45)
	local minimumDot = math.cos(math.rad(angleTolerance))
	return angA:Up():Dot(angB:Up()) >= minimumDot
		and angA:Forward():Dot(angB:Forward()) >= minimumDot
end

local function findProjectedDuplicate(className, pos, ang, ignored)
	for _, candidate in ipairs(ents.FindByClass(className)) do
		if candidate ~= ignored and IsValid(candidate)
		and projectedPlacementMatches(pos, ang,
			candidate:GetPos(), candidate:GetAngles()) then
			return candidate
		end
	end
end

local function createScreen(pos, ang, screenID, screenScale)
	local existing = findProjectedDuplicate("mb_naval_cic_screen", pos, ang)
	if IsValid(existing) then
		if tonumber(screenID) then
			existing:SetScreenScale(clampScreenScale(screenScale))
			existing.MilBaseNavalScreenID = tonumber(screenID)
			existing.MilBaseNavalPersistent = true
			existing.MilBaseNavalSavePending = nil
		end
		return existing, true
	end
	local ent = ents.Create("mb_naval_cic_screen")
	if not IsValid(ent) then return nil, false end
	ent:SetPos(pos)
	ent:SetAngles(ang)
	ent:SetScreenScale(clampScreenScale(screenScale))
	ent:Spawn()
	ent:Activate()
	ent.MilBaseNavalScreenID = tonumber(screenID) or nil
	ent.MilBaseNavalPersistent = screenID ~= nil
	return ent, false
end

local function screenAngleForSurface(ply, normal)
	normal = isvector(normal) and Vector(normal.x, normal.y, normal.z):GetNormalized()
		or Vector(0, 0, 0)
	if normal:LengthSqr() < 0.5 then return nil end

	-- Keep +Y visually downward on tilted map screens and +X toward the
	-- placing player's right. AngleEx gives Start3D2D exactly those axes.
	local down = Vector(0, 0, -1)
	down = down - normal * down:Dot(normal)
	if down:LengthSqr() < 0.01 then
		down = IsValid(ply) and -ply:EyeAngles():Up() or Vector(0, -1, 0)
		down = down - normal * down:Dot(normal)
	end
	down:Normalize()

	local eyeRight = IsValid(ply) and ply:EyeAngles():Right() or normal:Cross(down)
	local right = eyeRight - normal * eyeRight:Dot(normal) - down * eyeRight:Dot(down)
	if right:LengthSqr() < 0.01 then right = (-down):Cross(normal) end
	right:Normalize()
	if IsValid(ply) and right:Dot(ply:EyeAngles():Right()) < 0 then right = -right end
	return right:AngleEx(right:Cross(-down))
end

local function spawnScreen(ply, requestedScale)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	if not IsValid(ply) then return false, "A player must aim at the map screen" end
	local tr = ply:GetEyeTrace()
	if not tr.Hit or not isvector(tr.HitNormal) then
		return false, "Aim at the centre of the map screen"
	end
	local ang = screenAngleForSurface(ply, tr.HitNormal)
	if not ang then return false, "That surface cannot hold a CIC display" end
	local scale = clampScreenScale(requestedScale)
	local pos = tr.HitPos + tr.HitNormal:GetNormalized()
		* (tonumber(naval.ScreenSurfaceOffset) or 0.45)
	local ent, reused = createScreen(pos, ang, nil, scale)
	if not IsValid(ent) then return false, "CIC screen entity is unavailable" end
	if tonumber(ent.MilBaseNavalScreenID) or ent.MilBaseNavalSavePending then
		return false, "A saved CIC display already exists on that surface"
	end
	if reused then ent:SetScreenScale(scale) end
	ent.MilBaseNavalPersistent = true
	ent.MilBaseNavalSavePending = true
	MilBase.DB.Insert(string.format(
		"INSERT INTO " .. SCREEN_TABLE .. " "
		.. "(map_key,pos_x,pos_y,pos_z,ang_p,ang_y,ang_r,screen_scale) "
		.. "VALUES (%s,%f,%f,%f,%f,%f,%f,%f)",
		MilBase.SQLStr(mapKey()), pos.x, pos.y, pos.z, ang.p, ang.y, ang.r, scale
	), function(id)
		if not IsValid(ent) then return end
		ent.MilBaseNavalSavePending = nil
		if not tonumber(id) then
			ent.MilBaseNavalPersistent = false
			return
		end
		ent.MilBaseNavalScreenID = tonumber(id)
		ent.MilBaseNavalPersistent = true
	end)
	return true, reused and "Existing CIC projection adopted and saved."
		or "CIC display projected onto the map screen and saved."
end
concommand.Add("mb_naval_screen", function(ply, _, args)
	respond(ply, spawnScreen(ply, args and args[1]))
end)

function N.LoadScreens()
	N.ScreenLoadGeneration = (tonumber(N.ScreenLoadGeneration) or 0) + 1
	local generation = N.ScreenLoadGeneration
	N.ScreensReady = false
	for _, ent in ipairs(ents.FindByClass("mb_naval_cic_screen")) do
		ent:Remove()
	end
	MilBase.DB.Query("SELECT * FROM " .. SCREEN_TABLE .. " WHERE map_key="
		.. MilBase.SQLStr(mapKey()) .. " ORDER BY id ASC", function(rows)
		if generation ~= N.ScreenLoadGeneration then return end
		local placements = {}
		local removedDuplicates = 0
		for _, row in ipairs(rows or {}) do
			local pos = Vector(
				tonumber(row.pos_x) or 0,
				tonumber(row.pos_y) or 0,
				tonumber(row.pos_z) or 0
			)
			local ang = Angle(
				tonumber(row.ang_p) or 0,
				tonumber(row.ang_y) or 0,
				tonumber(row.ang_r) or 0
			)
			local duplicate = false
			for _, placement in ipairs(placements) do
				if projectedPlacementMatches(pos, ang, placement.pos, placement.ang) then
					duplicate = true
					break
				end
			end
			if duplicate then
				local id = tonumber(row.id)
				if id then
					MilBase.DB.Run("DELETE FROM " .. SCREEN_TABLE .. " WHERE id=" .. id)
				end
				removedDuplicates = removedDuplicates + 1
			else
				placements[#placements + 1] = { pos = pos, ang = ang }
				createScreen(pos, ang, tonumber(row.id), tonumber(row.screen_scale))
			end
		end
		N.ScreensReady = true
		if removedDuplicates > 0 then
			MsgC(Color(120, 210, 255), "[MilBase Naval] ", color_white,
				"Removed " .. removedDuplicates .. " duplicate CIC screen database row(s).\n")
		end
	end, function()
		if generation == N.ScreenLoadGeneration then N.ScreensReady = true end
	end)
end
hook.Add("InitPostEntity", "MilBase.Naval.LoadScreens", function()
	timer.Simple(1, function()
		N.LoadScreens()
		if N.LoadPowerConsoles then N.LoadPowerConsoles() end
	end)
end)
hook.Add("PostCleanupMap", "MilBase.Naval.ReloadScreens", function()
	timer.Simple(1, function()
		N.LoadScreens()
		if N.LoadPowerConsoles then N.LoadPowerConsoles() end
	end)
end)

local function aimedProjectedScreen(ply, maximumDistance)
	if not IsValid(ply) then return nil end
	local origin = ply:EyePos()
	local direction = ply:GetAimVector()
	local best, bestDistance
	for _, ent in ipairs(ents.FindByClass("mb_naval_cic_screen")) do
		local ang = ent:GetAngles()
		local normal = ang:Up()
		local denominator = direction:Dot(normal)
		if math.abs(denominator) < 0.001 then continue end
		local distance = (ent:GetPos() - origin):Dot(normal) / denominator
		if distance < 0 or distance > (tonumber(maximumDistance) or 700) then continue end
		local hit = origin + direction * distance
		local relative = hit - ent:GetPos()
		local scale = math.max(0.001, ent:GetScreenScale())
		local x = relative:Dot(ang:Forward()) / scale
		local y = -relative:Dot(ang:Right()) / scale
		if math.abs(x) <= 512 and math.abs(y) <= 310
		and (not bestDistance or distance < bestDistance) then
			best, bestDistance = ent, distance
		end
	end
	return best
end

function N.UseCICScreen(ply, ent)
	if not IsValid(ply) or not IsValid(ent)
	or ent:GetClass() ~= "mb_naval_cic_screen" then return false end
	if (ent.mb_nextUse or 0) > CurTime() then return false end
	ent.mb_nextUse = CurTime() + 0.4
	if not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		ent:EmitSound("buttons/button10.wav", 55, 92, 0.5)
		return false
	end
	local range = math.max(100, tonumber(naval.ConsoleUseRange) or 700)
	if ply:GetPos():DistToSqr(ent:GetPos()) > range * range then return false end
	N.SendCICConsole(ply, ent)
	ent:EmitSound("buttons/lightswitch2.wav", 55, 105, 0.45)
	return true
end

hook.Add("KeyPress", "MilBase.Naval.RemoteScreenUse", function(ply, key)
	if key ~= IN_USE then return end
	if N.AimedPowerConsole and IsValid(N.AimedPowerConsole(ply,
		tonumber(naval.PowerConsoleUseRange) or 700)) then return end
	local ent = aimedProjectedScreen(ply, 700)
	if IsValid(ent) then N.UseCICScreen(ply, ent) end
end)

local function screenAtAim(ply)
	if not IsValid(ply) then return nil end
	local projected = aimedProjectedScreen(ply, 1200)
	if IsValid(projected) then return projected end
	local tr = ply:GetEyeTrace()
	if IsValid(tr.Entity) and tr.Entity:GetClass() == "mb_naval_cic_screen" then
		return tr.Entity
	end
	local maximum = tonumber(naval.ScreenSelectionRadius) or 260
	local best, bestDistance
	for _, ent in ipairs(ents.FindByClass("mb_naval_cic_screen")) do
		local distance = ent:GetPos():DistToSqr(tr.HitPos)
		if distance <= maximum * maximum and (not bestDistance or distance < bestDistance) then
			best, bestDistance = ent, distance
		end
	end
	return best
end

local function removeScreen(ply)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	if not IsValid(ply) then return false, "A player must look at the CIC screen to remove it" end
	local ent = screenAtAim(ply)
	if not IsValid(ent) then return false, "Look at the CIC display you want to remove" end
	local id = tonumber(ent.MilBaseNavalScreenID)
	if id then MilBase.DB.Run("DELETE FROM " .. SCREEN_TABLE .. " WHERE id=" .. id) end
	ent.MilBaseNavalPersistent = false
	ent:Remove()
	return true, id and "Naval CIC screen removed from this map." or "Unsaved CIC screen removed."
end
concommand.Add("mb_naval_screen_remove", function(ply) respond(ply, removeScreen(ply)) end)

local function resizeScreen(ply, requestedScale)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	if not IsValid(ply) then return false, "A player must look at the CIC display" end
	if not tonumber(requestedScale) then return false, "Enter a scale, for example 0.135" end
	local ent = screenAtAim(ply)
	if not IsValid(ent) then return false, "Look at the CIC display you want to resize" end
	local scale = clampScreenScale(requestedScale)
	ent:SetScreenScale(scale)
	local id = tonumber(ent.MilBaseNavalScreenID)
	if id then
		MilBase.DB.Run("UPDATE " .. SCREEN_TABLE .. " SET screen_scale="
			.. tostring(scale) .. " WHERE id=" .. id)
	end
	return true, "CIC display scale set to " .. string.format("%.3f", scale) .. "."
end
concommand.Add("mb_naval_screen_scale", function(ply, _, args)
	respond(ply, resizeScreen(ply, args and args[1]))
end)

hook.Add("PlayerSay", "MilBase.Naval.ScreenCommand", function(ply, text)
	local raw = string.lower(string.Trim(text or ""))
	local command, tail = raw:match("^/(navalscreen[%w]*)%s*(.*)$")
	if command ~= "navalscreen" and command ~= "navalscreenremove"
	and command ~= "navalscreenscale" and command ~= "navalscreenreload" then return end
	local ok, message
	if command == "navalscreen" then
		ok, message = spawnScreen(ply, tonumber(tail))
	elseif command == "navalscreenremove" then
		ok, message = removeScreen(ply)
	elseif command == "navalscreenscale" then
		ok, message = resizeScreen(ply, tonumber(tail))
	else
		if not commandAllowed(ply, "command") then
			ok, message = false, "Not authorised"
		else
			N.LoadScreens()
			ok, message = true, "Saved CIC displays reloaded."
		end
	end
	respond(ply, ok, message)
	return ""
end)

local function clampPowerConsoleScale(value)
	return math.Clamp(tonumber(value) or tonumber(naval.PowerConsoleScale) or 0.105,
		tonumber(naval.PowerConsoleMinimumScale) or 0.025,
		tonumber(naval.PowerConsoleMaximumScale) or 0.3)
end

local function createPowerConsole(pos, ang, consoleID, screenScale)
	local existing = findProjectedDuplicate("mb_naval_power_console", pos, ang)
	if IsValid(existing) then
		if tonumber(consoleID) then
			existing:SetScreenScale(clampPowerConsoleScale(screenScale))
			existing.MilBaseNavalPowerConsoleID = tonumber(consoleID)
			existing.MilBaseNavalPersistent = true
			existing.MilBaseNavalSavePending = nil
		end
		return existing, true
	end
	local ent = ents.Create("mb_naval_power_console")
	if not IsValid(ent) then return nil, false end
	ent:SetPos(pos)
	ent:SetAngles(ang)
	ent:SetScreenScale(clampPowerConsoleScale(screenScale))
	ent:Spawn()
	ent:Activate()
	ent.MilBaseNavalPowerConsoleID = tonumber(consoleID) or nil
	ent.MilBaseNavalPersistent = consoleID ~= nil
	return ent, false
end

function N.AimedPowerConsole(ply, maximumDistance)
	if not IsValid(ply) then return nil end
	local origin = ply:EyePos()
	local direction = ply:GetAimVector()
	local best, bestDistance
	for _, ent in ipairs(ents.FindByClass("mb_naval_power_console")) do
		local ang = ent:GetAngles()
		local normal = ang:Up()
		local denominator = direction:Dot(normal)
		if math.abs(denominator) < 0.001 then continue end
		local distance = (ent:GetPos() - origin):Dot(normal) / denominator
		if distance < 0 or distance > (tonumber(maximumDistance) or 700) then continue end
		local hit = origin + direction * distance
		local relative = hit - ent:GetPos()
		local scale = math.max(0.001, ent:GetScreenScale())
		local x = relative:Dot(ang:Forward()) / scale
		local y = -relative:Dot(ang:Right()) / scale
		if math.abs(x) <= 512 and math.abs(y) <= 310
		and (not bestDistance or distance < bestDistance) then
			best, bestDistance = ent, distance
		end
	end
	return best
end

local function powerConsoleAtAim(ply)
	if not IsValid(ply) then return nil end
	local projected = N.AimedPowerConsole(ply, 1200)
	if IsValid(projected) then return projected end
	local tr = ply:GetEyeTrace()
	local maximum = tonumber(naval.ScreenSelectionRadius) or 260
	local best, bestDistance
	for _, ent in ipairs(ents.FindByClass("mb_naval_power_console")) do
		local distance = ent:GetPos():DistToSqr(tr.HitPos)
		if distance <= maximum * maximum and (not bestDistance or distance < bestDistance) then
			best, bestDistance = ent, distance
		end
	end
	return best
end

local function spawnPowerConsole(ply, requestedScale)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	if not IsValid(ply) then return false, "A player must aim at the console screen surface" end
	local tr = ply:GetEyeTrace()
	if not tr.Hit or not isvector(tr.HitNormal) then
		return false, "Aim at the centre of the console screen"
	end
	local ang = screenAngleForSurface(ply, tr.HitNormal)
	if not ang then return false, "That surface cannot hold a power console" end
	local scale = clampPowerConsoleScale(requestedScale)
	local pos = tr.HitPos + tr.HitNormal:GetNormalized()
		* (tonumber(naval.PowerConsoleSurfaceOffset) or 0.55)
	local ent, reused = createPowerConsole(pos, ang, nil, scale)
	if not IsValid(ent) then return false, "Power console entity is unavailable" end
	if tonumber(ent.MilBaseNavalPowerConsoleID) or ent.MilBaseNavalSavePending then
		return false, "A saved power console already exists on that surface"
	end
	if reused then ent:SetScreenScale(scale) end
	ent.MilBaseNavalPersistent = true
	ent.MilBaseNavalSavePending = true
	MilBase.DB.Insert(string.format(
		"INSERT INTO " .. POWER_CONSOLE_TABLE .. " "
		.. "(map_key,pos_x,pos_y,pos_z,ang_p,ang_y,ang_r,screen_scale) "
		.. "VALUES (%s,%f,%f,%f,%f,%f,%f,%f)",
		MilBase.SQLStr(mapKey()), pos.x, pos.y, pos.z, ang.p, ang.y, ang.r, scale
	), function(id)
		if not IsValid(ent) then return end
		ent.MilBaseNavalSavePending = nil
		if not tonumber(id) then
			ent.MilBaseNavalPersistent = false
			return
		end
		ent.MilBaseNavalPowerConsoleID = tonumber(id)
		ent.MilBaseNavalPersistent = true
	end)
	return true, reused and "Existing power-console projection adopted and saved."
		or "Power distribution console projected onto the surface and saved."
end

function N.LoadPowerConsoles()
	N.PowerConsoleLoadGeneration = (tonumber(N.PowerConsoleLoadGeneration) or 0) + 1
	local generation = N.PowerConsoleLoadGeneration
	N.PowerConsolesReady = false
	for _, ent in ipairs(ents.FindByClass("mb_naval_power_console")) do ent:Remove() end
	MilBase.DB.Query("SELECT * FROM " .. POWER_CONSOLE_TABLE .. " WHERE map_key="
		.. MilBase.SQLStr(mapKey()) .. " ORDER BY id ASC", function(rows)
		if generation ~= N.PowerConsoleLoadGeneration then return end
		local placements = {}
		local removedDuplicates = 0
		for _, row in ipairs(rows or {}) do
			local pos = Vector(
				tonumber(row.pos_x) or 0,
				tonumber(row.pos_y) or 0,
				tonumber(row.pos_z) or 0
			)
			local ang = Angle(
				tonumber(row.ang_p) or 0,
				tonumber(row.ang_y) or 0,
				tonumber(row.ang_r) or 0
			)
			local duplicate = false
			for _, placement in ipairs(placements) do
				if projectedPlacementMatches(pos, ang, placement.pos, placement.ang) then
					duplicate = true
					break
				end
			end
			if duplicate then
				local id = tonumber(row.id)
				if id then
					MilBase.DB.Run("DELETE FROM " .. POWER_CONSOLE_TABLE .. " WHERE id=" .. id)
				end
				removedDuplicates = removedDuplicates + 1
			else
				placements[#placements + 1] = { pos = pos, ang = ang }
				createPowerConsole(pos, ang, tonumber(row.id), tonumber(row.screen_scale))
			end
		end
		N.PowerConsolesReady = true
		if removedDuplicates > 0 then
			MsgC(Color(120, 210, 255), "[MilBase Naval] ", color_white,
				"Removed " .. removedDuplicates .. " duplicate power-console database row(s).\n")
		end
	end, function()
		if generation == N.PowerConsoleLoadGeneration then N.PowerConsolesReady = true end
	end)
end

local projectedEntityKinds = {
	mb_naval_cic_screen = {
		idField = "MilBaseNavalScreenID",
		tableName = SCREEN_TABLE,
	},
	mb_naval_power_console = {
		idField = "MilBaseNavalPowerConsoleID",
		tableName = POWER_CONSOLE_TABLE,
	},
}

local function removeLiveProjectedDuplicate(ent, duplicate, definition)
	if not IsValid(ent) or not IsValid(duplicate) or ent == duplicate then return end
	local idField = definition.idField
	local entID = tonumber(ent[idField])
	local duplicateID = tonumber(duplicate[idField])
	local keep, remove
	if entID and not duplicateID then
		keep, remove = ent, duplicate
	elseif duplicateID and not entID then
		keep, remove = duplicate, ent
	elseif entID and duplicateID and entID ~= duplicateID then
		if entID < duplicateID then keep, remove = ent, duplicate
		else keep, remove = duplicate, ent end
	else
		if ent:EntIndex() < duplicate:EntIndex() then keep, remove = ent, duplicate
		else keep, remove = duplicate, ent end
	end

	local keepID = tonumber(keep[idField])
	local removeID = tonumber(remove[idField])
	if removeID and removeID ~= keepID then
		MilBase.DB.Run("DELETE FROM " .. definition.tableName .. " WHERE id=" .. removeID)
	end
	remove.MilBaseNavalPersistent = false
	remove.MilBaseNavalSavePending = nil
	remove:Remove()
end

-- Some prop-persistence systems restore scripted entities after InitPostEntity.
-- Catch that late copy as well as any duplicate created by overlapping async
-- database loads, keeping the database-backed entity whenever one is present.
hook.Add("OnEntityCreated", "MilBase.Naval.DeduplicateProjectedConsoles", function(ent)
	if not IsValid(ent) then return end
	local definition = projectedEntityKinds[ent:GetClass()]
	if not definition then return end
	timer.Simple(0, function()
		if not IsValid(ent) then return end
		local duplicate = findProjectedDuplicate(ent:GetClass(),
			ent:GetPos(), ent:GetAngles(), ent)
		if IsValid(duplicate) then
			removeLiveProjectedDuplicate(ent, duplicate, definition)
		end
	end)
end)

local function removePowerConsole(ply)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	local ent = powerConsoleAtAim(ply)
	if not IsValid(ent) then return false, "Look at the power console you want to remove" end
	local id = tonumber(ent.MilBaseNavalPowerConsoleID)
	if id then MilBase.DB.Run("DELETE FROM " .. POWER_CONSOLE_TABLE .. " WHERE id=" .. id) end
	ent.MilBaseNavalPersistent = false
	ent:Remove()
	return true, id and "Power distribution console removed from this map."
		or "Unsaved power console removed."
end

local function resizePowerConsole(ply, requestedScale)
	if IsValid(ply) and not commandAllowed(ply, "command") then return false, "Not authorised" end
	if not tonumber(requestedScale) then return false, "Enter a scale, for example 0.105" end
	local ent = powerConsoleAtAim(ply)
	if not IsValid(ent) then return false, "Look at the power console you want to resize" end
	local scale = clampPowerConsoleScale(requestedScale)
	ent:SetScreenScale(scale)
	local id = tonumber(ent.MilBaseNavalPowerConsoleID)
	if id then
		MilBase.DB.Run("UPDATE " .. POWER_CONSOLE_TABLE .. " SET screen_scale="
			.. tostring(scale) .. " WHERE id=" .. id)
	end
	return true, "Power console scale set to " .. string.format("%.3f", scale) .. "."
end

concommand.Add("mb_naval_power_console", function(ply, _, args)
	respond(ply, spawnPowerConsole(ply, args and args[1]))
end)
concommand.Add("mb_naval_power_console_remove", function(ply)
	respond(ply, removePowerConsole(ply))
end)
concommand.Add("mb_naval_power_console_scale", function(ply, _, args)
	respond(ply, resizePowerConsole(ply, args and args[1]))
end)
concommand.Add("mb_naval_power_console_reload", function(ply)
	if not commandAllowed(ply, "command") then respond(ply, false, "Not authorised") return end
	N.LoadPowerConsoles()
	respond(ply, true, "Saved power distribution consoles reloaded.")
end)

hook.Add("KeyPress", "MilBase.Naval.RemotePowerConsoleUse", function(ply, key)
	if key ~= IN_USE then return end
	local ent = N.AimedPowerConsole(ply, tonumber(naval.PowerConsoleUseRange) or 700)
	if IsValid(ent) then N.UsePowerConsole(ply, ent) end
end)

hook.Add("PlayerSay", "MilBase.Naval.PowerConsoleCommands", function(ply, text)
	local raw = string.lower(string.Trim(text or ""))
	local command, tail = raw:match("^/(navalpowerconsole[%w]*)%s*(.*)$")
	if command ~= "navalpowerconsole" and command ~= "navalpowerconsoleremove"
	and command ~= "navalpowerconsolescale"
	and command ~= "navalpowerconsolereload" then return end
	local ok, message
	if command == "navalpowerconsole" then
		ok, message = spawnPowerConsole(ply, tonumber(tail))
	elseif command == "navalpowerconsoleremove" then
		ok, message = removePowerConsole(ply)
	elseif command == "navalpowerconsolescale" then
		ok, message = resizePowerConsole(ply, tonumber(tail))
	else
		if not commandAllowed(ply, "command") then
			ok, message = false, "Not authorised"
		else
			N.LoadPowerConsoles()
			ok, message = true, "Saved power distribution consoles reloaded."
		end
	end
	respond(ply, ok, message)
	return ""
end)

-- Automatic campaign income/recovery creates a real reason to assist ships.
if G and G.ResolveEncounter and not G.mb_navalEncounterLogWrapped then
	local base = G.ResolveEncounter
	G.ResolveEncounter = function(outcome, details, ...)
		if G.Active and (outcome == "success" or outcome == "republic") then
			N.ChangeResources({
				funding = math.random(700, 1800),
				supplies = math.random(35, 90),
				repair = math.random(10, 35),
			}, "Republic operational award", "REPUBLIC COMMAND", true)
			N.AddLog("operations", "Encounter completed", tostring(details or outcome), "SHIP COMPUTER")
		end
		return base(outcome, details, ...)
	end
	G.mb_navalEncounterLogWrapped = true
end
if G and G.ResolveOperation and not G.mb_navalOperationLogWrapped then
	local base = G.ResolveOperation
	G.ResolveOperation = function(outcome, details, ...)
		if G.Operation and outcome == "success" then
			N.ChangeResources({ funding = math.random(900, 2400), supplies = math.random(45, 120) },
				"Fleet operation award", "REPUBLIC COMMAND", true)
		end
		if G.Operation then
			N.AddLog("operations", "Fleet operation " .. tostring(outcome),
				tostring(details or ""), "SHIP COMPUTER")
		end
		return base(outcome, details, ...)
	end
	G.mb_navalOperationLogWrapped = true
end
if G and G.ResolveRaid and not G.mb_navalRaidLogWrapped then
	local base = G.ResolveRaid
	G.ResolveRaid = function(outcome, details, actor, ...)
		if G.Active and outcome == "republic" then
			N.ChangeResources({
				funding = math.random(2200, 4800),
				supplies = math.random(120, 260),
				repair = math.random(55, 120),
				medical = math.random(20, 60),
			}, "CIS assault defence award", "REPUBLIC COMMAND", true)
			N.AddLog("operations", "CIS assault repelled",
				tostring(details or "The Republic ship held against the assault."), actor)
		end
		return base(outcome, details, actor, ...)
	end
	G.mb_navalRaidLogWrapped = true
end
