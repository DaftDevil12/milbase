--[[
	EFT-style body UI, built on the actual playermodel.

	The body panel shows the soldier's real model standing, with HP
	bar chips (name / number / bar) pinned on each limb. Click a chip
	to target that body part for first aid.

	Used in three places:
	  - The HEALTH tab in F4: your body + your medical supplies
	  - MilBase.OpenTreatMenu(target): certified medics treating someone
	    else see the PATIENT's limbs and their own med supplies
	  - meds in the GEAR tab work through right-click / double-click
]]

local cfg = MilBase.Config

MilBase.SelectedLimb = MilBase.SelectedLimb or "thorax"

local CHIP_W, CHIP_H = 78, 34

local function limbColor(cur, max)
	if cur <= 0 then
		local pulse = 30 + 22 * math.sin(RealTime() * 3)
		return Color(65 + pulse, 22, 22)
	end

	local frac = cur / max
	if frac > 0.5 then
		local t = (frac - 0.5) / 0.5 -- yellow -> white
		return Color(Lerp(t, 235, 225), Lerp(t, 205, 230), Lerp(t, 95, 235))
	end
	local t = frac / 0.5 -- red -> yellow
	return Color(Lerp(t, 215, 235), Lerp(t, 75, 205), Lerp(t, 75, 95))
end

local function limbDef(id)
	for _, l in ipairs(MilBase.Limbs or {}) do
		if l.id == id then return l end
	end
end

local iconCache = {}
local function getIcon(path)
	iconCache[path] = iconCache[path] or Material(path, "smooth")
	return iconCache[path]
end

--------------------------------------------------------------------------
-- The body panel
--------------------------------------------------------------------------

function MilBase.CreateBodyPanel(parent, target)
	target = target or LocalPlayer()

	local ui = MilBase.UI
	local panel = vgui.Create("DPanel", parent)
	local hitRects = {}

	-- The soldier's actual model, standing at ease, facing you.
	local mdl = vgui.Create("DModelPanel", panel)
	mdl:SetModel(IsValid(target) and target:GetModel() or "models/player/group01/male_02.mdl")
	mdl:SetFOV(50)
	mdl:SetCamPos(Vector(64, 0, 38))
	mdl:SetLookAt(Vector(0, 0, 36))
	mdl:SetMouseInputEnabled(false)
	function mdl:LayoutEntity(ent)
		ent:SetAngles(Angle(0, 0, 0))
	end

	if IsValid(target) and IsValid(mdl.Entity) then
		mdl.Entity:SetSkin(target:GetSkin() or 0)
		for i = 0, target:GetNumBodyGroups() - 1 do
			mdl.Entity:SetBodygroup(i, target:GetBodygroup(i))
		end
	end

	function panel:PerformLayout(w, h)
		mdl:SetPos(10, 50)
		mdl:SetSize(w - 20, h - 50 - 112)
	end

	panel.Paint = function(self, w, h)
		MilBase.PaintPanel(w, h)
		if not IsValid(target) then return end

		local faction = target:MBFaction()
		local rank = target:MBRank()

		draw.SimpleText(target:MBName(), "MB.Med", 14, 8, ui.text)
		draw.SimpleText(string.upper((rank and rank.name or "")
			.. (faction and ("  •  " .. faction.name) or "")), "MB.Tiny", 14, 31,
			faction and faction.color or ui.dim)
	end

	-- HP chips pinned on the limbs, drawn over the model.
	panel.PaintOver = function(self, w, h)
		if not IsValid(target) then return end

		local mx, my = mdl:GetPos()
		local mw, mh = mdl:GetSize()

		hitRects = {}
		for _, limb in ipairs(MilBase.Limbs or {}) do
			local x = math.floor(mx + limb.px * mw - CHIP_W / 2)
			local y = math.floor(my + limb.py * mh - CHIP_H / 2)
			hitRects[limb.id] = { x = x, y = y, w = CHIP_W, h = CHIP_H }

			local max = MilBase.LimbMax(limb.id)
			local cur = target:GetNWInt("mb_limb_" .. limb.id, max)
			local col = limbColor(cur, max)
			local selected = MilBase.SelectedLimb == limb.id

			MilBase.DrawPanelBF2(x, y, CHIP_W, CHIP_H, {
				cut = 5,
				color = Color(8, 8, 9, selected and 250 or 225),
				outlineColor = Color(col.r, col.g, col.b, 160),
			})
			if selected then
				MilBase.DrawBrackets(x - 3, y - 3, CHIP_W + 6, CHIP_H + 6, ui.accent, 7)
			end

			draw.SimpleText(limb.name, "MB.Tiny", x + 6, y + 3, ui.dim)
			draw.SimpleText(cur, "MB.Tiny", x + CHIP_W - 6, y + 3, col, TEXT_ALIGN_RIGHT)

			surface.SetDrawColor(255, 255, 255, 14)
			surface.DrawRect(x + 6, y + CHIP_H - 9, CHIP_W - 12, 4)
			surface.SetDrawColor(col)
			surface.DrawRect(x + 6, y + CHIP_H - 9,
				math.floor((CHIP_W - 12) * math.Clamp(cur / max, 0, 1)), 4)
		end

		-- Selected limb readout (bottom)
		local y0 = h - 100
		local sel = limbDef(MilBase.SelectedLimb)

		if sel then
			local max = MilBase.LimbMax(sel.id)
			local cur = target:GetNWInt("mb_limb_" .. sel.id, max)

			draw.SimpleText(sel.name, "MB.Small", 14, y0, ui.text)
			draw.SimpleText(cur .. " / " .. max, "MB.Small", w - 14, y0,
				limbColor(cur, max), TEXT_ALIGN_RIGHT)
			MilBase.DrawBar(14, y0 + 20, w - 28, 5, cur / max, limbColor(cur, max))

			local status = cur <= 0 and "DESTROYED — REQUIRES SURGERY" or nil
			if not status and target:GetNWBool("mb_fractured", false)
			and (sel.id == "left_leg" or sel.id == "right_leg") then
				status = "FRACTURED — APPLY A SPLINT"
			end
			draw.SimpleText(status or "", "MB.Tiny", 14, y0 + 30,
				cur <= 0 and ui.danger or ui.warn)
		else
			draw.SimpleText("CLICK A BODY PART TO TARGET FIRST AID", "MB.Tiny",
				w / 2, y0 + 12, ui.faint, TEXT_ALIGN_CENTER)
		end

		local flags = {}
		if target:GetNWBool("mb_bleeding", false) then table.insert(flags, "BLEEDING") end
		if target:GetNWBool("mb_fractured", false) then table.insert(flags, "FRACTURED") end
		if target:GetNWFloat("mb_painkillers", 0) > CurTime() then table.insert(flags, "PAINKILLERS") end
		draw.SimpleText(table.concat(flags, "   "), "MB.Small", 14, h - 54,
			#flags > 0 and ui.danger or ui.ok)

		draw.SimpleText("Pick a body part, then click a med from your supplies",
			"MB.Tiny", 14, h - 24, ui.faint)
	end

	panel.OnMousePressed = function(self, code)
		if code ~= MOUSE_LEFT then return end
		local mx, my = self:CursorPos()

		for _, limb in ipairs(MilBase.Limbs or {}) do
			local r = hitRects[limb.id]
			if r and mx >= r.x and mx <= r.x + r.w and my >= r.y and my <= r.y + r.h then
				MilBase.SelectedLimb = limb.id
				if MilBase.PlayUISound then MilBase.PlayUISound("hover")
				else surface.PlaySound("ui/buttonrollover.wav") end
				return
			end
		end

		MilBase.SelectedLimb = nil -- empty space: back to auto
	end

	return panel
end

--------------------------------------------------------------------------
-- Medical supplies list (pulls from stash AND backpack). onUse(uid) is
-- called when a supply is clicked.
--------------------------------------------------------------------------

function MilBase.BuildMedList(parent, onUse)
	local ui = MilBase.UI
	local meds = vgui.Create("DScrollPanel", parent)

	local lastInv

	local function rebuild()
		meds:Clear()

		local label = vgui.Create("DLabel", meds)
		label:Dock(TOP)
		label:SetFont("MB.Tiny")
		label:SetText("SUPPLIES — applied to the selected body part")
		label:SetTextColor(ui.dim)
		label:DockMargin(2, 0, 0, 8)
		label:SizeToContents()

		local pools = { MilBase.LocalInv.items }
		if MilBase.LocalInv.pack then
			table.insert(pools, MilBase.LocalInv.pack.items)
		end

		local any = false
		for _, pool in ipairs(pools) do
			for _, it in ipairs(pool) do
				local def = MilBase.Items[it.id]
				if def and def.med then
					any = true

					local row = vgui.Create("DButton", meds)
					row:Dock(TOP)
					row:SetTall(44)
					row:DockMargin(0, 0, 6, 5)
					row:SetText("")
					row.Paint = function(self, w, h)
						MilBase.DrawPanelBF2(0, 0, w, h, {
							cut = 6,
							color = self:IsHovered() and ui.hover or ui.raised,
						})
						if self:IsHovered() then
							MilBase.DrawBrackets(2, 2, w - 4, h - 4, ui.accent, 7)
						end

						local tx = 12
						if def.icon then
							surface.SetDrawColor(255, 255, 255, 235)
							surface.SetMaterial(getIcon(def.icon))
							surface.DrawTexturedRect(8, math.floor(h / 2) - 16, 32, 32)
							tx = 48
						end

						local name = def.name
						if it.charges then
							name = name .. "  [" .. it.charges .. "]"
						elseif (it.amount or 1) > 1 then
							name = name .. "  x" .. it.amount
						end

						draw.SimpleText(name, "MB.Small", tx, h / 2 - 9,
							ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						draw.SimpleText(def.desc, "MB.Tiny", tx, h / 2 + 9,
							ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						draw.SimpleText(def.med.time .. "s", "MB.Small", w - 12, h / 2,
							ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
					end
					row.DoClick = function() onUse(it.uid) end
				end
			end
		end

		if not any then
			local none = vgui.Create("DLabel", meds)
			none:Dock(TOP)
			none:SetFont("MB.Small")
			none:SetText("No medical supplies.")
			none:SetTextColor(ui.faint)
			none:SizeToContents()
		end
	end

	meds.Think = function()
		if MilBase.LocalInv ~= lastInv then
			lastInv = MilBase.LocalInv
			rebuild()
		end
	end

	rebuild()
	return meds
end

--------------------------------------------------------------------------
-- Medic treatment window (Treat quick-interaction)
--------------------------------------------------------------------------

local treatFrame

function MilBase.OpenTreatMenu(target)
	if IsValid(treatFrame) then treatFrame:Remove() end
	if not IsValid(target) or not target:IsPlayer() then return end

	local ui = MilBase.UI
	local lp = LocalPlayer()

	local frame = vgui.Create("DPanel")
	treatFrame = frame
	frame:SetSize(math.min(700, ScrW() - 120), math.min(560, ScrH() - 120))
	frame:Center()
	frame:MakePopup()

	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h)
		MilBase.DrawBrackets(0, 0, w, h, ui.accent, 14)
		draw.SimpleText("FIELD TREATMENT — " .. string.upper(target:MBName()),
			"MB.Tab", 16, 8, ui.text)
	end

	frame.Think = function(self)
		if not IsValid(target) or not target:Alive()
		or target:GetPos():DistToSqr(lp:GetPos()) > 200 * 200 then
			self:Remove()
			return
		end
		if gui.IsGameUIVisible() then
			gui.HideGameUI()
			self:Remove()
		end
	end

	local close = vgui.Create("DButton", frame)
	close:SetText("")
	close:SetSize(110, 24)
	close:SetPos(frame:GetWide() - 118, 12)
	close.Paint = function(self, w, h)
		draw.SimpleText("CLOSE  [ESC]", "MB.Tiny", w, h / 2,
			self:IsHovered() and ui.text or ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Remove() end

	local body = MilBase.CreateBodyPanel(frame, target)
	body:SetPos(14, 44)
	body:SetSize(340, frame:GetTall() - 58)

	local meds = MilBase.BuildMedList(frame, function(uid)
		MilBase.InvUse(uid, MilBase.SelectedLimb, target)
		frame:Remove() -- watch the channel bar, stay aware
	end)
	meds:SetPos(368, 44)
	meds:SetSize(frame:GetWide() - 368 - 14, frame:GetTall() - 58)
end

--------------------------------------------------------------------------
-- The HEALTH tab: your body + your supplies
--------------------------------------------------------------------------

MilBase.AddMenuTab("HEALTH", 24, function(content)
	if not MilBase.Limbs then return end

	local body = MilBase.CreateBodyPanel(content, LocalPlayer())
	body:Dock(LEFT)
	body:SetWide(math.min(380, math.floor(content:GetWide() * 0.4)))

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL)
	right:DockMargin(14, 0, 0, 0)
	right.Paint = nil

	local meds = MilBase.BuildMedList(right, function(uid)
		MilBase.InvUse(uid, MilBase.SelectedLimb)
	end)
	meds:Dock(FILL)
end)
