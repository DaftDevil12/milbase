--[[
	Server logs: combat, connections, chat, commands, economy and staff
	actions, persisted in SQLite. Staff browse them in the F4 LOGS tab
	(category filters + search). Other modules write entries with
	MilBase.Log(cat, text, ply1, ply2).

	Categories: combat, connect, chat, cmd, econ, staff.
]]

local cfg = MilBase.Config

local CATS = { "combat", "connect", "chat", "cmd", "econ", "staff" }

local CAT_COLOR = {
	combat  = Color(220, 90, 80),
	connect = Color(90, 180, 230),
	chat    = Color(200, 200, 200),
	cmd     = Color(240, 190, 70),
	econ    = Color(150, 205, 125),
	staff   = Color(180, 120, 220),
}

--------------------------------------------------------------------------
-- Server: capture + storage + query
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_LogsReq")
	util.AddNetworkString("MilBase_LogsRes")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_logs ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "time INTEGER, cat VARCHAR(32), txt TEXT, sid1 VARCHAR(32), sid2 VARCHAR(32) )")

	-- Fully wipes the logs table. TRUNCATE on MySQL is a near-instant
	-- metadata operation regardless of table size (unlike DELETE, which is
	-- what chokes once the table gets huge). SQLite has no TRUNCATE, but a
	-- WHERE-less DELETE on SQLite gets the same fast-path treatment.
	function MilBase.WipeLogs()
		if MilBase.DB.IsMySQL() then
			MilBase.DB.Run("TRUNCATE TABLE frontier_logs")
		else
			MilBase.DB.Run("DELETE FROM frontier_logs")
		end
		MsgC(Color(150, 205, 125), "[MilBase] Logs table wiped.\n")
	end

	-- Wipe on server boot.
	if cfg.LogWipeOnBoot then
		MilBase.WipeLogs()
	end

	-- Wipe on a recurring interval (default: every 6 hours) so the table
	-- never has a chance to grow large enough to choke a SQL browser again.
	if cfg.LogAutoWipeEnabled then
		timer.Create("MilBase.LogAutoWipe", cfg.LogAutoWipeInterval or 21600, 0, MilBase.WipeLogs)
	end

	-- Prune old rows on boot so the table can't grow forever (skipped when
	-- LogWipeOnBoot already handled it above).
	if not cfg.LogWipeOnBoot then
	MilBase.DB.Query("SELECT MAX(id) AS m FROM frontier_logs", function(rows)
		local maxID = tonumber(rows[1] and rows[1].m) or 0
		local keep = cfg.LogRetention or 20000
		if maxID > keep then
			MilBase.DB.Run("DELETE FROM frontier_logs WHERE id <= " .. (maxID - keep))
		end
	end)
	end

	function MilBase.Log(cat, text, ply1, ply2)
		local sid1 = IsValid(ply1) and ply1:SteamID() or ""
		local sid2 = IsValid(ply2) and ply2:SteamID() or ""
		MilBase.DB.Run(string.format(
			"INSERT INTO frontier_logs (time, cat, txt, sid1, sid2) VALUES (%d, %s, %s, %s, %s)",
			os.time(), MilBase.SQLStr(cat), MilBase.SQLStr(text), MilBase.SQLStr(sid1), MilBase.SQLStr(sid2)))
	end

	local function tag(ent)
		if not IsValid(ent) or (ent.IsWorld and ent:IsWorld()) then return "world" end

		if ent.IsPlayer and ent:IsPlayer() then
			local displayName = "player"
			if type(ent.MBName) == "function" then
				local ok, value = pcall(ent.MBName, ent)
				if ok and isstring(value) and value ~= "" then displayName = value end
			elseif type(ent.Nick) == "function" then
				local ok, value = pcall(ent.Nick, ent)
				if ok and isstring(value) and value ~= "" then displayName = value end
			end

			local steamID = "unknown"
			if type(ent.SteamID) == "function" then
				local ok, value = pcall(ent.SteamID, ent)
				if ok and isstring(value) and value ~= "" then steamID = value end
			end
			return displayName .. " (" .. steamID .. ")"
		end

		local className = "entity"
		if type(ent.GetClass) == "function" then
			local ok, value = pcall(ent.GetClass, ent)
			if ok and isstring(value) and value ~= "" then className = value end
		end
		return className
	end
	MilBase.LogTag = tag

	----------------------------------------------------------------
	-- Combat
	----------------------------------------------------------------

	hook.Add("PlayerDeath", "MilBase.LogDeath", function(victim, inflictor, attacker)
		local wep = IsValid(attacker) and attacker:IsPlayer()
			and IsValid(attacker:GetActiveWeapon()) and attacker:GetActiveWeapon():GetClass() or ""
		if attacker == victim then
			MilBase.Log("combat", tag(victim) .. " died", victim)
		else
			MilBase.Log("combat", tag(attacker) .. " killed " .. tag(victim)
				.. (wep ~= "" and (" with " .. wep) or ""), attacker, victim)
		end
	end)

	-- Player-vs-player damage, throttled per attacker->victim pair.
	hook.Add("PlayerHurt", "MilBase.LogHurt", function(victim, attacker, _, dmg)
		if not (IsValid(attacker) and attacker:IsPlayer()) or attacker == victim then return end
		attacker.mb_logHurt = attacker.mb_logHurt or {}
		if (attacker.mb_logHurt[victim] or 0) > CurTime() then return end
		attacker.mb_logHurt[victim] = CurTime() + 5
		MilBase.Log("combat", tag(attacker) .. " damaged " .. tag(victim)
			.. " (" .. math.Round(dmg) .. " dmg)", attacker, victim)
	end)

	----------------------------------------------------------------
	-- Connections & identity
	----------------------------------------------------------------

	hook.Add("PlayerInitialSpawn", "MilBase.LogJoin", function(ply)
		MilBase.Log("connect", tag(ply) .. " connected", ply)
	end)

	hook.Add("PlayerDisconnected", "MilBase.LogLeave", function(ply)
		MilBase.Log("connect", tag(ply) .. " disconnected", ply)
	end)

	----------------------------------------------------------------
	-- Chat & commands (commands are chat lines starting with "/")
	----------------------------------------------------------------

	hook.Add("PlayerSay", "MilBase.LogChat", function(ply, text)
		if string.sub(text, 1, 1) == "/" then
			MilBase.Log("cmd", tag(ply) .. " ran " .. text, ply)
		else
			MilBase.Log("chat", tag(ply) .. ": " .. text, ply)
		end
		-- return nothing: purely observational
	end)

	----------------------------------------------------------------
	-- Economy: wrap MBAddMoney once (guard against autorefresh re-wrap)
	----------------------------------------------------------------

	local PLAYER = FindMetaTable("Player")
	if PLAYER.MBAddMoney and not MilBase._logMoneyWrapped then
		MilBase._logMoneyWrapped = true
		local orig = PLAYER.MBAddMoney
		function PLAYER:MBAddMoney(amount, ...)
			if amount and amount ~= 0 then
				MilBase.Log("econ", tag(self) .. (amount > 0 and " gained " or " lost ")
					.. math.abs(amount) .. " " .. (cfg.CurrencyName or "credits"), self)
			end
			return orig(self, amount, ...)
		end
	end

	----------------------------------------------------------------
	-- Log browser requests (staff only)
	----------------------------------------------------------------

	net.Receive("MilBase_LogsReq", function(_, ply)
		if ply:MBStaffLevel() < (cfg.StaffModeLevel or 1) then return end
		if (ply.mb_nextLogReq or 0) > CurTime() then return end
		ply.mb_nextLogReq = CurTime() + 1

		local cat = net.ReadString()
		local search = net.ReadString()

		local where = {}
		if cat ~= "" and cat ~= "all" then
			where[#where + 1] = "cat = " .. MilBase.SQLStr(cat)
		end
		if search ~= "" then
			where[#where + 1] = "txt LIKE " .. MilBase.SQLStr("%" .. search .. "%")
		end

		local q = "SELECT time, cat, txt FROM frontier_logs"
			.. (#where > 0 and (" WHERE " .. table.concat(where, " AND ")) or "")
			.. " ORDER BY id DESC LIMIT 200"

		MilBase.DB.Query(q, function(rows)
			if not IsValid(ply) then return end
			local payload = util.Compress(util.TableToJSON(rows))
			net.Start("MilBase_LogsRes")
				net.WriteUInt(#payload, 24)
				net.WriteData(payload, #payload)
			net.Send(ply)
		end)
	end)

	return
end

--------------------------------------------------------------------------
-- Client: LOGS tab
--------------------------------------------------------------------------

local logRows = {}
local logList -- rebuilt on response

net.Receive("MilBase_LogsRes", function()
	local len = net.ReadUInt(24)
	local raw = util.Decompress(net.ReadData(len))
	logRows = util.JSONToTable(raw or "") or {}
	if IsValid(logList) and logList.Rebuild then logList:Rebuild() end
end)

MilBase.AddMenuTab("LOGS", 94, function(content)
	local ui = MilBase.UI
	local activeCat, search = "all", ""

	local function request()
		net.Start("MilBase_LogsReq")
			net.WriteString(activeCat)
			net.WriteString(search)
		net.SendToServer()
	end

	-- Filter bar: category chips + search + refresh.
	local bar = vgui.Create("DPanel", content)
	bar:Dock(TOP); bar:SetTall(36); bar:DockMargin(0, 0, 0, 8); bar.Paint = nil

	local chips = {}
	local function chip(label, cat)
		local b = vgui.Create("DButton", bar); b:Dock(LEFT); b:DockMargin(0, 0, 6, 0); b:SetWide(86); b:SetText("")
		b.Paint = function(s, w, h)
			local on = activeCat == cat
			local col = CAT_COLOR[cat] or ui.accent
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
				color = on and Color(col.r, col.g, col.b, 45) or ui.raised,
				accent = on and col or nil })
			draw.SimpleText(label, "MB.Small", w / 2, h / 2,
				on and ui.text or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function() activeCat = cat request() end
		chips[#chips + 1] = b
	end
	chip("ALL", "all")
	for _, c in ipairs(CATS) do chip(string.upper(c), c) end

	local refresh = vgui.Create("DButton", bar); refresh:Dock(RIGHT); refresh:SetWide(90); refresh:SetText("")
	refresh.Paint = function(s, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = s:IsHovered() and ui.hover or ui.raised, accent = ui.accent })
		draw.SimpleText("REFRESH", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	refresh.DoClick = request

	local box = vgui.Create("DTextEntry", bar)
	box:Dock(RIGHT); box:SetWide(220); box:DockMargin(0, 4, 8, 4)
	box:SetFont("MB.Small"); box:SetPaintBackground(false)
	box:SetPlaceholderText("search…")
	box.OnEnter = function(s) search = s:GetValue() request() end
	box.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end

	-- The rows. Using DListView here instead of a hand-rolled
	-- DScrollPanel + one DPanel per row: the manual approach was
	-- reliably showing only the newest row despite logRows genuinely
	-- containing every entry (confirmed via direct DB queries and
	-- debug prints at every hop). DListView is GMod's built-in,
	-- battle-tested control for exactly this "many scrollable rows"
	-- case and doesn't have that failure mode.
	local list = vgui.Create("DListView", content)
	list:Dock(FILL)
	list:SetMultiSelect(false)
	list:SetSortable(false)
	list.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 90)
		surface.DrawRect(0, 0, w, h)
	end

	list:AddColumn("Time"):SetFixedWidth(80)
	local catColumn = list:AddColumn("Category")
	catColumn:SetFixedWidth(90)
	list:AddColumn("Message")

	logList = list

	function list:Rebuild()
		self:Clear()

		if #logRows == 0 then
			local line = self:AddLine("", "", "No log entries match.")
			if IsValid(line) and IsValid(line.Columns[3]) then
				line.Columns[3]:SetTextColor(ui.faint)
			end
			return
		end

		for _, row in ipairs(logRows) do
			local line = self:AddLine(
				os.date("%H:%M:%S", tonumber(row.time) or 0),
				string.upper(row.cat or ""),
				row.txt or "")

			local col = CAT_COLOR[row.cat] or ui.dim
			if IsValid(line) then
				if IsValid(line.Columns[2]) then line.Columns[2]:SetTextColor(col) end
				if IsValid(line.Columns[3]) then line.Columns[3]:SetTextColor(ui.text) end
			end
		end
	end

	request()
end, function(lp) return lp:MBStaffLevel() >= (MilBase.Config.StaffModeLevel or 1) end)