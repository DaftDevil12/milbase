--[[
	MilBase Lightsaber Forge.

	A complete replacement for the stock LSCS control panel. LSCS remains the
	combat and inventory engine; this interface owns the player-facing Jedi
	experience and routes every mutation through MilBase's server checks.
]]

local cfg = MilBase.Config.LSCS or {}
if cfg.Enabled == false then return end

local MBLSCS = MilBase.LSCS
if not MBLSCS then return end

local PAGE_ORDER = {
	{ id = "overview", label = "OVERVIEW", subtitle = "Jedi identity and combat readiness" },
	{ id = "skills", label = "SKILL MATRIX", subtitle = "Develop Force and saber disciplines" },
	{ id = "saber", label = "SABER FORGE", subtitle = "Build right and left-hand weapons" },
	{ id = "force", label = "FORCE LOADOUT", subtitle = "Choose four active powers" },
	{ id = "forms", label = "SABER FORMS", subtitle = "Review learned combat disciplines" },
	{ id = "trials", label = "TRIALS & LEGACY", subtitle = "Mentorship, trials, and holocrons" },
	{ id = "presets", label = "LOADOUT PRESETS", subtitle = "Save complete Jedi configurations" },
}

local PAGE_LABEL = {}
for _, page in ipairs(PAGE_ORDER) do PAGE_LABEL[page.id] = page.label end

MBLSCS.ForgeSelection = MBLSCS.ForgeSelection or {
	right = { hilt = nil, crystal = nil },
	left = { hilt = nil, crystal = nil },
}
MBLSCS.ForgePage = MBLSCS.ForgePage or "overview"

local function sendAction(action, target, arg)
	net.Start("MilBase_LSCSAdvancedAction")
		net.WriteString(action or "")
		net.WriteEntity(IsValid(target) and target or game.GetWorld())
		net.WriteString(tostring(arg or ""))
	net.SendToServer()
end

local function sendPurchase(id)
	net.Start("MilBase_LSCSPurchase")
		net.WriteString(id or "")
	net.SendToServer()
end

local function connectedToWorkbench()
	local ply = LocalPlayer()
	return IsValid(ply) and math.max(ply:GetNWFloat("mb_lscs_workbench_until", 0),
		MBLSCS.WorkbenchClientUntil or 0) > CurTime()
end

local function alignmentColor(value)
	if value >= 20 then return Color(90, 175, 255) end
	if value <= -20 then return Color(220, 70, 105) end
	return Color(225, 190, 100)
end

local function itemFor(class)
	if not MBLSCS.IsInstalled() or not class then return nil end
	return MBLSCS.ClassToItem(class)
end

local function itemName(class, fallback)
	local item = itemFor(class)
	return item and (item.name or item.id) or fallback or "UNASSIGNED"
end

local function inventoryRecords(wantedType)
	local ply = LocalPlayer()
	local result = {}
	if not IsValid(ply) or not MBLSCS.IsInstalled() or not ply.lscsGetInventory then return result end
	local equipped = ply.lscsGetEquipped and ply:lscsGetEquipped() or {}
	for index, class in pairs(ply:lscsGetInventory()) do
		local item = itemFor(class)
		if item and (not wantedType or item.type == wantedType) then
			result[#result + 1] = { index = index, class = class, item = item, equipped = equipped[index] }
		end
	end
	table.sort(result, function(a, b)
		local an = string.lower(a.item.name or a.class)
		local bn = string.lower(b.item.name or b.class)
		return an == bn and a.index < b.index or an < bn
	end)
	return result
end

local function equippedSaber()
	local result = { right = {}, left = {} }
	for _, record in ipairs(inventoryRecords()) do
		if (record.item.type == "hilt" or record.item.type == "crystal") and isbool(record.equipped) then
			local side = record.equipped and result.right or result.left
			side[record.item.type] = record.class
		end
	end
	return result
end

local function ownsClass(class, wantedType)
	if not class then return false end
	for _, record in ipairs(inventoryRecords(wantedType)) do
		if record.class == class then return true end
	end
	return false
end

local function seedForgeSelection()
	local equipped = equippedSaber()
	for _, side in ipairs({ "right", "left" }) do
		local selected = MBLSCS.ForgeSelection[side]
		if not ownsClass(selected.hilt, "hilt") then selected.hilt = equipped[side].hilt end
		if not ownsClass(selected.crystal, "crystal") then selected.crystal = equipped[side].crystal end
	end
end

local function inventoryFingerprint()
	local ply = LocalPlayer()
	if not IsValid(ply) or not ply.lscsGetInventory then return "none" end
	local parts = {}
	local equipped = ply.lscsGetEquipped and ply:lscsGetEquipped() or {}
	for index, class in pairs(ply:lscsGetInventory()) do
		parts[#parts + 1] = tostring(index) .. ":" .. tostring(class) .. ":" .. tostring(equipped[index])
	end
	table.sort(parts)
	return table.concat(parts, "|")
end

local function forgeButton(parent, label, accent, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		local enabled = self:IsEnabled()
		local col = enabled and (accent or ui.accent) or ui.faint
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 7,
			color = enabled and self:IsHovered() and Color(col.r, col.g, col.b, 46) or ui.raised,
			accent = enabled and col or nil,
		})
		if enabled and self:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 7) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, enabled and ui.text or ui.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		MilBase.PlayUISound("select")
		if callback then callback() end
	end
	return button
end

local function forgeSection(parent, title, height, accent, subtitle)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(height)
	panel:DockMargin(0, 0, 8, 12)
	panel.Paint = function(_, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = ui.panel, accent = accent or ui.accent })
		draw.SimpleText(title, "MB.Tab", 18, 14, accent or ui.accent)
		if subtitle then draw.SimpleText(subtitle, "MB.Tiny", 18, 42, ui.dim) end
	end
	return panel
end

local function metricCard(parent, title, value, subtitle, accent)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(LEFT)
	panel:SetWide(215)
	panel:DockMargin(0, 0, 10, 0)
	panel.Paint = function(_, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 9, color = ui.raised, accent = accent })
		draw.SimpleText(title, "MB.Tiny", 14, 13, ui.dim)
		draw.SimpleText(value, "MB.Big", 14, 35, ui.text)
		draw.SimpleText(subtitle or "", "MB.Tiny", 14, h - 22, accent or ui.accent)
	end
	return panel
end

local function emptyMessage(parent, text)
	local label = vgui.Create("DLabel", parent)
	label:Dock(TOP)
	label:SetTall(55)
	label:SetFont("MB.Med")
	label:SetTextColor(MilBase.UI.dim)
	label:SetText(text)
	label:SetContentAlignment(5)
	return label
end

local function drawItemIcon(item, x, y, size, color)
	if not item or not item.icon or item.icon:IsError() then return false end
	surface.SetMaterial(item.icon)
	surface.SetDrawColor(color or color_white)
	surface.DrawTexturedRect(x, y, size, size)
	return true
end

local function buildOverview(parent, _, navigate)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local state = MBLSCS.AdvancedState or {}
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)

	local metrics = vgui.Create("DPanel", scroll)
	metrics:Dock(TOP) metrics:SetTall(112) metrics:DockMargin(0, 0, 8, 12) metrics.Paint = nil
	metricCard(metrics, "JEDI RANK", ply:MBJediTitle(), "LEVEL " .. ply:MBJediLevel(), ui.accent)
	metricCard(metrics, "TRAINING", tostring(ply:MBLSCSPoints()), "AVAILABLE POINTS", ui.warn)
	metricCard(metrics, "FORCE LOADOUT", MBLSCS.ActiveCount(ply) .. " / " .. (cfg.ForceSlots or 4), "ACTIVE POWERS", ui.ok)
	metricCard(metrics, "ALIGNMENT", tostring(ply:MBLSCSAlignment()), MBLSCS.AlignmentName(ply:MBLSCSAlignment()), alignmentColor(ply:MBLSCSAlignment()))

	local equipped = equippedSaber()
	local readiness = forgeSection(scroll, "COMBAT READINESS", 220, ui.accent, "Your currently assembled weapon and active Force kit")
	for index, side in ipairs({ "right", "left" }) do
		local data = equipped[side]
		local col = data.crystal and ((itemFor(data.crystal) or {}).color_blur or ui.accent) or ui.faint
		local x = 18 + (index - 1) * 390
		local card = vgui.Create("DPanel", readiness)
		card:SetPos(x, 68) card:SetSize(372, 126)
		card.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = ui.raised, accent = col })
			draw.SimpleText(string.upper(side) .. " HAND", "MB.Small", 14, 12, col)
			draw.SimpleText(itemName(data.hilt, "NO HILT"), "MB.Med", 14, 42, ui.text)
			draw.SimpleText(itemName(data.crystal, "NO CRYSTAL"), "MB.Small", 14, 73, ui.dim)
			local ready = data.hilt and data.crystal
			draw.SimpleText(ready and "SABER READY" or "ASSEMBLY REQUIRED", "MB.Tiny", 14, 102, ready and ui.ok or ui.danger)
			if ready then MilBase.DrawSkewBar(210, 82, 138, 8, 1, col, { segments = 8 }) end
		end
	end
	local forge = forgeButton(readiness, "OPEN SABER FORGE", ui.accent, function() navigate("saber") end)
	forge:SetPos(800, 80) forge:SetSize(170, 42)
	local loadout = forgeButton(readiness, "EDIT FORCE KIT", ui.ok, function() navigate("force") end)
	loadout:SetPos(800, 132) loadout:SetSize(170, 42)

	local powers = forgeSection(scroll, "ACTIVE FORCE POWERS", 76 + math.max(1, MBLSCS.ActiveCount(ply)) * 40,
		ui.ok, "Only these powers can be invoked in combat")
	local y = 64
	local found = false
	for _, id in ipairs(MBLSCS.NodeOrder or {}) do
		local node = MBLSCS.Nodes[id]
		if node and node.active and (state.active or {})[id] then
			found = true
			local allowed, reason = MBLSCS.CanLearnAdvanced(ply, node)
			local row = vgui.Create("DPanel", powers)
			row:SetPos(18, y - 5) row:SetSize(720, 34)
			row.Paint = function(_, w, h)
				draw.SimpleText(node.name, "MB.Med", 2, h / 2, allowed and ui.text or ui.danger,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(allowed and "READY" or ("SUSPENDED - " .. (reason or "requirements changed")), "MB.Tiny",
					310, h / 2, allowed and ui.ok or ui.danger, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			y = y + 40
		end
	end
	if not found then
		local none = vgui.Create("DLabel", powers)
		none:SetPos(18, 59) none:SetSize(700, 30) none:SetFont("MB.Med") none:SetTextColor(ui.dim)
		none:SetText("No Force powers are assigned. Connect to a workbench to configure your loadout.")
	end

	local actions = forgeSection(scroll, "JEDI SYSTEMS", 110, ui.warn)
	local training = forgeButton(actions, "OPEN SKILL MATRIX", ui.warn, function() navigate("skills") end)
	training:SetPos(18, 55) training:SetSize(190, 38)
	local trials = forgeButton(actions, "VIEW TRIALS", ui.accent, function() navigate("trials") end)
	trials:SetPos(220, 55) trials:SetSize(170, 38)
	local presets = forgeButton(actions, "LOADOUT PRESETS", ui.ok, function() navigate("presets") end)
	presets:SetPos(402, 55) presets:SetSize(190, 38)
end

local function buildSkillMatrix(parent)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)

	local intro = forgeSection(scroll, "JEDI SKILL MATRIX", 118, ui.warn,
		"Spend training points to unlock permanent LSCS powers, saber forms, and passive mastery.")
	intro.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = ui.panel, accent = ui.warn })
		draw.SimpleText("JEDI SKILL MATRIX", "MB.Tab", 18, 13, ui.warn)
		draw.SimpleText(ply:MBLSCSPoints() .. "", "MB.Num", 18, 47, ui.text)
		draw.SimpleText("AVAILABLE TRAINING POINTS", "MB.Tiny", 82, 66, ui.dim)
		draw.SimpleText("Rank, alignment, trials, and holocrons can gate advanced disciplines.", "MB.Small",
			w - 18, 62, ui.dim, TEXT_ALIGN_RIGHT)
	end

	for _, branchID in ipairs(MBLSCS.BranchOrder or {}) do
		local branch = MBLSCS.Branches[branchID] or { name = branchID, color = ui.accent }
		local nodes = {}
		for _, id in ipairs(MBLSCS.NodeOrder or {}) do
			local node = MBLSCS.Nodes[id]
			if node and node.branch == branchID then nodes[#nodes + 1] = { id = id, node = node } end
		end
		local panel = forgeSection(scroll, branch.name or string.upper(branchID), 70 + math.max(1, #nodes) * 112,
			branch.color or ui.accent)
		for index, data in ipairs(nodes) do
			local id, node = data.id, data.node
			local learned = (MBLSCS.ClientUnlocked or {})[id] == true
			local prereqs, missing = MBLSCS.MeetsRequirements(MBLSCS.ClientUnlocked or {}, node)
			local advanced, reason = MBLSCS.CanLearnAdvanced(ply, node)
			local affordable = ply:MBLSCSPoints() >= (node.cost or 0)
			local available = not learned and prereqs and advanced and affordable
			local col = learned and ui.ok or (available and (branch.color or ui.accent) or ui.faint)
			local row = vgui.Create("DPanel", panel)
			row:SetPos(18, 60 + (index - 1) * 112) row:SetSize(940, 98)
			row.Paint = function(_, w, h)
				MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = ui.raised, accent = col })
				draw.SimpleText(node.name, "MB.Tab", 14, 10, learned and ui.ok or ui.text)
				draw.SimpleText(node.description or "", "MB.Tiny", 14, 41, ui.dim)
				local status
				if learned then status = "MASTERED"
				elseif not prereqs then status = "REQUIRES " .. (((MBLSCS.Nodes or {})[missing] or {}).name or tostring(missing))
				elseif not advanced then status = string.upper(reason or "REQUIREMENTS NOT MET")
				elseif not affordable then status = "NEED " .. (node.cost or 0) .. " TRAINING POINTS"
				else status = "AVAILABLE FOR TRAINING" end
				draw.SimpleText(status, "MB.Small", 14, 70, col)
				draw.SimpleText((node.cost or 0) .. " POINTS", "MB.Small", w - 178, 22, ui.warn, TEXT_ALIGN_CENTER)
			end
			local learn = forgeButton(row, learned and "LEARNED" or "UNLOCK", col, function() sendPurchase(id) end)
			learn:SetPos(790, 48) learn:SetSize(135, 36) learn:SetEnabled(available)
		end
	end
end

local function itemChoiceCard(parent, record, selected, callback)
	local item = record.item
	local accent = item.type == "crystal" and (item.color_blur or MilBase.UI.accent) or MilBase.UI.accent
	local button = vgui.Create("DButton", parent)
	button:SetSize(168, 112)
	button:SetText("")
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		local active = selected()
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 8, color = active and Color(accent.r, accent.g, accent.b, 38) or ui.raised,
			accent = active and accent or nil,
		})
		if self:IsHovered() or active then MilBase.DrawBrackets(2, 2, w - 4, h - 4, accent, 8) end
		drawItemIcon(item, 12, 13, 46, active and color_white or ui.dim)
		draw.SimpleText(item.name or record.class, "MB.Small", 66, 18, active and ui.text or ui.dim)
		draw.SimpleText(string.upper(item.Type or item.type), "MB.Tiny", 66, 43, accent)
		draw.SimpleText(active and "SELECTED" or "SELECT", "MB.Tiny", 14, 86, active and ui.ok or ui.faint)
	end
	button.DoClick = function() MilBase.PlayUISound("select") callback(record) end
	return button
end

local function setPreviewModel(panel, class)
	if not IsValid(panel) then return end
	local item = itemFor(class)
	if not item or not isstring(item.mdl) or item.mdl == "" then
		panel:SetModel("models/props_lab/huladoll.mdl")
		return
	end
	panel:SetModel(item.mdl)
	local ent = panel:GetEntity()
	if not IsValid(ent) then return end
	local mn, mx = ent:GetRenderBounds()
	local center = (mn + mx) * 0.5
	local size = math.max((mx - mn):Length(), 8)
	panel:SetFOV(32)
	panel:SetCamPos(center + Vector(size * 1.35, size * 0.75, size * 0.35))
	panel:SetLookAt(center)
end

local function buildSaberForge(parent, refresh)
	seedForgeSelection()
	local ui = MilBase.UI
	local selection = MBLSCS.ForgeSelection
	local side = MBLSCS.ForgeHand or "right"
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)

	local top = forgeSection(scroll, "LIGHTSABER ASSEMBLY", 300, ui.accent,
		"Select a hand, hilt, and focusing crystal. Final assembly requires a connected workbench.")
	local preview = vgui.Create("DModelPanel", top)
	preview:SetPos(20, 70) preview:SetSize(330, 205)
	preview:SetAnimated(false)
	preview.LayoutEntity = function(_, ent) ent:SetAngles(Angle(0, (RealTime() * 18) % 360, 0)) end
	setPreviewModel(preview, selection[side].hilt)
	preview.PaintOver = function(_, w, h)
		local crystal = itemFor(selection[side].crystal)
		local col = crystal and crystal.color_blur or ui.faint
		draw.SimpleText(string.upper(side) .. "-HAND CONFIGURATION", "MB.Small", 10, 8, col)
		if selection[side].hilt and selection[side].crystal then
			MilBase.DrawSkewBar(45, h - 27, w - 90, 9, 1, col, { segments = 14 })
		end
	end

	for index, hand in ipairs({ "right", "left" }) do
		local handID = hand
		local button = forgeButton(top, string.upper(hand) .. " HAND", side == hand and ui.ok or ui.accent, function()
			MBLSCS.ForgeHand = handID
			refresh()
		end)
		button:SetPos(385 + (index - 1) * 190, 74) button:SetSize(178, 40)
	end

	local current = equippedSaber()[side]
	local info = vgui.Create("DPanel", top)
	info:SetPos(385, 132) info:SetSize(370, 142)
	info.Paint = function(_, w, h)
		local crystal = itemFor(selection[side].crystal)
		local col = crystal and crystal.color_blur or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = ui.raised, accent = col })
		draw.SimpleText("HILT", "MB.Tiny", 14, 12, ui.dim)
		draw.SimpleText(itemName(selection[side].hilt), "MB.Med", 14, 31, ui.text)
		draw.SimpleText("FOCUSING CRYSTAL", "MB.Tiny", 14, 66, ui.dim)
		draw.SimpleText(itemName(selection[side].crystal), "MB.Med", 14, 85, col)
		local changed = current.hilt ~= selection[side].hilt or current.crystal ~= selection[side].crystal
		draw.SimpleText(changed and "PENDING ASSEMBLY" or "CURRENTLY EQUIPPED", "MB.Tiny", 14, 117,
			changed and ui.warn or ui.ok)
	end

	local assemble = forgeButton(top, "ASSEMBLE " .. string.upper(side), ui.ok, function()
		local chosen = selection[side]
		if not chosen.hilt or not chosen.crystal then
			notification.AddLegacy("Select both a hilt and crystal.", NOTIFY_ERROR, 4)
			return
		end
		sendAction("craft_hand", nil, chosen.hilt .. "|" .. chosen.crystal .. "|" .. side)
	end)
	assemble:SetPos(780, 132) assemble:SetSize(190, 52) assemble:SetEnabled(connectedToWorkbench())
	local clear = forgeButton(top, "CLEAR HAND", ui.danger, function()
		Derma_Query("Remove the equipped " .. side .. "-hand saber components?", "Saber Forge",
			"CLEAR", function() sendAction("clear_hand", nil, side) end, "CANCEL")
	end)
	clear:SetPos(780, 194) clear:SetSize(190, 42) clear:SetEnabled(connectedToWorkbench())
	local hilts = inventoryRecords("hilt")
	local hiltHeight = 72 + math.max(1, math.ceil(#hilts / 5)) * 122
	local hiltSection = forgeSection(scroll, "HILT COLLECTION", hiltHeight, ui.accent,
		"Choose the weapon chassis for your " .. side .. " hand")
	if #hilts == 0 then emptyMessage(hiltSection, "No hilts in your LSCS inventory. Staff can issue one from Jedi Management.") end
	local hiltGrid = vgui.Create("DIconLayout", hiltSection)
	hiltGrid:SetPos(18, 64) hiltGrid:SetSize(920, hiltHeight - 70) hiltGrid:SetSpaceX(10) hiltGrid:SetSpaceY(10)
	for _, data in ipairs(hilts) do
		local record = data
		itemChoiceCard(hiltGrid, record, function() return selection[side].hilt == record.class end, function()
			selection[side].hilt = record.class
			refresh()
		end)
	end

	local crystals = inventoryRecords("crystal")
	local crystalHeight = 72 + math.max(1, math.ceil(#crystals / 5)) * 122
	local crystalSection = forgeSection(scroll, "CRYSTAL VAULT", crystalHeight, ui.warn,
		"The crystal determines blade identity, color, and energy profile")
	if #crystals == 0 then emptyMessage(crystalSection, "No focusing crystals in your LSCS inventory.") end
	local crystalGrid = vgui.Create("DIconLayout", crystalSection)
	crystalGrid:SetPos(18, 64) crystalGrid:SetSize(920, crystalHeight - 70) crystalGrid:SetSpaceX(10) crystalGrid:SetSpaceY(10)
	for _, data in ipairs(crystals) do
		local record = data
		itemChoiceCard(crystalGrid, record, function() return selection[side].crystal == record.class end, function()
			selection[side].crystal = record.class
			refresh()
		end)
	end
end

local function buildForceLoadout(parent, _, navigate)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local state = MBLSCS.AdvancedState or {}
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)

	local header = forgeSection(scroll, "ACTIVE FORCE MATRIX", 122, ui.ok,
		"Learn powers in the skill tree, then assign up to four at a connected workbench.")
	header.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = ui.panel, accent = ui.ok })
		draw.SimpleText("ACTIVE FORCE MATRIX", "MB.Tab", 18, 13, ui.ok)
		draw.SimpleText(MBLSCS.ActiveCount(ply) .. " / " .. (cfg.ForceSlots or 4) .. " CHANNELS ASSIGNED", "MB.Big", 18, 50, ui.text)
		draw.SimpleText(connectedToWorkbench() and "WORKBENCH LINK ACTIVE" or "READ-ONLY - CONNECT TO A WORKBENCH",
			"MB.Small", w - 18, 63, connectedToWorkbench() and ui.ok or ui.danger, TEXT_ALIGN_RIGHT)
		MilBase.DrawSkewBar(18, 97, w - 36, 9, MBLSCS.ActiveCount(ply) / math.max(cfg.ForceSlots or 4, 1), ui.ok,
			{ segments = cfg.ForceSlots or 4 })
	end

	local activeNodes = {}
	for _, id in ipairs(MBLSCS.NodeOrder or {}) do
		local node = MBLSCS.Nodes[id]
		if node and node.active then activeNodes[#activeNodes + 1] = { id = id, node = node } end
	end
	for _, data in ipairs(activeNodes) do
		local id, node = data.id, data.node
		local learned = (MBLSCS.ClientUnlocked or {})[id] == true
		local enabled = (state.active or {})[id] == true
		local allowed, reason = MBLSCS.CanLearnAdvanced(ply, node)
		local col = enabled and (allowed and ui.ok or ui.danger) or (learned and ui.accent or ui.faint)
		local row = forgeSection(scroll, node.name, 104, col, node.description or "")
		row.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 9, color = ui.panel, accent = col })
			draw.SimpleText(node.name, "MB.Tab", 18, 13, learned and ui.text or ui.faint)
			draw.SimpleText(node.description or "", "MB.Tiny", 18, 44, ui.dim)
			local gate = not learned and "NOT LEARNED" or (not allowed and (reason or "SUSPENDED") or (enabled and "ACTIVE CHANNEL" or "AVAILABLE"))
			draw.SimpleText(string.upper(gate), "MB.Small", 18, 74, col)
		end
		local toggle = forgeButton(row, enabled and "REMOVE" or "ASSIGN", col, function()
			sendAction("toggle_power", nil, id)
		end)
		toggle:SetPos(790, 31) toggle:SetSize(165, 42)
		toggle:SetEnabled(learned and connectedToWorkbench() and (enabled or allowed))
	end
	local training = forgeSection(scroll, "NEED MORE OPTIONS?", 100, ui.warn)
	local open = forgeButton(training, "OPEN JEDI SKILL MATRIX", ui.warn, function() navigate("skills") end)
	open:SetPos(18, 51) open:SetSize(220, 36)
end

local function buildForms(parent)
	local ui = MilBase.UI
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)
	local intro = forgeSection(scroll, "SABER FORM LIBRARY", 92, ui.warn,
		"Forms learned through the skill tree become available to LSCS combat automatically.")

	local found = false
	for _, id in ipairs(MBLSCS.NodeOrder or {}) do
		local node = MBLSCS.Nodes[id]
		local item = node and itemFor(node.item)
		if item and item.type == "stance" then
			found = true
			local learned = (MBLSCS.ClientUnlocked or {})[id] == true
			local col = learned and ui.warn or ui.faint
			local panel = forgeSection(scroll, item.name or node.name, 142, col, node.description)
			panel.Paint = function(_, w, h)
				MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = ui.panel, accent = col })
				drawItemIcon(item, 18, 55, 64, learned and color_white or ui.faint)
				draw.SimpleText(item.name or node.name, "MB.Big", 102, 50, learned and ui.text or ui.faint)
				draw.SimpleText(learned and "COMBAT FORM AVAILABLE" or "LOCKED IN SKILL TREE", "MB.Small", 102, 88, col)
				local support = item.LeftSaberActive and "DUAL-SABER READY" or "RIGHT-HAND DISCIPLINE"
				draw.SimpleText(support, "MB.Tiny", w - 20, 60, ui.dim, TEXT_ALIGN_RIGHT)
				draw.SimpleText(item.AutoBlock and "AUTO DEFLECTION" or "MANUAL DEFLECTION", "MB.Tiny", w - 20, 83, ui.dim, TEXT_ALIGN_RIGHT)
				if item.MaxBlockPoints then draw.SimpleText("GUARD " .. item.MaxBlockPoints, "MB.Tiny", w - 20, 106, ui.dim, TEXT_ALIGN_RIGHT) end
			end
		end
	end
	if not found then emptyMessage(scroll, "No saber forms are configured in the current LSCS package.") end
end

local function findOnlineByCharacterKey(sid)
	for _, ply in ipairs(player.GetAll()) do if ply:MBCharacterKey() == sid then return ply end end
end

local function buildTrials(parent, refresh)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local state = MBLSCS.AdvancedState or {}
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)

	local trials = forgeSection(scroll, "JEDI TRIALS", 72 + table.Count(cfg.Trials or {}) * 112, ui.warn,
		"Complete tracked objectives and receive approval from your Master or Jedi staff.")
	local trialIDs = {}
	for id in pairs(cfg.Trials or {}) do trialIDs[#trialIDs + 1] = id end
	table.sort(trialIDs)
	for index, id in ipairs(trialIDs) do
		local trialID, def = id, cfg.Trials[id]
		local progress = tonumber(((state.trials or {}).progress or {})[id]) or 0
		local complete = ((state.trials or {}).completed or {})[id] ~= nil
		local ready = ((state.trials or {}).ready or {})[id] == true
		local active = (state.trials or {}).active == id
		local col = complete and ui.ok or (ready and ui.warn or (active and ui.accent or ui.dim))
		local row = vgui.Create("DPanel", trials)
		row:SetPos(18, 66 + (index - 1) * 112) row:SetSize(940, 98)
		row.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = ui.raised, accent = col })
			draw.SimpleText(def.name, "MB.Tab", 14, 11, complete and ui.ok or ui.text)
			draw.SimpleText(def.description or "", "MB.Tiny", 14, 42, ui.dim)
			local status = complete and "COMPLETE" or (ready and "AWAITING APPROVAL" or (active and "ACTIVE" or "AVAILABLE"))
			draw.SimpleText(status, "MB.Small", 14, 68, col)
			MilBase.DrawSkewBar(520, 67, 240, 8, progress / math.max(def.target or 1, 1), col, { segments = math.min(def.target or 1, 12) })
			draw.SimpleText(progress .. " / " .. (def.target or 1), "MB.Tiny", 775, 70, ui.dim)
		end
		if not complete and not ready then
			local start = forgeButton(row, active and "ACTIVE" or "BEGIN TRIAL", col, function() sendAction("trial_start", nil, trialID) end)
			start:SetPos(790, 25) start:SetSize(135, 42)
			start:SetEnabled(not active and ply:MBJediLevel() >= (def.minLevel or 1))
		end
	end

	local mentor = forgeSection(scroll, "MASTER-PADAWAN BOND", 158, ui.accent,
		"Mentors can monitor progress and approve completed trials.")
	local master = findOnlineByCharacterKey(state.mentor or "")
	local masterName = (state.mentor or "") ~= "" and (IsValid(master) and master:MBName() or "OFFLINE MASTER") or "NO MASTER ASSIGNED"
	local masterLabel = vgui.Create("DLabel", mentor)
	masterLabel:SetPos(18, 66) masterLabel:SetSize(400, 32) masterLabel:SetFont("MB.Med") masterLabel:SetTextColor(ui.text)
	masterLabel:SetText(masterName)
	if (state.mentor or "") ~= "" then
		local endBond = forgeButton(mentor, "END BOND", ui.danger, function()
			Derma_Query("End your Master-Padawan bond?", "Jedi Order", "END BOND", function() sendAction("mentor_end", nil, "") end, "CANCEL")
		end)
		endBond:SetPos(18, 108) endBond:SetSize(145, 34)
	elseif ply:MBJediLevel() <= (cfg.PadawanMaxLevel or 2) then
		local combo = vgui.Create("DComboBox", mentor)
		combo:SetPos(430, 66) combo:SetSize(270, 34) combo:SetValue("Select an online Jedi Master")
		local selectedMaster
		for _, candidate in ipairs(player.GetAll()) do
			if candidate ~= ply and candidate:MBIsJedi() and candidate:MBJediLevel() >= (cfg.MasterLevel or 4) then
				combo:AddChoice(candidate:MBName(), candidate)
			end
		end
		combo.OnSelect = function(_, _, _, data) selectedMaster = data end
		local request = forgeButton(mentor, "REQUEST MENTOR", ui.accent, function()
			if IsValid(selectedMaster) then sendAction("mentor_request", selectedMaster, "") end
		end)
		request:SetPos(715, 66) request:SetSize(175, 34)
	end

	local archive = forgeSection(scroll, "HOLOCRON ARCHIVE", 72 + table.Count(cfg.Holocrons or {}) * 54, ui.accent,
		"Legacy knowledge remains permanently recorded on this character.")
	local holocronIDs = {}
	for id in pairs(cfg.Holocrons or {}) do holocronIDs[#holocronIDs + 1] = id end
	table.sort(holocronIDs)
	for index, id in ipairs(holocronIDs) do
		local def = cfg.Holocrons[id]
		local found = (state.discoveries or {})[id] ~= nil
		local col = found and (def.color or ui.accent) or ui.faint
		local label = vgui.Create("DLabel", archive)
		label:SetPos(20, 61 + (index - 1) * 54) label:SetSize(700, 40)
		label:SetFont("MB.Med") label:SetTextColor(col)
		label:SetText((found and "DISCOVERED" or "UNKNOWN") .. "  /  " .. string.upper(def.name))
	end
end

local function buildPresets(parent)
	local ui = MilBase.UI
	local state = MBLSCS.AdvancedState or {}
	local scroll = vgui.Create("DScrollPanel", parent)
	scroll:Dock(FILL)
	local connected = connectedToWorkbench()
	local intro = forgeSection(scroll, "JEDI LOADOUT PRESETS", 98, ui.ok,
		"Each preset stores active Force powers and both hands' equipped hilt and crystal.")
	local status = vgui.Create("DLabel", intro)
	status:SetPos(18, 62) status:SetSize(600, 24) status:SetFont("MB.Small")
	status:SetTextColor(connected and ui.ok or ui.danger)
	status:SetText(connected and "WORKBENCH LINK ACTIVE - PRESETS ARE WRITABLE" or "CONNECT TO A WORKBENCH TO SAVE OR LOAD")

	for slot = 1, cfg.PresetSlots or 3 do
		local slotID = slot
		local preset = (state.presets or {})[tostring(slot)] or {}
		local panel = forgeSection(scroll, "PRESET " .. slot, 148, ui.accent)
		local name = vgui.Create("DTextEntry", panel)
		name:SetPos(18, 55) name:SetSize(300, 36) name:SetFont("MB.Med")
		name:SetText(preset.name or ("Preset " .. slot))
		local summary = vgui.Create("DLabel", panel)
		summary:SetPos(18, 99) summary:SetSize(560, 30) summary:SetFont("MB.Tiny") summary:SetTextColor(ui.dim)
		summary:SetText(#(preset.powers or {}) .. " Force powers  /  "
			.. itemName(preset.rightHilt, "No right hilt") .. "  /  " .. itemName(preset.leftHilt, "No left hilt"))
		local save = forgeButton(panel, "SAVE CURRENT", ui.ok, function()
			sendAction("preset_save", nil, slotID .. "|" .. name:GetValue())
		end)
		save:SetPos(620, 58) save:SetSize(150, 42) save:SetEnabled(connected)
		local load = forgeButton(panel, "LOAD PRESET", ui.accent, function() sendAction("preset_load", nil, slotID) end)
		load:SetPos(780, 58) load:SetSize(150, 42) load:SetEnabled(connected and preset.name ~= nil)
	end

	local remaining = math.max(0, (tonumber(state.lastRespec) or 0) + (cfg.RespecCooldown or 21600) - os.time())
	local respec = forgeSection(scroll, "SKILL RESPECIALIZATION", 132, ui.danger,
		"Refund every learned skill point. Trials, alignment, and holocron discoveries remain.")
	local reset = forgeButton(respec, "RESET SKILL TREE", ui.danger, function()
		Derma_Query("Reset every learned LSCS skill and refund its cost?", "Confirm Jedi respec",
			"RESET TREE", function() sendAction("respec", nil, "") end, "CANCEL")
	end)
	reset:SetPos(18, 76) reset:SetSize(190, 40) reset:SetEnabled(connected and remaining <= 0)
	local cooldown = vgui.Create("DLabel", respec)
	cooldown:SetPos(225, 79) cooldown:SetSize(500, 34) cooldown:SetFont("MB.Small")
	cooldown:SetTextColor(remaining > 0 and ui.warn or ui.ok)
	cooldown:SetText(remaining > 0 and ("AVAILABLE IN " .. math.ceil(remaining / 60) .. " MINUTES") or "RESPECIALIZATION AVAILABLE")
end

local PAGE_BUILDERS = {
	overview = buildOverview,
	skills = buildSkillMatrix,
	saber = buildSaberForge,
	force = buildForceLoadout,
	forms = buildForms,
	trials = buildTrials,
	presets = buildPresets,
}

local function buildCandidate(parent)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local state = MBLSCS.AdvancedState or {}
	local panel = forgeSection(parent, "FORCE-SENSITIVE CANDIDATE", 250, ui.warn,
		"A connection to the Force has been recorded, but Jedi clearance is required.")
	panel:Dock(FILL)
	panel.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, color = ui.panel, accent = ui.warn })
		draw.SimpleText("FORCE-SENSITIVE CANDIDATE", "MB.Huge", 32, 34, ui.text)
		draw.SimpleText(ply:MBFaction().name, "MB.Med", 35, 107, ui.warn)
		draw.SimpleText("The Lightsaber Forge, Force loadout, saber forms, and Jedi training are sealed.", "MB.Med", 35, 155, ui.dim)
		draw.SimpleText("Join a faction marked as Jedi to receive Order credentials.", "MB.Med", 35, 187, ui.dim)
		draw.SimpleText(table.Count(state.discoveries or {}) .. " HOLOCRON DISCOVERIES RETAINED", "MB.Small", 35, 228, ui.accent)
	end
end

local function buildForge(content)
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if not ply:MBIsJedi() then buildCandidate(content) return end

	local ui = MilBase.UI
	local root = vgui.Create("DPanel", content)
	root:Dock(FILL)
	root.Paint = nil
	MBLSCS.ForgeContent = content

	local header = vgui.Create("DPanel", root)
	header:Dock(TOP) header:SetTall(112) header:DockMargin(0, 0, 0, 12)
	header.Paint = function(_, w, h)
		local alignment = ply:MBLSCSAlignment()
		local acol = alignmentColor(alignment)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, color = ui.panel, accent = acol })
		draw.SimpleText("LIGHTSABER FORGE", "MB.Title", 22, 9, ui.text)
		draw.SimpleText(string.upper(ply:MBJediTitle()) .. "  /  " .. string.upper(ply:MBFaction().name), "MB.Small", 25, 66, acol)
		draw.SimpleText(PAGE_LABEL[MBLSCS.ForgePage] or "OVERVIEW", "MB.Tab", w / 2, 31, ui.dim, TEXT_ALIGN_CENTER)
		draw.SimpleText(MBLSCS.AlignmentName(alignment) .. "  " .. alignment, "MB.Small", w - 22, 24, acol, TEXT_ALIGN_RIGHT)
		draw.SimpleText(connectedToWorkbench() and "WORKBENCH CONNECTED" or "FIELD MODE / READ ONLY", "MB.Small",
			w - 22, 57, connectedToWorkbench() and ui.ok or ui.danger, TEXT_ALIGN_RIGHT)
		draw.SimpleText(ply:MBLSCSPoints() .. " TRAINING POINTS", "MB.Tiny", w - 22, 85, ui.warn, TEXT_ALIGN_RIGHT)
	end

	local body = vgui.Create("DPanel", root)
	body:Dock(FILL) body.Paint = nil
	local nav = vgui.Create("DPanel", body)
	nav:Dock(LEFT) nav:SetWide(230) nav:DockMargin(0, 0, 14, 0)
	nav.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = Color(5, 9, 16, 210), accent = ui.accent })
		draw.SimpleText("JEDI SYSTEMS", "MB.Tab", 16, 14, ui.accent)
	end
	local canvas = vgui.Create("DPanel", body)
	canvas:Dock(FILL) canvas.Paint = nil

	local rebuilding = false
	local function setPage(id)
		if rebuilding or not PAGE_BUILDERS[id] then return end
		MBLSCS.ForgePage = id
		rebuilding = true
		canvas:Clear()
		PAGE_BUILDERS[id](canvas, function() setPage(MBLSCS.ForgePage) end, setPage)
		rebuilding = false
	end

	local y = 58
	for _, pageData in ipairs(PAGE_ORDER) do
		local page = pageData
		local button = vgui.Create("DButton", nav)
		button:SetPos(10, y) button:SetSize(210, 62) button:SetText("")
		button.Paint = function(self, w, h)
			local active = MBLSCS.ForgePage == page.id
			local col = active and ui.accent or (self:IsHovered() and ui.text or ui.dim)
			if active or self:IsHovered() then
				MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = active and Color(70, 145, 235, 35) or ui.raised, accent = active and ui.accent or nil })
			end
			draw.SimpleText(page.label, "MB.Small", 12, 14, col)
			draw.SimpleText(page.subtitle, "MB.Tiny", 12, 37, active and ui.dim or ui.faint)
		end
		button.DoClick = function() MilBase.PlayUISound("select") setPage(page.id) end
		y = y + 68
	end

	local help = vgui.Create("DLabel", nav)
	help:SetPos(16, y + 8) help:SetSize(196, 90) help:SetFont("MB.Tiny") help:SetTextColor(ui.faint)
	help:SetWrap(true)
	help:SetText("The Forge replaces the stock LSCS control panel. Combat remains powered by LSCS; all progression and access are controlled by MilBase.")

	local lastConnected = connectedToWorkbench()
	local lastInventory = inventoryFingerprint()
	root.Think = function(self)
		self.mb_nextCheck = self.mb_nextCheck or 0
		if self.mb_nextCheck > CurTime() then return end
		self.mb_nextCheck = CurTime() + 0.5
		local nowConnected = connectedToWorkbench()
		local nowInventory = inventoryFingerprint()
		if nowConnected ~= lastConnected or nowInventory ~= lastInventory then
			lastConnected, lastInventory = nowConnected, nowInventory
			setPage(MBLSCS.ForgePage)
		end
	end

	MBLSCS.RefreshForgeUI = function()
		if not IsValid(content) then MBLSCS.RefreshForgeUI = nil return end
		setPage(MBLSCS.ForgePage)
	end
	setPage(MBLSCS.ForgePage)
end

-- Replace the older profile tab rather than presenting two overlapping Jedi UIs.
for index = #(MilBase.MenuTabs or {}), 1, -1 do
	if MilBase.MenuTabs[index].name == "JEDI PROFILE" or MilBase.MenuTabs[index].name == "LSCS TRAINING"
	or MilBase.MenuTabs[index].name == "LIGHTSABER FORGE" then
		table.remove(MilBase.MenuTabs, index)
	end
end

if MilBase.UI and MilBase.UI.art and MilBase.UI.art.menuTabIcons then
	MilBase.UI.art.menuTabIcons["LIGHTSABER FORGE"] = MilBase.Asset("menu/f4/bfui/power.png")
end

MilBase.AddMenuTab("LIGHTSABER FORGE", 23.5, buildForge, function(lp)
	return IsValid(lp) and lp:MBIsForceSensitive()
end)

-- Redirect every stock LSCS menu entry point into the Forge. Non-sensitive
-- characters receive no inventory/control panel at all.
local redirectOpen
redirectOpen = function()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if not ply:MBIsForceSensitive() then
		notification.AddLegacy("Jedi clearance is required to access the Lightsaber Forge.", NOTIFY_ERROR, 4)
		return
	end
	if MilBase.OpenMenu then MilBase.OpenMenu("LIGHTSABER FORGE") end
end

local function installLSCSRedirect()
	if not istable(LSCS) or not isfunction(LSCS.OpenMenu) or LSCS.OpenMenu == redirectOpen then return end
	LSCS.MilBaseStockOpenMenu = LSCS.MilBaseStockOpenMenu or LSCS.OpenMenu
	LSCS.OpenMenu = redirectOpen
end

timer.Create("MilBase.LSCSForgeRedirect", 1, 0, installLSCSRedirect)
hook.Add("InitPostEntity", "MilBase.LSCSForgeRedirect", installLSCSRedirect)
hook.Add("OnReloaded", "MilBase.LSCSForgeRedirect", function() timer.Simple(0, installLSCSRedirect) end)
concommand.Add("mb_lightsaber_forge", redirectOpen)

for _, hookName in ipairs({ "LSCS:OnPlayerEquippedItem", "LSCS:OnPlayerUnEquippedItem", "LSCS:PostPlayerInventory" }) do
	hook.Add(hookName, "MilBase.LSCSForgeInventoryRefresh", function(ply)
		if ply ~= LocalPlayer() then return end
		timer.Simple(0, function()
			if isfunction(MBLSCS.RefreshForgeUI) then MBLSCS.RefreshForgeUI() end
		end)
	end)
end
