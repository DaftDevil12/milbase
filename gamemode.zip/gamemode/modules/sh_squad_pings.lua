--[[
	Squad tactical pings.

	Tap middle mouse for a contextual ping. Hold it to select a tactical
	order from the radial wheel. Players may bind another key with:
		bind <key> +mb_squad_ping
]]

if MilBase.SquadPingsLoaded then return end
MilBase.SquadPingsLoaded = true

local cfg = MilBase.Config
local NET_REQUEST = "MilBase_SquadPingRequest"
local NET_CREATE = "MilBase_SquadPingCreate"

MilBase.SquadPingTypes = MilBase.SquadPingTypes or {
	hostile = {
		label = "HOSTILE", description = "Mark enemy contact",
		glyph = "!", color = Color(230, 72, 62),
	},
	move = {
		label = "MOVE HERE", description = "Advance to this position",
		glyph = ">>", color = Color(72, 160, 235),
	},
	defend = {
		label = "DEFEND", description = "Hold and defend this position",
		glyph = "D", color = Color(245, 190, 55),
	},
	regroup = {
		label = "REGROUP", description = "Rally the squad at this point",
		glyph = "R", color = Color(90, 205, 125),
	},
	observe = {
		label = "OBSERVE", description = "Watch this contact or location",
		glyph = "O", color = Color(175, 115, 235),
	},
	assist = {
		label = "ASSIST", description = "Squadmate or position needs support",
		glyph = "+", color = Color(70, 210, 205),
	},
}

MilBase.SquadPingOrder = {
	"hostile", "move", "defend", "regroup", "observe", "assist",
}

local function pingDefinition(id)
	return MilBase.SquadPingTypes[string.lower(tostring(id or ""))]
end

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_CREATE)

	MilBase.SquadPings = MilBase.SquadPings or {}
	MilBase.NextSquadPingID = MilBase.NextSquadPingID or 0

	local function squadFor(ply)
		local name = IsValid(ply) and ply:GetNWString("mb_squad", "") or ""
		return name ~= "" and MilBase.Squads and MilBase.Squads[name] or nil
	end

	local function activeMembers(squad)
		local result = {}
		for _, member in ipairs(squad and squad.members or {}) do
			if IsValid(member) and member:IsPlayer() and member:Alive()
			and member:GetNWString("mb_squad", "") == squad.name then
				result[#result + 1] = member
			end
		end
		return result
	end

	local function pruneSquadPings(squadName)
		local list = MilBase.SquadPings[squadName] or {}
		local now = CurTime()
		for index = #list, 1, -1 do
			if (tonumber(list[index].expiresAt) or 0) <= now then
				table.remove(list, index)
			end
		end
		local maximum = math.max(1,
			math.floor(tonumber(cfg.SquadPingMaximumActive) or 8))
		while #list >= maximum do table.remove(list, 1) end
		MilBase.SquadPings[squadName] = list
		return list
	end

	local function tracePing(ply, pingType)
		local maximum = math.max(500,
			tonumber(cfg.SquadPingMaximumRange) or 18000)
		local trace = util.TraceLine({
			start = ply:EyePos(),
			endpos = ply:EyePos() + ply:GetAimVector() * maximum,
			filter = ply,
			mask = MASK_SHOT,
		})
		local target = trace.Entity
		if not IsValid(target) or target:IsWorld() then target = NULL end
		if pingType ~= "hostile" and pingType ~= "assist"
		and pingType ~= "observe" then target = NULL end
		local position = IsValid(target) and target:WorldSpaceCenter() or trace.HitPos
		if not isvector(position) then return nil end
		return position, target
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if not cfg.SquadsEnabled or cfg.SquadPingsEnabled == false then return end
		if not IsValid(ply) or not ply:Alive()
		or ply:GetNWBool("mb_wounded", false)
		or ply:GetNWBool("mb_cuffed", false)
		or ply:GetNWBool("mb_eventmode", false) then return end
		local squad = squadFor(ply)
		if not squad then
			MilBase.Notify(ply, "Join a squad before using tactical pings.", "warn")
			return
		end
		local pingType = string.lower(string.sub(net.ReadString(), 1, 16))
		local definition = pingDefinition(pingType)
		if not definition then return end
		local now = CurTime()
		if now < (ply.mb_nextSquadPingAt or 0) then return end
		ply.mb_nextSquadPingAt = now
			+ math.max(0.2, tonumber(cfg.SquadPingCooldown) or 0.65)
		local position, target = tracePing(ply, pingType)
		if not isvector(position) then return end
		local lifetime = pingType == "hostile"
			and math.max(2, tonumber(cfg.SquadPingHostileLifetime) or 10)
			or math.max(2, tonumber(cfg.SquadPingLifetime) or 8)
		MilBase.NextSquadPingID = (MilBase.NextSquadPingID % 65535) + 1
		local ping = {
			id = MilBase.NextSquadPingID,
			type = pingType,
			position = position,
			target = target,
			sender = ply,
			senderName = string.sub(ply:MBName(), 1, 72),
			leader = squad.leader == ply,
			squadName = squad.name,
			expiresAt = now + lifetime,
		}
		local list = pruneSquadPings(squad.name)
		list[#list + 1] = ping
		local recipients = activeMembers(squad)
		if #recipients == 0 then return end
		net.Start(NET_CREATE)
			net.WriteUInt(ping.id, 16)
			net.WriteString(ping.type)
			net.WriteString(string.sub(ping.squadName, 1, 20))
			net.WriteVector(ping.position)
			net.WriteEntity(IsValid(ping.target) and ping.target or NULL)
			net.WriteEntity(ply)
			net.WriteString(ping.senderName)
			net.WriteBool(ping.leader)
			net.WriteFloat(lifetime)
		net.Send(recipients)
	end)

	hook.Add("PlayerDisconnected", "MilBase.SquadPingCleanup", function(ply)
		for squadName, list in pairs(MilBase.SquadPings or {}) do
			for index = #list, 1, -1 do
				if list[index].sender == ply then table.remove(list, index) end
			end
			if #list == 0 then MilBase.SquadPings[squadName] = nil end
		end
	end)

	timer.Create("MilBase.SquadPingExpiry", 15, 0, function()
		local now = CurTime()
		for squadName, list in pairs(MilBase.SquadPings or {}) do
			if not MilBase.Squads or not MilBase.Squads[squadName] then
				MilBase.SquadPings[squadName] = nil
			else
				for index = #list, 1, -1 do
					if (tonumber(list[index].expiresAt) or 0) <= now then
						table.remove(list, index)
					end
				end
				if #list == 0 then MilBase.SquadPings[squadName] = nil end
			end
		end
	end)

	return
end

local pings = {}
local inputState
local mouseWasDown = false
local mouseConvar = CreateClientConVar("cl_mb_squad_ping_mouse", "1", true, false,
	"Use middle mouse for squad quick pings and the tactical order wheel.")
local beamMaterial = Material("sprites/laserbeam")
local glowMaterial = Material("sprites/light_glow02_add")

local function canPing()
	local ply = LocalPlayer()
	return cfg.SquadsEnabled and cfg.SquadPingsEnabled ~= false
		and IsValid(ply) and ply:Alive()
		and ply:GetNWString("mb_squad", "") ~= ""
		and not ply:GetNWBool("mb_wounded", false)
		and not ply:GetNWBool("mb_cuffed", false)
		and not (MilBase.InEventView and MilBase.InEventView())
end

local function looksHostile(entity, ply)
	if not IsValid(entity) then return false end
	if entity:IsPlayer() then
		return MilBase.IsEventEnemy and MilBase.IsEventEnemy(entity)
	end
	if entity.GetHostile and entity:GetHostile() then return true end
	if entity.GetFaction
	and string.lower(tostring(entity:GetFaction() or "")) == "cis" then return true end
	if entity:IsNPC() then
		local disposition = entity:Disposition(ply)
		return disposition == D_HT or disposition == D_FR
	end
	return entity.IsNextBot and entity:IsNextBot()
end

local function contextualPing()
	local ply = LocalPlayer()
	local trace = ply:GetEyeTrace()
	local target = trace.Entity
	if looksHostile(target, ply) then return "hostile" end
	if IsValid(target) and target:IsPlayer()
	and target:GetNWString("mb_squad", "") == ply:GetNWString("mb_squad", "")
	and (target:GetNWBool("mb_wounded", false)
		or target:Health() < math.max(1, target:GetMaxHealth()) * 0.5) then
		return "assist"
	end
	return "move"
end

local function sendPing(pingType)
	if not canPing() or not pingDefinition(pingType) then return end
	net.Start(NET_REQUEST)
		net.WriteString(pingType)
	net.SendToServer()
end

local function closeWheel()
	if inputState and inputState.radial then gui.EnableScreenClicker(false) end
	inputState = nil
end

local function beginPing(source)
	if inputState or not canPing() then return end
	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible()
	or vgui.CursorVisible() then return end
	inputState = {
		source = source,
		startedAt = CurTime(),
		radial = false,
		selected = nil,
		previous = nil,
	}
end

local function finishPing(source)
	if not inputState or inputState.source ~= source then return end
	local state = inputState
	local pingType = state.radial and state.selected or contextualPing()
	closeWheel()
	if pingType then
		if MilBase.PlayUISound then MilBase.PlayUISound("select") end
		sendPing(pingType)
	end
end

concommand.Add("+mb_squad_ping", function() beginPing("bind") end)
concommand.Add("-mb_squad_ping", function() finishPing("bind") end)
concommand.Add("mb_squad_ping", function(_, _, args)
	local requested = string.lower(tostring(args and args[1] or ""))
	sendPing(pingDefinition(requested) and requested or contextualPing())
end)

hook.Add("Think", "MilBase.SquadPingInput", function()
	local mouseDown = mouseConvar:GetBool() and input.IsMouseDown(MOUSE_MIDDLE)
	if mouseDown and not mouseWasDown then beginPing("mouse") end
	if not mouseDown and mouseWasDown then finishPing("mouse") end
	mouseWasDown = mouseDown

	if not inputState then return end
	if not canPing() or gui.IsGameUIVisible() then closeWheel() return end
	if not inputState.radial
	and CurTime() - inputState.startedAt >= math.max(0.12,
		tonumber(cfg.SquadPingHoldTime) or 0.2) then
		inputState.radial = true
		gui.EnableScreenClicker(true)
		gui.SetMousePos(math.floor(ScrW() * 0.5), math.floor(ScrH() * 0.5))
	end
	if not inputState.radial then return end
	local cx, cy = ScrW() * 0.5, ScrH() * 0.5
	local mx, my = gui.MousePos()
	local dx, dy = mx - cx, my - cy
	local distance = math.sqrt(dx * dx + dy * dy)
	local selected
	if distance >= 62 and distance <= 330 then
		local angle = (math.deg(math.atan2(dy, dx)) + 450) % 360
		local segment = 360 / #MilBase.SquadPingOrder
		selected = math.floor((angle + segment * 0.5) / segment)
			% #MilBase.SquadPingOrder + 1
	end
	inputState.selected = selected and MilBase.SquadPingOrder[selected] or nil
	if inputState.selected ~= inputState.previous then
		if inputState.selected and MilBase.PlayUISound then
			MilBase.PlayUISound("hover")
		end
		inputState.previous = inputState.selected
	end
end)

hook.Add("ShutDown", "MilBase.SquadPingCursorCleanup", function()
	if inputState and inputState.radial then gui.EnableScreenClicker(false) end
end)

local function drawSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, color)
	local points = {}
	local steps = 10
	for step = 0, steps do
		local angle = math.rad(startAngle + (endAngle - startAngle) * step / steps)
		points[#points + 1] = {
			x = cx + math.cos(angle) * outerRadius,
			y = cy + math.sin(angle) * outerRadius,
		}
	end
	for step = steps, 0, -1 do
		local angle = math.rad(startAngle + (endAngle - startAngle) * step / steps)
		points[#points + 1] = {
			x = cx + math.cos(angle) * innerRadius,
			y = cy + math.sin(angle) * innerRadius,
		}
	end
	draw.NoTexture()
	surface.SetDrawColor(color)
	surface.DrawPoly(points)
end

local function markerPosition(ping)
	if IsValid(ping.target) then
		ping.position = ping.target:WorldSpaceCenter()
		if ping.target:IsPlayer() then
			ping.position = ping.target:GetPos()
				+ Vector(0, 0, ping.target:OBBMaxs().z + 14)
		end
	end
	return ping.position
end

net.Receive(NET_CREATE, function()
	local ping = {
		id = net.ReadUInt(16),
		type = net.ReadString(),
		squadName = net.ReadString(),
		position = net.ReadVector(),
		target = net.ReadEntity(),
		sender = net.ReadEntity(),
		senderName = net.ReadString(),
		leader = net.ReadBool(),
		diesAt = CurTime() + math.max(1, net.ReadFloat()),
		bornAt = CurTime(),
	}
	if not pingDefinition(ping.type) then return end
	if ping.squadName ~= LocalPlayer():GetNWString("mb_squad", "") then return end
	pings[#pings + 1] = ping
	local maximum = math.max(1,
		math.floor(tonumber(cfg.SquadPingMaximumActive) or 8))
	while #pings > maximum do table.remove(pings, 1) end
	if MilBase.PlayUISound then
		MilBase.PlayUISound("notify")
	else
		surface.PlaySound("kraken/squads/ping.wav")
	end
end)

local function drawOffscreenMarker(position, definition, alpha)
	local centerX, centerY = ScrW() * 0.5, ScrH() * 0.5
	local direction = position - EyePos()
	if direction:LengthSqr() <= 1 then return end
	local angle = direction:Angle()
	local yaw = math.rad(math.AngleDifference(angle.y, EyeAngles().y))
	local pitch = math.rad(math.AngleDifference(angle.p, EyeAngles().p))
	local x = math.Clamp(centerX + math.sin(yaw) * centerX * 0.82, 42, ScrW() - 42)
	local y = math.Clamp(centerY + math.sin(pitch) * ScrH() * 0.48, 42, ScrH() - 42)
	local arrowAngle = math.atan2(y - centerY, x - centerX)
	local size = 11
	local points = {}
	for index, offset in ipairs({ 0, 2.45, -2.45 }) do
		local a = arrowAngle + offset
		local length = index == 1 and size * 1.35 or size
		points[#points + 1] = {
			x = x + math.cos(a) * length,
			y = y + math.sin(a) * length,
		}
	end
	draw.NoTexture()
	surface.SetDrawColor(definition.color.r, definition.color.g,
		definition.color.b, alpha)
	surface.DrawPoly(points)
end

hook.Add("HUDPaint", "MilBase.SquadPingHUD", function()
	local ply = LocalPlayer()
	if not IsValid(ply) or MilBase.InEventView and MilBase.InEventView() then return end
	local squadName = ply:GetNWString("mb_squad", "")
	local now = CurTime()
	for index = #pings, 1, -1 do
		local ping = pings[index]
		if now >= ping.diesAt or ping.squadName ~= squadName then
			table.remove(pings, index)
			continue
		end
		local definition = pingDefinition(ping.type)
		local position = markerPosition(ping)
		if not definition or not isvector(position) then continue end
		local remaining = ping.diesAt - now
		local alpha = math.floor(255 * math.Clamp(remaining / 1.25, 0, 1))
		local screen = position:ToScreen()
		local inFront = (position - EyePos()):Dot(EyeAngles():Forward()) > 0
		if inFront and screen.visible and screen.x >= 20 and screen.x <= ScrW() - 20
		and screen.y >= 20 and screen.y <= ScrH() - 20 then
			local pulse = 1 + math.sin((now - ping.bornAt) * 8) * 0.1
			local size = 9 * pulse
			MilBase.DrawDiamond(screen.x, screen.y, size,
				Color(definition.color.r, definition.color.g,
					definition.color.b, alpha), true)
			draw.SimpleText(definition.glyph, "MB.Tiny", screen.x,
				screen.y - 1, Color(255, 255, 255, alpha),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			local orderPrefix = ping.leader and "ORDER: " or ""
			draw.SimpleTextOutlined(orderPrefix .. definition.label,
				"MB.Small", screen.x, screen.y + 15,
				Color(definition.color.r, definition.color.g,
					definition.color.b, alpha),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, alpha))
			local distance = math.Round(ply:GetPos():Distance(position) / 52.5)
			draw.SimpleTextOutlined((ping.leader and "LEAD / " or "")
				.. ping.senderName .. "  /  " .. distance .. "m",
				"MB.Tiny", screen.x, screen.y + 34,
				Color(225, 230, 235, alpha), TEXT_ALIGN_CENTER,
				TEXT_ALIGN_TOP, 1, Color(0, 0, 0, alpha))
		else
			drawOffscreenMarker(position, definition, alpha)
		end
	end

	if not inputState then return end
	local ui = MilBase.UI or {}
	local cx, cy = ScrW() * 0.5, ScrH() * 0.5
	if not inputState.radial then
		local progress = math.Clamp((CurTime() - inputState.startedAt)
			/ math.max(0.12, tonumber(cfg.SquadPingHoldTime) or 0.2), 0, 1)
		surface.SetDrawColor(255, 198, 60, 60 + progress * 120)
		surface.DrawOutlinedRect(cx - 17, cy - 17, 34, 34, 2)
		draw.SimpleText("RELEASE: QUICK PING  /  HOLD: ORDERS",
			"MB.Tiny", cx, cy + 27, ui.dim or color_white,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		return
	end

	surface.SetDrawColor(3, 7, 12, 205)
	surface.DrawRect(0, 0, ScrW(), ScrH())
	local innerRadius, outerRadius = 72, 245
	local segment = 360 / #MilBase.SquadPingOrder
	for index, pingType in ipairs(MilBase.SquadPingOrder) do
		local definition = pingDefinition(pingType)
		local middle = -90 + (index - 1) * segment
		local selected = inputState.selected == pingType
		local color = selected
			and Color(definition.color.r, definition.color.g, definition.color.b, 72)
			or Color(9, 17, 27, 238)
		drawSector(cx, cy, innerRadius, outerRadius,
			middle - segment * 0.5 + 2,
			middle + segment * 0.5 - 2, color)
		drawSector(cx, cy, outerRadius - 2, outerRadius,
			middle - segment * 0.5 + 2,
			middle + segment * 0.5 - 2,
			selected and definition.color or Color(90, 105, 120, 115))
		local angle = math.rad(middle)
		local radius = (innerRadius + outerRadius) * 0.5
		local x = cx + math.cos(angle) * radius
		local y = cy + math.sin(angle) * radius
		draw.SimpleText(definition.glyph, "MB.Med", x, y - 11,
			selected and definition.color or ui.text or color_white,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(definition.label, "MB.Tiny", x, y + 13,
			selected and definition.color or ui.dim or color_white,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	draw.SimpleText("SQUAD TACTICAL LINK", "MB.Tab", cx, cy - 18,
		ui.text or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	local selected = pingDefinition(inputState.selected)
	draw.SimpleText(selected and selected.description or "MOVE TO AN ORDER",
		"MB.Tiny", cx, cy + 13, selected and selected.color
			or ui.dim or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("RELEASE TO TRANSMIT", "MB.Tiny", cx,
		cy + outerRadius + 24, ui.dim or color_white,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("PostDrawTranslucentRenderables", "MilBase.SquadPingWorld", function()
	local ply = LocalPlayer()
	if not IsValid(ply) or MilBase.InEventView and MilBase.InEventView() then return end
	local squadName = ply:GetNWString("mb_squad", "")
	local now = CurTime()
	for _, ping in ipairs(pings) do
		if ping.squadName ~= squadName or now >= ping.diesAt then continue end
		local definition = pingDefinition(ping.type)
		local position = markerPosition(ping)
		if not definition or not isvector(position) then continue end
		local alpha = math.floor(150
			* math.Clamp((ping.diesAt - now) / 1.25, 0, 1))
		local pulse = 0.75 + math.sin(now * 6 + ping.id) * 0.25
		render.SetMaterial(beamMaterial)
		render.DrawBeam(position, position + Vector(0, 0, 46 + pulse * 18),
			2.5, 0, 1, Color(definition.color.r, definition.color.g,
				definition.color.b, alpha))
		render.SetMaterial(glowMaterial)
		render.DrawSprite(position + Vector(0, 0, 7), 18 + pulse * 7,
			18 + pulse * 7, Color(definition.color.r, definition.color.g,
				definition.color.b, alpha))
	end
end)
