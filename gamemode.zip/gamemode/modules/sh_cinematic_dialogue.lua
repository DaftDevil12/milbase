-- Reusable cinematic conversation namespace used by Customs and prison NPCs.
if MilBase._CinematicDialogueSharedLoaded then return end
MilBase._CinematicDialogueSharedLoaded = true

MilBase.CinematicDialogue = MilBase.CinematicDialogue or {}
MilBase.CinematicDialogue.NET_OPEN = "MilBase_CinematicDialogue_Open"
MilBase.CinematicDialogue.NET_ACTION = "MilBase_CinematicDialogue_Action"
MilBase.CinematicDialogue.NET_CLOSE = "MilBase_CinematicDialogue_Close"

