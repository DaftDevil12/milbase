--[[
	Scoreboard combat stats: Event Enemy kills, NPC kills, player kills, and
	deaths, tracked per-session via networked vars so the scoreboard (TAB)
	can display them live for every connected player.

	These are session stats (reset on reconnect/map change), matching the
	usual DarkRP-style scoreboard convention. If you want them to persist
	across sessions/restarts, hook MilBase.DB in here per-SteamID instead.
]]

if SERVER then

	local function bump(ply, key)
		if not IsValid(ply) or not ply:IsPlayer() then return end
		ply:SetNWInt(key, ply:GetNWInt(key, 0) + 1)
	end

	-- Player deaths + player-on-player kills.
	hook.Add("PlayerDeath", "MilBase.ScoreboardStats.PlayerDeath", function(victim, inflictor, attacker)
		bump(victim, "mb_sb_deaths")

		if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
			bump(attacker, "mb_sb_playerkills")
		end
	end)

	-- NPC kills, split into Event Enemy kills (NPCs spawned through the
	-- event system, tagged mb_event) vs ordinary NPC kills.
	hook.Add("OnNPCKilled", "MilBase.ScoreboardStats.NPCKilled", function(npc, attacker)
		if not IsValid(attacker) or not attacker:IsPlayer() then return end

		if IsValid(npc) and npc:GetNWBool("mb_event", false) then
			bump(attacker, "mb_sb_eekills")
		else
			bump(attacker, "mb_sb_npckills")
		end
	end)

end

--------------------------------------------------------------------------
-- Shared accessors (both realms can read the networked values)
--------------------------------------------------------------------------

function MilBase.SBEventKills(ply)
	return IsValid(ply) and ply:GetNWInt("mb_sb_eekills", 0) or 0
end

function MilBase.SBNPCKills(ply)
	return IsValid(ply) and ply:GetNWInt("mb_sb_npckills", 0) or 0
end

function MilBase.SBPlayerKills(ply)
	return IsValid(ply) and ply:GetNWInt("mb_sb_playerkills", 0) or 0
end

function MilBase.SBDeaths(ply)
	return IsValid(ply) and ply:GetNWInt("mb_sb_deaths", 0) or 0
end

-- K/D here is PvE-focused: (Event Enemy kills + NPC kills) / Deaths.
-- Player-vs-player kills are tracked separately in their own column
-- rather than folded into this ratio.
function MilBase.SBKDRatio(ply)
	local kills = MilBase.SBEventKills(ply) + MilBase.SBNPCKills(ply)
	local deaths = MilBase.SBDeaths(ply)
	if deaths <= 0 then return kills end
	return kills / deaths
end