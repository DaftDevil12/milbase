--[[
	501st Torrent Company Juggernaut system.

	This module deliberately does not create or modify a certification. Admin
	test commands activate it until the server owner is ready to wire it into
	Torrent Company's loadout/certification flow.
]]

if MilBase.JuggernautLoaded then return end
MilBase.JuggernautLoaded = true

local function cfg()
	return (MilBase.Config and MilBase.Config.Juggernaut) or {}
end

local SECTION_ORDER = { "head", "chest", "left_arm", "right_arm", "left_leg", "right_leg" }
local HITGROUP_SECTION = {
	[HITGROUP_HEAD] = "head",
	[HITGROUP_CHEST] = "chest",
	[HITGROUP_STOMACH] = "chest",
	[HITGROUP_LEFTARM] = "left_arm",
	[HITGROUP_RIGHTARM] = "right_arm",
	[HITGROUP_LEFTLEG] = "left_leg",
	[HITGROUP_RIGHTLEG] = "right_leg",
}

local function sectionKey(id)
	return "mb_jug_plate_" .. id
end

function MilBase.IsJuggernaut(ply)
	return IsValid(ply) and ply:IsPlayer() and ply:GetNWBool("mb_jug_active", false)
end

function MilBase.JuggernautSectionMax(id)
	local def = cfg().Sections and cfg().Sections[id]
	return def and math.max(1, tonumber(def.max) or 1) or 1
end

function MilBase.GetJuggernautSection(ply, id)
	return IsValid(ply) and ply:GetNWInt(sectionKey(id), MilBase.JuggernautSectionMax(id)) or 0
end

function MilBase.GetJuggernautArmourTotals(ply)
	local current, maximum = 0, 0
	for _, id in ipairs(SECTION_ORDER) do
		current = current + MilBase.GetJuggernautSection(ply, id)
		maximum = maximum + MilBase.JuggernautSectionMax(id)
	end
	return current, math.max(1, maximum)
end

local resolvedModel
local function validModel(path)
	return isstring(path) and path ~= "" and util.IsValidModel(path)
end

local function modelScore(path)
	local lower = string.lower(tostring(path or ""))
	local score = 0
	if string.find(lower, "juggernaut", 1, true) then score = score + 8 end
	if string.find(lower, "501", 1, true) then score = score + 5 end
	if string.find(lower, "darktrooper", 1, true) then score = score + 2 end
	if string.find(lower, "player", 1, true) then score = score + 1 end
	return score
end

local function mountedModelSearch()
	local roots = {
		"models/player", "models/moxfort", "models/501st", "models/juggernaut", "models/salty",
		"models/clone", "models/clones", "models/starwars",
	}
	local candidates = {}
	local seen = {}

	local function scan(path, depth)
		if depth < 0 or seen[path] then return end
		seen[path] = true
		local files, dirs = file.Find(path .. "/*", "GAME")
		for _, name in ipairs(files or {}) do
			if string.GetExtensionFromFilename(name) == "mdl" then
				local full = path .. "/" .. name
				local lower = string.lower(full)
				if string.find(lower, "juggernaut", 1, true)
					or string.find(lower, "501", 1, true)
					or string.find(lower, "darktrooper", 1, true) then
					candidates[#candidates + 1] = full
				end
			end
		end
		for _, dir in ipairs(dirs or {}) do scan(path .. "/" .. dir, depth - 1) end
	end

	for _, root in ipairs(roots) do scan(root, 4) end
	table.sort(candidates, function(a, b)
		local sa, sb = modelScore(a), modelScore(b)
		if sa == sb then return a < b end
		return sa > sb
	end)
	for _, path in ipairs(candidates) do
		if validModel(path) then return path end
	end
end

function MilBase.ResolveJuggernautModel(forceRefresh)
	if not forceRefresh and validModel(resolvedModel) then return resolvedModel end
	resolvedModel = nil
	local c = cfg()
	if validModel(c.Model) then resolvedModel = c.Model return resolvedModel end
	for _, path in ipairs(c.Models or {}) do
		if validModel(path) then resolvedModel = path return resolvedModel end
	end
	if player_manager and player_manager.AllValidModels then
		local candidates = {}
		for name, path in pairs(player_manager.AllValidModels() or {}) do
			local haystack = string.lower(tostring(name) .. " " .. tostring(path))
			if string.find(haystack, "juggernaut", 1, true)
				or (string.find(haystack, "501", 1, true) and string.find(haystack, "heavy", 1, true))
				or string.find(haystack, "darktrooper", 1, true) then
				candidates[#candidates + 1] = path
			end
		end
		table.sort(candidates, function(a, b) return modelScore(a) > modelScore(b) end)
		for _, path in ipairs(candidates) do
			if validModel(path) then resolvedModel = path return resolvedModel end
		end
	end
	resolvedModel = mountedModelSearch()
	return resolvedModel
end

local function sameSide(a, b)
	if not IsValid(a) or not IsValid(b) or not a:IsPlayer() or not b:IsPlayer() then return false end
	if a.MBFactionID and b.MBFactionID then return a:MBFactionID() == b:MBFactionID() end
	return a:Team() == b:Team()
end

-- Movement and input restrictions are shared so client prediction agrees with
-- the server. Ordinary movement remains unchanged outside active abilities,
-- broken leg plates, and suppression.
hook.Add("StartCommand", "MilBase.JuggernautInput", function(ply, cmd)
	if not MilBase.IsJuggernaut(ply) then return end
	local locked = ply:GetNWBool("mb_jug_lock", false)
	local shielded = ply:GetNWBool("mb_jug_shield_up", false)
	local down = ply:GetNWBool("mb_jug_incapacitated", false)
	local charging = ply:GetNWBool("mb_jug_charging", false)

	if shielded or locked or down then
		cmd:RemoveKey(IN_ATTACK)
		cmd:RemoveKey(IN_ATTACK2)
	end
	if locked or down then
		cmd:ClearMovement()
		cmd:RemoveKey(IN_JUMP)
		cmd:RemoveKey(IN_DUCK)
	end
	if charging then
		cmd:SetForwardMove(10000)
		cmd:SetSideMove(0)
		cmd:RemoveKey(IN_JUMP)
	end
end)

hook.Add("SetupMove", "MilBase.JuggernautMovement", function(ply, mv)
	local stagger = ply:GetNWFloat("mb_jug_stagger_until", 0)
	if stagger > CurTime() then
		mv:SetMaxSpeed(math.min(mv:GetMaxSpeed(), 45))
		mv:SetMaxClientSpeed(math.min(mv:GetMaxClientSpeed(), 45))
	end

	local suppression = ply:GetNWFloat("mb_jug_suppression", 0)
	if suppression > 0 then
		local maxSupp = math.max(1, cfg().SuppressionMax or 100)
		local fraction = math.Clamp(suppression / maxSupp, 0, 1)
		local minScale = cfg().SuppressionRunScaleAtMax or 0.82
		local scale = Lerp(fraction, 1, minScale)
		mv:SetMaxSpeed(mv:GetMaxSpeed() * scale)
		mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * scale)
	end

	if not MilBase.IsJuggernaut(ply) then return end
	if ply:GetNWBool("mb_jug_incapacitated", false) or ply:GetNWBool("mb_jug_lock", false) then
		mv:SetMaxSpeed(0)
		mv:SetMaxClientSpeed(0)
		mv:SetVelocity(vector_origin)
		return
	end

	local scale = 1
	if MilBase.GetJuggernautSection(ply, "left_leg") <= 0 then scale = scale * (cfg().BrokenOneLegSpeedScale or 0.82) end
	if MilBase.GetJuggernautSection(ply, "right_leg") <= 0 then scale = scale * (cfg().BrokenOneLegSpeedScale or 0.82) end
	if MilBase.GetJuggernautSection(ply, "left_leg") <= 0 and MilBase.GetJuggernautSection(ply, "right_leg") <= 0 then
		scale = cfg().BrokenBothLegsSpeedScale or 0.64
	end
	if ply:GetNWBool("mb_jug_shield_up", false) then scale = scale * (cfg().ShieldMoveScale or 0.55) end
	mv:SetMaxSpeed(mv:GetMaxSpeed() * scale)
	mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * scale)

	if ply:GetNWBool("mb_jug_charging", false) then
		local velocity = ply:GetForward() * (cfg().ChargeSpeed or 520)
		velocity.z = mv:GetVelocity().z
		mv:SetVelocity(velocity)
		mv:SetMaxSpeed(cfg().ChargeSpeed or 520)
		mv:SetMaxClientSpeed(cfg().ChargeSpeed or 520)
	end
end)

if SERVER then
	util.AddNetworkString("MilBase_JuggernautCommand")

	local function logAction(ply, text, target)
		if cfg().LogActions == false then return end
		local actor = IsValid(ply) and (ply.MBName and ply:MBName() or ply:Nick()) or "unknown"
		local suffix = IsValid(target) and (" -> " .. (target.MBName and target:MBName() or target:GetClass())) or ""
		ServerLog(string.format("[JUGGERNAUT] %s %s%s\n", actor, tostring(text), suffix))
	end

	local function notify(ply, text, kind)
		if IsValid(ply) and MilBase.Notify then MilBase.Notify(ply, text, kind) end
	end

	local function setPower(ply, value, delayRegen)
		local c = cfg()
		ply:SetNWFloat("mb_jug_power", math.Clamp(value, 0, c.PowerMax or 100))
		if delayRegen then ply.mb_jugPowerRegenAt = CurTime() + (c.PowerRegenDelay or 3) end
	end

	local function setShield(ply, value)
		ply:SetNWFloat("mb_jug_shield", math.Clamp(value, 0, cfg().ShieldMax or 260))
	end

	local function saveBodygroups(ply)
		local out = {}
		for i = 0, math.max(0, ply:GetNumBodyGroups() - 1) do out[i] = ply:GetBodygroup(i) end
		return out
	end

	local function applyBodygroups(ply, bodygroups)
		for id, value in pairs(bodygroups or {}) do ply:SetBodygroup(tonumber(id) or id, tonumber(value) or 0) end
	end

	local function armourWeaponClasses()
		local c = cfg()
		local classes, seen = {}, {}
		local function add(class)
			class = string.Trim(tostring(class or ""))
			if class == "" or seen[class] then return end
			seen[class] = true
			classes[#classes + 1] = class
		end
		add(c.WeaponClass or "arccw_cgi_k_z6")
		for _, class in ipairs(c.AdditionalArmourWeapons or {}) do add(class) end
		return classes, seen
	end

	local function isArmourWeaponClass(class)
		local _, allowed = armourWeaponClasses()
		return allowed[tostring(class or "")] == true
	end

	local function clearPlayerAmmo(ply)
		if ply.RemoveAllAmmo then
			ply:RemoveAllAmmo()
			return
		end
		for ammoID = 0, 255 do
			local count = ply:GetAmmoCount(ammoID)
			if count > 0 then ply:RemoveAmmo(count, ammoID) end
		end
	end

	local function captureLoadout(ply)
		local saved = { weapons = {}, ammo = {} }
		local active = ply:GetActiveWeapon()
		if IsValid(active) then saved.activeClass = active:GetClass() end
		for _, weapon in ipairs(ply:GetWeapons()) do
			if not IsValid(weapon) then continue end
			saved.weapons[#saved.weapons + 1] = {
				class = weapon:GetClass(),
				clip1 = weapon:Clip1(),
				clip2 = weapon:Clip2(),
			}
		end
		for ammoID = 0, 255 do
			local count = ply:GetAmmoCount(ammoID)
			if count > 0 then saved.ammo[ammoID] = count end
		end
		return saved
	end

	local function giveArmourLoadout(ply)
		local classes = armourWeaponClasses()
		for _, class in ipairs(classes) do
			if weapons.GetStored(class) then ply:Give(class) end
		end
		local primary = cfg().WeaponClass or "arccw_cgi_k_z6"
		if cfg().SelectZ6 ~= false and IsValid(ply:GetWeapon(primary)) then
			timer.Simple(0, function()
				if IsValid(ply) and MilBase.IsJuggernaut(ply) and IsValid(ply:GetWeapon(primary)) then
					ply:SelectWeapon(primary)
				end
			end)
		end
	end

	local function restoreSavedLoadout(ply, loadout)
		if not loadout then return end
		ply:StripWeapons()
		if cfg().RestoreAmmoOnDeactivate ~= false then clearPlayerAmmo(ply) end
		for _, data in ipairs(loadout.weapons or {}) do
			if weapons.GetStored(data.class) then
				local weapon = ply:Give(data.class, true)
				if IsValid(weapon) then
					if data.clip1 ~= nil then weapon:SetClip1(data.clip1) end
					if data.clip2 ~= nil then weapon:SetClip2(data.clip2) end
				end
			end
		end
		if cfg().RestoreAmmoOnDeactivate ~= false then
			for ammoID, count in pairs(loadout.ammo or {}) do
				if count > 0 then ply:GiveAmmo(count, tonumber(ammoID) or ammoID, true) end
			end
		end
		if loadout.activeClass then
			timer.Simple(0, function()
				if IsValid(ply) and not MilBase.IsJuggernaut(ply) and IsValid(ply:GetWeapon(loadout.activeClass)) then
					ply:SelectWeapon(loadout.activeClass)
				end
			end)
		end
	end

	local function resetNetworkState(ply)
		ply:SetNWBool("mb_jug_active", false)
		ply:SetNWBool("mb_jug_shield_up", false)
		ply:SetNWBool("mb_jug_lock", false)
		ply:SetNWBool("mb_jug_charging", false)
		ply:SetNWBool("mb_jug_incapacitated", false)
		ply:SetNWBool("mb_jug_med_stable", false)
		ply:SetNWBool("mb_jug_eng_stable", false)
		ply:SetNWFloat("mb_jug_power", 0)
		ply:SetNWFloat("mb_jug_shield", 0)
		ply:SetNWFloat("mb_jug_charge_cd", 0)
		ply:SetNWFloat("mb_jug_slam_cd", 0)
		ply:SetNWFloat("mb_jug_lock_cd", 0)
		ply:SetNWFloat("mb_jug_incap_ends", 0)
		ply:SetNWString("mb_jug_state", "")
		for _, id in ipairs(SECTION_ORDER) do ply:SetNWInt(sectionKey(id), 0) end
	end

	function MilBase.ActivateJuggernaut(ply)
		local c = cfg()
		if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
		if c.Enabled == false then notify(ply, "The Juggernaut system is disabled.", "warn") return false end
		if MilBase.IsJuggernaut(ply) then notify(ply, "Juggernaut systems are already active.", "warn") return false end

		local model = MilBase.ResolveJuggernautModel(false)
		if c.RequireModel ~= false and not validModel(model) then
			notify(ply, "The 501st Juggernaut model could not be found. Set MilBase.Config.Juggernaut.Model to its .mdl path.", "warn")
			return false
		end
		local class = c.WeaponClass or "arccw_cgi_k_z6"
		local weaponExists = weapons.GetStored(class) ~= nil
		if c.RequireWeapon ~= false and not weaponExists then
			notify(ply, "Required Z-6 weapon class is missing: " .. class, "warn")
			return false
		end

		ply.mb_jugSaved = {
			model = ply:GetModel(), skin = ply:GetSkin(), bodygroups = saveBodygroups(ply),
			hadZ6 = IsValid(ply:GetWeapon(class)),
			loadout = captureLoadout(ply),
		}
		ply:SetNWBool("mb_jug_active", true)
		ply:SetNWString("mb_jug_state", "READY")
		for _, id in ipairs(SECTION_ORDER) do ply:SetNWInt(sectionKey(id), MilBase.JuggernautSectionMax(id)) end
		setPower(ply, c.PowerMax or 100)
		setShield(ply, c.ShieldMax or 260)
		ply.mb_jugPowerRegenAt = CurTime()
		ply.mb_jugShieldRegenAt = CurTime()

		if validModel(model) then
			ply:SetModel(model)
			ply:SetSkin(tonumber(c.Skin) or 0)
			applyBodygroups(ply, c.Bodygroups)
		end
		if c.ReplaceWeaponsWhileActive ~= false then
			ply:StripWeapons()
			clearPlayerAmmo(ply)
			giveArmourLoadout(ply)
		elseif c.GiveZ6 ~= false and weaponExists then
			ply:Give(class)
			if c.SelectZ6 ~= false then
				timer.Simple(0, function() if IsValid(ply) and MilBase.IsJuggernaut(ply) then ply:SelectWeapon(class) end end)
			end
		end
		ply:EmitSound("items/suitchargeok1.wav", 75, 82)
		notify(ply, "Juggernaut systems online. Press G for the ability wheel.", "ok")
		logAction(ply, "activated")
		return true
	end

	function MilBase.DeactivateJuggernaut(ply, silent, skipRestore)
		if not IsValid(ply) or not MilBase.IsJuggernaut(ply) then return end
		local saved = ply.mb_jugSaved
		local class = cfg().WeaponClass or "arccw_cgi_k_z6"
		ply.mb_jugSaved = nil
		ply.mb_jugChargeHits = nil
		ply.mb_jugPowerRegenAt = nil
		ply.mb_jugShieldRegenAt = nil
		ply.mb_jugLockEnds = nil
		ply.mb_jugAirborne = nil
		ply.mb_jugAirPeakZ = nil
		resetNetworkState(ply)
		if not skipRestore and ply:Alive() and saved and cfg().RestoreOriginalModel ~= false then
			if validModel(saved.model) then
				ply:SetModel(saved.model)
				ply:SetSkin(saved.skin or 0)
				applyBodygroups(ply, saved.bodygroups)
			end
		end
		if not skipRestore and ply:Alive() and saved and cfg().ReplaceWeaponsWhileActive ~= false
			and cfg().RestoreWeaponsOnDeactivate ~= false then
			restoreSavedLoadout(ply, saved.loadout)
		elseif saved and cfg().ReplaceWeaponsWhileActive == false and not saved.hadZ6 then
			if IsValid(ply:GetWeapon(class)) then ply:StripWeapon(class) end
		end
		if MilBase.UpdateMoveSpeed then MilBase.UpdateMoveSpeed(ply) end
		if not silent then notify(ply, "Juggernaut systems disengaged.", "ok") end
		logAction(ply, "deactivated")
	end

	local function lowerShield(ply, message)
		if not ply:GetNWBool("mb_jug_shield_up", false) then return end
		ply:SetNWBool("mb_jug_shield_up", false)
		ply:SetNWString("mb_jug_state", "READY")
		ply.mb_jugPowerRegenAt = CurTime() + (cfg().PowerRegenDelay or 3)
		if message then notify(ply, message, "warn") end
	end

	local function endArmourLock(ply, message)
		if not ply:GetNWBool("mb_jug_lock", false) then return end
		ply:SetNWBool("mb_jug_lock", false)
		ply:SetNWString("mb_jug_state", "READY")
		ply:SetNWFloat("mb_jug_lock_cd", CurTime() + (cfg().ArmourLockCooldown or 18))
		ply.mb_jugPowerRegenAt = CurTime() + (cfg().PowerRegenDelay or 3)
		if message then notify(ply, message, "warn") end
	end

	local function stopCharge(ply)
		if not ply:GetNWBool("mb_jug_charging", false) then return end
		ply:SetNWBool("mb_jug_charging", false)
		ply:SetNWString("mb_jug_state", "READY")
		ply:SetLocalVelocity(vector_origin)
		ply.mb_jugChargeEnds = nil
		ply.mb_jugChargeHits = nil
	end

	local function powerAvailable(ply, cost)
		if ply:GetNWFloat("mb_jug_power", 0) < cost then
			notify(ply, "Insufficient suit power.", "warn")
			return false
		end
		return true
	end

	function MilBase.ToggleJuggernautShield(ply)
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return false end
		if ply:GetNWBool("mb_jug_lock", false) or ply:GetNWBool("mb_jug_charging", false) then
			notify(ply, "Shield unavailable in the current suit state.", "warn") return false
		end
		if ply:GetNWBool("mb_jug_shield_up", false) then lowerShield(ply) return true end
		if ply:GetNWFloat("mb_jug_shield", 0) <= 0 or not powerAvailable(ply, 1) then
			notify(ply, "Frontal shield is depleted.", "warn") return false
		end
		ply:SetNWBool("mb_jug_shield_up", true)
		ply:SetNWString("mb_jug_state", "SHIELD")
		ply.mb_jugPowerRegenAt = CurTime() + (cfg().PowerRegenDelay or 3)
		ply:EmitSound("npc/roller/mine/rmine_blip3.wav", 70, 115)
		logAction(ply, "raised frontal shield")
		return true
	end

	function MilBase.StartJuggernautCharge(ply)
		local c = cfg()
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return false end
		if ply:GetNWBool("mb_jug_shield_up", false) or ply:GetNWBool("mb_jug_lock", false) or ply:GetNWBool("mb_jug_charging", false) then
			notify(ply, "Charge unavailable in the current suit state.", "warn") return false
		end
		if CurTime() < ply:GetNWFloat("mb_jug_charge_cd", 0) then notify(ply, "Charge is cooling down.", "warn") return false end
		if MilBase.GetJuggernautSection(ply, "left_leg") <= 0 and MilBase.GetJuggernautSection(ply, "right_leg") <= 0 then
			notify(ply, "Both leg servos are disabled.", "warn") return false
		end
		if not powerAvailable(ply, c.ChargePowerCost or 30) then return false end
		setPower(ply, ply:GetNWFloat("mb_jug_power", 0) - (c.ChargePowerCost or 30), true)
		ply:SetNWFloat("mb_jug_charge_cd", CurTime() + (c.ChargeCooldown or 12))
		ply:SetNWBool("mb_jug_charging", true)
		ply:SetNWString("mb_jug_state", "CHARGE")
		ply.mb_jugChargeEnds = CurTime() + (c.ChargeDuration or 1.05)
		ply.mb_jugChargeHits = {}
		ply:EmitSound("npc/strider/strider_skewer1.wav", 75, 125)
		logAction(ply, "used charge")
		return true
	end

	local function slamImpact(ply)
		if not IsValid(ply) or not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return end
		local c = cfg()
		local origin = ply:GetPos()
		local effect = EffectData()
		effect:SetOrigin(origin + Vector(0, 0, 3))
		effect:SetScale(1.4)
		util.Effect("ThumperDust", effect, true, true)
		util.ScreenShake(origin, 8, 7, 0.65, c.SlamRadius or 260)
		for _, target in ipairs(ents.FindInSphere(origin, c.SlamRadius or 260)) do
			if target == ply or not IsValid(target) then continue end
			if not (target:IsPlayer() or target:IsNPC() or target:IsNextBot()) then continue end
			if target:IsPlayer() and not c.SlamAffectsFriendlies and sameSide(ply, target) then continue end
			local centre = target:WorldSpaceCenter()
			local tr = util.TraceLine({ start = ply:WorldSpaceCenter(), endpos = centre, filter = { ply, target }, mask = MASK_SOLID_BRUSHONLY })
			if tr.Hit then continue end
			local dir = (centre - origin):GetNormalized()
			local damage = DamageInfo()
			damage:SetAttacker(ply)
			damage:SetInflictor(ply)
			damage:SetDamage(c.SlamDamage or 12)
			damage:SetDamageType(DMG_CLUB)
			damage:SetDamageForce((dir + Vector(0, 0, 0.35)) * (c.SlamForce or 520))
			target:TakeDamageInfo(damage)
			if target:IsPlayer() then
				target:SetNWFloat("mb_jug_stagger_until", CurTime() + (c.SlamStaggerDuration or 1.75))
				target:SetVelocity((dir + Vector(0, 0, 0.35)) * (c.SlamForce or 520))
			elseif target.SetVelocity then
				target:SetVelocity((dir + Vector(0, 0, 0.35)) * (c.SlamForce or 520))
			end
		end
	end

	function MilBase.UseJuggernautSlam(ply, automatic, dropHeight, landingSpeed)
		local c = cfg()
		if automatic and c.AutomaticSlam == false then return false end
		if not automatic and c.AllowManualSlam ~= true then return false end
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return false end
		if automatic and ply:GetNWBool("mb_jug_shield_up", false) then lowerShield(ply) end
		if ply:GetNWBool("mb_jug_shield_up", false) or ply:GetNWBool("mb_jug_lock", false) or ply:GetNWBool("mb_jug_charging", false) then
			if not automatic then notify(ply, "Ground slam unavailable in the current suit state.", "warn") end
			return false
		end
		if CurTime() < ply:GetNWFloat("mb_jug_slam_cd", 0) then
			if not automatic then notify(ply, "Ground slam is cooling down.", "warn") end
			return false
		end
		local cost = c.SlamPowerCost or 35
		if not powerAvailable(ply, cost) then return false end
		setPower(ply, ply:GetNWFloat("mb_jug_power", 0) - cost, true)
		ply:SetNWFloat("mb_jug_slam_cd", CurTime() + (c.SlamCooldown or 14))
		ply:SetNWString("mb_jug_state", automatic and "LANDING SLAM" or "SLAM")
		ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_MELEE_SHOVE_1HAND, true)
		ply:EmitSound("ambient/machines/thumper_hit.wav", 82, automatic and 80 or 92)
		local delay = automatic and (c.SlamImpactDelay or 0.05) or (c.SlamDelay or 0.42)
		timer.Simple(delay, function()
			if IsValid(ply) and MilBase.IsJuggernaut(ply) then
				slamImpact(ply)
				if not ply:GetNWBool("mb_jug_incapacitated", false) then ply:SetNWString("mb_jug_state", "READY") end
			end
		end)
		local detail = automatic and string.format(" after %.0fu drop at %.0f speed", tonumber(dropHeight) or 0, tonumber(landingSpeed) or 0) or ""
		logAction(ply, "used ground slam" .. detail)
		return true
	end

	function MilBase.ToggleJuggernautArmourLock(ply)
		local c = cfg()
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return false end
		if ply:GetNWBool("mb_jug_lock", false) then endArmourLock(ply) return true end
		if ply:GetNWBool("mb_jug_shield_up", false) or ply:GetNWBool("mb_jug_charging", false) then
			notify(ply, "Armour lock unavailable in the current suit state.", "warn") return false
		end
		if CurTime() < ply:GetNWFloat("mb_jug_lock_cd", 0) then notify(ply, "Armour lock is cooling down.", "warn") return false end
		if not powerAvailable(ply, c.ArmourLockMinimumPower or 20) then return false end
		ply:SetNWBool("mb_jug_lock", true)
		ply:SetNWString("mb_jug_state", "ARMOUR LOCK")
		ply.mb_jugLockEnds = CurTime() + (c.ArmourLockMaxDuration or 6)
		ply:SetLocalVelocity(vector_origin)
		ply:EmitSound("ambient/machines/thumper_startup1.wav", 75, 90)
		logAction(ply, "engaged armour lock")
		return true
	end

	local function setIncapacitated(ply)
		local c = cfg()
		lowerShield(ply)
		endArmourLock(ply)
		stopCharge(ply)
		ply:SetHealth(1)
		ply:SetNWBool("mb_jug_incapacitated", true)
		ply:SetNWBool("mb_jug_med_stable", false)
		ply:SetNWBool("mb_jug_eng_stable", false)
		ply:SetNWFloat("mb_jug_incap_ends", CurTime() + (c.IncapacitationDuration or 50))
		ply:SetNWString("mb_jug_state", "EMERGENCY SHUTDOWN")
		ply:SetLocalVelocity(vector_origin)
		ply:EmitSound("npc/turret_floor/die.wav", 80, 72)
		notify(ply, "Juggernaut suit disabled. A medic and engineer are required.", "warn")
		logAction(ply, "was incapacitated")
	end

	local function sourcePosition(ply, dmg)
		local pos = dmg:GetDamagePosition()
		if isvector(pos) and pos:LengthSqr() > 1
			and pos:DistToSqr(ply:WorldSpaceCenter()) > 64 * 64 then return pos end
		local inflictor = dmg:GetInflictor()
		if IsValid(inflictor) and inflictor ~= ply then return inflictor:WorldSpaceCenter() end
		local attacker = dmg:GetAttacker()
		if IsValid(attacker) and attacker ~= ply then return attacker:WorldSpaceCenter() end
		if isvector(pos) and pos:LengthSqr() > 1 then return pos end
	end

	local function shieldCovers(ply, dmg)
		local source = sourcePosition(ply, dmg)
		if not source then return false end
		local toSource = (source - ply:WorldSpaceCenter())
		if toSource:LengthSqr() <= 1 then return false end
		toSource:Normalize()
		local threshold = math.cos(math.rad((cfg().ShieldArcDegrees or 125) * 0.5))
		return ply:GetForward():Dot(toSource) >= threshold
	end

	function MilBase.JuggernautProcessDamage(ply, dmg)
		if not MilBase.IsJuggernaut(ply) or not ply:Alive() then return false end
		local c = cfg()
		-- Fall immunity belongs to the active armour, not a specific plate.
		-- Keep this guard in the damage pipeline as well as GetFallDamage so
		-- medical/damage addons cannot re-introduce fall damage afterward.
		if c.PreventFallDamage ~= false and dmg:IsDamageType(DMG_FALL) then
			dmg:SetDamage(0)
			dmg:SetDamageForce(vector_origin)
			return true
		end
		if ply:GetNWBool("mb_jug_incapacitated", false) then
			if dmg:IsExplosionDamage() or dmg:GetDamage() >= (c.ExecutionDamage or 20) then
				ply:SetNWBool("mb_jug_incapacitated", false)
				return false -- allow the follow-up hit to kill normally
			end
			dmg:SetDamage(0)
			return true
		end

		local damage = math.max(0, dmg:GetDamage())
		if damage <= 0 then return true end

		if ply:GetNWBool("mb_jug_shield_up", false) and shieldCovers(ply, dmg) then
			local multiplier = dmg:IsExplosionDamage() and (c.ShieldExplosionDamageScale or 1.8) or 1
			local shield = ply:GetNWFloat("mb_jug_shield", 0)
			local shieldCost = damage * multiplier
			local absorbedCost = math.min(shield, shieldCost)
			setShield(ply, shield - absorbedCost)
			local powerCost = absorbedCost * (c.ShieldPowerPerDamage or 0.025)
			if powerCost > 0 then setPower(ply, ply:GetNWFloat("mb_jug_power", 0) - powerCost, true) end
			ply.mb_jugShieldRegenAt = CurTime() + (c.ShieldRegenDelay or 5)
			local residual = math.max(0, shieldCost - absorbedCost) / multiplier
			ply:EmitSound("weapons/physcannon/energy_sing_explosion2.wav", 62, 145, 0.32)
			if ply:GetNWFloat("mb_jug_shield", 0) <= 0 then lowerShield(ply, "Frontal shield collapsed.") end
			if residual <= 0.01 then dmg:SetDamage(0) return true end
			damage = residual
			dmg:SetDamage(damage)
		end

		if ply:GetNWBool("mb_jug_lock", false) then
			damage = damage * (c.ArmourLockDamageScale or 0.22)
			dmg:SetDamage(damage)
		end

		local section = c.ExplosionSection or "chest"
		if not dmg:IsExplosionDamage() then section = HITGROUP_SECTION[ply.mb_jugLastHitGroup] or "chest" end
		ply.mb_jugLastHitGroup = nil
		local def = c.Sections and c.Sections[section]
		if def then
			local current = MilBase.GetJuggernautSection(ply, section)
			if current > 0 then
				local before = current
				local wear = damage * (tonumber(def.wear) or 1)
				current = math.max(0, current - math.ceil(wear))
				ply:SetNWInt(sectionKey(section), current)
				damage = damage * (1 - math.Clamp(tonumber(def.reduction) or 0, 0, 0.95))
				dmg:SetDamage(damage)
				if before > 0 and current <= 0 then
					ply:EmitSound("physics/metal/metal_box_break2.wav", 76, 88)
					notify(ply, string.upper(def.name or section) .. " PLATE DESTROYED", "warn")
					logAction(ply, "lost " .. section .. " plate")
				end
			end
		end

		if c.IncapacitationEnabled ~= false and damage >= ply:Health() then
			dmg:SetDamage(0)
			setIncapacitated(ply)
			return true
		end
		return damage <= 0
	end

	hook.Add("ScalePlayerDamage", "MilBase.JuggernautHitGroup", function(ply, hitgroup)
		if MilBase.IsJuggernaut(ply) then ply.mb_jugLastHitGroup = hitgroup end
	end)

	-- Cancel Source fall damage at calculation time. OnPlayerHitGround still
	-- receives the landing speed, so automatic Ground Slam remains functional.
	hook.Add("GetFallDamage", "MilBase.JuggernautFallImmunity", function(ply)
		if MilBase.IsJuggernaut(ply) and cfg().PreventFallDamage ~= false then
			return 0
		end
	end)

	-- The medical module calls JuggernautProcessDamage before its standard limb
	-- pipeline. This fallback keeps the system functional when medical is off.
	hook.Add("EntityTakeDamage", "MilBase.JuggernautDamageFallback", function(ent, dmg)
		if MilBase.Config.MedicalEnabled ~= false then return end
		if MilBase.IsJuggernaut(ent) then return MilBase.JuggernautProcessDamage(ent, dmg) end
	end)

	local function chargeImpact(ply, target)
		local c = cfg()
		if not IsValid(target) then return end
		local dir = ply:GetForward()
		local damage = DamageInfo()
		damage:SetAttacker(ply)
		damage:SetInflictor(ply)
		damage:SetDamage(c.ChargeImpactDamage or 18)
		damage:SetDamageType(DMG_CLUB)
		damage:SetDamageForce((dir + Vector(0, 0, 0.15)) * (c.ChargeImpactForce or 520))
		target:TakeDamageInfo(damage)
		if target:IsPlayer() then
			target:SetNWFloat("mb_jug_stagger_until", CurTime() + (c.ChargeStaggerDuration or 1.25))
			target:SetVelocity((dir + Vector(0, 0, 0.15)) * (c.ChargeImpactForce or 520))
		elseif target.SetVelocity then
			target:SetVelocity((dir + Vector(0, 0, 0.15)) * (c.ChargeImpactForce or 520))
		end
	end

	local function closestPointDistance(startPos, endPos, point)
		local line = endPos - startPos
		local lengthSqr = line:LengthSqr()
		if lengthSqr <= 0 then return point:Distance(startPos) end
		local t = math.Clamp((point - startPos):Dot(line) / lengthSqr, 0, 1)
		return point:Distance(startPos + line * t)
	end

	hook.Add("EntityFireBullets", "MilBase.JuggernautSuppression", function(shooter, data)
		if not IsValid(shooter) or not shooter:IsPlayer() then return end
		local c = cfg()
		local suppression = shooter:GetNWFloat("mb_jug_suppression", 0)
		if suppression > 0 and isvector(data.Spread) then
			local fraction = math.Clamp(suppression / math.max(1, c.SuppressionMax or 100), 0, 1)
			local add = (c.SuppressionSpreadAtMax or 0.018) * fraction
			data.Spread = data.Spread + Vector(add, add, 0)
		end
		if not MilBase.IsJuggernaut(shooter) then return end
		local weapon = shooter:GetActiveWeapon()
		if not IsValid(weapon) or weapon:GetClass() ~= (c.WeaponClass or "arccw_cgi_k_z6") then return end
		local startPos = data.Src or shooter:GetShootPos()
		local distance = data.Distance or 8192
		local endPos = startPos + (data.Dir or shooter:GetAimVector()) * distance
		local bulletTrace = util.TraceLine({ start = startPos, endpos = endPos, filter = shooter, mask = MASK_SHOT })
		endPos = bulletTrace.HitPos
		for _, target in ipairs(player.GetAll()) do
			if target == shooter or not target:Alive() then continue end
			if not c.SuppressFriendlies and sameSide(shooter, target) then continue end
			if closestPointDistance(startPos, endPos, target:WorldSpaceCenter()) > (c.SuppressionRadius or 145) then continue end
			local amount = math.min(c.SuppressionMax or 100, target:GetNWFloat("mb_jug_suppression", 0) + (c.SuppressionPerShot or 6))
			target:SetNWFloat("mb_jug_suppression", amount)
			target.mb_jugSuppressedAt = CurTime()
		end
	end)

	local function isMedic(ply)
		if not IsValid(ply) or not ply:IsPlayer() then return false end
		if ply:IsAdmin() then return true end
		local rank = ply.MBRank and ply:MBRank()
		local faction = ply.MBFaction and ply:MBFaction()
		if (rank and rank.medic) or (faction and faction.medic) then return true end
		if ply.MBCertList then
			for _, certID in ipairs(ply:MBCertList()) do
				local cert = MilBase.Certs and MilBase.Certs[certID]
				if cert and (cert.medic or cert.medicOthers) then return true end
			end
		end
		return false
	end

	local function isEngineer(ply)
		return IsValid(ply) and ply:IsPlayer() and (ply:IsAdmin() or (ply.MBHasCert and ply:MBHasCert("engineer")))
	end

	local function repairItem(ply)
		if not cfg().RequireRepairKit then return true end
		local item = MilBase.FindEngItem and MilBase.FindEngItem(ply, "repair")
		local cost = cfg().EngineerRepairChargeCost or 50
		if not item or (item.charges and item.charges < cost) then return nil end
		return item
	end

	local function consumeRepairItem(ply, item)
		if item == true or not cfg().RequireRepairKit then return true end
		if not item then return false end
		local cost = cfg().EngineerRepairChargeCost or 50
		local current = MilBase.InvFindAny and MilBase.InvFindAny(MilBase.GetInventory(ply), item.uid) or item
		if not current then return false end
		if current.charges then
			if current.charges < cost then return false end
			current.charges = current.charges - cost
			if current.charges <= 0 then MilBase.RemoveItemUID(ply, current.uid) else MilBase.MarkInvDirty(ply) end
		else
			MilBase.RemoveItemUID(ply, current.uid, 1)
		end
		return true
	end

	local function mostDamagedSection(target)
		local best, bestFraction
		for _, id in ipairs(SECTION_ORDER) do
			local fraction = MilBase.GetJuggernautSection(target, id) / MilBase.JuggernautSectionMax(id)
			if fraction < 1 and (not bestFraction or fraction < bestFraction) then best, bestFraction = id, fraction end
		end
		return best
	end

	local function reviveJuggernaut(target, helper)
		target:SetNWBool("mb_jug_incapacitated", false)
		target:SetNWBool("mb_jug_med_stable", false)
		target:SetNWBool("mb_jug_eng_stable", false)
		target:SetNWFloat("mb_jug_incap_ends", 0)
		target:SetNWString("mb_jug_state", "READY")
		target:SetHealth(math.min(target:GetMaxHealth(), cfg().ReviveHealth or 35))
		setPower(target, cfg().RevivePower or 25, true)
		target:EmitSound("items/suitchargeok1.wav", 75, 92)
		notify(target, "Juggernaut operator and suit stabilized.", "ok")
		if IsValid(helper) then notify(helper, "Juggernaut recovery complete.", "ok") end
		logAction(target, "was restored", helper)
	end

	local function cancelService(ply)
		ply.mb_jugService = nil
		ply:SetNWFloat("mb_jug_service_progress", 0)
		ply:SetNWString("mb_jug_service_action", "")
	end

	local function beginService(helper, target, action, duration, item)
		helper.mb_jugService = {
			target = target, action = action, finish = CurTime() + duration,
			duration = duration, item = item,
		}
		helper:SetNWString("mb_jug_service_action", action == "medic" and "STABILIZING OPERATOR"
			or action == "restore" and "RESTORING SUIT"
			or "REPAIRING ARMOUR")
		helper:SetNWFloat("mb_jug_service_progress", 0.01)
	end

	local function finishService(helper, service)
		local target = service.target
		if not IsValid(target) or not MilBase.IsJuggernaut(target) then return end
		if service.action == "medic" then
			if cfg().RequireBandageForStabilize and MilBase.CountItem(helper, "bandage") < 1 then notify(helper, "A bandage is required.", "warn") return end
			if cfg().RequireBandageForStabilize then MilBase.TakeItem(helper, "bandage", 1) end
			target:SetNWBool("mb_jug_med_stable", true)
			notify(helper, "Operator stabilized; suit restoration is still required.", "ok")
			notify(target, "Biological condition stabilized.", "ok")
		elseif service.action == "restore" then
			if not consumeRepairItem(helper, service.item) then notify(helper, "Repair kit resources are no longer available.", "warn") return end
			target:SetNWBool("mb_jug_eng_stable", true)
			notify(helper, "Suit emergency systems restored.", "ok")
			notify(target, "Suit systems stabilized.", "ok")
		elseif service.action == "repair" then
			if not consumeRepairItem(helper, service.item) then notify(helper, "Repair kit resources are no longer available.", "warn") return end
			local id = mostDamagedSection(target)
			if id then
				local value = math.min(MilBase.JuggernautSectionMax(id), MilBase.GetJuggernautSection(target, id) + (cfg().EngineerRepairAmount or 70))
				target:SetNWInt(sectionKey(id), value)
				notify(helper, string.upper((cfg().Sections[id] and cfg().Sections[id].name) or id) .. " repaired.", "ok")
				target:EmitSound("items/battery_pickup.wav", 68, 92)
			end
		end
		if target:GetNWBool("mb_jug_incapacitated", false)
			and target:GetNWBool("mb_jug_med_stable", false)
			and target:GetNWBool("mb_jug_eng_stable", false) then
			reviveJuggernaut(target, helper)
		end
	end

	-- The armour inventory is authoritative while active. Pickups and weapons
	-- granted by other systems are rejected unless explicitly configured.
	hook.Add("PlayerCanPickupWeapon", "MilBase.JuggernautWeaponReplacement", function(ply, weapon)
		if not MilBase.IsJuggernaut(ply) or cfg().ReplaceWeaponsWhileActive == false then return end
		if not IsValid(weapon) or not isArmourWeaponClass(weapon:GetClass()) then return false end
	end)

	hook.Add("WeaponEquip", "MilBase.JuggernautWeaponEnforcement", function(weapon, ply)
		if not MilBase.IsJuggernaut(ply) or cfg().ReplaceWeaponsWhileActive == false then return end
		if isArmourWeaponClass(weapon:GetClass()) then return end
		timer.Simple(0, function()
			if IsValid(ply) and MilBase.IsJuggernaut(ply) and IsValid(weapon) then weapon:Remove() end
		end)
	end)

	-- Track the highest point reached during each airborne period. The landing
	-- hook requires both a substantial vertical drop and landing speed, which
	-- prevents ordinary jumps and small steps from activating the slam.
	hook.Add("SetupMove", "MilBase.JuggernautAirborneTracking", function(ply, mv)
		if not MilBase.IsJuggernaut(ply) or not ply:Alive() then return end
		if not ply:OnGround() then
			local z = mv:GetOrigin().z
			if not ply.mb_jugAirborne then
				ply.mb_jugAirborne = true
				ply.mb_jugAirPeakZ = z
			else
				ply.mb_jugAirPeakZ = math.max(ply.mb_jugAirPeakZ or z, z)
			end
		end
	end)

	hook.Add("OnPlayerHitGround", "MilBase.JuggernautAutomaticSlam", function(ply, inWater, onFloater, speed)
		if not MilBase.IsJuggernaut(ply) then return end
		local c = cfg()
		local peak = ply.mb_jugAirPeakZ or ply:GetPos().z
		local dropHeight = math.max(0, peak - ply:GetPos().z)
		local landingSpeed = math.abs(tonumber(speed) or 0)
		ply.mb_jugAirborne = nil
		ply.mb_jugAirPeakZ = nil
		if inWater or onFloater or c.AutomaticSlam == false then return end
		if dropHeight < (c.SlamMinimumDropHeight or 220) then return end
		if landingSpeed < (c.SlamMinimumLandingSpeed or 450) then return end
		MilBase.UseJuggernautSlam(ply, true, dropHeight, landingSpeed)
	end)

	net.Receive("MilBase_JuggernautCommand", function(_, ply)
		if not MilBase.IsJuggernaut(ply) then return end
		if CurTime() < (ply.mb_jugNetAt or 0) then return end
		ply.mb_jugNetAt = CurTime() + 0.12
		local command = string.lower(net.ReadString() or "")
		if command == "shield" then MilBase.ToggleJuggernautShield(ply)
		elseif command == "charge" then MilBase.StartJuggernautCharge(ply)
		elseif command == "lock" then MilBase.ToggleJuggernautArmourLock(ply)
		elseif command == "deactivate" then MilBase.DeactivateJuggernaut(ply)
		end
	end)

	local THINK_STEP = 0.1
	local nextThink = 0
	hook.Add("Think", "MilBase.JuggernautThink", function()
		if CurTime() < nextThink then return end
		nextThink = CurTime() + THINK_STEP
		local c = cfg()

		for _, target in ipairs(player.GetAll()) do
			local suppression = target:GetNWFloat("mb_jug_suppression", 0)
			if suppression > 0 and CurTime() > (target.mb_jugSuppressedAt or 0) + 0.25 then
				target:SetNWFloat("mb_jug_suppression", math.max(0, suppression - (c.SuppressionDecayPerSecond or 22) * THINK_STEP))
			end
		end

		for _, ply in ipairs(player.GetAll()) do
			if not MilBase.IsJuggernaut(ply) or not ply:Alive() then continue end

			if ply:GetNWBool("mb_jug_incapacitated", false) then
				if CurTime() >= ply:GetNWFloat("mb_jug_incap_ends", 0) then
					ply:SetNWBool("mb_jug_incapacitated", false)
					ply:Kill()
				end
				continue
			end

			local power = ply:GetNWFloat("mb_jug_power", 0)
			local usingPower = false
			if ply:GetNWBool("mb_jug_shield_up", false) then
				usingPower = true
				power = power - (c.ShieldPowerPerSecond or 11) * THINK_STEP
				if power <= 0 then power = 0 lowerShield(ply, "Suit power exhausted; shield lowered.") end
			end
			if ply:GetNWBool("mb_jug_lock", false) then
				usingPower = true
				power = power - (c.ArmourLockPowerPerSecond or 20) * THINK_STEP
				if power <= 0 or CurTime() >= (ply.mb_jugLockEnds or 0) then
					power = math.max(0, power)
					endArmourLock(ply, power <= 0 and "Suit power exhausted; armour lock released." or nil)
				end
			end
			if usingPower then
				setPower(ply, power, true)
			elseif CurTime() >= (ply.mb_jugPowerRegenAt or 0) then
				setPower(ply, power + (c.PowerRegenPerSecond or 9) * THINK_STEP)
			end

			if not ply:GetNWBool("mb_jug_shield_up", false) and not ply:GetNWBool("mb_jug_lock", false) and CurTime() >= (ply.mb_jugShieldRegenAt or 0) then
				setShield(ply, ply:GetNWFloat("mb_jug_shield", 0) + (c.ShieldRegenPerSecond or 24) * THINK_STEP)
			end

			if ply:GetNWBool("mb_jug_charging", false) then
				if CurTime() >= (ply.mb_jugChargeEnds or 0) then stopCharge(ply) continue end
				local filter = { ply }
				for ent in pairs(ply.mb_jugChargeHits or {}) do if IsValid(ent) then filter[#filter + 1] = ent end end
				local tr = util.TraceHull({
					start = ply:GetPos() + Vector(0, 0, 4),
					endpos = ply:GetPos() + ply:GetForward() * 48 + Vector(0, 0, 4),
					mins = c.ChargeHullMins or Vector(-22, -22, 0),
					maxs = c.ChargeHullMaxs or Vector(22, 22, 72),
					filter = filter,
					mask = MASK_PLAYERSOLID,
				})
				if tr.Hit then
					local hit = tr.Entity
					if IsValid(hit) and (hit:IsPlayer() or hit:IsNPC() or hit:IsNextBot()) then
						ply.mb_jugChargeHits[hit] = true
						chargeImpact(ply, hit)
					else
						stopCharge(ply)
						util.ScreenShake(tr.HitPos, 5, 6, 0.35, 220)
					end
				end
			end
		end

		-- Engineer/medic interaction channel. Hold E while looking at a nearby
		-- active Juggernaut. The system chooses the next valid operation.
		for _, helper in ipairs(player.GetAll()) do
			if not helper:Alive() then cancelService(helper) continue end
			local service = helper.mb_jugService
			local target = helper:KeyDown(IN_USE) and helper:GetEyeTrace().Entity or NULL
			local validTarget = IsValid(target) and target:IsPlayer() and target ~= helper
				and MilBase.IsJuggernaut(target) and target:GetPos():DistToSqr(helper:GetPos()) <= 135 * 135

			if service then
				if not validTarget or target ~= service.target then cancelService(helper)
				elseif CurTime() >= service.finish then
					finishService(helper, service)
					cancelService(helper)
				else
					helper:SetNWFloat("mb_jug_service_progress", 1 - (service.finish - CurTime()) / service.duration)
				end
				continue
			end
			if not validTarget then continue end

			if target:GetNWBool("mb_jug_incapacitated", false) then
				if isMedic(helper) and not target:GetNWBool("mb_jug_med_stable", false) then
					if c.RequireBandageForStabilize and MilBase.CountItem(helper, "bandage") < 1 then continue end
					beginService(helper, target, "medic", c.MedicStabilizeTime or 4)
				elseif isEngineer(helper) and not target:GetNWBool("mb_jug_eng_stable", false) then
					local item = repairItem(helper)
					if item then beginService(helper, target, "restore", c.EngineerRestoreTime or 6, item) end
				end
			elseif isEngineer(helper) and mostDamagedSection(target) then
				local item = repairItem(helper)
				if item then beginService(helper, target, "repair", c.EngineerRepairTime or 4, item) end
			end
		end
	end)

	MilBase.RegisterChatCommand("juggernaut", {
		help = "(Admin test) Toggle Juggernaut mode: /juggernaut [player]",
		adminOnly = true,
		func = function(ply, _, rawText)
			local target = string.Trim(rawText or "") ~= "" and MilBase.FindPlayer(string.Trim(rawText)) or ply
			if not IsValid(target) then notify(ply, "Player not found.", "warn") return end
			if MilBase.IsJuggernaut(target) then MilBase.DeactivateJuggernaut(target) else MilBase.ActivateJuggernaut(target) end
		end,
	})

	concommand.Add("mb_juggernaut", function(ply, _, args)
		if not IsValid(ply) or not ply:IsAdmin() then return end
		local target = args[1] and MilBase.FindPlayer(args[1]) or ply
		if not IsValid(target) then notify(ply, "Player not found.", "warn") return end
		if MilBase.IsJuggernaut(target) then MilBase.DeactivateJuggernaut(target) else MilBase.ActivateJuggernaut(target) end
	end)

	concommand.Add("mb_juggernaut_model_debug", function(ply)
		if IsValid(ply) and not ply:IsAdmin() then return end
		local model = MilBase.ResolveJuggernautModel(true)
		local message = "[JUGGERNAUT] resolved model: " .. tostring(model or "NONE")
		print(message)
		if IsValid(ply) then notify(ply, message, model and "ok" or "warn") end
	end)

	hook.Add("PlayerDeath", "MilBase.JuggernautDeathCleanup", function(ply)
		if MilBase.IsJuggernaut(ply) then MilBase.DeactivateJuggernaut(ply, true, true) end
		cancelService(ply)
	end)
	hook.Add("PlayerDisconnected", "MilBase.JuggernautDisconnectCleanup", function(ply)
		ply.mb_jugSaved = nil
		ply.mb_jugService = nil
		ply.mb_jugAirborne = nil
		ply.mb_jugAirPeakZ = nil
	end)
	hook.Add("PlayerSpawn", "MilBase.JuggernautSpawnCleanup", function(ply)
		if ply:GetNWBool("mb_jug_active", false) then resetNetworkState(ply) end
		ply.mb_jugSaved = nil
		ply.mb_jugAirborne = nil
		ply.mb_jugAirPeakZ = nil
		cancelService(ply)
	end)

else -- CLIENT
	local function sendCommand(id)
		net.Start("MilBase_JuggernautCommand")
			net.WriteString(id)
		net.SendToServer()
	end

	local function cooldownRemaining(ply, key)
		return math.max(0, ply:GetNWFloat(key, 0) - CurTime())
	end

	local function abilityDefinitions(ply)
		local c = cfg()
		local power = ply:GetNWFloat("mb_jug_power", 0)
		local incap = ply:GetNWBool("mb_jug_incapacitated", false)
		return {
			{ id = "shield", label = ply:GetNWBool("mb_jug_shield_up", false) and "LOWER SHIELD" or "FRONTAL SHIELD", description = "Directional protection", enabled = not incap and ply:GetNWFloat("mb_jug_shield", 0) > 0 and power > 0 },
			{ id = "charge", label = "CHARGE", description = "Power through the front line", cost = c.ChargePowerCost or 30, cooldown = cooldownRemaining(ply, "mb_jug_charge_cd"), enabled = not incap and power >= (c.ChargePowerCost or 30) and cooldownRemaining(ply, "mb_jug_charge_cd") <= 0 },
			{ id = "lock", label = ply:GetNWBool("mb_jug_lock", false) and "RELEASE LOCK" or "ARMOUR LOCK", description = "Stationary damage resistance", cost = c.ArmourLockMinimumPower or 20, cooldown = cooldownRemaining(ply, "mb_jug_lock_cd"), enabled = not incap and (ply:GetNWBool("mb_jug_lock", false) or (power >= (c.ArmourLockMinimumPower or 20) and cooldownRemaining(ply, "mb_jug_lock_cd") <= 0)) },
			{ id = "deactivate", label = "DISENGAGE", description = "Restore normal loadout state", enabled = true, danger = true },
			{ id = "cancel", label = "CANCEL", description = "Close ability wheel", enabled = true },
		}
	end

	local function drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, color)
		local points = {}
		local steps = 12
		for step = 0, steps do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * outerRadius, y = cy + math.sin(angle) * outerRadius }
		end
		for step = steps, 0, -1 do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * innerRadius, y = cy + math.sin(angle) * innerRadius }
		end
		draw.NoTexture()
		surface.SetDrawColor(color)
		surface.DrawPoly(points)
	end

	function MilBase.OpenJuggernautWheel()
		local ply = LocalPlayer()
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then return end
		if IsValid(MilBase.JuggernautWheel) then MilBase.JuggernautWheel:Remove() end
		local abilities = abilityDefinitions(ply)
		local frame = vgui.Create("DFrame")
		MilBase.JuggernautWheel = frame
		frame:SetSize(ScrW(), ScrH())
		frame:SetPos(0, 0)
		frame:SetTitle("")
		frame:ShowCloseButton(false)
		frame:SetDraggable(false)
		frame:MakePopup()
		frame:SetCursor("hand")
		frame.SelectedAbility = nil
		frame.PreviousAbility = nil

		local function metrics(w, h)
			local scale = math.Clamp(math.min(w / 1920, h / 1080), 0.72, 1.2)
			return w * 0.5, h * 0.52, 120 * scale, 320 * scale, scale
		end

		function frame:Think()
			local cx, cy, innerRadius, outerRadius = metrics(self:GetSize())
			local mx, my = gui.MousePos()
			local dx, dy = mx - cx, my - cy
			local distance = math.sqrt(dx * dx + dy * dy)
			local selected
			if distance >= innerRadius and distance <= outerRadius then
				local angle = (math.deg(math.atan2(dy, dx)) + 450) % 360
				local segment = 360 / #abilities
				selected = math.floor((angle + segment * 0.5) / segment) % #abilities + 1
			end
			self.SelectedAbility = selected
			if selected ~= self.PreviousAbility then
				if selected and MilBase.PlayUISound then MilBase.PlayUISound("hover") end
				self.PreviousAbility = selected
			end
		end

		function frame:OnMousePressed(code)
			if code == MOUSE_RIGHT then self:Remove() return end
			if code ~= MOUSE_LEFT then return end
			local ability = self.SelectedAbility and abilities[self.SelectedAbility]
			if not ability or not ability.enabled then return end
			if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			if ability.id ~= "cancel" then sendCommand(ability.id) end
			self:Remove()
		end
		function frame:OnKeyCodePressed(code) if code == KEY_ESCAPE then self:Remove() end end

		frame.Paint = function(self, w, h)
			local ui = MilBase.UI or {}
			local panel = ui.panel or Color(10, 10, 11, 230)
			local hover = ui.hover or Color(255, 198, 60, 25)
			local outline = ui.outline or Color(255, 198, 60, 55)
			local accent = ui.accent or Color(255, 198, 60)
			local text = ui.text or Color(240, 238, 230)
			local dim = ui.dim or Color(170, 162, 140)
			local danger = ui.danger or Color(220, 80, 70)
			if MilBase.DrawBlur then MilBase.DrawBlur(self, 3) end
			surface.SetDrawColor(6, 6, 7, 220)
			surface.DrawRect(0, 0, w, h)
			local cx, cy, innerRadius, outerRadius, scale = metrics(w, h)
			local segment, gap = 360 / #abilities, 2.6
			draw.SimpleText("501ST JUGGERNAUT SYSTEMS", "MB.Big", cx, cy - outerRadius - 72 * scale, text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(accent)
			surface.DrawRect(cx - 100 * scale, cy - outerRadius - 46 * scale, 200 * scale, 2)
			draw.SimpleText("SELECT AN ABILITY", "MB.Tiny", cx, cy - outerRadius - 28 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			for index, ability in ipairs(abilities) do
				local middle = -90 + (index - 1) * segment
				local startAngle = middle - segment * 0.5 + gap
				local endAngle = middle + segment * 0.5 - gap
				local selected = self.SelectedAbility == index
				local base = selected and hover or panel
				if not ability.enabled then base = Color(18, 18, 19, 215) end
				if ability.danger and selected then base = Color(danger.r, danger.g, danger.b, 34) end
				drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, base)
				local edge = not ability.enabled and Color(dim.r, dim.g, dim.b, 35) or selected and (ability.danger and danger or accent) or outline
				drawWheelSector(cx, cy, outerRadius - 2, outerRadius, startAngle, endAngle, edge)
				local angle = math.rad(middle)
				local radius = (innerRadius + outerRadius) * 0.5
				local lx, ly = cx + math.cos(angle) * radius, cy + math.sin(angle) * radius
				local labelColor = not ability.enabled and dim or selected and (ability.danger and danger or accent) or text
				draw.SimpleText(ability.label, "MB.Small", lx, ly - 5 * scale, labelColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				if ability.cooldown and ability.cooldown > 0 then draw.SimpleText(math.ceil(ability.cooldown) .. "s", "MB.Tiny", lx, ly + 14 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				elseif ability.cost and ability.cost > 0 then draw.SimpleText(ability.cost .. " PWR", "MB.Tiny", lx, ly + 14 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) end
			end
			local selected = self.SelectedAbility and abilities[self.SelectedAbility]
			if MilBase.DrawPanelBF2 then MilBase.DrawPanelBF2(cx - innerRadius + 8 * scale, cy - 62 * scale, innerRadius * 2 - 16 * scale, 124 * scale, { color = panel, accent = accent, outlineColor = outline, cut = 9 * scale }) end
			draw.SimpleText(selected and selected.label or "SYSTEMS", "MB.Tab", cx, cy - 22 * scale, selected and (selected.enabled and accent or danger) or text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(selected and selected.description or "MOVE THE CURSOR TO AN ABILITY", "MB.Tiny", cx, cy + 12 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("LMB CONFIRM  •  RMB / ESC CANCEL", "MB.Tiny", cx, cy + 39 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	concommand.Add("mb_juggernaut_wheel", function() MilBase.OpenJuggernautWheel() end)
	hook.Add("PlayerButtonDown", "MilBase.JuggernautWheelKey", function(ply, button)
		if ply ~= LocalPlayer() or button ~= (cfg().WheelKey or KEY_G or 17) then return end
		if gui.IsGameUIVisible() or vgui.CursorVisible() then return end
		MilBase.OpenJuggernautWheel()
	end)

	hook.Add("PostPlayerDraw", "MilBase.JuggernautShieldVisual", function(ply)
		if not MilBase.IsJuggernaut(ply) or not ply:GetNWBool("mb_jug_shield_up", false) then return end
		local pos = ply:WorldSpaceCenter() + ply:GetForward() * 48 + Vector(0, 0, 3)
		local normal = ply:GetForward()
		render.SetColorMaterial()
		render.DrawQuadEasy(pos, -normal, 92, 126, Color(85, 175, 255, 72), ply:GetAngles().y + 90)
		render.DrawQuadEasy(pos, normal, 92, 126, Color(85, 175, 255, 48), ply:GetAngles().y - 90)
		render.DrawWireframeBox(pos, Angle(0, ply:GetAngles().y, 0), Vector(-2, -46, -63), Vector(2, 46, 63), Color(125, 205, 255, 110), true)
	end)

	local lastSwayP, lastSwayY = 0, 0
	hook.Add("CreateMove", "MilBase.JuggernautArmSway", function(cmd)
		local ply = LocalPlayer()
		if not MilBase.IsJuggernaut(ply) or ply:GetNWBool("mb_jug_incapacitated", false) then lastSwayP, lastSwayY = 0, 0 return end
		local broken = 0
		if MilBase.GetJuggernautSection(ply, "left_arm") <= 0 then broken = broken + 1 end
		if MilBase.GetJuggernautSection(ply, "right_arm") <= 0 then broken = broken + 1 end
		local suppression = math.Clamp(ply:GetNWFloat("mb_jug_suppression", 0) / math.max(1, cfg().SuppressionMax or 100), 0, 1)
		if broken == 0 and suppression <= 0 then lastSwayP, lastSwayY = 0, 0 return end
		local t = RealTime()
		local magnitude = broken * (cfg().BrokenArmSway or 0.28) + suppression * 0.22
		local p, y = math.sin(t * 2.15) * magnitude, math.cos(t * 1.55) * magnitude
		local ang = cmd:GetViewAngles()
		ang.p = ang.p + (p - lastSwayP)
		ang.y = ang.y + (y - lastSwayY)
		cmd:SetViewAngles(ang)
		lastSwayP, lastSwayY = p, y
	end)

	local function bar(x, y, w, label, value, maximum, color)
		local fraction = math.Clamp(value / math.max(1, maximum), 0, 1)
		draw.SimpleText(label, "MB.Tiny", x, y, MilBase.UI.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(math.ceil(value) .. " / " .. math.ceil(maximum), "MB.Tiny", x + w, y, MilBase.UI.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		MilBase.DrawBar(x, y + 18, w, 7, fraction, color)
	end

	hook.Add("HUDPaint", "MilBase.JuggernautHUD", function()
		local ply = LocalPlayer()
		if not MilBase.IsJuggernaut(ply) or not ply:Alive() or MilBase.InEventView() then return end
		local ui = MilBase.UI
		local scale = math.Clamp(ScrH() / 1080, 0.75, 1.15)
		local w, h = 430 * scale, 258 * scale
		local x, y = 28 * scale, ScrH() - h - 34 * scale
		MilBase.DrawPanelBF2(x, y, w, h, { color = ui.panel, accent = ui.accent, outlineColor = ui.outline, cut = 10 * scale })
		draw.SimpleText("501ST JUGGERNAUT", "MB.Tab", x + 18 * scale, y + 13 * scale, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(ply:GetNWString("mb_jug_state", "READY"), "MB.Small", x + w - 18 * scale, y + 18 * scale, ui.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		bar(x + 18 * scale, y + 51 * scale, w - 36 * scale, "HEALTH", ply:Health(), ply:GetMaxHealth(), ui.ok)
		bar(x + 18 * scale, y + 86 * scale, w - 36 * scale, "SUIT POWER", ply:GetNWFloat("mb_jug_power", 0), cfg().PowerMax or 100, ui.accent)
		bar(x + 18 * scale, y + 121 * scale, w - 36 * scale, "FRONTAL SHIELD", ply:GetNWFloat("mb_jug_shield", 0), cfg().ShieldMax or 260, Color(95, 180, 255))

		local cellW = (w - 48 * scale) / 3
		for index, id in ipairs(SECTION_ORDER) do
			local col = (index - 1) % 3
			local row = math.floor((index - 1) / 3)
			local cx, cy = x + 18 * scale + col * (cellW + 6 * scale), y + 159 * scale + row * 37 * scale
			local current, maximum = MilBase.GetJuggernautSection(ply, id), MilBase.JuggernautSectionMax(id)
			local fraction = math.Clamp(current / maximum, 0, 1)
			local color = fraction <= 0 and ui.danger or fraction < 0.3 and ui.warn or ui.text
			draw.SimpleText((cfg().Sections[id] and cfg().Sections[id].name) or id, "MB.Tiny", cx, cy, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			MilBase.DrawBar(cx, cy + 17 * scale, cellW, 5 * scale, fraction, color)
		end
		draw.SimpleText("G  ABILITY WHEEL", "MB.Tiny", x + w - 18 * scale, y + h - 17 * scale, ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		local suppression = ply:GetNWFloat("mb_jug_suppression", 0)
		if suppression > 0 then
			local alpha = math.Clamp(suppression / math.max(1, cfg().SuppressionMax or 100) * 95, 0, 95)
			surface.SetDrawColor(120, 20, 20, alpha)
			surface.DrawRect(0, 0, ScrW(), 16)
			surface.DrawRect(0, ScrH() - 16, ScrW(), 16)
			surface.DrawRect(0, 0, 16, ScrH())
			surface.DrawRect(ScrW() - 16, 0, 16, ScrH())
		end

		if ply:GetNWBool("mb_jug_incapacitated", false) then
			surface.SetDrawColor(75, 0, 0, 95)
			surface.DrawRect(0, 0, ScrW(), ScrH())
			draw.SimpleText("EMERGENCY SHUTDOWN", "MB.Huge", ScrW() * 0.5, ScrH() * 0.34, ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			local remain = math.max(0, ply:GetNWFloat("mb_jug_incap_ends", 0) - CurTime())
			draw.SimpleText("TOTAL FAILURE IN " .. math.ceil(remain) .. "s", "MB.Med", ScrW() * 0.5, ScrH() * 0.34 + 50, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			local med = ply:GetNWBool("mb_jug_med_stable", false) and "MEDIC: STABLE" or "MEDIC REQUIRED"
			local eng = ply:GetNWBool("mb_jug_eng_stable", false) and "ENGINEER: STABLE" or "ENGINEER REQUIRED"
			draw.SimpleText(med .. "  •  " .. eng, "MB.Small", ScrW() * 0.5, ScrH() * 0.34 + 82, ui.warn, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local progress = ply:GetNWFloat("mb_jug_service_progress", 0)
		if progress > 0 then
			local pw, ph = 330 * scale, 32 * scale
			local px, py = ScrW() * 0.5 - pw * 0.5, ScrH() * 0.66
			MilBase.DrawPanelBF2(px, py, pw, ph, { cut = 7 * scale })
			MilBase.DrawBar(px + 6 * scale, py + ph - 9 * scale, pw - 12 * scale, 5 * scale, progress, ui.accent)
			draw.SimpleText(ply:GetNWString("mb_jug_service_action", "SERVICING"), "MB.Tiny", ScrW() * 0.5, py + 11 * scale, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end)

	hook.Add("HUDShouldDraw", "MilBase.JuggernautHideDefaultVitals", function(name)
		if not MilBase.IsJuggernaut(LocalPlayer()) then return end
		if name == "CHudHealth" or name == "CHudBattery" then return false end
	end)
end
