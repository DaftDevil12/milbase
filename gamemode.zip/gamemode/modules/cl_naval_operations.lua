if not CLIENT or MilBase.NavalOperationsClientLoaded then return end
MilBase.NavalOperationsClientLoaded = true

local N = MilBase.Naval
local NET_STATE = "MilBase_Naval_State"
local NET_POWER_OPEN = "MilBase_Naval_PowerOpen"
local NET_POWER_APPLY = "MilBase_Naval_PowerApply"
local NET_POWER_CLOSE = "MilBase_Naval_PowerClose"
local NET_CONSOLE_OPEN = "MilBase_Naval_ConsoleOpen"
local NET_CONSOLE_ACTION = "MilBase_Naval_ConsoleAction"

N.ClientState = N.ClientState or {
	resources = {}, power = {}, watches = {}, contacts = {}, incidents = {},
	rescues = {}, squadrons = {}, logs = {}, navigation = {},
	restrictedZones = {}, hangar = {},
}

surface.CreateFont("MBNavalTitle", {
	font = "Bebas Neue", size = 38, weight = 400, extended = true,
})
surface.CreateFont("MBNavalHead", {
	font = "Bebas Neue", size = 25, weight = 400, extended = true,
})
surface.CreateFont("MBNavalText", {
	font = "D-DIN", size = 17, weight = 600, extended = true,
})
surface.CreateFont("MBNavalTiny", {
	font = "D-DIN", size = 14, weight = 600, extended = true,
})
surface.CreateFont("MBNavalMono", {
	font = "D-DIN", size = 15, weight = 700, extended = true,
})

net.Receive(NET_STATE, function()
	local length = net.ReadUInt(32)
	if length <= 0 or length > 1000000 then return end
	local compressed = net.ReadData(length)
	local json = compressed and util.Decompress(compressed)
	local decoded = json and util.JSONToTable(json)
	if istable(decoded) then
		N.ClientState = decoded
		N.ClientReceivedAt = RealTime()
		if IsValid(N.ActiveCICFrame) then
			N.ActiveCICFrame.PendingState = decoded
		end
	end
end)

local UI = MilBase.UI or {}
local C = {
	background = Color(6, 6, 7, 252),
	panel = Color(10, 10, 11, 238),
	panelAlt = Color(255, 198, 60, 13),
	panelHover = Color(255, 198, 60, 25),
	grid = Color(255, 198, 60, 62),
	accent = UI.accent or Color(255, 198, 60),
	text = UI.text or Color(240, 238, 230),
	dim = UI.dim or Color(170, 162, 140),
	faint = UI.faint or Color(112, 106, 92),
	ok = UI.ok or Color(150, 205, 125),
	warn = UI.warn or Color(255, 198, 60),
	danger = UI.danger or Color(220, 80, 70),
	republic = Color(105, 170, 255),
	cis = Color(220, 80, 70),
	civilian = Color(150, 205, 125),
	pirate = Color(236, 145, 55),
}

local function alpha(colour, amount)
	return Color(colour.r, colour.g, colour.b, amount)
end

local function box(x, y, w, h, accent)
	local edge = accent or C.accent
	if MilBase.DrawPanelBF2 then
		MilBase.DrawPanelBF2(x, y, w, h, {
			color = C.panel,
			cut = 10,
			outlineColor = alpha(edge, edge == C.accent and 120 or 76),
			accent = edge,
		})
		return
	end
	surface.SetDrawColor(C.panel)
	surface.DrawRect(x, y, w, h)
	surface.SetDrawColor(edge)
	surface.DrawOutlinedRect(x, y, w, h, 2)
end

local function label(text, font, x, y, color, ax, ay)
	draw.SimpleText(tostring(text or ""), font, x, y, color or C.text,
		ax or TEXT_ALIGN_LEFT, ay or TEXT_ALIGN_TOP)
end

local function header(title, pageName, state)
	surface.SetDrawColor(C.background)
	surface.DrawRect(0, 0, 1024, 620)
	if MilBase.GetUIMat and UI.art and UI.art.bf2 then
		local scanlines = MilBase.GetUIMat(UI.art.bf2.scanlines)
		if scanlines then
			surface.SetMaterial(scanlines)
			surface.SetDrawColor(255, 255, 255, 12)
			surface.DrawTexturedRectUV(0, 0, 1024, 620, 0, 0,
				1024 / math.max(1, scanlines:Width()),
				620 / math.max(1, scanlines:Height()))
		end
	end
	box(20, 12, 984, 72, C.accent)
	surface.SetDrawColor(C.accent)
	surface.DrawRect(0, 0, 1024, 4)
	label("REPUBLIC NAVAL COMMAND", "MBNavalTitle", 38, 17, C.text)
	label(pageName, "MBNavalHead", 984, 21, C.accent, TEXT_ALIGN_RIGHT)
	label(title, "MBNavalTiny", 40, 57, C.dim)
	local stale = not N.ClientReceivedAt or RealTime() - N.ClientReceivedAt > 5
	label(stale and "DATA LINK LOST" or "FLEETNET LIVE", "MBNavalTiny", 984, 57,
		stale and C.danger or C.ok, TEXT_ALIGN_RIGHT)
end

local function factionColour(contact)
	if contact.hostile or contact.faction == "cis" then return C.cis end
	return C[contact.faction] or C.dim
end

local circlePolygons = {}
local function filledCircle(cx, cy, radius, colour, segments)
	segments = segments or 64
	local key = string.format("%d:%d:%d:%d", math.Round(cx), math.Round(cy),
		math.Round(radius), segments)
	local points = circlePolygons[key]
	if not points then
		points = {}
		for index = 0, segments - 1 do
			local angle = math.pi * 2 * index / segments
			points[#points + 1] = {
				x = cx + math.cos(angle) * radius,
				y = cy + math.sin(angle) * radius,
			}
		end
		circlePolygons[key] = points
	end
	draw.NoTexture()
	surface.SetDrawColor(colour)
	surface.DrawPoly(points)
end

local function radarPoint(cx, cy, radius, rawX, rawY, inset)
	local x = tonumber(rawX) or 0
	local y = tonumber(rawY) or 0
	local magnitude = math.sqrt(x * x + y * y)
	local limit = math.max(1, radius - (inset or 0))
	if magnitude > 1 then
		x = x / magnitude
		y = y / magnitude
	end
	return cx + x * limit, cy + y * limit
end

local function clampToRadar(cx, cy, radius, x, y, inset)
	local dx, dy = x - cx, y - cy
	local distance = math.sqrt(dx * dx + dy * dy)
	local limit = math.max(1, radius - (inset or 0))
	if distance > limit and distance > 0 then
		local scale = limit / distance
		return cx + dx * scale, cy + dy * scale
	end
	return x, y
end

local function clippedCircle(cx, cy, circleX, circleY, circleRadius, clipRadius, colour)
	local lastX, lastY
	for index = 0, 48 do
		local angle = math.pi * 2 * index / 48
		local x = circleX + math.cos(angle) * circleRadius
		local y = circleY + math.sin(angle) * circleRadius
		local inside = (x - cx) ^ 2 + (y - cy) ^ 2 <= clipRadius ^ 2
		if inside and lastX then
			surface.SetDrawColor(colour)
			surface.DrawLine(lastX, lastY, x, y)
		end
		lastX, lastY = inside and x or nil, inside and y or nil
	end
end

local function drawRadarMarker(x, y, size, colour, hostile)
	if MilBase.DrawDiamond then
		MilBase.DrawDiamond(x, y, size, colour, hostile)
		return
	end
	surface.SetDrawColor(colour)
	if hostile then
		surface.DrawOutlinedRect(x - size, y - size, size * 2, size * 2, 2)
	else
		surface.DrawRect(x - size / 2, y - size / 2, size, size)
	end
end

local function drawCircularRadar(state, cx, cy, radius, options)
	options = options or {}
	filledCircle(cx, cy, radius, Color(2, 2, 3, 238), 72)
	if MilBase.DrawIcon and UI.art and UI.art.bf2 then
		MilBase.DrawIcon(UI.art.bf2.glow, cx - radius, cy - radius,
			radius * 2, radius * 2, Color(C.accent.r, C.accent.g, C.accent.b, 18))
	end

	for ring = 1, 4 do
		local ringRadius = radius * ring / 4
		surface.SetDrawColor(ring == 4 and alpha(C.accent, 180) or C.grid)
		surface.DrawCircle(cx, cy, ringRadius, ring == 4 and alpha(C.accent, 180) or C.grid)
	end
	surface.SetDrawColor(C.grid)
	surface.DrawLine(cx - radius, cy, cx + radius, cy)
	surface.DrawLine(cx, cy - radius, cx, cy + radius)
	for bearing = 0, 330, 30 do
		local angle = math.rad(bearing - 90)
		local outerX = cx + math.cos(angle) * radius
		local outerY = cy + math.sin(angle) * radius
		local innerX = cx + math.cos(angle) * (radius - (bearing % 90 == 0 and 10 or 6))
		local innerY = cy + math.sin(angle) * (radius - (bearing % 90 == 0 and 10 or 6))
		surface.DrawLine(innerX, innerY, outerX, outerY)
	end
	label("N", "MBNavalTiny", cx, cy - radius + 10, C.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	label("E", "MBNavalTiny", cx + radius - 10, cy, C.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	label("S", "MBNavalTiny", cx, cy + radius - 10, C.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	label("W", "MBNavalTiny", cx - radius + 10, cy, C.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	for _, zone in ipairs(state.restrictedZones or {}) do
		if zone.localZone then
			local zx, zy = radarPoint(cx, cy, radius, zone.x, zone.y, 4)
			local zoneRadius = math.max(10,
				math.Clamp(tonumber(zone.radius) or 0.65, 0.05, 1) * radius)
			clippedCircle(cx, cy, zx, zy, zoneRadius, radius - 2, alpha(C.warn, 155))
			if options.labels then
				label(string.sub(tostring(zone.name or "RESTRICTED"), 1, 20),
					"MBNavalTiny", zx, math.max(cy - radius + 20, zy - 17),
					C.warn, TEXT_ALIGN_CENTER)
			end
		end
	end

	for _, contact in ipairs(state.contacts or {}) do
		local x, y = radarPoint(cx, cy, radius, contact.x, contact.y, 9)
		local vectorScale = radius * 0.16
		local vectorX = x + (tonumber(contact.vx) or 0) * vectorScale
		local vectorY = y + (tonumber(contact.vy) or 0) * vectorScale
		vectorX, vectorY = clampToRadar(cx, cy, radius, vectorX, vectorY, 4)
		local colour = factionColour(contact)
		surface.SetDrawColor(alpha(colour, 130))
		surface.DrawLine(x, y, vectorX, vectorY)
		drawRadarMarker(x, y, contact.hostile and 7 or 5, colour, contact.hostile == true)
		if options.labels then
			local align = x > cx + radius * 0.62 and TEXT_ALIGN_RIGHT or TEXT_ALIGN_LEFT
			local offset = align == TEXT_ALIGN_RIGHT and -10 or 10
			label(string.sub(tostring(contact.name or "CONTACT"), 1, 17),
				"MBNavalTiny", x + offset, y - 8, colour, align)
		end
	end

	drawRadarMarker(cx, cy, 8, C.republic, true)
	if options.labels then
		label("OUR SHIP", "MBNavalTiny", cx + 13, cy - 8, C.republic)
	end

	local intercept = state.intercept
	if istable(intercept) then
		local ix, iy = radarPoint(cx, cy, radius, intercept.x, intercept.y, 10)
		surface.SetDrawColor(C.warn)
		surface.DrawLine(ix - 8, iy, ix + 8, iy)
		surface.DrawLine(ix, iy - 8, ix, iy + 8)
		if options.labels then
			local align = ix > cx and TEXT_ALIGN_RIGHT or TEXT_ALIGN_LEFT
			label("INTERCEPT " .. math.floor(tonumber(intercept.seconds) or 0) .. "S",
				"MBNavalTiny", ix + (align == TEXT_ALIGN_RIGHT and -11 or 11),
				iy + 9, C.warn, align)
		end
	end
end

local function tactical(state)
	header("Real-time skybox contacts and flight vectors", "TACTICAL PLOT", state)
	box(24, 102, 700, 480, C.accent)
	label("LIVE SENSOR SCOPE", "MBNavalHead", 44, 118, C.accent)
	label("RELATIVE BEARING / LOCAL CONTROL SPACE", "MBNavalTiny", 44, 145, C.dim)
	drawCircularRadar(state, 374, 354, 202, { labels = true })

	box(742, 102, 258, 480, C.grid)
	label("CONTACT REGISTER", "MBNavalHead", 760, 118, C.accent)
	local y = 154
	for index, contact in ipairs(state.contacts or {}) do
		if index > 15 then break end
		local color = factionColour(contact)
		label(string.format("%03d", tonumber(contact.id) or 0), "MBNavalMono", 760, y, C.dim)
		label(string.sub(tostring(contact.name or "UNKNOWN"), 1, 20), "MBNavalText", 802, y, color)
		local status = contact.iff ~= "" and contact.iff or contact.state or ""
		label(string.sub(string.upper(tostring(status)), 1, 28),
			"MBNavalTiny", 802, y + 18,
			contact.iff == "AUTHENTICATED" and C.ok or C.dim)
		y = y + 29
	end
end

local function navigation(state)
	header("SWU navigation, bridge watches and current fleet order", "BRIDGE / NAVIGATION", state)
	local nav = state.navigation or {}
	box(24, 102, 470, 196, C.accent)
	label("NAVIGATION SOLUTION", "MBNavalHead", 44, 120, C.accent)
	label(string.upper(nav.planet or "DEEP SPACE"), "MBNavalTitle", 44, 154, C.text)
	label(nav.destination ~= "" and ("DESTINATION  " .. string.upper(nav.destination))
		or "NO HYPERSPACE DESTINATION SET", "MBNavalText", 44, 199, C.dim)
	label(string.format("ACTUAL THROTTLE  %03d%%", math.floor(tonumber(nav.throttle) or 0)),
		"MBNavalMono", 44, 237, C.ok)
	label(string.format("ORDERED THROTTLE %03d%%", math.floor(tonumber(nav.targetThrottle) or 0)),
		"MBNavalMono", 264, 237, C.warn)
	label(nav.hyperspace and "HYPERSPACE TRANSIT" or "REALSPACE TRANSIT",
		"MBNavalText", 44, 270, nav.hyperspace and C.warn or C.accent)

	box(514, 102, 486, 196, C.grid)
	label("COMMAND STATE", "MBNavalHead", 534, 120, C.accent)
	label("FLEET ORDER", "MBNavalTiny", 534, 163, C.dim)
	label(string.upper(state.fleetOrder or "INDEPENDENT OPERATIONS"), "MBNavalHead", 534, 184, C.text)
	label("TRAFFIC CONTROL", "MBNavalTiny", 534, 228, C.dim)
	label(string.upper(state.trafficNotice or "NORMAL TRANSIT"), "MBNavalText", 534, 249, C.ok)
	if istable(state.intercept) then
		label("ACTIVE INTERCEPT", "MBNavalTiny", 770, 163, C.warn)
		label(string.sub(string.upper(state.intercept.name or "CONTACT"), 1, 24),
			"MBNavalText", 770, 184, C.text)
		label(string.format("BRG %03d  ETA %ds", tonumber(state.intercept.bearing) or 0,
			tonumber(state.intercept.seconds) or 0), "MBNavalMono", 770, 210, C.warn)
	end

	box(24, 318, 976, 264, C.grid)
	label("CURRENT WATCH BILL", "MBNavalHead", 44, 336, C.accent)
	local stations = (MilBase.Config.NavalOperations or {}).WatchStations or {}
	for i, station in ipairs(stations) do
		local col = (i - 1) % 3
		local row = math.floor((i - 1) / 3)
		local x, y = 44 + col * 314, 379 + row * 60
		local watch = state.watches and state.watches[station]
		label(string.upper(station:gsub("_", " ")), "MBNavalTiny", x, y, C.dim)
		label(watch and string.upper(watch.name or "MANNED") or "STATION UNMANNED",
			"MBNavalText", x, y + 20, watch and C.ok or C.warn)
	end
end

local function engineering(state)
	header("Live power distribution and physical damage-control incidents", "ENGINEERING", state)
	box(24, 102, 510, 480, C.accent)
	label("POWER DISTRIBUTION", "MBNavalHead", 44, 120, C.accent)
	local total, y = 0, 164
	for _, key in ipairs((MilBase.Config.NavalOperations or {}).PowerSystems or {}) do
		local amount = tonumber(state.power and state.power[key]) or 0
		total = total + amount
		label(N.PowerLabels[key] or string.upper(key), "MBNavalText", 44, y, C.text)
		surface.SetDrawColor(C.panelAlt)
		surface.DrawRect(220, y + 2, 250, 17)
		surface.SetDrawColor(amount < 7 and C.danger or amount < 12 and C.warn or C.ok)
		surface.DrawRect(220, y + 2, 250 * math.Clamp(amount / 35, 0, 1), 17)
		label(amount .. "%", "MBNavalMono", 486, y, C.text, TEXT_ALIGN_RIGHT)
		y = y + 48
	end
	label("TOTAL ALLOCATION " .. total .. "%", "MBNavalHead", 44, 538,
		total > 100 and C.danger or C.accent)

	box(554, 102, 446, 480, C.grid)
	label("DAMAGE CONTROL", "MBNavalHead", 574, 120, C.accent)
	y = 164
	local open = 0
	for _, incident in ipairs(state.incidents or {}) do
		if incident.status ~= "SEALED" then
			open = open + 1
			label(string.upper(tostring(incident.severity or "DAMAGED")), "MBNavalTiny",
				574, y, incident.severity == "CRITICAL" and C.danger or C.warn)
			label(string.upper(tostring(incident.system or "SHIP SYSTEM"):gsub("mb_", "")),
				"MBNavalText", 574, y + 19, C.text)
			label(string.upper(tostring(incident.assignment or "REPAIR TEAM REQUIRED"))
				.. (incident.priority and (" / PRIORITY " .. incident.priority) or ""),
				"MBNavalTiny", 574, y + 40,
				incident.assignment and C.ok or C.dim)
			y = y + 72
			if open >= 5 then break end
		end
	end
	if open == 0 then
		label("ALL COMPARTMENTS REPORT SECURE", "MBNavalHead", 574, 184, C.ok)
		label("No open breaches, damaged nodes or failed terminals.",
			"MBNavalText", 574, 224, C.dim)
	end
end

local function powerCondition(key, amount)
	local factor = N.PowerFactorForAllocation(key, amount)
	if amount <= 0 then return "OFFLINE", C.danger, factor end
	if factor < 0.7 then return "BROWNOUT", C.danger, factor end
	if factor < 0.95 then return "REDUCED", C.warn, factor end
	if factor > 1.05 then return "BOOSTED", C.accent, factor end
	return "NOMINAL", C.ok, factor
end

function N.DrawPowerConsole(operator)
	local state = N.ClientState or {}
	local config = MilBase.Config.NavalOperations or {}
	local capacity = math.max(1, tonumber(config.PowerCapacity) or 100)
	header("Primary reactor routing and subsystem output", "POWER DISTRIBUTION", state)
	local total = 0
	for _, key in ipairs(config.PowerSystems or {}) do
		total = total + (tonumber(state.power and state.power[key]) or 0)
	end

	box(24, 104, 976, 88, C.accent)
	label("REACTOR LOAD", "MBNavalTiny", 44, 120, C.dim)
	label(string.format("%03d%%", total), "MBNavalTitle", 44, 140,
		total > capacity and C.danger or total > capacity * 0.92 and C.warn or C.ok)
	label("AVAILABLE RESERVE", "MBNavalTiny", 280, 120, C.dim)
	label(string.format("%03d%%", math.max(0, capacity - total)), "MBNavalTitle", 280, 140,
		capacity - total < 5 and C.warn or C.accent)
	label("CONSOLE OPERATOR", "MBNavalTiny", 610, 120, C.dim)
	local operatorName = IsValid(operator)
		and string.upper(operator.MBName and operator:MBName() or operator:Nick())
		or "STATION AVAILABLE"
	label(operatorName, "MBNavalHead", 610, 146, IsValid(operator) and C.ok or C.warn)

	local systems = config.PowerSystems or {}
	for index, key in ipairs(systems) do
		local column = (index - 1) % 2
		local row = math.floor((index - 1) / 2)
		local x, y = 24 + column * 494, 210 + row * 84
		local amount = tonumber(state.power and state.power[key]) or 0
		local condition, colour, factor = powerCondition(key, amount)
		box(x, y, 482, 70, colour)
		label(N.PowerLabels[key] or string.upper(key), "MBNavalHead", x + 18, y + 11, C.text)
		label(condition, "MBNavalTiny", x + 18, y + 42, colour)
		surface.SetDrawColor(C.panelAlt)
		surface.DrawRect(x + 190, y + 19, 205, 18)
		surface.SetDrawColor(colour)
		surface.DrawRect(x + 190, y + 19,
			205 * math.Clamp(amount / math.max(1, tonumber(config.PowerSystemMaximum) or 60), 0, 1), 18)
		label(amount .. "%", "MBNavalMono", x + 462, y + 13, C.text, TEXT_ALIGN_RIGHT)
		label("OUTPUT " .. math.floor(factor * 100) .. "%", "MBNavalTiny",
			x + 462, y + 43, C.dim, TEXT_ALIGN_RIGHT)
	end

	box(24, 556, 976, 42, C.grid)
	local authorised = N.IsNavy and N.IsNavy(LocalPlayer())
	label(not authorised and "ACCESS RESTRICTED — REPUBLIC NAVY ENGINEERING CREDENTIALS REQUIRED"
		or IsValid(operator) and "STATION IN USE — POWER ROUTING CONTROLS OPEN ON OPERATOR DISPLAY"
		or "PRESS E ON THIS DISPLAY TO ASSUME ENGINEERING WATCH AND ROUTE POWER",
		"MBNavalText", 512, 577, not authorised and C.danger
			or IsValid(operator) and C.ok or C.accent,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function logistics(state)
	header("Persistent stores, vehicle recovery and squadron readiness", "LOGISTICS / AIR WING", state)
	box(24, 102, 976, 192, C.accent)
	label("SHIP STORES", "MBNavalHead", 44, 120, C.accent)
	local maxima = (MilBase.Config.NavalOperations or {}).ResourceMaximums or {}
	for i, key in ipairs(N.ResourceOrder or {}) do
		local col = (i - 1) % 3
		local row = math.floor((i - 1) / 3)
		local x, y = 44 + col * 314, 164 + row * 62
		local amount = tonumber(state.resources and state.resources[key]) or 0
		local maximum = math.max(1, tonumber(maxima[key]) or amount)
		label(N.ResourceLabels[key] or string.upper(key), "MBNavalTiny", x, y, C.dim)
		label(string.Comma(amount), "MBNavalHead", x, y + 20,
			amount / maximum < 0.15 and C.danger or amount / maximum < 0.3 and C.warn or C.ok)
	end

	box(24, 314, 976, 268, C.grid)
	label("REPUBLIC AIR WING", "MBNavalHead", 44, 332, C.accent)
	local squadrons = {}
	for _, squadron in pairs(state.squadrons or {}) do squadrons[#squadrons + 1] = squadron end
	table.sort(squadrons, function(a, b) return tostring(a.name) < tostring(b.name) end)
	for i, squadron in ipairs(squadrons) do
		local x = 44 + (i - 1) * 314
		label(string.upper(squadron.name or "SQUADRON"), "MBNavalHead", x, 378, C.text)
		label(string.upper(squadron.craft or "FIGHTER"), "MBNavalText", x, 410, C.dim)
		label(string.format("READY %d / %d", tonumber(squadron.ready) or 0,
			tonumber(squadron.total) or 0), "MBNavalMono", x, 448, C.ok)
		label("ORDER  " .. string.upper(squadron.order or "STANDBY"),
			"MBNavalText", x, 480, C.warn)
		label(string.upper(squadron.status or "READY"), "MBNavalTiny", x, 512, C.dim)
	end
	local fleet = state.fleet or {}
	local hangar = state.hangar or {}
	label("SUPPORT FLEET  " .. math.floor(tonumber(fleet.shipCount) or 0)
		.. " SHIPS   /   GROUND VEHICLE BERTHS  "
		.. math.floor(tonumber(fleet.groundVehicleCapacity) or 0)
		.. "   /   " .. string.upper(tostring(fleet.formation or "vee"))
		.. " FORMATION " .. math.floor(tonumber(fleet.formationRange) or 10) .. "%",
		"MBNavalTiny", 44, 540, C.accent)
	label("DEPLOYED VEHICLES " .. math.floor(tonumber(hangar.deployedVehicles) or 0)
		.. "   /   DAMAGED " .. math.floor(tonumber(hangar.damagedVehicles) or 0)
		.. "   /   RETURN CRAFT EMPTY AND STATIONARY TO RECOVER STORES.",
		"MBNavalTiny", 44, 562,
		(tonumber(hangar.damagedVehicles) or 0) > 0 and C.warn or C.dim)
end

local function operations(state)
	header("Search and rescue board with captain's log and after-action entries", "OPERATIONS LOG", state)
	box(24, 102, 438, 480, C.accent)
	label("SEARCH AND RESCUE", "MBNavalHead", 44, 120, C.accent)
	local y = 162
	for i, mission in ipairs(state.rescues or {}) do
		if i > 6 then break end
		label("#" .. tostring(mission.id) .. "  " .. string.upper(mission.name or "DISTRESS"),
			"MBNavalText", 44, y, C.text)
		label(string.upper(mission.status or "UNKNOWN"), "MBNavalTiny", 44, y + 22,
			mission.status == "SURVIVORS RECOVERED" and C.ok or C.warn)
		label(string.sub(tostring(mission.detail or ""), 1, 48), "MBNavalTiny", 44, y + 41, C.dim)
		y = y + 68
	end
	if #(state.rescues or {}) == 0 then
		label("NO ACTIVE DISTRESS BEACONS", "MBNavalHead", 44, 174, C.ok)
	end

	box(482, 102, 518, 480, C.grid)
	label("SHIP'S LOG", "MBNavalHead", 502, 120, C.accent)
	y = 158
	for i, entry in ipairs(state.logs or {}) do
		if i > 9 then break end
		local stamp = os.date("%H:%M", tonumber(entry.time) or os.time())
		label(stamp, "MBNavalMono", 502, y, C.dim)
		label(string.upper(string.sub(tostring(entry.title or "ENTRY"), 1, 34)),
			"MBNavalText", 560, y, C.text)
		label(string.sub(tostring(entry.detail or ""), 1, 62), "MBNavalTiny", 560, y + 21, C.dim)
		y = y + 45
	end
end

local function restrictedSpace(state)
	header("Republic-controlled navigation zones, IFF challenges and active violations",
		"CONTROLLED SPACE", state)
	box(24, 102, 640, 480, C.warn)
	label("DECLARED NAVIGATION ZONES", "MBNavalHead", 44, 120, C.warn)
	local y = 162
	for index, zone in ipairs(state.restrictedZones or {}) do
		if index > 7 then break end
		local active = zone.localZone == true
		local colour = active and C.warn or C.dim
		label(string.upper(tostring(zone.name or "RESTRICTED AREA")), "MBNavalHead",
			44, y, colour)
		label(string.upper(tostring(zone.planetKey or "DEEP SPACE"))
			.. "  /  RADIUS " .. math.Round((tonumber(zone.radius) or 0) * 100) .. "%"
			.. "  /  " .. tostring(#(zone.violations or {})) .. " VIOLATIONS",
			"MBNavalTiny", 44, y + 27,
			#(zone.violations or {}) > 0 and C.danger or C.dim)
		y = y + 58
	end
	if #(state.restrictedZones or {}) == 0 then
		label("NO RESTRICTED NAVIGATION ZONES DECLARED", "MBNavalHead", 44, 174, C.ok)
	end

	box(684, 102, 316, 480, C.grid)
	label("ENFORCEMENT DOCTRINE", "MBNavalHead", 704, 120, C.accent)
	label("REPUBLIC", "MBNavalTiny", 704, 170, C.republic)
	label("AUTOMATICALLY AUTHORISED", "MBNavalText", 704, 191, C.ok)
	label("CIVILIAN / PIRATE", "MBNavalTiny", 704, 238, C.dim)
	label("CHALLENGE AND REROUTE", "MBNavalText", 704, 259, C.warn)
	label("CONFEDERACY", "MBNavalTiny", 704, 306, C.cis)
	label("HOSTILE INCURSION", "MBNavalText", 704, 327, C.danger)
	label("FLAGSHIP TRANSPONDER", "MBNavalTiny", 704, 386, C.dim)
	label(string.upper(tostring(state.transponderMode or "active"):gsub("_", " ")),
		"MBNavalText", 704, 407, C.ok)
	label("Nearby Republic patrols automatically intercept hostile violators.",
		"MBNavalTiny", 704, 474, C.dim)
	label("Use the CIC console to declare, inspect or lift controlled space.",
		"MBNavalTiny", 704, 510, C.accent)
end

N.CICPages = {
	[0] = tactical,
	[1] = navigation,
	[2] = engineering,
	[3] = logistics,
	[4] = operations,
	[5] = restrictedSpace,
}

function N.DrawCIC(page)
	local state = N.ClientState or {}
	local drawPage = N.CICPages[tonumber(page) or 0] or N.CICPages[0]
	drawPage(state)
	local authorised = N.IsNavy and N.IsNavy(LocalPlayer())
	label(authorised and "PRESS E FOR NAVAL COMMAND INTERFACE"
		or "VIEW ONLY — REPUBLIC NAVY CREDENTIALS REQUIRED",
		"MBNavalTiny", 996, 596, authorised and C.accent or C.danger,
		TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
end

local activePowerFrame

local function powerButton(parent, text, colour, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local hovered = self:IsHovered()
		surface.SetDrawColor(hovered and Color(
			math.min(255, colour.r + 24), math.min(255, colour.g + 24),
			math.min(255, colour.b + 24), 245) or Color(colour.r, colour.g, colour.b, 220))
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		if hovered then
			surface.SetDrawColor(colour.r, colour.g, colour.b, 32)
			surface.DrawRect(2, 2, w - 4, h - 4)
		end
		draw.SimpleText(text, "MBNavalText", w / 2, h / 2, C.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = callback
	return button
end

function N.OpenPowerConsole(console)
	if not IsValid(console) then return end
	if IsValid(activePowerFrame) then
		activePowerFrame.SuppressRelease = true
		activePowerFrame:Remove()
	end
	local config = MilBase.Config.NavalOperations or {}
	local systems = config.PowerSystems or {}
	local capacity = math.max(1, math.floor(tonumber(config.PowerCapacity) or 100))
	local maximum = math.max(1, math.floor(tonumber(config.PowerSystemMaximum) or 60))
	local lifeMinimum = math.max(0, math.floor(tonumber(config.PowerLifeSupportMinimum) or 8))
	local pending, sliders = {}, {}
	for _, key in ipairs(systems) do
		pending[key] = math.floor(tonumber(N.ClientState.power and N.ClientState.power[key]) or 0)
	end

	local frame = vgui.Create("DFrame")
	activePowerFrame = frame
	frame:SetSize(math.min(1120, ScrW() - 40), math.min(780, ScrH() - 40))
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(true)
	frame.Paint = function(self, w, h)
		surface.SetDrawColor(C.background)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(C.accent)
		surface.DrawRect(0, 0, w, 5)
		surface.SetDrawColor(C.grid)
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		draw.SimpleText("REPUBLIC REACTOR CONTROL", "MBNavalTitle", 28, 22, C.text)
		draw.SimpleText("ENGINEERING / POWER DISTRIBUTION", "MBNavalText", 30, 64, C.accent)
	end
	frame.OnRemove = function(self)
		if activePowerFrame == self then activePowerFrame = nil end
		if self.SuppressRelease or not IsValid(console) then return end
		net.Start(NET_POWER_CLOSE)
			net.WriteEntity(console)
		net.SendToServer()
	end

	local close = powerButton(frame, "CLOSE", C.danger, function() frame:Remove() end)
	close:SetSize(100, 36)
	close:SetPos(frame:GetWide() - 124, 25)

	local presetPanel = vgui.Create("DPanel", frame)
	presetPanel:SetPos(28, 96)
	presetPanel:SetSize(frame:GetWide() - 56, 66)
	presetPanel.Paint = function(self, w, h)
		surface.SetDrawColor(C.panel)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(C.grid)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText("ROUTING PRESETS", "MBNavalTiny", 14, 10, C.dim)
	end
	local presetList = {}
	for id, preset in pairs(config.PowerPresets or {}) do
		presetList[#presetList + 1] = { id = id, data = preset }
	end
	table.sort(presetList, function(a, b) return tostring(a.id) < tostring(b.id) end)
	for index, entry in ipairs(presetList) do
		local preset = entry.data
		local button = powerButton(presetPanel, tostring(preset.label or entry.id):upper(),
			C.accent, function()
				for _, key in ipairs(systems) do
					pending[key] = math.Clamp(math.floor(tonumber(preset[key]) or 0), 0, maximum)
					if IsValid(sliders[key]) then sliders[key]:SetValue(pending[key]) end
				end
			end)
		button:SetSize(180, 34)
		button:SetPos(14 + (index - 1) * 192, 27)
	end

	local rowTop = 178
	local rowHeight = 62
	for index, key in ipairs(systems) do
		local panel = vgui.Create("DPanel", frame)
		panel:SetPos(28, rowTop + (index - 1) * rowHeight)
		panel:SetSize(frame:GetWide() - 56, 54)
		panel.Paint = function(self, w, h)
			local condition, colour, factor = powerCondition(key, pending[key] or 0)
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(colour)
			surface.DrawRect(0, 0, 4, h)
			draw.SimpleText(N.PowerLabels[key] or string.upper(key), "MBNavalHead",
				18, h / 2, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(condition .. " / OUTPUT " .. math.floor(factor * 100) .. "%",
				"MBNavalTiny", 245, h / 2, colour, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText((pending[key] or 0) .. "%", "MBNavalHead",
				w - 22, h / 2, C.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local minus = powerButton(panel, "−", C.warn, function()
			pending[key] = math.max(0, (pending[key] or 0) - 1)
			sliders[key]:SetValue(pending[key])
		end)
		minus:SetSize(34, 32)
		minus:SetPos(470, 11)

		local slider = vgui.Create("DNumSlider", panel)
		sliders[key] = slider
		slider:SetPos(510, 4)
		slider:SetSize(panel:GetWide() - 620, 46)
		slider:SetText("")
		slider:SetMinMax(0, maximum)
		slider:SetDecimals(0)
		slider:SetValue(pending[key])
		slider.OnValueChanged = function(_, value)
			pending[key] = math.Clamp(math.floor((tonumber(value) or 0) + 0.5), 0, maximum)
		end

		local plus = powerButton(panel, "+", C.ok, function()
			pending[key] = math.min(maximum, (pending[key] or 0) + 1)
			sliders[key]:SetValue(pending[key])
		end)
		plus:SetSize(34, 32)
		plus:SetPos(panel:GetWide() - 94, 11)
	end

	local footerY = rowTop + #systems * rowHeight + 6
	local totalLabel = vgui.Create("DLabel", frame)
	totalLabel:SetFont("MBNavalHead")
	totalLabel:SetPos(30, footerY)
	totalLabel:SetSize(560, 34)

	local warningLabel = vgui.Create("DLabel", frame)
	warningLabel:SetFont("MBNavalText")
	warningLabel:SetPos(30, footerY + 34)
	warningLabel:SetSize(690, 28)

	local reset = powerButton(frame, "RESET TO LIVE", C.warn, function()
		for _, key in ipairs(systems) do
			pending[key] = math.floor(tonumber(N.ClientState.power and N.ClientState.power[key]) or 0)
			if IsValid(sliders[key]) then sliders[key]:SetValue(pending[key]) end
		end
	end)
	reset:SetSize(180, 42)
	reset:SetPos(frame:GetWide() - 408, footerY + 4)

	local apply = powerButton(frame, "APPLY DISTRIBUTION", C.ok, function()
		if not IsValid(console) then frame:Remove() return end
		net.Start(NET_POWER_APPLY)
			net.WriteEntity(console)
			for _, key in ipairs(systems) do
				net.WriteUInt(math.Clamp(math.floor(pending[key] or 0), 0, 127), 7)
			end
		net.SendToServer()
	end)
	apply:SetSize(210, 42)
	apply:SetPos(frame:GetWide() - 218, footerY + 4)

	frame.Think = function()
		if not IsValid(console) then frame:Remove() return end
		local total = 0
		for _, key in ipairs(systems) do total = total + (pending[key] or 0) end
		local reserve = capacity - total
		local valid = total <= capacity and (pending.life_support or 0) >= lifeMinimum
		totalLabel:SetText("REACTOR LOAD " .. total .. "%   /   RESERVE " .. math.max(0, reserve) .. "%")
		totalLabel:SetTextColor(valid and (reserve < 5 and C.warn or C.ok) or C.danger)
		if total > capacity then
			warningLabel:SetText("OVER CAPACITY BY " .. (total - capacity) .. "% — REDUCE ALLOCATION")
			warningLabel:SetTextColor(C.danger)
		elseif (pending.life_support or 0) < lifeMinimum then
			warningLabel:SetText("LIFE SUPPORT SAFETY INTERLOCK REQUIRES " .. lifeMinimum .. "%")
			warningLabel:SetTextColor(C.danger)
		else
			warningLabel:SetText("ALLOCATIONS APPLY TO LIVE SHIELDS, WEAPONS, SENSORS, COMMS AND PROPULSION")
			warningLabel:SetTextColor(C.dim)
		end
		apply:SetEnabled(valid)
		apply:SetAlpha(valid and 255 or 90)
	end
end

net.Receive(NET_POWER_OPEN, function()
	local console = net.ReadEntity()
	if IsValid(console) then N.OpenPowerConsole(console) end
end)

local function sendCICAction(console, action, first, second, third)
	if not IsValid(console) then return end
	net.Start(NET_CONSOLE_ACTION)
		net.WriteEntity(console)
		net.WriteString(tostring(action or ""))
		net.WriteString(tostring(first or ""))
		net.WriteString(tostring(second or ""))
		net.WriteString(tostring(third or ""))
	net.SendToServer()
end

local function consoleButton(parent, text, colour, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local hovered = self:IsHovered() and self:IsEnabled()
		local fill = hovered and alpha(colour, 30) or C.panelAlt
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = fill,
				cut = 6,
				outlineColor = alpha(colour, hovered and 190 or 90),
				accent = colour,
			})
		else
			surface.SetDrawColor(fill)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(colour)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
		end
		draw.SimpleText(text, "MBNavalTiny", w / 2, h / 2,
			self:IsEnabled() and (hovered and colour or C.text) or C.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.OnCursorEntered = function()
		if MilBase.PlayUISound then MilBase.PlayUISound("hover") end
	end
	button.DoClick = callback
	return button
end

local function consoleLabel(parent, text, font, colour)
	local item = vgui.Create("DLabel", parent)
	item:SetText(tostring(text or ""))
	item:SetFont(font or "MBNavalText")
	item:SetTextColor(colour or C.text)
	item:SetContentAlignment(4)
	return item
end

local function sectionTitle(parent, title, subtitle)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(68)
	panel:DockMargin(0, 0, 8, 10)
	panel.Paint = function(_, w, h)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = C.panel,
				cut = 8,
				outlineColor = C.grid,
				accent = C.accent,
			})
		else
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
		end
		draw.SimpleText(title, "MBNavalHead", 18, 12, C.text)
		draw.SimpleText(subtitle or "", "MBNavalTiny", 18, 40, C.dim)
	end
	return panel
end

local function dataRow(parent, height, accent, paint)
	local row = vgui.Create("DPanel", parent)
	row:Dock(TOP)
	row:SetTall(height or 76)
	row:DockMargin(0, 0, 8, 8)
	row.Paint = function(self, w, h)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = C.panel,
				cut = 7,
				outlineColor = C.grid,
				accent = accent or C.accent,
			})
		else
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
		end
		if paint then paint(self, w, h) end
	end
	return row
end

local function watchButton(parent, frame, station)
	local watch = frame.State.watches and frame.State.watches[station]
	local mine = watch and IsValid(LocalPlayer())
		and watch.steamID == LocalPlayer():SteamID64()
	local text = mine and ("ON WATCH — " .. string.upper(station:gsub("_", " ")))
		or watch and ("MANNED BY " .. string.upper(watch.name or "NAVY"))
		or ("ASSUME " .. string.upper(station:gsub("_", " ")) .. " WATCH")
	local button = consoleButton(parent, text, mine and C.ok or watch and C.warn or C.accent,
		function()
			if not mine and not watch then
				sendCICAction(frame.Console, "watch", station)
			end
		end)
	button:Dock(TOP)
	button:SetTall(38)
	button:DockMargin(0, 0, 8, 10)
	button:SetEnabled(not watch or mine)
	return button
end

local function contactRows(parent, frame, mode)
	for _, contact in ipairs(frame.State.contacts or {}) do
		local selected = contact
		local colour = factionColour(selected)
		local row = dataRow(parent, 78, colour, function(_, w)
			draw.SimpleText(string.upper(tostring(selected.name or "UNKNOWN CONTACT")),
				"MBNavalHead", 16, 10, C.text)
			draw.SimpleText(string.upper(tostring(selected.faction or "UNKNOWN"))
				.. "  /  " .. string.upper(tostring(selected.role or "VESSEL"))
				.. "  /  SPEED " .. math.floor(tonumber(selected.speed) or 0),
				"MBNavalTiny", 17, 39, colour)
			draw.SimpleText(selected.iff ~= "" and ("IFF " .. selected.iff)
				or string.upper(tostring(selected.state or "UNRESOLVED")),
				"MBNavalTiny", 17, 58,
				selected.iff == "AUTHENTICATED" and C.ok or C.dim)
			draw.SimpleText("HULL " .. math.floor((tonumber(selected.hull) or 0) * 100)
				.. "%", "MBNavalMono", w - 286, 13, C.dim, TEXT_ALIGN_RIGHT)
		end)
		if mode == "navigation" or mode == "tactical" then
			local plot = consoleButton(row, "PLOT INTERCEPT", C.warn, function()
				sendCICAction(frame.Console, "intercept", selected.id)
			end)
			plot:SetSize(122, 32)
			plot:SetPos(row:GetWide() - 262, 38)
			plot.Think = function(self) self:SetPos(row:GetWide() - 262, 38) end
		end
		if mode == "iff" or mode == "tactical" then
			local challenge = consoleButton(row, "IFF CHALLENGE", C.accent, function()
				sendCICAction(frame.Console, "iff", selected.id)
			end)
			challenge:SetSize(116, 32)
			challenge:SetPos(row:GetWide() - 132, 38)
			challenge.Think = function(self) self:SetPos(row:GetWide() - 132, 38) end
		end
		if mode == "iff" and selected.faction ~= "republic" then
			local leave = consoleButton(row, "ORDER TO LEAVE", C.danger, function()
				sendCICAction(frame.Console, "traffic", selected.id, "leave")
			end)
			leave:SetSize(122, 32)
			leave:SetPos(row:GetWide() - 392, 38)
			leave.Think = function(self) self:SetPos(row:GetWide() - 392, 38) end
		end
	end
end

local function buildTactical(parent, frame)
	sectionTitle(parent, "COMMON OPERATING PICTURE",
		"Live contacts, IFF state, restricted areas and plotted intercepts")
	watchButton(parent, frame, "tactical")
	local zones, violations = #(frame.State.restrictedZones or {}), 0
	for _, zone in ipairs(frame.State.restrictedZones or {}) do
		violations = violations + #(zone.violations or {})
	end
	local overview = dataRow(parent, 70, violations > 0 and C.danger or C.accent,
		function(_, w)
			draw.SimpleText("CONTACTS", "MBNavalTiny", 18, 10, C.dim)
			draw.SimpleText(tostring(#(frame.State.contacts or {})), "MBNavalTitle", 18, 27, C.text)
			draw.SimpleText("CONTROLLED ZONES", "MBNavalTiny", 180, 10, C.dim)
			draw.SimpleText(tostring(zones), "MBNavalTitle", 180, 27, C.warn)
			draw.SimpleText("ACTIVE VIOLATIONS", "MBNavalTiny", 390, 10, C.dim)
			draw.SimpleText(tostring(violations), "MBNavalTitle", 390, 27,
				violations > 0 and C.danger or C.ok)
			draw.SimpleText(string.upper(frame.State.trafficNotice or "NORMAL TRANSIT"),
				"MBNavalText", w - 18, 28, C.accent, TEXT_ALIGN_RIGHT)
		end)
	overview:DockMargin(0, 0, 8, 14)

	local radarPanel = vgui.Create("DPanel", parent)
	radarPanel:Dock(TOP)
	radarPanel:SetTall(370)
	radarPanel:DockMargin(0, 0, 8, 14)
	radarPanel.Paint = function(_, w, h)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = C.panel,
				cut = 10,
				outlineColor = C.grid,
				accent = C.accent,
			})
		else
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
		end

		local radius = math.min(154, h * 0.42, w * 0.25)
		local cx, cy = math.max(radius + 34, math.min(w * 0.29, 310)), h * 0.52
		drawCircularRadar(frame.State, cx, cy, radius, { labels = false })
		draw.SimpleText("CIRCULAR TACTICAL RADAR", "MBNavalHead", 20, 14, C.accent)
		draw.SimpleText("CONTACTS ARE CLAMPED TO THE SENSOR EDGE",
			"MBNavalTiny", 20, 43, C.dim)

		local infoX = math.max(cx + radius + 52, w * 0.57)
		draw.SimpleText("SENSOR KEY", "MBNavalHead", infoX, 64, C.text)
		drawRadarMarker(infoX + 6, 105, 6, C.republic, true)
		draw.SimpleText("REPUBLIC / OWN SHIP", "MBNavalTiny", infoX + 24, 97, C.republic)
		drawRadarMarker(infoX + 6, 137, 6, C.danger, true)
		draw.SimpleText("HOSTILE CONTACT", "MBNavalTiny", infoX + 24, 129, C.danger)
		drawRadarMarker(infoX + 6, 169, 5, C.civilian, false)
		draw.SimpleText("CIVILIAN / CLEARED", "MBNavalTiny", infoX + 24, 161, C.civilian)
		surface.SetDrawColor(C.warn)
		surface.DrawCircle(infoX + 6, 202, 7, C.warn)
		draw.SimpleText("RESTRICTED SPACE", "MBNavalTiny", infoX + 24, 194, C.warn)

		local intercept = frame.State.intercept
		draw.SimpleText("CURRENT SOLUTION", "MBNavalTiny", infoX, 239, C.dim)
		if istable(intercept) then
			draw.SimpleText(string.upper(tostring(intercept.name or "ACTIVE INTERCEPT")),
				"MBNavalText", infoX, 262, C.warn)
			draw.SimpleText(string.format("BRG %03d  /  ETA %ds",
				tonumber(intercept.bearing) or 0, tonumber(intercept.seconds) or 0),
				"MBNavalMono", infoX, 289, C.text)
		else
			draw.SimpleText("NO INTERCEPT PLOTTED", "MBNavalText", infoX, 262, C.dim)
		end
		draw.SimpleText("Select a contact below to challenge IFF or plot an intercept.",
			"MBNavalTiny", infoX, 326, C.dim)
	end
	contactRows(parent, frame, "tactical")
end

local squadronOrderPriority = {
	"ready_five", "cap", "patrol", "close_escort", "escort", "intercept", "attack",
	"defend", "screen", "disable", "recon", "shadow", "search_rescue",
	"blockade", "convoy", "boarding_cover",
}
local function buildFlight(parent, frame)
	sectionTitle(parent, "FLIGHT AND HANGAR OPERATIONS",
		"Physical carrier launches, live squadron missions and linked hangar control")
	watchButton(parent, frame, "flight_control")
	local hangar = frame.State.hangar or {}
	dataRow(parent, 66, C.accent, function(_, w)
		draw.SimpleText("DEPLOYED VEHICLES  " .. math.floor(tonumber(hangar.deployedVehicles) or 0),
			"MBNavalHead", 18, 12, C.text)
		draw.SimpleText("DAMAGED  " .. math.floor(tonumber(hangar.damagedVehicles) or 0),
			"MBNavalHead", w - 18, 12,
			(tonumber(hangar.damagedVehicles) or 0) > 0 and C.warn or C.ok, TEXT_ALIGN_RIGHT)
		draw.SimpleText("Return empty, stationary craft to a requisition pad to recover stores.",
			"MBNavalTiny", 18, 42, C.dim)
	end)
	for _, group in ipairs(hangar.groups or {}) do
		local selectedGroup = group
		local colour = selectedGroup.state == "BLOCKED" and C.danger
			or selectedGroup.doorsOpen and C.warn or C.accent
		local groupRow = dataRow(parent, 88, colour, function(_, w)
			draw.SimpleText(string.upper(selectedGroup.name or "MAIN HANGAR"),
				"MBNavalHead", 18, 10, C.text)
			draw.SimpleText("DOORS " .. math.floor(tonumber(selectedGroup.doorsResolved) or 0)
				.. "/" .. math.floor(tonumber(selectedGroup.doorsLinked) or 0)
				.. "  /  LAUNCH NODES "
				.. math.floor(tonumber(selectedGroup.launchNodes) or 0)
				.. "  /  RETURN NODES "
				.. math.floor(tonumber(selectedGroup.returnNodes) or 0),
				"MBNavalTiny", 18, 38, C.dim)
			draw.SimpleText(string.upper(selectedGroup.state or "SEALED") .. " — "
				.. tostring(selectedGroup.message or "Flight deck secure"),
				"MBNavalTiny", 18, 61,
				selectedGroup.state == "BLOCKED" and C.danger or C.warn)
			if (tonumber(selectedGroup.expectedCraft) or 0) > 0 then
				draw.SimpleText("FLIGHT "
					.. math.floor(tonumber(selectedGroup.completedCraft) or 0)
					.. "/" .. math.floor(tonumber(selectedGroup.expectedCraft) or 0)
					.. "  /  QUEUE "
					.. math.floor(tonumber(selectedGroup.queuedOperations) or 0),
					"MBNavalMono", w - 360, 16, C.ok, TEXT_ALIGN_RIGHT)
			end
		end)
		local open = consoleButton(groupRow, "OPEN", C.ok, function()
			sendCICAction(frame.Console, "hangar", selectedGroup.id, "open")
		end)
		open:SetSize(96, 30)
		local close = consoleButton(groupRow, "CLOSE", C.warn, function()
			sendCICAction(frame.Console, "hangar", selectedGroup.id, "close")
		end)
		close:SetSize(96, 30)
		local stop = consoleButton(groupRow, "STOP", C.danger, function()
			sendCICAction(frame.Console, "hangar", selectedGroup.id, "stop")
		end)
		stop:SetSize(96, 30)
		local function placeHangarButtons()
			open:SetPos(groupRow:GetWide() - 318, 47)
			close:SetPos(groupRow:GetWide() - 212, 47)
			stop:SetPos(groupRow:GetWide() - 106, 47)
		end
		groupRow.Think = placeHangarButtons
		placeHangarButtons()
	end
	if #(hangar.groups or {}) == 0 then
		dataRow(parent, 58, C.warn, function()
			draw.SimpleText("NO LINKED HANGAR GROUP CONFIGURED",
				"MBNavalHead", 18, 9, C.warn)
			draw.SimpleText("Squadrons use direct skybox deployment until MAIN hangar doors and routes are recorded.",
				"MBNavalTiny", 18, 35, C.dim)
		end)
	end
	local list = {}
	for _, squadron in pairs(frame.State.squadrons or {}) do list[#list + 1] = squadron end
	table.sort(list, function(a, b) return tostring(a.name) < tostring(b.name) end)
	for _, squadron in ipairs(list) do
		local selected = squadron
		local row = dataRow(parent, 182, C.republic, function(_, w)
			draw.SimpleText(string.upper(selected.name or "SQUADRON"), "MBNavalHead", 18, 10, C.text)
			draw.SimpleText(string.upper(selected.craft or "FIGHTER")
				.. "  /  READY " .. math.floor(tonumber(selected.ready) or 0)
				.. " OF " .. math.floor(tonumber(selected.total) or 0)
				.. "  /  DEPLOYED CRAFT "
				.. math.floor(tonumber(selected.deployedCraft) or 0),
				"MBNavalTiny", 18, 39, C.dim)
			draw.SimpleText("CURRENT ORDER  " .. string.upper(selected.order or "STANDBY"),
				"MBNavalTiny", 18, 61, C.warn)
			draw.SimpleText("STATUS  " .. string.upper(selected.status or "READY"),
				"MBNavalTiny", w - 18, 12,
				selected.status == "TARGET LOST" and C.danger or C.ok, TEXT_ALIGN_RIGHT)
			draw.SimpleText("HULL " .. math.floor(tonumber(selected.condition) or 100)
				.. "%  /  FUEL " .. math.floor(tonumber(selected.fuel) or 100)
				.. "%  /  AMMO " .. math.floor(tonumber(selected.ammunition) or 100)
				.. "%  /  KILLS " .. math.floor(tonumber(selected.kills) or 0)
				.. "  /  LOSSES " .. math.floor(tonumber(selected.losses) or 0),
				"MBNavalTiny", w - 18, 39, C.dim, TEXT_ALIGN_RIGHT)
			if (tonumber(selected.maintenanceRemaining) or 0) > 0 then
				draw.SimpleText("MAINTENANCE "
					.. math.floor(tonumber(selected.maintenanceRemaining) or 0)
					.. "s", "MBNavalTiny", w - 18, 61, C.warn, TEXT_ALIGN_RIGHT)
			elseif (tonumber(selected.missionRange) or 0) > 0 then
				draw.SimpleText("RANGE " .. math.floor(tonumber(selected.missionRange) or 0)
					.. "  /  ETA " .. math.floor(tonumber(selected.missionETA) or 0)
					.. "s", "MBNavalTiny", w - 18, 61, C.accent, TEXT_ALIGN_RIGHT)
			end
			if tostring(selected.targetName or "") ~= "" then
				draw.SimpleText("ASSIGNED CONTACT  " .. string.upper(selected.targetName),
					"MBNavalTiny", w - 210, 61, C.accent, TEXT_ALIGN_RIGHT)
			end
		end)

		local mission = vgui.Create("DComboBox", row)
		mission:SetPos(18, 86)
		mission:SetSize(250, 32)
		mission:SetFont("MBNavalText")
		mission.SelectedOrder = selected.order ~= "standby"
			and selected.order ~= "recall" and selected.order or "patrol"
		for _, order in ipairs(squadronOrderPriority) do
			local definition = (MilBase.Config.NavalOperations.SquadronMissionDefinitions or {})[order]
			if definition then
				mission:AddChoice(definition.label or string.upper(order), order,
					order == mission.SelectedOrder)
			end
		end
		mission.OnSelect = function(self, _, _, data)
			self.SelectedOrder = data or "patrol"
		end

		local target = vgui.Create("DComboBox", row)
		target:SetPos(280, 86)
		target:SetSize(278, 32)
		target:SetFont("MBNavalText")
		target.SelectedTarget = tonumber(selected.targetIndex) or 0
		target:AddChoice("USE TACTICAL SELECTION", 0, target.SelectedTarget <= 0)
		for _, contact in ipairs(frame.State.contacts or {}) do
			local contactID = tonumber(contact.id) or 0
			target:AddChoice(string.upper(contact.name or "CONTACT")
				.. " / " .. string.upper(contact.faction or "UNKNOWN"),
				contactID, contactID == target.SelectedTarget)
		end
		target.OnSelect = function(self, _, _, data)
			self.SelectedTarget = tonumber(data) or 0
		end

		local issue = consoleButton(row, "ISSUE / LAUNCH", C.accent, function()
			sendCICAction(frame.Console, "squadron", selected.id,
				mission.SelectedOrder, target.SelectedTarget)
		end)
		issue:SetPos(570, 86)
		issue:SetSize(138, 32)
		local recall = consoleButton(row, "RECALL", C.warn, function()
			sendCICAction(frame.Console, "squadron", selected.id, "recall")
		end)
		recall:SetPos(718, 86)
		recall:SetSize(104, 32)
		local pilotLabel = tostring(selected.pilotName or "") ~= ""
			and "PILOT: " .. string.upper(tostring(selected.pilotName))
			or "REMOTE PILOT"
		local pilot = consoleButton(row, pilotLabel,
			tostring(selected.pilotName or "") ~= "" and C.warn or C.ok, function()
			sendCICAction(frame.Console, "squadron_pilot", selected.id)
		end)
		pilot:SetPos(832, 86)
		pilot:SetSize(145, 32)

		local roe = vgui.Create("DComboBox", row)
		roe:SetPos(18, 134)
		roe:SetSize(250, 32)
		roe:SetFont("MBNavalText")
		roe:SetValue("ROE: " .. string.upper(tostring(selected.roe
			or "confirmed_hostiles"):gsub("_", " ")))
		for key, definition in pairs(
			MilBase.Config.NavalOperations.SquadronROE or {}) do
			roe:AddChoice(definition.label or string.upper(key), key,
				key == selected.roe)
		end
		roe.OnSelect = function(_, _, _, data)
			sendCICAction(frame.Console, "squadron_roe", selected.id, data)
		end
		local formation = vgui.Create("DComboBox", row)
		formation:SetPos(280, 134)
		formation:SetSize(220, 32)
		formation:SetFont("MBNavalText")
		formation:SetValue("FORMATION: "
			.. string.upper(tostring(selected.formation or "vee"):gsub("_", " ")))
		for key, definition in pairs(
			MilBase.Config.NavalOperations.SquadronFormations or {}) do
			formation:AddChoice(definition.label or string.upper(key), key,
				key == selected.formation)
		end
		formation.OnSelect = function(_, _, _, data)
			sendCICAction(frame.Console, "squadron_formation", selected.id, data)
		end
		local hangarLabel = vgui.Create("DLabel", row)
		hangarLabel:SetPos(515, 134)
		hangarLabel:SetSize(470, 32)
		hangarLabel:SetFont("MBNavalTiny")
		hangarLabel:SetTextColor(C.dim)
		hangarLabel:SetText("ASSIGNED HANGAR  "
			.. string.upper(selected.hangar or "MAIN")
			.. "   /   PILOTS " .. math.floor(tonumber(selected.pilots) or 0)
			.. "   /   MORALE " .. math.floor(tonumber(selected.morale) or 100)
			.. "%   /   EXPERIENCE " .. math.floor(tonumber(selected.experience) or 0)
			.. (tostring(selected.pilotName or "") ~= ""
				and "   /   REMOTE " .. string.upper(tostring(selected.pilotName)) or ""))
	end
end

local function buildNavigation(parent, frame)
	sectionTitle(parent, "NAVIGATION AND INTERCEPT CONTROL",
		"Predict contact movement and transmit a stable intercept solution to the bridge")
	watchButton(parent, frame, "navigation")
	local nav = frame.State.navigation or {}
	dataRow(parent, 92, C.accent, function(_, w)
		draw.SimpleText(string.upper(nav.planet or "DEEP SPACE"), "MBNavalTitle", 18, 10, C.text)
		draw.SimpleText(nav.destination ~= "" and ("DESTINATION  " .. string.upper(nav.destination))
			or "NO HYPERSPACE DESTINATION SET", "MBNavalTiny", 20, 55, C.dim)
		draw.SimpleText("THROTTLE " .. math.floor(tonumber(nav.throttle) or 0) .. "%",
			"MBNavalMono", w - 18, 18, C.ok, TEXT_ALIGN_RIGHT)
		draw.SimpleText(nav.hyperspace and "HYPERSPACE" or "REALSPACE",
			"MBNavalTiny", w - 18, 55, nav.hyperspace and C.warn or C.accent,
			TEXT_ALIGN_RIGHT)
	end)
	if istable(frame.State.intercept) then
		local intercept = frame.State.intercept
		dataRow(parent, 78, C.warn, function(_, w)
			draw.SimpleText("ACTIVE INTERCEPT — " .. string.upper(intercept.name or "CONTACT"),
				"MBNavalHead", 18, 11, C.warn)
			draw.SimpleText(string.format("BEARING %03d   ELEVATION %d   ETA %ds   RANGE %d",
				tonumber(intercept.bearing) or 0, tonumber(intercept.elevation) or 0,
				tonumber(intercept.seconds) or 0, tonumber(intercept.distance) or 0),
				"MBNavalMono", 18, 45, C.text)
			draw.SimpleText("INTERCEPT SPEED " .. math.floor(tonumber(intercept.closingSpeed) or 0),
				"MBNavalTiny", w - 18, 47, C.dim, TEXT_ALIGN_RIGHT)
		end)
	end
	contactRows(parent, frame, "navigation")
end

local function buildIFF(parent, frame)
	sectionTitle(parent, "IFF AND TRAFFIC CONTROL",
		"Authenticate transponders, challenge suspicious vessels and enforce Republic authority")
	watchButton(parent, frame, "traffic_control")
	local transponder = dataRow(parent, 92, C.accent, function()
		draw.SimpleText("FLAGSHIP TRANSPONDER", "MBNavalHead", 18, 10, C.text)
		draw.SimpleText("CURRENT  " .. string.upper(tostring(frame.State.transponderMode or "active")
			:gsub("_", " ")), "MBNavalTiny", 18, 40, C.ok)
	end)
	local modes = { "active", "low_emission", "emergency" }
	for index, mode in ipairs(modes) do
		local selectedMode = mode
		local positionIndex = index
		local button = consoleButton(transponder, string.upper(mode:gsub("_", " ")),
			mode == "emergency" and C.danger or C.accent,
			function() sendCICAction(frame.Console, "transponder", selectedMode) end)
		button:SetSize(142, 32)
		button:SetPos(transponder:GetWide() - (4 - positionIndex) * 150, 30)
		button.Think = function(self)
			self:SetPos(transponder:GetWide() - (4 - positionIndex) * 150, 30)
		end
	end
	contactRows(parent, frame, "iff")
end

local function buildDamage(parent, frame)
	sectionTitle(parent, "DAMAGE-CONTROL COORDINATION",
		"Set repair priorities and dispatch teams; engineers still complete physical repairs")
	watchButton(parent, frame, "engineering")
	local total = 0
	for _, amount in pairs(frame.State.power or {}) do total = total + (tonumber(amount) or 0) end
	dataRow(parent, 66, C.accent, function(_, w)
		draw.SimpleText("REACTOR LOAD  " .. total .. "%", "MBNavalHead", 18, 12,
			total > 100 and C.danger or C.ok)
		draw.SimpleText("OPEN INCIDENTS  " .. tostring(#(frame.State.incidents or {})),
			"MBNavalHead", w - 18, 12, C.warn, TEXT_ALIGN_RIGHT)
		draw.SimpleText("Power routing remains available at the engineering distribution console.",
			"MBNavalTiny", 18, 42, C.dim)
	end)
	local open = 0
	for _, incident in ipairs(frame.State.incidents or {}) do
		if incident.status == "SEALED" then continue end
		open = open + 1
		local selected = incident
		local colour = selected.severity == "CRITICAL" and C.danger or C.warn
		local row = dataRow(parent, 92, colour, function()
			draw.SimpleText(string.upper(selected.system or "SHIP SYSTEM"), "MBNavalHead",
				18, 10, C.text)
			draw.SimpleText(string.upper(selected.severity or "DAMAGED")
				.. "  /  " .. string.upper(selected.assignment or "UNASSIGNED"),
				"MBNavalTiny", 18, 40, colour)
			draw.SimpleText(selected.assignedBy and ("ASSIGNED BY " .. string.upper(selected.assignedBy))
				or "PHYSICAL REPAIR TEAM REQUIRED", "MBNavalTiny", 18, 61, C.dim)
		end)
		for priority = 1, 3 do
			local value = priority
			local button = consoleButton(row, "PRIORITY " .. value,
				value == 1 and C.danger or value == 2 and C.warn or C.accent,
				function() sendCICAction(frame.Console, "damage", selected.id, value) end)
			button:SetSize(102, 32)
			button:SetPos(row:GetWide() - (4 - value) * 110, 30)
			button.Think = function(self)
				self:SetPos(row:GetWide() - (4 - value) * 110, 30)
			end
		end
	end
	if open == 0 then
		dataRow(parent, 74, C.ok, function()
			draw.SimpleText("ALL COMPARTMENTS REPORT SECURE", "MBNavalHead", 18, 14, C.ok)
			draw.SimpleText("No open breaches, failed terminals or destroyed ship systems.",
				"MBNavalTiny", 18, 44, C.dim)
		end)
	end
end

local function buildZones(parent, frame)
	sectionTitle(parent, "RESTRICTED NAVIGATION ZONES",
		"Republic vessels are authorised; civilian and pirate traffic reroutes; CIS incursions are hostile")
	watchButton(parent, frame, "traffic_control")
	local form = dataRow(parent, 142, C.warn, function()
		draw.SimpleText("DECLARE CONTROLLED SPACE", "MBNavalHead", 18, 10, C.text)
		draw.SimpleText("The zone is anchored to the current system and persists until lifted or expired.",
			"MBNavalTiny", 18, 39, C.dim)
	end)
	local name = vgui.Create("DTextEntry", form)
	name:SetPos(18, 68)
	name:SetSize(270, 34)
	name:SetPlaceholderText("ZONE NAME")
	name:SetFont("MBNavalText")
	local radius = vgui.Create("DNumSlider", form)
	radius:SetPos(304, 59)
	radius:SetSize(260, 54)
	radius:SetText("RADIUS")
	radius:SetMinMax(15, 100)
	radius:SetDecimals(0)
	radius:SetValue(65)
	local duration = vgui.Create("DComboBox", form)
	duration:SetPos(580, 68)
	duration:SetSize(170, 34)
	duration:SetFont("MBNavalText")
	duration:SetValue("30 MINUTES")
	duration.SelectedDuration = "30m"
	for _, option in ipairs((MilBase.Config.NavalOperations or {}).RestrictedZoneDurations or {}) do
		duration:AddChoice(option.label or option.id, option.id)
	end
	duration.OnSelect = function(self, _, _, data) self.SelectedDuration = data or "30m" end
	local create = consoleButton(form, "DECLARE ZONE", C.warn, function()
		sendCICAction(frame.Console, "zone_create", name:GetValue(),
			math.Round(radius:GetValue()), duration.SelectedDuration)
	end)
	create:SetSize(154, 34)
	create:SetPos(766, 68)

	for _, zone in ipairs(frame.State.restrictedZones or {}) do
		local selected = zone
		local violationCount = #(selected.violations or {})
		local colour = violationCount > 0 and C.danger or selected.localZone and C.warn or C.dim
		local row = dataRow(parent, math.max(88, 68 + violationCount * 20), colour, function(_, w)
			draw.SimpleText(string.upper(selected.name or "RESTRICTED AREA"), "MBNavalHead",
				18, 10, C.text)
			local expiry = tonumber(selected.expiresAt) or 0
			local durationText = expiry > 0 and ("EXPIRES " .. os.date("%H:%M", expiry)) or "PERMANENT"
			draw.SimpleText(string.upper(selected.planetKey or "DEEP SPACE")
				.. "  /  RADIUS " .. math.Round((tonumber(selected.radius) or 0) * 100)
				.. "%  /  " .. durationText, "MBNavalTiny", 18, 39, C.dim)
			draw.SimpleText(violationCount .. " ACTIVE VIOLATION" .. (violationCount == 1 and "" or "S"),
				"MBNavalTiny", w - 170, 15, violationCount > 0 and C.danger or C.ok,
				TEXT_ALIGN_RIGHT)
			local y = 64
			for _, violation in ipairs(selected.violations or {}) do
				draw.SimpleText(string.upper(violation.name or "CONTACT") .. " — "
					.. string.upper(violation.status or "CHALLENGED"),
					"MBNavalTiny", 18, y, C.warn)
				y = y + 20
			end
		end)
		local remove = consoleButton(row, "LIFT ZONE", C.danger, function()
			sendCICAction(frame.Console, "zone_remove", selected.id)
		end)
		remove:SetSize(116, 32)
		remove:SetPos(row:GetWide() - 132, 44)
		remove.Think = function(self) self:SetPos(row:GetWide() - 132, 44) end
	end
end

local consoleTabs = {
	{ id = "tactical", label = "TACTICAL PICTURE", page = 0, build = buildTactical },
	{ id = "flight", label = "FLIGHT OPERATIONS", page = 3, build = buildFlight },
	{ id = "navigation", label = "NAVIGATION / INTERCEPT", page = 1, build = buildNavigation },
	{ id = "iff", label = "IFF / TRAFFIC", page = 0, build = buildIFF },
	{ id = "damage", label = "DAMAGE CONTROL", page = 2, build = buildDamage },
	{ id = "zones", label = "RESTRICTED AREAS", page = 5, build = buildZones },
}

function N.OpenCICConsole(console, payload)
	if not IsValid(console) then return end
	if IsValid(N.ActiveCICFrame) then
		N.ActiveCICFrame.Console = console
		N.ActiveCICFrame.State = payload.state or N.ClientState
		N.ActiveCICFrame.Feedback = payload.feedback or ""
		N.ActiveCICFrame.FeedbackOK = payload.feedbackOK == true
		N.ActiveCICFrame:Rebuild()
		return
	end
	local frame = vgui.Create("DFrame")
	N.ActiveCICFrame = frame
	frame:SetSize(math.min(1320, ScrW() - 50), math.min(860, ScrH() - 50))
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Console = console
	frame.State = payload.state or N.ClientState
	frame.ActiveTab = "tactical"
	frame.Feedback = payload.feedback or ""
	frame.FeedbackOK = payload.feedbackOK == true
	frame.Paint = function(self, w, h)
		if MilBase.PaintBackdrop then
			MilBase.PaintBackdrop(self, w, h, nil, 225)
		else
			surface.SetDrawColor(C.background)
			surface.DrawRect(0, 0, w, h)
		end
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = alpha(C.background, 235),
				cut = 13,
				outlineColor = alpha(C.accent, 105),
				accent = C.accent,
			})
		end
		surface.SetDrawColor(C.accent)
		surface.DrawRect(0, 0, w, 4)
	end
	frame.OnRemove = function(self)
		if N.ActiveCICFrame == self then N.ActiveCICFrame = nil end
	end
	frame.Think = function(self)
		if not IsValid(self.Console) or not IsValid(LocalPlayer())
		or not N.IsNavy or not N.IsNavy(LocalPlayer()) then
			self:Remove()
			return
		end
		local range = math.max(100,
			tonumber((MilBase.Config.NavalOperations or {}).ConsoleUseRange) or 700)
		if LocalPlayer():GetPos():DistToSqr(self.Console:GetPos()) > range * range then
			self:Remove()
		end
	end

	local headerPanel = vgui.Create("DPanel", frame)
	headerPanel:Dock(TOP)
	headerPanel:SetTall(82)
	headerPanel.Paint = function(_, w, h)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(12, 8, w - 24, h - 8, {
				color = C.panel,
				cut = 9,
				outlineColor = C.grid,
				accent = C.accent,
			})
		else
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
		end
		draw.SimpleText("REPUBLIC NAVAL COMMAND", "MBNavalTitle", 26, 14, C.text)
		draw.SimpleText("COMBAT INFORMATION CENTRE / FLEETNET CONTROL",
			"MBNavalTiny", 28, 53, C.accent)
		local stale = not N.ClientReceivedAt or RealTime() - N.ClientReceivedAt > 5
		draw.SimpleText(stale and "DATALINK DEGRADED" or "FLEETNET LIVE",
			"MBNavalText", w - 150, 31, stale and C.danger or C.ok, TEXT_ALIGN_RIGHT)
	end
	local close = consoleButton(headerPanel, "CLOSE", C.danger, function() frame:Remove() end)
	close:SetSize(100, 36)
	close:SetPos(headerPanel:GetWide() - 118, 23)
	close.Think = function(self) self:SetPos(headerPanel:GetWide() - 118, 23) end

	local feedback = consoleLabel(frame, "", "MBNavalTiny", C.dim)
	feedback:Dock(BOTTOM)
	feedback:SetTall(30)
	feedback:SetContentAlignment(5)

	local sidebar = vgui.Create("DPanel", frame)
	sidebar:Dock(LEFT)
	sidebar:SetWide(224)
	sidebar:DockMargin(12, 12, 10, 10)
	sidebar.Paint = function(_, w, h)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(0, 0, w, h, {
				color = C.panel,
				cut = 9,
				outlineColor = C.grid,
				accent = C.accent,
			})
		else
			surface.SetDrawColor(C.panel)
			surface.DrawRect(0, 0, w, h)
		end
	end

	local content = vgui.Create("DScrollPanel", frame)
	content:Dock(FILL)
	content:DockMargin(0, 12, 10, 10)
	content.Paint = function() end
	frame.Content = content
	local scrollBar = content:GetVBar()
	scrollBar:SetWide(7)
	scrollBar.Paint = function(_, w, h)
		surface.SetDrawColor(alpha(C.accent, 18))
		surface.DrawRect(0, 0, w, h)
	end
	scrollBar.btnUp.Paint = function() end
	scrollBar.btnDown.Paint = function() end
	scrollBar.btnGrip.Paint = function(_, w, h)
		surface.SetDrawColor(alpha(C.accent, 145))
		surface.DrawRect(1, 0, w - 2, h)
	end

	frame.Rebuild = function(self)
		if istable(self.PendingState) then
			self.State = self.PendingState
			self.PendingState = nil
		end
		content:Clear()
		local tab
		for _, candidate in ipairs(consoleTabs) do
			if candidate.id == self.ActiveTab then tab = candidate break end
		end
		tab = tab or consoleTabs[1]
		tab.build(content, self)
		feedback:SetText(self.Feedback ~= "" and self.Feedback
			or "All actions are authenticated and written to the Republic naval log.")
		feedback:SetTextColor(self.Feedback ~= ""
			and (self.FeedbackOK and C.ok or C.warn) or C.dim)
	end

	local y = 18
	for _, tab in ipairs(consoleTabs) do
		local selected = tab
		local button = consoleButton(sidebar, selected.label, C.accent, function()
			frame.ActiveTab = selected.id
			frame.Feedback = ""
			frame:Rebuild()
			sendCICAction(frame.Console, "set_page", selected.page)
		end)
		button:SetSize(196, 42)
		button:SetPos(14, y)
		local basePaint = button.Paint
		button.Paint = function(self, w, h)
			basePaint(self, w, h)
			if frame.ActiveTab == selected.id then
				surface.SetDrawColor(C.accent)
				surface.DrawRect(0, 0, 4, h)
			end
		end
		y = y + 50
	end
	local refresh = consoleButton(sidebar, "REFRESH FLEETNET", C.ok, function()
		if istable(frame.PendingState) then frame.State = frame.PendingState end
		frame.PendingState = nil
		frame.Feedback = ""
		frame:Rebuild()
	end)
	refresh:SetSize(196, 38)
	refresh:SetPos(14, y + 16)
	frame:Rebuild()
end

net.Receive(NET_CONSOLE_OPEN, function()
	local length = net.ReadUInt(32)
	if length <= 0 or length > 1000000 then return end
	local compressed = net.ReadData(length)
	local json = compressed and util.Decompress(compressed)
	local payload = json and util.JSONToTable(json)
	if not istable(payload) or not istable(payload.state) then return end
	N.ClientState = payload.state
	N.ClientReceivedAt = RealTime()
	local console = Entity(tonumber(payload.console) or 0)
	if IsValid(console) then N.OpenCICConsole(console, payload) end
end)
