-- Persistent shipboard prison shared API.
MilBase.Prison = MilBase.Prison or {}
local P = MilBase.Prison
local cfg = MilBase.Config.Prison or {}

P.StatusLabels = P.StatusLabels or {
	awaiting_escort = "AWAITING ESCORT",
	escort_waiting = "AWAITING SECOND GUARD",
	escorting = "UNDER ESCORT",
	holding = "HOLDING POSITION",
	kneeling = "KNEELING",
	facing_wall = "FACING WALL",
	intake = "INTAKE PROCESSING",
	incarcerated = "IN CELL",
	overflow = "OVERFLOW HOLDING",
	social = "SOCIAL PERIOD",
	medical = "MEDICAL",
	work = "WORK DETAIL",
	isolation = "ISOLATION",
	transfer_pending = "TRANSFER REQUESTED",
	transfer_ready = "TRANSFER ACCEPTED",
	boarding = "BOARDING TRANSFER",
	transferred = "TRANSFERRED",
	rioting = "RIOTING",
	released = "RELEASED",
	deceased = "DECEASED",
}

P.ScheduleLabels = P.ScheduleLabels or {
	lockdown = "LOCKDOWN",
	rollcall = "ROLL CALL",
	meal = "MEAL / WATER",
	cell_search = "CELL INSPECTIONS",
	social = "SOCIAL TIME",
	interviews = "INTERVIEWS / MEDICAL",
	work = "WORK PERIOD",
	shower = "SHOWERS",
	restricted = "RESTRICTED MOVEMENT",
	riot_lockdown = "RIOT LOCKDOWN",
	evacuation = "EVACUATION",
}

local function factionAllows(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	if MilBase.JailCanViewRecords and MilBase.JailCanViewRecords(ply) then return true end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	if faction and faction.police then return true end
	local name = string.lower(tostring(faction and faction.name or ""))
	return string.find(name, "navy", 1, true) ~= nil
		or string.find(name, "guard", 1, true) ~= nil
		or string.find(name, "security", 1, true) ~= nil
		or string.find(name, "clone", 1, true) ~= nil
end

function P.CanUse(ply)
	if cfg.Enabled == false then return false end
	return factionAllows(ply)
end

function P.CanCommand(ply)
	if not P.CanUse(ply) then return false end
	if game.SinglePlayer() then return true end
	if IsValid(ply) and (ply:IsAdmin() or ply:IsSuperAdmin()) then return true end
	return IsValid(ply) and ply.MBStaffLevel
		and ply:MBStaffLevel() >= (cfg.CommandStaffLevel or 3)
end

function P.CanConfigure(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsSuperAdmin() then return true end
	return ply.MBStaffLevel and ply:MBStaffLevel() >= (cfg.SetupStaffLevel or 6)
end

function P.CleanID(value, fallback)
	local text = string.lower(string.Trim(tostring(value or fallback or "")))
	text = string.gsub(text, "[^%w_%-]", "_")
	text = string.gsub(text, "_+", "_")
	return string.sub(text, 1, 48)
end

function P.Language(id)
	return MilBase.GetLanguage and MilBase.GetLanguage(id)
		or (MilBase.Languages and MilBase.Languages.basic)
end

function P.LanguageName(id)
	local language = P.Language(id)
	return tostring(language and language.name or "Galactic Basic")
end

function P.LanguageCertification(id)
	local language = P.Language(id)
	return tostring(language and language.certification or "")
end

function P.LanguageQualification(id)
	if MilBase.LanguageQualificationText then
		return MilBase.LanguageQualificationText(id)
	end
	local certID = P.LanguageCertification(id)
	local cert = MilBase.Certs and MilBase.Certs[certID]
	return cert and cert.name or certID
end

function P.PlayerUnderstandsLanguage(ply, id)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	return ply.MBUnderstandsLanguage and ply:MBUnderstandsLanguage(id) or false
end

function P.StatusLabel(id)
	return P.StatusLabels[tostring(id or "")] or string.upper(tostring(id or "UNKNOWN"))
end

function P.RiskWeight(id)
	local row = (cfg.RiskLevels or {})[tostring(id or "low")]
	return tonumber(row and row.weight) or 1
end

function P.RiskLabel(id)
	local row = (cfg.RiskLevels or {})[tostring(id or "low")]
	return tostring(row and row.label or string.upper(tostring(id or "LOW")))
end

function P.IsPrisonerEntity(ent)
	return IsValid(ent) and ent:GetClass() == "mb_prisoner"
end

local function prisonerVisible(lp, target)
	return P.IsPrisonerEntity(target) and P.CanUse(lp)
end

if MilBase.RegisterQuickInteraction and not P._quickInteractionsRegistered then
	P._quickInteractionsRegistered = true
	local function register(id, name, order, command, visible)
		MilBase.RegisterQuickInteraction(id, {
			name = name,
			order = order,
			prisoner = true,
			visible = function(lp, target)
				return prisonerVisible(lp, target) and (not visible or visible(lp, target))
			end,
			run = function(ply, target)
				if P.RunGuardCommand then P.RunGuardCommand(ply, target, command) end
			end,
		})
	end

	register("prison_follow", "Prisoner: Follow", 20, "follow")
	register("prison_assist", "Prisoner: Assist Escort", 21, "assist",
		function(_, target) return target:GetPrisonStatus() == "escort_waiting" end)
	register("prison_halt", "Prisoner: Halt", 22, "halt")
	register("prison_kneel", "Prisoner: Kneel", 23, "kneel")
	register("prison_wall", "Prisoner: Face Wall", 24, "face_wall")
	register("prison_cell", "Prisoner: Return To Cell", 25, "return_cell",
		function(_, target) return target:GetCellID() ~= "" end)
	register("prison_restrain", "Prisoner: Secure Restraints", 26, "restrain")
	register("prison_unrestrain", "Prisoner: Loosen Restraints", 26.5, "unrestrain",
		function(_, target) return target:GetRestrained() end)
	register("prison_search", "Prisoner: Search", 27, "search")
	register("prison_surrender", "Prisoner: Order Surrender", 28, "surrender",
		function(_, target) return target:GetRioting() end)
	register("prison_record", "Prisoner: Open Record", 29, "record")
end
