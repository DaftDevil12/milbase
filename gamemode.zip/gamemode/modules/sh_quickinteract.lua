--[[
	Quick interactions: hold [E] on a soldier, scroll to choose, release
	to confirm. ("Cancel" is always first, so a plain tap does nothing.)

	Built-in: Promote/Demote (officers), Push, Check Dogtags, Treat
	(certified medics - opens your med list), and for Military Police
	(faction `police = true`) or admins: Cuff/Uncuff and Drag.

	Cuffed soldiers are stripped of weapons, movement locked, can't use
	doors/items, and can be dragged by their captor. Event enemies can
	hold RELOAD to break cuffs.

	Add your own from any module:
	MilBase.RegisterQuickInteraction("search", {
		name = "Search",              -- or function(lp, target) return "..." end
		order = 45,
		visible = function(lp, target) return ... end, -- CLIENT
		run = function(ply, target) ... end,           -- SERVER
		-- or client = function(lp, target) ... end     (runs clientside)
	})
]]

local cfg = MilBase.Config

cfg.EventEnemyCuffEscapeTime = cfg.EventEnemyCuffEscapeTime or 4
cfg.EventEnemyCuffEscapeCooldown = cfg.EventEnemyCuffEscapeCooldown or 8
cfg.CuffedMovementLock = cfg.CuffedMovementLock ~= false

local function isEventEnemy(ply)
	if MilBase.IsEventEnemy then return MilBase.IsEventEnemy(ply) end
	return IsValid(ply) and ply:GetNWBool("mb_eventenemy", false)
end

-- (The MilBase.RegisterQuickInteraction registry lives in core/sh_actions.lua.)

local function isOfficer(ply)
	local rank = ply:MBRank()
	return (rank and rank.canPromote) or false
end

local function canManageView(lp, target)
	if lp:IsAdmin() then return true end
	return isOfficer(lp) and lp:MBFactionID() == target:MBFactionID()
		and lp:MBRankIndex() > target:MBRankIndex()
end

local function isPolice(ply)
	local faction = ply:MBFaction()
	return (faction and faction.police) or ply:IsAdmin()
end

--------------------------------------------------------------------------
-- Server: net handling, cuffing, dragging
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_QuickInteract")

	net.Receive("MilBase_QuickInteract", function(_, ply)
		local id = net.ReadString()
		local target = net.ReadEntity()

		if (ply.mb_lastQuick or 0) > CurTime() - 0.3 then return end
		ply.mb_lastQuick = CurTime()

		local action = MilBase.QuickInteractions[id]
		if not action or not action.run then return end
		if not IsValid(target) then return end
		if not ply:Alive() or ply:GetNWBool("mb_cuffed", false) then return end

		if action.prisoner then
			if not MilBase.Prison or not MilBase.Prison.IsPrisonerEntity
			or not MilBase.Prison.IsPrisonerEntity(target) then return end
			if target:GetPos():DistToSqr(ply:GetPos()) > 180 * 180 then return end
		elseif action.vehicle then
			if target.LVS ~= true then return end
			if target:NearestPoint(ply:GetPos()):DistToSqr(ply:GetPos()) > 180 * 180 then return end
		else
			if not target:IsPlayer() or not target:Alive() then return end
			if target:GetPos():DistToSqr(ply:GetPos()) > 160 * 160 then return end
		end

		action.run(ply, target)
	end)

	-- Cuffing ------------------------------------------------------------

	local function stopDrag(dragger)
		local target = dragger.mb_dragTarget
		dragger.mb_dragTarget = nil
		dragger:SetNWEntity("mb_dragging", NULL)
		if IsValid(target) then
			target.mb_draggedBy = nil
			target:SetNWEntity("mb_dragged_by", NULL)
		end
	end

	local function clearDragLinks(ply)
		stopDrag(ply)
		local dragger = ply.mb_draggedBy
		if IsValid(dragger) then stopDrag(dragger) end
	end

	function MilBase.SetCuffed(ply, cuffed, actor)
		ply:SetNWBool("mb_cuffed", cuffed)
		if cuffed and MilBase.CloseCharacterSwitchMenu then
			MilBase.CloseCharacterSwitchMenu(ply)
		end
		ply:SetNWFloat("mb_cuff_escape_frac", 0)
		if not cuffed then ply:SetNWFloat("mb_cuff_escape_cooldown", 0) end

		if cuffed then
			ply:StripWeapons()
			ply.mb_med = nil
			ply:SetNWFloat("mb_medprog", 0)
			ply:EmitSound("npc/metropolice/gear5.wav")
			MilBase.Notify(ply, "You have been restrained"
				.. (IsValid(actor) and (" by " .. actor:MBName()) or "") .. ".")
		else
			clearDragLinks(ply)
			hook.Run("PlayerLoadout", ply)
			ply:EmitSound("npc/metropolice/gear3.wav")
			MilBase.Notify(ply, "You have been released.")
		end

		MilBase.UpdateMoveSpeed(ply)
	end

	-- Restrained soldiers can't use doors/buttons/items or grab weapons.
	hook.Add("PlayerUse", "MilBase.CuffNoUse", function(ply)
		if ply:GetNWBool("mb_cuffed", false) then return false end
	end)

	hook.Add("PlayerCanPickupWeapon", "MilBase.CuffNoWeapons", function(ply)
		if ply:GetNWBool("mb_cuffed", false) then return false end
	end)

	hook.Add("CanPlayerEnterVehicle", "MilBase.CuffNoVehicleEntry", function(ply)
		if IsValid(ply) and ply:GetNWBool("mb_cuffed", false) then return false end
	end)

	-- Movement lock: restrained players cannot fight dragging, jump, crouch,
	-- sprint, attack, use, or move themselves. Event enemies keep RELOAD so
	-- they can use the cuff escape mechanic below.
	local cuffBlockButtons = IN_FORWARD + IN_BACK + IN_MOVELEFT + IN_MOVERIGHT
		+ IN_JUMP + IN_DUCK + IN_SPEED + IN_WALK + IN_ATTACK + IN_ATTACK2
		+ IN_USE + IN_ZOOM + IN_ALT1 + IN_ALT2

	hook.Add("SetupMove", "MilBase.CuffMovementLock", function(ply, mv, cmd)
		if not cfg.CuffedMovementLock then return end
		if not IsValid(ply) or not ply:GetNWBool("mb_cuffed", false) then return end

		mv:SetForwardSpeed(0)
		mv:SetSideSpeed(0)
		mv:SetUpSpeed(0)
		if mv.SetMaxSpeed then mv:SetMaxSpeed(0) end
		if mv.SetMaxClientSpeed then mv:SetMaxClientSpeed(0) end

		local buttons = mv:GetButtons()
		local block = cuffBlockButtons
		if not isEventEnemy(ply) then block = block + IN_RELOAD end
		buttons = bit.band(buttons, bit.bnot(block))
		mv:SetButtons(buttons)
		if cmd and cmd.SetButtons then cmd:SetButtons(buttons) end
	end)

	hook.Add("PlayerSpawn", "MilBase.CuffReset", function(ply)
		ply:SetNWBool("mb_cuffed", false)
		ply:SetNWFloat("mb_cuff_escape_frac", 0)
		ply:SetNWFloat("mb_cuff_escape_cooldown", 0)
		clearDragLinks(ply)
	end)

	hook.Add("PlayerDeath", "MilBase.CuffDragCleanup", clearDragLinks)
	hook.Add("PlayerDisconnected", "MilBase.CuffDragCleanup", clearDragLinks)

	-- Dragging -----------------------------------------------------------

	local TICK = 0.05
	local nextTick = 0

	hook.Add("Think", "MilBase.DragThink", function()
		if CurTime() < nextTick then return end
		nextTick = CurTime() + TICK

		for _, dragger in ipairs(player.GetAll()) do
			local target = dragger.mb_dragTarget
			if target == nil then continue end

			if not IsValid(target) or not target:Alive() or not dragger:Alive()
			or not target:GetNWBool("mb_cuffed", false)
			or target:GetPos():DistToSqr(dragger:GetPos()) > 300 * 300 then
				stopDrag(dragger)
				continue
			end

			-- A real pull: tug the prisoner toward you when the leash goes
			-- taut. No teleporting, so you can turn around and uncuff them.
			local offset = dragger:GetPos() - target:GetPos()
			offset.z = 0
			local dist = offset:Length()

			if dist > 60 and target:OnGround() then
				offset:Normalize()

				local speed = math.min(250, 40 + dist * 2)
				local pull = offset * speed
				local vel = target:GetVelocity()

				-- Replace horizontal velocity with the pull; keep gravity.
				target:SetVelocity(Vector(pull.x - vel.x, pull.y - vel.y, 0))
			end
		end
	end)


	-- Event enemies can break their own cuffs by holding RELOAD while restrained.
	-- This works even while being dragged; completing the escape releases the drag link.
	local nextEscapeTick = 0
	hook.Add("Think", "MilBase.EventEnemyCuffEscapeThink", function()
		if CurTime() < nextEscapeTick then return end
		local dt = 0.1
		nextEscapeTick = CurTime() + dt

		local needed = math.max(0.5, tonumber(cfg.EventEnemyCuffEscapeTime or 4) or 4)
		local cooldown = math.max(0, tonumber(cfg.EventEnemyCuffEscapeCooldown or 8) or 8)
		for _, ply in ipairs(player.GetAll()) do
			if not IsValid(ply) or not ply:Alive() or not ply:GetNWBool("mb_cuffed", false) or not isEventEnemy(ply) then
				if IsValid(ply) and (ply:GetNWFloat("mb_cuff_escape_frac", 0) or 0) > 0 then
					ply:SetNWFloat("mb_cuff_escape_frac", 0)
				end
				continue
			end

			local untilTime = ply:GetNWFloat("mb_cuff_escape_cooldown", 0)
			if untilTime > CurTime() then
				ply:SetNWFloat("mb_cuff_escape_frac", 0)
				continue
			end

			local frac = ply:GetNWFloat("mb_cuff_escape_frac", 0)
			if ply:KeyDown(IN_RELOAD) then
				frac = math.min(1, frac + dt / needed)
			else
				frac = math.max(0, frac - dt / 1.25)
			end

			if frac >= 1 then
				ply:SetNWFloat("mb_cuff_escape_frac", 0)
				ply:SetNWFloat("mb_cuff_escape_cooldown", CurTime() + cooldown)
				MilBase.SetCuffed(ply, false)
				ply:EmitSound("physics/metal/metal_box_break1.wav", 75, 105)
				MilBase.Notify(ply, "You broke free from the cuffs.", "warn")
				for _, near in ipairs(player.GetAll()) do
					if near ~= ply and near:GetPos():DistToSqr(ply:GetPos()) <= 700 * 700 then
						MilBase.Notify(near, ply:MBName() .. " broke free from their cuffs!", "warn")
					end
				end
			else
				ply:SetNWFloat("mb_cuff_escape_frac", frac)
			end
		end
	end)

	function MilBase.ToggleDrag(ply, target)
		if ply.mb_dragTarget == target then
			stopDrag(ply)
			MilBase.Notify(ply, "You let go of " .. target:MBName() .. ".")
			return
		end

		stopDrag(ply)
		ply.mb_dragTarget = target
		ply:SetNWEntity("mb_dragging", target)
		target.mb_draggedBy = ply
		target:SetNWEntity("mb_dragged_by", ply)
		MilBase.Notify(ply, "Dragging " .. target:MBName() .. ". Walk and they follow.")
		MilBase.Notify(target, ply:MBName() .. " is dragging you.")
	end

end

--------------------------------------------------------------------------
-- Client: hold E, scroll, release
--------------------------------------------------------------------------

if CLIENT then

	local active -- { target, options = { {id, name, def} }, sel, opened }

	local function buildOptions(lp, target)
		local out = { { id = nil, name = "Cancel" } }
		local isVehicle = target.LVS == true
		local isPrisoner = MilBase.Prison and MilBase.Prison.IsPrisonerEntity
			and MilBase.Prison.IsPrisonerEntity(target)

		for _, id in ipairs(MilBase.QuickOrder) do
			local action = MilBase.QuickInteractions[id]
			if (action.vehicle or false) == isVehicle
			and (action.prisoner or false) == isPrisoner
			and (not action.visible or action.visible(lp, target)) then
				local name = isfunction(action.name) and action.name(lp, target) or action.name
				table.insert(out, { id = id, name = name, def = action })
			end
		end

		return out
	end

	hook.Add("Think", "MilBase.QuickInteract", function()
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() or MilBase.InEventView() then
			active = nil
			return
		end

		local using = lp:KeyDown(IN_USE)

		if not active then
			if using and not lp.mb_wasUsing
			and not lp:GetNWBool("mb_wounded", false)
			and not lp:GetNWBool("mb_cuffed", false) then
				local tr = lp:GetEyeTrace()
				local target = tr.Entity

				local valid = false
				if IsValid(target) then
					if target.LVS == true then
						-- Vehicles: CROUCH + E (plain E enters the vehicle).
						valid = lp:Crouching()
							and tr.HitPos:DistToSqr(lp:GetPos()) < 140 * 140
					elseif MilBase.Prison and MilBase.Prison.IsPrisonerEntity
					and MilBase.Prison.IsPrisonerEntity(target) then
						valid = target:GetPos():DistToSqr(lp:GetPos()) < 140 * 140
					elseif target:IsPlayer() and target:Alive()
					and not target:GetNWBool("mb_wounded", false) then
						-- Wounded soldiers keep the hold-E stabilize behavior.
						valid = target:GetPos():DistToSqr(lp:GetPos()) < 110 * 110
					end
				end

				if valid then
					local options = buildOptions(lp, target)
					if #options > 1 then
						active = { target = target, options = options, sel = 1, opened = CurTime() }
						MilBase.PlayUISound("hover")
					end
				end
			end
		else
			local target = active.target
			local lost = not IsValid(target)

			if not lost then
				if MilBase.Prison and MilBase.Prison.IsPrisonerEntity
				and MilBase.Prison.IsPrisonerEntity(target) then
					lost = target:GetPos():DistToSqr(lp:GetPos()) > 180 * 180
				elseif target.LVS == true then
					lost = target:NearestPoint(lp:GetPos()):DistToSqr(lp:GetPos()) > 170 * 170
				else
					lost = not target:Alive()
						or target:GetPos():DistToSqr(lp:GetPos()) > 150 * 150
				end
			end

			if lost then
				active = nil
			elseif not using then
				-- Released: run the selection (a quick tap always cancels).
				local choice = active.options[active.sel]
				if choice and choice.id and CurTime() - active.opened > 0.15 then
					if choice.def.client then
						choice.def.client(lp, target)
					else
						net.Start("MilBase_QuickInteract")
							net.WriteString(choice.id)
							net.WriteEntity(target)
						net.SendToServer()
					end
				end
				active = nil
			end
		end

		lp.mb_wasUsing = using
	end)

	-- Scroll wheel drives the selection while the menu is up.
	hook.Add("PlayerBindPress", "MilBase.QuickScroll", function(ply, bind, pressed)
		if not active or not pressed then return end

		if string.find(bind, "invprev", 1, true) then
			active.sel = ((active.sel - 2) % #active.options) + 1
			MilBase.PlayUISound("hover")
			return true
		elseif string.find(bind, "invnext", 1, true) then
			active.sel = (active.sel % #active.options) + 1
			MilBase.PlayUISound("hover")
			return true
		end
	end)

	hook.Add("HUDPaint", "MilBase.QuickMenuHUD", function()
		if MilBase.InEventView() then return end
		if not active or not IsValid(active.target) then return end

		local ui = MilBase.UI
		local rowH = 26
		local w = 250
		local h = 42 + #active.options * rowH + 24
		local x = math.floor(ScrW() / 2 + 70)
		local y = math.floor(ScrH() / 2 - h / 2)

		MilBase.DrawPanelBF2(x, y, w, h, { cut = 10 })

		local title
		if active.target.LVS == true then
			title = active.target.PrintName or "VEHICLE"
		elseif MilBase.Prison and MilBase.Prison.IsPrisonerEntity
		and MilBase.Prison.IsPrisonerEntity(active.target) then
			title = active.target:GetDisplayName()
		else
			title = active.target:MBName()
		end
		draw.SimpleText(string.upper(title), "MB.Tab", x + 12, y + 4, ui.text)

		for i, option in ipairs(active.options) do
			local oy = y + 38 + (i - 1) * rowH
			local selected = active.sel == i

			if selected then
				surface.SetDrawColor(255, 198, 60, 22)
				surface.DrawRect(x + 4, oy, w - 8, rowH - 2)
				MilBase.DrawBrackets(x + 4, oy, w - 8, rowH - 2, ui.accent, 6)
			end

			draw.SimpleText(option.name, "MB.Small", x + 16, oy + (rowH - 2) / 2,
				selected and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		draw.SimpleText("SCROLL to choose  •  RELEASE [E] to confirm", "MB.Tiny",
			x + 12, y + h - 15, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end)

	local function drawCuffDragHUD()
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() or MilBase.InEventView() then return end

		local dragging = lp:GetNWEntity("mb_dragging")
		local draggedBy = lp:GetNWEntity("mb_dragged_by")
		local cuffed = lp:GetNWBool("mb_cuffed", false)
		local show = cuffed or IsValid(dragging) or IsValid(draggedBy)
		if not show then return end

		local ui = MilBase.UI or {}
		local accent = ui.warn or Color(255, 198, 60)
		local text = ui.text or color_white
		local dim = ui.dim or Color(190, 190, 190)
		local danger = ui.danger or Color(220, 70, 70)
		local ok = ui.ok or Color(90, 220, 130)
		local panel = ui.panel or Color(0, 0, 0, 185)

		local title = "RESTRAINED"
		local detail = "Movement locked"
		if IsValid(dragging) and dragging:IsPlayer() then
			title = "ESCORTING"
			detail = dragging:MBName() .. "  •  movement locked"
		elseif IsValid(draggedBy) and draggedBy:IsPlayer() then
			title = "BEING ESCORTED"
			detail = "Dragged by " .. draggedBy:MBName()
		elseif cuffed then
			title = "RESTRAINED"
			detail = "Movement locked"
		end

		local isEnemy = lp:GetNWBool("mb_eventenemy", false)
		local frac = math.Clamp(lp:GetNWFloat("mb_cuff_escape_frac", 0) or 0, 0, 1)
		local cooldown = math.max(0, (lp:GetNWFloat("mb_cuff_escape_cooldown", 0) or 0) - CurTime())
		local hasEscape = cuffed and isEnemy

		local w = 360
		local h = hasEscape and 104 or 68
		local x = math.floor(ScrW() / 2 - w / 2)
		local y = ScrH() - h - 112

		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, color = panel, accent = accent })
		else
			surface.SetDrawColor(panel)
			surface.DrawRect(x, y, w, h)
			surface.SetDrawColor(accent)
			surface.DrawOutlinedRect(x, y, w, h, 1)
		end

		draw.SimpleText(title, "MB.Small", x + 16, y + 13, accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(detail, "MB.Tiny", x + 16, y + 36, text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if hasEscape then
			local line = cooldown > 0 and ("Escape recovering: " .. math.ceil(cooldown) .. "s") or "Hold [R] to break cuffs"
			draw.SimpleText(line, "MB.Tiny", x + 16, y + 60, cooldown > 0 and danger or dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			local bx, by, bw, bh = x + 16, y + 78, w - 32, 8
			surface.SetDrawColor(255, 255, 255, 24)
			surface.DrawRect(bx, by, bw, bh)
			surface.SetDrawColor((cooldown > 0 and danger or ok))
			surface.DrawRect(bx, by, math.floor(bw * frac), bh)
		end
	end

	hook.Add("HUDPaint", "MilBase.CuffDragHUD", drawCuffDragHUD)

end

--------------------------------------------------------------------------
-- Built-in interactions
--------------------------------------------------------------------------

MilBase.RegisterQuickInteraction("promote", {
	name = "Promote",
	order = 10,
	visible = function(lp, target) return canManageView(lp, target) end,
	run = function(ply, target) MilBase.ChangeRank(ply, target, 1) end,
})

MilBase.RegisterQuickInteraction("demote", {
	name = "Demote",
	order = 11,
	visible = function(lp, target) return canManageView(lp, target) end,
	run = function(ply, target) MilBase.ChangeRank(ply, target, -1) end,
})

MilBase.RegisterQuickInteraction("push", {
	name = "Push",
	order = 20,
	run = function(ply, target)
		if (ply.mb_lastPush or 0) > CurTime() - 1.5 then return end
		ply.mb_lastPush = CurTime()

		local dir = ply:GetAimVector()
		dir.z = 0
		dir:Normalize()

		target:SetVelocity(dir * 200 + Vector(0, 0, 50))
		target:ViewPunch(Angle(-4, math.Rand(-3, 3), 0))
		ply:EmitSound("physics/body/body_medium_impact_soft" .. math.random(5, 7) .. ".wav")

		MilBase.TalkRanged(ply, cfg.TalkRange, Color(190, 170, 220),
			"** " .. ply:MBName() .. " shoves " .. target:MBName())
	end,
})

MilBase.RegisterQuickInteraction("cuff", {
	name = function(lp, target)
		return target:GetNWBool("mb_cuffed", false) and "Uncuff" or "Cuff"
	end,
	order = 30,
	visible = function(lp, target) return isPolice(lp) end,
	run = function(ply, target)
		if not isPolice(ply) then
			MilBase.Notify(ply, "Only Military Police can restrain soldiers.")
			return
		end
		MilBase.SetCuffed(target, not target:GetNWBool("mb_cuffed", false), ply)
	end,
})

MilBase.RegisterQuickInteraction("drag", {
	name = function(lp, target)
		return lp:GetNWEntity("mb_dragging") == target and "Stop Dragging" or "Drag"
	end,
	order = 31,
	visible = function(lp, target)
		return isPolice(lp) and target:GetNWBool("mb_cuffed", false)
	end,
	run = function(ply, target)
		if not isPolice(ply) then return end
		if not target:GetNWBool("mb_cuffed", false) then
			MilBase.Notify(ply, "They need to be cuffed first.")
			return
		end
		MilBase.ToggleDrag(ply, target)
	end,
})

MilBase.RegisterQuickInteraction("treat", {
	name = "Treat  (medic)",
	order = 40,
	visible = function(lp, target)
		for _, certID in ipairs(lp:MBCertList()) do
			local cert = MilBase.Certs[certID]
			if cert and cert.medicOthers then return true end
		end
		return false
	end,
	client = function(lp, target)
		-- Opens the patient's body screen with your med supplies.
		if MilBase.OpenTreatMenu then
			MilBase.OpenTreatMenu(target)
		end
	end,
})

MilBase.RegisterQuickInteraction("dogtags", {
	name = "Check Dogtags",
	order = 50,
	run = function(ply, target)
		local faction = target:MBFaction()
		local rank = target:MBRank()

		local certs = {}
		for _, id in ipairs(target:MBCertList()) do
			local cert = MilBase.Certs[id]
			table.insert(certs, cert and cert.name or id)
		end

		MilBase.Notify(ply, target:MBName() .. " — "
			.. (rank and rank.name or "Unknown") .. ", "
			.. (faction and faction.name or "Unassigned")
			.. (#certs > 0 and ("  •  " .. table.concat(certs, ", ")) or ""))
	end,
})
