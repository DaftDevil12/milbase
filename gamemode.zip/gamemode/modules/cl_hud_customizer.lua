if not CLIENT then return end

MilBase.HUDCustomizer = MilBase.HUDCustomizer or {}
local H = MilBase.HUDCustomizer

H.Layout = H.Layout or {}
H.Editing = false

local FILE_PATH = "milbase_hud_layout.json"

H.Elements = {
	vitals = { name = "Vitals Card (Health/Armor/Stamina)", defaultX = 20, defaultY = 0, relativeY = true, w = 300, h = 140 },
	ammo = { name = "Ammo & Weapon Display", defaultX = 0, defaultY = 0, relativeX = true, relativeY = true, w = 250, h = 92 },
	daily_quests = { name = "Daily Orders Tracker", defaultX = 0, defaultY = 20, relativeX = true, w = 310, h = 180 },
	compass = { name = "Compass Bar", defaultX = 0, defaultY = 15, centerX = true, w = 320, h = 30 },
	comms = { name = "Comms Menu & On-Air", defaultX = 20, defaultY = 120, w = 280, h = 100 },
	defcon = { name = "DEFCON Alert Display", defaultX = 0, defaultY = 20, relativeX = true, w = 260, h = 80 },
	chat = { name = "Chat Box Overlay", defaultX = 25, defaultY = 0, relativeY = true, w = 400, h = 200 },
	engine_damage = { name = "Engine & Ship Damage Monitor", defaultX = 20, defaultY = 240, w = 280, h = 120 },
	status_badges = { name = "Status Badges (Bleeding/Painkillers)", defaultX = 20, defaultY = 0, relativeY = true, w = 160, h = 80 },
}

function H.Load()
	if file.Exists(FILE_PATH, "DATA") then
		local raw = file.Read(FILE_PATH, "DATA")
		local data = raw and util.JSONToTable(raw)
		if istable(data) then
			H.Layout = data
		end
	end
end

function H.Save()
	file.Write(FILE_PATH, util.TableToJSON(H.Layout or {}))
	if MilBase.Notify then MilBase.Notify(LocalPlayer(), "HUD layout saved!", "ok") end
end

function H.Reset()
	H.Layout = {}
	if file.Exists(FILE_PATH, "DATA") then file.Delete(FILE_PATH) end
	if MilBase.Notify then MilBase.Notify(LocalPlayer(), "HUD layout reset to default.", "warn") end
end

function MilBase.GetHUDPosition(id, defX, defY)
	local elem = H.Elements[id]
	if not elem then return defX or 0, defY or 0 end

	local custom = H.Layout[id]
	if custom and custom.x and custom.y then
		return custom.x, custom.y
	end

	local sw, sh = ScrW(), ScrH()
	local x = defX or elem.defaultX
	local y = defY or elem.defaultY

	if elem.centerX then x = sw / 2 - elem.w / 2 end
	if elem.relativeX then x = sw - elem.w - math.abs(elem.defaultX) end
	if elem.relativeY then y = sh - elem.h - math.abs(elem.defaultY) end

	return x, y
end

function H.OpenEditor()
	if IsValid(H.Frame) then H.Frame:Remove() end
	H.Editing = true

	local sw, sh = ScrW(), ScrH()
	local frame = vgui.Create("DFrame")
	frame:SetSize(sw, sh)
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()

	H.Frame = frame

	frame.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 160)
		surface.DrawRect(0, 0, w, h)

		surface.SetDrawColor(65, 175, 240, 180)
		surface.DrawRect(0, 0, w, 50)

		draw.SimpleText("HUD CUSTOMIZER MODE (/hudedit) — DRAG BOXES TO REPOSITION ELEMENTS", "DermaDefaultBold", w / 2, 25, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local bar = vgui.Create("DPanel", frame)
	bar:SetSize(600, 40)
	bar:SetPos(sw / 2 - 300, sh - 60)
	bar.Paint = function(self, w, h)
		surface.SetDrawColor(10, 20, 30, 230)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(65, 175, 240)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
	end

	local saveBtn = vgui.Create("DButton", bar)
	saveBtn:SetSize(180, 30)
	saveBtn:SetPos(10, 5)
	saveBtn:SetText("SAVE POSITIONS")
	saveBtn.DoClick = function()
		H.Save()
		H.Editing = false
		frame:Remove()
	end

	local resetBtn = vgui.Create("DButton", bar)
	resetBtn:SetSize(180, 30)
	resetBtn:SetPos(205, 5)
	resetBtn:SetText("RESET TO DEFAULT")
	resetBtn.DoClick = function()
		H.Reset()
		H.OpenEditor()
	end

	local closeBtn = vgui.Create("DButton", bar)
	closeBtn:SetSize(180, 30)
	closeBtn:SetPos(405, 5)
	closeBtn:SetText("CANCEL / CLOSE")
	closeBtn.DoClick = function()
		H.Editing = false
		frame:Remove()
	end

	for id, elem in pairs(H.Elements) do
		local curX, curY = MilBase.GetHUDPosition(id)
		local box = vgui.Create("DButton", frame)
		box:SetSize(elem.w, elem.h)
		box:SetPos(curX, curY)
		box:SetText("")

		local dragging = false
		local dragOffsetX, dragOffsetY = 0, 0

		box.OnMousePressed = function(self, mousecode)
			if mousecode == MOUSE_LEFT then
				dragging = true
				local mx, my = gui.MousePos()
				local bx, by = self:GetPos()
				dragOffsetX = mx - bx
				dragOffsetY = my - by
				self:MouseCapture(true)
			end
		end

		box.OnMouseReleased = function(self, mousecode)
			if mousecode == MOUSE_LEFT and dragging then
				dragging = false
				self:MouseCapture(false)
				local bx, by = self:GetPos()
				H.Layout[id] = { x = bx, y = by }
			end
		end

		box.Think = function(self)
			if dragging then
				local mx, my = gui.MousePos()
				local newX = math.Clamp(mx - dragOffsetX, 0, sw - elem.w)
				local newY = math.Clamp(my - dragOffsetY, 0, sh - elem.h)
				self:SetPos(newX, newY)
				H.Layout[id] = { x = newX, y = newY }
			end
		end

		box.Paint = function(self, w, h)
			local col = self:IsHovered() and Color(65, 175, 240, 220) or Color(240, 180, 50, 180)
			surface.SetDrawColor(0, 0, 0, 180)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(col)
			surface.DrawOutlinedRect(0, 0, w, h, 2)
			draw.SimpleText(elem.name, "DermaDefaultBold", w / 2, h / 2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

concommand.Add("mb_hudedit", function()
	H.OpenEditor()
end)

concommand.Add("hudedit", function()
	H.OpenEditor()
end)

hook.Add("Initialize", "MilBase.HUDCustomizerLoad", function()
	H.Load()
end)

H.Load()
