--[[
	Paychecks module.

	This is also the reference example for MilBase's module system: any lua
	file dropped into modules/ loads automatically. Prefix the filename with
	sv_ (server), cl_ (client), or sh_ (shared). Delete this file to disable
	paychecks entirely.
]]

local cfg = MilBase.Config

timer.Create("MilBase.Paychecks", cfg.SalaryInterval, 0, function()
	for _, ply in ipairs(player.GetAll()) do
		local rank = ply:MBRank()
		local salary = rank and rank.salary or 0

		if salary > 0 then
			-- Route through the progression layer so boosters apply and
			-- payday also grants XP.
			local credits = MilBase.AwardCredits and MilBase.AwardCredits(ply, salary) or salary
			if not MilBase.AwardCredits then ply:MBAddMoney(salary) end
			if MilBase.AwardXP then MilBase.AwardXP(ply, salary) end

			MilBase.Notify(ply, "Payday: +" .. cfg.CurrencySymbol .. credits
				.. (MilBase.GetBoosterMult and MilBase.GetBoosterMult(ply) > 1 and "  (boosted)" or ""))
		end
	end
end)
