--[[
	Staff mode (/staffmode): a full switch out of your RP character.

	Entering saves your position/health/armor, strips your loadout and gives
	physgun + toolgun, then cloaks you (invisible + not solid), enables god,
	notarget and noclip. While active you get ESP: every player drawn through
	walls with name / HP / faction colour and a line showing where they're
	aiming. Toggling again restores your RP character exactly where it was.

	Min staff level: cfg.StaffModeLevel (default 1).
]]

local cfg = MilBase.Config

function MilBase.IsStaffMode(ply)
	return IsValid(ply) and ply:GetNWBool("mb_staffmode", false)
end

-- Registered SHARED so it lists in the F4 HELP tab; the func itself only
-- ever runs server-side (HandleCommand dispatches there).
MilBase.RegisterChatCommand("staffmode", {
	help = "(Staff) Toggle staff mode: cloak, god, notarget, noclip, ESP.",
	func = function(ply) MilBase.ToggleStaffMode(ply) end,
})

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	local function canStaffMode(ply)
		return ply:MBStaffLevel() >= (cfg.StaffModeLevel or 1)
	end

	local function enter(ply)
		ply.mb_smSaved = {
			pos = ply:GetPos(),
			ang = ply:EyeAngles(),
			health = ply:Health(),
			armor = ply:Armor(),
		}

		ply:SetNWBool("mb_staffmode", true)
		if MilBase.CloseCharacterSwitchMenu then
			MilBase.CloseCharacterSwitchMenu(ply)
		end
		ply:StripWeapons()
		ply:Give("weapon_physgun")
		ply:Give("gmod_tool")

		ply:GodEnable()
		ply:SetNoTarget(true)
		ply:SetNoDraw(true)
		ply:DrawShadow(false)
		ply:SetNotSolid(true)
		ply:SetMoveType(MOVETYPE_NOCLIP)

		MilBase.Notify(ply, "Staff mode ON — cloaked, god, notarget, noclip. /staffmode to return.")
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " entered staff mode", ply) end
	end

	local function exit(ply, silent)
		local saved = ply.mb_smSaved
		ply.mb_smSaved = nil

		ply:SetNWBool("mb_staffmode", false)
		ply:GodDisable()
		ply:SetNoTarget(false)
		ply:SetNoDraw(false)
		ply:DrawShadow(true)
		ply:SetNotSolid(false)
		ply:SetMoveType(MOVETYPE_WALK)

		if saved then
			ply:SetPos(saved.pos)
			ply:SetEyeAngles(saved.ang)
		end

		-- Rebuild the RP character through the normal spawn pipeline.
		ply:StripWeapons()
		hook.Run("PlayerLoadout", ply)
		if MilBase.ApplyEquipment then MilBase.ApplyEquipment(ply) end
		if saved then
			ply:SetHealth(math.min(saved.health, ply:GetMaxHealth()))
			ply:SetArmor(saved.armor)
		end

		if not silent then
			MilBase.Notify(ply, "Staff mode OFF — back to your character.")
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " left staff mode", ply) end
		end
	end

	function MilBase.ToggleStaffMode(ply)
		if not canStaffMode(ply) then
			MilBase.Notify(ply, "Staff only.")
			return
		end
		if not ply:Alive() then return end

		if MilBase.IsStaffMode(ply) then
			exit(ply)
		else
			enter(ply)
		end
	end

	-- Console fallback in case chat dispatch is unavailable: mb_staffmode
	concommand.Add("mb_staffmode", function(ply)
		if IsValid(ply) then MilBase.ToggleStaffMode(ply) end
	end)

	-- Noclip is part of staff mode even for non-engine-admin staff ranks.
	hook.Add("PlayerNoClip", "MilBase.StaffModeNoclip", function(ply, desired)
		if MilBase.IsStaffMode(ply) then return true end
	end)

	-- No accidental damage FROM cloaked staff either (god covers damage to them).
	hook.Add("EntityTakeDamage", "MilBase.StaffModeNoDamage", function(ent, dmg)
		local attacker = dmg:GetAttacker()
		if IsValid(attacker) and attacker:IsPlayer() and MilBase.IsStaffMode(attacker) then
			return true
		end
	end)

	-- Clean exits: death shouldn't happen (god), but disconnect/respawn must
	-- not leave a cloaked ghost state behind.
	hook.Add("PlayerSpawn", "MilBase.StaffModeReset", function(ply)
		if ply:GetNWBool("mb_staffmode", false) then
			ply:SetNWBool("mb_staffmode", false)
			ply.mb_smSaved = nil
			ply:SetNoDraw(false)
			ply:DrawShadow(true)
			ply:SetNotSolid(false)
			ply:SetNoTarget(false)
			ply:GodDisable()
		end
	end)

	hook.Add("PlayerDisconnected", "MilBase.StaffModeLeave", function(ply)
		ply.mb_smSaved = nil
	end)

	return
end

--------------------------------------------------------------------------
-- Client: ESP (players through walls + look direction)
--------------------------------------------------------------------------

local COL_LINE = Color(255, 198, 60, 170)

hook.Add("HUDPaint", "MilBase.StaffESP", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not MilBase.IsStaffMode(lp) then return end

	local ui = MilBase.UI

	for _, ply in ipairs(player.GetAll()) do
		if ply == lp or not ply:Alive() then continue end
		if MilBase.IsStaffMode(ply) then continue end -- other cloaked staff stay hidden

		local eye = ply:EyePos()
		local head = eye + Vector(0, 0, 10)
		local screen = head:ToScreen()
		if not screen.visible then continue end

		local dist = lp:GetPos():Distance(ply:GetPos())
		local alpha = math.Clamp(255 - dist / 12, 60, 255)

		local faction = ply:MBFaction()
		local fcol = faction and faction.color or ui.dim
		local staff = ply.MBStaffRank and ply:MBStaffRank()

		-- Look-direction line (eye -> eye + aim * 120).
		local aimEnd = (eye + ply:GetAimVector() * 120):ToScreen()
		local eyeScr = eye:ToScreen()
		if aimEnd.visible and eyeScr.visible then
			surface.SetDrawColor(COL_LINE.r, COL_LINE.g, COL_LINE.b, alpha * 0.6)
			surface.DrawLine(eyeScr.x, eyeScr.y, aimEnd.x, aimEnd.y)
			surface.DrawRect(aimEnd.x - 2, aimEnd.y - 2, 4, 4)
		end

		-- Name + rank + distance.
		draw.SimpleTextOutlined(ply:MBName(), "MB.Small", screen.x, screen.y - 26,
			Color(fcol.r, fcol.g, fcol.b, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

		local sub = math.Round(dist / 39.37) .. "m"
		if staff then sub = staff.name .. "  •  " .. sub end
		draw.SimpleTextOutlined(sub, "MB.Tiny", screen.x, screen.y - 12,
			Color(255, 255, 255, alpha * 0.7), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

		-- HP bar.
		local frac = ply:Health() / math.max(ply:GetMaxHealth(), 1)
		local bw = 46
		surface.SetDrawColor(0, 0, 0, alpha * 0.7)
		surface.DrawRect(screen.x - bw / 2, screen.y - 4, bw, 5)
		surface.SetDrawColor(frac > 0.3 and Color(150, 205, 125, alpha) or Color(220, 80, 70, alpha))
		surface.DrawRect(screen.x - bw / 2 + 1, screen.y - 3, math.floor((bw - 2) * math.Clamp(frac, 0, 1)), 3)

		-- In-sit tag.
		if ply:GetNWBool("mb_insit", false) then
			draw.SimpleTextOutlined("IN SIT", "MB.Tiny", screen.x, screen.y + 8,
				ui.warn, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end
	end

	-- Own status strip.
	draw.SimpleTextOutlined("STAFF MODE — cloaked  •  /staffmode to return", "MB.Small",
		ScrW() / 2, 24, MilBase.UI.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end)
