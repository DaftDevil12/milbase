--[[
	Gravity zones, per-map zero-gravity & magnetic boots.

	Every map has normal gravity by default. On a space / ship map, staff open
	the gravity settings menu (/gravity) and DISABLE gravity for that map, then
	SAVE it (persists per map). Once disabled the whole map is weightless EXCEPT
	inside GRAVITY ZONES traced out with the toolgun (MilBase -> Gravity Zones):
	you paint the ship interior as gravity boxes, and the void outside floats.

	The tool also paints ZERO-G CARVE-OUTS (tick "Zero-G carve-out"): weightless
	pockets that override gravity zones, so you can float an airlock or hull
	breach inside an otherwise-gravity interior. Carve-outs win everywhere.

	A weightless player drifts and moves sluggishly unless they carry Magnetic
	Boots and engage them from the self-menu (hold G). Only staff holding the
	tool see the zone boxes.
]]

local cfg = MilBase.Config

-- Zones are either an axis-aligned box { id, mins, maxs } or an extruded
-- polygon { id, poly = {Vector(x,y,0)...}, minz, maxz, mins, maxs }.
MilBase.GravityZones = MilBase.GravityZones or {}

-- Ray-cast point-in-polygon on the XY plane.
local function pointInPoly(px, py, poly)
	local inside, n = false, #poly
	local j = n
	for i = 1, n do
		local vi, vj = poly[i], poly[j]
		if ((vi.y > py) ~= (vj.y > py))
		and (px < (vj.x - vi.x) * (py - vi.y) / (vj.y - vi.y) + vi.x) then
			inside = not inside
		end
		j = i
	end
	return inside
end

-- Does a zone (box or polygon) contain a world point?
local function zoneContains(z, pos)
	if z.poly then
		return pos.z >= z.minz and pos.z <= z.maxz and pointInPoly(pos.x, pos.y, z.poly)
	end
	return pos.x >= z.mins.x and pos.x <= z.maxs.x
		and pos.y >= z.mins.y and pos.y <= z.maxs.y
		and pos.z >= z.mins.z and pos.z <= z.maxs.z
end
MilBase.GravityZoneContains = zoneContains

-- Zones carry a kind: "gravity" (a pocket of gravity in a weightless map -
-- the ship interior) or "zerog" (a weightless carve-out, e.g. an airlock or
-- breach INSIDE a gravity zone). Older saves without a kind read as gravity.
local function pointInKind(pos, kind)
	for _, z in ipairs(MilBase.GravityZones) do
		if (z.kind or "gravity") == kind and zoneContains(z, pos) then return true end
	end
	return false
end

-- Is a world point inside any gravity zone (ship interior)?
function MilBase.PointInGravityZone(pos)
	return pointInKind(pos, "gravity")
end

-- Is a world point inside a zero-G carve-out? These win over gravity zones.
function MilBase.PointInZeroGZone(pos)
	return pointInKind(pos, "zerog")
end

-- Has gravity been disabled on this map? (Global bool, synced to clients.)
function MilBase.MapGravityOff()
	return GetGlobalBool("mb_gravity_off", false)
end

-- Should a player be weightless right now? Inside a zero-G carve-out always;
-- otherwise only when the map's gravity is disabled and they're outside every
-- gravity zone.
function MilBase.PlayerInZeroG(ply, pos)
	if cfg.ZeroGEnabled == false then return false end
	pos = pos or (IsValid(ply) and ply:WorldSpaceCenter()) or vector_origin

	-- A zero-G carve-out is weightless wherever it's painted - even inside a
	-- gravity zone, and even on a map whose gravity is otherwise on.
	if MilBase.PointInZeroGZone(pos) then return true end

	-- Otherwise the map-wide toggle governs the void outside the gravity zones.
	if not MilBase.MapGravityOff() then return false end
	return not MilBase.PointInGravityZone(pos)
end

local function invHasMagBoots(inv)
	if not inv then return false end
	local pools = { inv.items }
	if inv.pack then pools[#pools + 1] = inv.pack.items end
	for _, pool in ipairs(pools) do
		for _, it in ipairs(pool or {}) do
			local def = MilBase.Items[it.id]
			if def and def.type == "magboots" then return true end
		end
	end
	return false
end

-- Works in both realms: server reads the player's inventory, client the local one.
function MilBase.HasMagBoots(ply)
	if CLIENT then return invHasMagBoots(MilBase.LocalInv) end
	return IsValid(ply) and invHasMagBoots(MilBase.GetInventory(ply))
end

-- Self-menu toggle (hold G). visible() runs client, run() runs server.
MilBase.RegisterSelfAction("magboots", {
	name = function(lp)
		return lp:GetNWBool("mb_magboots_on", false) and "Disengage Mag-Boots" or "Engage Mag-Boots"
	end,
	order = 20,
	visible = function(lp) return MilBase.HasMagBoots() end,
	run = function(ply)
		if not MilBase.HasMagBoots(ply) then return end
		local on = not ply:GetNWBool("mb_magboots_on", false)
		ply:SetNWBool("mb_magboots_on", on)
		ply:EmitSound(on and "buttons/combine_button1.wav" or "buttons/combine_button7.wav",
			62, on and 100 or 90)
		MilBase.Notify(ply, on and "Mag-boots engaged — locked to the deck." or "Mag-boots disengaged.")
	end,
})

-- Sluggish, floaty footing while weightless (runs on both realms for
-- prediction; SetGravity(0) handles the actual floating).
hook.Add("SetupMove", "MilBase.ZeroGMove", function(ply, mv)
	if not ply:GetNWBool("mb_zerog", false) then return end
	mv:SetMaxSpeed(mv:GetMaxSpeed() * 0.55)
	mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * 0.55)
end)

--------------------------------------------------------------------------
-- Server: persistence, sync, the gravity effect
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_GravityZones")
	util.AddNetworkString("MilBase_GravitySet")
	util.AddNetworkString("MilBase_GravityMenu")
	util.AddNetworkString("MilBase_GravityPolyFinish")
	util.AddNetworkString("MilBase_GravityPolyClear")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_gravzones ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map VARCHAR(64), mins TEXT, maxs TEXT, poly TEXT, kind VARCHAR(16) )")

	-- Migrate tables that predate the zero-G carve-out column: SELECT it, and
	-- only if that errors (column missing) do we ALTER it in.
	MilBase.DB.Query("SELECT kind FROM frontier_gravzones LIMIT 1", nil, function()
		MilBase.DB.Run("ALTER TABLE frontier_gravzones ADD COLUMN kind VARCHAR(16)")
	end)
	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_gravsettings (
		map VARCHAR(64) PRIMARY KEY, gravity_off INTEGER
	)]])

	local function syncAll(target)
		net.Start("MilBase_GravityZones")
			net.WriteUInt(#MilBase.GravityZones, 16)
			for _, z in ipairs(MilBase.GravityZones) do
				if z.poly then
					net.WriteBool(true)
					net.WriteUInt(#z.poly, 8)
					for _, p in ipairs(z.poly) do
						net.WriteFloat(p.x)
						net.WriteFloat(p.y)
					end
					net.WriteFloat(z.minz)
					net.WriteFloat(z.maxz)
				else
					net.WriteBool(false)
					net.WriteVector(z.mins)
					net.WriteVector(z.maxs)
				end
				net.WriteBool((z.kind or "gravity") == "zerog")
			end
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	local function loadZones(cb)
		MilBase.DB.Query(string.format(
			"SELECT * FROM frontier_gravzones WHERE map = %s", MilBase.SQLStr(game.GetMap())), function(rows)
			MilBase.GravityZones = {}
			for _, row in ipairs(rows) do
				local z = { id = tonumber(row.id) }
				if row.poly and row.poly ~= "" and row.poly ~= "NULL" then
					local data = util.JSONToTable(row.poly)
					if data and data.pts and #data.pts >= 3 then
						z.poly = {}
						for _, xy in ipairs(data.pts) do
							z.poly[#z.poly + 1] = Vector(xy[1], xy[2], 0)
						end
						z.minz, z.maxz = data.minz, data.maxz
					end
				end
				z.mins = util.StringToType(row.mins, "Vector")
				z.maxs = util.StringToType(row.maxs, "Vector")
				z.kind = (row.kind == "zerog") and "zerog" or "gravity"
				if z.poly or (isvector(z.mins) and isvector(z.maxs)) then
					MilBase.GravityZones[#MilBase.GravityZones + 1] = z
				end
			end
			if cb then cb() end
		end)
	end

	-- Load the saved per-map gravity-off flag into the global bool.
	local function loadGravitySetting()
		MilBase.DB.Query(string.format(
			"SELECT gravity_off FROM frontier_gravsettings WHERE map = %s",
			MilBase.SQLStr(game.GetMap())), function(rows)
			local off = rows and rows[1] and tonumber(rows[1].gravity_off) == 1
			SetGlobalBool("mb_gravity_off", off or false)
		end)
	end

	MilBase.GravityZones = MilBase.GravityZones or {}

	local function reload()
		loadZones(syncAll)
		loadGravitySetting()
	end

	hook.Add("InitPostEntity", "MilBase.GravityLoad", reload)
	hook.Add("PostCleanupMap", "MilBase.GravityLoad", reload)

	hook.Add("PlayerInitialSpawn", "MilBase.GravitySync", function(ply)
		timer.Simple(3, function() if IsValid(ply) then syncAll(ply) end end)
	end)

	function MilBase.GravityZoneAdd(a, b, kind)
		kind = (kind == "zerog") and "zerog" or "gravity"
		local mins = Vector(math.min(a.x, b.x), math.min(a.y, b.y), math.min(a.z, b.z))
		local maxs = Vector(math.max(a.x, b.x), math.max(a.y, b.y), math.max(a.z, b.z))
		MilBase.DB.Run(string.format(
			"INSERT INTO frontier_gravzones (map, mins, maxs, kind) VALUES (%s, %s, %s, %s)",
			MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(tostring(mins)),
			MilBase.SQLStr(tostring(maxs)), MilBase.SQLStr(kind)))
		loadZones(syncAll)
	end

	-- Create an extruded-polygon zone from a traced outline + a height. The
	-- floor is the lowest point; the prism rises `height` above it.
	function MilBase.GravityZoneAddPoly(pts, height, kind)
		if #pts < 3 then return false end
		kind = (kind == "zerog") and "zerog" or "gravity"

		local minz = math.huge
		local minx, miny, maxx, maxy = math.huge, math.huge, -math.huge, -math.huge
		for _, p in ipairs(pts) do
			minz = math.min(minz, p.z)
			minx, miny = math.min(minx, p.x), math.min(miny, p.y)
			maxx, maxy = math.max(maxx, p.x), math.max(maxy, p.y)
		end
		local maxz = minz + height

		local data = { minz = minz, maxz = maxz, pts = {} }
		for _, p in ipairs(pts) do data.pts[#data.pts + 1] = { p.x, p.y } end

		MilBase.DB.Run(string.format(
			"INSERT INTO frontier_gravzones (map, mins, maxs, poly, kind) VALUES (%s, %s, %s, %s, %s)",
			MilBase.SQLStr(game.GetMap()),
			MilBase.SQLStr(tostring(Vector(minx, miny, minz))),
			MilBase.SQLStr(tostring(Vector(maxx, maxy, maxz))),
			MilBase.SQLStr(util.TableToJSON(data)),
			MilBase.SQLStr(kind)))
		loadZones(syncAll)
		return true
	end

	-- Delete the zone containing pos, else the nearest one (box or polygon).
	-- Delete the zone under pos (else the nearest). If `kind` is given, only
	-- zones of that kind are considered, so the tool removes the kind you're
	-- currently painting - handy for a zero-G carve-out nested in a gravity zone.
	function MilBase.GravityZoneRemoveAt(pos, kind)
		local best, bestDist
		for _, z in ipairs(MilBase.GravityZones) do
			if kind and (z.kind or "gravity") ~= kind then continue end
			if MilBase.GravityZoneContains(z, pos) then
				best = z
				break
			end
			local center = (z.mins and z.maxs) and ((z.mins + z.maxs) / 2) or pos
			local d = center:DistToSqr(pos)
			if not bestDist or d < bestDist then best, bestDist = z, d end
		end
		if not best then return false end
		MilBase.DB.Run("DELETE FROM frontier_gravzones WHERE id = " .. best.id)
		loadZones(syncAll)
		return true
	end

	net.Receive("MilBase_GravityPolyFinish", function(_, ply)
		if not (ply:IsAdmin() or ply:IsSuperAdmin()) then return end
		local height = math.Clamp(net.ReadFloat(), 16, 8192)
		local kind = net.ReadBool() and "zerog" or "gravity"

		local pts = ply.mb_gzPoly
		if not pts or #pts < 3 then
			MilBase.Notify(ply, "Trace at least 3 outline points first (left-click around the room).")
			return
		end
		MilBase.GravityZoneAddPoly(pts, height, kind)
		ply.mb_gzPoly = nil
		MilBase.Notify(ply, (kind == "zerog" and "Zero-G carve-out" or "Gravity zone")
			.. " created from your traced outline.")
	end)

	net.Receive("MilBase_GravityPolyClear", function(_, ply)
		ply.mb_gzPoly = nil
	end)

	-- Set (and optionally persist) the per-map gravity-off state.
	function MilBase.SetMapGravityOff(off, save)
		SetGlobalBool("mb_gravity_off", off and true or false)
		if save then
			MilBase.DB.Run(string.format(
				"REPLACE INTO frontier_gravsettings (map, gravity_off) VALUES (%s, %d)",
				MilBase.SQLStr(game.GetMap()), off and 1 or 0))
		end
	end

	net.Receive("MilBase_GravitySet", function(_, ply)
		if not (ply:IsAdmin() or ply:IsSuperAdmin()) then return end
		local off = net.ReadBool()
		local save = net.ReadBool()
		MilBase.SetMapGravityOff(off, save)
		MilBase.Notify(ply, "Gravity " .. (off and "DISABLED (zero-g)" or "ENABLED")
			.. " on " .. game.GetMap() .. (save and " — saved." or " (not saved yet)."))
	end)

	MilBase.RegisterChatCommand("gravity", {
		help = "(Admin) Open the map gravity settings menu.",
		func = function(ply)
			if not (ply:IsAdmin() or ply:IsSuperAdmin()) then
				MilBase.Notify(ply, "Gravity settings are admin-only.")
				return
			end
			net.Start("MilBase_GravityMenu")
			net.Send(ply)
		end,
	})

	hook.Add("PlayerSpawn", "MilBase.ZeroGBootsReset", function(ply)
		ply:SetNWBool("mb_magboots_on", false)
	end)

	local function bootsActive(ply)
		return ply:GetNWBool("mb_magboots_on", false) and MilBase.HasMagBoots(ply)
	end

	local nextTick = 0
	hook.Add("Think", "MilBase.ZeroGThink", function()
		if CurTime() < nextTick then return end
		nextTick = CurTime() + 0.1
		if cfg.ZeroGEnabled == false then return end

		local grav = (cfg.ZeroGGravity and cfg.ZeroGGravity > 0) and cfg.ZeroGGravity or 0.00001

		for _, ply in ipairs(player.GetAll()) do
			local zerog = ply:Alive() and not ply:InVehicle()
				and not bootsActive(ply)
				and MilBase.PlayerInZeroG(ply)

			if zerog then
				if not ply.mb_zerog then
					ply.mb_zerog = true
					ply:SetNWBool("mb_zerog", true)
				end
				ply:SetGravity(grav)
			elseif ply.mb_zerog then
				ply.mb_zerog = false
				ply:SetNWBool("mb_zerog", false)
				ply:SetGravity(1)
			end
		end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: zone sync, tool visualization, HUD, settings menu
--------------------------------------------------------------------------

net.Receive("MilBase_GravityZones", function()
	local n = net.ReadUInt(16)
	local zones = {}
	for i = 1, n do
		if net.ReadBool() then
			local cnt = net.ReadUInt(8)
			local poly = {}
			for k = 1, cnt do poly[k] = Vector(net.ReadFloat(), net.ReadFloat(), 0) end
			zones[i] = { poly = poly, minz = net.ReadFloat(), maxz = net.ReadFloat() }
		else
			zones[i] = { mins = net.ReadVector(), maxs = net.ReadVector() }
		end
		zones[i].kind = net.ReadBool() and "zerog" or "gravity"
	end
	MilBase.GravityZones = zones
end)

-- Pending state mirrored from the tool for live previews.
MilBase.GravityPending = MilBase.GravityPending -- box mode: first corner
MilBase.GravityPoly = MilBase.GravityPoly       -- polygon mode: traced outline

local function holdingTool()
	local lp = LocalPlayer()
	local wep = lp:GetActiveWeapon()
	return IsValid(wep) and wep:GetClass() == "gmod_tool"
		and GetConVar("gmod_toolmode"):GetString() == "zerog"
end

local function boxFromCorners(a, b, h)
	local mins = Vector(math.min(a.x, b.x), math.min(a.y, b.y), math.min(a.z, b.z))
	local maxs = Vector(math.max(a.x, b.x), math.max(a.y, b.y), math.max(a.z, b.z))
	maxs.z = mins.z + (h or 512)
	return mins, maxs
end

-- Draw a polygon prism as a wireframe (bottom loop, top loop, verticals).
local function drawPrism(poly, minz, maxz, col)
	local n = #poly
	for i = 1, n do
		local a, b = poly[i], poly[i % n + 1]
		render.DrawLine(Vector(a.x, a.y, minz), Vector(b.x, b.y, minz), col, true)
		render.DrawLine(Vector(a.x, a.y, maxz), Vector(b.x, b.y, maxz), col, true)
		render.DrawLine(Vector(a.x, a.y, minz), Vector(a.x, a.y, maxz), col, true)
	end
end

hook.Add("PostDrawTranslucentRenderables", "MilBase.GravityDraw", function(_, sky)
	if sky or not holdingTool() then return end

	render.SetColorMaterial()
	local green = Color(120, 255, 160, 230) -- gravity zones (ship interior)
	local blue  = Color(120, 180, 255, 235) -- zero-G carve-outs

	-- Existing zones: gravity draws green, zero-G carve-outs draw blue.
	for _, z in ipairs(MilBase.GravityZones) do
		local zero = z.kind == "zerog"
		local line = zero and blue or green
		local fill = zero and Color(90, 140, 220, 20) or Color(90, 220, 130, 18)
		if z.poly then
			drawPrism(z.poly, z.minz, z.maxz, line)
		else
			render.DrawBox(vector_origin, angle_zero, z.mins, z.maxs, fill)
			render.DrawWireframeBox(vector_origin, angle_zero, z.mins, z.maxs, line, true)
		end
	end

	-- Previews below take the colour of the mode you're painting.
	local neg = GetConVarNumber("zerog_negative") >= 1
	local previewLine = neg and Color(150, 200, 255, 235) or Color(150, 255, 170, 230)
	local previewFill = neg and Color(90, 140, 220, 24) or Color(90, 220, 130, 22)

	-- Box mode: preview between the first corner and the cursor.
	if MilBase.GravityPending then
		local aim = LocalPlayer():GetEyeTrace().HitPos
		local h = GetConVarNumber("zerog_height")
		if h <= 0 then h = 512 end
		local mins, maxs = boxFromCorners(MilBase.GravityPending, aim, h)
		render.DrawBox(vector_origin, angle_zero, mins, maxs, previewFill)
		render.DrawWireframeBox(vector_origin, angle_zero, mins, maxs, previewLine, true)
	end

	-- Polygon mode: markers, floor lines, a live segment to the cursor, and a
	-- preview of the closed prism.
	local pts = MilBase.GravityPoly
	if pts and #pts > 0 then
		local live = previewLine
		for i = 1, #pts do
			render.DrawWireframeSphere(pts[i], 6, 6, 6, live, true)
			if i < #pts then render.DrawLine(pts[i], pts[i + 1], live, true) end
		end

		local aim = LocalPlayer():GetEyeTrace().HitPos
		render.DrawLine(pts[#pts], aim, ColorAlpha(live, 120), true)

		if #pts >= 3 then
			local h = GetConVarNumber("zerog_height")
			if h <= 0 then h = 512 end
			local minz = math.huge
			for _, p in ipairs(pts) do minz = math.min(minz, p.z) end
			drawPrism(pts, minz, minz + h, ColorAlpha(live, 180))
		end
	end
end)

-- The zero-g / mag-boots state now shows as a bottom-left status badge (see
-- core/cl_hud.lua drawStatusBadges), matching FRACTURED / BLEEDING etc.

--------------------------------------------------------------------------
-- Staff gravity settings menu (/gravity)
--------------------------------------------------------------------------

local function sendGravity(off, save)
	net.Start("MilBase_GravitySet")
		net.WriteBool(off)
		net.WriteBool(save)
	net.SendToServer()
end

function MilBase.OpenGravitySettings()
	local ui = MilBase.UI
	if IsValid(MilBase.GravityMenuFrame) then MilBase.GravityMenuFrame:Remove() end

	local frame = vgui.Create("DFrame")
	MilBase.GravityMenuFrame = frame
	frame:SetSize(400, 250)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()

	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12, accent = ui.accent })
		draw.SimpleText("MAP GRAVITY", "MB.Tab", 18, 16, ui.accent, TEXT_ALIGN_LEFT)
		draw.SimpleText(game.GetMap(), "MB.Small", 18, 44, ui.dim, TEXT_ALIGN_LEFT)

		local off = MilBase.MapGravityOff()
		draw.SimpleText("Current:", "MB.Small", 18, 78, ui.dim, TEXT_ALIGN_LEFT)
		draw.SimpleText(off and "ZERO-GRAVITY (gravity disabled)" or "NORMAL GRAVITY",
			"MB.Med", 18, 96, off and Color(120, 200, 255) or ui.ok, TEXT_ALIGN_LEFT)

		local nGrav, nZero = 0, 0
		for _, z in ipairs(MilBase.GravityZones) do
			if z.kind == "zerog" then nZero = nZero + 1 else nGrav = nGrav + 1 end
		end
		draw.SimpleText("Gravity zones: " .. nGrav .. "     Zero-G carve-outs: " .. nZero,
			"MB.Tiny", 18, 128, ui.faint, TEXT_ALIGN_LEFT)
		draw.SimpleText("When disabled, only Gravity Zones have gravity; carve-outs re-float inside them.",
			"MB.Tiny", 18, 144, ui.faint, TEXT_ALIGN_LEFT)
	end

	local function styled(x, y, w, h, label, col, font, onClick)
		local b = vgui.Create("DButton", frame)
		b:SetPos(x, y) b:SetSize(w, h) b:SetText("")
		b.Paint = function(self, bw, bh)
			surface.SetDrawColor(self:IsHovered() and ColorAlpha(col, 90) or ColorAlpha(col, 45))
			surface.DrawRect(0, 0, bw, bh)
			surface.SetDrawColor(col) surface.DrawOutlinedRect(0, 0, bw, bh)
			draw.SimpleText(label, font or "MB.Small", bw / 2, bh / 2, ui.text,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = onClick
		return b
	end

	styled(370, 12, 22, 22, "X", Color(200, 80, 70), "MB.Small", function() frame:Remove() end)

	-- Toggle live (test), then Save to persist.
	styled(18, 172, 224, 34, "TOGGLE GRAVITY", ui.accent, "MB.Tab", function()
		sendGravity(not MilBase.MapGravityOff(), false)
		surface.PlaySound("buttons/button14.wav")
	end)
	styled(250, 172, 132, 34, "SAVE", Color(120, 200, 140), "MB.Tab", function()
		sendGravity(MilBase.MapGravityOff(), true)
		surface.PlaySound("buttons/button14.wav")
	end)

	local hint = vgui.Create("DLabel", frame)
	hint:SetPos(18, 214) hint:SetSize(364, 28) hint:SetFont("MB.Tiny")
	hint:SetText("Toggle applies live so you can test; SAVE persists it for this map.")
	hint:SetTextColor(ui.dim)
end

net.Receive("MilBase_GravityMenu", function()
	MilBase.OpenGravitySettings()
end)
