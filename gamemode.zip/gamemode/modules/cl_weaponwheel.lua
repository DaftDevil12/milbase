--[[
	Custom weapon wheel: replaces GMod's CHudWeaponSelection with a radial
	selector. Scroll (invnext/invprev) or number keys open it and move the
	highlight; the highlighted weapon is equipped on +attack or after a
	short idle. Reuses the BF2 UI kit.

	Doesn't fight controls which also own the scroll binds: hold-G menus,
	vehicles/LVS, Physgun push/pull and scroll-aware Toolgun modes all receive
	the native input instead.
]]

surface.CreateFont("MB.WheelName", { font = "Bebas Neue", size = 30, weight = 400 })
surface.CreateFont("MB.WheelItem", { font = "D-DIN", size = 15, weight = 700 })
surface.CreateFont("MB.WheelAmmo", { font = "D-DIN", size = 15, weight = 500 })

-- Hide the engine selector.
hook.Add("HUDShouldDraw", "MilBase.HideWeaponSelect", function(name)
	if name == "CHudWeaponSelection" then return false end
end)

local open = false
local weps = {}
local sel = 1
local lastActivity = 0
local lastClass -- for lastinv
local IDLE_COMMIT = 1.3

local function lvsVehicle(ply)
	if not (IsValid(ply) and ply.lvsGetVehicle) then return nil end
	local vehicle = ply:lvsGetVehicle()
	return IsValid(vehicle) and vehicle or nil
end

local function nativeScrollOwner(ply)
	if not IsValid(ply) then return false end
	-- Vehicle addons commonly use invnext/invprev for weapon groups. Never
	-- open the on-foot selector while seated, including LVS remote seats.
	if ply:InVehicle() or IsValid(lvsVehicle(ply)) then return true end

	local activeWeapon = ply:GetActiveWeapon()
	if not IsValid(activeWeapon) then return false end
	local class = activeWeapon:GetClass()
	if class == "weapon_physgun" and ply:KeyDown(IN_ATTACK) then
		return true
	end
	if class == "gmod_tool" and ply.GetTool then
		local tool = ply:GetTool()
		if tool and tool.Scroll ~= nil then return true end
	end
	return false
end

local function weaponName(wep)
	if not IsValid(wep) then return "" end
	local n = wep:GetPrintName() or wep:GetClass()
	if string.sub(n, 1, 1) == "#" then n = language.GetPhrase(n) end
	return n
end

-- Refresh the weapon list, keeping a stable slot/name order.
local function rebuild()
	weps = {}
	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	for _, w in ipairs(lp:GetWeapons()) do
		if IsValid(w) then weps[#weps + 1] = w end
	end

	table.sort(weps, function(a, b)
		if a:GetSlot() ~= b:GetSlot() then return a:GetSlot() < b:GetSlot() end
		return weaponName(a) < weaponName(b)
	end)
end

local function blocked()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return true end
	if input.IsKeyDown(KEY_G) then return true end -- self menu owns scroll
	if lp:InVehicle() or IsValid(lvsVehicle(lp)) then return true end
	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible()
	or vgui.CursorVisible() then return true end
	return false
end

local function openOrMove(dir)
	if not open then
		rebuild()
		if #weps < 2 then return false end -- nothing to switch between
		open = true
		-- Start the highlight on the currently held weapon.
		local cur = LocalPlayer():GetActiveWeapon()
		sel = 1
		for i, w in ipairs(weps) do
			if w == cur then sel = i break end
		end
		surface.PlaySound("ui/buttonrollover.wav")
	end

	sel = ((sel - 1 + dir) % #weps) + 1
	lastActivity = CurTime()
	surface.PlaySound("ui/buttonrollover.wav")
	return true
end

local function commit()
	if open and weps[sel] and IsValid(weps[sel]) then
		local prev = LocalPlayer():GetActiveWeapon()
		if IsValid(prev) then lastClass = prev:GetClass() end
		input.SelectWeapon(weps[sel])
		surface.PlaySound("ui/buttonclickrelease.wav")
	end
	open = false
end

hook.Add("PlayerBindPress", "MilBase.WeaponWheel", function(_, bind, pressed)
	if not pressed then return end
	bind = string.lower(tostring(bind or ""))
	local scroll = string.find(bind, "invnext", 1, true)
		or string.find(bind, "invprev", 1, true)
	if scroll and nativeScrollOwner(LocalPlayer()) then
		-- Cancel a selector left open before the native control took ownership,
		-- then return nil so the Physgun/LVS/Toolgun receives this wheel event.
		open = false
		return
	end

	-- Confirm/fire while the wheel is up.
	if open and string.find(bind, "+attack", 1, true) and not string.find(bind, "+attack2", 1, true) then
		commit()
		return true
	end

	if blocked() then return end

	if string.find(bind, "invnext", 1, true) then
		return openOrMove(1)
	elseif string.find(bind, "invprev", 1, true) then
		return openOrMove(-1)
	elseif string.find(bind, "lastinv", 1, true) then
		if lastClass then
			local lp = LocalPlayer()
			for _, w in ipairs(lp:GetWeapons()) do
				if IsValid(w) and w:GetClass() == lastClass then
					local cur = lp:GetActiveWeapon()
					if IsValid(cur) then lastClass = cur:GetClass() end
					input.SelectWeapon(w)
					surface.PlaySound("ui/buttonclickrelease.wav")
					return true
				end
			end
		end
	else
		-- slot1..slot6 -> jump straight to the Nth weapon in that slot.
		local slot = string.match(bind, "slot(%d)")
		if slot then
			rebuild()
			if #weps == 0 then return end
			open = true
			local want = tonumber(slot) - 1
			sel = 1
			for i, w in ipairs(weps) do
				if w:GetSlot() == want then sel = i break end
			end
			lastActivity = CurTime()
			surface.PlaySound("ui/buttonrollover.wav")
			return true
		end
	end
end)

-- Auto-commit after a brief idle so scroll-and-pause equips the weapon.
hook.Add("Think", "MilBase.WeaponWheelIdle", function()
	if not open then return end
	if blocked() then
		open = false
		return
	end
	if CurTime() - lastActivity > IDLE_COMMIT then commit() end
end)

hook.Add("HUDPaint", "MilBase.WeaponWheelDraw", function()
	if not open then return end
	if #weps == 0 then open = false return end

	local ui = MilBase.UI
	local cx, cy = ScrW() / 2, ScrH() / 2
	local n = #weps
	local radius = math.Clamp(90 + n * 14, 150, 250)

	-- Dim backdrop.
	surface.SetDrawColor(0, 0, 0, 110)
	surface.DrawRect(0, 0, ScrW(), ScrH())

	for i, w in ipairs(weps) do
		local ang = math.rad(-90 + (i - 1) / n * 360)
		local x = cx + math.cos(ang) * radius
		local y = cy + math.sin(ang) * radius
		local selected = i == sel

		local bw, bh = 150, 34
		local bx, by = x - bw / 2, y - bh / 2

		MilBase.DrawPanelBF2(bx, by, bw, bh, {
			cut = 6,
			color = selected and Color(255, 198, 60, 30) or Color(10, 10, 12, 210),
			outlineColor = selected and ui.accent or ui.outline,
		})
		if selected then MilBase.DrawBrackets(bx, by, bw, bh, ui.accent, 7) end

		draw.SimpleText(string.upper(weaponName(w)), "MB.WheelItem", x, y,
			selected and ui.text or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Center hub: selected weapon name + ammo.
	local cur = weps[sel]
	if IsValid(cur) then
		draw.SimpleText(string.upper(weaponName(cur)), "MB.WheelName", cx, cy - 10,
			ui.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		local clip = cur:Clip1()
		if clip and clip >= 0 then
			local reserve = LocalPlayer():GetAmmoCount(cur:GetPrimaryAmmoType())
			draw.SimpleText(clip .. "  /  " .. reserve, "MB.WheelAmmo", cx, cy + 14,
				ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end)
