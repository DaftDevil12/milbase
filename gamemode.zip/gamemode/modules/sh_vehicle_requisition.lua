--[[
	MilBase Vehicle Requisition / Officer of the Deck system.

	Flow:
	  /od toggles/transfers the active Officer of the Deck.
	  Players press E on mb_vehicle_requisition_terminal to request a vehicle.
	  The active OD opens /odmenu to accept/deny pending requests.
	  Staff configure vehicles/settings in game with /vehreqconfig.
	  Staff place persistent vehicle pads with the Vehicle Requisition Spawn Toolgun.
]]

local cfg = MilBase.Config
MilBase.VehicleReq = MilBase.VehicleReq or {}
local VR = MilBase.VehicleReq

cfg.VehicleReqStaffLevel = cfg.VehicleReqStaffLevel or 3
cfg.VehicleReqTerminalModel = cfg.VehicleReqTerminalModel or "models/lordtrilobite/starwars/isd/imp_console_medium03.mdl"
cfg.VehicleReqTerminalRange = cfg.VehicleReqTerminalRange or 170
cfg.VehicleReqRequestCooldown = cfg.VehicleReqRequestCooldown or 8
cfg.VehicleReqPadClearRadius = cfg.VehicleReqPadClearRadius or 80
cfg.VehicleReqPadClearHeight = cfg.VehicleReqPadClearHeight or 96
cfg.VehicleReqUseWorldHullCheck = cfg.VehicleReqUseWorldHullCheck or false

local NET_TERMINAL_OPEN = "MilBase_VehicleReq_TerminalOpen"
local NET_SUBMIT = "MilBase_VehicleReq_Submit"
local NET_OD_OPEN = "MilBase_VehicleReq_ODOpen"
local NET_OD_DECIDE = "MilBase_VehicleReq_ODDecide"
local NET_ADMIN_OPEN = "MilBase_VehicleReq_AdminOpen"
local NET_ADMIN_ACTION = "MilBase_VehicleReq_AdminAction"

local function trim(s)
	return string.Trim(tostring(s or ""))
end

local function lower(s)
	return string.lower(trim(s))
end

local function splitList(value)
	local out = {}
	value = trim(value)
	if value == "" then return out end
	for part in string.gmatch(value, "([^,;|]+)") do
		part = trim(part)
		if part ~= "" then out[#out + 1] = part end
	end
	return out
end

local function joinList(list)
	if not istable(list) then return trim(list) end
	local out = {}
	for _, v in ipairs(list) do
		v = trim(v)
		if v ~= "" then out[#out + 1] = v end
	end
	return table.concat(out, ",")
end

local function listHas(listText, candidates)
	local list = splitList(listText)
	if #list == 0 then return true end

	local wanted = {}
	for _, c in ipairs(candidates or {}) do
		if trim(c) ~= "" then wanted[lower(c)] = true end
	end

	for _, item in ipairs(list) do
		local l = lower(item)
		if l == "*" or l == "all" or wanted[l] then return true end
	end
	return false
end

local function displayList(value, emptyText)
	local list = splitList(value)
	if #list == 0 then return emptyText or "Any" end
	return table.concat(list, ", ")
end

local function certTokenMatchesPlayer(ply, token)
	token = lower(token)
	if token == "" then return false end
	if not IsValid(ply) or not ply.MBCertList then return false end

	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs and MilBase.Certs[certID]
		if lower(certID) == token or (cert and lower(cert.name) == token) then
			return true
		end
	end
	return false
end

local function certRequirementPasses(ply, certText, requireAll)
	local certs = splitList(certText)
	if #certs == 0 then return true end

	local matched = 0
	for _, token in ipairs(certs) do
		local l = lower(token)
		if l == "*" or l == "all" or certTokenMatchesPlayer(ply, token) then
			matched = matched + 1
		elseif requireAll then
			return false
		end
	end

	return requireAll and matched == #certs or matched > 0
end

function VR.RankGroup(ply)
	if MilBase.SpawnSelectorRankGroup then return MilBase.SpawnSelectorRankGroup(ply) end
	if MilBase.QuartermasterRankGroup then return MilBase.QuartermasterRankGroup(ply) end

	local rank = IsValid(ply) and ply.MBRank and ply:MBRank() or nil
	if not rank then return "trooper" end
	if isstring(rank.vehicleReqGroup) and rank.vehicleReqGroup ~= "" then return lower(rank.vehicleReqGroup) end
	if isstring(rank.spawnGroup) and rank.spawnGroup ~= "" then return lower(rank.spawnGroup) end
	if isstring(rank.quartermasterGroup) and rank.quartermasterGroup ~= "" then return lower(rank.quartermasterGroup) end

	local name = lower(rank.name)
	local groups = cfg.QuartermasterRankGroups or {}
	for _, group in ipairs({ "commander", "officer", "nco" }) do
		for _, token in ipairs(groups[group] or {}) do
			if token ~= "" and string.find(name, lower(token), 1, true) then return group end
		end
	end

	return "trooper"
end

local function playerRankNames(ply)
	local rank = IsValid(ply) and ply.MBRank and ply:MBRank() or nil
	local group = VR.RankGroup(ply)
	local names = { group, rank and rank.name or "" }
	if group == "trp" or group == "trooper" then
		names[#names + 1] = "trooper"
		names[#names + 1] = "trp"
		names[#names + 1] = "enlisted"
	end
	return names
end

local function factionNames(ply)
	local faction = IsValid(ply) and ply.MBFaction and ply:MBFaction() or nil
	return { IsValid(ply) and ply.MBFactionID and ply:MBFactionID() or "", faction and faction.name or "" }
end

function VR.CanStaffConfigure(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) then return false end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	return ply.MBStaffLevel and ply:MBStaffLevel() >= (cfg.VehicleReqStaffLevel or 3)
end

VR.DefaultSettings = {
	od_priority_factions = "Republic Navy",
	od_allowed_factions = "",
	od_rank_groups = "officer,commander",
	request_cooldown = tostring(cfg.VehicleReqRequestCooldown or 8),
	staff_level = tostring(cfg.VehicleReqStaffLevel or 3),
	pad_clear_radius = tostring(cfg.VehicleReqPadClearRadius or 80),
	pad_clear_height = tostring(cfg.VehicleReqPadClearHeight or 96),
	world_hull_check = cfg.VehicleReqUseWorldHullCheck and "1" or "0",
}

function VR.GetSetting(key, fallback)
	VR.Settings = VR.Settings or table.Copy(VR.DefaultSettings)
	local val = VR.Settings[key]
	if val == nil or val == "" then return fallback end
	return val
end

function VR.GetRequestCooldown()
	return math.max(0, tonumber(VR.GetSetting("request_cooldown", cfg.VehicleReqRequestCooldown or 8)) or 8)
end

function VR.AccessText(data, kind)
	local parts = {}
	if kind == "spawn" and trim(data.vehicles) ~= "" then
		parts[#parts + 1] = "Vehicles: " .. displayList(data.vehicles, "Any")
	end
	parts[#parts + 1] = "Faction: " .. displayList(data.factions, "Any")
	local minRank = tonumber(data.minRank or 0) or 0
	local maxRank = tonumber(data.maxRank or 0) or 0
	if minRank > 0 or maxRank > 0 then
		if minRank > 0 and maxRank > 0 then
			parts[#parts + 1] = "Ranks: " .. minRank .. "-" .. maxRank
		elseif minRank > 0 then
			parts[#parts + 1] = "Rank: " .. minRank .. "+"
		else
			parts[#parts + 1] = "Rank: up to " .. maxRank
		end
	end
	if trim(data.rankGroups) ~= "" then
		parts[#parts + 1] = "Rank Groups: " .. displayList(data.rankGroups, "Any")
	end
	if trim(data.certs) ~= "" then
		parts[#parts + 1] = "Certs: " .. displayList(data.certs, "Any")
		parts[#parts + 1] = (tonumber(data.requireAll or 0) == 1) and "Requires all certs" or "Requires any cert"
	end
	return table.concat(parts, "  •  ")
end

function VR.CanAccessRule(ply, data)
	if not IsValid(ply) or not ply:IsPlayer() then return false, "Invalid player" end
	if not data then return false, "Invalid rule" end
	if tonumber(data.active or 1) == 0 then return false, "Inactive" end

	if not listHas(data.factions or "", factionNames(ply)) then
		return false, "Wrong faction"
	end

	local rankIndex = ply.MBRankIndex and ply:MBRankIndex() or 1
	local minRank = tonumber(data.minRank or 0) or 0
	local maxRank = tonumber(data.maxRank or 0) or 0
	if minRank > 0 and rankIndex < minRank then return false, "Rank too low" end
	if maxRank > 0 and rankIndex > maxRank then return false, "Rank too high" end

	if not listHas(data.rankGroups or "", playerRankNames(ply)) then
		return false, "Wrong rank group"
	end

	if not certRequirementPasses(ply, data.certs or "", tonumber(data.requireAll or 0) == 1) then
		return false, "Missing cert"
	end

	return true
end

local function vehicleTokens(vehicle)
	if not vehicle then return {} end
	return {
		tostring(vehicle.id or ""),
		vehicle.name or "",
		vehicle.entityClass or "",
		vehicle.category or "",
	}
end

function VR.SpawnAllowsVehicle(spawn, vehicle)
	return spawn and vehicle and listHas(spawn.vehicles or "", vehicleTokens(vehicle))
end

function VR.CanUseVehicle(ply, vehicle)
	return VR.CanAccessRule(ply, vehicle)
end

function VR.CanUseSpawn(ply, spawn, vehicle)
	local ok, reason = VR.CanAccessRule(ply, spawn)
	if not ok then return false, reason end
	if vehicle and not VR.SpawnAllowsVehicle(spawn, vehicle) then
		return false, "Vehicle not allowed at this spawn"
	end
	return true
end

function VR.IsPriorityOD(ply)
	if not IsValid(ply) then return false end
	return listHas(VR.GetSetting("od_priority_factions", "Republic Navy"), factionNames(ply))
end

function VR.CanBeOD(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false, "Invalid player" end
	if not ply:Alive() then return false, "You must be alive to take OD." end
	if VR.IsPriorityOD(ply) then return true end

	local allowedFactions = trim(VR.GetSetting("od_allowed_factions", ""))
	if allowedFactions ~= "" and not listHas(allowedFactions, factionNames(ply)) then
		return false, "Your faction is not allowed to take OD."
	end

	local rank = ply.MBRank and ply:MBRank() or nil
	if rank and rank.canPromote then return true end
	if listHas(VR.GetSetting("od_rank_groups", "officer,commander"), playerRankNames(ply)) then return true end
	return false, "Only Republic Navy or officers can take OD."
end

function VR.GetOD()
	local od = VR.OD
	if IsValid(od) and od:IsPlayer() then return od end
	VR.OD = nil
	return nil
end


-- Add OD to the generated RP name on both server and client.
local baseFormatRPName = MilBase.FormatRPName
if baseFormatRPName and not MilBase.VehicleReqNameWrapped then
	MilBase.VehicleReqNameWrapped = true
	MilBase.FormatRPName = function(ply, rawName)
		local name = baseFormatRPName(ply, rawName)
		if IsValid(ply) and ply:GetNWBool("mb_od", false) and not string.find(name, "%f[%w]OD%f[%W]$") then
			name = name .. " OD"
		end
		return name
	end
end

if SERVER then
	util.AddNetworkString(NET_TERMINAL_OPEN)
	util.AddNetworkString(NET_SUBMIT)
	util.AddNetworkString(NET_OD_OPEN)
	util.AddNetworkString(NET_OD_DECIDE)
	util.AddNetworkString(NET_ADMIN_OPEN)
	util.AddNetworkString(NET_ADMIN_ACTION)

	VR.Vehicles = VR.Vehicles or {}
	VR.Spawns = VR.Spawns or {}
	VR.Terminals = VR.Terminals or {}
	VR.Requests = VR.Requests or {}
	VR.NextRequestID = VR.NextRequestID or 1

	local function sqlText(value) return MilBase.SQLStr(trim(value)) end
	local function sqlInt(value) return math.floor(tonumber(value or 0) or 0) end
	local function sqlBool(value) return value and 1 or 0 end

	local function createTables()
		MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_vehicle_req_settings ("
			.. "setting_key VARCHAR(64) PRIMARY KEY, setting_value TEXT)")

		MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_vehicle_req_vehicles ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "name TEXT, entity_class TEXT, category TEXT, factions TEXT, certs TEXT, require_all INTEGER, "
			.. "min_rank INTEGER, max_rank INTEGER, rank_groups TEXT, active INTEGER)")

		MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_vehicle_req_spawns ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "map VARCHAR(64), name TEXT, pos TEXT, ang TEXT, vehicles TEXT, factions TEXT, certs TEXT, require_all INTEGER, "
			.. "min_rank INTEGER, max_rank INTEGER, rank_groups TEXT, active INTEGER)")

		MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_vehicle_req_terminals ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "map VARCHAR(64), name TEXT, pos TEXT, ang TEXT, active INTEGER)")
	end
	createTables()

	local function rowToVehicle(row)
		return {
			id = tonumber(row.id) or 0,
			name = row.name or "Vehicle",
			entityClass = row.entity_class or row.entityClass or "",
			category = row.category or "General",
			factions = row.factions or "",
			certs = row.certs or "",
			requireAll = tonumber(row.require_all or row.requireAll or 0) or 0,
			minRank = tonumber(row.min_rank or row.minRank or 0) or 0,
			maxRank = tonumber(row.max_rank or row.maxRank or 0) or 0,
			rankGroups = row.rank_groups or row.rankGroups or "",
			active = tonumber(row.active or 1) or 1,
		}
	end

	local function rowToSpawn(row)
		local pos = util.StringToType(row.pos or "", "Vector")
		local ang = util.StringToType(row.ang or "", "Angle")
		if not isvector(pos) then pos = vector_origin end
		if not isangle(ang) then ang = angle_zero end

		return {
			id = tonumber(row.id) or 0,
			map = row.map or game.GetMap(),
			name = row.name or "Vehicle Spawn",
			pos = pos,
			ang = ang,
			vehicles = row.vehicles or "",
			factions = row.factions or "",
			certs = row.certs or "",
			requireAll = tonumber(row.require_all or row.requireAll or 0) or 0,
			minRank = tonumber(row.min_rank or row.minRank or 0) or 0,
			maxRank = tonumber(row.max_rank or row.maxRank or 0) or 0,
			rankGroups = row.rank_groups or row.rankGroups or "",
			active = tonumber(row.active or 1) or 1,
		}
	end

	local function rowToTerminal(row)
		local pos = util.StringToType(row.pos or "", "Vector")
		local ang = util.StringToType(row.ang or "", "Angle")
		if not isvector(pos) then pos = vector_origin end
		if not isangle(ang) then ang = angle_zero end

		return {
			id = tonumber(row.id) or 0,
			map = row.map or game.GetMap(),
			name = row.name or "Vehicle Requisition Console",
			pos = pos,
			ang = ang,
			active = tonumber(row.active or 1) or 1,
		}
	end

	function VR.ReloadSettings(cb)
		VR.Settings = table.Copy(VR.DefaultSettings)
		MilBase.DB.Query("SELECT * FROM frontier_vehicle_req_settings", function(rows)
			for _, row in ipairs(rows or {}) do
				local key = row.setting_key or row.key
				local value = row.setting_value or row.value or ""
				if key then VR.Settings[key] = tostring(value or "") end
			end
			cfg.VehicleReqStaffLevel = tonumber(VR.Settings.staff_level or cfg.VehicleReqStaffLevel or 3) or 3
			if cb then cb() end
		end)
	end

	function VR.ReloadVehicles(cb)
		MilBase.DB.Query("SELECT * FROM frontier_vehicle_req_vehicles ORDER BY category, name", function(rows)
			VR.Vehicles = {}
			for _, row in ipairs(rows or {}) do
				local vehicle = rowToVehicle(row)
				if vehicle.id > 0 then VR.Vehicles[vehicle.id] = vehicle end
			end
			if cb then cb() end
		end)
	end

	function VR.ReloadSpawns(cb)
		MilBase.DB.Query("SELECT * FROM frontier_vehicle_req_spawns WHERE map = " .. MilBase.SQLStr(game.GetMap()) .. " ORDER BY name", function(rows)
			VR.Spawns = {}
			for _, row in ipairs(rows or {}) do
				local spawn = rowToSpawn(row)
				if spawn.id > 0 then VR.Spawns[spawn.id] = spawn end
			end
			if cb then cb() end
		end)
	end

	local function removePersistedTerminalEntities()
		for _, ent in ipairs(ents.FindByClass("mb_vehicle_requisition_terminal")) do
			if ent.MilBaseVehicleReqTerminalPersisted then ent:Remove() end
		end
	end

	function VR.SpawnTerminalEntity(data)
		if data then data.ent = nil end
		if not data or tonumber(data.active or 1) == 0 then return nil end
		local ent = ents.Create("mb_vehicle_requisition_terminal")
		if not IsValid(ent) then return nil end
		ent:SetPos(data.pos or vector_origin)
		ent:SetAngles(data.ang or angle_zero)
		ent.MilBaseVehicleReqTerminalPersisted = true
		ent.MilBaseVehicleReqTerminalID = data.id
		ent.MilBaseVehicleReqTerminalName = data.name
		ent:Spawn()
		ent:Activate()
		local phys = ent:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
		data.ent = ent
		return ent
	end

	function VR.ReloadTerminals(cb)
		MilBase.DB.Query("SELECT * FROM frontier_vehicle_req_terminals WHERE map = " .. MilBase.SQLStr(game.GetMap()) .. " ORDER BY name", function(rows)
			removePersistedTerminalEntities()
			VR.Terminals = {}
			for _, row in ipairs(rows or {}) do
				local terminal = rowToTerminal(row)
				if terminal.id > 0 then
					VR.Terminals[terminal.id] = terminal
					VR.SpawnTerminalEntity(terminal)
				end
			end
			if cb then cb() end
		end)
	end

	function VR.ReloadAll(cb)
		VR.ReloadSettings(function()
			VR.ReloadVehicles(function()
				VR.ReloadSpawns(function()
					VR.ReloadTerminals(cb)
				end)
			end)
		end)
	end

	hook.Add("InitPostEntity", "MilBase.VehicleReq.Reload", function() VR.ReloadAll() end)
	hook.Add("PostCleanupMap", "MilBase.VehicleReq.Reload", function()
		timer.Simple(0, function()
			if VR.ReloadSpawns then VR.ReloadSpawns() end
			if VR.ReloadTerminals then VR.ReloadTerminals() end
		end)
	end)
	hook.Add("MilBase.DBReady", "MilBase.VehicleReq.Reload", function() VR.ReloadAll() end)

	function VR.BroadcastOD(text, color)
		MilBase.ChatMsg(nil, color or Color(180, 60, 60), "[OD] ", color_white, text)
	end

	local function setODFlags(old, new)
		if IsValid(old) then old:SetNWBool("mb_od", false) end
		if IsValid(new) then new:SetNWBool("mb_od", true) end
	end

	function VR.SetOD(ply)
		local ok, err = VR.CanBeOD(ply)
		if not ok then MilBase.Notify(ply, err, "warn") return false end

		local current = VR.GetOD()
		if current == ply then
			VR.ClearOD("stepdown")
			return true
		end

		if IsValid(current) and VR.IsPriorityOD(current) and not VR.IsPriorityOD(ply) then
			MilBase.Notify(ply, "Republic Navy currently has OD priority.", "warn")
			return false
		end

		VR.OD = ply
		setODFlags(current, ply)
		if IsValid(current) then
			VR.BroadcastOD("Officer of the Deck has been transferred from " .. current:MBName() .. " to " .. ply:MBName() .. ".")
		else
			VR.BroadcastOD(ply:MBName() .. " is now Officer of the Deck.")
		end
		return true
	end

	function VR.ClearOD(reason)
		local current = VR.GetOD()
		if not IsValid(current) then return false end
		VR.OD = nil
		current:SetNWBool("mb_od", false)
		VR.BroadcastOD(current:MBName() .. " has stepped down as Officer of the Deck.")
		return true
	end

	MilBase.RegisterChatCommand("od", {
		help = "Take or step down as Officer of the Deck.",
		func = function(ply)
			VR.SetOD(ply)
		end,
	})

	MilBase.RegisterChatCommand("odmenu", {
		help = "Open the Officer of the Deck vehicle request menu.",
		func = function(ply)
			VR.OpenODMenu(ply)
		end,
	})
	MilBase.RegisterChatCommand("odrequests", {
		help = "Open the Officer of the Deck vehicle request menu.",
		func = function(ply)
			VR.OpenODMenu(ply)
		end,
	})

	MilBase.RegisterChatCommand("vehreqconfig", {
		help = "Open staff Vehicle Requisition configuration.",
		func = function(ply)
			VR.OpenAdminMenu(ply)
		end,
	})
	MilBase.RegisterChatCommand("vehiclereqconfig", {
		help = "Open staff Vehicle Requisition configuration.",
		func = function(ply)
			VR.OpenAdminMenu(ply)
		end,
	})

	hook.Add("PlayerDisconnected", "MilBase.VehicleReq.ODDisconnect", function(ply)
		if VR.GetOD() == ply then VR.ClearOD("disconnect") end
		for id, req in pairs(VR.Requests or {}) do
			if req.requester == ply then VR.Requests[id] = nil end
		end
	end)

	hook.Add("PlayerDeath", "MilBase.VehicleReq.ODDeath", function(ply)
		if VR.GetOD() == ply then VR.ClearOD("death") end
	end)

	local function recheckODRole(ply)
		if VR.GetOD() == ply then
			local ok = VR.CanBeOD(ply)
			if not ok then VR.ClearOD("role") end
		end
	end

	local baseSetFaction = MilBase.SetFaction
	if baseSetFaction and not MilBase.VehicleReqSetFactionWrapped then
		MilBase.VehicleReqSetFactionWrapped = true
		MilBase.SetFaction = function(ply, factionID, rank, actor)
			local ret = { baseSetFaction(ply, factionID, rank, actor) }
			timer.Simple(0, function() if IsValid(ply) then recheckODRole(ply) end end)
			return unpack(ret)
		end
	end

	local baseSetRank = MilBase.SetRank
	if baseSetRank and not MilBase.VehicleReqSetRankWrapped then
		MilBase.VehicleReqSetRankWrapped = true
		MilBase.SetRank = function(ply, rankIndex, actor)
			local ret = { baseSetRank(ply, rankIndex, actor) }
			timer.Simple(0, function() if IsValid(ply) then recheckODRole(ply) end end)
			return unpack(ret)
		end
	end

	function VR.GetVehicle(id)
		return VR.Vehicles[tonumber(id or 0) or 0]
	end

	function VR.GetSpawn(id)
		return VR.Spawns[tonumber(id or 0) or 0]
	end

	function VR.GetTerminal(id)
		return VR.Terminals and VR.Terminals[tonumber(id or 0) or 0]
	end

	function VR.NearestTerminal(pos, radius)
		local best, bestD
		local maxD = (radius or 260) ^ 2
		for _, terminal in pairs(VR.Terminals or {}) do
			local d = terminal.pos and terminal.pos:DistToSqr(pos) or math.huge
			if d <= maxD and (not bestD or d < bestD) then
				best, bestD = terminal, d
			end
		end
		return best
	end

	function VR.NearestSpawn(pos, radius)
		local best, bestD
		local maxD = (radius or 260) ^ 2
		for _, spawn in pairs(VR.Spawns or {}) do
			local d = spawn.pos and spawn.pos:DistToSqr(pos) or math.huge
			if d <= maxD and (not bestD or d < bestD) then
				best, bestD = spawn, d
			end
		end
		return best
	end

	local function sanitizeVehicle(data)
		data = istable(data) and data or {}
		return {
			name = trim(data.name) ~= "" and trim(data.name) or "Vehicle",
			entityClass = trim(data.entityClass or data.entity_class),
			category = trim(data.category) ~= "" and trim(data.category) or "General",
			factions = trim(data.factions),
			certs = trim(data.certs),
			requireAll = data.requireAll and 1 or 0,
			minRank = math.max(0, sqlInt(data.minRank)),
			maxRank = math.max(0, sqlInt(data.maxRank)),
			rankGroups = trim(data.rankGroups),
			active = data.active == false and 0 or 1,
		}
	end

	local function sanitizeSpawn(data)
		data = istable(data) and data or {}
		return {
			name = trim(data.name) ~= "" and trim(data.name) or "Vehicle Spawn",
			vehicles = trim(data.vehicles),
			factions = trim(data.factions),
			certs = trim(data.certs),
			requireAll = data.requireAll and 1 or 0,
			minRank = math.max(0, sqlInt(data.minRank)),
			maxRank = math.max(0, sqlInt(data.maxRank)),
			rankGroups = trim(data.rankGroups),
			active = data.active == false and 0 or 1,
		}
	end

	function VR.AddVehicle(ply, data)
		if not VR.CanStaffConfigure(ply) then return false end
		data = sanitizeVehicle(data)
		if data.entityClass == "" then MilBase.Notify(ply, "Vehicle entity class is required.", "warn") return false end
		MilBase.DB.Insert(string.format(
			"INSERT INTO frontier_vehicle_req_vehicles (name, entity_class, category, factions, certs, require_all, min_rank, max_rank, rank_groups, active) VALUES (%s, %s, %s, %s, %s, %d, %d, %d, %s, %d)",
			sqlText(data.name), sqlText(data.entityClass), sqlText(data.category), sqlText(data.factions), sqlText(data.certs), data.requireAll, data.minRank, data.maxRank, sqlText(data.rankGroups), data.active
		), function(id)
			if not id then if IsValid(ply) then MilBase.Notify(ply, "Vehicle could not be saved.", "danger") end return end
			data.id = tonumber(id)
			VR.Vehicles[data.id] = data
			if IsValid(ply) then MilBase.Notify(ply, "Vehicle saved: " .. data.name .. ".", "ok") VR.OpenAdminMenu(ply) end
		end)
		return true
	end

	function VR.UpdateVehicle(ply, id, data)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		if not VR.Vehicles[id] then MilBase.Notify(ply, "Vehicle not found.", "warn") return false end
		data = sanitizeVehicle(data)
		if data.entityClass == "" then MilBase.Notify(ply, "Vehicle entity class is required.", "warn") return false end
		MilBase.DB.Run(string.format(
			"UPDATE frontier_vehicle_req_vehicles SET name = %s, entity_class = %s, category = %s, factions = %s, certs = %s, require_all = %d, min_rank = %d, max_rank = %d, rank_groups = %s, active = %d WHERE id = %d",
			sqlText(data.name), sqlText(data.entityClass), sqlText(data.category), sqlText(data.factions), sqlText(data.certs), data.requireAll, data.minRank, data.maxRank, sqlText(data.rankGroups), data.active, id
		))
		data.id = id
		VR.Vehicles[id] = data
		MilBase.Notify(ply, "Vehicle updated: " .. data.name .. ".", "ok")
		VR.OpenAdminMenu(ply)
		return true
	end

	function VR.DeleteVehicle(ply, id)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		if not VR.Vehicles[id] then MilBase.Notify(ply, "Vehicle not found.", "warn") return false end
		MilBase.DB.Run("DELETE FROM frontier_vehicle_req_vehicles WHERE id = " .. id)
		VR.Vehicles[id] = nil
		MilBase.Notify(ply, "Vehicle removed.", "warn")
		VR.OpenAdminMenu(ply)
		return true
	end

	function VR.AddSpawn(ply, pos, ang, data)
		if not VR.CanStaffConfigure(ply) then return false end
		if not isvector(pos) then return false end
		ang = isangle(ang) and ang or angle_zero
		data = sanitizeSpawn(data)
		MilBase.DB.Insert(string.format(
			"INSERT INTO frontier_vehicle_req_spawns (map, name, pos, ang, vehicles, factions, certs, require_all, min_rank, max_rank, rank_groups, active) VALUES (%s, %s, %s, %s, %s, %s, %s, %d, %d, %d, %s, %d)",
			MilBase.SQLStr(game.GetMap()), sqlText(data.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), sqlText(data.vehicles), sqlText(data.factions), sqlText(data.certs), data.requireAll, data.minRank, data.maxRank, sqlText(data.rankGroups), data.active
		), function(id)
			if not id then if IsValid(ply) then MilBase.Notify(ply, "Vehicle spawn could not be saved.", "danger") end return end
			data.id = tonumber(id)
			data.map = game.GetMap()
			data.pos = pos
			data.ang = ang
			VR.Spawns[data.id] = data
			if IsValid(ply) then MilBase.Notify(ply, "Vehicle spawn added: " .. data.name .. ".", "ok") end
		end)
		return true
	end

	function VR.UpdateNearestSpawn(ply, pos, ang, data)
		if not VR.CanStaffConfigure(ply) or not isvector(pos) then return false end
		local spawn = VR.NearestSpawn(pos, 300)
		if not spawn then MilBase.Notify(ply, "No vehicle spawn close enough to update.", "warn") return false end
		return VR.UpdateSpawn(ply, spawn.id, data, pos, ang)
	end

	function VR.UpdateSpawn(ply, id, data, pos, ang)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		local spawn = VR.Spawns[id]
		if not spawn then MilBase.Notify(ply, "Vehicle spawn not found.", "warn") return false end
		data = sanitizeSpawn(data)
		pos = isvector(pos) and pos or spawn.pos
		ang = isangle(ang) and ang or spawn.ang
		MilBase.DB.Run(string.format(
			"UPDATE frontier_vehicle_req_spawns SET name = %s, pos = %s, ang = %s, vehicles = %s, factions = %s, certs = %s, require_all = %d, min_rank = %d, max_rank = %d, rank_groups = %s, active = %d WHERE id = %d AND map = %s",
			sqlText(data.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), sqlText(data.vehicles), sqlText(data.factions), sqlText(data.certs), data.requireAll, data.minRank, data.maxRank, sqlText(data.rankGroups), data.active, id, MilBase.SQLStr(game.GetMap())
		))
		for k, v in pairs(data) do spawn[k] = v end
		spawn.pos = pos
		spawn.ang = ang
		MilBase.Notify(ply, "Vehicle spawn updated: " .. data.name .. ".", "ok")
		VR.OpenAdminMenu(ply)
		return true
	end

	function VR.RemoveNearestSpawn(ply, pos, radius)
		if not VR.CanStaffConfigure(ply) then return false end
		local spawn = VR.NearestSpawn(pos, radius or 300)
		if not spawn then MilBase.Notify(ply, "No vehicle spawn close enough to remove.", "warn") return false end
		return VR.DeleteSpawn(ply, spawn.id)
	end

	function VR.DeleteSpawn(ply, id)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		if not VR.Spawns[id] then MilBase.Notify(ply, "Vehicle spawn not found.", "warn") return false end
		MilBase.DB.Run("DELETE FROM frontier_vehicle_req_spawns WHERE id = " .. id .. " AND map = " .. MilBase.SQLStr(game.GetMap()))
		VR.Spawns[id] = nil
		MilBase.Notify(ply, "Vehicle spawn removed.", "warn")
		VR.OpenAdminMenu(ply)
		return true
	end

	local function sanitizeTerminal(data)
		data = istable(data) and data or {}
		return {
			name = trim(data.name) ~= "" and trim(data.name) or "Vehicle Requisition Console",
			active = data.active == false and 0 or 1,
		}
	end

	function VR.AddTerminal(ply, pos, ang, data)
		if not VR.CanStaffConfigure(ply) then return false end
		if not isvector(pos) then return false end
		ang = isangle(ang) and ang or angle_zero
		data = sanitizeTerminal(data)
		MilBase.DB.Insert(string.format(
			"INSERT INTO frontier_vehicle_req_terminals (map, name, pos, ang, active) VALUES (%s, %s, %s, %s, %d)",
			MilBase.SQLStr(game.GetMap()), sqlText(data.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), data.active
		), function(id)
			if not id then if IsValid(ply) then MilBase.Notify(ply, "Vehicle requisition console could not be saved.", "danger") end return end
			data.id = tonumber(id)
			data.map = game.GetMap()
			data.pos = pos
			data.ang = ang
			VR.Terminals[data.id] = data
			VR.SpawnTerminalEntity(data)
			if IsValid(ply) then MilBase.Notify(ply, "Vehicle requisition console added: " .. data.name .. ".", "ok") end
		end)
		return true
	end

	function VR.UpdateNearestTerminal(ply, pos, ang, data)
		if not VR.CanStaffConfigure(ply) or not isvector(pos) then return false end
		local terminal = VR.NearestTerminal(pos, 300)
		if not terminal then MilBase.Notify(ply, "No vehicle requisition console close enough to update.", "warn") return false end
		return VR.UpdateTerminal(ply, terminal.id, data, pos, ang)
	end

	function VR.UpdateTerminal(ply, id, data, pos, ang)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		local terminal = VR.Terminals and VR.Terminals[id]
		if not terminal then MilBase.Notify(ply, "Vehicle requisition console not found.", "warn") return false end
		data = sanitizeTerminal(data)
		pos = isvector(pos) and pos or terminal.pos
		ang = isangle(ang) and ang or terminal.ang
		MilBase.DB.Run(string.format(
			"UPDATE frontier_vehicle_req_terminals SET name = %s, pos = %s, ang = %s, active = %d WHERE id = %d AND map = %s",
			sqlText(data.name), MilBase.SQLStr(util.TypeToString(pos)), MilBase.SQLStr(util.TypeToString(ang)), data.active, id, MilBase.SQLStr(game.GetMap())
		))
		if IsValid(terminal.ent) then terminal.ent:Remove() end
		terminal.ent = nil
		for k, v in pairs(data) do terminal[k] = v end
		terminal.pos = pos
		terminal.ang = ang
		VR.SpawnTerminalEntity(terminal)
		MilBase.Notify(ply, "Vehicle requisition console updated: " .. data.name .. ".", "ok")
		return true
	end

	function VR.RemoveNearestTerminal(ply, pos, radius)
		if not VR.CanStaffConfigure(ply) then return false end
		local terminal = VR.NearestTerminal(pos, radius or 300)
		if not terminal then MilBase.Notify(ply, "No vehicle requisition console close enough to remove.", "warn") return false end
		return VR.DeleteTerminal(ply, terminal.id)
	end

	function VR.DeleteTerminal(ply, id)
		if not VR.CanStaffConfigure(ply) then return false end
		id = tonumber(id or 0) or 0
		local terminal = VR.Terminals and VR.Terminals[id]
		if not terminal then MilBase.Notify(ply, "Vehicle requisition console not found.", "warn") return false end
		MilBase.DB.Run("DELETE FROM frontier_vehicle_req_terminals WHERE id = " .. id .. " AND map = " .. MilBase.SQLStr(game.GetMap()))
		if IsValid(terminal.ent) then terminal.ent:Remove() end
		VR.Terminals[id] = nil
		MilBase.Notify(ply, "Vehicle requisition console removed.", "warn")
		return true
	end

	function VR.SaveSettings(ply, data)
		if not VR.CanStaffConfigure(ply) then return false end
		data = istable(data) and data or {}
		local allowed = {
			od_priority_factions = true,
			od_allowed_factions = true,
			od_rank_groups = true,
			request_cooldown = true,
			staff_level = true,
			pad_clear_radius = true,
			pad_clear_height = true,
			world_hull_check = true,
		}
		for key in pairs(allowed) do
			local value = trim(data[key] or VR.DefaultSettings[key] or "")
			if key == "request_cooldown" then value = tostring(math.max(0, tonumber(value) or 0)) end
			if key == "staff_level" then value = tostring(math.Clamp(math.floor(tonumber(value) or 3), 0, 99)) end
			if key == "pad_clear_radius" then value = tostring(math.Clamp(math.floor(tonumber(value) or 80), 16, 4096)) end
			if key == "pad_clear_height" then value = tostring(math.Clamp(math.floor(tonumber(value) or 96), 16, 4096)) end
			if key == "world_hull_check" then value = (value == true or value == "1" or lower(value) == "true" or lower(value) == "yes") and "1" or "0" end
			VR.Settings[key] = value
			MilBase.DB.Run(string.format("REPLACE INTO frontier_vehicle_req_settings (setting_key, setting_value) VALUES (%s, %s)", MilBase.SQLStr(key), MilBase.SQLStr(value)))
		end
		cfg.VehicleReqStaffLevel = tonumber(VR.Settings.staff_level or 3) or 3
		cfg.VehicleReqPadClearRadius = tonumber(VR.Settings.pad_clear_radius or cfg.VehicleReqPadClearRadius or 80) or 80
		cfg.VehicleReqPadClearHeight = tonumber(VR.Settings.pad_clear_height or cfg.VehicleReqPadClearHeight or 96) or 96
		cfg.VehicleReqUseWorldHullCheck = tostring(VR.Settings.world_hull_check or "0") == "1"
		MilBase.Notify(ply, "Vehicle requisition settings saved.", "ok")
		VR.OpenAdminMenu(ply)
		return true
	end

	local function toPublicVehicle(ply, vehicle)
		local allowed, reason = VR.CanUseVehicle(ply, vehicle)
		local cost = MilBase.Naval and MilBase.Naval.GetVehicleCost
			and MilBase.Naval.GetVehicleCost(vehicle) or {}
		if allowed and MilBase.Naval and MilBase.Naval.CanAfford then
			local affordable, missing = MilBase.Naval.CanAfford(cost)
			if not affordable then
				allowed = false
				reason = "Insufficient " .. string.lower(tostring(missing or "ship stores"))
			end
		end
		return {
			id = vehicle.id,
			name = vehicle.name,
			entityClass = vehicle.entityClass,
			category = vehicle.category,
			allowed = allowed,
			reason = allowed and "Available" or reason,
			access = VR.AccessText(vehicle, "vehicle"),
			cost = cost,
			costText = MilBase.Naval and MilBase.Naval.FormatCost
				and MilBase.Naval.FormatCost(cost, true) or "",
		}
	end

	local function toPublicSpawn(ply, spawn, vehicle)
		local allowed, reason = VR.CanUseSpawn(ply, spawn, vehicle)
		return {
			id = spawn.id,
			name = spawn.name,
			vehicles = spawn.vehicles,
			allowed = allowed,
			reason = allowed and "Available" or reason,
			access = VR.AccessText(spawn, "spawn"),
		}
	end

	function VR.BuildTerminalData(ply)
		local vehicles = {}
		for _, vehicle in pairs(VR.Vehicles or {}) do
			if tonumber(vehicle.active or 1) == 1 then vehicles[#vehicles + 1] = toPublicVehicle(ply, vehicle) end
		end
		table.sort(vehicles, function(a, b)
			if a.allowed ~= b.allowed then return a.allowed end
			return lower(a.category .. a.name) < lower(b.category .. b.name)
		end)

		local spawns = {}
		for _, spawn in pairs(VR.Spawns or {}) do
			if tonumber(spawn.active or 1) == 1 then spawns[#spawns + 1] = toPublicSpawn(ply, spawn, nil) end
		end
		table.sort(spawns, function(a, b)
			if a.allowed ~= b.allowed then return a.allowed end
			return lower(a.name) < lower(b.name)
		end)

		local od = VR.GetOD()
		return {
			odName = IsValid(od) and od:MBName() or "No active OD",
			hasOD = IsValid(od),
			vehicles = vehicles,
			spawns = spawns,
			resources = MilBase.Naval and MilBase.Naval.State
				and table.Copy(MilBase.Naval.State.resources) or {},
		}
	end

	function VR.OpenTerminal(ply, ent)
		if not IsValid(ply) or not ply:IsPlayer() then return end
		if IsValid(ent) and ply:GetPos():DistToSqr(ent:GetPos()) > (cfg.VehicleReqTerminalRange or 170) ^ 2 then return end
		net.Start(NET_TERMINAL_OPEN)
			net.WriteTable(VR.BuildTerminalData(ply))
		net.Send(ply)
	end

	local function getCertNames(ply)
		local out = {}
		for _, id in ipairs(ply:MBCertList()) do
			local cert = MilBase.Certs and MilBase.Certs[id]
			out[#out + 1] = (cert and cert.name or id)
		end
		return table.concat(out, ", ")
	end

	function VR.SubmitRequest(ply, vehicleID, spawnID, reason)
		local od = VR.GetOD()
		if not IsValid(od) then MilBase.Notify(ply, "No Officer of the Deck is active.", "warn") return false end

		if (ply.mb_vreq_next or 0) > CurTime() then
			MilBase.Notify(ply, "Please wait before submitting another vehicle request.", "warn")
			return false
		end

		for _, req in pairs(VR.Requests or {}) do
			if req.requester == ply then MilBase.Notify(ply, "You already have a pending vehicle request.", "warn") return false end
		end

		local vehicle = VR.GetVehicle(vehicleID)
		local spawn = VR.GetSpawn(spawnID)
		local ok, err = VR.CanUseVehicle(ply, vehicle)
		if not ok then MilBase.Notify(ply, "Vehicle denied: " .. tostring(err), "warn") return false end
		if MilBase.Naval and MilBase.Naval.GetVehicleCost and MilBase.Naval.CanAfford then
			local affordable, missing = MilBase.Naval.CanAfford(MilBase.Naval.GetVehicleCost(vehicle))
			if not affordable then
				MilBase.Notify(ply, "Vehicle denied: insufficient "
					.. string.lower(tostring(missing or "ship stores")) .. ".", "warn")
				return false
			end
		end
		ok, err = VR.CanUseSpawn(ply, spawn, vehicle)
		if not ok then MilBase.Notify(ply, "Spawn denied: " .. tostring(err), "warn") return false end

		reason = string.sub(trim(reason), 1, 220)
		if reason == "" then reason = "No reason provided." end

		local id = VR.NextRequestID
		VR.NextRequestID = id + 1
		VR.Requests[id] = {
			id = id,
			requester = ply,
			requesterSteamID = ply:SteamID64(),
			requesterName = ply:MBName(),
			faction = (ply:MBFaction() and ply:MBFaction().name) or ply:MBFactionID(),
			rank = (ply:MBRank() and ply:MBRank().name) or tostring(ply:MBRankIndex()),
			certs = getCertNames(ply),
			vehicleID = vehicle.id,
			vehicleName = vehicle.name,
			vehicleClass = vehicle.entityClass,
			costText = MilBase.Naval and MilBase.Naval.FormatCost and MilBase.Naval.GetVehicleCost
				and MilBase.Naval.FormatCost(MilBase.Naval.GetVehicleCost(vehicle), true) or "",
			spawnID = spawn.id,
			spawnName = spawn.name,
			reason = reason,
			created = os.time(),
		}

		ply.mb_vreq_next = CurTime() + VR.GetRequestCooldown()
		MilBase.Notify(ply, "Vehicle request submitted to OD.", "ok")
		if IsValid(od) then MilBase.Notify(od, "New vehicle request. Use /odmenu.", "warn") end
		return true
	end

	net.Receive(NET_SUBMIT, function(_, ply)
		local vehicleID = net.ReadUInt(32)
		local spawnID = net.ReadUInt(32)
		local reason = net.ReadString()
		VR.SubmitRequest(ply, vehicleID, spawnID, reason)
	end)

	local function requestToPublic(req)
		return {
			id = req.id,
			requesterName = req.requesterName,
			faction = req.faction,
			rank = req.rank,
			certs = req.certs ~= "" and req.certs or "None",
			vehicleName = req.vehicleName,
			vehicleClass = req.vehicleClass,
			costText = req.costText or "",
			spawnName = req.spawnName,
			reason = req.reason,
			created = req.created,
		}
	end

	function VR.OpenODMenu(ply)
		if VR.GetOD() ~= ply then MilBase.Notify(ply, "Only the active OD can open vehicle requests.", "warn") return end
		local requests = {}
		for _, req in pairs(VR.Requests or {}) do requests[#requests + 1] = requestToPublic(req) end
		table.sort(requests, function(a, b) return (a.created or 0) < (b.created or 0) end)
		net.Start(NET_OD_OPEN)
			net.WriteTable(requests)
		net.Send(ply)
	end

	local function entityLabel(ent)
		if not IsValid(ent) then return "unknown entity" end
		if ent:IsPlayer() then return ent:Nick() end
		return ent:GetClass() or "entity"
	end

	local function isVehicleLike(ent)
		if not IsValid(ent) then return false end
		if ent:IsVehicle() or ent.LVS or ent.LVSVehicle or ent.IsLVS or ent.SimfphysVehicle or ent.IsSimfphyscar then return true end

		local class = string.lower(ent:GetClass() or "")
		return string.StartWith(class, "lvs_")
			or class:find("simfphys", 1, true) ~= nil
			or string.StartWith(class, "wac_")
			or class:find("vehicle", 1, true) ~= nil
	end

	local function isPadBlocker(ent)
		if not IsValid(ent) or ent == game.GetWorld() then return false end

		local class = ent:GetClass() or ""
		if class == "worldspawn" or class == "mb_vehicle_requisition_terminal" then return false end
		if ent.MilBaseIgnoreVehicleReqBlocker then return false end
		if ent:GetSolid() == SOLID_NONE then return false end

		if ent:IsPlayer() then return ent:Alive() end
		if ent:IsNPC() or ent:IsNextBot() then return true end
		if isVehicleLike(ent) then return true end

		-- Only loose physics props block pads. The old check blocked almost every entity in the box,
		-- including map helpers and nearby scripted entities, which caused false "pad blocked" errors.
		local lowerClass = string.lower(class)
		if string.StartWith(lowerClass, "prop_physics") then return true end

		return false
	end

	local function spawnClear(spawn)
		local pos = spawn.pos or vector_origin
		local radius = tonumber(VR.GetSetting("pad_clear_radius", cfg.VehicleReqPadClearRadius or 80)) or 80
		local height = tonumber(VR.GetSetting("pad_clear_height", cfg.VehicleReqPadClearHeight or 96)) or 96
		local mins = Vector(-radius, -radius, 4)
		local maxs = Vector(radius, radius, height)

		-- Optional world hull check. Disabled by default because hangars/ships often use map entities,
		-- curved floors, or low ceilings that make a large hull trace report blocked even when the pad is usable.
		local useWorldHull = tostring(VR.GetSetting("world_hull_check", cfg.VehicleReqUseWorldHullCheck and "1" or "0")) == "1"
		if useWorldHull then
			local tr = util.TraceHull({
				start = pos + Vector(0, 0, 8),
				endpos = pos + Vector(0, 0, 8),
				mins = mins,
				maxs = maxs,
				mask = MASK_SOLID_BRUSHONLY or MASK_SOLID,
			})
			if tr.Hit then return false, "world geometry" end
		end

		for _, ent in ipairs(ents.FindInBox(pos + mins, pos + maxs)) do
			if isPadBlocker(ent) then return false, entityLabel(ent) end
		end
		return true
	end

	function VR.DecideRequest(ply, id, accepted, note)
		if VR.GetOD() ~= ply then MilBase.Notify(ply, "Only the active OD can manage vehicle requests.", "warn") return false end
		id = tonumber(id or 0) or 0
		local req = VR.Requests[id]
		if not req then MilBase.Notify(ply, "Request not found.", "warn") VR.OpenODMenu(ply) return false end

		local requester = req.requester
		if not IsValid(requester) then
			VR.Requests[id] = nil
			MilBase.Notify(ply, "Requester is no longer online.", "warn")
			VR.OpenODMenu(ply)
			return false
		end

		if not accepted then
			VR.Requests[id] = nil
			MilBase.Notify(ply, "Request denied.", "warn")
			MilBase.Notify(requester, "Your vehicle request was denied" .. (trim(note) ~= "" and (": " .. trim(note)) or "."), "warn")
			VR.OpenODMenu(ply)
			return true
		end

		local vehicle = VR.GetVehicle(req.vehicleID)
		local spawn = VR.GetSpawn(req.spawnID)
		local ok, err = VR.CanUseVehicle(requester, vehicle)
		if not ok then MilBase.Notify(ply, "Cannot approve: " .. tostring(err), "warn") return false end
		ok, err = VR.CanUseSpawn(requester, spawn, vehicle)
		if not ok then MilBase.Notify(ply, "Cannot approve: " .. tostring(err), "warn") return false end
		local clear, blocker = spawnClear(spawn)
		if not clear then MilBase.Notify(ply, "Cannot approve: selected vehicle pad is blocked by " .. tostring(blocker or "something") .. ".", "warn") return false end

		local ent = ents.Create(vehicle.entityClass)
		if not IsValid(ent) then MilBase.Notify(ply, "Vehicle entity class is invalid: " .. tostring(vehicle.entityClass), "danger") return false end
		local allocation
		if MilBase.Naval and MilBase.Naval.ReserveVehicle then
			allocation, err = MilBase.Naval.ReserveVehicle(vehicle, requester, spawn)
			if not allocation then
				ent:Remove()
				MilBase.Notify(ply, "Cannot approve: " .. tostring(err or "insufficient ship stores") .. ".", "warn")
				return false
			end
		end
		local spawned, spawnError = pcall(function()
			ent:SetPos(spawn.pos + Vector(0, 0, 8))
			ent:SetAngles(spawn.ang or angle_zero)
			ent:Spawn()
			ent:Activate()
		end)
		if not spawned then
			if IsValid(ent) then ent:Remove() end
			if allocation and MilBase.Naval and MilBase.Naval.RefundVehicleAllocation then
				MilBase.Naval.RefundVehicleAllocation(allocation, 1, "Vehicle issue failed; stores restored.", ply)
			end
			MilBase.Notify(ply, "Vehicle failed to deploy: " .. tostring(spawnError) .. ". Stores were restored.", "danger")
			return false
		end
		if not IsValid(ent) then
			if allocation and MilBase.Naval and MilBase.Naval.RefundVehicleAllocation then
				MilBase.Naval.RefundVehicleAllocation(allocation, 1, "Vehicle issue failed; stores restored.", ply)
			end
			MilBase.Notify(ply, "Vehicle failed to deploy; stores were restored.", "danger")
			return false
		end
		if ent.SetCreator then ent:SetCreator(requester) end
		ent.MilBaseVehicleReq = true
		ent.MilBaseVehicleReqRequester = requester
		ent.MilBaseVehicleReqOD = ply
		if allocation and MilBase.Naval and MilBase.Naval.RegisterRequisitionedVehicle then
			MilBase.Naval.RegisterRequisitionedVehicle(ent, allocation)
		end

		VR.Requests[id] = nil
		MilBase.Notify(ply, "Request accepted. Vehicle spawned at " .. spawn.name .. ".", "ok")
		MilBase.Notify(requester, "Your vehicle request was accepted.", "ok")
		VR.OpenODMenu(ply)
		return true
	end

	net.Receive(NET_OD_DECIDE, function(_, ply)
		local id = net.ReadUInt(32)
		local accepted = net.ReadBool()
		local note = net.ReadString()
		VR.DecideRequest(ply, id, accepted, note)
	end)

	function VR.AdminData()
		local vehicles = {}
		for _, vehicle in pairs(VR.Vehicles or {}) do
			local copy = table.Copy(vehicle)
			copy.access = VR.AccessText(vehicle, "vehicle")
			vehicles[#vehicles + 1] = copy
		end
		table.sort(vehicles, function(a, b) return lower((a.category or "") .. (a.name or "")) < lower((b.category or "") .. (b.name or "")) end)

		local spawns = {}
		for _, spawn in pairs(VR.Spawns or {}) do
			local copy = table.Copy(spawn)
			copy.access = VR.AccessText(spawn, "spawn")
			spawns[#spawns + 1] = copy
		end
		table.sort(spawns, function(a, b) return lower(a.name or "") < lower(b.name or "") end)

		local terminals = {}
		for _, terminal in pairs(VR.Terminals or {}) do
			local copy = table.Copy(terminal)
			copy.ent = nil
			terminals[#terminals + 1] = copy
		end
		table.sort(terminals, function(a, b) return lower(a.name or "") < lower(b.name or "") end)

		return { settings = table.Copy(VR.Settings or VR.DefaultSettings), vehicles = vehicles, spawns = spawns, terminals = terminals }
	end

	function VR.OpenAdminMenu(ply)
		if not VR.CanStaffConfigure(ply) then MilBase.Notify(ply, "Staff only.", "warn") return end
		net.Start(NET_ADMIN_OPEN)
			net.WriteTable(VR.AdminData())
		net.Send(ply)
	end

	net.Receive(NET_ADMIN_ACTION, function(_, ply)
		if not VR.CanStaffConfigure(ply) then return end
		local action = net.ReadString()
		local data = net.ReadTable() or {}
		if action == "settings" then
			VR.SaveSettings(ply, data)
		elseif action == "vehicle_add" then
			VR.AddVehicle(ply, data)
		elseif action == "vehicle_update" then
			VR.UpdateVehicle(ply, data.id, data)
		elseif action == "vehicle_delete" then
			VR.DeleteVehicle(ply, data.id)
		elseif action == "spawn_update" then
			VR.UpdateSpawn(ply, data.id, data)
		elseif action == "spawn_delete" then
			VR.DeleteSpawn(ply, data.id)
		elseif action == "terminal_update" then
			VR.UpdateTerminal(ply, data.id, data)
		elseif action == "terminal_delete" then
			VR.DeleteTerminal(ply, data.id)
		elseif action == "reload" then
			VR.ReloadAll(function() if IsValid(ply) then MilBase.Notify(ply, "Vehicle requisition data reloaded.", "ok") VR.OpenAdminMenu(ply) end end)
		end
	end)

	concommand.Add("mb_vehicle_req_config", function(ply)
		if IsValid(ply) then VR.OpenAdminMenu(ply) end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: UI
--------------------------------------------------------------------------

local function ui()
	return (MilBase and MilBase.UI) or {
		bg = Color(6, 6, 7, 240), panel = Color(10, 10, 11, 218), raised = Color(255, 198, 60, 10),
		hover = Color(255, 198, 60, 25), outline = Color(255, 198, 60, 50), accent = Color(255, 198, 60),
		text = Color(240, 238, 230), dim = Color(170, 162, 140), faint = Color(112, 106, 92), ok = Color(150, 205, 125), danger = Color(220, 80, 70), warn = Color(255, 215, 135),
	}
end

local function drawPanel(x, y, w, h, opts)
	if MilBase and MilBase.DrawPanelBF2 then
		MilBase.DrawPanelBF2(x, y, w, h, opts)
	else
		surface.SetDrawColor((opts and opts.color) or ui().panel)
		surface.DrawRect(x, y, w, h)
		surface.SetDrawColor((opts and opts.outlineColor) or ui().outline)
		surface.DrawOutlinedRect(x, y, w, h)
	end
end

local function play(id)
	if MilBase and MilBase.PlayUISound then MilBase.PlayUISound(id) end
end

local function font(name, fallback)
	return (MilBase and MilBase.UI and name) or fallback or "DermaDefault"
end

local function styledButton(parent, text, color, click)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.DoClick = function()
		play("select")
		if click then click(b) end
	end
	b.Paint = function(self, w, h)
		local c = color or ui().accent
		drawPanel(0, 0, w, h, { cut = 8, color = self:IsHovered() and Color(c.r, c.g, c.b, 42) or ui().raised, accent = c })
		draw.SimpleText(text, font("MB.Tab", "DermaDefaultBold"), w / 2, h / 2, ui().text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return b
end

local function selectedLine(list)
	local line = list:GetSelectedLine()
	if not line then return nil end
	return list:GetLine(line)
end

local terminalFrame
function VR.OpenTerminalUI(data)
	data = data or {}
	if IsValid(terminalFrame) then terminalFrame:Remove() end
	local U = ui()

	local vehicles = data.vehicles or {}
	local spawns = data.spawns or {}
	local selectedVehicleID = 0

	terminalFrame = vgui.Create("DFrame")
	terminalFrame:SetSize(math.min(760, ScrW() - 80), math.min(560, ScrH() - 80))
	terminalFrame:Center()
	terminalFrame:SetTitle("")
	terminalFrame:MakePopup()
	terminalFrame:ShowCloseButton(false)
	terminalFrame.Paint = function(self, w, h)
		if MilBase and MilBase.DrawBlur then MilBase.DrawBlur(self, 5) end
		drawPanel(0, 0, w, h, { cut = 12, color = Color(6, 6, 7, 235), accent = U.accent })
		draw.SimpleText(string.upper(tostring(data.terminalName or "VEHICLE REQUISITION")), font("MB.Title", "DermaLarge"), 24, 18, U.text)
		draw.SimpleText("Current OD: " .. tostring(data.odName or "None"), font("MB.Small", "DermaDefaultBold"), 26, 70, data.hasOD and U.ok or U.warn)
		if MilBase.Naval and MilBase.Naval.FormatCost then
			draw.SimpleText("SHIP STORES  " .. MilBase.Naval.FormatCost(data.resources or {}, true),
				font("MB.Tiny", "DermaDefault"), 26, 92, U.dim)
		end
	end

	local close = styledButton(terminalFrame, "CLOSE", U.danger, function() terminalFrame:Remove() end)
	close:SetSize(110, 34); close:SetPos(terminalFrame:GetWide() - 130, 24)

	local vehLabel = vgui.Create("DLabel", terminalFrame)
	vehLabel:SetText("VEHICLE")
	vehLabel:SetFont(font("MB.Small", "DermaDefaultBold")); vehLabel:SetTextColor(U.accent)
	vehLabel:SetPos(28, 110); vehLabel:SetSize(300, 22)

	local vehicleCombo = vgui.Create("DComboBox", terminalFrame)
	vehicleCombo:SetPos(28, 136); vehicleCombo:SetSize(330, 28)
	vehicleCombo:SetValue("Select vehicle...")
	for _, v in ipairs(vehicles) do
		vehicleCombo:AddChoice((v.allowed and "" or "[LOCKED] ") .. (v.name or "Vehicle")
			.. "  [" .. (v.category or "General") .. "]"
			.. (v.costText ~= "" and ("  — " .. v.costText) or ""), v.id)
	end

	local vehInfo = vgui.Create("DLabel", terminalFrame)
	vehInfo:SetPos(28, 170); vehInfo:SetSize(330, 72); vehInfo:SetWrap(true); vehInfo:SetTextColor(U.dim); vehInfo:SetFont(font("MB.Tiny", "DermaDefault"))
	vehInfo:SetText(tostring(data.terminalHelp or "Pick a vehicle. Locked vehicles are shown for visibility but cannot be requested."))

	local spawnLabel = vgui.Create("DLabel", terminalFrame)
	spawnLabel:SetText("SPAWN")
	spawnLabel:SetFont(font("MB.Small", "DermaDefaultBold")); spawnLabel:SetTextColor(U.accent)
	spawnLabel:SetPos(390, 110); spawnLabel:SetSize(300, 22)

	local spawnCombo = vgui.Create("DComboBox", terminalFrame)
	spawnCombo:SetPos(390, 136); spawnCombo:SetSize(330, 28)
	spawnCombo:SetValue("Select spawn...")

	local spawnInfo = vgui.Create("DLabel", terminalFrame)
	spawnInfo:SetPos(390, 170); spawnInfo:SetSize(330, 72); spawnInfo:SetWrap(true); spawnInfo:SetTextColor(U.dim); spawnInfo:SetFont(font("MB.Tiny", "DermaDefault"))
	spawnInfo:SetText("Pick a vehicle first, then choose a matching vehicle pad.")

	local selectedSpawnID = 0
	local function vehicleByID(id)
		for _, v in ipairs(vehicles) do if tonumber(v.id) == tonumber(id) then return v end end
	end
	local function spawnAllowsVehicle(sp, veh)
		if not veh then return false end
		if trim(sp.vehicles or "") == "" then return true end
		return listHas(sp.vehicles, { tostring(veh.id or ""), veh.name or "", veh.entityClass or "", veh.category or "" })
	end
	local function refillSpawns()
		spawnCombo:Clear()
		spawnCombo:SetValue("Select spawn...")
		selectedSpawnID = 0
		local veh = vehicleByID(selectedVehicleID)
		for _, sp in ipairs(spawns) do
			local allowed = sp.allowed == true and spawnAllowsVehicle(sp, veh)
			spawnCombo:AddChoice((allowed and "" or "[LOCKED] ") .. (sp.name or "Spawn"), sp.id)
		end
	end

	vehicleCombo.OnSelect = function(_, _, _, value)
		selectedVehicleID = tonumber(value or 0) or 0
		local veh = vehicleByID(selectedVehicleID)
		vehInfo:SetText(veh and ((veh.allowed and "Available" or ("Locked: " .. tostring(veh.reason)))
			.. (veh.costText ~= "" and ("\nIssue cost: " .. veh.costText) or "")
			.. "\n" .. (veh.access or "")) or "")
		refillSpawns()
	end
	spawnCombo.OnSelect = function(_, _, _, value)
		selectedSpawnID = tonumber(value or 0) or 0
		for _, sp in ipairs(spawns) do
			if tonumber(sp.id) == selectedSpawnID then
				spawnInfo:SetText(((sp.allowed and "Available" or ("Locked: " .. tostring(sp.reason))) .. "\n" .. (sp.access or "")))
				break
			end
		end
	end

	local reasonLabel = vgui.Create("DLabel", terminalFrame)
	reasonLabel:SetText("REASON / MISSION NOTE")
	reasonLabel:SetFont(font("MB.Small", "DermaDefaultBold")); reasonLabel:SetTextColor(U.accent)
	reasonLabel:SetPos(28, 255); reasonLabel:SetSize(400, 22)

	local reason = vgui.Create("DTextEntry", terminalFrame)
	reason:SetPos(28, 282); reason:SetSize(692, 125); reason:SetMultiline(true)
	reason:SetPlaceholderText("Example: Transporting engineers to Main Gate repair objective.")

	local submit = styledButton(terminalFrame, "SUBMIT REQUEST", U.ok, function()
		if not data.hasOD then MilBase.Notify("No OD is active.") return end
		if selectedVehicleID <= 0 or selectedSpawnID <= 0 then MilBase.Notify("Select a vehicle and spawn.") return end
		net.Start(NET_SUBMIT)
			net.WriteUInt(selectedVehicleID, 32)
			net.WriteUInt(selectedSpawnID, 32)
			net.WriteString(string.sub(reason:GetValue() or "", 1, 220))
		net.SendToServer()
		terminalFrame:Remove()
	end)
	submit:SetSize(210, 40); submit:SetPos(terminalFrame:GetWide() - 238, terminalFrame:GetTall() - 64)
end

net.Receive(NET_TERMINAL_OPEN, function()
	VR.OpenTerminalUI(net.ReadTable() or {})
end)

local odFrame
function VR.OpenODUI(requests)
	requests = requests or {}
	if IsValid(odFrame) then odFrame:Remove() end
	local U = ui()

	odFrame = vgui.Create("DFrame")
	odFrame:SetSize(math.min(900, ScrW() - 80), math.min(620, ScrH() - 80))
	odFrame:Center()
	odFrame:SetTitle("")
	odFrame:MakePopup()
	odFrame:ShowCloseButton(false)
	odFrame.Paint = function(self, w, h)
		if MilBase and MilBase.DrawBlur then MilBase.DrawBlur(self, 5) end
		drawPanel(0, 0, w, h, { cut = 12, color = Color(6, 6, 7, 238), accent = U.accent })
		draw.SimpleText("OFFICER OF THE DECK", font("MB.Title", "DermaLarge"), 24, 18, U.text)
		draw.SimpleText("VEHICLE REQUESTS", font("MB.Small", "DermaDefaultBold"), 26, 72, U.accent)
	end

	local close = styledButton(odFrame, "CLOSE", U.danger, function() odFrame:Remove() end)
	close:SetSize(110, 34); close:SetPos(odFrame:GetWide() - 130, 24)

	local list = vgui.Create("DListView", odFrame)
	list:SetPos(24, 110); list:SetSize(380, odFrame:GetTall() - 138)
	list:AddColumn("#"):SetFixedWidth(40)
	list:AddColumn("Requester")
	list:AddColumn("Vehicle")
	for _, req in ipairs(requests) do
		local line = list:AddLine(req.id, req.requesterName or "Unknown", req.vehicleName or "Vehicle")
		line.Req = req
	end

	local detail = vgui.Create("DLabel", odFrame)
	detail:SetPos(430, 114); detail:SetSize(430, 300); detail:SetWrap(true); detail:SetFont(font("MB.Small", "DermaDefault")); detail:SetTextColor(U.text)
	detail:SetText("Select a request.")

	local note = vgui.Create("DTextEntry", odFrame)
	note:SetPos(430, odFrame:GetTall() - 145); note:SetSize(430, 42); note:SetPlaceholderText("Optional denial reason")

	local selectedID = 0
	list.OnRowSelected = function(_, _, line)
		local r = line.Req or {}
		selectedID = tonumber(r.id or 0) or 0
		detail:SetText("Requester: " .. tostring(r.requesterName) .. "\nFaction: " .. tostring(r.faction) .. "\nRank: " .. tostring(r.rank) .. "\nCerts: " .. tostring(r.certs) .. "\n\nVehicle: " .. tostring(r.vehicleName) .. "\nClass: " .. tostring(r.vehicleClass) .. "\nIssue cost: " .. tostring(r.costText ~= "" and r.costText or "No naval cost") .. "\nSpawn: " .. tostring(r.spawnName) .. "\n\nReason:\n" .. tostring(r.reason))
	end

	local accept = styledButton(odFrame, "ACCEPT", U.ok, function()
		if selectedID <= 0 then MilBase.Notify("Select a request.") return end
		net.Start(NET_OD_DECIDE)
			net.WriteUInt(selectedID, 32)
			net.WriteBool(true)
			net.WriteString("")
		net.SendToServer()
	end)
	accept:SetSize(130, 40); accept:SetPos(430, odFrame:GetTall() - 82)

	local deny = styledButton(odFrame, "DENY", U.warn, function()
		if selectedID <= 0 then MilBase.Notify("Select a request.") return end
		net.Start(NET_OD_DECIDE)
			net.WriteUInt(selectedID, 32)
			net.WriteBool(false)
			net.WriteString(string.sub(note:GetValue() or "", 1, 140))
		net.SendToServer()
	end)
	deny:SetSize(130, 40); deny:SetPos(570, odFrame:GetTall() - 82)
end

net.Receive(NET_OD_OPEN, function()
	VR.OpenODUI(net.ReadTable() or {})
end)

local function writeAdmin(action, data)
	net.Start(NET_ADMIN_ACTION)
		net.WriteString(action)
		net.WriteTable(data or {})
	net.SendToServer()
end

local adminFrame
local function addLabel(parent, text, x, y, w)
	local l = vgui.Create("DLabel", parent)
	l:SetText(text); l:SetFont(font("MB.Tiny", "DermaDefaultBold")); l:SetTextColor(ui().accent)
	l:SetPos(x, y); l:SetSize(w or 160, 18)
	return l
end

local function addEntry(parent, x, y, w, value)
	local e = vgui.Create("DTextEntry", parent)
	e:SetPos(x, y); e:SetSize(w, 24); e:SetText(tostring(value or ""))
	return e
end

local function addCheck(parent, text, x, y, checked)
	local c = vgui.Create("DCheckBoxLabel", parent)
	c:SetText(text); c:SetTextColor(ui().text); c:SetPos(x, y); c:SetValue(checked and 1 or 0); c:SizeToContents()
	return c
end

function VR.OpenAdminUI(data)
	data = data or {}
	if IsValid(adminFrame) then adminFrame:Remove() end
	local U = ui()
	adminFrame = vgui.Create("DFrame")
	adminFrame:SetSize(math.min(980, ScrW() - 80), math.min(680, ScrH() - 80))
	adminFrame:Center(); adminFrame:SetTitle(""); adminFrame:MakePopup(); adminFrame:ShowCloseButton(false)
	adminFrame.Paint = function(self, w, h)
		if MilBase and MilBase.DrawBlur then MilBase.DrawBlur(self, 4) end
		drawPanel(0, 0, w, h, { cut = 12, color = Color(6, 6, 7, 238), accent = U.accent })
		draw.SimpleText("VEHICLE REQUISITION CONFIG", font("MB.Title", "DermaLarge"), 24, 18, U.text)
	end
	local close = styledButton(adminFrame, "CLOSE", U.danger, function() adminFrame:Remove() end)
	close:SetSize(110, 34); close:SetPos(adminFrame:GetWide() - 130, 24)

	local sheet = vgui.Create("DPropertySheet", adminFrame)
	sheet:SetPos(22, 88); sheet:SetSize(adminFrame:GetWide() - 44, adminFrame:GetTall() - 110)

	-- Settings tab
	local settings = vgui.Create("DPanel", sheet); settings.Paint = nil
	local s = data.settings or {}
	addLabel(settings, "Navy / priority factions", 20, 20, 220)
	local odPriority = addEntry(settings, 20, 42, 400, s.od_priority_factions or "Republic Navy")
	addLabel(settings, "Allowed non-priority factions (blank = any officer faction)", 20, 78, 420)
	local odAllowed = addEntry(settings, 20, 100, 400, s.od_allowed_factions or "")
	addLabel(settings, "Officer rank groups allowed to take OD", 20, 136, 340)
	local odGroups = addEntry(settings, 20, 158, 400, s.od_rank_groups or "officer,commander")
	addLabel(settings, "Request cooldown seconds", 20, 194, 220)
	local cooldown = addEntry(settings, 20, 216, 120, s.request_cooldown or "8")
	addLabel(settings, "Staff config level", 170, 194, 220)
	local staffLevel = addEntry(settings, 170, 216, 120, s.staff_level or "3")
	addLabel(settings, "Pad clear radius", 20, 252, 160)
	local padRadius = addEntry(settings, 20, 274, 120, s.pad_clear_radius or "80")
	addLabel(settings, "Pad clear height", 170, 252, 160)
	local padHeight = addEntry(settings, 170, 274, 120, s.pad_clear_height or "96")
	local worldHull = vgui.Create("DCheckBoxLabel", settings)
	worldHull:SetPos(320, 274); worldHull:SetText("Strict world hull check"); worldHull:SetTextColor(U.text); worldHull:SetValue(tostring(s.world_hull_check or "0") == "1" and 1 or 0); worldHull:SizeToContents()
	local saveSettings = styledButton(settings, "SAVE SETTINGS", U.ok, function()
		writeAdmin("settings", {
			od_priority_factions = odPriority:GetValue(),
			od_allowed_factions = odAllowed:GetValue(),
			od_rank_groups = odGroups:GetValue(),
			request_cooldown = cooldown:GetValue(),
			staff_level = staffLevel:GetValue(),
			pad_clear_radius = padRadius:GetValue(),
			pad_clear_height = padHeight:GetValue(),
			world_hull_check = worldHull:GetChecked() and "1" or "0",
		})
	end)
	saveSettings:SetPos(20, 330); saveSettings:SetSize(180, 38)
	sheet:AddSheet("Settings", settings, "icon16/cog.png")

	local function buildVehicleTab()
		local pnl = vgui.Create("DPanel", sheet); pnl.Paint = nil
		local list = vgui.Create("DListView", pnl)
		list:SetPos(12, 12); list:SetSize(420, sheet:GetTall() - 70)
		list:AddColumn("ID"):SetFixedWidth(42); list:AddColumn("Name"); list:AddColumn("Class")
		for _, v in ipairs(data.vehicles or {}) do
			local line = list:AddLine(v.id, v.name, v.entityClass)
			line.Data = v
		end
		local x = 455
		addLabel(pnl, "Name", x, 14); local name = addEntry(pnl, x, 36, 220, "")
		addLabel(pnl, "Entity class", x + 240, 14); local cls = addEntry(pnl, x + 240, 36, 220, "")
		addLabel(pnl, "Category", x, 70); local cat = addEntry(pnl, x, 92, 220, "General")
		addLabel(pnl, "Factions", x + 240, 70); local factions = addEntry(pnl, x + 240, 92, 220, "")
		addLabel(pnl, "Certs", x, 126); local certs = addEntry(pnl, x, 148, 220, "")
		addLabel(pnl, "Rank groups", x + 240, 126); local groups = addEntry(pnl, x + 240, 148, 220, "")
		addLabel(pnl, "Min rank", x, 182); local minRank = addEntry(pnl, x, 204, 90, "0")
		addLabel(pnl, "Max rank", x + 110, 182); local maxRank = addEntry(pnl, x + 110, 204, 90, "0")
		local requireAll = addCheck(pnl, "Require all listed certs", x + 225, 204, false)
		local active = addCheck(pnl, "Active", x + 225, 230, true)
		local selectedID = 0
		list.OnRowSelected = function(_, _, line)
			local v = line.Data or {}; selectedID = tonumber(v.id or 0) or 0
			name:SetText(v.name or ""); cls:SetText(v.entityClass or ""); cat:SetText(v.category or "General")
			factions:SetText(v.factions or ""); certs:SetText(v.certs or ""); groups:SetText(v.rankGroups or "")
			minRank:SetText(tostring(v.minRank or 0)); maxRank:SetText(tostring(v.maxRank or 0))
			requireAll:SetValue(tonumber(v.requireAll or 0) == 1 and 1 or 0); active:SetValue(tonumber(v.active or 1) == 1 and 1 or 0)
		end
		local function collect()
			return { id = selectedID, name = name:GetValue(), entityClass = cls:GetValue(), category = cat:GetValue(), factions = factions:GetValue(), certs = certs:GetValue(), rankGroups = groups:GetValue(), minRank = minRank:GetValue(), maxRank = maxRank:GetValue(), requireAll = requireAll:GetChecked(), active = active:GetChecked() }
		end
		local addBtn = styledButton(pnl, "ADD NEW", U.ok, function() local d = collect(); d.id = nil; writeAdmin("vehicle_add", d) end)
		addBtn:SetPos(x, 280); addBtn:SetSize(140, 36)
		local updateBtn = styledButton(pnl, "UPDATE", U.accent, function() if selectedID > 0 then writeAdmin("vehicle_update", collect()) else MilBase.Notify("Select a vehicle.") end end)
		updateBtn:SetPos(x + 150, 280); updateBtn:SetSize(140, 36)
		local delBtn = styledButton(pnl, "DELETE", U.danger, function() if selectedID > 0 then writeAdmin("vehicle_delete", { id = selectedID }) else MilBase.Notify("Select a vehicle.") end end)
		delBtn:SetPos(x + 300, 280); delBtn:SetSize(140, 36)
		return pnl
	end
	sheet:AddSheet("Vehicles", buildVehicleTab(), "icon16/car.png")

	local function buildSpawnTab()
		local pnl = vgui.Create("DPanel", sheet); pnl.Paint = nil
		local list = vgui.Create("DListView", pnl)
		list:SetPos(12, 12); list:SetSize(420, sheet:GetTall() - 70)
		list:AddColumn("ID"):SetFixedWidth(42); list:AddColumn("Name"); list:AddColumn("Vehicles")
		for _, sp in ipairs(data.spawns or {}) do
			local line = list:AddLine(sp.id, sp.name, sp.vehicles ~= "" and sp.vehicles or "Any")
			line.Data = sp
		end
		local x = 455
		addLabel(pnl, "Name", x, 14); local name = addEntry(pnl, x, 36, 220, "")
		addLabel(pnl, "Allowed vehicles", x + 240, 14); local vehicles = addEntry(pnl, x + 240, 36, 220, "")
		addLabel(pnl, "Factions", x, 70); local factions = addEntry(pnl, x, 92, 220, "")
		addLabel(pnl, "Certs", x + 240, 70); local certs = addEntry(pnl, x + 240, 92, 220, "")
		addLabel(pnl, "Rank groups", x, 126); local groups = addEntry(pnl, x, 148, 220, "")
		addLabel(pnl, "Min rank", x, 182); local minRank = addEntry(pnl, x, 204, 90, "0")
		addLabel(pnl, "Max rank", x + 110, 182); local maxRank = addEntry(pnl, x + 110, 204, 90, "0")
		local requireAll = addCheck(pnl, "Require all listed certs", x + 225, 204, false)
		local active = addCheck(pnl, "Active", x + 225, 230, true)
		local selectedID = 0
		list.OnRowSelected = function(_, _, line)
			local sp = line.Data or {}; selectedID = tonumber(sp.id or 0) or 0
			name:SetText(sp.name or ""); vehicles:SetText(sp.vehicles or ""); factions:SetText(sp.factions or "")
			certs:SetText(sp.certs or ""); groups:SetText(sp.rankGroups or "")
			minRank:SetText(tostring(sp.minRank or 0)); maxRank:SetText(tostring(sp.maxRank or 0))
			requireAll:SetValue(tonumber(sp.requireAll or 0) == 1 and 1 or 0); active:SetValue(tonumber(sp.active or 1) == 1 and 1 or 0)
		end
		local function collect()
			return { id = selectedID, name = name:GetValue(), vehicles = vehicles:GetValue(), factions = factions:GetValue(), certs = certs:GetValue(), rankGroups = groups:GetValue(), minRank = minRank:GetValue(), maxRank = maxRank:GetValue(), requireAll = requireAll:GetChecked(), active = active:GetChecked() }
		end
		local updateBtn = styledButton(pnl, "UPDATE", U.accent, function() if selectedID > 0 then writeAdmin("spawn_update", collect()) else MilBase.Notify("Select a spawn.") end end)
		updateBtn:SetPos(x, 280); updateBtn:SetSize(140, 36)
		local delBtn = styledButton(pnl, "DELETE", U.danger, function() if selectedID > 0 then writeAdmin("spawn_delete", { id = selectedID }) else MilBase.Notify("Select a spawn.") end end)
		delBtn:SetPos(x + 150, 280); delBtn:SetSize(140, 36)
		local reloadBtn = styledButton(pnl, "RELOAD", U.ok, function() writeAdmin("reload", {}) end)
		reloadBtn:SetPos(x + 300, 280); reloadBtn:SetSize(140, 36)
		local help = vgui.Create("DLabel", pnl)
		help:SetPos(x, 338); help:SetSize(460, 80); help:SetWrap(true); help:SetFont(font("MB.Tiny", "DermaDefault")); help:SetTextColor(U.dim)
		help:SetText("Place and move vehicle spawns with the Toolgun: Star Wars RP → Vehicle Requisition Spawn. This UI edits names and access rules only.")
		return pnl
	end
	sheet:AddSheet("Spawns", buildSpawnTab(), "icon16/world.png")
end

net.Receive(NET_ADMIN_OPEN, function()
	local data = net.ReadTable() or {}
	VR.Vehicles = data.vehicles or {}
	VR.Spawns = data.spawns or {}
	VR.OpenAdminUI(data)
end)
