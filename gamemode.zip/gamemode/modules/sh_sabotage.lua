--[[
	Sabotage system.

	A Saboteur (saboteur certification) can:
	  - SEE a ship's weak points - every hull-breach spot glows as a WEAK
	    POINT marker, even the dormant ones normal soldiers can't see.
	  - PLANT a Detonation Charge on a weak point: aim at it up close and
	    press [E] while carrying a charge.
	  - DETONATE all their planted charges from the self-menu (hold [G] ->
	    Detonate Charges), blowing the weak points open into hull breaches
	    for the enemy's engineers to deal with.

	Charges are visible entities (mb_charge) so defenders can spot them.
]]

local cfg = MilBase.Config

local function isSaboteur(ply)
	return ply:MBHasCert("saboteur") or ply:IsAdmin()
end

-- A valid charge target the player is aiming at, up close: an un-breached
-- hull weak point (mb_breach) or an intact engine/hyperdrive part (mb_shippart).
local function aimedWeakPoint(ply)
	local range = cfg.SabotagePlantRange or 100
	local best, bestDot
	for _, class in ipairs({ "mb_breach", "mb_shippart" }) do
		for _, ent in ipairs(ents.FindByClass(class)) do
			local ok = (class == "mb_breach" and not ent:GetBreached())
				or (class == "mb_shippart" and not ent:GetDestroyed())
			if ok and ent:GetPos():DistToSqr(ply:GetPos()) < range * range then
				local aim = ent:GetPos() - ply:EyePos()
				aim:Normalize()
				local dot = aim:Dot(ply:GetAimVector())
				if dot > 0.85 and (not bestDot or dot > bestDot) then
					best, bestDot = ent, dot
				end
			end
		end
	end
	return best
end

local function hasCharge_inv(inv)
	local pools = { inv.items }
	if inv.pack then pools[#pools + 1] = inv.pack.items end
	for _, pool in ipairs(pools) do
		for _, it in ipairs(pool) do
			local def = MilBase.Items[it.id]
			if def and def.type == "sabotage" then return true end
		end
	end
	return false
end

-- Self-menu action: detonate (visible once you have charges planted).
MilBase.RegisterSelfAction("detonate", {
	name = function(lp)
		return "Detonate Charges  (" .. lp:GetNWInt("mb_charges", 0) .. ")"
	end,
	order = 10,
	visible = function(lp) return lp:GetNWInt("mb_charges", 0) > 0 end,
	run = function(ply)
		if MilBase.DetonateCharges then MilBase.DetonateCharges(ply) end
	end,
})

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_PlantCharge")

	MilBase.Charges = MilBase.Charges or {}

	local function playerCharges(ply)
		local out = {}
		for i = #MilBase.Charges, 1, -1 do
			local c = MilBase.Charges[i]
			if not IsValid(c) then
				table.remove(MilBase.Charges, i)
			elseif c:GetPlanter() == ply then
				out[#out + 1] = c
			end
		end
		return out
	end

	net.Receive("MilBase_PlantCharge", function(_, ply)
		if not ply:Alive() or not isSaboteur(ply) then return end

		local target = net.ReadEntity()
		if not IsValid(target) then return end
		local class = target:GetClass()
		local valid = (class == "mb_breach" and not target:GetBreached())
			or (class == "mb_shippart" and not target:GetDestroyed())
		if not valid then return end

		local range = cfg.SabotagePlantRange or 100
		if target:GetPos():DistToSqr(ply:GetPos()) > range * range then return end
		if IsValid(target.mb_charge) then
			MilBase.Notify(ply, "There's already a charge on that target.")
			return
		end
		if not hasCharge_inv(MilBase.GetInventory(ply)) then
			MilBase.Notify(ply, "You have no charges to plant.")
			return
		end
		if #playerCharges(ply) >= (cfg.MaxChargesPerPlayer or 4) then
			MilBase.Notify(ply, "You've placed the maximum number of charges.")
			return
		end
		if (ply.mb_nextPlant or 0) > CurTime() then return end
		ply.mb_nextPlant = CurTime() + 1

		MilBase.TakeItem(ply, "det_charge", 1)

		local charge = ents.Create("mb_charge")
		if not IsValid(charge) then return end
		charge:SetPos(class == "mb_shippart" and target:LocalToWorld(target:OBBCenter())
			or target:GetPos())
		charge:SetAngles(target:GetAngles())
		charge:SetPlanter(ply)
		charge:Spawn()
		if class == "mb_shippart" then
			charge.mb_part = target
		else
			charge.mb_breach = target
		end
		target.mb_charge = charge
		table.insert(MilBase.Charges, charge)

		ply:SetNWInt("mb_charges", #playerCharges(ply))
		MilBase.Notify(ply, "Charge planted. Hold [G] to detonate.")
	end)

	-- Detonate all of the saboteur's charges (self-menu action).
	function MilBase.DetonateCharges(ply)
		local charges = playerCharges(ply)
		if #charges == 0 then
			MilBase.Notify(ply, "You have no charges planted.")
			return
		end

		for i, c in ipairs(charges) do
			-- Small stagger so multiple blasts ripple rather than stack.
			timer.Simple((i - 1) * 0.12, function()
				if IsValid(c) then c:Detonate() end
			end)
		end

		ply:SetNWInt("mb_charges", 0)
		MilBase.ChatMsg(nil, Color(220, 90, 70), "[SABOTAGE] ", color_white,
			ply:MBName() .. " detonated " .. #charges .. " charge(s)!")
	end

	hook.Add("PlayerDisconnected", "MilBase.SabotageCleanup", function(ply)
		for _, c in ipairs(MilBase.Charges) do
			if IsValid(c) and c:GetPlanter() == ply then c:Remove() end
		end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: weak-point vision, plant prompt, plant on [E]
--------------------------------------------------------------------------

function MilBase.HasCharge()
	return hasCharge_inv(MilBase.LocalInv)
end

hook.Add("HUDPaint", "MilBase.SabotageHUD", function()
	if MilBase.InEventView and MilBase.InEventView() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() or not isSaboteur(lp) then return end

	local ui = MilBase.UI
	local hasCharge = MilBase.HasCharge()
	local aimed = aimedWeakPoint(lp)
	local range = cfg.SabotagePlantRange or 100

	local function marker(ent, label, pos)
		local dist = lp:GetPos():Distance(pos)
		if dist > 700 then return end
		local screen = pos:ToScreen()
		if not screen.visible then return end

		MilBase.DrawDiamond(screen.x, screen.y, 6, ui.danger, true)
		draw.SimpleTextOutlined(label, "MB.Tiny", screen.x, screen.y - 14,
			ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

		if ent == aimed and dist < range then
			draw.SimpleTextOutlined(hasCharge and "[E] PLANT CHARGE" or "NO CHARGES",
				"MB.Tiny", screen.x, screen.y + 12, hasCharge and ui.accent or ui.faint,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end
	end

	-- Already-breached spots are drawn by the engineering module.
	for _, breach in ipairs(ents.FindByClass("mb_breach")) do
		if not breach:GetBreached() then marker(breach, "WEAK POINT", breach:GetPos()) end
	end
	for _, part in ipairs(ents.FindByClass("mb_shippart")) do
		if not part:GetDestroyed() then
			marker(part, "CRITICAL PART", part:LocalToWorld(part:OBBCenter()))
		end
	end
end)

-- Press [E] on a weak point (with a charge) to plant - consumes the use.
hook.Add("PlayerBindPress", "MilBase.SabotagePlant", function(ply, bind, pressed)
	if not pressed or not string.find(bind, "use", 1, true) then return end
	if not IsValid(ply) or not ply:Alive() or not isSaboteur(ply) then return end
	if not MilBase.HasCharge() then return end

	local target = aimedWeakPoint(ply)
	if not IsValid(target) then return end -- already filtered to valid targets

	net.Start("MilBase_PlantCharge")
		net.WriteEntity(target)
	net.SendToServer()
	return true -- don't also trigger a normal +use
end)
