if not CLIENT or MilBase._CinematicDialogueClientLoaded then return end
MilBase._CinematicDialogueClientLoaded = true

MilBase.CinematicDialogue = MilBase.CinematicDialogue or {}
local D = MilBase.CinematicDialogue
D.NET_OPEN = D.NET_OPEN or "MilBase_CinematicDialogue_Open"
D.NET_ACTION = D.NET_ACTION or "MilBase_CinematicDialogue_Action"
D.NET_CLOSE = D.NET_CLOSE or "MilBase_CinematicDialogue_Close"

local active
local cameraPosition
local cameraAngles
local cameraFov

local function readPayload()
	local length = net.ReadUInt(24)
	if length <= 0 then return {} end
	local raw = util.Decompress(net.ReadData(length))
	local data = raw and util.JSONToTable(raw) or nil
	return istable(data) and data or {}
end

local function font(name, fallback)
	return MilBase.UI and name or fallback
end

local function sendAction(action)
	if not active or not active.data then return end
	net.Start(D.NET_ACTION)
		net.WriteString(tostring(active.data.token or ""))
		net.WriteString(tostring(action or ""))
	net.SendToServer()
end

local function removeActive(sendClose)
	if not active then return end
	local old = active
	active = nil
	cameraPosition, cameraAngles, cameraFov = nil, nil, nil
	if IsValid(old.frame) then old.frame:Remove() end
	if sendClose and old.data then
		net.Start(D.NET_ACTION)
			net.WriteString(tostring(old.data.token or ""))
			net.WriteString("close")
		net.SendToServer()
	end
end

local function createPortrait(frame, data)
	if data.mode ~= "remote" or tostring(data.model or "") == "" then return end
	local portrait = vgui.Create("DModelPanel", frame)
	portrait:SetPos(math.floor(ScrW() * 0.25), math.floor(ScrH() * 0.11))
	portrait:SetSize(math.floor(ScrW() * 0.5), math.floor(ScrH() * 0.51))
	portrait:SetModel(data.model)
	portrait:SetFOV(28)
	portrait:SetAmbientLight(Color(35, 65, 85))
	portrait:SetDirectionalLight(BOX_FRONT, Color(90, 175, 225))
	portrait:SetDirectionalLight(BOX_RIGHT, Color(30, 75, 115))
	portrait:SetAnimated(true)
	portrait.LayoutEntity = function(_, ent)
		if not IsValid(ent) then return end
		ent:SetAngles(Angle(0, 18, 0))
		ent:FrameAdvance(FrameTime())
	end
	timer.Simple(0, function()
		if not IsValid(portrait) or not IsValid(portrait.Entity) then return end
		local mins, maxs = portrait.Entity:GetRenderBounds()
		local centre = (mins + maxs) * 0.5
		portrait:SetLookAt(centre + Vector(0, 0, maxs.z * 0.12))
		portrait:SetCamPos(centre + Vector(95, 0, maxs.z * 0.08))
	end)
	active.portrait = portrait
end

local function openDialogue(data)
	removeActive(false)
	local frame = vgui.Create("DFrame")
	frame:SetPos(0, 0)
	frame:SetSize(ScrW(), ScrH())
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(true)
	frame:SetMouseInputEnabled(true)

	active = { frame = frame, data = data, buttons = {} }
	createPortrait(frame, data)

	frame.Paint = function(_, w, h)
		local amber = Color(239, 174, 48)
		local blue = Color(65, 155, 235)
		surface.SetDrawColor(0, 0, 0, data.mode == "remote" and 205 or 68)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(0, 0, 0, 245)
		surface.DrawRect(0, 0, w, math.floor(h * 0.09))
		surface.DrawRect(0, math.floor(h * 0.87), w, math.ceil(h * 0.13))
		surface.SetDrawColor(0, 0, 0, 145)
		surface.DrawRect(0, math.floor(h * 0.55), w, math.floor(h * 0.32))

		local left = math.floor(w * 0.085)
		local baseline = math.floor(h * 0.68)
		draw.SimpleText(data.speakerName or "Civilian", font("MB.Big", "Trebuchet24"),
			left, baseline, amber, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		draw.DrawText(data.line or "", font("MB.Small", "Trebuchet18"),
			left, baseline + 12, color_white, TEXT_ALIGN_LEFT)
		local meta = string.upper(tostring(data.speciesName or ""))
			.. (tostring(data.languageName or "") ~= "" and ("  •  " .. string.upper(data.languageName)) or "")
		draw.SimpleText(meta, font("MB.Tiny", "DermaDefault"), left, baseline + 62,
			Color(180, 195, 210), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		if data.understood == false then
			draw.SimpleText("TRANSLATION REQUIRED", font("MB.Tiny", "DermaDefaultBold"),
				left, baseline + 84, Color(235, 95, 75), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		elseif tostring(data.translator or "") ~= "" then
			draw.SimpleText("INTERPRETED BY " .. string.upper(data.translator),
				font("MB.Tiny", "DermaDefaultBold"), left, baseline + 84,
				Color(90, 205, 145), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		draw.SimpleText(data.playerName or LocalPlayer():Nick(), font("MB.Big", "Trebuchet24"),
			math.floor(w * 0.93), math.floor(h * 0.59), blue, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
		draw.SimpleText(string.upper(tostring(data.title or "CONVERSATION")),
			font("MB.Tiny", "DermaDefaultBold"), w / 2, math.floor(h * 0.045),
			Color(185, 200, 215), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.upper(tostring(data.subtitle or "")),
			font("MB.Tiny", "DermaDefault"), w / 2, math.floor(h * 0.066),
			Color(120, 145, 165), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	frame.OnKeyCodePressed = function(_, key)
		if key == KEY_ESCAPE then removeActive(true) return end
		local number = key >= KEY_1 and key <= KEY_9 and key - KEY_0 or nil
		local button = number and active and active.buttons[number] or nil
		if IsValid(button) and button:IsEnabled() then button:DoClick() end
	end

	local choiceCount = #data.choices
	local width = math.min(660, math.floor(ScrW() * 0.47))
	local buttonHeight = 34
	local right = math.floor(ScrW() * 0.93)
	local bottom = math.floor(ScrH() * 0.84)
	for index, choice in ipairs(data.choices or {}) do
		local button = vgui.Create("DButton", frame)
		button:SetSize(width, buttonHeight)
		button:SetPos(right - width, bottom - (choiceCount - index + 1) * (buttonHeight + 5))
		button:SetText("")
		button:SetEnabled(choice.disabled ~= true)
		button.Paint = function(self, w, h)
			local selected = self:IsHovered() and self:IsEnabled()
			local colour = choice.danger and Color(230, 90, 65) or Color(239, 174, 48)
			surface.SetDrawColor(0, 0, 0, selected and 205 or 120)
			surface.DrawRect(0, 0, w, h)
			if selected then
				surface.SetDrawColor(colour.r, colour.g, colour.b, 62)
				surface.DrawRect(0, 0, w, h)
			end
			draw.SimpleText(index .. ". " .. tostring(choice.label or choice.id),
				font("MB.Small", "Trebuchet18"), w - 12, h / 2,
				selected and colour or Color(235, 235, 235),
				TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function() sendAction(choice.id) end
		active.buttons[index] = button
	end
end

net.Receive(D.NET_OPEN, function()
	openDialogue(readPayload())
end)

net.Receive(D.NET_CLOSE, function()
	removeActive(false)
end)

hook.Add("CalcView", "MilBase_CinematicDialogue_Camera", function(ply, origin, angles, fov)
	if not active or active.data.mode ~= "physical" then return end
	local speaker = Entity(tonumber(active.data.speakerEntIndex) or 0)
	if not IsValid(speaker) then return end
	local target = speaker:WorldSpaceCenter() + Vector(0, 0, math.max(2, speaker:OBBMaxs().z * 0.08))
	local desired = target + speaker:GetForward() * 96 + speaker:GetRight() * 16 + Vector(0, 0, 6)
	local trace = util.TraceHull({
		start = target,
		endpos = desired,
		mins = Vector(-5, -5, -5),
		maxs = Vector(5, 5, 5),
		filter = { ply, speaker },
		mask = MASK_SOLID,
	})
	desired = trace.HitPos + trace.HitNormal * 4
	local desiredAngles = (target - desired):Angle()
	cameraPosition = cameraPosition and LerpVector(math.Clamp(FrameTime() * 6, 0, 1), cameraPosition, desired) or desired
	cameraAngles = cameraAngles and LerpAngle(math.Clamp(FrameTime() * 7, 0, 1), cameraAngles, desiredAngles) or desiredAngles
	cameraFov = cameraFov and Lerp(math.Clamp(FrameTime() * 8, 0, 1), cameraFov, 48) or fov
	return {
		origin = cameraPosition,
		angles = cameraAngles,
		fov = cameraFov,
		drawviewer = false,
	}
end)

hook.Add("CreateMove", "MilBase_CinematicDialogue_LockMovement", function(command)
	if not active then return end
	command:ClearMovement()
	command:RemoveKey(IN_ATTACK)
	command:RemoveKey(IN_ATTACK2)
	command:RemoveKey(IN_USE)
end)
