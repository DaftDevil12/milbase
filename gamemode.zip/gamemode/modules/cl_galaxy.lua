--[[
	Galaxy Director client:
	  * Tactical HUD and skybox weapon beams.
	  * Interactive contact/distress communication panel.
	  * Player-facing Galaxy F4 tab.
	  * Staff/management F2 control centre.
]]

if not CLIENT or MilBase._GalaxyClientLoaded then return end
MilBase._GalaxyClientLoaded = true

local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}
G.ClientState = G.ClientState or {}
G.AdminData = G.AdminData or {}
G.LastEncounter = G.LastEncounter or nil

local laserMaterial = Material("cable/redlaser")
local hyperspaceMaterial = Material("sprites/light_glow02_add")
local galaxyBeams = {}
local hyperspaceBursts = {}
local encounterFrame
local hailFrame

local function readCompressed()
	local length = net.ReadUInt(24)
	if length <= 0 or length > 16000000 then return {} end
	local raw = util.Decompress(net.ReadData(length))
	return util.JSONToTable(raw or "") or {}
end

net.Receive("MilBase_GalaxyState", function()
	G.ClientState = readCompressed()
	if G.RefreshGalaxyTab then G.RefreshGalaxyTab() end
end)

net.Receive("MilBase_GalaxyAdminData", function()
	G.AdminData = readCompressed()
	if G.RebuildAdmin then G.RebuildAdmin() end
end)

net.Receive("MilBase_GalaxyLaser", function()
	galaxyBeams[#galaxyBeams + 1] = {
		startPos = net.ReadVector(),
		endPos = net.ReadVector(),
		color = net.ReadColor(),
		width = net.ReadFloat(),
		born = CurTime(),
		dies = CurTime() + 0.32,
	}
end)

net.Receive("MilBase_GalaxyHyperspace", function()
	hyperspaceBursts[#hyperspaceBursts + 1] = {
		pos = net.ReadVector(),
		direction = net.ReadVector(),
		color = net.ReadColor(),
		arriving = net.ReadBool(),
		born = CurTime(),
		dies = CurTime() + 0.72,
	}
end)

hook.Add("PostDrawTranslucentRenderables", "MilBase.GalaxyLasers", function()
	if #galaxyBeams == 0 then return end
	render.SetMaterial(laserMaterial)
	local now = CurTime()
	for i = #galaxyBeams, 1, -1 do
		local beam = galaxyBeams[i]
		if now >= beam.dies then
			table.remove(galaxyBeams, i)
		else
			local alpha = math.Clamp((beam.dies - now) / (beam.dies - beam.born), 0, 1)
			local color = Color(beam.color.r, beam.color.g, beam.color.b, 255 * alpha)
			render.DrawBeam(beam.startPos, beam.endPos, beam.width, 0, 1, color)
			render.DrawBeam(beam.startPos, beam.endPos, beam.width * 0.35, 0, 1,
				Color(255, 255, 255, 220 * alpha))
		end
	end
end)

hook.Add("PostDrawTranslucentRenderables", "MilBase.GalaxyHyperspaceBursts", function()
	if #hyperspaceBursts == 0 then return end
	local length = math.max(180, tonumber(gd.HyperspaceTransitEffectLength) or 950)
	local now = CurTime()
	render.SetMaterial(hyperspaceMaterial)
	for index = #hyperspaceBursts, 1, -1 do
		local burst = hyperspaceBursts[index]
		if now >= burst.dies then
			table.remove(hyperspaceBursts, index)
		else
			local life = math.Clamp((burst.dies - now) / (burst.dies - burst.born), 0, 1)
			local startPos = burst.arriving and burst.pos - burst.direction * length or burst.pos
			local endPos = burst.arriving and burst.pos or burst.pos + burst.direction * length
			local color = Color(burst.color.r, burst.color.g, burst.color.b, 230 * life)
			render.DrawBeam(startPos, endPos, 18 * life + 4, 0, 1, color)
			render.DrawSprite(burst.pos, 110 * life + 40, 110 * life + 40,
				Color(210, 235, 255, 220 * life))
		end
	end
end)

local function paintBFPanel(width, height, accent, fill)
	local ui = MilBase.UI
	MilBase.DrawPanelBF2(0, 0, width, height, {
		cut = 8,
		color = fill or ui.panel,
		accent = accent or ui.accent,
	})
end

local function galaxyButton(parent, label, onClick, accent)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.mb_label = label
	button.Paint = function(self, width, height)
		local ui = MilBase.UI
		local color = accent or ui.accent
		paintBFPanel(width, height, color,
			self:IsHovered() and Color(color.r, color.g, color.b, 48) or ui.raised)
		draw.SimpleText(self.mb_label, "MB.Small", width / 2, height / 2,
			self:IsEnabled() and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = onClick
	return button
end

local function darkEntry(parent, placeholder)
	local entry = vgui.Create("DTextEntry", parent)
	entry:SetFont("MB.Small")
	entry:SetPlaceholderText(placeholder or "")
	entry:SetPaintBackground(false)
	entry.Paint = function(self, width, height)
		local ui = MilBase.UI
		surface.SetDrawColor(0, 0, 0, 155)
		surface.DrawRect(0, 0, width, height)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, width, height)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end
	return entry
end

local function closeEncounter()
	if IsValid(encounterFrame) then encounterFrame:Remove() end
	encounterFrame = nil
end

local function closeHail()
	if IsValid(hailFrame) then hailFrame:Remove() end
	hailFrame = nil
end

local function answerEncounter(id, response)
	net.Start("MilBase_GalaxyRespond")
		net.WriteString(id)
		net.WriteString(response)
	net.SendToServer()
	closeEncounter()
end

local function requestCapitalVolley(id)
	net.Start("MilBase_GalaxyRespond")
		net.WriteString(id)
		net.WriteString("capital_volley")
	net.SendToServer()
end

local function canAuthorizeCapitalVolley()
	local ply = LocalPlayer()
	if not IsValid(ply) then return false end
	if ply:IsAdmin() then return true end
	if ply.MBHasCert and (ply:MBHasCert("fleet_operator")
		or ply:MBHasCert("high_command")) then return true end
	return MilBase.CommsIsHighCommand
		and MilBase.CommsIsHighCommand(ply) == true
end

local function openEncounter(data)
	closeEncounter()
	if not data or data.close or not data.id then return end
	closeHail()
	G.LastEncounter = data

	local ui = MilBase.UI
	local width = math.min(570, ScrW() - 40)
	local choiceHeight = math.ceil(#(data.choices or {}) / 2) * 42
	local height = 200 + choiceHeight
	local frame = vgui.Create("DFrame")
	encounterFrame = frame
	frame:SetSize(width, height)
	frame:SetPos(ScrW() - width - 24, ScrH() - height - 24)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	frame.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur(self, self.mb_opened or SysTime())
		paintBFPanel(w, h, ui.warn, Color(7, 14, 22, 246))
		surface.SetDrawColor(ui.warn.r, ui.warn.g, ui.warn.b, 32)
		surface.DrawRect(1, 1, w - 2, 48)
		draw.SimpleText(data.title or "INCOMING TRANSMISSION", "MB.Med", 18, 12, ui.text)
		draw.SimpleText(string.upper(data.source or "UNKNOWN CONTACT"), "MB.Tiny",
			18, 39, ui.warn)
	end
	frame.mb_opened = SysTime()

	local close = galaxyButton(frame, "X", function() closeEncounter() end, ui.danger)
	close:SetSize(34, 28)
	close:SetPos(width - 46, 10)

	local body = vgui.Create("DLabel", frame)
	body:SetPos(18, 62)
	body:SetSize(width - 36, 70)
	body:SetFont("MB.Small")
	body:SetTextColor(ui.dim)
	body:SetWrap(true)
	body:SetAutoStretchVertical(true)
	body:SetText(data.body or "")

	local timeout = vgui.Create("DLabel", frame)
	timeout:SetPos(18, 135)
	timeout:SetSize(width - 36, 24)
	timeout:SetFont("MB.Tiny")
	timeout:SetTextColor(ui.faint)
	timeout.Think = function(self)
		local remain = math.max(0, (tonumber(data.timeout) or CurTime()) - CurTime())
		self:SetText("CHANNEL WINDOW  " .. G.FormatDuration(remain))
		if remain <= 0 then closeEncounter() end
	end

	local choices = data.choices or {}
	for index, choice in ipairs(choices) do
		local column = (index - 1) % 2
		local row = math.floor((index - 1) / 2)
		local buttonWidth = math.floor((width - 46) / 2)
		local button = galaxyButton(frame, choice.label or choice.id, function()
			answerEncounter(data.id, choice.id)
		end, column == 0 and ui.accent or ui.warn)
		button:SetSize(buttonWidth, 34)
		button:SetPos(18 + column * (buttonWidth + 10), 168 + row * 42)
	end
end

net.Receive("MilBase_GalaxyEncounter", function()
	local data = readCompressed()
	if data.close then
		G.LastEncounter = nil
		closeEncounter()
		return
	end
	openEncounter(data)
end)

local function hailFactionColor(faction)
	return G.AllegianceColor and G.AllegianceColor(faction)
		or (MilBase.UI and MilBase.UI.accent) or Color(80, 150, 235)
end

local function requestHail(entityIndex)
	net.Start("MilBase_GalaxyHailRequest")
		net.WriteUInt(math.Clamp(math.floor(tonumber(entityIndex) or 0), 0, 65535), 16)
	net.SendToServer()
end

local function requestHailAction(action, entityIndex)
	net.Start("MilBase_GalaxyHailAction")
		net.WriteString(tostring(action or ""))
		net.WriteUInt(math.Clamp(math.floor(tonumber(entityIndex) or 0), 0, 65535), 16)
	net.SendToServer()
end

local function openCustomsHail(data)
	closeHail()
	closeEncounter()
	local ui = MilBase.UI
	local customs = data.customs or {}
	local contact = data.contact or {}
	local accent = hailFactionColor(contact.faction or "civilian")
	local width = math.min(780, ScrW() - 40)
	local height = math.min(620, ScrH() - 40)
	local frame = vgui.Create("DFrame")
	hailFrame = frame
	frame:SetSize(width, height)
	frame:SetPos(ScrW() - width - 24, ScrH() - height - 24)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	frame.mb_opened = SysTime()
	frame.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur(self, self.mb_opened)
		paintBFPanel(w, h, accent, Color(7, 14, 22, 248))
		surface.SetDrawColor(accent.r, accent.g, accent.b, 34)
		surface.DrawRect(1, 1, w - 2, 58)
		draw.SimpleText(data.title or "REPUBLIC CUSTOMS CHANNEL", "MB.Med", 18, 10, ui.text)
		draw.SimpleText(string.upper(tostring(customs.contact or contact.name or "UNKNOWN CONTACT"))
			.. "  /  " .. tostring(customs.id or "UNASSIGNED"), "MB.Tiny", 18, 39, accent)
	end

	local close = galaxyButton(frame, "X", function() closeHail() end, ui.danger)
	close:SetSize(34, 28); close:SetPos(width - 46, 12)
	local contacts = galaxyButton(frame, "CONTACT LIST", function() requestHail(0) end, ui.accent)
	contacts:SetSize(108, 28); contacts:SetPos(width - 164, 12)

	local content = vgui.Create("DPanel", frame)
	content:SetPos(16, 70)
	content:SetSize(width - 32, height - 86)
	content.Paint = nil

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT); left:SetWide(math.Clamp(math.floor(width * 0.43), 285, 340)); left:DockMargin(0, 0, 12, 0)
	left.Paint = nil

	local response = vgui.Create("DPanel", left)
	response:Dock(TOP); response:SetTall(112); response:DockMargin(0, 0, 0, 10)
	response.Paint = function(self, w, h)
		paintBFPanel(w, h, ui.warn, Color(3, 9, 16, 225))
		draw.SimpleText("LATEST TRANSMISSION", "MB.Tiny", 12, 9, ui.warn)
	end
	local responseText = vgui.Create("DLabel", response)
	responseText:Dock(FILL); responseText:DockMargin(12, 30, 12, 10)
	responseText:SetFont("MB.Small"); responseText:SetTextColor(ui.text)
	responseText:SetWrap(true); responseText:SetAutoStretchVertical(false)
	responseText:SetText(tostring(customs.message or data.body or "Channel established."))

	local summary = vgui.Create("DPanel", left)
	summary:Dock(TOP); summary:SetTall(152); summary:DockMargin(0, 0, 0, 10)
	summary.Paint = function(self, w, h)
		paintBFPanel(w, h, accent, Color(3, 9, 16, 220))
		draw.SimpleText("CASE SUMMARY", "MB.Tiny", 12, 9, accent)
		local rows = {
			{ "CAPTAIN", customs.captain or "UNKNOWN" },
			{ "STATUS", customs.status or "UNKNOWN" },
			{ "IFF", customs.iff or "UNVERIFIED" },
			{ "SUSPICION", tostring(customs.suspicion or 0) .. "%" },
			{ "EVIDENCE", tostring(customs.evidenceCount or 0) },
		}
		for index, row in ipairs(rows) do
			local y = 31 + (index - 1) * 23
			draw.SimpleText(row[1], "MB.Tiny", 12, y, ui.faint)
			local value = tostring(row[2] or "")
			if #value > 36 then value = string.sub(value, 1, 33) .. "..." end
			draw.SimpleText(value, "MB.Tiny", w - 12, y, index >= 4 and ui.warn or ui.text, TEXT_ALIGN_RIGHT)
		end
	end

	local records = vgui.Create("DScrollPanel", left)
	records:Dock(FILL)
	local function addRecordSection(title, rows, formatter)
		local heading = vgui.Create("DLabel", records)
		heading:Dock(TOP); heading:DockMargin(4, 4, 8, 4); heading:SetTall(22)
		heading:SetFont("MB.Small"); heading:SetTextColor(accent); heading:SetText(title)
		if #(rows or {}) == 0 then
			local empty = vgui.Create("DLabel", records)
			empty:Dock(TOP); empty:DockMargin(10, 0, 10, 7); empty:SetTall(20)
			empty:SetFont("MB.Tiny"); empty:SetTextColor(ui.faint); empty:SetText("None recorded")
			return
		end
		for _, row in ipairs(rows or {}) do
			local line = vgui.Create("DLabel", records)
			line:Dock(TOP); line:DockMargin(10, 0, 10, 5); line:SetTall(20)
			line:SetFont("MB.Tiny"); line:SetTextColor(ui.dim)
			line:SetText("• " .. tostring(formatter and formatter(row) or row))
		end
	end
	addRecordSection("VERIFICATION CHECKS", customs.checks or {}, function(row)
		return tostring(row.label or "CHECK") .. ": " .. tostring(row.value or "UNKNOWN")
	end)
	addRecordSection("CONFIRMED EVIDENCE", customs.evidence or {})
	addRecordSection("POTENTIAL CHARGES", customs.charges or {})

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL); right.Paint = nil
	local instructions = vgui.Create("DPanel", right)
	instructions:Dock(TOP); instructions:SetTall(58); instructions:DockMargin(0, 0, 0, 8)
	instructions.Paint = function(self, w, h)
		paintBFPanel(w, h, accent, Color(3, 9, 16, 218))
		draw.SimpleText("SELECT THE NEXT STEP", "MB.Small", 12, 8, ui.text)
		draw.SimpleText("Documents → sensor checks → flight control → disposition", "MB.Tiny", 12, 34, ui.dim)
	end

	local actionScroll = vgui.Create("DScrollPanel", right)
	actionScroll:Dock(FILL)
	local groups, order = {}, {}
	for _, choice in ipairs(data.choices or {}) do
		local group = tostring(choice.group or "CHANNEL")
		if not groups[group] then groups[group] = {}; order[#order + 1] = group end
		groups[group][#groups[group] + 1] = choice
	end
	for _, group in ipairs(order) do
		local groupName = group
		local heading = vgui.Create("DPanel", actionScroll)
		heading:Dock(TOP); heading:SetTall(31); heading:DockMargin(0, 0, 4, 5)
		heading.Paint = function(self, w, h)
			surface.SetDrawColor(accent.r, accent.g, accent.b, 18); surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(accent.r, accent.g, accent.b, 100); surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(groupName, "MB.Tiny", 10, h / 2, accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		for _, choice in ipairs(groups[group]) do
			local rowChoice = choice
			local buttonAccent = rowChoice.danger and ui.danger or accent
			local button = galaxyButton(actionScroll, rowChoice.label or rowChoice.id, function()
				requestHailAction(rowChoice.id, contact.entity)
			end, buttonAccent)
			button:Dock(TOP); button:SetTall(38); button:DockMargin(0, 0, 4, 6)
		end
	end
end

local function openHail(data)
	closeHail()
	if not data or data.mode == "close" then return end
	if tostring(data.layout or "") == "customs" then
		openCustomsHail(data)
		return
	end
	closeEncounter()

	local ui = MilBase.UI
	local mode = tostring(data.mode or "contacts")
	local station = tostring(data.station or "communications")
	local scannerStation = station == "scanner"
	local gunnerStation = station == "gunner"
	local communicationsStation = not scannerStation and not gunnerStation
	local ordnance = tostring(data.ordnance or "turbolaser")
	local expansionEnabled = gd.LivingUniverseExpansion ~= false
	local function refreshStation()
		if scannerStation then
			requestHailAction("scanner_contacts", 0)
		elseif gunnerStation then
			requestHailAction(ordnance == "ion" and "ion_contacts"
				or ordnance == "torpedo" and "torpedo_contacts" or "gunner_contacts", 0)
		else
			requestHail(0)
		end
	end
	local width = math.min(640, ScrW() - 40)
	local choices = data.choices or {}
	local choiceRows = math.ceil(#choices / 2)
	local bodyHeight = mode == "scan_result" and 220 or 92
	local choiceStart = 61 + bodyHeight + 36
	local height = (mode == "contacts" or mode == "history")
			and math.min(560, ScrH() - 40)
		or mode == "pending" and 205
		or math.min(math.max(285, choiceStart + choiceRows * 42 + 60), ScrH() - 40)
	local frame = vgui.Create("DFrame")
	hailFrame = frame
	frame:SetSize(width, height)
	frame:SetPos(ScrW() - width - 24, ScrH() - height - 24)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	frame.mb_opened = SysTime()

	local contact = data.contact or {}
	local faction = contact.faction or "neutral"
	local accent = mode == "result" and data.answered == false
		and ui.warn or hailFactionColor(faction)
	frame.Paint = function(self, w, h)
		Derma_DrawBackgroundBlur(self, self.mb_opened)
		paintBFPanel(w, h, accent, Color(7, 14, 22, 246))
		surface.SetDrawColor(accent.r, accent.g, accent.b, 32)
		surface.DrawRect(1, 1, w - 2, 48)
		draw.SimpleText(data.title or "OUTGOING COMMUNICATIONS", "MB.Med",
			18, 12, ui.text)
		if mode ~= "contacts" and mode ~= "history" then
			draw.SimpleText(string.upper(contact.name or "UNKNOWN CONTACT"), "MB.Tiny",
				18, 39, accent)
		elseif mode == "history" then
			draw.SimpleText("PRIVATE TERMINAL RECORD", "MB.Tiny", 18, 39, ui.accent)
		else
			draw.SimpleText(gunnerStation and (ordnance == "ion" and "ION TARGETING SOLUTIONS"
				or ordnance == "torpedo" and "PROTON TORPEDO TARGETING"
				or "SCANNER-LOCKED HOSTILES")
			or scannerStation and "VISIBLE LOCAL CONTACTS" or "LOCAL VISUAL CONTACTS",
			"MB.Tiny", 18, 39, ui.accent)
		end
	end

	local close = galaxyButton(frame, "X", function() closeHail() end, ui.danger)
	close:SetSize(34, 28)
	close:SetPos(width - 46, 10)
	if mode == "contacts" then
		local refresh = galaxyButton(frame, "REFRESH", function()
			refreshStation()
		end, ui.accent)
		refresh:SetSize(84, 28)
		refresh:SetPos(width - 140, 10)

		if expansionEnabled and communicationsStation then
			if MilBase.Prison then
				local prison = galaxyButton(frame, "PRISON TRANSFERS", function()
					net.Start("MilBase_Prison_Comms")
						net.WriteString("open")
						net.SendToServer()
				end, ui.accent)
				prison:SetSize(118, 28)
				prison:SetPos(width - 484, 10)
			end

			local history = galaxyButton(frame, "HISTORY", function()
				requestHailAction("history", 0)
			end, ui.accent)
			history:SetSize(84, 28)
			history:SetPos(width - 234, 10)

			local supportLabel = data.supportPending and "SUPPORT INBOUND"
				or ("SUPPORT " .. tostring(data.supportCharges or 0)
					.. "/" .. tostring(data.supportMaximum or 0))
			local support = galaxyButton(frame, supportLabel, function()
				requestHailAction("support", 0)
			end, ui.warn)
			support:SetSize(112, 28)
			support:SetPos(width - 356, 10)
			support:SetEnabled(not data.supportPending)
		end
	elseif mode == "history" then
		local back = galaxyButton(frame, "CONTACTS", function()
			refreshStation()
		end, ui.accent)
		back:SetSize(88, 28)
		back:SetPos(width - 144, 10)
	end

	local body = vgui.Create("DLabel", frame)
	body:SetPos(18, 61)
	body:SetSize(width - 36, (mode == "contacts" or mode == "history")
		and 38 or bodyHeight)
	body:SetFont("MB.Small")
	body:SetTextColor(ui.dim)
	body:SetWrap(true)
	body:SetAutoStretchVertical(true)
	body:SetText(data.body or "")

	if mode == "pending" then
		local waiting = vgui.Create("DLabel", frame)
		waiting:SetPos(18, height - 48)
		waiting:SetSize(width - 36, 24)
		waiting:SetFont("MB.Tiny")
		waiting:SetTextColor(accent)
		waiting.Think = function(self)
			local dots = string.rep(".", math.floor(CurTime() * 2) % 4)
			self:SetText((scannerStation and "RESOLVING SCAN" or "AWAITING RESPONSE") .. dots)
		end
		return
	end

	if mode == "history" then
		local historyList = vgui.Create("DScrollPanel", frame)
		historyList:SetPos(18, 108)
		historyList:SetSize(width - 36, height - 126)
		local historyItems = data.history or {}
		if #historyItems == 0 then
			local empty = vgui.Create("DLabel", historyList)
			empty:Dock(TOP)
			empty:SetTall(70)
			empty:SetFont("MB.Small")
			empty:SetTextColor(ui.faint)
			empty:SetContentAlignment(5)
			empty:SetText("NO COMMUNICATIONS HAVE BEEN RECORDED")
			return
		end
		for _, value in ipairs(historyItems) do
			local item = value
			local itemAccent = hailFactionColor(item.faction)
			local row = vgui.Create("DPanel", historyList)
			row:Dock(TOP)
			row:DockMargin(0, 0, 4, 8)
			row:SetTall(78)
			row.Paint = function(self, w, h)
				surface.SetDrawColor(3, 8, 14, 210)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(itemAccent.r, itemAccent.g, itemAccent.b, 150)
				surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(string.upper(item.direction or "log") .. "   /   "
					.. tostring(item.contact or "UNKNOWN"), "MB.Small", 12, 8, ui.text)
				draw.SimpleText(os.date("%d/%m %H:%M", tonumber(item.time) or 0)
					.. "   /   " .. string.upper(item.planet or "UNKNOWN"),
					"MB.Tiny", w - 12, 12, itemAccent, TEXT_ALIGN_RIGHT)
				draw.SimpleText(item.summary or "", "MB.Tiny", 12, 38, ui.dim)
			end
		end
		return
	end

	if mode == "result" or mode == "scan_result" then
		local details = vgui.Create("DLabel", frame)
		details:SetPos(18, 61 + bodyHeight + 5)
		details:SetSize(width - 36, 24)
		details:SetFont("MB.Tiny")
		details:SetTextColor(accent)
		details:SetText(string.upper(contact.factionName or faction)
			.. "   /   " .. string.upper(contact.state or "UNKNOWN")
			.. (contact.signal and ("   /   SIGNAL " .. contact.signal .. "%") or ""))

		local done = galaxyButton(frame, scannerStation and "SCANNER CONTACTS"
			or gunnerStation and "FIRE CONTROL" or "CONTACT LIST", function()
			refreshStation()
		end, accent)
		done:SetSize(120, 34)
		done:SetPos(width - 138, height - 48)

		for index, choice in ipairs(choices) do
			local rowChoice = choice
			local column = (index - 1) % 2
			local rowIndex = math.floor((index - 1) / 2)
			local buttonWidth = math.floor((width - 46) / 2)
			local choiceButton = galaxyButton(frame,
				rowChoice.label or rowChoice.id, function()
					requestHailAction(rowChoice.id, contact.entity)
				end, column == 0 and accent or ui.warn)
			choiceButton:SetSize(buttonWidth, 34)
			choiceButton:SetPos(18 + column * (buttonWidth + 10),
				choiceStart + rowIndex * 42)
		end
		return
	end

	local contacts = data.contacts or {}
	local tracking = scannerStation and (data.tracking or {}) or {}
	local reports = scannerStation and (data.reports or {}) or {}
	local list = vgui.Create("DScrollPanel", frame)
	list:SetPos(18, 108)
	list:SetSize(width - 36, height - 126)

	if #contacts == 0 and #tracking == 0 and #reports == 0 then
		local empty = vgui.Create("DLabel", list)
		empty:Dock(TOP)
		empty:SetTall(70)
		empty:SetFont("MB.Small")
		empty:SetTextColor(ui.faint)
		empty:SetContentAlignment(5)
		empty:SetText(gunnerStation
			and "NO SCANNER-LOCKED HOSTILES ARE AVAILABLE FOR FIRE CONTROL"
			or "NO VISIBLE AI SHIPS ARE CURRENTLY INSIDE LOCAL SENSOR RANGE")
		return
	end

	for _, value in ipairs(tracking) do
		local tracked = value
		local rowAccent = hailFactionColor(tracked.faction)
		local row = vgui.Create("DPanel", list)
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 8)
		row:SetTall(66)
		row.Paint = function(self, w, h)
			surface.SetDrawColor(3, 15, 25, 228)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(rowAccent.r, rowAccent.g, rowAccent.b, 210)
			surface.DrawOutlinedRect(0, 0, w, h)
			surface.DrawRect(0, 0, 4, h)
			draw.SimpleText("ROUTE TRACK  /  " .. tostring(tracked.name or "UNKNOWN"),
				"MB.Small", 16, 8, ui.text)
			draw.SimpleText(string.upper(tracked.status or "AWAITING TELEMETRY"),
				"MB.Tiny", 16, 35, rowAccent)
		end
	end

	for _, value in ipairs(reports) do
		local report = value
		local reportAccent = report.kind == "battle" and ui.danger
			or report.kind == "distress" and ui.warn or ui.accent
		local row = vgui.Create("DPanel", list)
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 8)
		row:SetTall(64)
		row.Paint = function(self, w, h)
			surface.SetDrawColor(8, 12, 20, 228)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(reportAccent.r, reportAccent.g, reportAccent.b, 160)
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText("SECTOR REPORT  /  " .. string.upper(report.title or "UPDATE"),
				"MB.Tiny", 12, 8, reportAccent)
			local text = tostring(report.details or "")
			if #text > 92 then text = string.sub(text, 1, 89) .. "..." end
			draw.SimpleText(text, "MB.Tiny", 12, 30, ui.dim)
			draw.SimpleText(string.upper(report.system or "UNKNOWN"), "MB.Tiny",
				w - 12, 8, reportAccent, TEXT_ALIGN_RIGHT)
		end
	end

	for _, value in ipairs(contacts) do
		local rowContact = value
		local rowAccent = hailFactionColor(rowContact.faction)
		local row = vgui.Create("DPanel", list)
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 8)
		row:SetTall(78)
		row.Paint = function(self, w, h)
			surface.SetDrawColor(3, 8, 14, 210)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(rowAccent.r, rowAccent.g, rowAccent.b, 180)
			surface.DrawOutlinedRect(0, 0, w, h)
			surface.DrawRect(0, 0, 4, h)
			draw.SimpleText(rowContact.name or "UNKNOWN CONTACT", "MB.Small",
				16, 10, ui.text)
			draw.SimpleText(string.upper(rowContact.factionName or rowContact.faction or "UNKNOWN"),
				"MB.Tiny", 16, 38, rowAccent)
			local status = string.upper(rowContact.state or "UNKNOWN")
			if rowContact.planetContact then
				status = status .. "   /   SECURE PLANETARY LINK"
			elseif rowContact.hull and rowContact.maxHull
			and (rowContact.scanned or rowContact.scanned == nil) then
				local hull = math.floor(math.Clamp((tonumber(rowContact.hull) or 0)
					/ math.max(1, tonumber(rowContact.maxHull) or 1), 0, 1) * 100)
				status = status .. "   /   HULL " .. hull .. "%"
				if (tonumber(rowContact.maxShield) or 0) > 0 then
					local shield = math.floor(math.Clamp((tonumber(rowContact.shield) or 0)
						/ math.max(1, tonumber(rowContact.maxShield) or 1), 0, 1) * 100)
					status = status .. "   /   SHIELD " .. shield .. "%"
				end
			else
				status = status .. "   /   UNSCANNED"
			end
			if rowContact.hostile then status = "HOSTILE   /   " .. status end
			draw.SimpleText(status, "MB.Tiny", w - 118, 14,
				rowContact.hostile and ui.danger or ui.dim, TEXT_ALIGN_RIGHT)
			local route = rowContact.scanned and string.upper(tostring(rowContact.routeStatus or "")) or ""
			if #route > 36 then route = string.sub(route, 1, 33) .. "..." end
			draw.SimpleText((route ~= "" and (route .. "   /   ")
				or (rowContact.contactTypeName ~= "" and
					(rowContact.contactTypeName .. "   /   ") or ""))
				.. "SIGNAL " .. tostring(rowContact.signal or 0) .. "% "
				.. tostring(rowContact.signalLabel or "")
				.. (rowContact.known and ("   /   TRUST "
					.. string.format("%+d", tonumber(rowContact.relationship) or 0)) or ""),
				"MB.Tiny", w - 118, 43, rowAccent, TEXT_ALIGN_RIGHT)
		end

		if communicationsStation then
			local hail = galaxyButton(row, rowContact.planetContact and "REQUEST" or "HAIL", function()
				if rowContact.planetContact then
					requestHailAction("planet_supply", 0)
				else
					requestHail(rowContact.entity)
				end
			end, rowAccent)
			hail:SetSize(76, 28)
			hail:SetPos(width - 36 - 92, 44)
		elseif scannerStation and expansionEnabled then
			local scan = galaxyButton(row,
				rowContact.scanned and rowContact.canTrackRoute
					and (rowContact.routeTracked and "UNTRACK" or "TRACK")
					or rowContact.scanned and "LOCKED" or "SCAN", function()
				requestHailAction(rowContact.scanned and rowContact.canTrackRoute
					and "track_route" or "scan", rowContact.entity)
			end, ui.accent)
			scan:SetSize(82, 28)
			scan:SetPos(width - 36 - 98, 44)
			scan:SetEnabled(not rowContact.scanned or rowContact.canTrackRoute)
		elseif gunnerStation and rowContact.canSkyboxVolley then
			local fire = galaxyButton(row, data.ordnanceButton or "FIRE", function()
				requestHailAction(data.ordnanceAction or "skybox_volley", rowContact.entity)
			end, ui.danger)
			fire:SetSize(88, 28)
			fire:SetPos(width - 36 - 104, 44)
		end
	end
end

net.Receive("MilBase_GalaxyHailContacts", function()
	openHail(readCompressed())
end)

hook.Add("HUDPaint", "MilBase.GalaxyHUD", function()
	if MilBase.Naval and MilBase.Naval.IsNavy
	and not MilBase.Naval.IsNavy(LocalPlayer()) then return end
	local state = G.ClientState or {}
	local active = state.active
	if not active then return end

	local ui = MilBase.UI
	local width = math.min(620, ScrW() * 0.46)
	local height = active.integrity and 96 or 76
	local x = (ScrW() - width) / 2
	local y = 54
	local hostile = active.kind == "cis" or active.kind == "cis_raid"
		or active.phase == "combat" or active.phase == "rescue"
	local accent = hostile and ui.danger or ui.warn

	MilBase.DrawPanelBF2(x, y, width, height, {
		cut = 9,
		color = Color(5, 11, 18, 225),
		accent = accent,
	})
	draw.SimpleText(active.title or "GALAXY EVENT", "MB.Med", x + 16, y + 10, ui.text)
	local phase = active.phaseName or active.phase or ""
	local remain = math.max(0, (active.endsAt or CurTime()) - CurTime())
	draw.SimpleText(string.upper(phase) .. "   " .. G.FormatDuration(remain),
		"MB.Tiny", x + width - 16, y + 17, accent, TEXT_ALIGN_RIGHT)
	draw.SimpleText(active.body or "", "MB.Tiny", x + 16, y + 43, ui.dim)

	if active.integrity then
		local maximum = math.max(1, tonumber(active.maxIntegrity) or 100)
		local fraction = math.Clamp((tonumber(active.integrity) or 0) / maximum, 0, 1)
		local barX, barY, barW = x + 16, y + height - 19, width - 32
		surface.SetDrawColor(255, 255, 255, 16)
		surface.DrawRect(barX, barY, barW, 7)
		surface.SetDrawColor(
			fraction > 0.55 and Color(80, 205, 125)
				or fraction > 0.25 and ui.warn or ui.danger)
		surface.DrawRect(barX, barY, barW * fraction, 7)
		draw.SimpleText("SHIP INTEGRITY " .. math.ceil(active.integrity)
			.. "   •   WAVE " .. (active.wave or 0) .. "/" .. (active.maxWaves or 0)
			.. "   •   HOSTILES " .. (active.hostiles or 0)
			.. ((tonumber(active.capitalCount) or 0) > 0
				and ("   •   MUNIFICENTS " .. active.capitalCount) or "")
			.. ((tonumber(active.breachZones) or 0) > 0
				and ("   •   FRONTS " .. active.breachZones) or "")
			.. ((tonumber(active.republicSupport) or 0) > 0
				and ("   •   ALLIED SHIPS " .. active.republicSupport) or ""),
			"MB.Tiny", x + 16, barY - 3, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
	end
end)

--------------------------------------------------------------------------
-- Player Galaxy tab
--------------------------------------------------------------------------

local function infoRow(parent, label, valueFn, colorFn)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(42)
	panel:DockMargin(0, 0, 0, 5)
	panel.Paint = function(self, width, height)
		local ui = MilBase.UI
		surface.SetDrawColor(255, 255, 255, 5)
		surface.DrawRect(0, 0, width, height)
		draw.SimpleText(label, "MB.Tiny", 12, 8, ui.dim)
		draw.SimpleText(tostring(valueFn() or "UNKNOWN"), "MB.Small", 12, 25,
			colorFn and colorFn() or ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	return panel
end

local function buildGalaxyTab(content)
	local ui = MilBase.UI
	local state = G.ClientState or {}
	local planet = state.planet or {}

	local header = vgui.Create("DPanel", content)
	header:Dock(TOP)
	header:SetTall(78)
	header:DockMargin(0, 0, 0, 12)
	header.Paint = function(self, width, height)
		paintBFPanel(width, height, G.AllegianceColor(planet.allegiance))
		draw.SimpleText("REPUBLIC STRATEGIC STAR MAP", "MB.Big", 18, 10, ui.text)
		draw.SimpleText("LIVE NAVIGATION, TERRITORY AND SENSOR INTELLIGENCE",
			"MB.Tiny", 20, 52, ui.dim)
	end

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(math.min(390, content:GetWide() * 0.42))
	left:DockMargin(0, 0, 12, 0)
	left.Paint = nil

	infoRow(left, "CURRENT LOCATION", function() return state.currentPlanet end,
		function() return G.AllegianceColor(planet.allegiance) end)
	infoRow(left, "ALLEGIANCE", function() return G.AllegianceLabel(planet.allegiance) end,
		function() return G.AllegianceColor(planet.allegiance) end)
	infoRow(left, "REPUBLIC OPINION", function() return (planet.republicOpinion or 0) .. " / 100" end)
	infoRow(left, "CIS OPINION", function() return (planet.cisOpinion or 0) .. " / 100" end)
	infoRow(left, "CIS PRESSURE", function() return (planet.pressure or 0) .. "%" end,
		function() return (planet.pressure or 0) >= 65 and ui.danger or ui.warn end)
	infoRow(left, "ROUTE THREAT", function()
		return math.floor((state.currentRisk or 0) * 100) .. "%"
	end, function() return (state.currentRisk or 0) > 0.6 and ui.danger or ui.warn end)
	if gd.LivingUniverseExpansion ~= false then
		infoRow(left, "SENSOR ARRAY", function()
			local systems = state.shipSystems or {}
			return tostring(math.floor(tonumber(systems.sensors) or 100)) .. "%"
		end, function()
			local value = tonumber((state.shipSystems or {}).sensors) or 100
			return value < 35 and ui.danger or value < 70 and ui.warn or ui.ok
		end)
		infoRow(left, "REPUBLIC SUPPORT", function()
			local support = state.support or {}
			return support.pending and "REINFORCEMENTS INBOUND"
				or tostring(support.charges or 0) .. " / " .. tostring(support.maximum or 0)
		end, function()
			return (state.support or {}).pending and ui.warn or ui.accent
		end)
	end
	infoRow(left, "SHIP COMMUNICATIONS", function()
		local comms = state.comms or {}
		if (comms.terminalCount or 0) <= 0 then return "NO TERMINAL INSTALLED" end
		if comms.incoming then
			return comms.operator ~= "" and ("CONNECTED: " .. comms.operator)
				or "TRANSMISSION WAITING"
		end
		return comms.operator ~= "" and ("OPERATED BY " .. comms.operator) or "STANDBY"
	end, function()
		local comms = state.comms or {}
		if (comms.terminalCount or 0) <= 0 then return ui.danger end
		return comms.incoming and ui.warn or ui.accent
	end)

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL)
	right.Paint = function(self, width, height)
		paintBFPanel(width, height, ui.accent)
		draw.SimpleText("TACTICAL SUMMARY", "MB.Tab", 16, 12, ui.text)
	end

	local summary = vgui.Create("DLabel", right)
	summary:SetPos(16, 52)
	summary:SetSize(math.max(200, content:GetWide() - left:GetWide() - 60), 150)
	summary:SetFont("MB.Small")
	summary:SetTextColor(ui.dim)
	summary:SetWrap(true)
	local active = state.active
	local text
	if active then
		text = (active.title or "Galaxy event") .. "\n\n" .. (active.body or "")
		if active.capitalHull then
			text = text .. "\n\nCIS ATTACK GROUP HULL"
				.. ((tonumber(active.capitalCount) or 0) > 0
					and (" (" .. active.capitalCount .. " MUNIFICENTS)") or "")
				.. ": " .. math.max(0, active.capitalHull)
				.. " / " .. math.max(1, active.capitalMaxHull or 1)
		end
		if active.targetMaxShield and active.targetMaxShield > 0 then
			text = text .. "\nCIS DEFLECTOR SHIELD: "
				.. math.max(0, active.targetShield or 0)
				.. " / " .. math.max(1, active.targetMaxShield)
		end
		if active.waveVariantName then
			text = text .. "\n\nBOARDING CONTACT: " .. active.waveVariantName
		end
	elseif state.operation then
		local operation = state.operation
		local goal = tonumber(operation.goal) or 1
		local progressText = goal == 1
			and (math.floor((tonumber(operation.progress) or 0) * 100) .. "%")
			or (tostring(operation.progress or 0) .. " / " .. tostring(goal))
		text = (operation.title or "Fleet operation") .. "\n\n"
			.. (operation.body or "")
			.. "\n\nPROGRESS: " .. progressText
	elseif (state.intelUntil or 0) > CurTime() then
		text = "CURRENT INTELLIGENCE\n\n" .. (state.intelText or "No additional details.")
	else
		text = "No priority contact is active. Sensor crews continue to monitor local traffic and hyperspace lanes."
	end
	summary:SetText(text)

	if G.LastEncounter and active then
		local reopen = galaxyButton(right, "OPEN ACTIVE COMMUNICATIONS", function()
			openEncounter(G.LastEncounter)
		end, ui.warn)
		reopen:SetPos(16, 220)
		reopen:SetSize(260, 38)
	end

	if active and active.kind == "cis_raid" and active.capitalHull then
		local volley = galaxyButton(right, "", function()
			if canAuthorizeCapitalVolley() then requestCapitalVolley(active.id) end
		end, ui.danger)
		volley:SetPos(16, 270)
		volley:SetSize(310, 38)
		volley.Think = function(self)
			if not canAuthorizeCapitalVolley() then
				self.mb_label = "FLEET FIRE CONTROL REQUIRED"
				self:SetEnabled(false)
				return
			end
			local remaining = (active.volleyReadyAt or 0) - CurTime()
			if remaining <= 0 then
				self.mb_label = "AUTHORIZE CAPITAL BATTERY VOLLEY"
				self:SetEnabled(true)
			else
				self.mb_label = "BATTERIES RECHARGING  " .. G.FormatDuration(remaining)
				self:SetEnabled(false)
			end
		end
	end

	G.RefreshGalaxyTab = function()
		if not IsValid(content) then G.RefreshGalaxyTab = nil return end
		content:Clear()
		buildGalaxyTab(content)
	end
end

MilBase.AddMenuTab("GALAXY", 27, buildGalaxyTab)

--------------------------------------------------------------------------
-- Staff Galaxy Director tab
--------------------------------------------------------------------------

local function sendAdmin(action, data)
	net.Start("MilBase_GalaxyAdminAction")
		net.WriteString(action)
		net.WriteString(util.TableToJSON(data or {}))
	net.SendToServer()
end

local function requestAdmin()
	net.Start("MilBase_GalaxyAdminRequest")
	net.SendToServer()
end

local function section(parent, text, accent)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(28)
	panel:DockMargin(0, 10, 6, 5)
	panel.Paint = function(self, width, height)
		local ui = MilBase.UI
		local color = accent or ui.accent
		draw.SimpleText(text, "MB.Small", 2, height / 2, color,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("MB.Small")
		local textWidth = surface.GetTextSize(text)
		surface.SetDrawColor(color.r, color.g, color.b, 45)
		surface.DrawRect(textWidth + 12, height / 2, math.max(0, width - textWidth - 14), 1)
	end
	return panel
end

local function buttonGrid(parent, definitions, columns)
	columns = columns or 2
	local rows = math.ceil(#definitions / columns)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(rows * 42)
	panel:DockMargin(0, 0, 6, 2)
	panel.Paint = nil
	panel.PerformLayout = function(self, width)
		local buttonWidth = math.floor((width - (columns - 1) * 7) / columns)
		for index, button in ipairs(self.buttons or {}) do
			local column = (index - 1) % columns
			local row = math.floor((index - 1) / columns)
			button:SetPos(column * (buttonWidth + 7), row * 42)
			button:SetSize(buttonWidth, 35)
		end
	end
	panel.buttons = {}
	for _, definition in ipairs(definitions) do
		local button = galaxyButton(panel, definition.label, definition.click, definition.color)
		if definition.enabled == false then button:SetEnabled(false) end
		panel.buttons[#panel.buttons + 1] = button
	end
	return panel
end

local function settingRow(parent, field, current)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(34)
	panel:DockMargin(0, 0, 6, 4)
	panel.Paint = function(self, width, height)
		local ui = MilBase.UI
		surface.SetDrawColor(255, 255, 255, 4)
		surface.DrawRect(0, 0, width, height)
		draw.SimpleText(field.label, "MB.Tiny", 9, height / 2, ui.dim,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local save = galaxyButton(panel, "SAVE", nil)
	save:Dock(RIGHT)
	save:SetWide(64)
	local entry = darkEntry(panel)
	entry:Dock(RIGHT)
	entry:SetWide(82)
	entry:DockMargin(0, 3, 7, 3)
	entry:SetNumeric(true)
	entry:SetText(tostring(current))
	save.DoClick = function()
		sendAdmin("runtime", { key = field.key, value = tonumber(entry:GetValue()) })
	end
	return panel
end

local function buildPlanetManager(parent, admin, canManage)
	local ui = MilBase.UI
	local search = darkEntry(parent, "Search planets...")
	search:Dock(TOP)
	search:SetTall(32)
	search:DockMargin(0, 0, 0, 7)

	local list = vgui.Create("DListView", parent)
	list:Dock(LEFT)
	list:SetWide(290)
	list:DockMargin(0, 0, 10, 0)
	list:SetMultiSelect(false)
	list:AddColumn("Planet")
	list:AddColumn("Control"):SetFixedWidth(82)
	list:AddColumn("Pressure"):SetFixedWidth(58)

	local editor = vgui.Create("DScrollPanel", parent)
	editor:Dock(FILL)

	local selected
	local function rebuildList()
		list:Clear()
		local term = string.lower(string.Trim(search:GetValue() or ""))
		for _, planet in ipairs(admin.planets or {}) do
			if term == "" or string.find(string.lower(planet.name), term, 1, true) then
				local line = list:AddLine(planet.name, string.upper(planet.allegiance),
					tostring(planet.pressure) .. "%")
				line.mb_planet = planet
			end
		end
	end

	local function label(text)
		local item = vgui.Create("DLabel", editor)
		item:Dock(TOP)
		item:SetTall(20)
		item:DockMargin(2, 4, 4, 2)
		item:SetFont("MB.Tiny")
		item:SetTextColor(ui.dim)
		item:SetText(text)
		return item
	end

	local function showEditor(planet)
		selected = planet
		editor:Clear()
		label("PLANET")
		local title = vgui.Create("DLabel", editor)
		title:Dock(TOP)
		title:SetTall(32)
		title:SetFont("MB.Med")
		title:SetTextColor(G.AllegianceColor(planet.allegiance))
		title:SetText(planet.name)

		label("OFFICIAL ALLEGIANCE")
		local allegiance = vgui.Create("DComboBox", editor)
		allegiance:Dock(TOP)
		allegiance:SetTall(30)
		allegiance:SetValue(planet.allegiance)
		for _, id in ipairs({ "republic", "neutral", "contested", "cis" }) do
			allegiance:AddChoice(G.AllegianceLabel(id), id, id == planet.allegiance)
		end
		allegiance.OnSelect = function(_, _, _, data) allegiance.mb_value = data end

		local function numberField(name, value, minimum, maximum)
			label(name)
			local number = vgui.Create("DNumberWang", editor)
			number:Dock(TOP)
			number:SetTall(28)
			number:SetMin(minimum)
			number:SetMax(maximum)
			number:SetDecimals(0)
			number:SetValue(value)
			return number
		end
		local republic = numberField("REPUBLIC OPINION (-100 TO 100)",
			planet.republicOpinion, -100, 100)
		local cis = numberField("CIS OPINION (-100 TO 100)", planet.cisOpinion, -100, 100)
		local pressure = numberField("CIS STRATEGIC PRESSURE (0 TO 100)",
			planet.pressure, 0, 100)

		label("LORE PROTECTION")
		local locked = vgui.Create("DCheckBoxLabel", editor)
		locked:Dock(TOP)
		locked:SetTall(28)
		locked:SetFont("MB.Small")
		locked:SetTextColor(ui.text)
		locked:SetText("Prevent automatic CIS capture")
		locked:SetValue(planet.locked and 1 or 0)

		local lockFaction = vgui.Create("DComboBox", editor)
		lockFaction:Dock(TOP)
		lockFaction:SetTall(28)
		lockFaction:SetValue(planet.lockFaction ~= "" and planet.lockFaction or "republic")
		for _, id in ipairs({ "republic", "neutral", "contested", "cis" }) do
			lockFaction:AddChoice(G.AllegianceLabel(id), id, id == planet.lockFaction)
		end
		lockFaction.mb_value = planet.lockFaction
		lockFaction.OnSelect = function(_, _, _, data) lockFaction.mb_value = data end

		label("MANAGEMENT NOTES")
		local note = darkEntry(editor, "Campaign or lore notes")
		note:Dock(TOP)
		note:SetTall(52)
		note:SetMultiline(true)
		note:SetText(planet.note or "")

		label("ORBITAL BLOCKADE")
		local blockade = (admin.orbitalBlockades or {})[planet.key]
		local blockadeStatus = vgui.Create("DLabel", editor)
		blockadeStatus:Dock(TOP)
		blockadeStatus:SetTall(24)
		blockadeStatus:SetFont("MB.Small")
		blockadeStatus:SetTextColor(blockade and (blockade.faction == "cis"
			and ui.danger or ui.accent) or ui.dim)
		blockadeStatus:SetText(blockade and (string.upper(blockade.faction)
			.. " PERIMETER ACTIVE") or "NO ORBITAL BLOCKADE")

		local blockadeActions = vgui.Create("DPanel", editor)
		blockadeActions:Dock(TOP)
		blockadeActions:SetTall(36)
		blockadeActions:DockMargin(0, 3, 5, 6)
		blockadeActions.Paint = nil
		local republicBlockade = galaxyButton(blockadeActions, "REPUBLIC", function()
			sendAdmin("blockade", { planet = planet.name, faction = "republic" })
		end, ui.accent)
		republicBlockade:Dock(LEFT)
		republicBlockade:SetWide(112)
		republicBlockade:SetEnabled(canManage)
		local cisBlockade = galaxyButton(blockadeActions, "CIS", function()
			sendAdmin("blockade", { planet = planet.name, faction = "cis" })
		end, ui.danger)
		cisBlockade:Dock(LEFT)
		cisBlockade:SetWide(82)
		cisBlockade:DockMargin(6, 0, 0, 0)
		cisBlockade:SetEnabled(canManage)
		local clearBlockade = galaxyButton(blockadeActions, "CLEAR", function()
			sendAdmin("blockade", { planet = planet.name, faction = "clear" })
		end, ui.warn)
		clearBlockade:Dock(LEFT)
		clearBlockade:SetWide(82)
		clearBlockade:DockMargin(6, 0, 0, 0)
		clearBlockade:SetEnabled(canManage)

		local actions = vgui.Create("DPanel", editor)
		actions:Dock(TOP)
		actions:SetTall(42)
		actions:DockMargin(0, 9, 5, 0)
		actions.Paint = nil

		local save = galaxyButton(actions, "SAVE PLANET", function()
			sendAdmin("planet", {
				key = planet.key,
				name = planet.name,
				allegiance = allegiance.mb_value or planet.allegiance,
				republicOpinion = republic:GetValue(),
				cisOpinion = cis:GetValue(),
				pressure = pressure:GetValue(),
				locked = locked:GetChecked(),
				lockFaction = lockFaction.mb_value or "",
				note = note:GetValue(),
			})
		end, ui.accent)
		save:Dock(LEFT)
		save:SetWide(150)
		save:SetEnabled(canManage)

		local locate = galaxyButton(actions, "SET CURRENT LOCATION", function()
			sendAdmin("set_location", { name = planet.name })
		end, ui.warn)
		locate:Dock(LEFT)
		locate:SetWide(185)
		locate:DockMargin(8, 0, 0, 0)
		locate:SetEnabled(canManage)
	end

	list.OnRowSelected = function(_, _, line)
		if line.mb_planet then showEditor(line.mb_planet) end
	end
	search.OnValueChange = rebuildList
	rebuildList()
	if admin.planets and admin.planets[1] then showEditor(admin.planets[1]) end
end

local function buildAdminContent(content)
	local ui = MilBase.UI
	local admin = G.AdminData or {}
	local runtime = admin.runtime or {}
	local public = admin.public or {}
	local level = LocalPlayer():MBStaffLevel()
	local canManage = LocalPlayer():IsListenServerHost()
		or level >= (gd.ManagementLevel or 6)

	local left = vgui.Create("DScrollPanel", content)
	left:Dock(LEFT)
	left:SetWide(math.min(500, math.floor(content:GetWide() * 0.46)))
	left:DockMargin(0, 0, 12, 0)

	local status = vgui.Create("DPanel", left)
	status:Dock(TOP)
	status:SetTall(104)
	status:DockMargin(0, 0, 6, 4)
	status.Paint = function(self, width, height)
		local active = public.active
		local accent = active and ui.danger or ui.accent
		paintBFPanel(width, height, accent)
		draw.SimpleText("GALAXY DIRECTOR", "MB.Big", 14, 8, ui.text)
		draw.SimpleText((public.currentPlanet or "Unknown") .. "   •   "
			.. math.floor((public.currentRisk or 0) * 100) .. "% THREAT",
			"MB.Small", 16, 45, accent)
		draw.SimpleText(active and ((active.title or active.kind) .. " / " .. (active.phase or ""))
			or "NO ACTIVE PRIORITY EVENT",
			"MB.Tiny", 16, 72, active and ui.danger or ui.dim)
		draw.SimpleText((admin.swuAvailable and "SWU ONLINE" or "SWU NOT DETECTED")
			.. "   •   " .. (public.activePlayers or 0) .. " ACTIVE PLAYERS",
			"MB.Tiny", width - 14, 92, ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
	end

	section(left, "SYSTEM SWITCHES  (staff)")
	local switches = {
		{ key = "enabled", label = "MASTER" },
		{ key = "encounters", label = "ENCOUNTERS" },
		{ key = "attacks", label = "CIS ATTACKS" },
		{ key = "simulation", label = "CIS STRATEGY", management = true },
	}
	local switchDefs = {}
	for _, switch in ipairs(switches) do
		local on = runtime[switch.key] == true
		switchDefs[#switchDefs + 1] = {
			label = switch.label .. ": " .. (on and "ON" or "OFF"),
			color = on and Color(95, 210, 130) or ui.danger,
			enabled = not switch.management or canManage,
			click = function() sendAdmin("runtime", { key = switch.key, value = not on }) end,
		}
	end
	buttonGrid(left, switchDefs, 2)

	section(left, "ENCOUNTER CONTROL  (staff)")
	local eventDefs = {}
	for _, definition in ipairs({
		{ "RANDOM CONTACT", "random" }, { "CIVILIAN", "civilian" },
		{ "PIRATES", "pirate" }, { "REPUBLIC", "republic" },
		{ "DISTRESS", "distress" }, { "CIS CONTACT", "cis" },
		{ "CIS CAPITAL RAID", "raid" },
	}) do
		eventDefs[#eventDefs + 1] = {
			label = definition[1],
			click = function() sendAdmin("force", { kind = definition[2] }) end,
			color = definition[2] == "raid" and ui.danger or ui.accent,
		}
	end
	buttonGrid(left, eventDefs, 2)
	buttonGrid(left, {
		{ label = "CANCEL EVENT", color = ui.danger,
			click = function() sendAdmin("cancel", { reason = "Cancelled from staff control." }) end },
		{ label = "ADVANCE RAID PHASE", color = ui.warn,
			click = function() sendAdmin("advance") end },
		{ label = "REPUBLIC VICTORY", color = Color(90, 210, 130),
			click = function() sendAdmin("resolve", { outcome = "republic" }) end },
		{ label = "CIS VICTORY", color = ui.danger,
			click = function() sendAdmin("resolve", { outcome = "cis" }) end },
	}, 2)

	section(left, "MAP ANCHORS  (staff)")
	buttonGrid(left, {
		{ label = "ADD BOARDING AT AIM", click = function()
			sendAdmin("anchor_add", { kind = "boarding", mode = "aim" })
		end },
		{ label = "ADD BOARDING AT SELF", click = function()
			sendAdmin("anchor_add", { kind = "boarding", mode = "self" })
		end },
		{ label = "SET DRILL-POD ZONE", color = ui.danger, click = function()
			sendAdmin("anchor_add", { kind = "boarding_drill", mode = "aim" })
		end },
		{ label = "SET DROPSHIP ZONE", color = ui.warn, click = function()
			sendAdmin("anchor_add", { kind = "boarding_dropship", mode = "aim" })
		end },
		{ label = "SET PLAYER CIS ZONE", color = Color(190, 105, 235), click = function()
			sendAdmin("anchor_add", { kind = "boarding_player", mode = "aim" })
		end },
		{ label = "ADD IMPACT AT AIM", color = ui.warn, click = function()
			sendAdmin("anchor_add", { kind = "impact", mode = "aim" })
		end },
		{ label = "SET BREACH DOOR AT AIM", color = ui.danger, click = function()
			sendAdmin("anchor_add", { kind = "breach_door", mode = "aim" })
		end },
		{ label = "SET MUNIFICENT AT AIM", color = Color(190, 105, 235), click = function()
			sendAdmin("anchor_add", { kind = "capital", mode = "aim" })
		end },
		{ label = "SET SPACE BATTLE AT AIM", color = ui.accent, click = function()
			sendAdmin("anchor_add", { kind = "space_battle", mode = "aim" })
		end },
		{ label = "SET SPACE BATTLE AT SELF", color = ui.accent, click = function()
			sendAdmin("anchor_add", { kind = "space_battle", mode = "self" })
		end },
	}, 2)

	for _, anchor in ipairs(admin.anchors or {}) do
		local row = vgui.Create("DPanel", left)
		row:Dock(TOP)
		row:SetTall(31)
		row:DockMargin(0, 0, 6, 3)
		row.Paint = function(self, width, height)
			surface.SetDrawColor(255, 255, 255, 4)
			surface.DrawRect(0, 0, width, height)
			draw.SimpleText(string.upper(anchor.kind) .. "   " .. (anchor.label or ""),
				"MB.Tiny", 9, height / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		local remove = galaxyButton(row, "REMOVE", function()
			sendAdmin("anchor_delete", { id = anchor.id })
		end, ui.danger)
		remove:Dock(RIGHT)
		remove:SetWide(74)
	end

	local spawnInfo = vgui.Create("DLabel", left)
	spawnInfo:Dock(TOP)
	spawnInfo:SetTall(25)
	spawnInfo:SetFont("MB.Tiny")
	spawnInfo:SetTextColor(ui.faint)
	spawnInfo:SetText("Existing Event Enemy spawns also used: "
		.. (admin.eventEnemySpawnCount or 0))

	if canManage then
		section(left, "REPUTATION RECOMMENDATIONS  (management)")
		for _, recommendation in ipairs(admin.recommendations or {}) do
			local row = vgui.Create("DPanel", left)
			row:Dock(TOP)
			row:SetTall(74)
			row:DockMargin(0, 0, 6, 5)
			row.Paint = function(self, width, height)
				paintBFPanel(width, height, ui.warn, Color(255, 255, 255, 4))
				draw.SimpleText(recommendation.planet .. "   REP "
					.. string.format("%+d", recommendation.republicDelta)
					.. "   CIS " .. string.format("%+d", recommendation.cisDelta),
					"MB.Small", 10, 9, ui.text)
				draw.SimpleText(recommendation.reason, "MB.Tiny", 10, 31, ui.dim)
				draw.SimpleText(recommendation.source or "", "MB.Tiny", 10, 54, ui.faint)
			end
			local approve = galaxyButton(row, "APPROVE", function()
				sendAdmin("recommendation", { id = recommendation.id, decision = "approve" })
			end, Color(90, 210, 130))
			approve:SetSize(78, 25)
			approve:SetPos(left:GetWide() - 184, 42)
			local reject = galaxyButton(row, "REJECT", function()
				sendAdmin("recommendation", { id = recommendation.id, decision = "reject" })
			end, ui.danger)
			reject:SetSize(78, 25)
			reject:SetPos(left:GetWide() - 99, 42)
		end

		section(left, "LIVE CONFIGURATION  (management)")
		for _, field in ipairs(gd.RuntimeFields or {}) do
			settingRow(left, field, runtime[field.key])
		end
		buttonGrid(left, {
			{ label = "RUN CIS STRATEGY TICK", color = ui.danger,
				click = function() sendAdmin("simulation_tick") end },
			{ label = "TEST DISCORD", color = ui.accent,
				click = function() sendAdmin("discord_test") end },
		}, 2)
	end

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL)
	right.Paint = nil
	section(right, "PLANET MANAGEMENT"
		.. (canManage and "" or "  (view only — management required)"))
	local manager = vgui.Create("DPanel", right)
	manager:Dock(FILL)
	manager.Paint = nil
	buildPlanetManager(manager, admin, canManage)

	G.RebuildAdmin = function()
		if not IsValid(content) then G.RebuildAdmin = nil return end
		content:Clear()
		buildAdminContent(content)
	end
end

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["GALAXY DIRECTOR"] = true

MilBase.AddMenuTab("GALAXY DIRECTOR", 96, function(content)
	buildAdminContent(content)
	requestAdmin()
end, function(ply)
	return IsValid(ply) and (ply:IsListenServerHost()
		or ply:MBStaffLevel() >= (gd.StaffLevel or 3))
end)
