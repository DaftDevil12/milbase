--[[
	Disease / bio-warfare core.

	Event staff author viruses (F4 BIO-LAB tab, staff-only) and infect players
	(/infect <id> while aiming). A virus has phases; each phase runs a set of
	effects (poison, hallucinations, coughing, voices, etc). Contagious viruses
	spread to nearby unsealed players. Medics research a cure (sh_biolab.lua).

	Networked per-player: mb_virus (id), mb_infphase (0=incubation,1..n), and
	mb_infslow (movement factor). Clients derive the active visual effects from
	the synced virus definition, so individual effects aren't networked.
]]

local cfg = MilBase.Config

MilBase.Viruses = MilBase.Viruses or {}      -- [id] = def
MilBase.VirusEffects = MilBase.VirusEffects or {}
MilBase.VirusEffectOrder = MilBase.VirusEffectOrder or {}

function MilBase.RegisterVirus(id, def)
	def.id = id
	MilBase.Viruses[id] = def
end

local function regEffect(id, data)
	data.id = id
	MilBase.VirusEffects[id] = data
	MilBase.VirusEffectOrder[#MilBase.VirusEffectOrder + 1] = id
end

--------------------------------------------------------------------------
-- Effect palette. server=fn(ply,p) runs each 1s tick. Visual-only effects
-- are flagged client=true and handled in the client render code by id.
--------------------------------------------------------------------------

regEffect("dot", { name = "Necrosis (damage/sec)", cat = "Damage", client = false,
	server = function(ply, p)
		local dmg = DamageInfo()
		dmg:SetDamage(p.rate or 3)
		dmg:SetDamageType(DMG_POISON)
		dmg:SetAttacker(game.GetWorld())
		ply:TakeDamageInfo(dmg)
	end })

regEffect("weakness", { name = "Weakness (-max HP)", cat = "Damage",
	server = function(ply, p)
		local base = MilBase.CalcMaxHealth and MilBase.CalcMaxHealth(ply) or ply:GetMaxHealth()
		local mx = math.max(1, base - (p.amount or 40))
		ply:SetMaxHealth(mx)
		if ply:Health() > mx then ply:SetHealth(mx) end
	end })

regEffect("stamina", { name = "Fatigue (drains stamina)", cat = "Damage",
	server = function(ply, p)
		ply:SetNWFloat("mb_stamina", math.max(0, ply:GetNWFloat("mb_stamina", 100) - (p.rate or 12)))
	end })

regEffect("slow", { name = "Sluggish (slowed movement)", cat = "Movement",
	slow = function(p) return p.factor or 0.6 end })

regEffect("stumble", { name = "Convulsions (stumbling)", cat = "Movement",
	server = function(ply, p)
		if ply:OnGround() and math.random() < (p.chance or 0.15) then
			ply:SetVelocity(VectorRand() * Vector(180, 180, 0) + Vector(0, 0, 60))
		end
	end })

regEffect("cough", { name = "Coughing (audible)", cat = "Senses",
	server = function(ply, p)
		if (ply.mb_nextCough or 0) > CurTime() then return end
		ply.mb_nextCough = CurTime() + math.Rand(3, 7)
		ply:EmitSound("ambient/voices/cough" .. math.random(1, 4) .. ".wav", 70, math.random(90, 105))
	end })

regEffect("tremor",      { name = "Tremors (aim sway)",       cat = "Movement", client = true })
regEffect("hallucinate", { name = "Hallucinations (B1 models)", cat = "Mind",   client = true })
regEffect("voices",      { name = "Voices in the head",       cat = "Mind",     client = true })
regEffect("blur",        { name = "Blurred vision",           cat = "Senses",   client = true })
regEffect("tint",        { name = "Sickly vision (tint)",     cat = "Senses",   client = true })
regEffect("fever",       { name = "Fever (screen shake)",     cat = "Senses",   client = true })

-- Active effect table for a player's current phase (nil if not infected/active).
function MilBase.ActiveEffects(ply)
	local vid = ply:GetNWString("mb_virus", "")
	if vid == "" then return nil end
	local v = MilBase.Viruses[vid]
	local phase = ply:GetNWInt("mb_infphase", 0)
	local pd = v and v.phases and v.phases[phase]
	return pd and pd.effects or nil, v
end

--------------------------------------------------------------------------
-- Movement slow (both realms, for prediction) via the networked factor.
--------------------------------------------------------------------------
hook.Add("SetupMove", "MilBase.DiseaseSlow", function(ply, mv)
	local f = ply:GetNWFloat("mb_infslow", 1)
	if f < 1 then
		mv:SetMaxSpeed(mv:GetMaxSpeed() * f)
		mv:SetMaxClientSpeed(mv:GetMaxClientSpeed() * f)
	end
end)

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_Viruses")
	util.AddNetworkString("MilBase_SaveVirus")
	util.AddNetworkString("MilBase_DeleteVirus")
	util.AddNetworkString("MilBase_Infect")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_viruses (id VARCHAR(64) PRIMARY KEY, data TEXT)")

	local function loadViruses()
		MilBase.DB.Query("SELECT * FROM frontier_viruses", function(rows)
			for _, row in ipairs(rows) do
				local def = util.JSONToTable(row.data)
				if def then def.id = row.id; MilBase.Viruses[row.id] = def end
			end
		end)
	end
	loadViruses()

	local function syncViruses(target)
		net.Start("MilBase_Viruses")
			net.WriteString(util.TableToJSON(MilBase.Viruses))
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	hook.Add("PlayerInitialSpawn", "MilBase.VirusSync", function(ply)
		timer.Simple(3, function() if IsValid(ply) then syncViruses(ply) end end)
	end)

	MilBase.VirusResearch = MilBase.VirusResearch or {} -- [vid] = { discovered = {}, count }

	--------------------------------------------------------------------
	-- Infect / cure
	--------------------------------------------------------------------

	function MilBase.Infect(ply, vid, opts)
		opts = opts or {}
		if cfg.DiseaseEnabled == false then return false end
		if not (IsValid(ply) and ply:Alive()) then return false end
		local v = MilBase.Viruses[vid]
		if not v then return false end
		if ply:GetNWString("mb_virus", "") ~= "" then return false end -- already sick
		if not opts.bypassSeal then
			if ply:GetNWBool("mb_sealed", false) then return false end
			if (ply.mb_immuneUntil or 0) > CurTime() then return false end
		end

		ply:SetNWString("mb_virus", vid)
		ply:SetNWInt("mb_infphase", 0) -- incubation
		ply.mb_phaseEnd = CurTime() + (v.incubation or 0)
		ply:SetNWBool("mb_infected", true)
		ply:SetNWFloat("mb_infslow", 1)

		-- Seed the research entry so medics have a component target.
		MilBase.VirusResearch[vid] = MilBase.VirusResearch[vid]
			or { discovered = {}, count = 0 }
		return true
	end

	function MilBase.Cure(ply, opts)
		if ply:GetNWString("mb_virus", "") == "" then return false end
		ply:SetNWString("mb_virus", "")
		ply:SetNWInt("mb_infphase", 0)
		ply:SetNWBool("mb_infected", false)
		ply:SetNWFloat("mb_infslow", 1)
		ply.mb_phaseEnd = nil
		if MilBase.CalcMaxHealth then ply:SetMaxHealth(MilBase.CalcMaxHealth(ply)) end
		ply.mb_immuneUntil = CurTime() + ((opts and opts.immunity) or 60)
		ply:EmitSound("items/smallmedkit1.wav", 65)
		return true
	end

	-- Clear infection on respawn (mirrors clearInjuries in sh_medical).
	hook.Add("PlayerSpawn", "MilBase.DiseaseReset", function(ply)
		ply:SetNWString("mb_virus", "")
		ply:SetNWInt("mb_infphase", 0)
		ply:SetNWBool("mb_infected", false)
		ply:SetNWFloat("mb_infslow", 1)
		ply.mb_phaseEnd = nil
	end)

	local function advancePhase(ply, v)
		local next = ply:GetNWInt("mb_infphase", 0) + 1
		if v.phases and v.phases[next] then
			ply:SetNWInt("mb_infphase", next)
			ply.mb_phaseEnd = CurTime() + (v.phases[next].duration or 60)
			MilBase.Notify(ply, "You feel worse... (" .. v.name .. " — stage " .. next .. ")")
			return
		end

		-- No further phase: resolve the outcome.
		local outcome = v.outcome or "recover"
		if outcome == "death" then
			ply:TakeDamage(ply:Health() + 50, game.GetWorld())
			MilBase.Cure(ply)
		elseif outcome == "chronic" then
			ply.mb_phaseEnd = CurTime() + 9999 -- stays at the last stage
		else -- recover
			MilBase.Cure(ply)
			MilBase.Notify(ply, "The infection has run its course. You recover.")
		end
	end

	local spreadAccum = 0
	local nextTick = 0
	hook.Add("Think", "MilBase.DiseaseThink", function()
		if cfg.DiseaseEnabled == false or CurTime() < nextTick then return end
		nextTick = CurTime() + 1
		local doSpread = false
		spreadAccum = spreadAccum + 1
		if spreadAccum >= (cfg.DiseaseSpreadInterval or 3) then spreadAccum = 0; doSpread = true end

		for _, ply in ipairs(player.GetAll()) do
			if not ply:Alive() then continue end
			local vid = ply:GetNWString("mb_virus", "")
			if vid == "" then continue end
			local v = MilBase.Viruses[vid]
			if not v then continue end

			-- Phase timing.
			if (ply.mb_phaseEnd or 0) <= CurTime() then
				advancePhase(ply, v)
				if ply:GetNWString("mb_virus", "") == "" then continue end
			end

			local effects = select(1, MilBase.ActiveEffects(ply)) or {}

			-- Normalise max HP each tick so the `weakness` effect re-derives
			-- cleanly (and restores once it's no longer in the active phase).
			if MilBase.CalcMaxHealth then ply:SetMaxHealth(MilBase.CalcMaxHealth(ply)) end

			-- Server-side effects + movement factor.
			local slow = 1
			for eid, p in pairs(effects) do
				local eff = MilBase.VirusEffects[eid]
				if eff then
					if eff.server then eff.server(ply, p or {}) end
					if eff.slow then slow = math.min(slow, eff.slow(p or {})) end
				end
			end
			ply:SetNWFloat("mb_infslow", slow)

			-- Contagion.
			if doSpread and v.contagious and ply:GetNWInt("mb_infphase", 0) >= 1 then
				local range = v.spreadRange or 300
				for _, other in ipairs(ents.FindInSphere(ply:GetPos(), range)) do
					if other:IsPlayer() and other ~= ply and other:Alive()
					and other:GetNWString("mb_virus", "") == ""
					and not other:GetNWBool("mb_sealed", false)
					and (other.mb_immuneUntil or 0) < CurTime()
					and math.random() < (v.spreadChance or 0.2) then
						MilBase.Infect(other, vid)
					end
				end
			end
		end
	end)

	--------------------------------------------------------------------
	-- Staff net: author viruses, infect
	--------------------------------------------------------------------

	net.Receive("MilBase_SaveVirus", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local def = util.JSONToTable(net.ReadString())
		if not istable(def) or not isstring(def.id) or def.id == "" then return end
		def.id = string.lower(string.gsub(def.id, "%s+", "_"))

		MilBase.Viruses[def.id] = def
		MilBase.DB.Run(string.format("REPLACE INTO frontier_viruses (id, data) VALUES (%s, %s)",
			MilBase.SQLStr(def.id), MilBase.SQLStr(util.TableToJSON(def))))
		syncViruses()
		MilBase.Notify(ply, "Virus saved: " .. (def.name or def.id))
	end)

	net.Receive("MilBase_DeleteVirus", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local id = net.ReadString()
		MilBase.Viruses[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_viruses WHERE id = " .. MilBase.SQLStr(id))
		syncViruses()
	end)

	net.Receive("MilBase_Infect", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local vid = net.ReadString()
		local tr = ply:GetEyeTrace()
		local target = tr.Entity
		if not (IsValid(target) and target:IsPlayer()) then
			MilBase.Notify(ply, "Aim at a player to infect them.")
			return
		end
		if MilBase.Infect(target, vid, { bypassSeal = true }) then
			MilBase.Notify(ply, "Infected " .. target:MBName() .. " with " ..
				(MilBase.Viruses[vid].name or vid) .. ".")
		else
			MilBase.Notify(ply, "Couldn't infect (already sick, dead, or unknown virus).")
		end
	end)

	MilBase.RegisterChatCommand("infect", {
		help = "(Event staff) Infect the player you're aiming at: /infect <virus id>",
		func = function(ply, args)
			if not MilBase.CanRunEvents(ply) then
				MilBase.Notify(ply, "Event staff only.")
				return
			end
			local vid = string.lower(args[1] or "")
			if not MilBase.Viruses[vid] then
				MilBase.Notify(ply, "Unknown virus. Open the BIO-LAB tab to see/create viruses.")
				return
			end
			local target = ply:GetEyeTrace().Entity
			if IsValid(target) and target:IsPlayer() then
				MilBase.Infect(target, vid, { bypassSeal = true })
				MilBase.Notify(ply, "Infected " .. target:MBName() .. ".")
			else
				MilBase.Notify(ply, "Aim at a player.")
			end
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: sync, visual effects, staff editor + BIO-LAB tab
--------------------------------------------------------------------------

net.Receive("MilBase_Viruses", function()
	MilBase.Viruses = util.JSONToTable(net.ReadString()) or {}
end)

local function localEffects()
	return MilBase.ActiveEffects(LocalPlayer())
end

-- Blur + sickly tint.
local sickTint = {
	["$pp_colour_addr"] = 0, ["$pp_colour_addg"] = 0.05, ["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = -0.04, ["$pp_colour_contrast"] = 0.92,
	["$pp_colour_colour"] = 0.55, ["$pp_colour_mulr"] = 0, ["$pp_colour_mulg"] = 0.12, ["$pp_colour_mulb"] = 0,
}
hook.Add("RenderScreenspaceEffects", "MilBase.DiseaseFX", function()
	local e = localEffects()
	if not e then return end
	if e.tint then DrawColorModify(sickTint) end
	if e.blur then DrawMotionBlur(0.28, 0.75, 0.008) end
end)

-- Fever/tremor view sway.
hook.Add("CalcView", "MilBase.DiseaseView", function(ply, pos, ang, fov)
	local e = localEffects()
	if not e then return end
	local t = CurTime()
	local sway = 0
	if e.fever then sway = sway + 0.6 end
	if e.tremor then sway = sway + 0.9 end
	if sway <= 0 then return end
	local a = Angle(ang.p + math.sin(t * 13) * sway * 0.4, ang.y + math.cos(t * 11) * sway * 0.4, ang.r)
	return { origin = pos, angles = a, fov = fov }
end)

-- Hallucination: swap other players' clientside models. Restores on cure.
local swapped = {}
hook.Add("Think", "MilBase.DiseaseHallucinate", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local e = localEffects()
	local model = cfg.HallucinationModel
	local active = e and e.hallucinate and model and util.IsValidModel(model)

	if active then
		for _, other in ipairs(player.GetAll()) do
			if other ~= lp and IsValid(other) and other:GetModel() ~= model then
				swapped[other] = swapped[other] or other:GetModel()
				other:SetModel(model)
			end
		end
	elseif next(swapped) then
		for other, real in pairs(swapped) do
			if IsValid(other) then other:SetModel(real) end
			swapped[other] = nil
		end
	end
end)

-- Coughing/voices client sounds + infected HUD readout.
local WHISPERS = { "they know", "don't trust them", "run", "it's inside you", "they're not real" }
hook.Add("Think", "MilBase.DiseaseSounds", function()
	local e = localEffects()
	if not e then return end
	local lp = LocalPlayer()
	if e.voices and (lp.mb_nextVoice or 0) < CurTime() then
		lp.mb_nextVoice = CurTime() + math.Rand(6, 12)
		surface.PlaySound("ambient/voices/m_scream1.wav")
		lp.mb_voiceText = { text = WHISPERS[math.random(#WHISPERS)], until_ = CurTime() + 3 }
	end
end)

hook.Add("HUDPaint", "MilBase.DiseaseHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local e, v = localEffects()

	if lp.mb_voiceText and lp.mb_voiceText.until_ > CurTime() then
		draw.SimpleTextOutlined(lp.mb_voiceText.text, "MB.Med",
			ScrW() / 2 + math.sin(CurTime() * 3) * 40, ScrH() * 0.35,
			Color(180, 60, 60, 200 * ((lp.mb_voiceText.until_ - CurTime()) / 3)),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end

	local vid = lp:GetNWString("mb_virus", "")
	if vid == "" then return end
	local ui = MilBase.UI
	local phase = lp:GetNWInt("mb_infphase", 0)
	local label = phase == 0 and "INCUBATING" or ("STAGE " .. phase)
	draw.SimpleTextOutlined("☣ INFECTED — " .. ((v and v.name) or "?") .. "  (" .. label .. ")",
		"MB.Small", ScrW() / 2, ScrH() - 92, Color(150, 210, 90),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end)

hook.Add("EntityRemoved", "MilBase.DiseaseSwapCleanup", function(ent)
	swapped[ent] = nil
end)

--------------------------------------------------------------------------
-- BIO-LAB staff tab: virus list + editor
--------------------------------------------------------------------------

local EDIT_PHASES = 2 -- authored viruses have 2 phases

local CAT_COLOR = {
	Damage   = Color(220, 90, 80),
	Movement = Color(240, 190, 70),
	Mind     = Color(180, 120, 220),
	Senses   = Color(90, 180, 230),
}

--------------------------------------------------------------------------
-- Sleek widget kit (MilBase BF2 styling) shared by the editor + archive
--------------------------------------------------------------------------

local function sleekFrame(w, h, title, subtitle)
	local ui = MilBase.UI
	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h); frame:Center(); frame:MakePopup()
	frame:SetTitle(""); frame:ShowCloseButton(false); frame:SetDraggable(true)
	frame.Paint = function(self, fw, fh)
		MilBase.DrawBlur(self, 5)
		MilBase.DrawPanelBF2(0, 0, fw, fh, { cut = 12, color = Color(8, 9, 11, 248), accent = ui.accent })
		draw.SimpleText(title, "MB.Tab", 22, 13, ui.text)
		if subtitle then draw.SimpleText(subtitle, "MB.Tiny", 24, 40, ui.dim) end
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 90)
		surface.DrawRect(22, 53, fw - 44, 1)
	end
	frame.Think = function(self)
		if gui.IsGameUIVisible() then gui.HideGameUI() self:Remove() end
	end

	local close = vgui.Create("DButton", frame)
	close:SetText(""); close:SetSize(30, 30); close:SetPos(w - 38, 12)
	close.Paint = function(s, cw, ch)
		draw.SimpleText("✕", "MB.Med", cw / 2, ch / 2 - 1,
			s:IsHovered() and ui.danger or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Remove() end

	local body = vgui.Create("DScrollPanel", frame)
	body:SetPos(18, 62); body:SetSize(w - 36, h - 62 - 58)
	return frame, body
end

local function section(parent, text)
	local p = vgui.Create("DPanel", parent); p:Dock(TOP); p:SetTall(24); p:DockMargin(0, 14, 0, 6)
	p.Paint = function(s, w, h)
		local ui = MilBase.UI
		draw.SimpleText(text, "MB.Small", 2, h / 2, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		surface.SetFont("MB.Small")
		local tw = surface.GetTextSize(text)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 45)
		surface.DrawRect(tw + 12, h / 2, math.max(0, w - tw - 14), 1)
	end
	return p
end

local function entryRow(parent, value, onChange, placeholder, enabled)
	local e = vgui.Create("DTextEntry", parent)
	e:Dock(TOP); e:SetTall(30); e:DockMargin(0, 0, 0, 4)
	e:SetFont("MB.Small"); e:SetText(value or ""); e:SetPaintBackground(false)
	if placeholder then e:SetPlaceholderText(placeholder) end
	if enabled == false then e:SetEnabled(false) end
	e.OnChange = function(s) onChange(s:GetValue()) end
	e.Paint = function(self, w, h)
		local ui = MilBase.UI
		surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end
	return e
end

local function toggle(parent, label, get, set)
	local b = vgui.Create("DButton", parent); b:Dock(TOP); b:SetTall(30); b:DockMargin(0, 0, 0, 4); b:SetText("")
	b.Paint = function(s, w, h)
		local ui = MilBase.UI
		local on = get()
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = on and Color(ui.accent.r, ui.accent.g, ui.accent.b, 28) or ui.raised,
			accent = on and ui.accent or nil })
		surface.SetDrawColor(on and ui.accent or ui.faint)
		surface.DrawOutlinedRect(10, h / 2 - 8, 16, 16)
		if on then surface.SetDrawColor(ui.accent); surface.DrawRect(13, h / 2 - 5, 10, 10) end
		draw.SimpleText(label, "MB.Small", 36, h / 2, on and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function() set(not get()) end
	return b
end

local function stepperRow(parent, label, get, set, lo, hi, step, suffix)
	local ui = MilBase.UI
	local row = vgui.Create("DPanel", parent); row:Dock(TOP); row:SetTall(30); row:DockMargin(0, 0, 0, 4)
	row.Paint = function(s, w, h)
		draw.SimpleText(label, "MB.Small", 4, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local function chBtn(sym, dir)
		local b = vgui.Create("DButton", row); b:SetText(""); b:SetSize(28, 24)
		b.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5, color = s:IsHovered() and ui.hover or ui.raised })
			draw.SimpleText(sym, "MB.Med", w / 2, h / 2 - 1, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function() set(math.Clamp(get() + dir * step, lo, hi)) end
		return b
	end
	local dec, inc = chBtn("−", -1), chBtn("+", 1)
	local val = vgui.Create("DPanel", row); val:SetSize(78, 24)
	val.Paint = function(s, w, h)
		surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
		draw.SimpleText(get() .. (suffix or ""), "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	row.PerformLayout = function(s, w, h)
		inc:SetPos(w - 28, 3); val:SetPos(w - 28 - 82, 3); dec:SetPos(w - 28 - 82 - 32, 3)
	end
	return row
end

local function effectRow(parent, eff, get, set)
	local col = CAT_COLOR[eff.cat] or MilBase.UI.accent
	local b = vgui.Create("DButton", parent); b:Dock(TOP); b:SetTall(28); b:DockMargin(0, 0, 0, 3); b:SetText("")
	b.Paint = function(s, w, h)
		local ui = MilBase.UI
		local on = get()
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
			color = on and Color(col.r, col.g, col.b, 34) or Color(255, 255, 255, 4) })
		surface.SetDrawColor(col.r, col.g, col.b, on and 255 or 70); surface.DrawRect(0, 4, 3, h - 8)
		if on then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(eff.name, "MB.Small", 14, h / 2, on and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.upper(eff.cat), "MB.Tiny", w - 10, h / 2, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	b.DoClick = function() set(not get()) end
	return b
end

local function segmented(parent, options, get, set)
	local row = vgui.Create("DPanel", parent); row:Dock(TOP); row:SetTall(34); row:DockMargin(0, 0, 0, 4); row.Paint = nil
	local btns = {}
	for i, o in ipairs(options) do
		local b = vgui.Create("DButton", row); b:SetText("")
		b.Paint = function(s, w, h)
			local on = get() == o.value
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
				color = on and Color(o.color.r, o.color.g, o.color.b, 48) or MilBase.UI.raised,
				accent = on and o.color or nil })
			if on then MilBase.DrawBrackets(2, 2, w - 4, h - 4, o.color, 7) end
			draw.SimpleText(o.label, "MB.Small", w / 2, h / 2,
				on and MilBase.UI.text or MilBase.UI.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function() set(o.value) end
		btns[i] = b
	end
	row.PerformLayout = function(s, w, h)
		local bw = (w - (#options - 1) * 6) / #options
		for i, b in ipairs(btns) do b:SetPos((i - 1) * (bw + 6), 0); b:SetSize(bw, h) end
	end
	return row
end

--------------------------------------------------------------------------
-- Virus editor
--------------------------------------------------------------------------

local function openEditor(existing)
	local ui = MilBase.UI
	local def = existing and table.Copy(existing) or {
		id = "", name = "New Virus", contagious = false, spreadRange = 300,
		spreadChance = 0.2, incubation = 8, outcome = "recover",
		phases = { [1] = { duration = 40, effects = {} }, [2] = { duration = 40, effects = {} } },
	}
	def.phases = def.phases or {}
	for i = 1, EDIT_PHASES do def.phases[i] = def.phases[i] or { duration = 40, effects = {} } end

	local frame, body = sleekFrame(660, 700, "VIRUS DESIGNER",
		existing and ("Editing  " .. string.upper(def.name or def.id or "")) or "Author a new pathogen")

	section(body, "IDENTITY")
	entryRow(body, def.name, function(v) def.name = v end, "Virus name")
	entryRow(body, def.id, function(v) def.id = v end, "virus id (lowercase, no spaces)", not existing)

	section(body, "CONTAGION & ONSET")
	toggle(body, "Contagious — spreads to nearby unsealed players",
		function() return def.contagious end, function(v) def.contagious = v end)
	stepperRow(body, "Spread range", function() return def.spreadRange end,
		function(v) def.spreadRange = v end, 100, 2000, 50, "u")
	stepperRow(body, "Spread chance", function() return math.Round((def.spreadChance or 0.2) * 100) end,
		function(v) def.spreadChance = v / 100 end, 5, 100, 5, "%")
	stepperRow(body, "Incubation", function() return def.incubation or 0 end,
		function(v) def.incubation = v end, 0, 120, 2, "s")

	for n = 1, EDIT_PHASES do
		section(body, "PHASE " .. n .. " — SYMPTOMS")
		local pd = def.phases[n]
		stepperRow(body, "Duration", function() return pd.duration end,
			function(v) pd.duration = v end, 5, 600, 5, "s")
		for _, eid in ipairs(MilBase.VirusEffectOrder) do
			local eff = MilBase.VirusEffects[eid]
			effectRow(body, eff,
				function() return pd.effects[eid] ~= nil end,
				function(on) pd.effects[eid] = on and (pd.effects[eid] or {}) or nil end)
		end
	end

	section(body, "OUTCOME  (after the final phase)")
	segmented(body, {
		{ label = "RECOVER", value = "recover", color = ui.ok },
		{ label = "DEATH",   value = "death",   color = ui.danger },
		{ label = "CHRONIC", value = "chronic", color = ui.warn },
	}, function() return def.outcome or "recover" end, function(v) def.outcome = v end)

	local save = vgui.Create("DButton", frame); save:SetText(""); save:SetSize(160, 36)
	save:SetPos(660 - 160 - 20, 700 - 48)
	save.Paint = function(s, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7,
			color = s:IsHovered() and Color(ui.ok.r, ui.ok.g, ui.ok.b, 60) or ui.raised, accent = ui.ok })
		MilBase.DrawBrackets(2, 2, w - 4, h - 4, ui.ok, 7)
		draw.SimpleText("SAVE VIRUS", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	save.DoClick = function()
		if (def.id or "") == "" then def.id = string.lower(string.gsub(def.name or "virus", "%s+", "_")) end
		net.Start("MilBase_SaveVirus"); net.WriteString(util.TableToJSON(def)); net.SendToServer()
		frame:Remove()
	end

	local cancel = vgui.Create("DButton", frame); cancel:SetText(""); cancel:SetSize(110, 36)
	cancel:SetPos(660 - 160 - 20 - 120, 700 - 48)
	cancel.Paint = function(s, w, h)
		draw.SimpleText("CANCEL", "MB.Small", w / 2, h / 2,
			s:IsHovered() and ui.text or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	cancel.DoClick = function() frame:Remove() end
end
MilBase.OpenVirusEditor = openEditor

--------------------------------------------------------------------------
-- BIO-LAB archive tab
--------------------------------------------------------------------------

local function virusEffectSet(v)
	local set = {}
	for _, phase in pairs(v.phases or {}) do
		for eid in pairs(phase.effects or {}) do set[eid] = true end
	end
	return set
end

MilBase.AddMenuTab("BIO-LAB", 93, function(content)
	local ui = MilBase.UI

	local head = vgui.Create("DPanel", content); head:Dock(TOP); head:SetTall(44); head:DockMargin(0, 0, 0, 8)
	head.Paint = function(s, w, h)
		draw.SimpleText("BIO-LAB — PATHOGEN ARCHIVE", "MB.Tab", 2, 2, ui.text)
		draw.SimpleText("Author viruses, then  /infect <id>  while aiming at a player.",
			"MB.Tiny", 4, 30, ui.dim)
		MilBase.DrawIcon(ui.art.bf2.accentBar, 2, 26, 200, 3)
	end

	local newBtn = vgui.Create("DButton", content); newBtn:Dock(TOP); newBtn:SetTall(36); newBtn:DockMargin(0, 0, 8, 8)
	newBtn:SetText("")
	newBtn.Paint = function(s, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7,
			color = s:IsHovered() and Color(ui.ok.r, ui.ok.g, ui.ok.b, 55) or ui.raised, accent = ui.ok })
		if s:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, ui.ok, 7) end
		draw.SimpleText("+  DESIGN NEW VIRUS", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	newBtn.DoClick = function() openEditor() end

	local scroll = vgui.Create("DScrollPanel", content); scroll:Dock(FILL)

	for id, v in SortedPairs(MilBase.Viruses) do
		local dots = virusEffectSet(v)
		local card = vgui.Create("DPanel", scroll); card:Dock(TOP); card:SetTall(66); card:DockMargin(0, 0, 8, 6)
		card.Paint = function(s, w, h)
			local accent = v.contagious and ui.danger or ui.accent
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = accent })
			draw.SimpleText(string.upper(v.name or id), "MB.Med", 16, 10, ui.text)
			local info = "id: " .. id .. "   •   " .. (v.contagious and "CONTAGIOUS" or "CONTAINED")
				.. "   •   OUTCOME: " .. string.upper(v.outcome or "recover")
			draw.SimpleText(info, "MB.Tiny", 16, 36, v.contagious and ui.danger or ui.dim)

			local dx = 16
			for _, eid in ipairs(MilBase.VirusEffectOrder) do
				if dots[eid] then
					local eff = MilBase.VirusEffects[eid]
					MilBase.DrawDiamond(dx + 4, h - 12, 5, CAT_COLOR[eff.cat] or ui.accent)
					dx = dx + 15
					if dx > w - 130 then break end
				end
			end
		end

		local edit = vgui.Create("DButton", card); edit:SetText(""); edit:SetSize(64, 26)
		edit.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5, color = s:IsHovered() and ui.hover or ui.raised })
			draw.SimpleText("EDIT", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		edit.DoClick = function() openEditor(v) end

		local del = vgui.Create("DButton", card); del:SetText(""); del:SetSize(30, 26)
		del.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
				color = s:IsHovered() and Color(ui.danger.r, ui.danger.g, ui.danger.b, 60) or ui.raised })
			draw.SimpleText("✕", "MB.Small", w / 2, h / 2, s:IsHovered() and ui.text or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		del.DoClick = function()
			net.Start("MilBase_DeleteVirus"); net.WriteString(id); net.SendToServer()
			card:Remove()
		end

		card.PerformLayout = function(s, w, h)
			del:SetPos(w - 38, 11); edit:SetPos(w - 38 - 68, 11)
		end
	end
end, function(lp) return MilBase.CanRunEvents and MilBase.CanRunEvents(lp) end)
