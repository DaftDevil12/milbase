--[[
	Quartermaster module.

	Staff place persistent Quartermaster NPCs per-map with /quartermaster.
	Players press E on the NPC to retrieve basic gear selected from their
	Faction + Rank Group + Certifications. The important example is built in:
	104th + officer/commander rank + Field Medic cert => 104th Medic Officer armor.
]]

local cfg = MilBase.Config

MilBase.Quartermaster = MilBase.Quartermaster or {}

local function mergeTargets(out, items)
	for id, amount in pairs(items or {}) do
		amount = math.max(0, math.floor(tonumber(amount) or 0))
		if amount > 0 then out[id] = math.max(out[id] or 0, amount) end
	end
end

local function itemExists(id)
	return isstring(id) and MilBase.Items and MilBase.Items[id] ~= nil
end

local function firstExisting(candidates)
	for _, id in ipairs(candidates or {}) do
		if itemExists(id) then return id end
	end
end

local function factionLoadout(ply)
	local all = cfg.QuartermasterFactionLoadouts or {}
	local faction = ply:MBFaction()
	return all[ply:MBFactionID()] or (faction and all[faction.name]) or all.default or {}
end

function MilBase.QuartermasterRankGroup(ply)
	local rank = ply:MBRank()
	if not rank then return "trp" end
	if isstring(rank.quartermasterGroup) and rank.quartermasterGroup ~= "" then
		return string.lower(rank.quartermasterGroup)
	end

	local name = string.lower(rank.name or "")
	local groups = cfg.QuartermasterRankGroups or {}
	for _, group in ipairs({ "commander", "officer", "nco" }) do
		for _, token in ipairs(groups[group] or {}) do
			if token ~= "" and string.find(name, string.lower(token), 1, true) then
				return group
			end
		end
	end

	return "trp"
end

function MilBase.QuartermasterArmorRole(ply)
	for certID, role in pairs(cfg.QuartermasterCertArmorRoles or {}) do
		if ply:MBHasCert(certID) then return string.lower(role) end
	end
end

function MilBase.QuartermasterArmorID(ply)
	-- A certification-specific armor selection is the most explicit rule and
	-- therefore overrides the older role-name/prefix heuristics below. CertOrder
	-- provides deterministic priority when a character holds multiple overrides.
	for _, certID in ipairs(MilBase.CertOrder or {}) do
		if ply:MBHasCert(certID) then
			local cert = MilBase.Certs[certID]
			local armorID = cert and cert.armor
			local armor = armorID and MilBase.Items and MilBase.Items[armorID]
			if armor and armor.slot == "armor" then return armorID end
		end
	end

	local loadout = factionLoadout(ply)
	local armor = loadout.armor or {}
	local prefix = loadout.armorPrefix
	local rankGroup = MilBase.QuartermasterRankGroup(ply)
	local role = MilBase.QuartermasterArmorRole(ply)
	local candidates = {}

	local function add(id)
		if id and id ~= "" then candidates[#candidates + 1] = id end
	end
	local function addKey(key)
		add(armor[key])
		if prefix then add("armor_" .. prefix .. "_" .. key) end
	end

	-- Certification-specialized armor wins. Field Medic officers intentionally
	-- prefer medic_officer, so 104th officers with field_medic get
	-- armor_104th_medic_officer when that item exists.
	if role then
		addKey(role .. "_" .. rankGroup)
		if rankGroup == "officer" or rankGroup == "commander" then
			addKey(role .. "_officer")
		end
		addKey(role)
	end

	-- Rank armor fallback.
	addKey(rankGroup)
	if rankGroup == "commander" then addKey("officer") end
	if rankGroup == "officer" then addKey("nco") end
	addKey("trp")

	return firstExisting(candidates)
end

function MilBase.QuartermasterBuildItems(ply)
	local targets = {}
	local loadout = factionLoadout(ply)
	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local rankGroup = MilBase.QuartermasterRankGroup(ply)

	mergeTargets(targets, cfg.QuartermasterDefaultItems)
	mergeTargets(targets, loadout.baseItems)
	mergeTargets(targets, (cfg.QuartermasterRankItems or {})[rankGroup])

	if cfg.QuartermasterIncludeIssue ~= false then
		mergeTargets(targets, faction and faction.issue)
		mergeTargets(targets, rank and rank.issue)
	end

	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[certID]
		mergeTargets(targets, (cfg.QuartermasterCertItems or {})[certID])
		if cfg.QuartermasterIncludeIssue ~= false then
			mergeTargets(targets, cert and cert.issue)
		end
	end

	local armorID = MilBase.QuartermasterArmorID(ply)
	if armorID then targets[armorID] = math.max(targets[armorID] or 0, 1) end

	return targets, armorID, rankGroup
end

function MilBase.QuartermasterBuildWeapons(ply)
	if cfg.QuartermasterGiveWeapons == false then return {} end

	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local weapons, seen = {}, {}

	local function add(list)
		for _, class in ipairs(list or {}) do
			if isstring(class) and class ~= "" and not seen[class] then
				seen[class] = true
				weapons[#weapons + 1] = class
			end
		end
	end

	add(cfg.DefaultLoadout)
	add(faction and faction.loadout)
	add(rank and rank.loadout)
	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs[certID]
		add(cert and cert.loadout)
	end

	return weapons
end


local function addItemIDs(out, items)
	for id in pairs(items or {}) do
		if isstring(id) and id ~= "" then out[id] = true end
	end
end

local function generatedArmorKeys()
	local keys, seen = {}, {}
	local function add(key)
		if isstring(key) and key ~= "" and not seen[key] then
			seen[key] = true
			keys[#keys + 1] = key
		end
	end

	for _, key in ipairs({ "trp", "nco", "officer", "commander" }) do add(key) end
	for _, role in pairs(cfg.QuartermasterCertArmorRoles or {}) do
		role = string.lower(tostring(role or ""))
		add(role)
		for _, group in ipairs({ "trp", "nco", "officer", "commander" }) do
			add(role .. "_" .. group)
		end
	end

	return keys
end

-- The Quartermaster owns/reconciles these items. Anything managed but no
-- longer authorized for the player's current faction/rank/certs is removed,
-- and quantities above the current target are trimmed before new gear is issued.
function MilBase.QuartermasterManagedItemIDs()
	local managed = {}

	addItemIDs(managed, cfg.QuartermasterDefaultItems)
	for _, items in pairs(cfg.QuartermasterRankItems or {}) do addItemIDs(managed, items) end
	for _, items in pairs(cfg.QuartermasterCertItems or {}) do addItemIDs(managed, items) end

	for _, loadout in pairs(cfg.QuartermasterFactionLoadouts or {}) do
		addItemIDs(managed, loadout.baseItems)
		for _, id in pairs(loadout.armor or {}) do
			if isstring(id) and id ~= "" then managed[id] = true end
		end
		if isstring(loadout.armorPrefix) and loadout.armorPrefix ~= "" then
			for _, key in ipairs(generatedArmorKeys()) do
				managed["armor_" .. loadout.armorPrefix .. "_" .. key] = true
			end
		end
	end

	if cfg.QuartermasterIncludeIssue ~= false then
		for _, faction in pairs(MilBase.Factions or {}) do
			addItemIDs(managed, faction.issue)
			for _, rank in ipairs(faction.ranks or {}) do addItemIDs(managed, rank.issue) end
		end
		for _, cert in pairs(MilBase.Certs or {}) do addItemIDs(managed, cert.issue) end
	end

	-- Armor is deliberately broad: this prevents someone changing from 104th to
	-- 501st and keeping a 104th chest piece in their inventory/equipped slot.
	if cfg.QuartermasterRemoveOldArmor ~= false then
		for id, def in pairs(MilBase.Items or {}) do
			if def and def.slot == "armor" then managed[id] = true end
		end
	end

	for id, enabled in pairs(cfg.QuartermasterManagedItems or {}) do
		if enabled ~= false then managed[id] = true end
	end

	return managed
end

function MilBase.QuartermasterIsManagedItem(id)
	return MilBase.QuartermasterManagedItemIDs()[id] == true
end

local function itemAmount(item)
	return math.max(1, math.floor(tonumber(item and item.amount) or 1))
end

local function removeFromContainer(container, id, amount)
	if not container or not container.items or amount <= 0 then return 0 end
	local removed = 0

	for i = #container.items, 1, -1 do
		if removed >= amount then break end
		local item = container.items[i]
		if item.id == id then
			local take = math.min(itemAmount(item), amount - removed)
			item.amount = itemAmount(item) - take
			removed = removed + take
			if item.amount <= 0 then table.remove(container.items, i) end
		end
	end

	return removed
end

local function canDeleteEquipped(inv, slot)
	-- Do not silently delete a worn backpack that contains player-owned items.
	return not (slot == "backpack" and inv.pack and #(inv.pack.items or {}) > 0)
end

function MilBase.QuartermasterCleanupGear(ply, targets, armorID)
	if cfg.QuartermasterRemoveOldGear == false then return {}, 0 end

	local inv = MilBase.GetInventory(ply)
	local managed = MilBase.QuartermasterManagedItemIDs()
	local removed, totalRemoved = {}, 0
	local equipmentChanged = false

	local function record(id, amount)
		amount = math.max(0, math.floor(tonumber(amount) or 0))
		if amount <= 0 then return end
		removed[id] = (removed[id] or 0) + amount
		totalRemoved = totalRemoved + amount
	end

	-- Remove equipped gear that the current role should not have anymore.
	for slot, item in pairs(inv.equip or {}) do
		local id = item and item.id
		local def = id and MilBase.Items[id]
		local wanted = math.max(0, math.floor(tonumber(targets[id] or 0) or 0))
		local isOldArmor = def and def.slot == "armor" and id ~= armorID

		if id and (managed[id] or isOldArmor) and (wanted <= 0 or isOldArmor) and canDeleteEquipped(inv, slot) then
			record(id, itemAmount(item))
			inv.equip[slot] = nil
			if slot == "backpack" then inv.pack = nil end
			equipmentChanged = true
		end
	end

	-- Then trim every managed inventory item down to the current authorized count.
	for id in pairs(managed) do
		local wanted = math.max(0, math.floor(tonumber(targets[id] or 0) or 0))
		local extra = MilBase.CountItem(ply, id) - wanted
		if extra > 0 then
			local removedHere = removeFromContainer(inv, id, extra)
			record(id, removedHere)
			extra = extra - removedHere

			if inv.pack and extra > 0 then
				removedHere = removeFromContainer(inv.pack, id, extra)
				record(id, removedHere)
				extra = extra - removedHere
			end

			if extra > 0 then
				for slot, item in pairs(inv.equip or {}) do
					if extra <= 0 then break end
					if item.id == id and canDeleteEquipped(inv, slot) then
						local take = math.min(itemAmount(item), extra)
						record(id, take)
						inv.equip[slot] = nil
						if slot == "backpack" then inv.pack = nil end
						equipmentChanged = true
						extra = extra - take
					end
				end
			end
		end
	end

	if totalRemoved > 0 then
		if equipmentChanged and MilBase.ApplyEquipment then MilBase.ApplyEquipment(ply) end
		MilBase.MarkInvDirty(ply)
	end

	return removed, totalRemoved
end

local function cleanupSummary(removed)
	local parts = {}
	for id, amount in SortedPairs(removed or {}) do
		local def = MilBase.Items[id]
		parts[#parts + 1] = amount .. "x " .. ((def and def.name) or id)
		if #parts >= 5 then break end
	end
	return table.concat(parts, ", ")
end

function MilBase.QuartermasterReconcileGear(ply, notify)
	local targets, armorID, rankGroup = MilBase.QuartermasterBuildItems(ply)
	local removed, totalRemoved = MilBase.QuartermasterCleanupGear(ply, targets, armorID)

	if notify and totalRemoved > 0 then
		local summary = cleanupSummary(removed)
		MilBase.Notify(ply, "Quartermaster removed " .. totalRemoved
			.. " old/basic item(s) no longer authorized"
			.. (summary ~= "" and (": " .. summary .. ".") or "."), "warn")
	end

	return removed, totalRemoved, targets, armorID, rankGroup
end

local ARMOR_OBJECTIVE_ID = "quartermaster_armor"

local function keyedLookup(tbl, value)
	if not tbl or not value then return false end
	local raw = tostring(value)
	local lower = string.lower(raw)
	if tbl[raw] == true or tbl[lower] == true then return true end
	for k, enabled in pairs(tbl) do
		if enabled == true and string.lower(tostring(k)) == lower then return true end
	end
	return false
end

local function arrayOrKeyLookup(tbl, value)
	if keyedLookup(tbl, value) then return true end
	if not istable(tbl) or value == nil then return false end
	local lower = string.lower(tostring(value))
	for _, v in pairs(tbl) do
		if string.lower(tostring(v)) == lower then return true end
	end
	return false
end

function MilBase.QuartermasterArmorObjectiveExcluded(ply)
	if not IsValid(ply) then return true end

	local factionID = ply:MBFactionID()
	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local excludedFactions = cfg.QuartermasterArmorObjectiveExcludedFactions or {}
	local excludedRanks = cfg.QuartermasterArmorObjectiveExcludedRanks or {}

	if arrayOrKeyLookup(excludedFactions, factionID) then return true end
	if faction and arrayOrKeyLookup(excludedFactions, faction.name) then return true end
	if rank and arrayOrKeyLookup(excludedRanks, rank.name) then return true end

	return false
end

function MilBase.QuartermasterNearestPosition(ply)
	if not SERVER or not IsValid(ply) then return nil end

	local nearest, best
	for _, ent in ipairs(ents.FindByClass("mb_quartermaster")) do
		if not IsValid(ent) then continue end
		local d = ent:GetPos():DistToSqr(ply:GetPos())
		if not best or d < best then
			nearest, best = ent, d
		end
	end

	return IsValid(nearest) and nearest:GetPos() or nil
end

function MilBase.QuartermasterUpdateArmorObjective(ply, reason)
	if not SERVER then return end
	if cfg.QuartermasterArmorObjectiveEnabled == false then return end
	if not (IsValid(ply) and ply:IsPlayer()) then return end
	if not ply.mb_inv then return end
	if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return end
	if not (MilBase.SetPlayerObjective and MilBase.ClearPlayerObjective) then return end

	local existing = ply.mb_personalObjectives and ply.mb_personalObjectives[ARMOR_OBJECTIVE_ID]

	if MilBase.QuartermasterArmorObjectiveExcluded(ply) then
		if existing then MilBase.ClearPlayerObjective(ply, ARMOR_OBJECTIVE_ID, false) end
		return
	end

	local armorID = MilBase.QuartermasterArmorID(ply)
	if not armorID or not MilBase.Items[armorID] then
		if existing then MilBase.ClearPlayerObjective(ply, ARMOR_OBJECTIVE_ID, false) end
		return
	end

	-- CountItem includes equipped armor, so the objective only exists while the
	-- player is missing their currently-authorized chest piece.
	if MilBase.CountItem(ply, armorID) > 0 then
		if existing then MilBase.ClearPlayerObjective(ply, ARMOR_OBJECTIVE_ID, true) end
		return
	end

	local armor = MilBase.Items[armorID]
	local faction = ply:MBFaction()
	local rank = ply:MBRank()
	local targetName = armor.name or armorID
	local changedArmor = not existing or existing.armorID ~= armorID

	MilBase.SetPlayerObjective(ply, ARMOR_OBJECTIVE_ID, {
		name = cfg.QuartermasterArmorObjectiveTitle or "Obtain new armor",
		desc = "Visit a Quartermaster to collect " .. targetName .. ".",
		otype = cfg.QuartermasterArmorObjectiveType or "rally",
		pos = MilBase.QuartermasterNearestPosition(ply),
		armorID = armorID,
	})

	if changedArmor then
		local role = ((faction and faction.name) or ply:MBFactionID())
		if rank and rank.name then role = role .. " / " .. rank.name end
		MilBase.Notify(ply, "New Objective: obtain your new armor from the Quartermaster (" .. targetName .. ").", "warn")
		if MilBase.Log then
			MilBase.Log("character", MilBase.LogTag(ply) .. " received armor objective for " .. targetName .. " (" .. role .. ").", ply)
		end
	end
end

function MilBase.QuartermasterCompleteArmorObjective(ply)
	if SERVER and MilBase.QuartermasterUpdateArmorObjective then
		MilBase.QuartermasterUpdateArmorObjective(ply, "quartermaster")
	end
end

if SERVER then
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_quartermasters ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "map VARCHAR(64), pos TEXT, ang TEXT )")

	local function canPlace(ply)
		return IsValid(ply) and (ply:IsAdmin() or ply:MBStaffLevel() >= (cfg.QuartermasterStaffLevel or 3))
	end

	local function spawnQuartermaster(row)
		if cfg.QuartermasterEnabled == false then return end

		local ent = ents.Create("mb_quartermaster")
		if not IsValid(ent) then return end

		ent:SetPos(util.StringToType(row.pos, "Vector"))
		ent:SetAngles(util.StringToType(row.ang, "Angle"))
		ent:Spawn()
		ent:Activate()
		ent.mb_qmID = tonumber(row.id)
		return ent
	end

	function MilBase.ReloadQuartermasters()
		for _, ent in ipairs(ents.FindByClass("mb_quartermaster")) do
			if ent.mb_qmID then ent:Remove() end
		end

		if cfg.QuartermasterEnabled == false then return end
		MilBase.DB.Query(string.format(
			"SELECT * FROM frontier_quartermasters WHERE map = %s",
			MilBase.SQLStr(game.GetMap())), function(rows)
			for _, row in ipairs(rows or {}) do spawnQuartermaster(row) end
		end)
	end

	hook.Add("InitPostEntity", "MilBase.Quartermasters", function()
		MilBase.ReloadQuartermasters()
	end)

	hook.Add("PostCleanupMap", "MilBase.Quartermasters", function()
		timer.Simple(0, function()
			if MilBase.ReloadQuartermasters then MilBase.ReloadQuartermasters() end
		end)
	end)

	local function nearestQuartermaster(ply, radius)
		local nearest, best
		local maxDist = (radius or 300) ^ 2
		for _, ent in ipairs(ents.FindByClass("mb_quartermaster")) do
			local d = ent:GetPos():DistToSqr(ply:GetPos())
			if d <= maxDist and (not best or d < best) then
				nearest, best = ent, d
			end
		end
		return nearest
	end

	function MilBase.QuartermasterClaim(ply, ent)
		if cfg.QuartermasterEnabled == false then
			MilBase.Notify(ply, "Quartermasters are disabled.")
			return
		end
		if not (IsValid(ply) and ply:IsPlayer() and ply:Alive()) then return end
		if IsValid(ent) and ent:GetPos():DistToSqr(ply:GetPos()) > (cfg.QuartermasterUseRange or 150) ^ 2 then
			return
		end
		if ply:GetNWBool("mb_wounded", false) or ply:GetNWBool("mb_cuffed", false) then
			MilBase.Notify(ply, "You can't access the Quartermaster right now.")
			return
		end
		if (ply.mb_nextQuartermaster or 0) > CurTime() then
			MilBase.Notify(ply, "Quartermaster is still processing your last request.")
			return
		end
		ply.mb_nextQuartermaster = CurTime() + (cfg.QuartermasterCooldown or 5)

		local removed, totalRemoved, targets, armorID, rankGroup = MilBase.QuartermasterReconcileGear(ply, false)
		local issued, skipped, totalGiven = {}, {}, 0

		for id, wanted in SortedPairs(targets) do
			local def = MilBase.Items[id]
			if not def then
				skipped[#skipped + 1] = id
				continue
			end

			local missing = math.max(0, wanted - MilBase.CountItem(ply, id))
			if missing > 0 then
				local given = MilBase.GiveItem(ply, id, missing)
				if given > 0 then
					totalGiven = totalGiven + given
					issued[#issued + 1] = given .. "x " .. (def.name or id)
				end
				if given < missing then skipped[#skipped + 1] = (def.name or id) end
			end
		end

		local weaponIssued = {}
		local oldFlag = ply.mb_giveLoadout
		ply.mb_giveLoadout = true
		for _, class in ipairs(MilBase.QuartermasterBuildWeapons(ply)) do
			if not ply:HasWeapon(class) then
				ply:Give(class)
				if ply:HasWeapon(class) then weaponIssued[#weaponIssued + 1] = class end
			end
		end
		ply.mb_giveLoadout = oldFlag

		if cfg.QuartermasterGiveAmmo == true then
			for _, wep in ipairs(ply:GetWeapons()) do
				local ammoType = wep:GetPrimaryAmmoType()
				local clipSize = wep:GetMaxClip1()
				if ammoType >= 0 and clipSize > 0 then
					ply:GiveAmmo(clipSize * (cfg.SpareMagazines or 3), ammoType, true)
				end
			end
		end

		if MilBase.QuartermasterCompleteArmorObjective then
			MilBase.QuartermasterCompleteArmorObjective(ply)
		end

		local armorName = armorID and MilBase.Items[armorID] and MilBase.Items[armorID].name
		local parts = {}
		if totalGiven > 0 then parts[#parts + 1] = totalGiven .. " inventory item(s)" end
		if #weaponIssued > 0 then parts[#parts + 1] = #weaponIssued .. " weapon(s)" end

		if totalRemoved > 0 then
			local summary = cleanupSummary(removed)
			MilBase.Notify(ply, "Quartermaster removed " .. totalRemoved
				.. " old/basic item(s) no longer authorized"
				.. (summary ~= "" and (": " .. summary .. ".") or "."), "warn")
		end

		if #parts == 0 then
			MilBase.Notify(ply, "Quartermaster: your basic gear is already topped up.", "ok")
		else
			MilBase.Notify(ply, "Quartermaster issued " .. table.concat(parts, " and ") .. ".", "ok")
		end

		if armorName then
			local faction = ply:MBFaction()
			MilBase.Notify(ply, "Armor authorization: " .. armorName .. " ("
				.. ((faction and faction.name) or ply:MBFactionID()) .. " / " .. rankGroup .. ").")
		end

		if #skipped > 0 then
			MilBase.Notify(ply, "Some gear could not be issued (full inventory or missing config): "
				.. table.concat(skipped, ", ") .. ".", "warn")
		end

		if #issued > 0 and MilBase.Log then
			local preview = table.concat(issued, ", ")
			if #preview > 180 then preview = string.sub(preview, 1, 177) .. "..." end
			MilBase.Log("econ", MilBase.LogTag(ply) .. " retrieved Quartermaster gear: " .. preview, ply)
		end
	end


	hook.Add("PlayerSpawn", "MilBase.QuartermasterRoleCleanup", function(ply)
		if cfg.QuartermasterCleanupOnSpawn == false then return end

		timer.Simple(0, function()
			if not IsValid(ply) or not ply.mb_inv then return end
			if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return end
			if MilBase.QuartermasterReconcileGear then
				MilBase.QuartermasterReconcileGear(ply, cfg.QuartermasterNotifyCleanupOnSpawn == true)
			end
			if MilBase.QuartermasterUpdateArmorObjective then
				MilBase.QuartermasterUpdateArmorObjective(ply, "spawn")
			end
		end)
	end)

	hook.Add("MilBase.PlayerLoaded", "MilBase.QuartermasterArmorObjective", function(ply)
		timer.Simple(1, function()
			if IsValid(ply) and MilBase.QuartermasterUpdateArmorObjective then
				MilBase.QuartermasterUpdateArmorObjective(ply, "loaded")
			end
		end)
	end)

	function MilBase.QuartermasterCommand(ply, args)
		if not canPlace(ply) then
			MilBase.Notify(ply, "Quartermaster placement requires staff level "
				.. (cfg.QuartermasterStaffLevel or 3) .. "+.")
			return
		end

		local sub = string.lower(args[1] or "")
		if sub == "add" or sub == "place" then
			local tr = ply:GetEyeTrace()
			if not tr.Hit then return end

			local pos = tr.HitPos
			local face = (ply:GetPos() - pos):Angle()
			local ang = Angle(0, face.y, 0)
			local posStr, angStr = tostring(pos), tostring(ang)

			MilBase.DB.Insert(string.format(
				"INSERT INTO frontier_quartermasters (map, pos, ang) VALUES (%s, %s, %s)",
				MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(posStr), MilBase.SQLStr(angStr)), function(id)
				if not IsValid(ply) then return end
				spawnQuartermaster({ id = id, pos = posStr, ang = angStr })
				MilBase.Notify(ply, "Placed Quartermaster #" .. tostring(id) .. ".")
			end)

		elseif sub == "remove" or sub == "delete" then
			local ent = nearestQuartermaster(ply, 300)
			if not IsValid(ent) then
				MilBase.Notify(ply, "No Quartermaster within 300 units.")
				return
			end
			if ent.mb_qmID then
				MilBase.DB.Run("DELETE FROM frontier_quartermasters WHERE id = " .. tonumber(ent.mb_qmID))
			end
			ent:Remove()
			MilBase.Notify(ply, "Removed the nearest Quartermaster.")

		elseif sub == "reload" then
			MilBase.ReloadQuartermasters()
			MilBase.Notify(ply, "Reloaded Quartermasters for this map.")

		else
			local count = #ents.FindByClass("mb_quartermaster")
			MilBase.Notify(ply, "Usage: /quartermaster add|remove|reload (" .. count .. " active on this map).")
		end
	end
end

MilBase.RegisterChatCommand("quartermaster", {
	help = "(Staff 3+) Quartermaster NPCs: /quartermaster add|remove|reload",
	func = function(ply, args)
		if SERVER and MilBase.QuartermasterCommand then
			MilBase.QuartermasterCommand(ply, args or {})
		end
	end,
})
