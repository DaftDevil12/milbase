--[[
	Event system (server): the commander-mode backend.

	Event staff enter a top-down control camera (/event) and:
	  - spawn enemies (NPCs) and LVS vehicles at the cursor
	  - box-select units and order MOVE / ATTACK / DEFEND / PATROL
	  - drive LVS aircraft: GUN RUN (hard-lock a point/target) and
	    FLIGHT PATH (patrol waypoints), toggle autopilot
	  - clear the battlefield

	All spawned units are tagged and cleaned up on /event clear, round
	restart, or map change. NPCs are made hostile to players.
]]

local cfg = MilBase.Config

util.AddNetworkString("MilBase_EventState")
util.AddNetworkString("MilBase_EventCam")
util.AddNetworkString("MilBase_EventSpawn")
util.AddNetworkString("MilBase_EventOrder")
util.AddNetworkString("MilBase_EventClear")
util.AddNetworkString("MilBase_EventBuild")

MilBase.EventEntities = MilBase.EventEntities or {}

local ENEMY_TEAM = 3 -- LVS AI team: hostile to everyone (players included)

--------------------------------------------------------------------------
-- Enter / exit the commander view
--------------------------------------------------------------------------

function MilBase.EnterEventMode(ply)
	if not MilBase.CanRunEvents(ply) then
		MilBase.Notify(ply, "You don't have event permission.")
		return
	end
	if ply:GetNWBool("mb_eventmode", false) then return end

	-- Stash the body: float, invulnerable, hidden, frozen in place.
	ply.mb_eventReturn = { pos = ply:GetPos(), wep = IsValid(ply:GetActiveWeapon())
		and ply:GetActiveWeapon():GetClass() or nil }
	ply:SetNWBool("mb_eventmode", true)
	ply:SetNWBool("mb_eventbuild", false)
	ply:GodEnable()
	ply:SetMoveType(MOVETYPE_NONE)
	ply:SetNoDraw(true)
	ply:DrawShadow(false)
	ply:SetNotSolid(true)
	ply:SetNoTarget(true)

	net.Start("MilBase_EventState")
		net.WriteBool(true)
	net.Send(ply)

	-- Show any existing triggers on the game master's HUD.
	if MilBase.SyncTriggers then MilBase.SyncTriggers(ply) end
end

function MilBase.ExitEventMode(ply)
	if not ply:GetNWBool("mb_eventmode", false) then return end

	ply:SetNWBool("mb_eventmode", false)
	ply:SetNWBool("mb_eventbuild", false)
	ply.OFEventCamPos = nil
	ply:GodDisable()
	ply:SetMoveType(MOVETYPE_WALK)
	ply:SetNoDraw(false)
	ply:DrawShadow(true)
	ply:SetNotSolid(false)
	ply:SetNoTarget(false)

	-- Build mode may have noclipped the body away; put it back.
	if ply.mb_eventReturn and isvector(ply.mb_eventReturn.pos) then
		ply:SetPos(ply.mb_eventReturn.pos)
	end

	-- Clean up the build-mode tools.
	ply:StripWeapon("gmod_tool")
	ply:StripWeapon("weapon_physgun")
	ply:StripWeapon("gmod_camera")

	net.Start("MilBase_EventState")
		net.WriteBool(false)
	net.Send(ply)
end

-- Build mode: fly around as an invisible god with the toolgun / physgun /
-- spawn menu (spawns at your aim), for building the scene. Toggled from
-- the game-master view.
function MilBase.SetEventBuild(ply, on)
	if not ply:GetNWBool("mb_eventmode", false) then return end
	ply:SetNWBool("mb_eventbuild", on)

	if on then
		ply:SetMoveType(MOVETYPE_NOCLIP)
		ply:Give("gmod_tool")
		ply:Give("weapon_physgun")
		ply:Give("gmod_camera")
		ply:SelectWeapon("gmod_tool")
	else
		ply:StripWeapon("gmod_tool")
		ply:StripWeapon("weapon_physgun")
		ply:StripWeapon("gmod_camera")
		ply:SetMoveType(MOVETYPE_NONE)
	end
end

net.Receive("MilBase_EventBuild", function(_, ply)
	MilBase.SetEventBuild(ply, net.ReadBool())
end)

-- Event staff can physgun anything while building.
hook.Add("PhysgunPickup", "MilBase.EventPhysgun", function(ply, ent)
	if ply:GetNWBool("mb_eventmode", false) then return true end
end)

hook.Add("PlayerDeath", "MilBase.EventCleanup", function(ply)
	if ply:GetNWBool("mb_eventmode", false) then MilBase.ExitEventMode(ply) end
end)
hook.Add("PlayerDisconnected", "MilBase.EventCleanup", function(ply)
	if ply:GetNWBool("mb_eventmode", false) then MilBase.ExitEventMode(ply) end
end)

-- Expand PVS to the commander camera so distant units keep updating.
hook.Add("SetupPlayerVisibility", "MilBase.EventPVS", function(ply)
	local pos = ply.OFEventCamPos
	if isvector(pos) and util.IsInWorld(pos) then
		AddOriginToPVS(pos)
	end
end)

net.Receive("MilBase_EventCam", function(_, ply)
	if not ply:GetNWBool("mb_eventmode", false) then return end
	local pos = net.ReadVector()
	if isvector(pos) then ply.OFEventCamPos = pos end
end)

--------------------------------------------------------------------------
-- Spawning
--------------------------------------------------------------------------

local function tagEntity(ent, ply)
	ent.mb_eventSpawned = true
	ent.mb_eventOwner = ply
	ent:SetNWBool("mb_event", true) -- so the commander client can select it
	table.insert(MilBase.EventEntities, ent)
end

-- Admin log of who spawned what (anti-abuse / accountability). `ply` may
-- be a trigger (no player) - fall back to a generic label.
local function logSpawn(ply, name)
	local who = (IsValid(ply) and ply:IsPlayer())
		and (ply:Nick() .. " (" .. ply:SteamID() .. ")") or "a trigger"
	ServerLog("[MilBase Event] " .. who .. " spawned " .. name .. "\n")
end

-- Total active event-entity budget, to keep servers from melting.
local function overCap(ply)
	local cap = cfg.MaxEventEntities or 250
	local live = 0
	for _, e in ipairs(MilBase.EventEntities) do
		if IsValid(e) then live = live + 1 end
	end
	if live >= cap then
		if IsValid(ply) and ply:IsPlayer() and (ply.mb_capNotify or 0) < CurTime() then
			ply.mb_capNotify = CurTime() + 3
			MilBase.Notify(ply, "Event entity cap reached (" .. cap
				.. "). Clear some units before spawning more.")
		end
		return true
	end
	return false
end

-- NPC teams decide who fights whom:
--   enemy    - hunts players, fights friendly NPCs
--   friendly - allied to players, fights enemy NPCs
--   neutral  - ignores everyone until attacked
MilBase.NPCTeams = { enemy = true, friendly = true, neutral = true }
local FRIENDLY_TEAM = 1 -- LVS AI team for friendly vehicles

local function npcTeam(ent) return ent.mb_npcteam or "enemy" end

-- Set an NPC's relationship to players and to every other event NPC.
local function applyNPCTeam(npc)
	local team = npcTeam(npc)
	npc:SetNWString("mb_team", team)

	if team == "friendly" then
		npc:AddRelationship("player D_LI 99")
		npc:SetNPCState(NPC_STATE_ALERT)
	elseif team == "neutral" then
		npc:AddRelationship("player D_NU 99")
		npc:SetNPCState(NPC_STATE_IDLE)
	else -- enemy
		npc:AddRelationship("player D_HT 99")
		npc:SetNPCState(NPC_STATE_ALERT)
	end

	-- Pairwise with the other event NPCs already in play.
	for _, other in ipairs(MilBase.EventEntities) do
		if other == npc or not IsValid(other) or not other:IsNPC() then continue end
		local ot = npcTeam(other)
		local disp = D_NU
		if team ~= "neutral" and ot ~= "neutral" then
			disp = (team == ot) and D_LI or D_HT
		end
		npc:AddEntityRelationship(other, disp, 99)
		other:AddEntityRelationship(npc, disp, 99)
	end
end

-- Apply a behavior stance to an NPC. Shared by spawn options and the
-- Behavior order. Team relationships are untouched (a friendly unit set
-- "aggressive" hunts enemies, not players).
function MilBase.SetNPCStance(ent, stance)
	if not IsValid(ent) or not ent:IsNPC() then return end
	ent.mb_follow = nil

	if stance == "hold" or stance == "defend" then
		ent.mb_stance = "defend"
		ent.mb_patrol = nil
		ent:StopMoving()
		ent.mb_guardPos = ent:GetPos()
		ent:SetSchedule(SCHED_COMBAT_STAND)
	elseif stance == "patrol" then
		ent.mb_stance = "patrol"
		ent:SetNPCState(NPC_STATE_ALERT)
		ent:SetSchedule(SCHED_PATROL_WALK)
	elseif stance == "careless" then
		ent.mb_stance = "careless"
		ent.mb_patrol = nil
		ent:SetNPCState(NPC_STATE_IDLE)
		ent:SetSchedule(SCHED_IDLE_STAND)
	else -- aggressive / attack
		ent.mb_stance = "attack"
		ent.mb_patrol = nil
		ent:SetNPCState(NPC_STATE_ALERT)
	end
end

-- One-shot / environmental effects the game master can place.
function MilBase.SpawnEventEffect(ply, def, pos)
	local e = def.effect

	if e == "explosion" then
		local attacker = (IsValid(ply) and ply) or game.GetWorld()
		local fx = EffectData()
		fx:SetOrigin(pos)
		fx:SetScale(1)
		util.Effect("HelicopterMegaBomb", fx)
		util.Effect("Explosion", fx)
		util.BlastDamage(attacker, attacker, pos, 320, 160)
		sound.Play("ambient/explosions/explode_" .. math.random(1, 9) .. ".wav", pos, 100, 100)

	elseif e == "fire" then
		local fire = ents.Create("env_fire")
		if IsValid(fire) then
			fire:SetPos(pos)
			fire:SetKeyValue("firesize", tostring(def.size or 160))
			fire:SetKeyValue("fireattack", "6")
			fire:SetKeyValue("damagescale", "2")
			fire:SetKeyValue("health", "40")
			fire:SetKeyValue("spawnflags", "4") -- infinite duration
			fire:Spawn()
			fire:Fire("StartFire", "", 0)
			tagEntity(fire, ply)
		end

	elseif e == "smoke" then
		local sm = ents.Create("env_smokestack")
		if IsValid(sm) then
			sm:SetPos(pos)
			sm:SetKeyValue("BaseSpread", "40")
			sm:SetKeyValue("SpreadSpeed", "60")
			sm:SetKeyValue("Speed", "120")
			sm:SetKeyValue("StartSize", "20")
			sm:SetKeyValue("EndSize", "80")
			sm:SetKeyValue("Rate", "80")
			sm:SetKeyValue("renderamt", "180")
			sm:SetKeyValue("rendercolor", "40 40 40")
			sm:SetKeyValue("SmokeMaterial", "particle/SmokeStack.vmt")
			sm:Spawn()
			sm:Activate()
			sm:Fire("TurnOn", "", 0)
			tagEntity(sm, ply)
		end
	end
end

-- Core spawn used by both the game master's palette and trigger actions.
-- `ply` may be a player or nil/world (trigger-fired). `opts` (optional):
--   team ("enemy"/"friendly"/"neutral"), hp (health multiplier), stance.
-- Returns the entity, or nil for effects / failures.
function MilBase.DoEventSpawn(ply, def, pos, yaw, opts)
	if not def or not isvector(pos) or not util.IsInWorld(pos) then return end
	yaw = yaw or 0
	opts = opts or {}

	-- Effects are one-shot / environmental, not selectable entities.
	if def.kind == "effect" then
		MilBase.SpawnEventEffect(ply, def, pos)
		return
	end

	if overCap(ply) then return end

	-- RP entities: hackable terminal / hull breach (spawn already
	-- malfunctioning) and the encryption relay (spawn functional).
	local RP_ENT = {
		terminal = "mb_terminal", breach = "mb_breach",
		relay_dish = "mb_relay_dish", relay_terminal = "mb_relay_terminal",
	}
	if RP_ENT[def.kind] then
		local ent = ents.Create(RP_ENT[def.kind])
		if not IsValid(ent) then return end
		ent:SetPos(pos + Vector(0, 0, def.kind == "breach" and 6 or 2))
		ent:SetAngles(Angle(0, yaw, 0))
		if IsValid(ply) then ent:SetCreator(ply) end
		ent:Spawn()
		local phys = ent:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
		-- Terminals/breaches start broken; relays start operational.
		if (def.kind == "terminal" or def.kind == "breach") and ent.Break then ent:Break() end
		tagEntity(ent, ply)
		logSpawn(ply, def.name)
		return ent
	end

	local ent = ents.Create(def.kind == "prop" and "prop_physics" or def.class)
	if not IsValid(ent) then
		if IsValid(ply) and ply:IsPlayer() then
			MilBase.Notify(ply, "Failed to spawn " .. def.name .. " (class missing?)")
		end
		return
	end

	ent:SetPos(pos + Vector(0, 0, 8))
	ent:SetAngles(Angle(0, yaw, 0))
	if IsValid(ply) then ent:SetCreator(ply) end
	if def.kind == "prop" then
		ent:SetModel(def.model or "models/props_junk/wood_crate001a.mdl")
	end
	-- Arm HL2 NPCs so they can actually fight (before Spawn).
	if def.weapon then ent:SetKeyValue("additionalequipment", def.weapon) end
	ent:Spawn()
	ent:Activate()

	-- Optional model override for NPCs, e.g. reskinning a stock combine
	-- soldier class as a B1 battle droid. Only clean with models rigged
	-- to a compatible skeleton for the base class - mismatched skeletons
	-- will animate incorrectly (T-pose / broken bone-follow).
	if def.kind == "npc" then
		print("[MB DROPSHIP DEBUG] def.model = '" .. tostring(def.model) .. "', ent model before = '" .. ent:GetModel() .. "'")
	end
	if def.kind == "npc" and def.model and def.model ~= "" and util.IsValidModel(def.model) then
		ent:SetModel(def.model)
		print("[MB DROPSHIP DEBUG] ent model after = '" .. ent:GetModel() .. "'")
	end

	local team = def.forceTeam or opts.team or "enemy"
	if not MilBase.NPCTeams[team] then team = "enemy" end

	if def.kind == "prop" then
		local phys = ent:GetPhysicsObject()
		if IsValid(phys) then phys:EnableMotion(false) end
	elseif def.kind == "lvs" or ent.LVS then
		-- LVS vehicle: AI team + autopilot.
		if ent.SetAITEAM then ent:SetAITEAM(team == "friendly" and FRIENDLY_TEAM or ENEMY_TEAM) end
		if def.ai ~= false and ent.SetAI then ent:SetAI(true) end
		ent.mb_npcteam = team
		ent:SetNWString("mb_team", team)
		ent.mb_stance = "attack"
	elseif ent:IsNPC() then
		ent.mb_npcteam = team
		applyNPCTeam(ent)

		if opts.hp and opts.hp > 0 and opts.hp ~= 1 then
			local h = math.max(1, math.floor(ent:GetMaxHealth() * opts.hp))
			ent:SetMaxHealth(h)
			ent:SetHealth(h)
		end
		if opts.stance then MilBase.SetNPCStance(ent, opts.stance) end
	end

	tagEntity(ent, ply)
	logSpawn(ply, def.name)
	return ent
end

net.Receive("MilBase_EventSpawn", function(_, ply)
	if not MilBase.CanRunEvents(ply) or not ply:GetNWBool("mb_eventmode", false) then return end
	if (ply.mb_eventNextSpawn or 0) > CurTime() then return end
	ply.mb_eventNextSpawn = CurTime() + 0.12

	local def = MilBase.EventSpawns[net.ReadString()]
	local pos = net.ReadVector()
	local yaw = net.ReadFloat()
	local team = net.ReadString()
	local count = math.Clamp(net.ReadUInt(4), 1, 12)
	local hp = net.ReadFloat()
	local stance = net.ReadString()

	if not MilBase.NPCTeams[team] then team = "enemy" end
	local opts = { team = team, hp = hp, stance = stance ~= "" and stance or nil }

	-- Only units (NPCs / LVS) spawn as squads; everything else is single.
	local isUnit = def and (def.kind == "npc" or def.kind == "lvs")
	if not isUnit or count <= 1 then
		MilBase.DoEventSpawn(ply, def, pos, yaw, opts)
		return
	end

	-- Squad: spread the group in rings around the click point.
	for i = 1, count do
		local ang = (i / count) * math.pi * 2
		local r = 55 + math.floor((i - 1) / 8) * 55
		local off = Vector(math.cos(ang) * r, math.sin(ang) * r, 0)
		MilBase.DoEventSpawn(ply, def, pos + off, yaw, opts)
	end
end)

--------------------------------------------------------------------------
-- Orders
--------------------------------------------------------------------------

local ORDER = {}

-- Move / attack-move: run to the point (attack keeps them aggressive).
local function orderMove(ent, pos, aggressive)
	if not ent:IsNPC() then return end

	ent.mb_stance = aggressive and "attack" or "move"
	ent.mb_patrol = nil
	ent:StopMoving()
	ent:SetLastPosition(pos)

	if ent.IsVJBaseSNPC and ent.SCHEDULE_GOTO_POSITION then
		ent:SCHEDULE_GOTO_POSITION("TASK_RUN_PATH", function(schedule)
			schedule.CanShootWhenMoving = true
		end)
	else
		ent:SetSchedule(SCHED_FORCED_GO_RUN)
	end
end

ORDER.move = function(ent, data) orderMove(ent, data.pos, false) end
ORDER.attack = function(ent, data) orderMove(ent, data.pos, true) end

-- Zeus-style direct manipulation.
ORDER.teleport = function(ent, data)
	ent:SetPos(data.pos + Vector(0, 0, 8))
	if ent:IsNPC() then
		ent:StopMoving()
		ent.mb_patrol = nil
	end
	if ent.PhysWake then ent:PhysWake() end
end

ORDER.delete = function(ent)
	if ent.mb_charge then ent.mb_breach = nil end
	SafeRemoveEntity(ent)
end

ORDER.heal = function(ent)
	if ent:IsNPC() then
		ent:SetHealth(ent:GetMaxHealth())
	elseif ent.LVS then
		if ent.Repair then ent:Repair() end
		if ent.SetHP and ent.GetMaxHP then ent:SetHP(ent:GetMaxHP()) end
	end
end

ORDER.invincible = function(ent)
	ent.mb_god = not ent.mb_god
	if ent.mb_eventOwner then
		MilBase.Notify(ent.mb_eventOwner, (ent.PrintName or ent:GetClass())
			.. (ent.mb_god and " is now invincible." or " is vulnerable again."))
	end
end

-- Behavior presets (data.str = hold / aggressive / patrol / careless).
ORDER.behavior = function(ent, data)
	MilBase.SetNPCStance(ent, data.str)
end

-- Hold: stop and guard the current spot.
ORDER.defend = function(ent, data)
	MilBase.SetNPCStance(ent, "defend")
end

-- Attack a specific target (a player, or an enemy unit under the cursor).
ORDER.attackentity = function(ent, data)
	if not ent:IsNPC() or not IsValid(data.target) then return end
	ent.mb_stance = "attack"
	ent.mb_patrol = nil
	ent.mb_follow = nil
	ent.mb_holdfire = false
	ent:AddEntityRelationship(data.target, D_HT, 99)
	ent:UpdateEnemyMemory(data.target, data.target:GetPos())
	ent:SetEnemy(data.target)
	ent:SetNPCState(NPC_STATE_COMBAT)
	ent:SetSchedule(SCHED_ESTABLISH_LINE_OF_FIRE)
end

-- Follow a target entity (kept up in the think loop).
ORDER.follow = function(ent, data)
	if not ent:IsNPC() or not IsValid(data.target) then return end
	ent.mb_patrol = nil
	ent.mb_follow = data.target
	orderMove(ent, data.target:GetPos(), false)
	ent.mb_stance = "follow"
end

-- Toggle hold-fire: the unit goes neutral to everyone without losing its
-- team; toggling again restores its team relationships.
ORDER.holdfire = function(ent, data)
	if not ent:IsNPC() then return end
	ent.mb_holdfire = not ent.mb_holdfire

	if ent.mb_holdfire then
		ent.mb_stance = "holdfire"
		ent:AddRelationship("player D_NU 99")
		ent:SetEnemy(NULL)
		ent:ClearEnemyMemory()
		for _, o in ipairs(MilBase.EventEntities) do
			if IsValid(o) and o:IsNPC() and o ~= ent then
				ent:AddEntityRelationship(o, D_NU, 99)
			end
		end
		ent:SetSchedule(SCHED_COMBAT_STAND)
	else
		applyNPCTeam(ent) -- restore hostilities
		ent.mb_stance = "attack"
	end
end

-- Retreat: break off and run away from the nearest player.
ORDER.retreat = function(ent, data)
	if not ent:IsNPC() then return end
	ent.mb_patrol = nil
	ent.mb_follow = nil

	local nearest, nd
	for _, p in ipairs(player.GetAll()) do
		if p:Alive() and not p:GetNWBool("mb_eventmode", false) then
			local d = ent:GetPos():DistToSqr(p:GetPos())
			if not nd or d < nd then nearest, nd = p, d end
		end
	end

	local away
	if IsValid(nearest) then
		away = ent:GetPos() - nearest:GetPos()
		away.z = 0
	end
	if not away or away:LengthSqr() < 1 then away = -ent:GetForward() end

	orderMove(ent, ent:GetPos() + away:GetNormalized() * 1200, false)
	ent.mb_stance = "retreat"
end

-- Patrol: cycle the given waypoints forever (handled in the think loop).
ORDER.patrol = function(ent, data)
	if not ent:IsNPC() then return end
	if not data.points or #data.points == 0 then return end
	ent.mb_stance = "patrol"
	ent.mb_patrol = { points = data.points, index = 1 }
	orderMove(ent, data.points[1], false)
end

-- LVS gun run: hard-lock a target entity (or a bullseye at the point)
-- and let the autopilot make attack passes.
ORDER.gunrun = function(ent, data)
	if not ent.LVS then return end
	if ent.SetAI then ent:SetAI(true) end
	ent.mb_stance = "gunrun"
	ent.mb_patrol = nil

	local target = data.target
	if not IsValid(target) then
		-- Anchor a bullseye at the point for the AI to attack.
		local bull = ents.Create("npc_bullseye")
		if IsValid(bull) then
			bull:SetPos(data.pos)
			bull:SetKeyValue("solid", "0")
			bull:Spawn()
			bull:SetHealth(999999)
			if bull.SetAITEAM then bull:SetAITEAM(ENEMY_TEAM == 3 and 1 or 3) end
			tagEntity(bull, ent.mb_eventOwner)
			target = bull
		end
	end

	if IsValid(target) and ent.SetHardLockTarget then
		ent:SetHardLockTarget(target)
	end
end

-- LVS flight path: fly a circuit of waypoints. We drop invisible beacons
-- on the vehicle's OWN team (so it navigates to them without shooting)
-- and cycle the hard-lock through them.
ORDER.flightpath = function(ent, data)
	if not ent.LVS then return end
	if ent.SetAI then ent:SetAI(true) end
	ent.mb_stance = "flightpath"

	if ent.mb_pathBeacons then
		for _, b in ipairs(ent.mb_pathBeacons) do if IsValid(b) then b:Remove() end end
	end
	ent.mb_pathBeacons = {}

	if not data.points or #data.points == 0 then return end

	local myTeam = ent.GetAITEAM and ent:GetAITEAM() or ENEMY_TEAM
	for _, p in ipairs(data.points) do
		local b = ents.Create("npc_bullseye")
		if IsValid(b) then
			b:SetPos(p)
			b:SetKeyValue("solid", "0")
			b:Spawn()
			b:SetHealth(999999)
			b:SetNoDraw(true)
			if b.SetAITEAM then b:SetAITEAM(myTeam) end -- same team = navigate, don't fire
			b.mb_eventSpawned = true
			b:SetNWBool("mb_event", false)
			table.insert(MilBase.EventEntities, b)
			table.insert(ent.mb_pathBeacons, b)
		end
	end

	ent.mb_patrol = { index = 1, air = true, beacons = ent.mb_pathBeacons }
	if ent.SetHardLockTarget and IsValid(ent.mb_pathBeacons[1]) then
		ent:SetHardLockTarget(ent.mb_pathBeacons[1])
	end
end

net.Receive("MilBase_EventOrder", function(_, ply)
	if not MilBase.CanRunEvents(ply) or not ply:GetNWBool("mb_eventmode", false) then return end

	local orderType = net.ReadString()
	local handler = ORDER[orderType]
	if not handler then return end

	local count = net.ReadUInt(10)
	if count <= 0 or count > 256 then return end
	local ents_ = {}
	for i = 1, count do ents_[i] = Entity(net.ReadUInt(16)) end

	local data = {}
	data.pos = net.ReadVector()

	local hasTarget = net.ReadBool()
	if hasTarget then data.target = net.ReadEntity() end

	local pointCount = net.ReadUInt(6)
	if pointCount > 0 then
		data.points = {}
		for i = 1, pointCount do data.points[i] = net.ReadVector() end
	end

	data.str = net.ReadString() -- behavior preset / extra arg

	for _, ent in ipairs(ents_) do
		if IsValid(ent) and ent.mb_eventSpawned then
			handler(ent, data)
		end
	end
end)

-- Invincible event entities take no damage.
hook.Add("EntityTakeDamage", "MilBase.EventGodMode", function(ent, dmg)
	if ent.mb_god then return true end
end)

--------------------------------------------------------------------------
-- Patrol / guard think loop
--------------------------------------------------------------------------

local nextTick = 0
hook.Add("Think", "MilBase.EventThink", function()
	if CurTime() < nextTick then return end
	nextTick = CurTime() + 0.4

	for i = #MilBase.EventEntities, 1, -1 do
		local ent = MilBase.EventEntities[i]
		if not IsValid(ent) then
			table.remove(MilBase.EventEntities, i)
			continue
		end

		-- Follow: re-path to the target when it moves away.
		if ent.mb_follow then
			if IsValid(ent.mb_follow) then
				if ent:IsNPC() and ent:GetPos():DistToSqr(ent.mb_follow:GetPos()) > 300 * 300 then
					orderMove(ent, ent.mb_follow:GetPos(), false)
					ent.mb_stance = "follow"
				end
			else
				ent.mb_follow = nil
			end
			continue
		end

		local patrol = ent.mb_patrol
		if not patrol then continue end

		if patrol.air and patrol.beacons then
			-- LVS: advance the hard-lock to the next beacon on approach.
			local goal = patrol.beacons[patrol.index]
			if IsValid(goal) and ent:GetPos():DistToSqr(goal:GetPos()) < 1400 * 1400 then
				patrol.index = patrol.index % #patrol.beacons + 1
				local nxt = patrol.beacons[patrol.index]
				if IsValid(nxt) and ent.SetHardLockTarget then
					ent:SetHardLockTarget(nxt)
				end
			end
		elseif patrol.points then
			-- NPC ground patrol: walk the circuit.
			local goal = patrol.points[patrol.index]
			if isvector(goal) and ent:GetPos():DistToSqr(goal) < 160 * 160 then
				patrol.index = patrol.index % #patrol.points + 1
				if ent:IsNPC() then
					orderMove(ent, patrol.points[patrol.index], false)
					ent.mb_patrol = patrol -- orderMove cleared it
				end
			end
		end
	end
end)

--------------------------------------------------------------------------
-- Cleanup
--------------------------------------------------------------------------

function MilBase.ClearEventEntities()
	local n = 0
	for _, ent in ipairs(MilBase.EventEntities) do
		if IsValid(ent) then ent:Remove() n = n + 1 end
	end
	MilBase.EventEntities = {}
	if MilBase.ClearObjectives then MilBase.ClearObjectives() end
	if MilBase.ClearTriggers then MilBase.ClearTriggers() end
	return n
end

net.Receive("MilBase_EventClear", function(_, ply)
	if not MilBase.CanRunEvents(ply) then return end
	local n = MilBase.ClearEventEntities()
	MilBase.Notify(ply, "Cleared " .. n .. " event units.")
end)

hook.Add("PostCleanupMap", "MilBase.EventClear", function()
	MilBase.EventEntities = {}
end)

--------------------------------------------------------------------------
-- Commands
--------------------------------------------------------------------------

MilBase.RegisterChatCommand("event", {
	help = "Open the event commander view (event staff).",
	func = function(ply)
		if ply:GetNWBool("mb_eventmode", false) then
			MilBase.ExitEventMode(ply)
		else
			MilBase.EnterEventMode(ply)
		end
	end,
})

MilBase.RegisterChatCommand("eventclear", {
	help = "(Event staff) Remove all event-spawned units.",
	func = function(ply)
		if not MilBase.CanRunEvents(ply) then
			MilBase.Notify(ply, "You don't have event permission.")
			return
		end
		local n = MilBase.ClearEventEntities()
		MilBase.ChatMsg(nil, Color(200, 160, 80), "[EVENT] ", color_white,
			ply:MBName() .. " cleared " .. n .. " event units.")
	end,
})