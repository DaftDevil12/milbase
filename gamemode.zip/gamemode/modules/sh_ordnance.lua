--[[
	Fleet ordnance support.

	Forward observers mark a grid with binoculars. A fleet operator types that
	grid into an in-world console and dispatches support: orbital fire, bombs,
	LVS gun runs, supply drops, or the existing AAT dropship.
]]

MilBase.Ordnance = MilBase.Ordnance or {}

local ORD = MilBase.Ordnance
local cfg = MilBase.Config

cfg.OrdnanceGridScale = cfg.OrdnanceGridScale or 16
cfg.OrdnanceGridOffset = cfg.OrdnanceGridOffset or 32768
cfg.OrdnanceGridExpire = cfg.OrdnanceGridExpire or 900
cfg.OrdnanceConsoleRange = cfg.OrdnanceConsoleRange or 180
cfg.OrdnanceConsoleModel = cfg.OrdnanceConsoleModel or "models/props_lab/monitor01b.mdl"
cfg.OrdnanceSupplyCrateModel = cfg.OrdnanceSupplyCrateModel or "models/Items/item_item_crate.mdl"
cfg.OrdnanceMaxAirHeight = cfg.OrdnanceMaxAirHeight or 1800
cfg.OrdnanceAirCeilingMargin = cfg.OrdnanceAirCeilingMargin or 160

-- Operator-selectable orbital fire plan (number of turbolaser shots + spread).
cfg.OrdnanceOrbitalShots = cfg.OrdnanceOrbitalShots or 3
cfg.OrdnanceOrbitalShotsMax = cfg.OrdnanceOrbitalShotsMax or 8
cfg.OrdnanceOrbitalSpread = cfg.OrdnanceOrbitalSpread or 2
cfg.OrdnanceOrbitalSpreadMax = cfg.OrdnanceOrbitalSpreadMax or 12

-- Operator-selectable heavy bombardment munition load (HBOMBs class + salvo size).
cfg.OrdnanceHeavyLoad = cfg.OrdnanceHeavyLoad or 1
cfg.OrdnanceHeavyLoadMax = cfg.OrdnanceHeavyLoadMax or 6

cfg.OrdnanceHeartTurbolaserClasses = cfg.OrdnanceHeartTurbolaserClasses or {
	"heart_turbolaser_spawner",
	"heart_turbolaser",
	"heart_turbo_laser",
	"sent_heart_turbolaser",
	"sent_turbolaser",
}

cfg.OrdnanceHBombHeavyClasses = cfg.OrdnanceHBombHeavyClasses or {
	"hb_bomb_mk82",
	"hb_bomb_mk84",
	"hb_bomb_fab250",
	"hb_bomb_fab500",
	"hbomb_mk82",
	"hbomb_mk84",
	"gbomb_500lb",
	"gbomb_1000lb",
}

cfg.OrdnanceHBombGasClasses = cfg.OrdnanceHBombGasClasses or {
	"hb_bomb_gas",
	"hb_bomb_chemical",
	"hb_bomb_nervegas",
	"hbomb_gas",
	"hbomb_chemical",
	"gbomb_gas",
	"gbomb_chemical",
}

cfg.OrdnanceGunRunClass = cfg.OrdnanceGunRunClass or "auto"
cfg.OrdnanceWorkshopContent = cfg.OrdnanceWorkshopContent or {
	"2943090068", -- Heart Turbolaser Tool
	"668552230", -- HBOMBS Base Pack
	"668558959", -- HBOMBS Materials Pack
}

-- Optional addon bridge hooks. Define these in config if an addon exposes a
-- direct API and you want to bypass the built-in fallback behavior.
-- cfg.OrdnanceOrbitalHandler = function(owner, pos, grid, def) end
-- cfg.OrdnanceGasHandler = function(owner, pos, grid, def) end
-- cfg.OrdnanceHeavyHandler = function(owner, pos, grid, def) end

local gunshipClassCandidates = {
	"lvs_laat",
	"lvs_laatc",
	"lvs_republic_laat",
	"lvs_gunship_laat",
	"lvs_hmp",
	"lvs_hmp_gunship",
	"lvs_droid_gunship",
}

local SUPPORTS = {
	orbital = {
		name = "Orbital Turbolaser",
		desc = "Precision fleet strike from orbit.",
		delay = 6,
		cooldown = 45,
		radius = 430,
		damage = 320,
		color = Color(255, 210, 90),
	},
	gas = {
		name = "Gas Bomb",
		desc = "Area denial gas cloud with HBOMBs fallback support.",
		delay = 8,
		cooldown = 60,
		radius = 360,
		damage = 16,
		duration = 18,
		color = Color(130, 220, 110),
	},
	heavy = {
		name = "Heavy Bombardment",
		desc = "Large explosive strike with HBOMBs fallback support.",
		delay = 9,
		cooldown = 75,
		radius = 620,
		damage = 520,
		color = Color(255, 130, 70),
	},
	gunrun = {
		name = "LVS Gun Run",
		desc = "Gunship attack pass on the submitted grid.",
		delay = 5,
		cooldown = 50,
		radius = 180,
		damage = 70,
		duration = 24,
		color = Color(120, 190, 255),
	},
	supply = {
		name = "Supply Drop",
		desc = "Fleet drops a usable resupply crate.",
		delay = 7,
		cooldown = 40,
		radius = 180,
		damage = 0,
		color = Color(130, 210, 190),
	},
	aat = {
		name = "AAT Drop",
		desc = "Gunship deploys an AI AAT at the grid.",
		delay = 4,
		cooldown = 70,
		radius = 260,
		damage = 0,
		color = Color(220, 160, 255),
	},
}

local supportOrder = { "orbital", "gas", "heavy", "gunrun", "supply", "aat" }

ORD.ActiveGrids = ORD.ActiveGrids or {}
ORD.Cooldowns = ORD.Cooldowns or {}

function ORD.GetSupports()
	return SUPPORTS, supportOrder
end

local function cleanString(value, fallback)
	value = string.Trim(tostring(value or ""))
	return value ~= "" and value or fallback
end

local function notify(ply, text, kind)
	if IsValid(ply) and MilBase.Notify then
		MilBase.Notify(ply, text, kind)
	end
end

local function isHighCommand(ply)
	return MilBase.CommsIsHighCommand and MilBase.CommsIsHighCommand(ply)
end

function ORD.CanUseConsole(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if MilBase.Naval and MilBase.Naval.CanUseConsole
	and not MilBase.Naval.CanUseConsole(ply) then return false end
	if ply.MBHasCert and (ply:MBHasCert("fleet_operator") or ply:MBHasCert("high_command")) then return true end
	return isHighCommand(ply) == true
end

function ORD.CanMarkGrid(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	if MilBase.CanRunEvents and MilBase.CanRunEvents(ply) then return true end
	if ply.MBHasCert and (ply:MBHasCert("forward_observer") or ply:MBHasCert("sigint")) then return true end
	return false
end

function ORD.GridFromPos(pos)
	if not isvector(pos) then return "" end

	local scale = math.max(tonumber(cfg.OrdnanceGridScale) or 16, 1)
	local offset = tonumber(cfg.OrdnanceGridOffset) or 32768
	local maxValue = math.floor((offset * 2) / scale)
	local x = math.Clamp(math.floor((pos.x + offset) / scale + 0.5), 0, maxValue)
	local y = math.Clamp(math.floor((pos.y + offset) / scale + 0.5), 0, maxValue)

	return string.format("GRID %04X-%04X", x, y)
end

function ORD.PosFromGrid(grid)
	local raw = string.upper(tostring(grid or ""))
	local xHex, yHex = string.match(raw, "([0-9A-F][0-9A-F][0-9A-F][0-9A-F])%s*[-/: ]%s*([0-9A-F][0-9A-F][0-9A-F][0-9A-F])")
	if not xHex then return nil end

	local scale = math.max(tonumber(cfg.OrdnanceGridScale) or 16, 1)
	local offset = tonumber(cfg.OrdnanceGridOffset) or 32768
	local x = tonumber(xHex, 16)
	local y = tonumber(yHex, 16)
	if not x or not y then return nil end

	return Vector(x * scale - offset, y * scale - offset, 0), string.format("GRID %04X-%04X", x, y)
end

-- Snap a known impact point down to the floor beneath it. Bounded so a mark on
-- a wall/slope settles onto the ground without shooting up through the roof.
local function groundBelow(pos)
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 16),
		endpos = pos - Vector(0, 0, 8192),
		mask = MASK_SOLID_BRUSHONLY,
	})

	return tr.Hit and tr.HitPos or pos
end

-- Blind grid lookup (manually typed grid, no marker). We only have X/Y, so we
-- must trace top-down and cannot know the observer's real Z. On sealed/interior
-- maps this can hit a ceiling first; marked grids avoid this entirely because
-- MarkGrid stores the observer's actual impact point.
local function groundForGrid(grid)
	local pos, clean = ORD.PosFromGrid(grid)
	if not pos then return nil end

	local tr = util.TraceLine({
		start = Vector(pos.x, pos.y, 32760),
		endpos = Vector(pos.x, pos.y, -32760),
		mask = MASK_SOLID_BRUSHONLY,
	})

	return tr.Hit and tr.HitPos or pos, clean
end

function ORD.GetLatestGrid()
	local bestGrid, bestData, bestTime
	local now = CurTime()

	for grid, data in pairs(ORD.ActiveGrids or {}) do
		if data.expires and data.expires > now and isvector(data.pos) then
			if not bestTime or data.expires > bestTime then
				bestGrid = grid
				bestData = data
				bestTime = data.expires
			end
		end
	end

	return bestGrid, bestData
end

function ORD.ResolveGrid(grid)
	local _, clean = ORD.PosFromGrid(grid)
	if not clean then
		clean = ORD.GetLatestGrid()
		if not clean then return nil end
	end

	local marked = ORD.ActiveGrids[clean]
	if marked and marked.expires > CurTime() and isvector(marked.pos) then
		return marked.pos, clean, marked
	end

	local pos = groundForGrid(clean)
	return pos, clean
end

local function tagEventEntity(ent, owner)
	MilBase.EventEntities = MilBase.EventEntities or {}
	ent.mb_eventSpawned = true
	ent.mb_eventOwner = owner
	ent:SetNWBool("mb_event", true)
	table.insert(MilBase.EventEntities, ent)
end

local WORLD_SAFE_LIMIT = 15000

local function safeCoord(value)
	return math.Clamp(tonumber(value) or 0, -WORLD_SAFE_LIMIT, WORLD_SAFE_LIMIT)
end

local function safeWorldPos(pos)
	return Vector(safeCoord(pos.x), safeCoord(pos.y), safeCoord(pos.z))
end

local function safeAirPos(pos, height, minAbove)
	local maxHeight = math.min(tonumber(height) or cfg.OrdnanceMaxAirHeight, tonumber(cfg.OrdnanceMaxAirHeight) or 1800)
	local minHeight = tonumber(minAbove) or 96
	local margin = tonumber(cfg.OrdnanceAirCeilingMargin) or 160
	local start = safeWorldPos(pos + Vector(0, 0, 32))
	local wanted = safeWorldPos(pos + Vector(0, 0, maxHeight))
	local z = wanted.z

	local tr = util.TraceLine({
		start = start,
		endpos = wanted,
		mask = MASK_SOLID_BRUSHONLY,
	})

	if tr.Hit then
		local ceilingZ = tr.HitPos.z - margin
		local preferredZ = pos.z + minHeight

		if ceilingZ >= preferredZ then
			z = math.min(z, ceilingZ)
		else
			z = math.max(pos.z + 48, tr.HitPos.z - 24)
		end
	end

	return Vector(safeCoord(pos.x), safeCoord(pos.y), safeCoord(z))
end

local function safeOffsetPos(pos, offset)
	return safeWorldPos(pos + offset)
end

local function externalClassExists(class)
	return isstring(class) and class ~= "" and scripted_ents.GetStored(class) ~= nil
end

local function resolveExternalClass(candidates, matcher)
	for _, class in ipairs(candidates or {}) do
		if externalClassExists(class) then return class end
	end

	for class, stored in pairs(scripted_ents.GetList()) do
		local t = stored.t or {}
		local haystack = string.lower(class .. " " .. tostring(t.PrintName or "") .. " " .. tostring(t.Category or ""))
		if matcher(class, haystack, t) then return class end
	end
end

function ORD.ResolveHBombGasClass()
	return resolveExternalClass(cfg.OrdnanceHBombGasClasses, function(class, haystack)
		if string.find(haystack, "base", 1, true) then return false end
		local hbomb = string.find(haystack, "hbomb", 1, true)
			or string.find(haystack, "h-bomb", 1, true)
			or string.find(haystack, "hb_", 1, true)
			or string.find(haystack, "gbomb", 1, true)

		return hbomb and (string.find(haystack, "gas", 1, true)
			or string.find(haystack, "chemical", 1, true)
			or string.find(haystack, "nerve", 1, true))
	end)
end

function ORD.ResolveHBombHeavyClass()
	return resolveExternalClass(cfg.OrdnanceHBombHeavyClasses, function(class, haystack)
		if string.find(haystack, "base", 1, true) then return false end
		if string.find(haystack, "gas", 1, true)
		or string.find(haystack, "chemical", 1, true)
		or string.find(haystack, "nerve", 1, true) then
			return false
		end

		local hbomb = string.find(haystack, "hbomb", 1, true)
			or string.find(haystack, "h-bomb", 1, true)
			or string.find(haystack, "hb_", 1, true)
			or string.find(haystack, "gbomb", 1, true)

		return hbomb and (string.find(haystack, "mk82", 1, true)
			or string.find(haystack, "mk84", 1, true)
			or string.find(haystack, "fab", 1, true)
			or string.find(haystack, "bomb", 1, true))
	end)
end

-- Every mounted HBOMB/GBOMB munition the operator can pick as a heavy load.
-- Configured heavy classes are listed first (preferred order), then anything
-- else discovered on the server. Names come from each entity's PrintName.
function ORD.ListHBombClasses()
	local out, seen = {}, {}

	local function add(class)
		class = cleanString(class, "")
		if class == "" or seen[class] or not externalClassExists(class) then return end
		seen[class] = true
		local stored = scripted_ents.GetStored(class)
		local t = stored and stored.t or {}
		out[#out + 1] = { class = class, name = tostring(t.PrintName or class) }
	end

	for _, class in ipairs(cfg.OrdnanceHBombHeavyClasses or {}) do add(class) end

	for class, stored in pairs(scripted_ents.GetList()) do
		local t = stored.t or {}
		local haystack = string.lower(class .. " " .. tostring(t.PrintName or "") .. " " .. tostring(t.Category or ""))
		if not string.find(haystack, "base", 1, true) then
			local isBomb = string.find(haystack, "hbomb", 1, true)
				or string.find(haystack, "h-bomb", 1, true)
				or string.find(haystack, "hb_", 1, true)
				or string.find(haystack, "gbomb", 1, true)
			if isBomb then add(class) end
		end
	end

	return out
end

-- Validate an operator-requested munition class against the mounted list so a
-- crafted request can't spawn an arbitrary entity. Empty/unknown -> auto pick.
function ORD.ResolveHeavyLoadClass(requested)
	requested = cleanString(requested, "")
	if requested ~= "" then
		for _, info in ipairs(ORD.ListHBombClasses()) do
			if info.class == requested then return requested end
		end
	end
	return ORD.ResolveHBombHeavyClass()
end

if SERVER then
	util.AddNetworkString("MilBase_OrdnanceMarked")
	util.AddNetworkString("MilBase_OrdnanceOpen")
	util.AddNetworkString("MilBase_OrdnanceRequest")
	util.AddNetworkString("MilBase_OrdnanceCue")

	for _, id in ipairs(cfg.OrdnanceWorkshopContent or {}) do
		resource.AddWorkshop(id)
	end

	local function broadcastCue(phase, supportID, pos, grid, eta, radius)
		net.Start("MilBase_OrdnanceCue")
			net.WriteString(phase)
			net.WriteString(supportID)
			net.WriteVector(pos)
			net.WriteString(grid)
			net.WriteFloat(eta or 0)
			net.WriteFloat(radius or 0)
		net.Broadcast()
	end

	local function sendMarkedGrid(ply, grid, pos)
		net.Start("MilBase_OrdnanceMarked")
			net.WriteString(grid)
			net.WriteVector(pos)
		net.Send(ply)
	end

	function ORD.MarkGrid(ply, pos)
		if not ORD.CanMarkGrid(ply) then
			notify(ply, "You are not authorized to transmit fleet grids.", "danger")
			return false
		end

		if not isvector(pos) or not util.IsInWorld(pos) then
			notify(ply, "No valid grid lock.", "warn")
			return false
		end

		local grid = ORD.GridFromPos(pos)
		-- Keep the observer's real line-of-sight impact and only settle it to the
		-- floor beneath. Re-grounding from the sky (groundForGrid) hits the map
		-- roof / skybox brush on sealed or interior maps, which is why fire was
		-- landing on the ceiling instead of the target.
		local cleanPos = groundBelow(pos)

		ORD.ActiveGrids[grid] = {
			grid = grid,
			pos = cleanPos,
			by = IsValid(ply) and ply:MBName() or "Unknown",
			expires = CurTime() + (tonumber(cfg.OrdnanceGridExpire) or 900),
		}

		ply:SetNWString("mb_ordnance_grid", grid)
		ply:SetNWVector("mb_ordnance_pos", cleanPos)
		sendMarkedGrid(ply, grid, cleanPos)

		if MilBase.ChatMsg then
			MilBase.ChatMsg(nil, Color(120, 200, 255), "[FORWARD OBSERVER] ", color_white,
				(IsValid(ply) and ply:MBName() or "Observer") .. " transmitted " .. grid .. ".")
		end

		return true, grid
	end

	local function gridList()
		local out = {}
		local now = CurTime()

		for grid, data in pairs(ORD.ActiveGrids) do
			if data.expires <= now then
				ORD.ActiveGrids[grid] = nil
			else
				out[#out + 1] = {
					grid = grid,
					pos = data.pos,
					by = data.by or "Unknown",
					expires = data.expires,
				}
			end
		end

		table.SortByMember(out, "expires", true)
		return out
	end

	local function consoleState()
		return {
			grids = gridList(),
			cooldowns = ORD.Cooldowns,
			munitions = ORD.ListHBombClasses(),
			now = CurTime(),
		}
	end

	function ORD.OpenConsole(ply, console)
		if not ORD.CanUseConsole(ply) then
			notify(ply, "You are not authorized for fleet fire control.", "danger")
			return false
		end

		if not IsValid(console) or console:GetClass() ~= "mb_ordnance_console" then return false end
		if ply:GetPos():DistToSqr(console:GetPos()) > (tonumber(cfg.OrdnanceConsoleRange) or 180) ^ 2 then
			notify(ply, "Move closer to the fire control console.", "warn")
			return false
		end

		net.Start("MilBase_OrdnanceOpen")
			net.WriteEntity(console)
			net.WriteTable(consoleState())
		net.Send(ply)
		return true
	end

	local function spawnExternal(classes, pos, ang, owner, setup)
		for _, class in ipairs(classes or {}) do
			class = cleanString(class, "")
			if class == "" then continue end

			local ent = ents.Create(class)
			if not IsValid(ent) then continue end

			ent:SetPos(pos)
			ent:SetAngles(ang or angle_zero)
			if IsValid(owner) then
				ent:SetCreator(owner)
				ent:SetOwner(owner)
			end
			if setup then setup(ent) end
			ent:Spawn()
			ent:Activate()
			tagEventEntity(ent, owner)

			local phys = ent:GetPhysicsObject()
			if IsValid(phys) then phys:Wake() end

			return ent, class
		end
	end

	local function scorch(pos)
		util.Decal("Scorch", pos + Vector(0, 0, 64), pos - Vector(0, 0, 96))
	end

	local function blast(owner, pos, radius, damage, scale)
		local fx = EffectData()
		fx:SetOrigin(pos)
		fx:SetScale(scale or math.Clamp(radius / 220, 0.8, 4))
		util.Effect("Explosion", fx, true, true)
		util.BlastDamage(IsValid(owner) and owner or game.GetWorld(), IsValid(owner) and owner or game.GetWorld(), pos, radius, damage)
		util.ScreenShake(pos, math.Clamp(damage / 30, 8, 28), 180, 1.5, radius * 2)
		scorch(pos)
	end

	function ORD.ResolveOrbitalPlan(opts)
		opts = opts or {}
		local shots = math.Clamp(math.floor(tonumber(opts.count) or cfg.OrdnanceOrbitalShots),
			1, tonumber(cfg.OrdnanceOrbitalShotsMax) or 8)
		local spread = math.Clamp(tonumber(opts.spread) or cfg.OrdnanceOrbitalSpread,
			0, tonumber(cfg.OrdnanceOrbitalSpreadMax) or 12)
		return shots, spread
	end

	local function runOrbital(owner, pos, grid, def, opts)
		local shots, spread = ORD.ResolveOrbitalPlan(opts)

		if isfunction(cfg.OrdnanceOrbitalHandler) then
			cfg.OrdnanceOrbitalHandler(owner, pos, grid, def, { count = shots, spread = spread })
			return
		end

		local heart, heartClass = spawnExternal(cfg.OrdnanceHeartTurbolaserClasses, safeAirPos(pos, 5000, 512), Angle(90, 0, 0), owner, function(ent)
			ent:SetVar("speed", 5000)
			ent:SetVar("damage", def.damage)
			ent:SetVar("radius", def.radius)
			ent:SetVar("scale", 1.35)
			ent:SetVar("r", 255)
			ent:SetVar("g", 35)
			ent:SetVar("b", 20)
			ent:SetVar("shots", shots)
			ent:SetVar("delay", 0.18)
			ent:SetVar("spread", spread)

			if ent.SetTargetPos then ent:SetTargetPos(pos) end
			if ent.SetTarget then ent:SetTarget(pos) end
		end)

		if IsValid(heart) then
			heart.mb_eventName = heartClass
			return
		end

		-- Fallback (no Heart addon mounted): scatter blasts, jitter scaled by spread.
		local jitter = 45 * spread
		for i = 1, shots do
			timer.Simple((i - 1) * 0.18, function()
				if not isvector(pos) then return end
				local impact = pos + Vector(math.Rand(-jitter, jitter), math.Rand(-jitter, jitter), 0)
				blast(owner, impact, def.radius, def.damage, 2.5)
			end)
		end
	end

	local function damageGas(owner, pos, def)
		local dmgType = bit.bor(DMG_POISON, _G.DMG_NERVEGAS or 0)
		local dmg = DamageInfo()
		dmg:SetAttacker(IsValid(owner) and owner or game.GetWorld())
		dmg:SetInflictor(IsValid(owner) and owner or game.GetWorld())
		dmg:SetDamageType(dmgType)
		dmg:SetDamage(def.damage)

		for _, ent in ipairs(ents.FindInSphere(pos, def.radius)) do
			if IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or (ent.IsNextBot and ent:IsNextBot())) then
				ent:TakeDamageInfo(dmg)
			end
		end
	end

	local function runGas(owner, pos, grid, def)
		if isfunction(cfg.OrdnanceGasHandler) then
			cfg.OrdnanceGasHandler(owner, pos, grid, def)
			return
		end

		local gasClass = ORD.ResolveHBombGasClass()
		if gasClass then
			spawnExternal({ gasClass }, safeAirPos(pos, 900, 160), Angle(0, 0, 0), owner)
		end

		local smoke = ents.Create("env_smokestack")
		if IsValid(smoke) then
			smoke:SetPos(pos)
			smoke:SetKeyValue("InitialState", "1")
			smoke:SetKeyValue("BaseSpread", tostring(def.radius * 0.45))
			smoke:SetKeyValue("SpreadSpeed", "32")
			smoke:SetKeyValue("Speed", "38")
			smoke:SetKeyValue("StartSize", "95")
			smoke:SetKeyValue("EndSize", "210")
			smoke:SetKeyValue("Rate", "48")
			smoke:SetKeyValue("JetLength", "260")
			smoke:SetKeyValue("Twist", "24")
			smoke:SetKeyValue("SmokeMaterial", "particle/particle_smokegrenade")
			smoke:SetKeyValue("RenderColor", "110 190 90")
			smoke:Spawn()
			smoke:Activate()
			smoke:Fire("TurnOn")
			timer.Simple(def.duration, function()
				if IsValid(smoke) then smoke:Remove() end
			end)
		end

		local timerName = "MilBase_OrdnanceGas_" .. string.gsub(grid, "%W", "") .. "_" .. math.floor(CurTime())
		timer.Create(timerName, 1, def.duration, function()
			if not isvector(pos) then return end
			damageGas(owner, pos, def)
			local fx = EffectData()
			fx:SetOrigin(pos + Vector(math.Rand(-80, 80), math.Rand(-80, 80), 16))
			fx:SetScale(0.8)
			util.Effect("ThumperDust", fx, true, true)
		end)
	end

	local function runHeavy(owner, pos, grid, def, opts)
		opts = opts or {}
		local load = math.Clamp(math.floor(tonumber(opts.load) or cfg.OrdnanceHeavyLoad),
			1, tonumber(cfg.OrdnanceHeavyLoadMax) or 6)

		if isfunction(cfg.OrdnanceHeavyHandler) then
			cfg.OrdnanceHeavyHandler(owner, pos, grid, def, { munition = opts.munition, load = load })
			return
		end

		local heavyClass = ORD.ResolveHeavyLoadClass(opts.munition)
		if heavyClass then
			-- Drop the selected munition as a salvo, scattered across the target.
			for i = 1, load do
				timer.Simple((i - 1) * 0.25, function()
					if not isvector(pos) then return end
					local jitter = load > 1 and def.radius * 0.5 or 0
					local drop = pos + Vector(math.Rand(-jitter, jitter), math.Rand(-jitter, jitter), 0)
					spawnExternal({ heavyClass }, safeAirPos(drop, 1100, 180), Angle(0, 0, 0), owner)
				end)
			end
			return
		end

		for i = 1, 5 do
			timer.Simple((i - 1) * 0.32, function()
				if not isvector(pos) then return end
				local impact = pos + Vector(math.Rand(-220, 220), math.Rand(-220, 220), 0)
				blast(owner, impact, def.radius * (i == 3 and 1 or 0.55), def.damage * (i == 3 and 1 or 0.45), i == 3 and 3.5 or 1.8)
			end)
		end
	end

	function ORD.ResolveGunshipClass(requested)
		requested = cleanString(requested, "auto")

		if requested ~= "auto" and scripted_ents.GetStored(requested) then
			return requested
		end

		for _, class in ipairs(gunshipClassCandidates) do
			if scripted_ents.GetStored(class) then return class end
		end

		for class, stored in pairs(scripted_ents.GetList()) do
			local t = stored.t or {}
			local haystack = string.lower(class .. " " .. tostring(t.PrintName or "") .. " " .. tostring(t.Category or ""))
			local isGunship = string.find(haystack, "laat", 1, true)
				or (string.find(haystack, "hmp", 1, true) and string.find(haystack, "gunship", 1, true))

			if isGunship and string.find(haystack, "lvs", 1, true) then
				return class
			end
		end
	end

	local function runFallbackGunRun(owner, pos, def)
		local yaw = IsValid(owner) and owner:EyeAngles().y or math.random(0, 359)
		local dir = Angle(0, yaw, 0):Forward()
		local right = Angle(0, yaw, 0):Right()

		for i = 1, 16 do
			timer.Simple(i * 0.16, function()
				if not isvector(pos) then return end
				local impact = pos + dir * math.Rand(-850, 850) + right * math.Rand(-160, 160)
				local start = impact - dir * 1100 + Vector(0, 0, 760)
				local tr = util.TraceLine({
					start = start,
					endpos = impact - Vector(0, 0, 240),
					mask = MASK_SHOT,
				})

				local fx = EffectData()
				fx:SetStart(start)
				fx:SetOrigin(tr.HitPos)
				fx:SetScale(1)
				util.Effect("AR2Tracer", fx, true, true)
				util.BlastDamage(IsValid(owner) and owner or game.GetWorld(), IsValid(owner) and owner or game.GetWorld(),
					tr.HitPos, def.radius, def.damage)

				if i % 3 == 0 then
					local boom = EffectData()
					boom:SetOrigin(tr.HitPos)
					boom:SetScale(0.6)
					util.Effect("cball_explode", boom, true, true)
				end
			end)
		end
	end

	local function runGunRun(owner, pos, grid, def)
		local class = ORD.ResolveGunshipClass(cfg.OrdnanceGunRunClass)
		local spawned

		if class and MilBase.DoEventSpawn then
			local yaw = IsValid(owner) and owner:EyeAngles().y or math.random(0, 359)
			local dir = Angle(0, yaw, 0):Forward()
			local start = safeOffsetPos(pos, -dir * 2600 + Vector(0, 0, 900))

			spawned = MilBase.DoEventSpawn(owner, {
				name = class,
				category = "Ordnance",
				kind = "lvs",
				class = class,
				ai = true,
			}, start, yaw, { team = "friendly" })

			local bull = ents.Create("npc_bullseye")
			if IsValid(bull) then
				bull:SetPos(pos + Vector(0, 0, 40))
				bull:SetKeyValue("solid", "0")
				bull:Spawn()
				bull:SetHealth(999999)
				bull:SetNoDraw(true)
				tagEventEntity(bull, owner)

				if IsValid(spawned) and spawned.SetHardLockTarget then
					spawned:SetHardLockTarget(bull)
				end

				timer.Simple(def.duration, function()
					if IsValid(bull) then bull:Remove() end
				end)
			end

			if IsValid(spawned) then
				timer.Simple(def.duration + 10, function()
					if IsValid(spawned) and spawned.mb_eventSpawned then spawned:Remove() end
				end)
			end
		end

		if not IsValid(spawned) then
			runFallbackGunRun(owner, pos, def)
		end
	end

	local function spawnSupplyGunship(owner, pos)
		local class = ORD.ResolveGunshipClass(cfg.OrdnanceGunRunClass)
		if not class or not MilBase.DoEventSpawn then return end

		local yaw = IsValid(owner) and owner:EyeAngles().y or math.random(0, 359)
		local dir = Angle(0, yaw, 0):Forward()
		local start = safeOffsetPos(pos, -dir * 2400 + Vector(0, 0, 850))
		local spawned = MilBase.DoEventSpawn(owner, {
			name = class,
			category = "Ordnance",
			kind = "lvs",
			class = class,
			ai = true,
		}, start, yaw, { team = "friendly" })

		if not IsValid(spawned) then return end

		local beacon = ents.Create("npc_bullseye")
		if IsValid(beacon) then
			beacon:SetPos(safeOffsetPos(pos, dir * 1800 + Vector(0, 0, 850)))
			beacon:SetKeyValue("solid", "0")
			beacon:Spawn()
			beacon:SetHealth(999999)
			beacon:SetNoDraw(true)
			tagEventEntity(beacon, owner)

			if spawned.SetHardLockTarget then
				spawned:SetHardLockTarget(beacon)
			end
		end

		timer.Simple(24, function()
			if IsValid(beacon) then beacon:Remove() end
			if IsValid(spawned) and spawned.mb_eventSpawned then spawned:Remove() end
		end)
	end

	local function runSupply(owner, pos, grid, def)
		spawnSupplyGunship(owner, pos)

		local crate = ents.Create("mb_supply_drop")
		if not IsValid(crate) then
			crate = ents.Create("prop_physics")
		end

		if not IsValid(crate) then return end

		if crate:GetClass() == "prop_physics" then
			local model = cfg.OrdnanceSupplyCrateModel
			if not util.IsValidModel(model) then model = "models/props_junk/wood_crate002a.mdl" end
			crate:SetModel(model)
		end

		crate:SetPos(safeAirPos(pos, 850, 160))
		crate:SetAngles(Angle(0, math.random(0, 359), 0))
		if IsValid(owner) then crate:SetCreator(owner) end
		crate:Spawn()
		crate:Activate()
		tagEventEntity(crate, owner)

		local phys = crate:GetPhysicsObject()
		if IsValid(phys) then
			phys:Wake()
			phys:SetVelocity(Vector(0, 0, -140))
			phys:AddAngleVelocity(VectorRand() * 120)
		end

		local fx = EffectData()
		fx:SetOrigin(pos + Vector(0, 0, 120))
		fx:SetScale(1.1)
		util.Effect("ThumperDust", fx, true, true)
	end

	local function runAAT(owner, pos)
		if not MilBase.StartVehicleDropshipDrop then
			notify(owner, "AAT dropship support is not loaded.", "danger")
			return
		end

		MilBase.StartVehicleDropshipDrop(owner, pos, {
			vehicleClass = "auto",
			vehicleModel = "auto",
			carrierModel = "auto",
			team = "friendly",
			approachTime = 6,
			holdTime = 4,
			departureTime = 6,
			hoverHeight = 185,
			dropDelay = 1,
			turnAround = true,
			carryUp = -95,
		})
	end

	local runSupport = {
		orbital = runOrbital,
		gas = runGas,
		heavy = runHeavy,
		gunrun = runGunRun,
		supply = runSupply,
		aat = runAAT,
	}

	function ORD.RequestSupport(ply, console, grid, supportID, opts)
		if not ORD.CanUseConsole(ply) then
			notify(ply, "You are not authorized for fleet fire control.", "danger")
			return false
		end

		if not IsValid(console) or console:GetClass() ~= "mb_ordnance_console" then return false end
		if ply:GetPos():DistToSqr(console:GetPos()) > (tonumber(cfg.OrdnanceConsoleRange) or 180) ^ 2 then
			notify(ply, "Move closer to the fire control console.", "warn")
			return false
		end

		local def = SUPPORTS[supportID]
		local runner = runSupport[supportID]
		if not def or not runner then
			notify(ply, "Unknown support package.", "danger")
			return false
		end

		local now = CurTime()
		local ready = ORD.Cooldowns[supportID] or 0
		if ready > now then
			notify(ply, def.name .. " cooling down: " .. math.ceil(ready - now) .. "s.", "warn")
			return false
		end

		local pos, clean = ORD.ResolveGrid(grid)
		if not pos and IsValid(console) then
			pos, clean = ORD.ResolveGrid(console:GetActiveGrid())
		end
		if not pos and IsValid(ply) then
			pos, clean = ORD.ResolveGrid(ply:GetNWString("mb_ordnance_grid", ""))
		end
		if not pos then
			notify(ply, "Invalid grid area.", "danger")
			return false
		end

		ORD.Cooldowns[supportID] = now + def.cooldown
		console:SetActiveGrid(clean)
		console:SetStatus("QUEUED " .. string.upper(def.name))
		console:SetReadyTime(now + def.delay)

		if MilBase.ChatMsg then
			MilBase.ChatMsg(nil, Color(255, 198, 60), "[FLEET FIRE CONTROL] ", color_white,
				(IsValid(ply) and ply:MBName() or "Operator") .. " authorized " .. def.name .. " at " .. clean .. ".")
		end

		broadcastCue("incoming", supportID, pos, clean, def.delay, def.radius)

		timer.Simple(def.delay, function()
			if IsValid(console) then
				console:SetStatus("FIRED " .. string.upper(def.name))
				console:SetReadyTime(CurTime() + 2)
			end

			if supportID == "orbital" then
				broadcastCue("beam", supportID, pos, clean, 0.85, def.radius)
			end

			broadcastCue("impact", supportID, pos, clean, 0, def.radius)
			runner(ply, pos, clean, def, opts)
		end)

		net.Start("MilBase_OrdnanceOpen")
			net.WriteEntity(console)
			net.WriteTable(consoleState())
		net.Send(ply)

		return true
	end

	net.Receive("MilBase_OrdnanceRequest", function(_, ply)
		local console = net.ReadEntity()
		local grid = net.ReadString()
		local supportID = net.ReadString()
		local opts = {
			count = net.ReadUInt(8),
			spread = net.ReadFloat(),
			munition = net.ReadString(),
			load = net.ReadUInt(8),
		}
		ORD.RequestSupport(ply, console, grid, supportID, opts)
	end)

	MilBase.RegisterChatCommand("ordconsole", {
		help = "Place a fleet fire control console where you are aiming.",
		func = function(ply)
			if not ORD.CanUseConsole(ply) then
				notify(ply, "You are not authorized to place fire control consoles.", "danger")
				return
			end

			local tr = ply:GetEyeTrace()
			if not tr.Hit or not util.IsInWorld(tr.HitPos) then
				notify(ply, "Aim at a valid console location.", "warn")
				return
			end

			local ent = ents.Create("mb_ordnance_console")
			if not IsValid(ent) then
				notify(ply, "Could not create ordnance console.", "danger")
				return
			end

			ent:SetPos(tr.HitPos + tr.HitNormal * 4)
			ent:SetAngles(Angle(0, ply:EyeAngles().y + 180, 0))
			ent:Spawn()
			ent:Activate()

			local phys = ent:GetPhysicsObject()
			if IsValid(phys) then phys:EnableMotion(false) end

			notify(ply, "Fleet fire control console placed.", "ok")
		end,
	})

	MilBase.RegisterChatCommand("ordscan", {
		help = "Print mounted Heart Turbolaser and HBOMBS entity classes.",
		func = function(ply)
			if not ORD.CanUseConsole(ply) then
				notify(ply, "You are not authorized for ordnance diagnostics.", "danger")
				return
			end

			local found = {}
			for class, stored in pairs(scripted_ents.GetList()) do
				local t = stored.t or {}
				local haystack = string.lower(class .. " " .. tostring(t.PrintName or "") .. " " .. tostring(t.Category or ""))
				local relevant = string.find(haystack, "heart_turbolaser", 1, true)
					or string.find(haystack, "turbolaser", 1, true)
					or string.find(haystack, "hbomb", 1, true)
					or string.find(haystack, "h-bomb", 1, true)
					or string.find(haystack, "hb_", 1, true)
					or string.find(haystack, "gbomb", 1, true)

				if relevant then
					found[#found + 1] = string.format("%s | %s | %s",
						class,
						tostring(t.PrintName or ""),
						tostring(t.Category or ""))
				end
			end

			table.sort(found)

			if #found == 0 then
				notify(ply, "No Heart/HBOMBS scripted entities are mounted yet.", "warn")
				return
			end

			ply:PrintMessage(HUD_PRINTCONSOLE, "[MilBase Ordnance] Mounted support classes:")
			for _, line in ipairs(found) do
				ply:PrintMessage(HUD_PRINTCONSOLE, "  " .. line)
			end
			notify(ply, "Printed " .. #found .. " support class(es) to console.", "ok")
		end,
	})
else
	ORD.Cues = ORD.Cues or {}
	ORD.Beams = ORD.Beams or {}

	local beamMat = Material("sprites/physbeam")

	net.Receive("MilBase_OrdnanceMarked", function()
		local grid = net.ReadString()
		local pos = net.ReadVector()
		LocalPlayer().mb_ordnanceLastGrid = grid
		LocalPlayer().mb_ordnanceLastPos = pos
		MilBase.Notify("Grid transmitted: " .. grid)
	end)

	net.Receive("MilBase_OrdnanceCue", function()
		local phase = net.ReadString()
		local supportID = net.ReadString()
		local pos = net.ReadVector()
		local grid = net.ReadString()
		local eta = net.ReadFloat()
		local radius = net.ReadFloat()
		local def = SUPPORTS[supportID] or SUPPORTS.orbital

		if phase == "incoming" then
			ORD.Cues[#ORD.Cues + 1] = {
				id = supportID,
				name = def.name,
				pos = pos,
				grid = grid,
				radius = radius,
				start = CurTime(),
				expires = CurTime() + eta,
				color = def.color,
			}
			surface.PlaySound("buttons/button17.wav")
		elseif phase == "beam" then
			ORD.Beams[#ORD.Beams + 1] = {
				id = supportID,
				pos = pos,
				grid = grid,
				radius = radius,
				start = CurTime(),
				expires = CurTime() + math.max(eta, 0.25),
				color = def.color or Color(255, 198, 60),
			}
			surface.PlaySound("ambient/energy/weld1.wav")
		else
			local fx = EffectData()
			fx:SetOrigin(pos)
			fx:SetScale(math.Clamp(radius / 180, 0.8, 4))

			if supportID == "orbital" or supportID == "heavy" then
				util.Effect("Explosion", fx)
				util.Effect("HelicopterMegaBomb", fx)
				util.Effect("cball_explode", fx)
				surface.PlaySound("ambient/explosions/explode_4.wav")
			elseif supportID == "gas" then
				util.Effect("ThumperDust", fx)
				surface.PlaySound("ambient/levels/canals/toxic_slime_sizzle3.wav")
			elseif supportID == "gunrun" then
				util.Effect("cball_explode", fx)
				surface.PlaySound("weapons/ar2/fire1.wav")
			elseif supportID == "supply" or supportID == "aat" then
				util.Effect("ThumperDust", fx)
				surface.PlaySound("items/ammo_pickup.wav")
			else
				util.Effect("cball_explode", fx)
				surface.PlaySound("ambient/explosions/explode_4.wav")
			end
		end
	end)

	local function drawButton(btn, w, h, label, sub, active)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 7,
			color = active and Color(255, 198, 60, 28) or Color(8, 10, 12, 225),
			outlineColor = active and ui.accent or ui.outline,
		})
		draw.SimpleText(label, "MB.Small", 10, 8, ui.text)
		draw.SimpleText(sub or "", "MB.Tiny", 10, 29, active and ui.accent or ui.dim)
	end

	function ORD.OpenConsoleUI(console, state)
		if IsValid(ORD.Frame) then ORD.Frame:Remove() end

		local ui = MilBase.UI
		local supports, order = ORD.GetSupports()
		local frame = vgui.Create("DFrame")
		ORD.Frame = frame
		frame:SetSize(math.min(ScrW() - 80, 760), math.min(ScrH() - 80, 560))
		frame:Center()
		frame:SetTitle("")
		frame:MakePopup()
		frame:ShowCloseButton(false)
		frame.Paint = function(self, w, h)
			MilBase.DrawBlur(self, 4)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 14, color = Color(4, 8, 10, 242), outlineColor = ui.accent })
			draw.SimpleText("FLEET FIRE CONTROL", "MB.Tab", 20, 16, ui.accent)
			draw.SimpleText("ORDNANCE UPLINK", "MB.Tiny", 22, 48, ui.dim)
		end

		local close = vgui.Create("DButton", frame)
		close:SetText("")
		close:SetSize(34, 28)
		close:SetPos(frame:GetWide() - 48, 14)
		close.DoClick = function() frame:Remove() end
		close.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6, color = Color(45, 16, 14, 230), outlineColor = ui.danger })
			draw.SimpleText("X", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local defaultGrid = LocalPlayer():GetNWString("mb_ordnance_grid", "")
		if defaultGrid == "" and state and state.grids and state.grids[1] then
			defaultGrid = state.grids[1].grid or ""
		end

		local gridEntry = vgui.Create("DTextEntry", frame)
		gridEntry:SetPos(22, 78)
		gridEntry:SetSize(frame:GetWide() - 44, 38)
		gridEntry:SetFont("MB.Med")
		gridEntry:SetText(defaultGrid)
		gridEntry:SetTextColor(ui.text)
		gridEntry:SetCursorColor(ui.accent)
		gridEntry:SetPaintBackground(false)
		gridEntry.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = Color(0, 0, 0, 180), outlineColor = ui.outline })
			self:DrawTextEntryText(ui.text, ui.accent, ui.text)
		end

		local left = vgui.Create("DScrollPanel", frame)
		left:SetPos(22, 132)
		left:SetSize(255, frame:GetTall() - 154)
		left.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = Color(5, 8, 10, 165), outlineColor = ui.outline })
			draw.SimpleText("RECENT GRID AREAS", "MB.Tiny", 12, 9, ui.dim)
		end

		local y = 34
		for _, data in ipairs((state and state.grids) or {}) do
			local row = vgui.Create("DButton", left)
			row:SetText("")
			row:SetPos(10, y)
			row:SetSize(230, 42)
			row.DoClick = function()
				gridEntry:SetText(data.grid or "")
			end
			row.Paint = function(self, w, h)
				drawButton(self, w, h, data.grid or "GRID", data.by or "Unknown", self:IsHovered())
			end
			y = y + 48
		end

		if y == 34 then
			local empty = vgui.Create("DLabel", left)
			empty:SetPos(12, 38)
			empty:SetSize(220, 60)
			empty:SetFont("MB.Tiny")
			empty:SetTextColor(ui.dim)
			empty:SetWrap(true)
			empty:SetText("No active binocular grids.")
		end

		local right = vgui.Create("DPanel", frame)
		right:SetPos(292, 132)
		right:SetSize(frame:GetWide() - 314, frame:GetTall() - 154)
		right.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, color = Color(5, 8, 10, 165), outlineColor = ui.outline })
			draw.SimpleText("SUPPORT PACKAGES", "MB.Tiny", 12, 9, ui.dim)
		end

		local now = (state and state.now) or CurTime()
		local cooldowns = (state and state.cooldowns) or {}
		local bw = math.floor((right:GetWide() - 34) / 2)

		for index, id in ipairs(order) do
			local def = supports[id]
			local bx = 12 + ((index - 1) % 2) * (bw + 10)
			local by = 34 + math.floor((index - 1) / 2) * 76
			local btn = vgui.Create("DButton", right)
			btn:SetText("")
			btn:SetPos(bx, by)
			btn:SetSize(bw, 66)
			btn.DoClick = function()
				net.Start("MilBase_OrdnanceRequest")
					net.WriteEntity(console)
					net.WriteString(gridEntry:GetText())
					net.WriteString(id)
					net.WriteUInt(math.floor(ORD.OrbitalShots or cfg.OrdnanceOrbitalShots), 8)
					net.WriteFloat(ORD.OrbitalSpread or cfg.OrdnanceOrbitalSpread)
					net.WriteString(ORD.HeavyMunition or "")
					net.WriteUInt(math.floor(ORD.HeavyLoad or cfg.OrdnanceHeavyLoad), 8)
				net.SendToServer()
			end
			btn.Paint = function(self, w, h)
				local remain = math.max((cooldowns[id] or 0) - now, 0)
				local sub = remain > 0 and ("COOLDOWN " .. math.ceil(remain) .. "S") or ("ETA " .. def.delay .. "S")
				if remain <= 0 then
					if id == "orbital" then
						sub = "ETA " .. def.delay .. "S   x" .. (ORD.OrbitalShots or cfg.OrdnanceOrbitalShots)
					elseif id == "heavy" then
						sub = "ETA " .. def.delay .. "S   x" .. (ORD.HeavyLoad or cfg.OrdnanceHeavyLoad)
					end
				end
				drawButton(self, w, h, string.upper(def.name), sub, self:IsHovered() and remain <= 0)
			end
		end

		-- Persisted fire-plan selections.
		ORD.OrbitalShots = math.Clamp(math.floor(ORD.OrbitalShots or cfg.OrdnanceOrbitalShots or 3),
			1, cfg.OrdnanceOrbitalShotsMax or 8)
		ORD.OrbitalSpread = math.Clamp(ORD.OrbitalSpread or cfg.OrdnanceOrbitalSpread or 2,
			0, cfg.OrdnanceOrbitalSpreadMax or 12)
		ORD.HeavyLoad = math.Clamp(math.floor(ORD.HeavyLoad or cfg.OrdnanceHeavyLoad or 1),
			1, cfg.OrdnanceHeavyLoadMax or 6)

		-- Heavy munition options: AUTO first, then every mounted HBOMBs class.
		local munOptions = { { class = "", name = "AUTO (BEST)" } }
		for _, m in ipairs((state and state.munitions) or {}) do
			munOptions[#munOptions + 1] = m
		end
		local munIndex = 1
		for i, m in ipairs(munOptions) do
			if m.class == (ORD.HeavyMunition or "") then munIndex = i break end
		end
		ORD.HeavyMunition = munOptions[munIndex].class

		local function sectionLabel(x, y, text)
			local lbl = vgui.Create("DLabel", right)
			lbl:SetPos(x, y)
			lbl:SetFont("MB.Tiny")
			lbl:SetTextColor(ui.dim)
			lbl:SetText(text)
			lbl:SizeToContents()
		end

		local function panelButton(parent, bx, txt, onClick)
			local b = vgui.Create("DButton", parent)
			b:SetText("")
			b:SetSize(24, 26)
			b:SetPos(bx, 6)
			b.DoClick = function()
				onClick()
				surface.PlaySound("buttons/button24.wav")
			end
			b.Paint = function(self, w, h)
				MilBase.DrawPanelBF2(0, 0, w, h, {
					cut = 5,
					color = self:IsHovered() and Color(255, 198, 60, 45) or Color(0, 0, 0, 180),
					outlineColor = ui.outline,
				})
				draw.SimpleText(txt, "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		local function makeStepper(x, y, w, label, get, set, min, max, step)
			local row = vgui.Create("DPanel", right)
			row:SetPos(x, y)
			row:SetSize(w, 38)
			row.Paint = function(_, pw, ph)
				MilBase.DrawPanelBF2(0, 0, pw, ph, { cut = 6, color = Color(8, 10, 12, 205), outlineColor = ui.outline })
				draw.SimpleText(label, "MB.Tiny", 12, ph / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(tostring(get()), "MB.Small", pw - 62, ph / 2, ui.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			panelButton(row, w - 94, "-", function() set(math.Clamp(get() - step, min, max)) end)
			panelButton(row, w - 30, "+", function() set(math.Clamp(get() + step, min, max)) end)
		end

		local function makeCycler(x, y, w)
			local row = vgui.Create("DPanel", right)
			row:SetPos(x, y)
			row:SetSize(w, 38)
			row.Paint = function(_, pw, ph)
				MilBase.DrawPanelBF2(0, 0, pw, ph, { cut = 6, color = Color(8, 10, 12, 205), outlineColor = ui.outline })
				local nm = munOptions[munIndex] and munOptions[munIndex].name or "AUTO"
				draw.SimpleText(nm, "MB.Tiny", pw / 2, ph / 2, ui.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end

			local function cycle(delta)
				munIndex = ((munIndex - 1 + delta) % #munOptions) + 1
				ORD.HeavyMunition = munOptions[munIndex].class
			end
			panelButton(row, 6, "<", function() cycle(-1) end)
			panelButton(row, w - 30, ">", function() cycle(1) end)
		end

		local colW = math.floor((right:GetWide() - 30) / 2)
		local col1X, col2X = 12, 12 + colW + 6
		local headerY = right:GetTall() - 118
		local row1Y = headerY + 18
		local row2Y = row1Y + 44

		-- Left column: orbital strike plan.
		sectionLabel(col1X, headerY, "ORBITAL STRIKE")
		makeStepper(col1X, row1Y, colW, "TURBOLASERS", function() return ORD.OrbitalShots end,
			function(v) ORD.OrbitalShots = v end, 1, cfg.OrdnanceOrbitalShotsMax or 8, 1)
		makeStepper(col1X, row2Y, colW, "SPREAD", function() return ORD.OrbitalSpread end,
			function(v) ORD.OrbitalSpread = v end, 0, cfg.OrdnanceOrbitalSpreadMax or 12, 1)

		-- Right column: heavy bombardment munition load.
		sectionLabel(col2X, headerY, "HEAVY LOAD")
		makeCycler(col2X, row1Y, colW)
		makeStepper(col2X, row2Y, colW, "SALVO", function() return ORD.HeavyLoad end,
			function(v) ORD.HeavyLoad = v end, 1, cfg.OrdnanceHeavyLoadMax or 6, 1)
	end

	net.Receive("MilBase_OrdnanceOpen", function()
		local console = net.ReadEntity()
		local state = net.ReadTable()
		ORD.OpenConsoleUI(console, state)
	end)

	hook.Add("PostDrawTranslucentRenderables", "MilBase.OrdnanceCues", function()
		local now = CurTime()
		render.SetMaterial(beamMat)
		for i = #ORD.Beams, 1, -1 do
			local beam = ORD.Beams[i]
			if beam.expires <= now then
				table.remove(ORD.Beams, i)
			else
				local life = math.max(beam.expires - beam.start, 0.01)
				local frac = math.Clamp((beam.expires - now) / life, 0, 1)
				local col = beam.color or Color(255, 198, 60)
				local alpha = 230 * frac
				local start = safeAirPos(beam.pos, 4800, 256)
				local width = math.max(38, (beam.radius or 300) * 0.12) * (0.55 + frac * 0.65)

				cam.IgnoreZ(true)
				render.DrawBeam(start, beam.pos + Vector(0, 0, 18), width, 0, 1,
					Color(col.r, col.g, col.b, alpha))
				render.DrawWireframeSphere(beam.pos + Vector(0, 0, 16), math.max(80, beam.radius or 260), 48, 10,
					Color(col.r, col.g, col.b, alpha * 0.75), true)
				cam.IgnoreZ(false)
			end
		end

		for i = #ORD.Cues, 1, -1 do
			local cue = ORD.Cues[i]
			if cue.expires <= now then
				table.remove(ORD.Cues, i)
			else
				local frac = math.Clamp((cue.expires - now) / math.max(cue.expires - cue.start, 0.01), 0, 1)
				local col = cue.color or Color(255, 198, 60)
				render.DrawWireframeSphere(cue.pos + Vector(0, 0, 8), cue.radius * (1.05 - frac * 0.25), 32, 8,
					Color(col.r, col.g, col.b, 160), true)
			end
		end
	end)

	hook.Add("HUDPaint", "MilBase.OrdnanceHUDCues", function()
		local now = CurTime()
		local cue = ORD.Cues[#ORD.Cues]
		if not cue or cue.expires <= now then return end

		local ui = MilBase.UI
		local remain = math.max(cue.expires - now, 0)
		local w, h = 360, 46
		local x, y = ScrW() / 2 - w / 2, 72
		MilBase.DrawPanelBF2(x, y, w, h, { cut = 8, color = Color(0, 0, 0, 185), outlineColor = cue.color or ui.accent })
		draw.SimpleText(string.upper(cue.name), "MB.Small", x + 14, y + 9, cue.color or ui.accent)
		draw.SimpleText(cue.grid .. "  T-" .. string.format("%.1f", remain), "MB.Tiny", x + 14, y + 28, ui.text)
	end)
end
