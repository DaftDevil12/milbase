--[[
	Management-only, persistent ArcCW weapon tuning.

	The editor deliberately changes a small, safe set of base weapon stats. It
	does not edit arbitrary SWEP fields, attachment definitions or weapon files.
	Overrides are applied to the stored SWEP table and every existing/future
	weapon entity on both server and client, so ArcCW prediction stays in step.
]]

local cfg = MilBase.Config
local E = MilBase.ArcCWWeaponEditor or {}
MilBase.ArcCWWeaponEditor = E

E.Overrides = E.Overrides or {}
E.BaseStats = E.BaseStats or {}

local NET_REQUEST = "MilBase_ArcCWWeaponEditorRequest"
local NET_EDITOR_SYNC = "MilBase_ArcCWWeaponEditorEditorSync"
local NET_OVERRIDE_SYNC = "MilBase_ArcCWWeaponEditorOverrideSync"
local NET_ACTION = "MilBase_ArcCWWeaponEditorAction"
local MAX_NETWORK_BYTES = 256 * 1024

local STATS = {
	{ id = "damage", label = "MAX DAMAGE", key = "Damage", minimum = 0.1, maximum = 5000, decimals = 2 },
	{ id = "damage_min", label = "MIN DAMAGE", key = "DamageMin", minimum = 0.1, maximum = 5000, decimals = 2 },
	{ id = "rpm", label = "FIRE RATE (RPM)", minimum = 30, maximum = 6000, integer = true },
	{ id = "range", label = "DAMAGE RANGE (METRES)", key = "Range", minimum = 1, maximum = 50000, decimals = 1 },
	{ id = "recoil", label = "RECOIL", key = "Recoil", minimum = 0, maximum = 100, decimals = 2 },
	{ id = "accuracy_moa", label = "HIP SPREAD (MOA)", key = "AccuracyMOA", minimum = 0, maximum = 180, decimals = 2 },
	{ id = "penetration", label = "PENETRATION", key = "Penetration", minimum = 0, maximum = 2000, decimals = 2 },
	{ id = "clip_size", label = "MAGAZINE CAPACITY", key = "ClipSize", minimum = 1, maximum = 500, integer = true },
	{ id = "muzzle_velocity", label = "MUZZLE VELOCITY", key = "MuzzleVelocity", minimum = 1, maximum = 100000, decimals = 0 },
}

E.Stats = STATS

local function managementLevel()
	return math.max(1, math.floor(tonumber(cfg.ArcCWWeaponEditorStaffLevel) or 6))
end

local function isArcCWWeapon(class, definition)
	if not isstring(class) or not istable(definition) then return false end
	class = string.lower(class)
	if class == "arccw_base" or class == "arccw_base_nade" then return false end
	if definition.ArcCW == true or string.StartWith(class, "arccw_") then return true end
	return isstring(definition.Base)
		and string.find(string.lower(definition.Base), "arccw", 1, true) ~= nil
end

local function statValue(definition, stat)
	if stat.id == "rpm" then
		local rpm = tonumber(definition.RPM)
		if rpm then return rpm end
		local delay = tonumber(definition.Delay)
		return delay and delay > 0 and 60 / delay or nil
	end
	return tonumber(definition[stat.key])
end

local function captureBase(class, definition)
	local known = E.BaseStats[class]
	if known then return known end

	-- Stored SWEP tables omit inherited ArcCW base values. Read a resolved copy
	-- for the editor, but retain the child table's raw fields so Reset can put
	-- the class back exactly as its addon registered it.
	local resolved = weapons.Get(class) or definition
	known = { values = {}, raw = {}, name = tostring(resolved.PrintName or definition.PrintName or class) }
	for _, stat in ipairs(STATS) do
		known.values[stat.id] = statValue(resolved, stat)
		if stat.id == "rpm" then
			known.raw.RPM = definition.RPM
			known.raw.Delay = definition.Delay
		else
			known.raw[stat.key] = definition[stat.key]
		end
	end
	E.BaseStats[class] = known
	return known
end

local function writeStat(target, base, stat, value)
	if stat.id == "rpm" then
		if value ~= nil then
			target.RPM = value
			target.Delay = 60 / value
		else
			target.RPM = base.raw.RPM
			target.Delay = base.raw.Delay
		end
		return
	end
	target[stat.key] = value ~= nil and value or base.raw[stat.key]
end

local function currentValues(class, base)
	local values = table.Copy(base.values or {})
	local override = E.Overrides[class]
	for id, value in pairs(override and override.stats or {}) do values[id] = tonumber(value) end
	return values
end

function E.ApplyToWeaponEntity(weapon)
	if not IsValid(weapon) or not weapon.IsWeapon or not weapon:IsWeapon() then return end
	local class = weapon:GetClass()
	local definition = weapons.GetStored(class)
	if not isArcCWWeapon(class, definition) then return end
	if not E.Overrides[class] and not E.BaseStats[class] then return end

	local base = captureBase(class, definition)
	local override = E.Overrides[class]
	for _, stat in ipairs(STATS) do
		writeStat(weapon, base, stat, override and override.stats[stat.id])
	end
	local values = currentValues(class, base)

	if SERVER and values.clip_size and weapon.Clip1 and weapon.SetClip1
	and weapon:Clip1() > values.clip_size then
		weapon:SetClip1(values.clip_size)
	end
	if weapon.RecalcAllBuffs then weapon:RecalcAllBuffs() end
end

function E.ApplyClass(class)
	local definition = weapons.GetStored(class)
	if not isArcCWWeapon(class, definition) then return end

	local base = captureBase(class, definition)
	local override = E.Overrides[class]
	for _, stat in ipairs(STATS) do
		writeStat(definition, base, stat, override and override.stats[stat.id])
	end

	for _, entity in ipairs(ents.GetAll()) do
		if IsValid(entity) and entity.IsWeapon and entity:IsWeapon()
		and entity:GetClass() == class then
			E.ApplyToWeaponEntity(entity)
		end
	end
end

function E.ApplyAll()
	local classes = {}
	for class in pairs(E.BaseStats) do classes[class] = true end
	for class in pairs(E.Overrides) do classes[class] = true end
	for class in pairs(classes) do E.ApplyClass(class) end
end

local function applyCreatedWeapon(entity)
	timer.Simple(0, function()
		if not IsValid(entity) or not entity.IsWeapon or not entity:IsWeapon() then return end
		local class = entity:GetClass()
		if E.Overrides[class] or E.BaseStats[class] then E.ApplyToWeaponEntity(entity) end
	end)
end

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_EDITOR_SYNC)
	util.AddNetworkString(NET_OVERRIDE_SYNC)
	util.AddNetworkString(NET_ACTION)

	local function canManage(ply)
		return IsValid(ply) and isfunction(ply.MBStaffLevel)
			and ply:MBStaffLevel() >= managementLevel()
	end

	local function rounded(value, stat)
		if stat.integer then return math.floor(value + 0.5) end
		return math.Round(value * 100) / 100
	end

	local function validClass(value)
		value = string.lower(string.Trim(tostring(value or "")))
		if not string.match(value, "^[%w_%-]+$") then return nil end
		local definition = weapons.GetStored(value)
		if not isArcCWWeapon(value, definition) then return nil end
		return value, definition
	end

	local function validateOverride(source, allowMissing)
		if not istable(source) then return nil, "Malformed weapon override." end
		local class, definition = validClass(source.class)
		if not class then return nil, "Select a valid ArcCW weapon." end

		local base = captureBase(class, definition)
		local supplied = istable(source.stats) and source.stats or source
		local clean = { class = class, stats = {} }
		for _, stat in ipairs(STATS) do
			if base.values[stat.id] ~= nil then
				local value = tonumber(supplied[stat.id])
				if value == nil then
					if allowMissing then
						value = base.values[stat.id]
					else
						return nil, stat.label .. " must be a number."
					end
				end
				if value < stat.minimum or value > stat.maximum then
					return nil, stat.label .. " must be between " .. stat.minimum .. " and " .. stat.maximum .. "."
				end
				clean.stats[stat.id] = rounded(value, stat)
			end
		end

		if clean.stats.damage and clean.stats.damage_min
		and clean.stats.damage_min > clean.stats.damage then
			return nil, "Minimum damage cannot exceed maximum damage."
		end
		return clean
	end

	local function editorPayload()
		local listed, seen = {}, {}
		for _, definition in pairs(weapons.GetList() or {}) do
			local class = string.lower(tostring(definition.ClassName or definition.Class or ""))
			if class ~= "" and not seen[class] then
				local stored = weapons.GetStored(class) or definition
				if isArcCWWeapon(class, stored) then
					seen[class] = true
					local base = captureBase(class, stored)
					listed[#listed + 1] = {
						class = class,
						name = tostring(stored.PrintName or base.name or class),
						category = tostring(stored.Category or "ArcCW"),
						base = table.Copy(base.values),
						current = currentValues(class, base),
						overridden = E.Overrides[class] ~= nil,
					}
				end
			end
		end
		table.sort(listed, function(a, b)
			return string.lower(a.name) == string.lower(b.name)
				and a.class < b.class or string.lower(a.name) < string.lower(b.name)
		end)
		return { weapons = listed, overrides = table.Copy(E.Overrides), requiredLevel = managementLevel() }
	end

	local function writeCompressed(netName, recipient, data)
		local compressed = util.Compress(util.TableToJSON(data) or "{}") or ""
		if #compressed > MAX_NETWORK_BYTES then return end
		net.Start(netName)
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		if IsValid(recipient) then net.Send(recipient) else net.Broadcast() end
	end

	local function syncOverrides(recipient)
		writeCompressed(NET_OVERRIDE_SYNC, recipient, { overrides = E.Overrides })
	end

	local function syncEditor(recipient)
		if canManage(recipient) then writeCompressed(NET_EDITOR_SYNC, recipient, editorPayload()) end
	end

	local function saveOverride(actor, source)
		local clean, err = validateOverride(source)
		if not clean then return false, err end

		E.Overrides[clean.class] = clean
		E.ApplyClass(clean.class)
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_arccw_weapon_overrides (class, data, updated_by, updated_at) VALUES (%s, %s, %s, %d)",
			MilBase.SQLStr(clean.class), MilBase.SQLStr(util.TableToJSON(clean)),
			MilBase.SQLStr(actor:SteamID64()), os.time()))
		syncOverrides()
		syncEditor(actor)
		if MilBase.Log then
			MilBase.Log("staff", MilBase.LogTag(actor) .. " updated ArcCW weapon " .. clean.class, actor)
		end
		return true, "Global override applied to " .. clean.class .. "."
	end

	local function resetOverride(actor, value)
		local class = validClass(value)
		if not class then return false, "Select a valid ArcCW weapon." end

		E.Overrides[class] = nil
		E.ApplyClass(class)
		MilBase.DB.Run("DELETE FROM frontier_arccw_weapon_overrides WHERE class = " .. MilBase.SQLStr(class))
		syncOverrides()
		syncEditor(actor)
		if MilBase.Log then
			MilBase.Log("staff", MilBase.LogTag(actor) .. " reset ArcCW weapon " .. class, actor)
		end
		return true, "Weapon restored to its addon defaults."
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if not canManage(ply) or (ply.mb_nextArcCWWeaponEditorRequest or 0) > CurTime() then return end
		ply.mb_nextArcCWWeaponEditorRequest = CurTime() + 0.75
		syncEditor(ply)
	end)

	net.Receive(NET_ACTION, function(_, ply)
		if not canManage(ply) or (ply.mb_nextArcCWWeaponEditorAction or 0) > CurTime() then return end
		ply.mb_nextArcCWWeaponEditorAction = CurTime() + 0.35
		local action = net.ReadString()
		local ok, message
		if action == "save" then
			local length = net.ReadUInt(20)
			if length <= 0 or length > MAX_NETWORK_BYTES then return end
			local raw = util.Decompress(net.ReadData(length) or "")
			if not raw or #raw > MAX_NETWORK_BYTES then return end
			ok, message = saveOverride(ply, util.JSONToTable(raw))
		elseif action == "reset" then
			ok, message = resetOverride(ply, net.ReadString())
		else
			return
		end
		MilBase.Notify(ply, message, ok and "ok" or "warn")
	end)

	MilBase.DB.Query([[CREATE TABLE IF NOT EXISTS frontier_arccw_weapon_overrides (
		class VARCHAR(128) PRIMARY KEY, data TEXT, updated_by VARCHAR(32), updated_at INTEGER
	)]], function()
		MilBase.DB.Query("SELECT class, data FROM frontier_arccw_weapon_overrides", function(rows)
			for _, row in ipairs(rows or {}) do
				local saved = util.JSONToTable(row.data or "")
				if istable(saved) then
					saved.class = saved.class or row.class
					local clean = validateOverride(saved, true)
					if clean then E.Overrides[clean.class] = clean end
				end
			end
			E.ApplyAll()
			syncOverrides()
		end)
	end, function(err)
		MsgC(Color(255, 100, 90), "[MilBase ArcCW Weapon Editor] Database setup failed: ", color_white,
			tostring(err), "\n")
	end)

	hook.Add("OnEntityCreated", "MilBase.ArcCWWeaponEditor.ServerApply", applyCreatedWeapon)
	hook.Add("PlayerInitialSpawn", "MilBase.ArcCWWeaponEditor.InitialSync", function(ply)
		timer.Simple(2, function() if IsValid(ply) then syncOverrides(ply) end end)
	end)
	return
end

-- Client -----------------------------------------------------------------

local function applyClientPayload(data)
	if not istable(data) then return end
	E.Overrides = istable(data.overrides) and data.overrides or {}
	E.ApplyAll()
end

local function readCompressed()
	local length = net.ReadUInt(20)
	if length <= 0 or length > MAX_NETWORK_BYTES then return nil end
	local raw = util.Decompress(net.ReadData(length) or "")
	return raw and util.JSONToTable(raw) or nil
end

net.Receive(NET_OVERRIDE_SYNC, function()
	applyClientPayload(readCompressed())
end)

net.Receive(NET_EDITOR_SYNC, function()
	local data = readCompressed()
	if not istable(data) then return end
	E.ClientData = data
	applyClientPayload(data)
	if IsValid(E.Frame) then
		E.Frame.Data = data
		E.Frame:Rebuild()
	end
end)

hook.Add("OnEntityCreated", "MilBase.ArcCWWeaponEditor.ClientApply", applyCreatedWeapon)
hook.Add("InitPostEntity", "MilBase.ArcCWWeaponEditor.ClientInitialApply", function()
	timer.Simple(0, function() E.ApplyAll() end)
end)

local function canManageLocal()
	local ply = LocalPlayer()
	return IsValid(ply) and isfunction(ply.MBStaffLevel) and ply:MBStaffLevel() >= managementLevel()
end

local function requestEditor()
	net.Start(NET_REQUEST)
	net.SendToServer()
end

local function sendAction(action, value)
	net.Start(NET_ACTION)
		net.WriteString(action)
		if action == "save" then
			local compressed = util.Compress(util.TableToJSON(value) or "{}") or ""
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		else
			net.WriteString(tostring(value or ""))
		end
	net.SendToServer()
end

local function statText(value, stat)
	value = tonumber(value) or 0
	if stat.integer then return tostring(math.floor(value + 0.5)) end
	local decimals = stat.decimals or 2
	return string.format("%." .. decimals .. "f", value)
end

local function panelButton(parent, label, colour, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 7,
			color = self:IsHovered() and Color(colour.r, colour.g, colour.b, 54) or ui.raised,
			outlineColor = self:IsHovered() and colour or ui.outline,
			accent = colour,
		})
		if self:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, colour, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2,
			self:IsEnabled() and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = callback
	return button
end

local function paintEntry(self, w, h)
	local ui = MilBase.UI
	surface.SetDrawColor(0, 0, 0, 165)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
	surface.DrawOutlinedRect(0, 0, w, h)
	self:DrawTextEntryText(ui.text, ui.accent, ui.text)
end

function MilBase.OpenArcCWWeaponEditor()
	if not canManageLocal() then
		MilBase.Notify(LocalPlayer(), "ArcCW weapon tuning requires Management rank or higher.", "warn")
		return
	end

	if IsValid(E.Frame) then
		E.Frame:MakePopup()
		requestEditor()
		return
	end

	local frame = vgui.Create("DFrame")
	E.Frame = frame
	frame:SetSize(math.min(1240, ScrW() - 50), math.min(790, ScrH() - 50))
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Data = E.ClientData or { weapons = {}, overrides = {} }
	frame.SelectedClass = nil
	frame.Paint = function(self, w, h)
		MilBase.PaintBackdrop(self, w, h, nil, 220)
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 12, color = Color(6, 6, 7, 236), outlineColor = MilBase.UI.outline,
			accent = MilBase.UI.warn,
		})
	end
	frame.OnRemove = function(self)
		if E.Frame == self then E.Frame = nil end
	end

	local header = vgui.Create("DPanel", frame)
	header:Dock(TOP)
	header:SetTall(72)
	header:DockMargin(12, 10, 12, 0)
	header.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 9, color = MilBase.UI.panel, outlineColor = MilBase.UI.outline,
			accent = MilBase.UI.warn,
		})
		draw.SimpleText("ARCCW WEAPON EDITOR", "MB.Big", 18, 10, MilBase.UI.text)
		draw.SimpleText("MANAGEMENT-ONLY  •  GLOBAL, PERSISTENT BASE-STAT OVERRIDES",
			"MB.Tiny", 20, 45, MilBase.UI.warn)
	end
	local close = panelButton(header, "CLOSE", MilBase.UI.danger, function() frame:Remove() end)
	close:SetSize(100, 36)
	close:SetPos(header:GetWide() - 116, 18)
	close.Think = function(self) self:SetPos(header:GetWide() - 116, 18) end

	local body = vgui.Create("DPanel", frame)
	body:Dock(FILL)
	body:DockMargin(12, 12, 12, 12)
	body.Paint = nil

	local left = vgui.Create("DPanel", body)
	left:Dock(LEFT)
	left:SetWide(338)
	left:DockMargin(0, 0, 12, 0)
	left.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 9, color = MilBase.UI.panel, accent = MilBase.UI.accent })
		draw.SimpleText("ARCCW WEAPONS", "MB.Tab", 14, 10, MilBase.UI.text)
	end

	local search = vgui.Create("DTextEntry", left)
	search:SetPos(12, 44)
	search:SetSize(left:GetWide() - 24, 32)
	search:SetFont("MB.Small")
	search:SetPaintBackground(false)
	search:SetPlaceholderText("Search weapon name or class…")
	search:SetUpdateOnType(true)
	search.Paint = paintEntry
	search.Think = function(self) self:SetWide(left:GetWide() - 24) end

	local list = vgui.Create("DScrollPanel", left)
	list:Dock(FILL)
	list:DockMargin(12, 86, 12, 12)

	local details = vgui.Create("DScrollPanel", body)
	details:Dock(FILL)
	details.Paint = function() end

	local function selectedWeapon()
		for _, weapon in ipairs(frame.Data.weapons or {}) do
			if weapon.class == frame.SelectedClass then return weapon end
		end
		return nil
	end

	local function rebuildDetails()
		details:Clear()
		local weapon = selectedWeapon()
		if not weapon then
			local empty = vgui.Create("DLabel", details)
			empty:Dock(TOP)
			empty:SetTall(44)
			empty:SetFont("MB.Med")
			empty:SetTextColor(MilBase.UI.dim)
			empty:SetText("Select an ArcCW weapon from the list.")
			return
		end

		local title = vgui.Create("DPanel", details)
		title:Dock(TOP)
		title:SetTall(88)
		title:DockMargin(0, 0, 8, 10)
		title.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 9, color = MilBase.UI.panel, outlineColor = MilBase.UI.outline,
				accent = weapon.overridden and MilBase.UI.warn or MilBase.UI.accent,
			})
			draw.SimpleText(weapon.name, "MB.Big", 16, 10, MilBase.UI.text)
			draw.SimpleText(weapon.class .. "  •  " .. weapon.category, "MB.Tiny", 18, 46, MilBase.UI.dim)
			draw.SimpleText(weapon.overridden and "GLOBAL OVERRIDE ACTIVE" or "USING ADDON DEFAULTS",
				"MB.Small", w - 16, 18, weapon.overridden and MilBase.UI.warn or MilBase.UI.ok,
				TEXT_ALIGN_RIGHT)
			draw.SimpleText("Attachment modifiers still apply on top of these base values.",
				"MB.Tiny", w - 16, 49, MilBase.UI.faint, TEXT_ALIGN_RIGHT)
		end

		local note = vgui.Create("DPanel", details)
		note:Dock(TOP)
		note:SetTall(44)
		note:DockMargin(0, 0, 8, 10)
		note.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 7, color = Color(MilBase.UI.warn.r, MilBase.UI.warn.g, MilBase.UI.warn.b, 10),
				outlineColor = MilBase.UI.outline, accent = MilBase.UI.warn,
			})
			draw.SimpleText("Changes apply to held, dropped and newly issued copies immediately. Reset restores this entire weapon to its addon values.",
				"MB.Tiny", 14, h / 2, MilBase.UI.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		frame.Fields = {}
		for _, stat in ipairs(STATS) do
			if weapon.base and weapon.base[stat.id] ~= nil then
				local row = vgui.Create("DPanel", details)
				row:Dock(TOP)
				row:SetTall(58)
				row:DockMargin(0, 0, 8, 6)
				row.Paint = function(_, w, h)
					MilBase.DrawPanelBF2(0, 0, w, h, {
						cut = 7, color = MilBase.UI.panel, outlineColor = MilBase.UI.outline,
						accent = MilBase.UI.accent,
					})
					draw.SimpleText(stat.label, "MB.Small", 14, 10, MilBase.UI.text)
					draw.SimpleText("ADDON DEFAULT  " .. statText(weapon.base[stat.id], stat)
						.. "     LIMIT " .. stat.minimum .. "–" .. stat.maximum,
						"MB.Tiny", 14, 32, MilBase.UI.dim)
				end

				local entry = vgui.Create("DTextEntry", row)
				entry:SetSize(164, 32)
				entry:SetPos(row:GetWide() - 176, 13)
				entry:SetFont("MB.Small")
				entry:SetPaintBackground(false)
				entry:SetText(statText((weapon.current or weapon.base)[stat.id], stat))
				entry.Paint = paintEntry
				entry.Think = function(self) self:SetPos(row:GetWide() - 176, 13) end
				frame.Fields[stat.id] = entry
			end
		end

		local actions = vgui.Create("DPanel", details)
		actions:Dock(TOP)
		actions:SetTall(48)
		actions:DockMargin(0, 6, 8, 16)
		actions.Paint = nil

		local save = panelButton(actions, "SAVE GLOBAL OVERRIDE", MilBase.UI.ok, function()
			local stats = {}
			for id, entry in pairs(frame.Fields or {}) do stats[id] = tonumber(entry:GetValue()) end
			sendAction("save", { class = weapon.class, stats = stats })
		end)
		save:Dock(LEFT)
		save:SetWide(210)
		save:DockMargin(0, 4, 10, 4)

		local reset = panelButton(actions, "RESET TO ADDON DEFAULTS", MilBase.UI.danger,
			function() sendAction("reset", weapon.class) end)
		reset:Dock(LEFT)
		reset:SetWide(220)
		reset:DockMargin(0, 4, 0, 4)
		reset:SetEnabled(weapon.overridden == true)
	end

	local function rebuildList()
		list:Clear()
		local query = string.lower(string.Trim(search:GetValue() or ""))
		local shown = 0
		for _, weapon in ipairs(frame.Data.weapons or {}) do
			local searchable = string.lower(weapon.name .. " " .. weapon.class)
			if query == "" or string.find(searchable, query, 1, true) then
				shown = shown + 1
				local row = vgui.Create("DButton", list)
				row:Dock(TOP)
				row:SetTall(54)
				row:DockMargin(0, 0, 0, 5)
				row:SetText("")
				row.Paint = function(self, w, h)
					local selected = frame.SelectedClass == weapon.class
					MilBase.DrawPanelBF2(0, 0, w, h, {
						cut = 7,
						color = selected and Color(MilBase.UI.accent.r, MilBase.UI.accent.g, MilBase.UI.accent.b, 38)
							or (self:IsHovered() and MilBase.UI.hover or Color(255, 255, 255, 4)),
						accent = selected and MilBase.UI.accent or weapon.overridden and MilBase.UI.warn or nil,
					})
					draw.SimpleText(weapon.name, "MB.Small", 12, 9, MilBase.UI.text)
					draw.SimpleText(weapon.class, "MB.Tiny", 12, 30, MilBase.UI.dim)
					if weapon.overridden then
						draw.SimpleText("TUNED", "MB.Tiny", w - 10, 12, MilBase.UI.warn, TEXT_ALIGN_RIGHT)
					end
				end
				row.DoClick = function()
					frame.SelectedClass = weapon.class
					MilBase.PlayUISound("select")
					rebuildList()
					rebuildDetails()
				end
			end
		end
		if shown == 0 then
			local empty = vgui.Create("DLabel", list)
			empty:Dock(TOP)
			empty:SetTall(38)
			empty:SetFont("MB.Small")
			empty:SetTextColor(MilBase.UI.dim)
			empty:SetText("No ArcCW weapons match that search.")
		end
	end

	frame.Rebuild = function(self)
		if self.SelectedClass and not selectedWeapon() then self.SelectedClass = nil end
		if not self.SelectedClass and self.Data.weapons and self.Data.weapons[1] then
			self.SelectedClass = self.Data.weapons[1].class
		end
		rebuildList()
		rebuildDetails()
	end
	search.OnValueChange = rebuildList
	frame:Rebuild()
	requestEditor()
end
