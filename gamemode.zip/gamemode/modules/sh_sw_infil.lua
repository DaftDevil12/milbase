-- MilBase module loader for the Star Wars Tactical LAAT infil system.
-- The implementation is flattened into top-level module files because GMod's
-- gamemode include/download path refused the nested module directory.

SWInfil = SWInfil or {}

if SWInfil.Loaded then
	return
end

SWInfil.Loaded = true
SWInfil.MilBaseModule = true

if SERVER then
	print("[MilBase] LAAT tactical infil module loading.")
end

if SERVER then
	AddCSLuaFile("modules/sh_sw_infil_core.lua")
	AddCSLuaFile("modules/cl_sw_infil_core.lua")
	AddCSLuaFile("weapons/gmod_tool/stools/sw_infil_route.lua")
	AddCSLuaFile("weapons/gmod_tool/stools/sw_infil_seats.lua")
	AddCSLuaFile("weapons/gmod_tool/stools/sw_infil_skybox.lua")
end

include("modules/sh_sw_infil_core.lua")

if SERVER then
	include("modules/sv_sw_infil_core.lua")
else
	include("modules/cl_sw_infil_core.lua")
end
