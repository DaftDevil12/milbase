--[[
	MilBase cockpit HUD for LVS vehicles (black & gold).

	Shown while sitting in an LVS vehicle: a status panel bottom-left
	(hull, shields, fuel + our subsystem conditions) and a flight panel
	bottom-right (weapon/heat, speed, altitude). It complements the LVS
	crosshair/targeting rather than replacing it.

	Every LVS call is guarded, so it's inert without lvs_base and tolerant
	of vehicles that lack shields / fuel / weapons.
]]

if SERVER then return end

local cfg = MilBase.Config

local COL_HULL   = Color(255, 198, 60)
local COL_SHIELD = Color(140, 200, 235)
local COL_FUEL   = Color(210, 160, 70)
local COL_HEAT   = Color(230, 120, 60)

-- The LVS vehicle the local player is currently in (nil otherwise).
local function myVehicle()
	local lp = LocalPlayer()
	if not (IsValid(lp) and lp:Alive()) then return end
	local veh = lp.lvsGetVehicle and lp:lvsGetVehicle()
	if IsValid(veh) and veh.LVS then return veh, lp end
end

local function pct(a, b)
	b = b or 0
	if b <= 0 then return nil end
	return math.Clamp(a / b, 0, 1)
end

-- Distance to the ground below the vehicle (nil if grounded / no LVS check).
local function altitude(veh)
	local start = veh:LocalToWorld(veh:OBBCenter())
	local tr = util.TraceLine({
		start = start,
		endpos = start - Vector(0, 0, 8000),
		filter = veh.GetCrosshairFilterEnts and veh:GetCrosshairFilterEnts() or veh,
		mask = MASK_SOLID_BRUSHONLY,
	})
	if not tr.Hit then return nil end
	return start.z - tr.HitPos.z
end

--------------------------------------------------------------------------
-- Status panel (bottom-left): hull / shields / fuel / subsystems
--------------------------------------------------------------------------

local function drawStatusPanel(veh)
	local ui = MilBase.UI

	-- Which subsystems apply?
	local subs = {}
	if MilBase.VehSubsystems then
		for _, s in ipairs(MilBase.VehSubsystems) do
			if s.id ~= "hull" and MilBase.VehSysApplies and MilBase.VehSysApplies(veh, s.id) then
				subs[#subs + 1] = s
			end
		end
	end

	local hp = veh.GetHP and veh:GetHP()
	local maxhp = veh.GetMaxHP and veh:GetMaxHP()
	local shield = veh.GetShield and veh:GetShield()
	local maxShield = veh.GetMaxShield and veh:GetMaxShield() or 0
	local fuel = veh.GetFuel and veh:GetFuel()
	local maxFuel = veh.GetMaxFuel and veh:GetMaxFuel() or 1

	local rows = 0
	if hp then rows = rows + 1 end
	if shield and maxShield > 0 then rows = rows + 1 end
	if fuel then rows = rows + 1 end

	local w, x = 300, 20
	local h = 40 + rows * 24 + (#subs > 0 and 30 or 4)
	local y = ScrH() - h - 20

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, accent = ui.accent })

	draw.SimpleText(string.upper(veh.PrintName or veh:GetClass()), "MB.Med", x + 14, y + 8, ui.text)

	local rowX, rowW = x + 14, w - 28
	local ry = y + 36

	local function bar(label, frac, value, color)
		draw.SimpleText(label, "MB.Tiny", rowX, ry, ui.dim)
		draw.SimpleText(value, "MB.Tiny", rowX + rowW, ry, ui.text, TEXT_ALIGN_RIGHT)
		MilBase.DrawBar(rowX, ry + 13, rowW, 5, frac, color)
		ry = ry + 24
	end

	if hp then
		local f = pct(hp, maxhp) or 0
		bar("HULL", f, math.Round(hp) .. " / " .. math.Round(maxhp),
			f <= 0.3 and ui.danger or COL_HULL)
	end
	if shield and maxShield > 0 then
		bar("SHIELD", pct(shield, maxShield) or 0, math.Round(shield), COL_SHIELD)
	end
	if fuel then
		bar("FUEL", pct(fuel, maxFuel) or 0, math.Round((pct(fuel, maxFuel) or 0) * 100) .. "%", COL_FUEL)
	end

	-- Subsystem chips.
	if #subs > 0 then
		local cx = x + 14
		for _, s in ipairs(subs) do
			local cond = MilBase.GetVehSysCondition(veh, s.id)
			local col = cond > 60 and ui.ok or (cond > 0 and ui.warn or ui.danger)
			local txt = cond <= 0 and (string.upper(s.name) .. " OUT")
				or (string.upper(s.name) .. " " .. math.Round(cond) .. "%")

			surface.SetFont("MB.Tiny")
			local tw = surface.GetTextSize(txt) + 16
			MilBase.DrawPanelBF2(cx, ry, tw, 20, { cut = 4, outlineColor = col })
			draw.SimpleText(txt, "MB.Tiny", cx + 8, ry + 10, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			cx = cx + tw + 6
		end
	end
end

--------------------------------------------------------------------------
-- Flight panel (bottom-right): weapon / heat / speed / altitude
--------------------------------------------------------------------------

local function drawFlightPanel(veh)
	local ui = MilBase.UI

	local speed = math.Round(veh:GetVelocity():Length() * 0.06858) -- ~km/h
	local alt = altitude(veh)
	local grounded = veh.HitGround and veh:HitGround() or false

	local wep = veh.GetActiveWeapon and veh:GetActiveWeapon()
	local wepName = istable(wep) and (wep.PrintName or wep.Name) or nil
	local heat = veh.GetHeat and veh:GetHeat()
	local overheated = veh.GetOverheated and veh:GetOverheated()

	local w, h = 210, 40 + (wepName and 22 or 0) + (heat and 12 or 0) + 44
	local x, y = ScrW() - w - 20, ScrH() - h - 20

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, accent = overheated and ui.danger or ui.accent })

	local ry = y + 10

	if wepName then
		draw.SimpleText(string.upper(wepName), "MB.Small", x + 14, ry,
			overheated and ui.danger or ui.text)
		ry = ry + 22
	end
	if heat then
		MilBase.DrawBar(x + 14, ry, w - 28, 5, math.Clamp(heat, 0, 1),
			overheated and ui.danger or COL_HEAT)
		ry = ry + 12
	end

	-- Speed + altitude readout.
	draw.SimpleText("SPD", "MB.Tiny", x + 14, ry + 4, ui.dim)
	draw.SimpleText(speed .. " KM/H", "MB.Small", x + w - 14, ry, ui.text, TEXT_ALIGN_RIGHT)
	ry = ry + 22

	draw.SimpleText("ALT", "MB.Tiny", x + 14, ry + 4, ui.dim)
	local altText = grounded and "GROUNDED"
		or (alt and (math.Round(alt) .. " u") or "AIRBORNE")
	draw.SimpleText(altText, "MB.Small", x + w - 14, ry,
		grounded and ui.dim or ui.text, TEXT_ALIGN_RIGHT)
end

--------------------------------------------------------------------------
hook.Add("HUDPaint", "MilBase.VehicleHUD", function()
	if not cfg.LVSHudEnabled then return end
	if MilBase.InEventView and MilBase.InEventView() then return end

	local veh = myVehicle()
	if not veh then return end

	drawStatusPanel(veh)
	drawFlightPanel(veh)
end)
