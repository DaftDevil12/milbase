if not CLIENT then return end

MilBase.EventCharacter = MilBase.EventCharacter or {}
local EC = MilBase.EventCharacter

function EC.OpenMenu()
	local frame = vgui.Create("DFrame")
	frame:SetSize(480, 520)
	frame:Center()
	frame:SetTitle("EVENT CHARACTER CREATOR (STAFF)")
	frame:MakePopup()

	local nameLabel = vgui.Create("DLabel", frame)
	nameLabel:SetPos(20, 40)
	nameLabel:SetText("Character Name:")

	local nameEntry = vgui.Create("DTextEntry", frame)
	nameEntry:SetPos(20, 60)
	nameEntry:SetSize(440, 26)
	nameEntry:SetText(LocalPlayer():MBName())

	local modelLabel = vgui.Create("DLabel", frame)
	modelLabel:SetPos(20, 95)
	modelLabel:SetText("Model Path:")

	local modelEntry = vgui.Create("DTextEntry", frame)
	modelEntry:SetPos(20, 115)
	modelEntry:SetSize(440, 26)
	modelEntry:SetText(LocalPlayer():GetModel())

	local hpLabel = vgui.Create("DLabel", frame)
	hpLabel:SetPos(20, 150)
	hpLabel:SetText("Boss Health (HP):")

	local hpEntry = vgui.Create("DTextEntry", frame)
	hpEntry:SetPos(20, 170)
	hpEntry:SetSize(210, 26)
	hpEntry:SetText("1000")

	local scaleLabel = vgui.Create("DLabel", frame)
	scaleLabel:SetPos(250, 150)
	scaleLabel:SetText("Model Scale (0.5 to 3.0):")

	local scaleEntry = vgui.Create("DTextEntry", frame)
	scaleEntry:SetPos(250, 170)
	scaleEntry:SetSize(210, 26)
	scaleEntry:SetText("1.0")

	local langLabel = vgui.Create("DLabel", frame)
	langLabel:SetPos(20, 205)
	langLabel:SetText("Species Speech Language:")

	local langCombo = vgui.Create("DComboBox", frame)
	langCombo:SetPos(20, 225)
	langCombo:SetSize(440, 26)
	for _, lang in ipairs(EC.Languages or {}) do
		langCombo:AddChoice(lang.name, lang.id)
	end
	langCombo:ChooseOptionID(1)

	local wepLabel = vgui.Create("DLabel", frame)
	wepLabel:SetPos(20, 260)
	wepLabel:SetText("Extra Weapons (comma separated class names):")

	local wepEntry = vgui.Create("DTextEntry", frame)
	wepEntry:SetPos(20, 280)
	wepEntry:SetSize(440, 26)
	wepEntry:SetText("arccw_cgi_k_dc15a, arccw_k_valken38")

	local unlimitedCheck = vgui.Create("DCheckBoxLabel", frame)
	unlimitedCheck:SetPos(20, 320)
	unlimitedCheck:SetText("Bypass Weapon Carry Weight / Slot Limits (Unlimited Loadout)")
	unlimitedCheck:SetValue(true)

	local applyBtn = vgui.Create("DButton", frame)
	applyBtn:SetPos(20, 370)
	applyBtn:SetSize(440, 40)
	applyBtn:SetText("ACTIVATE EVENT CHARACTER PROFILE")
	applyBtn.DoClick = function()
		local _, langID = langCombo:GetSelected()
		local weps = {}
		for _, w in ipairs(string.Explode(",", wepEntry:GetText())) do
			w = string.Trim(w)
			if w ~= "" then table.insert(weps, w) end
		end

		local payload = {
			name = nameEntry:GetText(),
			model = modelEntry:GetText(),
			health = tonumber(hpEntry:GetText()) or 1000,
			scale = tonumber(scaleEntry:GetText()) or 1.0,
			language = langID or "basic",
			weapons = weps,
			unlimitedWeapons = unlimitedCheck:GetChecked(),
		}

		local raw = util.TableToJSON(payload)
		local compressed = util.Compress(raw)
		net.Start("MilBase_EC_ApplyProfile")
			net.WriteUInt(#compressed, 24)
			net.WriteData(compressed, #compressed)
		net.SendToServer()
		frame:Close()
	end

	local revertBtn = vgui.Create("DButton", frame)
	revertBtn:SetPos(20, 425)
	revertBtn:SetSize(440, 34)
	revertBtn:SetText("REVERT TO NORMAL PLAYER CHARACTER (/ec off)")
	revertBtn.DoClick = function()
		net.Start("MilBase_EC_RevertProfile")
		net.SendToServer()
		frame:Close()
	end
end

net.Receive("MilBase_EC_OpenMenu", function()
	EC.OpenMenu()
end)
