--[[
	RP-in-menus: puts the actionable RP commands on the Self Menu (hold G)
	and Player Menu (C + right-click) instead of chat. Speech stays in chat
	(/me /it // /ooc /w /y /r /s /pm /name).

	Every action here just re-uses the existing chat command's function
	(MilBase.Commands[name].func(ply, args, rawText)) - the self/player
	action .run bodies execute serverside, where MilBase.Commands holds
	every command, so all of the original guards stay in one place.

	The old chat commands still work but are hidden from the F4 HELP list
	via MilBase.HiddenCommands (see core/cl_menu.lua + modules/sh_stafftab).
]]

--------------------------------------------------------------------------
-- Hidden aliases: still typeable, just not listed in /help.
--------------------------------------------------------------------------

MilBase.HiddenCommands = MilBase.HiddenCommands or {}
for _, n in ipairs({
	"salute", "wave", "halt", "forward", "group", "agree", "disagree", "bow",
	"drop", "roll",
	-- Now driven from the C + right-click player menu (with submenus):
	"certify", "decertify", "setfaction",
}) do
	MilBase.HiddenCommands[n] = true
end

-- Runs an existing chat command's func serverside (nil-safe).
local function runCmd(ply, name, args, raw)
	local cmd = MilBase.Commands[name]
	if cmd and cmd.func then cmd.func(ply, args or {}, raw or "") end
end

--------------------------------------------------------------------------
-- Gestures: one "Gestures" self-menu entry opens a clickable wheel.
-- The 8 underlying gesture chat commands live in sh_gestures.lua.
--------------------------------------------------------------------------

-- id (= gesture chat command) -> button label
local GESTURES = {
	{ "salute",   "Salute"  },
	{ "wave",     "Wave"    },
	{ "halt",     "Halt"    },
	{ "forward",  "Advance" },
	{ "group",    "Rally"   },
	{ "agree",    "Yes"     },
	{ "disagree", "No"      },
	{ "bow",      "Bow"     },
}

-- Hidden self-actions g_<gesture>: not shown in the hold-G list
-- (visible=false) but still runnable by id through the MilBase_SelfAction
-- net, which the wheel buttons use.
for _, g in ipairs(GESTURES) do
	local cmdName = g[1]
	MilBase.RegisterSelfAction("g_" .. cmdName, {
		name = g[2],
		order = 999,
		visible = function() return false end,
		run = function(ply) runCmd(ply, cmdName) end,
	})
end

-- The visible entry: opens the wheel clientside.
MilBase.RegisterSelfAction("gestures", {
	name = "Gestures",
	order = 40,
	visible = function(lp)
		return not lp:GetNWBool("mb_wounded", false)
	end,
	client = function(lp) MilBase.OpenGestureWheel() end,
})

--------------------------------------------------------------------------
-- Roll + drop as direct self-actions.
--------------------------------------------------------------------------

MilBase.RegisterSelfAction("roll", {
	name = "Roll Dice",
	order = 45,
	run = function(ply) runCmd(ply, "roll") end,
})

MilBase.RegisterSelfAction("drop", {
	name = "Drop Weapon",
	order = 12,
	visible = function(lp)
		local w = lp:GetActiveWeapon()
		return IsValid(w) and w:GetClass() ~= "weapon_fists"
	end,
	run = function(ply) runCmd(ply, "drop") end,
})

--------------------------------------------------------------------------
-- Squad: self-menu for your own membership, player-menu for others.
-- Backed by /squad (sh_squads.lua); mb_squad / mb_squadleader are set
-- by that module so clientside visibility is accurate.
--------------------------------------------------------------------------

local function inSquad(ply) return ply:GetNWString("mb_squad", "") ~= "" end
local function isLeader(ply) return ply:GetNWBool("mb_squadleader", false) end

MilBase.RegisterSelfAction("squad_accept", {
	name = "Accept Squad Invite",
	order = 60,
	visible = function(lp) return not inSquad(lp) end,
	run = function(ply) runCmd(ply, "squad", { "accept" }, "accept") end,
})

MilBase.RegisterSelfAction("squad_leave", {
	name = "Leave Squad",
	order = 61,
	visible = function(lp) return inSquad(lp) and not isLeader(lp) end,
	run = function(ply) runCmd(ply, "squad", { "leave" }, "leave") end,
})

MilBase.RegisterSelfAction("squad_disband", {
	name = "Disband Squad",
	order = 62,
	visible = function(lp) return isLeader(lp) end,
	run = function(ply) runCmd(ply, "squad", { "disband" }, "disband") end,
})

MilBase.RegisterPlayerAction("squad_invite", {
	name = "Invite to Squad",
	icon = "icon16/group_add.png",
	order = 35,
	visible = function(lp, target)
		return target ~= lp and isLeader(lp)
			and target:GetNWString("mb_squad", "") == ""
	end,
	run = function(ply, target)
		runCmd(ply, "squad", { "invite", target:Nick() }, "invite " .. target:Nick())
	end,
})

MilBase.RegisterPlayerAction("squad_kick", {
	name = "Kick From Squad",
	icon = "icon16/group_delete.png",
	order = 36,
	visible = function(lp, target)
		return target ~= lp and isLeader(lp)
			and target:GetNWString("mb_squad", "") == lp:GetNWString("mb_squad", "")
	end,
	run = function(ply, target)
		runCmd(ply, "squad", { "kick", target:Nick() }, "kick " .. target:Nick())
	end,
})

--------------------------------------------------------------------------
-- Assign a player to a regiment (faction whitelist) via a submenu.
-- Admins can assign anyone to anything; TryAssignFaction re-checks
-- serverside. Officers already have the targeted Recruit / Discharge
-- actions, so this full submenu is admin-only to avoid a list of
-- choices that would just get rejected.
--------------------------------------------------------------------------

MilBase.RegisterPlayerAction("assign_faction", {
	name = "Assign to Regiment",
	icon = "icon16/flag_blue.png",
	order = 25,
	visible = function(lp, target)
		return target ~= lp and lp:IsAdmin()
	end,
	options = function(lp, target)
		local out = {}
		for _, id in ipairs(MilBase.FactionOrder) do
			local faction = MilBase.GetFaction(id)
			if faction then
				out[#out + 1] = {
					label = (target:MBFactionID() == id and "✔  " or "") .. faction.name,
					value = id,
				}
			end
		end
		return out
	end,
	run = function(ply, target, extra)
		local faction = MilBase.GetFaction(extra)
		if not faction then return end
		MilBase.TryAssignFaction(ply, target, faction)
	end,
})

--------------------------------------------------------------------------
-- Client: the gesture wheel popup.
--------------------------------------------------------------------------

if SERVER then return end

function MilBase.OpenGestureWheel()
	local ui = MilBase.UI

	local cols, rows = 4, 2
	local bw, bh = 118, 46
	local pad = 10
	local w = cols * bw + (cols + 1) * pad
	local h = 44 + rows * bh + (rows + 1) * pad

	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Paint = function(_, pw, ph)
		MilBase.DrawPanelBF2(0, 0, pw, ph, { cut = 12, accent = ui.accent })
		draw.SimpleText("GESTURES", "MB.Tab", 14, 8, ui.text)
		draw.SimpleText("ESC to cancel", "MB.Tiny", pw - 14, 16, ui.faint,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	for i, g in ipairs(GESTURES) do
		local col = (i - 1) % cols
		local row = math.floor((i - 1) / cols)

		local btn = vgui.Create("DButton", frame)
		btn:SetText("")
		btn:SetSize(bw, bh)
		btn:SetPos(pad + col * (bw + pad), 40 + pad + row * (bh + pad))
		btn.Paint = function(self, pw, ph)
			local hovered = self:IsHovered()
			MilBase.DrawPanelBF2(0, 0, pw, ph, {
				cut = 8,
				color = hovered and ui.hover or ui.raised,
				outlineColor = hovered and ui.accent or ui.outline,
			})
			if hovered then MilBase.DrawBrackets(2, 2, pw - 4, ph - 4, ui.accent, 6) end
			draw.SimpleText(g[2], "MB.Med", pw / 2, ph / 2,
				hovered and ui.text or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = function()
			net.Start("MilBase_SelfAction")
				net.WriteString("g_" .. g[1])
			net.SendToServer()
			surface.PlaySound("ui/buttonclickrelease.wav")
			frame:Close()
		end
	end
end
