-- MilBase-styled LSCS HUD, training tree, and staff console.

local cfg = MilBase.Config.LSCS or {}
if cfg.Enabled == false then return end

local MBLSCS = MilBase.LSCS
if not MBLSCS then return end

if MilBase.UI and MilBase.UI.art and MilBase.UI.art.menuTabIcons then
	MilBase.UI.art.menuTabIcons["LSCS TRAINING"] = MilBase.Asset("menu/f4/bfui/paint-board-and-brush.png")
	MilBase.UI.art.menuTabIcons["LSCS ADMIN"] = MilBase.Asset("menu/f4/bfui/cogwheel.png")
end

MBLSCS.ClientUnlocked = MBLSCS.ClientUnlocked or {}
MBLSCS.AdminState = MBLSCS.AdminState or {}

net.Receive("MilBase_LSCSSync", function()
	MBLSCS.ClientUnlocked = net.ReadTable() or {}
	if isfunction(MBLSCS.RefreshTrainingUI) then MBLSCS.RefreshTrainingUI() end
end)

net.Receive("MilBase_LSCSAdminState", function()
	local target = net.ReadEntity()
	if not IsValid(target) then return end
	MBLSCS.AdminState[target] = {
		points = net.ReadInt(32),
		milestones = net.ReadUInt(32),
		access = net.ReadBool(),
		jedi = net.ReadBool(),
		loaded = net.ReadBool(),
		unlocked = net.ReadTable() or {},
		inventory = net.ReadTable() or {},
	}
	if isfunction(MBLSCS.RefreshAdminUI) then MBLSCS.RefreshAdminUI(target) end
end)

local function sendPurchase(id)
	net.Start("MilBase_LSCSPurchase")
		net.WriteString(id or "")
	net.SendToServer()
end

local function sendAdmin(action, target, arg)
	if not IsValid(target) then
		MilBase.Notify(LocalPlayer(), "Select a player first.")
		return
	end
	net.Start("MilBase_LSCSAdmin")
		net.WriteString(action or "")
		net.WriteEntity(target)
		net.WriteString(tostring(arg or ""))
	net.SendToServer()
end

local function actionButton(parent, label, accent, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		local enabled = self:IsEnabled()
		local col = enabled and (accent or ui.accent) or ui.faint
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6,
			color = enabled and self:IsHovered() and Color(col.r, col.g, col.b, 48) or ui.raised,
			accent = enabled and col or nil,
		})
		if enabled and self:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, enabled and ui.text or ui.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		MilBase.PlayUISound("select")
		callback()
	end
	return button
end

local function paintEntry(self, w, h)
	local ui = MilBase.UI
	surface.SetDrawColor(0, 0, 0, 155)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
	surface.DrawOutlinedRect(0, 0, w, h)
	self:DrawTextEntryText(ui.text, ui.accent, ui.text)
end

local function branchColor(node)
	local branch = node and MBLSCS.Branches[node.branch]
	return branch and branch.color or MilBase.UI.accent
end

local function requirementsText(node)
	local names = {}
	for _, id in ipairs((node and node.requires) or {}) do
		local required = MBLSCS.Nodes[id]
		names[#names + 1] = required and required.name or id
	end
	if MBLSCS.AdvancedRequirementsText then
		for _, text in ipairs(MBLSCS.AdvancedRequirementsText(node)) do names[#names + 1] = text end
	end
	return #names > 0 and table.concat(names, ", ") or "None"
end

local function nodeAvailable(node)
	if not MBLSCS.MeetsRequirements(MBLSCS.ClientUnlocked, node) then return false end
	if MBLSCS.CanLearnAdvanced then return MBLSCS.CanLearnAdvanced(LocalPlayer(), node) end
	return true
end

local function effectText(node)
	local result = {}
	local effects = node and node.effects or nil
	if effects then
		if effects.maxForce then result[#result + 1] = "+" .. effects.maxForce .. " max Force" end
		if effects.forceRegen then result[#result + 1] = "+" .. effects.forceRegen .. " Force regeneration" end
		if effects.saberDamage then result[#result + 1] = "+" .. math.Round(effects.saberDamage * 100) .. "% saber damage" end
		if effects.saberDefense then result[#result + 1] = "+" .. math.Round(effects.saberDefense * 100) .. "% saber resistance" end
	end
	if node and node.item then result[#result + 1] = "Unlocks " .. node.item end
	return #result > 0 and table.concat(result, "\n") or "Training prerequisite"
end

local function buildTrainingTab(content)
	local ui = MilBase.UI
	local selectedID = MBLSCS.NodeOrder[1]
	local nodeButtons = {}
	local maxRow = 1
	for _, id in ipairs(MBLSCS.NodeOrder) do
		maxRow = math.max(maxRow, MBLSCS.Nodes[id].row or 1)
	end

	local details = vgui.Create("DPanel", content)
	details:Dock(LEFT)
	details:SetWide(330)
	details:DockMargin(0, 0, 16, 0)
	details.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h, selectedID and branchColor(MBLSCS.Nodes[selectedID]) or ui.accent)
		draw.SimpleText("LSCS TRAINING", "MB.Tab", 18, 14, ui.text)
		draw.SimpleText(LocalPlayer():MBLSCSPoints() .. " AVAILABLE POINTS", "MB.Small", 18, 48, ui.accent)
		local xpStep = math.max(1, math.floor(tonumber(cfg.XPPerPoint) or 500))
		local progress = LocalPlayer():GetNWInt("mb_xp", 0) % xpStep
		draw.SimpleText(progress .. " / " .. xpStep .. " XP TO NEXT POINT", "MB.Tiny", 18, 70, ui.dim)
		MilBase.DrawBar(18, 91, w - 36, 6, progress / xpStep, ui.accent)
		if not MBLSCS.IsInstalled() then
			draw.SimpleText("LSCS ADDON NOT DETECTED", "MB.Small", 18, 114, ui.danger)
		end
	end

	local title = vgui.Create("DLabel", details)
	title:SetPos(18, 140)
	title:SetSize(294, 34)
	title:SetFont("MB.Big")
	title:SetTextColor(ui.text)

	local status = vgui.Create("DLabel", details)
	status:SetPos(18, 178)
	status:SetSize(294, 24)
	status:SetFont("MB.Small")

	local description = vgui.Create("DLabel", details)
	description:SetPos(18, 216)
	description:SetSize(294, 72)
	description:SetFont("MB.Small")
	description:SetTextColor(ui.dim)
	description:SetWrap(true)
	description:SetAutoStretchVertical(true)

	local requirements = vgui.Create("DLabel", details)
	requirements:SetPos(18, 314)
	requirements:SetSize(294, 66)
	requirements:SetFont("MB.Tiny")
	requirements:SetTextColor(ui.dim)
	requirements:SetWrap(true)

	local effects = vgui.Create("DLabel", details)
	effects:SetPos(18, 390)
	effects:SetSize(294, 100)
	effects:SetFont("MB.Small")
	effects:SetTextColor(ui.text)
	effects:SetWrap(true)

	local purchase = actionButton(details, "LEARN SELECTED SKILL", ui.ok, function()
		if selectedID then sendPurchase(selectedID) end
	end)
	purchase:SetPos(18, 510)
	purchase:SetSize(294, 42)

	local hint = vgui.Create("DLabel", details)
	hint:SetPos(18, 566)
	hint:SetSize(294, 82)
	hint:SetFont("MB.Tiny")
	hint:SetTextColor(ui.faint)
	hint:SetWrap(true)
	hint:SetText("Use a Jedi workbench to equip Force powers, save presets, craft a saber, or respec. Rank, alignment, trials, and holocrons can gate advanced skills.")

	details.PerformLayout = function(_, _, h)
		if h < 660 then
			hint:SetVisible(false)
			local purchaseY = math.max(410, h - 50)
			purchase:SetPos(18, purchaseY)
			effects:SetTall(math.max(20, purchaseY - 400))
		else
			hint:SetVisible(true)
			purchase:SetPos(18, 510)
			effects:SetTall(100)
		end
	end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local canvas = vgui.Create("DPanel", scroll)
	canvas:Dock(TOP)
	canvas:SetTall(78 + maxRow * 112)
	canvas.Paint = function(self, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10 })
		local columnWidth = w / math.max(#MBLSCS.BranchOrder, 1)
		for index, branchID in ipairs(MBLSCS.BranchOrder) do
			local branch = MBLSCS.Branches[branchID]
			local cx = (index - 0.5) * columnWidth
			draw.SimpleText(branch.name, "MB.Tab", cx, 25, branch.color,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(branch.color.r, branch.color.g, branch.color.b, 70)
			surface.DrawRect((index - 1) * columnWidth + 18, 48, columnWidth - 36, 2)
		end

		for id, button in pairs(nodeButtons) do
			local node = MBLSCS.Nodes[id]
			if IsValid(button) and node then
				for _, requiredID in ipairs(node.requires or {}) do
					local requiredButton = nodeButtons[requiredID]
					if IsValid(requiredButton) then
						local x1 = requiredButton:GetX() + requiredButton:GetWide() / 2
						local y1 = requiredButton:GetY() + requiredButton:GetTall()
						local x2 = button:GetX() + button:GetWide() / 2
						local y2 = button:GetY()
						local learned = MBLSCS.ClientUnlocked[requiredID] and MBLSCS.ClientUnlocked[id]
						local col = learned and branchColor(node) or ui.faint
						surface.SetDrawColor(col.r, col.g, col.b, learned and 210 or 80)
						local mid = (y1 + y2) / 2
						surface.DrawLine(x1, y1, x1, mid)
						surface.DrawLine(x1, mid, x2, mid)
						surface.DrawLine(x2, mid, x2, y2)
					end
				end
			end
		end
	end

	canvas.PerformLayout = function(self, w)
		local columnWidth = w / math.max(#MBLSCS.BranchOrder, 1)
		for id, button in pairs(nodeButtons) do
			local node = MBLSCS.Nodes[id]
			local branch = MBLSCS.Branches[node.branch]
			local index = branch and branch.index or 1
			button:SetPos((index - 1) * columnWidth + 18, 66 + (node.row - 1) * 112)
			button:SetSize(math.max(80, columnWidth - 36), 82)
		end
	end

	local function refreshDetails()
		local node = MBLSCS.Nodes[selectedID]
		if not node then return end
		local learned = MBLSCS.ClientUnlocked[selectedID] == true
		local available = nodeAvailable(node)
		local enough = LocalPlayer():MBLSCSPoints() >= node.cost
		title:SetText(node.name)
		status:SetText(learned and "LEARNED" or (available and enough and (node.cost .. " POINTS — AVAILABLE") or (node.cost .. " POINTS — LOCKED")))
		status:SetTextColor(learned and ui.ok or (available and enough and ui.accent or ui.danger))
		description:SetText(node.description or "")
		requirements:SetText("PREREQUISITES\n" .. requirementsText(node))
		effects:SetText("EFFECTS\n" .. effectText(node))
		purchase:SetEnabled(not learned and available and enough and MBLSCS.IsInstalled())
	end

	for _, id in ipairs(MBLSCS.NodeOrder) do
		local node = MBLSCS.Nodes[id]
		local button = vgui.Create("DButton", canvas)
		button:SetText("")
		button.Paint = function(self, w, h)
			local learned = MBLSCS.ClientUnlocked[id] == true
			local available = nodeAvailable(node)
			local enough = LocalPlayer():MBLSCSPoints() >= node.cost
			local col = branchColor(node)
			local fill = Color(255, 255, 255, 4)
			if learned then fill = Color(ui.ok.r, ui.ok.g, ui.ok.b, 30)
			elseif available and enough then fill = Color(col.r, col.g, col.b, self:IsHovered() and 48 or 22)
			elseif self:IsHovered() then fill = Color(255, 255, 255, 9) end
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 8, color = fill,
				accent = learned and ui.ok or (available and col or nil),
				outlineColor = available and col or ui.outline,
			})
			if selectedID == id then MilBase.DrawBrackets(3, 3, w - 6, h - 6, col, 8) end
			draw.SimpleText(node.name, "MB.Med", 14, 13, learned and ui.ok or ui.text)
			draw.SimpleText(string.upper(node.description or ""), "MB.Tiny", 14, 39,
				available and ui.dim or ui.faint)
			draw.SimpleText(learned and "LEARNED" or (node.cost .. " PT" .. (node.cost == 1 and "" or "S")),
				"MB.Small", w - 14, h - 16, learned and ui.ok or col,
				TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function()
			selectedID = id
			MilBase.PlayUISound("hover")
			refreshDetails()
		end
		nodeButtons[id] = button
	end

	MBLSCS.RefreshTrainingUI = function()
		if not IsValid(content) then MBLSCS.RefreshTrainingUI = nil return end
		refreshDetails()
		canvas:InvalidateLayout(true)
	end
	refreshDetails()
end

MilBase.AddMenuTab("LSCS TRAINING", 23, buildTrainingTab, function(lp)
	return IsValid(lp) and lp:MBLSCSAccess()
end)

-- Custom in-world HUD -----------------------------------------------------

hook.Add("LSCS:HUDShouldDraw", "MilBase.HideLSCSHUD", function()
	if cfg.HideDefaultHUD ~= false then return false end
end)

local FORCE_COLOR = Color(80, 155, 235)
local BLOCK_COLOR = Color(220, 80, 70)
local ADV_COLOR = Color(255, 198, 60)

hook.Add("HUDPaint", "MilBase.LSCSHUD", function()
	if cfg.HUDEnabled == false or not MBLSCS.IsInstalled() then return end
	if MilBase.InEventView() or MilBase.InVehicleHUD() then return end
	local ply = LocalPlayer()
	if not IsValid(ply) or not ply:Alive() or not ply:GetNWBool("mb_lscs_loaded", false) then return end
	if not ply:MBLSCSAccess() or not ply.lscsGetForce or not ply.lscsGetMaxForce then return end

	local force, maxForce = ply:lscsGetForce(), math.max(ply:lscsGetMaxForce(), 1)
	local weapon = ply:GetActiveWeapon()
	local saber = IsValid(weapon) and weapon.LSCS == true
	if cfg.HUDAlways ~= true and not saber and force >= maxForce then return end

	local rows = {
		{ label = "FORCE", value = force, maximum = maxForce, color = force / maxForce <= 0.2 and BLOCK_COLOR or FORCE_COLOR },
	}
	local stance = "FORCE CHANNEL"
	if saber then
		if weapon.GetCombo then
			local ok, combo = pcall(weapon.GetCombo, weapon)
			if ok and combo then stance = string.upper(combo.name or combo.id or "SABER") end
		end
		if weapon.GetBlockPoints and weapon.GetMaxBlockPoints then
			rows[#rows + 1] = {
				label = "GUARD",
				value = weapon:GetBlockPoints(),
				maximum = math.max(weapon:GetMaxBlockPoints(), 1),
				color = BLOCK_COLOR,
			}
		end
		if weapon.GetComboHits then
			rows[#rows + 1] = {
				label = "ADVANTAGE",
				value = weapon:GetComboHits(),
				maximum = 1,
				color = ADV_COLOR,
			}
		end
	end

	local ui = MilBase.UI
	local w = 310
	local h = 58 + #rows * 34
	local x = ScrW() - w - 28
	local y = ScrH() - h - 122
	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10, accent = saber and ADV_COLOR or FORCE_COLOR })
	draw.SimpleText(stance, "MB.Med", x + 16, y + 15, ui.text)
	draw.SimpleText(ply:MBLSCSPoints() .. " TRAINING", "MB.Tiny", x + w - 16, y + 17,
		ui.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	for index, row in ipairs(rows) do
		local ry = y + 43 + (index - 1) * 34
		local rounded = row.maximum <= 1 and math.Round(row.value * 100) .. "%" or math.floor(row.value) .. " / " .. math.floor(row.maximum)
		draw.SimpleText(row.label, "MB.Tiny", x + 16, ry, ui.dim)
		draw.SimpleText(rounded, "MB.Tiny", x + w - 16, ry, ui.text, TEXT_ALIGN_RIGHT)
		MilBase.DrawSkewBar(x + 16, ry + 17, w - 42, 7, row.value / row.maximum, row.color, { segments = 10 })
	end
end)

-- Staff console -----------------------------------------------------------

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["LSCS ADMIN"] = true

local function collectLSCSItems()
	local result = {}
	if not MBLSCS.IsInstalled() then return result end
	for _, registry in ipairs({ LSCS.Hilt or {}, LSCS.Blade or {}, LSCS.Stance or {}, LSCS.Force or {} }) do
		for _, item in pairs(registry) do
			if item.class then
				result[#result + 1] = {
					class = item.class,
					label = (item.Type or item.type or "Item") .. " — " .. (item.name or item.id or item.class),
				}
			end
		end
	end
	table.sort(result, function(a, b) return a.label < b.label end)
	return result
end

local function buildAdminTab(content)
	local ui = MilBase.UI
	local selectedPlayer
	local selectedNode = MBLSCS.NodeOrder[1]
	local selectedItem

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(290)
	left:DockMargin(0, 0, 14, 0)
	left.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("LSCS PERSONNEL", "MB.Tab", 14, 12, ui.text)
	end

	local playerScroll = vgui.Create("DScrollPanel", left)
	playerScroll:Dock(FILL)
	playerScroll:DockMargin(10, 52, 10, 10)

	for _, playerEntity in ipairs(player.GetAll()) do
		local target = playerEntity
		local row = vgui.Create("DButton", playerScroll)
		row:Dock(TOP)
		row:SetTall(48)
		row:DockMargin(0, 0, 0, 5)
		row:SetText("")
		row.Paint = function(self, w, h)
			if not IsValid(target) then return end
			local active = selectedPlayer == target
			local accent = target:MBLSCSAccess() and ui.accent or ui.danger
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 6,
				color = active and Color(accent.r, accent.g, accent.b, 35) or (self:IsHovered() and ui.hover or ui.raised),
				accent = active and accent or nil,
			})
			draw.SimpleText(target:MBName(), "MB.Small", 10, 9, ui.text)
			local accessLabel = not target:MBIsJedi() and "NON-JEDI" or (target:MBLSCSAccess() and "ENABLED" or "DISABLED")
			draw.SimpleText(target:MBLSCSPoints() .. " PTS  •  " .. accessLabel,
				"MB.Tiny", 10, 29, accent)
		end
		row.DoClick = function()
			selectedPlayer = target
			MilBase.PlayUISound("select")
			sendAdmin("request", selectedPlayer)
		end
	end

	local right = vgui.Create("DScrollPanel", content)
	right:Dock(FILL)

	local function section(label)
		local panel = vgui.Create("DPanel", right)
		panel:Dock(TOP)
		panel:SetTall(31)
		panel:DockMargin(0, 8, 8, 5)
		panel.Paint = function(_, w, h)
			draw.SimpleText(label, "MB.Small", 2, h / 2, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 45)
			surface.DrawRect(180, h / 2, math.max(0, w - 180), 1)
		end
	end

	section("PROFILE STATUS")
	local statusPanel = vgui.Create("DPanel", right)
	statusPanel:Dock(TOP)
	statusPanel:SetTall(78)
	statusPanel:DockMargin(0, 0, 8, 4)
	statusPanel.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7 })
		local state = IsValid(selectedPlayer) and MBLSCS.AdminState[selectedPlayer] or nil
		if not IsValid(selectedPlayer) then
			draw.SimpleText("SELECT A PLAYER", "MB.Tab", 16, 14, ui.dim)
			return
		end
		draw.SimpleText(selectedPlayer:MBName(), "MB.Tab", 16, 10, ui.text)
		if not state then
			draw.SimpleText("REQUESTING PROFILE…", "MB.Small", 16, 45, ui.dim)
			return
		end
		local unlockedCount = table.Count(state.unlocked or {})
		draw.SimpleText(state.points .. " POINTS  •  " .. unlockedCount .. "/" .. #MBLSCS.NodeOrder .. " SKILLS  •  "
			.. #(state.inventory or {}) .. " ITEMS", "MB.Small", 16, 48, state.access and ui.ok or ui.danger)
		local accessLabel = not state.jedi and "NON-JEDI FACTION" or (state.access and "ACCESS ENABLED" or "ACCESS DISABLED")
		draw.SimpleText(accessLabel, "MB.Small", w - 16, 21,
			state.access and ui.ok or ui.danger, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	section("TRAINING POINTS")
	local pointRow = vgui.Create("DPanel", right)
	pointRow:Dock(TOP)
	pointRow:SetTall(38)
	pointRow:DockMargin(0, 0, 8, 4)
	pointRow.Paint = nil

	local pointEntry = vgui.Create("DTextEntry", pointRow)
	pointEntry:Dock(LEFT)
	pointEntry:SetWide(130)
	pointEntry:DockMargin(0, 2, 8, 2)
	pointEntry:SetFont("MB.Small")
	pointEntry:SetText("1")
	pointEntry:SetPaintBackground(false)
	pointEntry.Paint = paintEntry

	local addPoints = actionButton(pointRow, "ADD / REMOVE", ui.accent, function()
		sendAdmin("addpoints", selectedPlayer, pointEntry:GetValue())
	end)
	addPoints:Dock(LEFT)
	addPoints:SetWide(150)
	addPoints:DockMargin(0, 0, 8, 0)

	local setPoints = actionButton(pointRow, "SET EXACT", ui.warn, function()
		sendAdmin("setpoints", selectedPlayer, pointEntry:GetValue())
	end)
	setPoints:Dock(LEFT)
	setPoints:SetWide(125)

	section("ACCESS & TREE")
	local accessRow = vgui.Create("DPanel", right)
	accessRow:Dock(TOP)
	accessRow:SetTall(38)
	accessRow:DockMargin(0, 0, 8, 5)
	accessRow.Paint = nil

	local toggleAccess = actionButton(accessRow, "TOGGLE ACCESS", ui.warn, function()
		local state = IsValid(selectedPlayer) and MBLSCS.AdminState[selectedPlayer] or nil
		if state then sendAdmin("setaccess", selectedPlayer, state.access and "0" or "1") end
	end)
	toggleAccess:Dock(LEFT)
	toggleAccess:SetWide(150)
	toggleAccess:DockMargin(0, 0, 8, 0)

	local grantAll = actionButton(accessRow, "GRANT ALL", ui.ok, function()
		sendAdmin("grantall", selectedPlayer)
	end)
	grantAll:Dock(LEFT)
	grantAll:SetWide(125)
	grantAll:DockMargin(0, 0, 8, 0)

	local resetTree = actionButton(accessRow, "RESET + REFUND", ui.danger, function()
		if not IsValid(selectedPlayer) then return end
		Derma_Query("Reset " .. selectedPlayer:MBName() .. "'s full LSCS tree and refund its costs?",
			"Confirm LSCS respec", "RESET TREE", function() sendAdmin("reset", selectedPlayer) end, "CANCEL")
	end)
	resetTree:Dock(LEFT)
	resetTree:SetWide(170)

	local nodeRow = vgui.Create("DPanel", right)
	nodeRow:Dock(TOP)
	nodeRow:SetTall(38)
	nodeRow:DockMargin(0, 0, 8, 4)
	nodeRow.Paint = nil

	local nodeCombo = vgui.Create("DComboBox", nodeRow)
	nodeCombo:Dock(FILL)
	nodeCombo:DockMargin(0, 2, 8, 2)
	nodeCombo:SetFont("MB.Small")
	nodeCombo:SetSortItems(false)
	nodeCombo:SetValue("Select a skill")
	for _, id in ipairs(MBLSCS.NodeOrder) do nodeCombo:AddChoice(MBLSCS.Nodes[id].name, id) end
	nodeCombo.OnSelect = function(_, _, _, data) selectedNode = data end

	local unlockNode = actionButton(nodeRow, "UNLOCK FREE", ui.ok, function()
		sendAdmin("unlock", selectedPlayer, selectedNode)
	end)
	unlockNode:Dock(RIGHT)
	unlockNode:SetWide(140)
	unlockNode:DockMargin(0, 0, 8, 0)

	local refundNode = actionButton(nodeRow, "REFUND BRANCH", ui.warn, function()
		sendAdmin("refund", selectedPlayer, selectedNode)
	end)
	refundNode:Dock(RIGHT)
	refundNode:SetWide(150)

	section("LSCS INVENTORY")
	local itemRow = vgui.Create("DPanel", right)
	itemRow:Dock(TOP)
	itemRow:SetTall(38)
	itemRow:DockMargin(0, 0, 8, 4)
	itemRow.Paint = nil

	local itemCombo = vgui.Create("DComboBox", itemRow)
	itemCombo:Dock(FILL)
	itemCombo:DockMargin(0, 2, 8, 2)
	itemCombo:SetFont("MB.Small")
	itemCombo:SetSortItems(false)
	itemCombo:SetValue(MBLSCS.IsInstalled() and "Select an LSCS item" or "LSCS not detected")
	for _, item in ipairs(collectLSCSItems()) do itemCombo:AddChoice(item.label, item.class) end
	itemCombo.OnSelect = function(_, _, _, data) selectedItem = data end

	local giveItem = actionButton(itemRow, "GIVE", ui.ok, function()
		if selectedItem then sendAdmin("giveitem", selectedPlayer, selectedItem) end
	end)
	giveItem:Dock(RIGHT)
	giveItem:SetWide(90)
	giveItem:DockMargin(0, 0, 8, 0)

	local removeItem = actionButton(itemRow, "REMOVE ALL", ui.danger, function()
		if selectedItem then sendAdmin("removeitem", selectedPlayer, selectedItem) end
	end)
	removeItem:Dock(RIGHT)
	removeItem:SetWide(125)

	local utilityRow = vgui.Create("DPanel", right)
	utilityRow:Dock(TOP)
	utilityRow:SetTall(38)
	utilityRow:DockMargin(0, 0, 8, 5)
	utilityRow.Paint = nil

	local craft = actionButton(utilityRow, "CRAFT / ISSUE SABER", ui.accent, function()
		sendAdmin("craft", selectedPlayer)
	end)
	craft:Dock(LEFT)
	craft:SetWide(190)
	craft:DockMargin(0, 0, 8, 0)

	local wipe = actionButton(utilityRow, "WIPE INVENTORY", ui.danger, function()
		if not IsValid(selectedPlayer) then return end
		Derma_Query("Wipe all LSCS items from " .. selectedPlayer:MBName() .. "? Learned skill items will be restored.",
			"Confirm inventory wipe", "WIPE", function() sendAdmin("wipeinventory", selectedPlayer) end, "CANCEL")
	end)
	wipe:Dock(LEFT)
	wipe:SetWide(160)

	local inventory = vgui.Create("DScrollPanel", right)
	inventory:Dock(TOP)
	inventory:SetTall(220)
	inventory:DockMargin(0, 0, 8, 8)

	local function refreshInventory()
		inventory:Clear()
		local state = IsValid(selectedPlayer) and MBLSCS.AdminState[selectedPlayer] or nil
		for _, item in ipairs(state and state.inventory or {}) do
			local row = vgui.Create("DPanel", inventory)
			row:Dock(TOP)
			row:SetTall(28)
			row:DockMargin(0, 0, 0, 3)
			row.Paint = function(_, w, h)
				surface.SetDrawColor(255, 255, 255, 5)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText("#" .. item.index .. "  " .. item.class, "MB.Small", 10, h / 2,
					ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(item.state, "MB.Tiny", w - 10, h / 2, ui.dim,
					TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		end
		if not state or #(state.inventory or {}) == 0 then
			local empty = vgui.Create("DLabel", inventory)
			empty:Dock(TOP)
			empty:SetTall(32)
			empty:SetFont("MB.Small")
			empty:SetTextColor(ui.dim)
			empty:SetText(state and "No LSCS inventory items." or "Select a player to inspect inventory.")
		end
	end

	MBLSCS.RefreshAdminUI = function(target)
		if not IsValid(content) then MBLSCS.RefreshAdminUI = nil return end
		if target == selectedPlayer then refreshInventory() end
	end
	refreshInventory()
end

MilBase.AddMenuTab("LSCS ADMIN", 94, buildAdminTab, function(lp)
	return lp:IsListenServerHost() or lp:MBStaffLevel() >= (cfg.AdminLevel or 3)
end)
