--[[
	MilBase thrust-based jetpack system.

	No certification is registered here. The reusable jetpack is a persistent
	MilBase inventory item equipped in the dedicated JETPACK gear slot. Admin
	test commands remain available while a future certification is designed.
]]

if MilBase.JetpackLoaded then return end
MilBase.JetpackLoaded = true

local function cfg()
	return (MilBase.Config and MilBase.Config.Jetpack) or {}
end

local function notify(ply, text, kind)
	if SERVER and IsValid(ply) and MilBase.Notify then MilBase.Notify(ply, text, kind) end
end

local function logAction(ply, text)
	if not SERVER or cfg().LogActions == false then return end
	local name = IsValid(ply) and (ply.MBName and ply:MBName() or ply:Nick()) or "unknown"
	local line = "[JETPACK] " .. name .. " " .. text
	print(line)
	if MilBase.Log then MilBase.Log("jetpack", line, ply) end
end

function MilBase.IsJetpackEquipped(ply)
	return IsValid(ply) and ply:IsPlayer() and ply:GetNWBool("mb_jetpack_equipped", false)
end

function MilBase.IsJetpackActive(ply)
	return MilBase.IsJetpackEquipped(ply) and ply:GetNWBool("mb_jetpack_active", false)
end

local function maximum(name, fallback)
	return math.max(1, tonumber(cfg()[name]) or fallback)
end

-- Forward-declared because the resource setters are shared, while persistent
-- inventory state is only written on the server.
local writeItemState = function() end

local function setFuel(ply, amount, delayRegen)
	local value = math.Clamp(amount, 0, maximum("FuelMax", 100))
	ply:SetNWFloat("mb_jetpack_fuel", value)
	writeItemState(ply, "jetpackFuel", value)
	if delayRegen then ply.mb_jetpackFuelRegenAt = CurTime() + (cfg().FuelRegenDelay or 1.25) end
end

local function setHeat(ply, amount)
	local value = math.Clamp(amount, 0, maximum("HeatMax", 100))
	ply:SetNWFloat("mb_jetpack_heat", value)
	writeItemState(ply, "jetpackHeat", value)
end

local function setIntegrity(ply, amount)
	local value = math.Clamp(amount, 0, maximum("IntegrityMax", 100))
	ply:SetNWFloat("mb_jetpack_integrity", value)
	writeItemState(ply, "jetpackIntegrity", value)
end

local function setThrustNetwork(ply, thrusting)
	thrusting = thrusting == true
	if ply:GetNWBool("mb_jetpack_thrust", false) ~= thrusting then
		ply:SetNWBool("mb_jetpack_thrust", thrusting)
	end
end

local function restrictionReason(ply)
	local c = cfg()
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return "You must be alive." end
	if c.MutuallyExclusiveWithJuggernaut ~= false and MilBase.IsJuggernaut and MilBase.IsJuggernaut(ply) then return "Juggernaut armour is incompatible with a jetpack." end
	if c.DisableInVehicle ~= false and ply:InVehicle() then return "Jetpack systems are disabled in vehicles." end
	if c.DisableWhileCuffed ~= false and ply:GetNWBool("mb_cuffed", false) then return "Jetpack systems are locked while restrained." end
	if c.DisableWhileJailed ~= false and ply:GetNWBool("mb_jailed", false) then return "Jetpack systems are locked while jailed." end
	if c.DisableWhileWounded ~= false and (ply:GetNWBool("mb_wounded", false) or ply:GetNWBool("mb_jug_incapacitated", false)) then return "You cannot operate a jetpack while incapacitated." end
	if c.DisableInZeroG ~= false and ply:GetNWBool("mb_zerog", false) then return "Jetpack propulsion is disabled in zero gravity." end
	return nil
end

function MilBase.GetEquippedJetpackItem(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not MilBase.GetInventory then return nil end
	local inv = MilBase.GetInventory(ply)
	local item = inv and inv.equip and inv.equip.jetpack
	local def = item and MilBase.Items and MilBase.Items[item.id]
	if item and def and def.jetpack then return item, def end
	return nil
end

writeItemState = function(ply, key, value)
	if not SERVER or not ply.mb_jetpackFromInventory then return end
	local item = MilBase.GetEquippedJetpackItem(ply)
	if item then item[key] = value end
end

function MilBase.StoreJetpackItemState(ply)
	if not SERVER or not IsValid(ply) or not ply.mb_jetpackFromInventory then return end
	local item = MilBase.GetEquippedJetpackItem(ply)
	if not item then return end
	item.jetpackFuel = ply:GetNWFloat("mb_jetpack_fuel", maximum("FuelMax", 100))
	item.jetpackHeat = ply:GetNWFloat("mb_jetpack_heat", 0)
	item.jetpackIntegrity = ply:GetNWFloat("mb_jetpack_integrity", maximum("IntegrityMax", 100))
	item.jetpackOverheated = ply:GetNWBool("mb_jetpack_overheated", false)
end

local function resetNetworkState(ply)
	ply:SetNWBool("mb_jetpack_equipped", false)
	ply:SetNWBool("mb_jetpack_active", false)
	ply:SetNWBool("mb_jetpack_hover", false)
	ply:SetNWBool("mb_jetpack_overheated", false)
	ply:SetNWBool("mb_jetpack_thrust", false)
	ply:SetNWBool("mb_jetpack_emergency", false)
	ply:SetNWFloat("mb_jetpack_fuel", 0)
	ply:SetNWFloat("mb_jetpack_heat", 0)
	ply:SetNWFloat("mb_jetpack_integrity", 0)
	ply:SetNWFloat("mb_jetpack_boost_cd", 0)
	ply:SetNWFloat("mb_jetpack_boost_until", 0)
	ply:SetNWString("mb_jetpack_state", "")
end

if SERVER then
	util.AddNetworkString("MilBase_JetpackCommand")

	function MilBase.SetJetpackActive(ply, active, silent)
		if not MilBase.IsJetpackEquipped(ply) then return false end
		active = active == true
		if active then
			local reason = restrictionReason(ply)
			if reason then if not silent then notify(ply, reason, "warn") end return false end
			if cfg().IntegrityEnabled ~= false and ply:GetNWFloat("mb_jetpack_integrity", 0) <= 0 then
				if not silent then notify(ply, "Jetpack integrity is depleted. An engineer must repair it.", "warn") end
				return false
			end
			if ply:GetNWBool("mb_jetpack_overheated", false) then
				if not silent then notify(ply, "Jetpack is overheated.", "warn") end
				return false
			end
			if ply:GetNWFloat("mb_jetpack_fuel", 0) < (cfg().FuelMinimumToIgnite or 10) then
				if not silent then notify(ply, "Insufficient jetpack fuel.", "warn") end
				return false
			end
		end

		ply:SetNWBool("mb_jetpack_active", active)
		if not active then
			ply:SetNWBool("mb_jetpack_hover", false)
			ply:SetNWBool("mb_jetpack_emergency", false)
			setThrustNetwork(ply, false)
		end
		ply:SetNWString("mb_jetpack_state", active and "IGNITED" or (ply:GetNWBool("mb_jetpack_overheated", false) and "OVERHEATED" or "STANDBY"))
		ply:EmitSound(active and "ambient/machines/thumper_startup1.wav" or "buttons/combine_button7.wav", 62, active and 138 or 90, 0.45)
		return true
	end

	function MilBase.CanEquipJetpack(ply)
		local c = cfg()
		if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false, "You must be alive." end
		if c.Enabled == false then return false, "The Jetpack system is disabled." end
		if MilBase.IsJetpackEquipped(ply) then return false, "A jetpack is already equipped." end
		local reason = restrictionReason(ply)
		if reason then return false, reason end
		return true
	end

	function MilBase.EquipJetpack(ply, inventoryItem, silent)
		local c = cfg()
		local ok, reason = MilBase.CanEquipJetpack(ply)
		if not ok then if not silent then notify(ply, reason, "warn") end return false end

		ply.mb_jetpackFromInventory = istable(inventoryItem)
		ply.mb_jetpackInventoryUID = istable(inventoryItem) and inventoryItem.uid or nil
		ply:SetNWBool("mb_jetpack_equipped", true)
		ply:SetNWBool("mb_jetpack_active", false)
		ply:SetNWBool("mb_jetpack_hover", false)
		ply:SetNWBool("mb_jetpack_overheated", false)
		ply:SetNWBool("mb_jetpack_emergency", false)
		local storedFuel = istable(inventoryItem) and tonumber(inventoryItem.jetpackFuel) or nil
		local storedHeat = istable(inventoryItem) and tonumber(inventoryItem.jetpackHeat) or nil
		local storedIntegrity = istable(inventoryItem) and tonumber(inventoryItem.jetpackIntegrity) or nil
		local storedOverheat = istable(inventoryItem) and inventoryItem.jetpackOverheated == true
		ply:SetNWBool("mb_jetpack_overheated", storedOverheat and (storedHeat or 0) > (c.OverheatRecovery or 38))
		ply:SetNWString("mb_jetpack_state", ply:GetNWBool("mb_jetpack_overheated", false) and "OVERHEATED" or "STANDBY")
		setFuel(ply, storedFuel or c.FuelMax or 100)
		setHeat(ply, storedHeat or 0)
		setIntegrity(ply, storedIntegrity or c.IntegrityMax or 100)
		ply:SetNWFloat("mb_jetpack_boost_cd", 0)
		ply.mb_jetpackFuelRegenAt = CurTime()
		ply:EmitSound("items/suitchargeok1.wav", 68, 112)
		if not silent then notify(ply, "Jetpack equipped. Double-tap Jump to ignite; press G for systems.", "ok") end
		logAction(ply, "equipped")
		return true
	end

	function MilBase.UnequipJetpack(ply, silent)
		if not IsValid(ply) or not MilBase.IsJetpackEquipped(ply) then return end
		MilBase.StoreJetpackItemState(ply)
		MilBase.SetJetpackActive(ply, false, true)
		resetNetworkState(ply)
		ply.mb_jetpackFromInventory = nil
		ply.mb_jetpackInventoryUID = nil
		ply.mb_jetpackLastJump = nil
		ply.mb_jetpackFuelRegenAt = nil
		ply.mb_jetpackRepair = nil
		if not silent then notify(ply, "Jetpack removed.", "ok") end
		logAction(ply, "unequipped")
	end

	function MilBase.SyncJetpackEquipment(ply, inventoryItem)
		if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
		if inventoryItem then
			if not MilBase.IsJetpackEquipped(ply) then
				MilBase.EquipJetpack(ply, inventoryItem, true)
			elseif ply.mb_jetpackFromInventory then
				ply.mb_jetpackInventoryUID = inventoryItem.uid
			end
		elseif MilBase.IsJetpackEquipped(ply) and ply.mb_jetpackFromInventory then
			MilBase.UnequipJetpack(ply, true)
		end
	end

	function MilBase.ToggleJetpackHover(ply)
		if not MilBase.IsJetpackActive(ply) then
			if not MilBase.SetJetpackActive(ply, true) then return false end
		end
		local on = not ply:GetNWBool("mb_jetpack_hover", false)
		ply:SetNWBool("mb_jetpack_hover", on)
		ply:SetNWBool("mb_jetpack_emergency", false)
		ply:SetNWString("mb_jetpack_state", on and "HOVER" or "IGNITED")
		return true
	end

	function MilBase.VentJetpack(ply)
		if not MilBase.IsJetpackEquipped(ply) then return false end
		MilBase.SetJetpackActive(ply, false, true)
		ply.mb_jetpackVentUntil = CurTime() + (cfg().VentDuration or 2.5)
		ply:SetNWString("mb_jetpack_state", "VENTING")
		ply:EmitSound("ambient/gas/steam2.wav", 68, 115, 0.55)
		return true
	end

	function MilBase.JetpackEmergencyLanding(ply)
		if not MilBase.IsJetpackEquipped(ply) or ply:OnGround() then return false end
		if not MilBase.SetJetpackActive(ply, true) then return false end
		ply:SetNWBool("mb_jetpack_hover", false)
		ply:SetNWBool("mb_jetpack_emergency", true)
		ply:SetNWString("mb_jetpack_state", "AUTO LAND")
		return true
	end

	local function performBoost(ply)
		local c = cfg()
		if not MilBase.IsJetpackActive(ply) or ply:OnGround() then return false end
		if CurTime() < ply:GetNWFloat("mb_jetpack_boost_cd", 0) then return false end
		local fuelCost = c.BoostFuelCost or 22
		if ply:GetNWFloat("mb_jetpack_fuel", 0) < fuelCost then notify(ply, "Insufficient fuel for boost.", "warn") return false end
		if ply:GetNWBool("mb_jetpack_overheated", false) then return false end

		local forward = ply:EyeAngles():Forward()
		local move = Vector(0, 0, 0)
		if ply:KeyDown(IN_FORWARD) then move = move + forward end
		if ply:KeyDown(IN_BACK) then move = move - forward end
		if ply:KeyDown(IN_MOVERIGHT) then move = move + ply:EyeAngles():Right() end
		if ply:KeyDown(IN_MOVELEFT) then move = move - ply:EyeAngles():Right() end
		if move:LengthSqr() < 0.01 then move = forward end
		move.z = math.Clamp(move.z, -0.25, 0.65)
		move:Normalize()

		local trace = util.TraceHull({
			start = ply:GetPos(),
			endpos = ply:GetPos() + move * (c.BoostTraceDistance or 92),
			mins = ply:OBBMins(), maxs = ply:OBBMaxs(),
			filter = ply, mask = MASK_PLAYERSOLID,
		})
		if trace.Hit then notify(ply, "Boost path obstructed.", "warn") return false end

		setFuel(ply, ply:GetNWFloat("mb_jetpack_fuel", 0) - fuelCost, true)
		setHeat(ply, ply:GetNWFloat("mb_jetpack_heat", 0) + (c.BoostHeat or 26))
		ply:SetNWFloat("mb_jetpack_boost_cd", CurTime() + (c.BoostCooldown or 2.25))
		ply:SetNWFloat("mb_jetpack_boost_until", CurTime() + 0.32)
		ply:SetNWString("mb_jetpack_state", "BOOST")
		ply:SetVelocity(move * (c.BoostSpeed or 540) + Vector(0, 0, c.BoostUpwardSpeed or 75))
		ply:EmitSound("ambient/machines/thumper_hit.wav", 72, 155, 0.38)
		logAction(ply, "boosted")
		return true
	end

	local function consumeRepairItem(ply, item)
		if cfg().RequireRepairKit == false then return true end
		if not item then return false end
		local current = MilBase.InvFindAny and MilBase.InvFindAny(MilBase.GetInventory(ply), item.uid) or item
		if not current then return false end
		local cost = cfg().RepairChargeCost or 35
		if current.charges then
			if current.charges < cost then return false end
			current.charges = current.charges - cost
			if current.charges <= 0 then MilBase.RemoveItemUID(ply, current.uid) else MilBase.MarkInvDirty(ply) end
		else
			MilBase.RemoveItemUID(ply, current.uid, 1)
		end
		return true
	end

	local function beginRepair(helper, target)
		if helper.mb_jetpackRepair then return end
		if not (helper:IsAdmin() or (helper.MBHasCert and helper:MBHasCert("engineer"))) then return end
		if not MilBase.IsJetpackEquipped(target) then return end
		if target:GetNWFloat("mb_jetpack_integrity", 0) >= maximum("IntegrityMax", 100) then return end
		local item = true
		if cfg().RequireRepairKit ~= false then
			item = MilBase.FindEngItem and MilBase.FindEngItem(helper, "repair")
			if not item or (item.charges and item.charges < (cfg().RepairChargeCost or 35)) then
				notify(helper, "A repair kit with sufficient parts is required.", "warn")
				return
			end
		end
		local duration = cfg().RepairTime or 5
		helper.mb_jetpackRepair = { target = target, item = item, started = CurTime(), finish = CurTime() + duration, duration = duration }
		helper:SetNWString("mb_jetpack_repair_action", "REPAIRING JETPACK")
		helper:SetNWFloat("mb_jetpack_repair_progress", 0.01)
	end

	local function cancelRepair(helper, message)
		if not helper.mb_jetpackRepair then return end
		helper.mb_jetpackRepair = nil
		helper:SetNWFloat("mb_jetpack_repair_progress", 0)
		helper:SetNWString("mb_jetpack_repair_action", "")
		if message then notify(helper, message, "warn") end
	end

	hook.Add("KeyPress", "MilBase.JetpackControls", function(ply, key)
		if not MilBase.IsJetpackEquipped(ply) then return end
		if key == IN_JUMP then
			local now = CurTime()
			if ply.mb_jetpackLastJump and now - ply.mb_jetpackLastJump <= (cfg().DoubleTapJumpWindow or 0.34) then
				ply.mb_jetpackLastJump = nil
				MilBase.SetJetpackActive(ply, not MilBase.IsJetpackActive(ply))
			else
				ply.mb_jetpackLastJump = now
			end
		elseif key == (cfg().BoostKey or IN_SPEED) then
			performBoost(ply)
		elseif key == IN_USE and ply:Crouching() then
			local target = ply:GetEyeTrace().Entity
			if IsValid(target) and target:IsPlayer() and target:GetPos():DistToSqr(ply:GetPos()) <= (cfg().RepairRange or 125) ^ 2 then
				beginRepair(ply, target)
			end
		end
	end)

	hook.Add("KeyRelease", "MilBase.JetpackRepairRelease", function(ply, key)
		if key == IN_USE and ply.mb_jetpackRepair then cancelRepair(ply, "Jetpack repair interrupted.") end
	end)

	local nextResourceTick = 0
	hook.Add("Think", "MilBase.JetpackResources", function()
		local now = CurTime()
		if now < nextResourceTick then return end
		local dt = 0.1
		nextResourceTick = now + dt
		local c = cfg()
		for _, ply in ipairs(player.GetAll()) do
			if MilBase.IsJetpackEquipped(ply) then
				local reason = restrictionReason(ply)
				if reason and MilBase.IsJetpackActive(ply) then MilBase.SetJetpackActive(ply, false, true) end

				local fuel = ply:GetNWFloat("mb_jetpack_fuel", 0)
				local heat = ply:GetNWFloat("mb_jetpack_heat", 0)
				local active = MilBase.IsJetpackActive(ply)
				local thrusting = ply.mb_jetpackThrusting == true
				local directional = ply.mb_jetpackDirectional == true
				local hovering = ply:GetNWBool("mb_jetpack_hover", false)
				local venting = (ply.mb_jetpackVentUntil or 0) > now

				if active and not ply:OnGround() then
					local drain = c.FuelDrainIdleFlight or 2.5
					if thrusting then drain = drain + (c.FuelDrainLift or 13) end
					if hovering then drain = drain + (c.FuelDrainHover or 10) end
					if directional then drain = drain + (c.FuelDrainDirectional or 3) end
					fuel = fuel - drain * dt
					local heatGain = 0
					if thrusting then heatGain = heatGain + (c.HeatLiftPerSecond or 13) end
					if hovering then heatGain = heatGain + (c.HeatHoverPerSecond or 9) end
					if directional then heatGain = heatGain + (c.HeatDirectionalPerSecond or 3) end
					heat = heat + heatGain * dt
				else
					local regen = ply:OnGround() and (c.FuelRegenGrounded or 22) or (c.FuelRegenAirborne or 0)
					if now >= (ply.mb_jetpackFuelRegenAt or 0) then fuel = fuel + regen * dt end
				end

				local cooling = venting and (c.HeatVentPerSecond or 48) or (c.HeatCoolPerSecond or 20)
				if not active or (not thrusting and not hovering) then heat = heat - cooling * dt end
				setFuel(ply, fuel)
				setHeat(ply, heat)

				if ply:GetNWFloat("mb_jetpack_fuel", 0) <= 0 and active then
					MilBase.SetJetpackActive(ply, false, true)
					notify(ply, "Jetpack fuel depleted.", "warn")
				end
				if ply:GetNWFloat("mb_jetpack_heat", 0) >= maximum("HeatMax", 100) and not ply:GetNWBool("mb_jetpack_overheated", false) then
					ply:SetNWBool("mb_jetpack_overheated", true)
					writeItemState(ply, "jetpackOverheated", true)
					MilBase.SetJetpackActive(ply, false, true)
					ply:SetNWString("mb_jetpack_state", "OVERHEATED")
					ply:EmitSound("ambient/gas/steam2.wav", 76, 88, 0.65)
					notify(ply, "Jetpack emergency thermal shutdown.", "warn")
				end
				if ply:GetNWBool("mb_jetpack_overheated", false) and ply:GetNWFloat("mb_jetpack_heat", 0) <= (c.OverheatRecovery or 38) then
					ply:SetNWBool("mb_jetpack_overheated", false)
					writeItemState(ply, "jetpackOverheated", false)
					ply:SetNWString("mb_jetpack_state", "STANDBY")
					notify(ply, "Jetpack thermal systems recovered.", "ok")
				end
				if venting and ply.mb_jetpackVentUntil <= now then
					ply.mb_jetpackVentUntil = nil
					if not ply:GetNWBool("mb_jetpack_overheated", false) then ply:SetNWString("mb_jetpack_state", "STANDBY") end
				end
			end

			local repair = ply.mb_jetpackRepair
			if repair then
				local target = repair.target
				local valid = IsValid(target) and target:IsPlayer() and target:Alive()
					and MilBase.IsJetpackEquipped(target) and ply:Alive() and ply:Crouching() and ply:KeyDown(IN_USE)
					and target:GetPos():DistToSqr(ply:GetPos()) <= (c.RepairRange or 125) ^ 2
				if not valid then
					cancelRepair(ply, "Jetpack repair interrupted.")
				else
					ply:SetNWFloat("mb_jetpack_repair_progress", math.Clamp((now - repair.started) / repair.duration, 0.01, 1))
					if now >= repair.finish then
						if consumeRepairItem(ply, repair.item) then
							setIntegrity(target, target:GetNWFloat("mb_jetpack_integrity", 0) + (c.RepairAmount or 55))
							target:EmitSound("items/suitchargeok1.wav", 65, 118)
							notify(ply, "Jetpack repaired.", "ok")
							notify(target, "Your jetpack was repaired by " .. (ply.MBName and ply:MBName() or ply:Nick()) .. ".", "ok")
						end
						cancelRepair(ply)
					end
				end
			end
		end
	end)

	net.Receive("MilBase_JetpackCommand", function(_, ply)
		if not MilBase.IsJetpackEquipped(ply) then return end
		local command = net.ReadString()
		if command == "flight" then MilBase.SetJetpackActive(ply, not MilBase.IsJetpackActive(ply))
		elseif command == "hover" then MilBase.ToggleJetpackHover(ply)
		elseif command == "vent" then MilBase.VentJetpack(ply)
		elseif command == "land" then MilBase.JetpackEmergencyLanding(ply)
		elseif command == "unequip" then
			if ply.mb_jetpackFromInventory and MilBase.UnequipEquipmentSlot then
				MilBase.UnequipEquipmentSlot(ply, "jetpack")
			else
				MilBase.UnequipJetpack(ply)
			end
		end
	end)

	MilBase.RegisterChatCommand("jetpack", {
		help = "(Admin test) Toggle a jetpack: /jetpack [player]",
		adminOnly = true,
		func = function(ply, _, rawText)
			local target = string.Trim(rawText or "") ~= "" and MilBase.FindPlayer(string.Trim(rawText)) or ply
			if not IsValid(target) then notify(ply, "Player not found.", "warn") return end
			if MilBase.IsJetpackEquipped(target) then
				if target.mb_jetpackFromInventory and MilBase.UnequipEquipmentSlot then
					MilBase.UnequipEquipmentSlot(target, "jetpack")
				else
					MilBase.UnequipJetpack(target)
				end
			else
				MilBase.EquipJetpack(target)
			end
		end,
	})

	MilBase.RegisterChatCommand("givejetpack", {
		help = "(Admin) Give the persistent jetpack inventory item: /givejetpack [player]",
		adminOnly = true,
		func = function(ply, _, rawText)
			local target = string.Trim(rawText or "") ~= "" and MilBase.FindPlayer(string.Trim(rawText)) or ply
			if not IsValid(target) then notify(ply, "Player not found.", "warn") return end
			local id = cfg().InventoryItemID or "jetpack_jt12"
			if MilBase.CountItem and MilBase.CountItem(target, id) > 0 then
				notify(ply, "That player already owns a jetpack item.", "warn")
				return
			end
			if not MilBase.GiveItem or MilBase.GiveItem(target, id, 1) < 1 then
				notify(ply, "The target has no inventory space for a jetpack.", "warn")
				return
			end
			local def = MilBase.Items and MilBase.Items[id]
			notify(target, "A " .. (def and def.name or "Jetpack") .. " was added to your inventory.", "ok")
			if target ~= ply then notify(ply, "Jetpack item issued.", "ok") end
		end,
	})

	concommand.Add("mb_jetpack", function(ply, _, args)
		if IsValid(ply) and not ply:IsAdmin() then return end
		local target = IsValid(ply) and (args[1] and MilBase.FindPlayer(args[1]) or ply) or nil
		if not IsValid(target) then return end
		if MilBase.IsJetpackEquipped(target) then
			if target.mb_jetpackFromInventory and MilBase.UnequipEquipmentSlot then
				MilBase.UnequipEquipmentSlot(target, "jetpack")
			else
				MilBase.UnequipJetpack(target)
			end
		else
			MilBase.EquipJetpack(target)
		end
	end)

	hook.Add("GetFallDamage", "MilBase.JetpackAssistedLanding", function(ply, speed)
		local c = cfg()
		if c.AssistedLanding == false or not MilBase.IsJetpackActive(ply) then return end
		if ply:GetNWBool("mb_jetpack_overheated", false) then return end
		if c.IntegrityEnabled ~= false and ply:GetNWFloat("mb_jetpack_integrity", 0) <= 0 then return end
		if (tonumber(speed) or 0) < (c.LandingMinimumSpeed or 360) then return end
		local cost = c.LandingFuelCost or 12
		if ply:GetNWFloat("mb_jetpack_fuel", 0) < cost then return end
		setFuel(ply, ply:GetNWFloat("mb_jetpack_fuel", 0) - cost, true)
		setHeat(ply, ply:GetNWFloat("mb_jetpack_heat", 0) + (c.LandingHeat or 8))
		ply.mb_jetpackSafeLandingUntil = CurTime() + 0.25
		return 0
	end)

	hook.Add("OnPlayerHitGround", "MilBase.JetpackLanding", function(ply, inWater, onFloater, speed)
		if not MilBase.IsJetpackEquipped(ply) then return end
		ply:SetNWBool("mb_jetpack_emergency", false)
		if MilBase.IsJetpackActive(ply) and not ply:KeyDown(IN_JUMP) then
			ply:SetNWString("mb_jetpack_state", "IGNITED")
		end
		if (ply.mb_jetpackSafeLandingUntil or 0) >= CurTime() then
			ply:EmitSound("physics/flesh/flesh_impact_hard3.wav", 58, 135, 0.3)
		end
	end)

	hook.Add("EntityTakeDamage", "MilBase.JetpackIntegrity", function(ent, dmg)
		local c = cfg()
		if c.IntegrityEnabled == false or not MilBase.IsJetpackEquipped(ent) then return end
		if dmg:IsDamageType(DMG_FALL) then return end
		local scale = 0
		if dmg:IsExplosionDamage() then
			scale = c.ExplosionDamageScale or 0.55
		else
			local source
			local attacker = dmg:GetAttacker()
			if IsValid(attacker) and attacker ~= ent then source = attacker:WorldSpaceCenter() end
			if not source then
				local inflictor = dmg:GetInflictor()
				if IsValid(inflictor) and inflictor ~= ent then source = inflictor:WorldSpaceCenter() end
			end
			if source then
				local dir = (source - ent:WorldSpaceCenter()):GetNormalized()
				if ent:GetForward():Dot(dir) <= (c.RearDamageDot or -0.2) then scale = c.RearDamageScale or 0.32 end
			end
		end
		if scale <= 0 then return end
		local before = ent:GetNWFloat("mb_jetpack_integrity", maximum("IntegrityMax", 100))
		setIntegrity(ent, before - math.max(1, dmg:GetDamage() * scale))
		if before > 0 and ent:GetNWFloat("mb_jetpack_integrity", 0) <= 0 then
			MilBase.SetJetpackActive(ent, false, true)
			ent:SetNWString("mb_jetpack_state", "SYSTEM DAMAGED")
			ent:EmitSound("npc/turret_floor/die.wav", 74, 120)
			notify(ent, "Jetpack disabled by damage. Engineer repair required.", "warn")
		end
	end)

	hook.Add("EntityFireBullets", "MilBase.JetpackWeaponSpread", function(shooter, data)
		if not IsValid(shooter) or not shooter:IsPlayer() or not MilBase.IsJetpackActive(shooter) or shooter:OnGround() then return end
		if cfg().BoostBlocksFiring ~= false and shooter:GetNWFloat("mb_jetpack_boost_until", 0) > CurTime() then return false end
		if isvector(data.Spread) then
			local add = cfg().AirborneWeaponSpread or 0.014
			data.Spread = data.Spread + Vector(add, add, 0)
		end
	end)

	hook.Add("CanPlayerEnterVehicle", "MilBase.JetpackVehicleRestriction", function(ply)
		if MilBase.IsJetpackActive(ply) then MilBase.SetJetpackActive(ply, false, true) end
	end)

	hook.Add("PlayerDeath", "MilBase.JetpackDeathCleanup", function(ply)
		if MilBase.IsJetpackEquipped(ply) then MilBase.UnequipJetpack(ply, true) end
		cancelRepair(ply)
	end)
	hook.Add("PlayerSpawn", "MilBase.JetpackSpawnCleanup", function(ply)
		if ply:GetNWBool("mb_jetpack_equipped", false) then
			MilBase.StoreJetpackItemState(ply)
			resetNetworkState(ply)
		end
		ply.mb_jetpackFromInventory = nil
		ply.mb_jetpackInventoryUID = nil
		ply.mb_jetpackLastJump = nil
		ply.mb_jetpackRepair = nil
		timer.Simple(0, function()
			if IsValid(ply) and ply:Alive() and MilBase.SyncJetpackEquipment then
				MilBase.SyncJetpackEquipment(ply, MilBase.GetEquippedJetpackItem(ply))
			end
		end)
	end)
	hook.Add("PlayerDisconnected", "MilBase.JetpackDisconnectCleanup", function(ply)
		ply.mb_jetpackRepair = nil
	end)
else
	local function sendCommand(id)
		net.Start("MilBase_JetpackCommand")
			net.WriteString(id)
		net.SendToServer()
	end

	local function drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, color)
		local points = {}
		local steps = 12
		for step = 0, steps do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * outerRadius, y = cy + math.sin(angle) * outerRadius }
		end
		for step = steps, 0, -1 do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * innerRadius, y = cy + math.sin(angle) * innerRadius }
		end
		draw.NoTexture()
		surface.SetDrawColor(color)
		surface.DrawPoly(points)
	end

	local function abilities(ply)
		local active = MilBase.IsJetpackActive(ply)
		local fuel = ply:GetNWFloat("mb_jetpack_fuel", 0)
		local heat = ply:GetNWFloat("mb_jetpack_heat", 0)
		local broken = cfg().IntegrityEnabled ~= false and ply:GetNWFloat("mb_jetpack_integrity", 0) <= 0
		return {
			{ id = "flight", label = active and "SHUT DOWN" or "IGNITE", description = active and "Disable thrust" or "Enable flight systems", enabled = active or (fuel >= (cfg().FuelMinimumToIgnite or 10) and not broken and not ply:GetNWBool("mb_jetpack_overheated", false)) },
			{ id = "hover", label = ply:GetNWBool("mb_jetpack_hover", false) and "RELEASE HOVER" or "HOVER MODE", description = "Hold approximate altitude", enabled = not broken and fuel > 0 },
			{ id = "land", label = "AUTO LAND", description = "Controlled emergency descent", enabled = not ply:OnGround() and not broken and fuel > 0 },
			{ id = "vent", label = "VENT HEAT", description = "Shut down and cool rapidly", enabled = heat > 2 },
			{ id = "unequip", label = "STOW PACK", description = "Return the jetpack to your inventory", enabled = ply:OnGround(), danger = true },
			{ id = "cancel", label = "CANCEL", description = "Close systems wheel", enabled = true },
		}
	end

	function MilBase.OpenJetpackWheel()
		local ply = LocalPlayer()
		if not MilBase.IsJetpackEquipped(ply) then return end
		if IsValid(MilBase.JetpackWheel) then MilBase.JetpackWheel:Remove() end
		local options = abilities(ply)
		local frame = vgui.Create("DFrame")
		MilBase.JetpackWheel = frame
		frame:SetSize(ScrW(), ScrH())
		frame:SetPos(0, 0)
		frame:SetTitle("")
		frame:ShowCloseButton(false)
		frame:SetDraggable(false)
		frame:MakePopup()
		frame:SetCursor("hand")
		frame.SelectedAbility = nil
		frame.PreviousAbility = nil

		local function metrics(w, h)
			local scale = math.Clamp(math.min(w / 1920, h / 1080), 0.72, 1.2)
			return w * 0.5, h * 0.52, 120 * scale, 320 * scale, scale
		end

		function frame:Think()
			local cx, cy, innerRadius, outerRadius = metrics(self:GetSize())
			local mx, my = gui.MousePos()
			local dx, dy = mx - cx, my - cy
			local distance = math.sqrt(dx * dx + dy * dy)
			local selected
			if distance >= innerRadius and distance <= outerRadius then
				local angle = (math.deg(math.atan2(dy, dx)) + 450) % 360
				local segment = 360 / #options
				selected = math.floor((angle + segment * 0.5) / segment) % #options + 1
			end
			self.SelectedAbility = selected
			if selected ~= self.PreviousAbility then
				if selected and MilBase.PlayUISound then MilBase.PlayUISound("hover") end
				self.PreviousAbility = selected
			end
		end

		function frame:OnMousePressed(code)
			if code == MOUSE_RIGHT then self:Remove() return end
			if code ~= MOUSE_LEFT then return end
			local option = self.SelectedAbility and options[self.SelectedAbility]
			if not option or not option.enabled then return end
			if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			if option.id ~= "cancel" then sendCommand(option.id) end
			self:Remove()
		end
		function frame:OnKeyCodePressed(code) if code == KEY_ESCAPE then self:Remove() end end

		frame.Paint = function(self, w, h)
			local ui = MilBase.UI or {}
			local panel = ui.panel or Color(10, 10, 11, 230)
			local hover = ui.hover or Color(255, 198, 60, 25)
			local outline = ui.outline or Color(255, 198, 60, 55)
			local accent = ui.accent or Color(255, 198, 60)
			local text = ui.text or Color(240, 238, 230)
			local dim = ui.dim or Color(170, 162, 140)
			local danger = ui.danger or Color(220, 80, 70)
			if MilBase.DrawBlur then MilBase.DrawBlur(self, 3) end
			surface.SetDrawColor(6, 6, 7, 220)
			surface.DrawRect(0, 0, w, h)
			local cx, cy, innerRadius, outerRadius, scale = metrics(w, h)
			local segment, gap = 360 / #options, 2.6
			draw.SimpleText("JETPACK FLIGHT SYSTEMS", "MB.Big", cx, cy - outerRadius - 72 * scale, text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(accent)
			surface.DrawRect(cx - 100 * scale, cy - outerRadius - 46 * scale, 200 * scale, 2)
			draw.SimpleText("SELECT A SYSTEM", "MB.Tiny", cx, cy - outerRadius - 28 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			for index, option in ipairs(options) do
				local middle = -90 + (index - 1) * segment
				local startAngle = middle - segment * 0.5 + gap
				local endAngle = middle + segment * 0.5 - gap
				local selected = self.SelectedAbility == index
				local base = selected and hover or panel
				if not option.enabled then base = Color(18, 18, 19, 215) end
				if option.danger and selected then base = Color(danger.r, danger.g, danger.b, 34) end
				drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, base)
				local edge = not option.enabled and Color(dim.r, dim.g, dim.b, 35) or selected and (option.danger and danger or accent) or outline
				drawWheelSector(cx, cy, outerRadius - 2, outerRadius, startAngle, endAngle, edge)
				local angle = math.rad(middle)
				local radius = (innerRadius + outerRadius) * 0.5
				local lx, ly = cx + math.cos(angle) * radius, cy + math.sin(angle) * radius
				local labelColor = not option.enabled and dim or selected and (option.danger and danger or accent) or text
				draw.SimpleText(option.label, "MB.Small", lx, ly, labelColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			local selected = self.SelectedAbility and options[self.SelectedAbility]
			if MilBase.DrawPanelBF2 then MilBase.DrawPanelBF2(cx - innerRadius + 8 * scale, cy - 62 * scale, innerRadius * 2 - 16 * scale, 124 * scale, { color = panel, accent = accent, outlineColor = outline, cut = 9 * scale }) end
			draw.SimpleText(selected and selected.label or "SYSTEMS", "MB.Tab", cx, cy - 22 * scale, selected and (selected.enabled and accent or danger) or text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(selected and selected.description or "MOVE THE CURSOR TO A SYSTEM", "MB.Tiny", cx, cy + 12 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("LMB CONFIRM  •  RMB / ESC CANCEL", "MB.Tiny", cx, cy + 39 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	concommand.Add("mb_jetpack_wheel", function() MilBase.OpenJetpackWheel() end)
	hook.Add("PlayerButtonDown", "MilBase.JetpackWheelKey", function(ply, button)
		if ply ~= LocalPlayer() or button ~= (cfg().WheelKey or KEY_G or 17) then return end
		if gui.IsGameUIVisible() or vgui.CursorVisible() then return end
		if MilBase.IsJetpackEquipped(ply) then MilBase.OpenJetpackWheel() end
	end)

	local packModels = {}
	local function removePackModel(ply)
		local model = packModels[ply]
		if IsValid(model) then model:Remove() end
		packModels[ply] = nil
	end

	hook.Add("PostPlayerDraw", "MilBase.JetpackVisuals", function(ply)
		if not MilBase.IsJetpackEquipped(ply) then removePackModel(ply) return end
		local c = cfg()
		local path = c.BackModel or ""
		if path ~= "" and util.IsValidModel(path) then
			local model = packModels[ply]
			if not IsValid(model) or model:GetModel() ~= path then
				removePackModel(ply)
				model = ClientsideModel(path, RENDERGROUP_OPAQUE)
				if IsValid(model) then model:SetNoDraw(true) packModels[ply] = model end
			end
			if IsValid(model) then
				local bone = ply:LookupBone(c.BackBone or "ValveBiped.Bip01_Spine2")
				local matrix = bone and ply:GetBoneMatrix(bone)
				if matrix then
					local pos, ang = LocalToWorld(c.BackOffset or vector_origin, c.BackAngle or angle_zero, matrix:GetTranslation(), matrix:GetAngles())
					model:SetRenderOrigin(pos)
					model:SetRenderAngles(ang)
					model:SetModelScale(c.BackModelScale or 1, 0)
					model:DrawModel()
				end
			end
		end

		if not MilBase.IsJetpackActive(ply) and ply:GetNWFloat("mb_jetpack_boost_until", 0) <= CurTime() then return end
		local ang = Angle(0, ply:GetAngles().y, 0)
		local left = LocalToWorld(c.ThrusterOffsetLeft or Vector(-10, -8, 43), angle_zero, ply:GetPos(), ang)
		local right = LocalToWorld(c.ThrusterOffsetRight or Vector(-10, 8, 43), angle_zero, ply:GetPos(), ang)
		local boost = ply:GetNWFloat("mb_jetpack_boost_until", 0) > CurTime()
		local thrust = ply:GetNWBool("mb_jetpack_thrust", false) or boost or ply:GetNWBool("mb_jetpack_hover", false)
		if not thrust then return end
		local size = boost and 22 or 13
		local mat = Material("sprites/light_glow02_add")
		render.SetMaterial(mat)
		render.DrawSprite(left, size, size, Color(95, 180, 255, 235))
		render.DrawSprite(right, size, size, Color(95, 180, 255, 235))
		render.DrawBeam(left, left - Vector(0, 0, boost and 34 or 20), size * 0.35, 0, 1, Color(120, 205, 255, 160))
		render.DrawBeam(right, right - Vector(0, 0, boost and 34 or 20), size * 0.35, 0, 1, Color(120, 205, 255, 160))
	end)

	hook.Add("EntityRemoved", "MilBase.JetpackRemoveModel", function(ent)
		if ent:IsPlayer() then removePackModel(ent) end
	end)
	hook.Add("ShutDown", "MilBase.JetpackRemoveAllModels", function()
		for ply in pairs(packModels) do removePackModel(ply) end
	end)

	local loopSounds = {}
	hook.Add("Think", "MilBase.JetpackLoopSound", function()
		for _, ply in ipairs(player.GetAll()) do
			local shouldPlay = MilBase.IsJetpackActive(ply) and (ply:GetNWBool("mb_jetpack_thrust", false) or ply:GetNWBool("mb_jetpack_hover", false))
			local soundPatch = loopSounds[ply]
			if shouldPlay and not soundPatch then
				soundPatch = CreateSound(ply, "ambient/fire/mtov_flame2.wav")
				if soundPatch then soundPatch:PlayEx(0.24, 135) loopSounds[ply] = soundPatch end
			elseif not shouldPlay and soundPatch then
				soundPatch:FadeOut(0.15)
				loopSounds[ply] = nil
			end
		end
		for ply, soundPatch in pairs(loopSounds) do
			if not IsValid(ply) then if soundPatch then soundPatch:Stop() end loopSounds[ply] = nil end
		end
	end)

	local function bar(x, y, w, label, value, maximumValue, color)
		local fraction = math.Clamp(value / math.max(1, maximumValue), 0, 1)
		draw.SimpleText(label, "MB.Tiny", x, y, MilBase.UI.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(math.ceil(value) .. " / " .. math.ceil(maximumValue), "MB.Tiny", x + w, y, MilBase.UI.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		MilBase.DrawBar(x, y + 18, w, 7, fraction, color)
	end

	hook.Add("HUDPaint", "MilBase.JetpackHUD", function()
		local ply = LocalPlayer()
		if not MilBase.IsJetpackEquipped(ply) or not ply:Alive() or MilBase.InEventView() then return end
		local c = cfg()
		local ui = MilBase.UI
		local scale = math.Clamp(ScrH() / 1080, 0.75, 1.15)
		local w, h = 400 * scale, 188 * scale
		local x, y = ScrW() - w - 28 * scale, ScrH() - h - 34 * scale
		MilBase.DrawPanelBF2(x, y, w, h, { color = ui.panel, accent = ui.accent, outlineColor = ui.outline, cut = 10 * scale })
		draw.SimpleText("JETPACK", "MB.Tab", x + 18 * scale, y + 13 * scale, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(ply:GetNWString("mb_jetpack_state", "STANDBY"), "MB.Small", x + w - 18 * scale, y + 18 * scale, ui.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		bar(x + 18 * scale, y + 49 * scale, w - 36 * scale, "FUEL", ply:GetNWFloat("mb_jetpack_fuel", 0), c.FuelMax or 100, ui.accent)
		bar(x + 18 * scale, y + 84 * scale, w - 36 * scale, "HEAT", ply:GetNWFloat("mb_jetpack_heat", 0), c.HeatMax or 100, ui.warn)
		if c.IntegrityEnabled ~= false then bar(x + 18 * scale, y + 119 * scale, w - 36 * scale, "INTEGRITY", ply:GetNWFloat("mb_jetpack_integrity", 0), c.IntegrityMax or 100, ui.ok) end
		local boost = math.max(0, ply:GetNWFloat("mb_jetpack_boost_cd", 0) - CurTime())
		local vertical = math.Round(ply:GetVelocity().z)
		draw.SimpleText("VERT " .. vertical .. "  •  BOOST " .. (boost > 0 and math.ceil(boost) .. "s" or "READY"), "MB.Tiny", x + 18 * scale, y + h - 18 * scale, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("G  SYSTEMS", "MB.Tiny", x + w - 18 * scale, y + h - 18 * scale, ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		if ply:GetNWBool("mb_jetpack_overheated", false) then
			draw.SimpleText("THERMAL SHUTDOWN", "MB.Big", ScrW() * 0.5, ScrH() * 0.29, ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		elseif ply:GetNWFloat("mb_jetpack_fuel", 0) <= 15 then
			draw.SimpleText("FUEL RESERVES LOW", "MB.Big", ScrW() * 0.5, ScrH() * 0.29, ui.warn, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local progress = ply:GetNWFloat("mb_jetpack_repair_progress", 0)
		if progress > 0 then
			local pw, ph = 330 * scale, 32 * scale
			local px, py = ScrW() * 0.5 - pw * 0.5, ScrH() * 0.66
			MilBase.DrawPanelBF2(px, py, pw, ph, { cut = 7 * scale })
			MilBase.DrawBar(px + 6 * scale, py + ph - 9 * scale, pw - 12 * scale, 5 * scale, progress, ui.accent)
			draw.SimpleText(ply:GetNWString("mb_jetpack_repair_action", "REPAIRING"), "MB.Tiny", ScrW() * 0.5, py + 11 * scale, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end)
end

-- Predicted thrust movement. The server remains authoritative for fuel, heat,
-- cooldowns and activation, while both realms perform the same velocity work.
hook.Add("SetupMove", "MilBase.JetpackMovement", function(ply, mv)
	if not MilBase.IsJetpackActive(ply) then
		if SERVER and MilBase.IsJetpackEquipped(ply) then
			ply.mb_jetpackThrusting = false
			ply.mb_jetpackDirectional = false
			setThrustNetwork(ply, false)
		end
		return
	end
	if ply:InVehicle() or not ply:Alive() then return end
	local c = cfg()
	if c.DisableInZeroG ~= false and ply:GetNWBool("mb_zerog", false) then return end

	local dt = engine.TickInterval()
	local buttons = mv:GetButtons()
	local jump = bit.band(buttons, IN_JUMP) ~= 0
	local duck = bit.band(buttons, IN_DUCK) ~= 0
	local emergency = ply:GetNWBool("mb_jetpack_emergency", false)
	local hover = ply:GetNWBool("mb_jetpack_hover", false)
	local forwardMove, sideMove = mv:GetForwardSpeed(), mv:GetSideSpeed()
	local directional = math.abs(forwardMove) > 5 or math.abs(sideMove) > 5

	local moveAngles = mv:GetMoveAngles()
	moveAngles.p = 0
	moveAngles.r = 0
	local wish = moveAngles:Forward() * forwardMove + moveAngles:Right() * sideMove
	wish.z = 0
	if wish:LengthSqr() > 1 then wish:Normalize() end

	local velocity = mv:GetVelocity()
	local targetHorizontal = wish * (c.FlightSpeed or 300)
	local accel = (c.HorizontalAcceleration or 680) * dt
	velocity.x = math.Approach(velocity.x, targetHorizontal.x, accel)
	velocity.y = math.Approach(velocity.y, targetHorizontal.y, accel)

	local verticalAccel = (c.VerticalAcceleration or 760) * dt
	if emergency then
		velocity.z = math.Approach(velocity.z, -(c.EmergencyDescentSpeed or 115), verticalAccel)
	elseif jump then
		local target = c.RiseSpeed or 265
		if ply:OnGround() then target = math.max(target, c.GroundLaunchSpeed or 185) end
		velocity.z = math.Approach(velocity.z, target, verticalAccel)
	elseif duck then
		velocity.z = math.Approach(velocity.z, -(c.DescendSpeed or 235), verticalAccel)
	elseif hover then
		velocity.z = math.Approach(velocity.z, 0, (c.HoverDamping or 8) * verticalAccel)
	end

	local horizontal = Vector(velocity.x, velocity.y, 0)
	local maxHorizontal = c.MaximumHorizontalSpeed or 520
	if horizontal:Length() > maxHorizontal then
		horizontal:Normalize()
		horizontal = horizontal * maxHorizontal
		velocity.x, velocity.y = horizontal.x, horizontal.y
	end
	velocity.z = math.Clamp(velocity.z, -(c.MaximumFallSpeed or 620), c.MaximumRiseSpeed or 330)
	mv:SetVelocity(velocity)
	mv:SetMaxSpeed(math.max(mv:GetMaxSpeed(), c.FlightSpeed or 300))
	mv:SetMaxClientSpeed(math.max(mv:GetMaxClientSpeed(), c.FlightSpeed or 300))

	if SERVER then
		ply.mb_jetpackThrusting = jump or emergency
		ply.mb_jetpackDirectional = directional
		setThrustNetwork(ply, jump or hover or emergency or ply:GetNWFloat("mb_jetpack_boost_until", 0) > CurTime())
		if ply:GetNWFloat("mb_jetpack_boost_until", 0) <= CurTime() and ply:GetNWString("mb_jetpack_state", "") == "BOOST" then
			ply:SetNWString("mb_jetpack_state", hover and "HOVER" or "IGNITED")
		end
	end
end)
