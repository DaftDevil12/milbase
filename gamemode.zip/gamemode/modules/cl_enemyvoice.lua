--[[
	Event-enemy voice modulator (client).

	Enemy classes can set `voice = "<profile id>"` (profiles live in
	config/sh_eventenemies.lua) to give their players a radio/droid vocoder:
	everyone in earshot hears an on-click when they key up, an optional static
	bed ducked under their speech, and an off-click when they release - like a
	B1 battle droid's comlink chatter.

	GMod Lua can't touch the actual mic stream, so this layers effect sounds
	around the voice instead; droid profiles use pitched-up clicks. A profile
	can additionally set `dsp = <preset>` to run incoming voice through an
	engine DSP preset (the dsp_voice cvar) while the enemy transmits - that
	distorts the real voice, though it can't pitch-shift it.

	Optional on both ends:
	  speakers  - /voicefx toggles their own modulator (server command)
	  listeners - mb_enemy_voicefx 0 turns the overlay off entirely

	Testing:
	  mb_voicefx_test [profile] [seconds]  - preview a profile on yourself
	  For the real thing: TEST SELF in the class editor, voice_loopback 1
	  in console, then talk - you'll hear your own voice plus the FX.
]]

local cvHear = CreateClientConVar("mb_enemy_voicefx", "1", true, false,
	"Hear event-enemy voice modulators (0 = off)", 0, 1)

local active = {} -- speaker -> { loop = CSoundPatch, profile = table }

local function pick(sounds)
	if isstring(sounds) then return sounds ~= "" and sounds or nil end
	if istable(sounds) and #sounds > 0 then return sounds[math.random(#sounds)] end
end

local function pitchOf(profile)
	local p = profile.pitch
	if istable(p) then return math.random(p[1] or 100, p[2] or p[1] or 100) end
	return tonumber(p) or 100
end

local function click(ply, sounds, profile)
	local snd = pick(sounds)
	if snd then ply:EmitSound(snd, 70, pitchOf(profile), profile.volume or 0.6, CHAN_STATIC) end
end

-- Experimental: run incoming voice through an engine DSP preset (dsp_voice)
-- while a modulated enemy transmits. Refcounted so overlapping speakers
-- don't fight; restored to 0 when the last one stops.
local dspCount = 0

local function setVoiceDSP(n)
	local cv = GetConVar("dsp_voice")
	if cv then cv:SetInt(n) end
end

local function grabDSP(fx)
	local preset = math.floor(tonumber(fx.profile.dsp) or 0)
	if preset <= 0 then return end
	fx.dsp = preset
	dspCount = dspCount + 1
	setVoiceDSP(preset)
end

local function releaseDSP(fx)
	if not fx.dsp then return end
	fx.dsp = nil
	dspCount = math.max(0, dspCount - 1)
	if dspCount == 0 then setVoiceDSP(0) end
end

local function stopFX(ply, withClick)
	local fx = active[ply]
	if not fx then return end
	active[ply] = nil
	releaseDSP(fx)
	if fx.loop then fx.loop:FadeOut(0.15) end
	if withClick and IsValid(ply) then click(ply, fx.profile.stop, fx.profile) end
end

hook.Add("PlayerStartVoice", "MilBase.EnemyVoiceFX", function(ply)
	if not cvHear:GetBool() or not IsValid(ply) then return end
	local profile = MilBase.EventEnemyVoiceProfile and MilBase.EventEnemyVoiceProfile(ply)
	if not profile then return end

	stopFX(ply, false) -- re-key without a stray off-click
	click(ply, profile.start, profile)

	local fx = { profile = profile }
	local loop = pick(profile.loop)
	if loop then
		fx.loop = CreateSound(ply, loop)
		fx.loop:PlayEx(0, pitchOf(profile)) -- Think ramps the volume in
	end
	grabDSP(fx)
	active[ply] = fx
end)

hook.Add("PlayerEndVoice", "MilBase.EnemyVoiceFX", function(ply)
	stopFX(ply, true)
end)

--------------------------------------------------------------------------
-- Self-test: mb_voicefx_test [profile] [seconds]
-- Previews a profile on your own player - no event-enemy role or mic
-- needed. Fakes the voice level so the static bed pulses like speech.
--------------------------------------------------------------------------

local testFX

local function stopTest(withClick)
	if not testFX then return end
	local fx = testFX
	testFX = nil
	timer.Remove("MilBase.EnemyVoiceFXTest")
	releaseDSP(fx)
	if fx.loop then fx.loop:FadeOut(0.15) end
	local lp = LocalPlayer()
	if withClick and IsValid(lp) then click(lp, fx.profile.stop, fx.profile) end
end

concommand.Add("mb_voicefx_test", function(_, _, args)
	local profiles = MilBase.EventEnemyVoiceProfiles or {}
	local id = string.lower(string.Trim(args[1] or "droid"))
	local profile = profiles[id]
	if not profile then
		local ids = {}
		for pid in pairs(profiles) do ids[#ids + 1] = pid end
		table.sort(ids)
		print("[MilBase] Unknown voice profile '" .. id .. "'. Available: "
			.. (#ids > 0 and table.concat(ids, ", ") or "(none configured)"))
		return
	end

	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	stopTest(false)

	local dur = math.Clamp(tonumber(args[2]) or 3, 1, 15)
	click(lp, profile.start, profile)
	testFX = { profile = profile }
	local loop = pick(profile.loop)
	if loop then
		testFX.loop = CreateSound(lp, loop)
		testFX.loop:PlayEx(0, pitchOf(profile))
	end
	grabDSP(testFX) -- with voice_loopback 1 you'll hear it on your own voice
	print("[MilBase] Voice FX test: " .. id .. " for " .. dur .. "s "
		.. "(key-up click" .. (loop and " + static bed" or "") .. " + key-off click)")
	timer.Create("MilBase.EnemyVoiceFXTest", dur, 1, function() stopTest(true) end)
end, nil, "Preview an event-enemy voice modulator profile on yourself")

-- Duck the static bed with the speaker's live voice level, and kill the FX
-- if the speaker reverts, toggles off, or disconnects mid-transmission.
hook.Add("Think", "MilBase.EnemyVoiceFX", function()
	for ply, fx in pairs(active) do
		if not IsValid(ply)
		or not (MilBase.EventEnemyVoiceProfile and MilBase.EventEnemyVoiceProfile(ply)) then
			releaseDSP(fx)
			if fx.loop then fx.loop:Stop() end
			active[ply] = nil
		elseif fx.loop then
			local vol = (fx.profile.loopVolume or 0.3) * (0.4 + ply:VoiceVolume() * 0.6)
			fx.loop:ChangeVolume(vol, 0.05)
		end
	end

	-- Pulse the test bed as if someone were talking.
	if testFX and testFX.loop then
		local fake = math.abs(math.sin(CurTime() * 5))
		testFX.loop:ChangeVolume((testFX.profile.loopVolume or 0.3) * (0.4 + fake * 0.6), 0.05)
	end
end)
