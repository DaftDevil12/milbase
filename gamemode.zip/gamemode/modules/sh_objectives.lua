--[[
	Event objectives, world markers & announcements.

	The game master places objective markers (from the Zeus context menu
	or /objective) that every targeted player sees on their HUD, and sends
	center-screen announcements (/announce). Cleared with /eventclear.
]]

-- Objective/marker types: icon glyph + color.
MilBase.ObjectiveTypes = {
	attack     = { name = "Attack",     color = Color(215, 80, 70) },
	defend     = { name = "Defend",     color = Color(90, 150, 220) },
	hack       = { name = "Hack",       color = Color(255, 198, 60) },
	repair     = { name = "Repair",     color = Color(120, 200, 140) },
	intel      = { name = "Intel",      color = Color(120, 210, 235) },
	extraction = { name = "Extraction", color = Color(180, 120, 220) },
	rally      = { name = "Rally",      color = Color(230, 230, 230) },
	breach     = { name = "Breach",     color = Color(230, 120, 60) },
}
MilBase.ObjectiveOrder = { "attack", "defend", "hack", "repair", "intel", "extraction", "rally", "breach" }

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_Objectives")
	util.AddNetworkString("MilBase_Announce")
	util.AddNetworkString("MilBase_ObjPlace")
	util.AddNetworkString("MilBase_ObjComplete")
	util.AddNetworkString("MilBase_ObjEdit")
	util.AddNetworkString("MilBase_PlayerObjectives")
	util.AddNetworkString("MilBase_PlayerObjComplete")

	MilBase.Objectives = MilBase.Objectives or {}
	local nextObjID = 0

	local function syncPlayerObjectives(ply)
		if not IsValid(ply) then return end
		net.Start("MilBase_PlayerObjectives")
			net.WriteTable(ply.mb_personalObjectives or {})
		net.Send(ply)
	end

	function MilBase.SetPlayerObjective(ply, id, data)
		if not IsValid(ply) or not id or id == "" then return false end
		ply.mb_personalObjectives = ply.mb_personalObjectives or {}

		data = data or {}
		local obj = {
			id = id,
			name = data.name or "Objective",
			desc = data.desc or "",
			otype = MilBase.ObjectiveTypes[data.otype] and data.otype or "rally",
			faction = "",
			pos = isvector(data.pos) and data.pos or nil,
			armorID = data.armorID,
			started = CurTime(),
		}

		local old = ply.mb_personalObjectives[id]
		local changed = not old
			or old.name ~= obj.name
			or old.desc ~= obj.desc
			or old.otype ~= obj.otype
			or old.armorID ~= obj.armorID
			or tostring(old.pos or "") ~= tostring(obj.pos or "")

		ply.mb_personalObjectives[id] = obj
		if changed then syncPlayerObjectives(ply) end
		return changed
	end

	function MilBase.ClearPlayerObjective(ply, id, complete)
		if not IsValid(ply) or not ply.mb_personalObjectives or not ply.mb_personalObjectives[id] then return false end
		local old = ply.mb_personalObjectives[id]
		ply.mb_personalObjectives[id] = nil
		syncPlayerObjectives(ply)

		if complete then
			net.Start("MilBase_PlayerObjComplete")
				net.WriteString(old.name or "Objective")
				net.WriteVector(isvector(old.pos) and old.pos or vector_origin)
				net.WriteBool(isvector(old.pos))
			net.Send(ply)
		end
		return true
	end

	function MilBase.HasPlayerObjective(ply, id)
		return IsValid(ply) and ply.mb_personalObjectives and ply.mb_personalObjectives[id] ~= nil
	end

	local function broadcastObjectives()
		net.Start("MilBase_Objectives")
			net.WriteTable(MilBase.Objectives)
		net.Broadcast()
	end

	function MilBase.AddObjective(ply, data)
		nextObjID = nextObjID + 1
		MilBase.Objectives[nextObjID] = {
			id = nextObjID,
			pos = data.pos,
			name = data.name or "Objective",
			otype = MilBase.ObjectiveTypes[data.otype] and data.otype or "attack",
			faction = data.faction or "", -- "" = everyone
		}
		broadcastObjectives()
		return nextObjID
	end

	function MilBase.RemoveObjective(id)
		if MilBase.Objectives[id] then
			MilBase.Objectives[id] = nil
			broadcastObjectives()
		end
	end

	function MilBase.ClearObjectives()
		MilBase.Objectives = {}
		broadcastObjectives()
	end

	-- The nearest objective id to `pos` (within `maxDist`, if given).
	function MilBase.NearestObjective(pos, maxDist)
		local best, bd
		for id, o in pairs(MilBase.Objectives) do
			local d = o.pos:Distance(pos)
			if (not maxDist or d <= maxDist) and (not bd or d < bd) then
				best, bd = id, d
			end
		end
		return best
	end

	-- Mark an objective done: green completion flash + chime at its spot,
	-- then remove the marker. Called by trigger actions or the game master.
	function MilBase.CompleteObjective(id)
		local o = MilBase.Objectives[id]
		if not o then return end

		net.Start("MilBase_ObjComplete")
			net.WriteString(o.name)
			net.WriteVector(o.pos)
			net.WriteString(o.faction)
		net.Broadcast()

		hook.Run("MilBase.ObjectiveCompleted", table.Copy(o), id)
		MilBase.Objectives[id] = nil
		broadcastObjectives()
	end

	-- scope: "all" or a faction id. Sends a center-screen announcement.
	function MilBase.Announce(scope, text, color)
		local targets
		if scope and scope ~= "all" and MilBase.GetFaction(scope) then
			targets = {}
			for _, p in ipairs(player.GetAll()) do
				if p:MBFactionID() == scope then targets[#targets + 1] = p end
			end
		end

		net.Start("MilBase_Announce")
			net.WriteString(text)
			net.WriteColor(color or Color(255, 198, 60))
		if targets then net.Send(targets) else net.Broadcast() end
	end

	-- Game master places a marker from the Zeus context menu.
	net.Receive("MilBase_ObjPlace", function(_, ply)
		if not MilBase.CanRunEvents(ply) or not ply:GetNWBool("mb_eventmode", false) then return end
		local pos = net.ReadVector()
		local name = net.ReadString()
		local otype = net.ReadString()
		local faction = net.ReadString()
		if not isvector(pos) then return end

		MilBase.AddObjective(ply, {
			pos = pos,
			name = name ~= "" and name or nil,
			otype = otype,
			faction = faction,
		})
	end)

	-- Game master completes / removes a single objective by id.
	net.Receive("MilBase_ObjEdit", function(_, ply)
		if not MilBase.CanRunEvents(ply) or not ply:GetNWBool("mb_eventmode", false) then return end
		local id = net.ReadUInt(16)
		if net.ReadBool() then
			MilBase.CompleteObjective(id)
		else
			MilBase.RemoveObjective(id)
		end
	end)

	-- Re-sync objectives when someone joins.
	hook.Add("PlayerInitialSpawn", "MilBase.ObjSync", function(ply)
		timer.Simple(3, function()
			if IsValid(ply) then
				net.Start("MilBase_Objectives")
					net.WriteTable(MilBase.Objectives)
				net.Send(ply)
				syncPlayerObjectives(ply)
			end
		end)
	end)

	hook.Add("PostCleanupMap", "MilBase.ObjClear", function()
		MilBase.Objectives = {}
	end)

	--------------------------------------------------------------------
	-- Commands (event staff)
	--------------------------------------------------------------------

	MilBase.RegisterChatCommand("announce", {
		help = "(Event staff) Center-screen announcement: /announce <message>",
		func = function(ply, args, rawText)
			if not MilBase.CanRunEvents(ply) then
				MilBase.Notify(ply, "You don't have event permission.")
				return
			end
			if rawText == "" then return end
			MilBase.Announce("all", rawText)
			MilBase.ChatMsg(nil, Color(255, 198, 60), "[COMMAND] ", color_white, rawText)
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: objective HUD + announcements
--------------------------------------------------------------------------

MilBase.Objectives = MilBase.Objectives or {}
MilBase.PlayerObjectives = MilBase.PlayerObjectives or {}

net.Receive("MilBase_Objectives", function()
	MilBase.Objectives = net.ReadTable() or {}
end)

net.Receive("MilBase_PlayerObjectives", function()
	MilBase.PlayerObjectives = net.ReadTable() or {}
end)

local announce = { text = "", until_ = 0, born = 0, color = color_white }
local completions = {} -- transient green "objective complete" flashes

-- Palette for the plates: black text on a gold plate with a dark border.
local INK     = Color(18, 15, 8)      -- near-black text
local INK_DIM = Color(74, 62, 28)     -- muted brown (distances)
local GOLD    = Color(255, 201, 71)   -- plate fill
local GREEN   = Color(150, 205, 125)  -- completion plate

net.Receive("MilBase_Announce", function()
	announce.text = net.ReadString()
	announce.color = net.ReadColor()
	announce.born = CurTime()
	announce.until_ = CurTime() + 8
	surface.PlaySound("ambient/alarms/warningbell1.wav")
end)

net.Receive("MilBase_ObjComplete", function()
	completions[#completions + 1] = {
		name = net.ReadString(),
		pos = net.ReadVector(),
		faction = net.ReadString(),
		born = CurTime(),
		until_ = CurTime() + 3.5,
	}
	surface.PlaySound("buttons/button9.wav")
end)

net.Receive("MilBase_PlayerObjComplete", function()
	completions[#completions + 1] = {
		name = net.ReadString(),
		pos = net.ReadVector(),
		faction = "",
		hasPos = net.ReadBool(),
		born = CurTime(),
		until_ = CurTime() + 3.5,
	}
	surface.PlaySound("buttons/button9.wav")
end)

local function visibleTo(lp, obj)
	return obj.faction == "" or obj.faction == lp:MBFactionID()
end

-- A chamfered plate with a colored left strip and black text. Returns its
-- rect so callers can stack things around it.
local function objectivePlate(cx, topY, label, distText, stripColor, alpha, plateColor)
	alpha = alpha or 255

	surface.SetFont("MB.Small")
	local tw, th = surface.GetTextSize(label)
	local dw = 0
	if distText and distText ~= "" then
		surface.SetFont("MB.Tiny")
		dw = surface.GetTextSize(distText) + 10
	end

	local padX, h = 13, 26
	local w = tw + dw + padX * 2 + 4
	local x, y = math.Round(cx - w / 2), math.Round(topY)

	MilBase.DrawPanelBF2(x, y, w, h, {
		color = ColorAlpha(plateColor or GOLD, alpha),
		cut = 6,
		outlineColor = ColorAlpha(INK, alpha),
	})
	-- type-colored accent strip
	surface.SetDrawColor(ColorAlpha(stripColor, alpha))
	surface.DrawRect(x + 4, y + 6, 3, h - 12)

	draw.SimpleText(label, "MB.Small", x + padX + 4, y + h / 2 + 1,
		ColorAlpha(INK, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	if distText and distText ~= "" then
		draw.SimpleText(distText, "MB.Tiny", x + w - 9, y + h / 2 + 1,
			ColorAlpha(INK_DIM, alpha), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	return x, y, w, h
end

hook.Add("HUDPaint", "MilBase.ObjectiveHUD", function()
	if MilBase.InEventView and MilBase.InEventView() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end

	-- World markers (edge-clamped so players always see the direction).
	local cx, cy = ScrW() / 2, ScrH() / 2
	local eyePos, eyeFwd = EyePos(), lp:EyeAngles():Forward()
	local worldObjectives = {}
	for _, obj in pairs(MilBase.Objectives) do
		if visibleTo(lp, obj) and isvector(obj.pos) then worldObjectives[#worldObjectives + 1] = obj end
	end
	for _, obj in pairs(MilBase.PlayerObjectives or {}) do
		if isvector(obj.pos) then worldObjectives[#worldObjectives + 1] = obj end
	end
	for _, obj in ipairs(worldObjectives) do
		local t = MilBase.ObjectiveTypes[obj.otype] or MilBase.ObjectiveTypes.attack
		local pos = obj.pos + Vector(0, 0, 40)
		local scr = pos:ToScreen()
		local dist = math.Round(lp:GetPos():Distance(obj.pos) / 52.5)

		local inFront = eyeFwd:Dot(pos - eyePos) > 0
		local onScreen = inFront and scr.visible and scr.x > 8 and scr.x < ScrW() - 8
			and scr.y > 8 and scr.y < ScrH() - 8
		local x, y = scr.x, scr.y
		if not onScreen then
			-- Clamp to a ring around the screen centre (flip when behind us).
			local dx, dy = scr.x - cx, scr.y - cy
			if not inFront then dx, dy = -dx, -dy end
			local ang = math.atan2(dy, dx)
			x = cx + math.cos(ang) * (ScrW() * 0.42)
			y = cy + math.sin(ang) * (ScrH() * 0.40)
		end

		-- Location pin.
		MilBase.DrawDiamond(x, y, 9, t.color)
		MilBase.DrawDiamond(x, y, 9, INK, true)

		if onScreen then
			objectivePlate(x, y + 14, string.upper(obj.name), dist .. "m", t.color)
		end
	end

	-- Objective briefing panel, top-right (gold plate, black text).
	local list = {}
	for _, obj in pairs(MilBase.Objectives) do
		if visibleTo(lp, obj) then list[#list + 1] = obj end
	end
	for _, obj in pairs(MilBase.PlayerObjectives or {}) do
		obj.personal = true
		list[#list + 1] = obj
	end
	if #list > 0 then
		surface.SetFont("MB.Small")
		local wtext = surface.GetTextSize("OBJECTIVES")
		for _, obj in ipairs(list) do
			local label = string.upper(obj.name)
			if obj.personal then label = "★ " .. label end
			wtext = math.max(wtext, surface.GetTextSize(label) + 20)
		end
		local pad, rowH = 14, 21
		local w = wtext + pad * 2
		local h = 40 + #list * rowH + 6
		local px, py = ScrW() - w - 22, 116

		MilBase.DrawPanelBF2(px, py, w, h, { color = GOLD, cut = 8, outlineColor = INK })
		draw.SimpleText("OBJECTIVES", "MB.Small", px + pad, py + 13, INK, TEXT_ALIGN_LEFT)
		surface.SetDrawColor(INK.r, INK.g, INK.b, 150)
		surface.DrawRect(px + pad, py + 32, w - pad * 2, 1)

		local ry = py + 40
		for _, obj in ipairs(list) do
			local t = MilBase.ObjectiveTypes[obj.otype] or MilBase.ObjectiveTypes.attack
			MilBase.DrawDiamond(px + pad + 5, ry + rowH / 2, 5, t.color)
			MilBase.DrawDiamond(px + pad + 5, ry + rowH / 2, 5, INK, true)
			local label = string.upper(obj.name)
			if obj.personal then label = "★ " .. label end
			draw.SimpleText(label, "MB.Small", px + pad + 16, ry + rowH / 2,
				INK, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			ry = ry + rowH
		end
	end

	-- Completion flashes: a green plate that rises and fades.
	for i = #completions, 1, -1 do
		local c = completions[i]
		if c.until_ < CurTime() then
			table.remove(completions, i)
			continue
		end
		if c.faction ~= "" and c.faction ~= lp:MBFactionID() then continue end

		local age = CurTime() - c.born
		local a = 255
		if age < 0.3 then a = 255 * (age / 0.3)
		elseif c.until_ - CurTime() < 1 then a = 255 * (c.until_ - CurTime()) end

		if c.hasPos == false then
			objectivePlate(ScrW() / 2, ScrH() * 0.28 - age * 12, "COMPLETE  " .. string.upper(c.name),
				nil, INK, a, GREEN)
		else
			local scr = (c.pos + Vector(0, 0, 44)):ToScreen()
			if scr.visible then
				objectivePlate(scr.x, scr.y - age * 12, "COMPLETE  " .. string.upper(c.name),
					nil, INK, a, GREEN)
			end
		end
	end

	-- Center-screen announcement.
	if announce.until_ > CurTime() then
		local age = CurTime() - announce.born
		local a = 255
		if age < 0.4 then a = 255 * (age / 0.4)
		elseif announce.until_ - CurTime() < 1 then a = 255 * (announce.until_ - CurTime()) end

		draw.SimpleTextOutlined(announce.text, "MB.Med", ScrW() / 2, ScrH() * 0.2,
			ColorAlpha(announce.color, a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1,
			ColorAlpha(color_black, a))
	end
end)
