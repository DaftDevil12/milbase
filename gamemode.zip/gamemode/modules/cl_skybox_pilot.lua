if not CLIENT then return end
if not MilBase or not MilBase.Config then return end
if MilBase.SkyboxPilotClientLoaded then return end
MilBase.SkyboxPilotClientLoaded = true

local naval = MilBase.Config.NavalOperations or {}
local NET_START = "MilBase_SkyboxPilot_Start"
local NET_STOP = "MilBase_SkyboxPilot_Stop"
local NET_INPUT = "MilBase_SkyboxPilot_Input"
local NET_EXIT = "MilBase_SkyboxPilot_Exit"
local NET_COMMS = "MilBase_SkyboxPilot_Comms"
local NET_FEEDBACK = "MilBase_SkyboxPilot_Feedback"

local FLAG_FIRE = 1
local FLAG_BOOST = 2
local FLAG_BRAKE = 4
local FLAG_LOCK = 8
local FLAG_CYCLE = 16
local FLAG_ADVANCED = 32
local FLAG_ORDER = 64
local FLAG_CYCLE_FRIENDLY = 128
local FLAG_THREAT = 256
local FLAG_SECONDARY = 512
local FLAG_WING_ORDER = 1024
local FLAG_RETURN_ASSIST = 2048
local FLAG_COLLISION_OFF = 4096

local PILOT_ORDERS = {
	"HAIL / IDENTIFY",
	"FOLLOW MY LEAD",
	"FORM ON MY LEFT",
	"FORM ON MY RIGHT",
	"HOLD POSITION",
	"LEAVE THE AREA",
	"BREAK OFF ATTACK",
	"FINAL WARNING",
	"HEAVE TO / SURRENDER",
}

local WING_ORDERS = {
	"TIGHT FORMATION",
	"WIDE FORMATION",
	"ATTACK MY TARGET",
	"COVER ME",
	"BREAK AND ENGAGE",
	"REGROUP",
	"RETURN TO CARRIER",
	"SPLIT INTO PAIRS",
}

local TARGET_SUBSYSTEMS = { "HULL", "ENGINES", "WEAPONS", "SHIELDS" }
local ASSIST_MODES = { "COMBAT", "CRUISE", "FORMATION" }

local cvComfort = CreateClientConVar("mb_flight_comfort", "1", true, false,
	"Disable camera roll, shake and rapid field-of-view changes during remote flight.")
local cvCameraRoll = CreateClientConVar("mb_flight_camera_roll", "0", true, false,
	"Fraction of ship roll inherited by the remote camera.", 0, 1)
local cvCameraSmooth = CreateClientConVar("mb_flight_camera_smoothing", "8", true, false,
	"Remote camera smoothing strength.", 2, 18)
local cvCameraFOV = CreateClientConVar("mb_flight_fov", "84", true, false,
	"Remote flight field of view.", 70, 105)
local cvBoostFOV = CreateClientConVar("mb_flight_boost_fov", "3", true, false,
	"Extra field of view while boosting.", 0, 12)
local cvDamageShake = CreateClientConVar("mb_flight_damage_shake", "0.35", true, false,
	"Damage camera shake strength.", 0, 1)
local cvMouseSensitivity = CreateClientConVar("mb_flight_mouse_sensitivity", "1", true, false,
	"Remote mouse-aim sensitivity multiplier.", 0.25, 2.5)
local cvInvertY = CreateClientConVar("mb_flight_invert_y", "0", true, false,
	"Invert vertical remote-flight mouse input.")
local cvHUDScale = CreateClientConVar("mb_flight_hud_scale", "1", true, false,
	"Remote flight HUD scale.", 0.7, 1.35)
local cvMarkerScale = CreateClientConVar("mb_flight_marker_scale", "1", true, false,
	"Remote contact marker scale.", 0.65, 1.8)
local cvRadarEnabled = CreateClientConVar("mb_flight_radar", "1", true, false,
	"Show the remote-flight tactical radar.")
local cvRadarRange = CreateClientConVar("mb_flight_radar_range", "6500", true, false,
	"Remote-flight tactical radar range.", 1500, 12000)
local cvTargetTrails = CreateClientConVar("mb_flight_target_trails", "1", true, false,
	"Show short motion trails on marked contacts.")
local cvColourBlind = CreateClientConVar("mb_flight_colourblind", "0", true, false,
	"Use colour-blind-friendly contact colours.")
local cvCollisionAssist = CreateClientConVar("mb_flight_collision_assist", "1", true, false,
	"Allow the server to gently steer away from nearby ships and solid geometry.")

local state = {
	ship = nil,
	squadron = "",
	label = "STARFIGHTER",
	aim = Angle(0, 0, 0),
	predictedAngle = Angle(0, 0, 0),
	cameraAngle = Angle(0, 0, 0),
	cameraOrigin = nil,
	throttle = 0,
	cursorYaw = 0,
	cursorPitch = 0,
	cameraZoom = 1,
	advanced = false,
	cockpit = false,
	lookBehind = false,
	roll = 0,
	nextSend = 0,
	exitHeld = false,
	lockHeld = false,
	cycleHeld = false,
	orderHeld = false,
	transmitHeld = false,
	modeHeld = false,
	viewHeld = false,
	lockPulse = false,
	cyclePulse = false,
	transmitPulse = false,
	orderIndex = 1,
	radio = nil,
	cameraMode = 1,
	freeLook = false,
	freeLookYaw = 0,
	freeLookPitch = 0,
	freeLookHeld = false,
	assistMode = 1,
	returnAssist = false,
	targetSubsystem = 1,
	wingOrderIndex = 1,
	wingHeld = false,
	friendlyHeld = false,
	threatHeld = false,
	secondaryHeld = false,
	subsystemHeld = false,
	assistHeld = false,
	returnHeld = false,
	settingsHeld = false,
	radialMode = nil,
	radialHeld = false,
	radialX = 0,
	radialY = -80,
	radialSelection = 1,
	uiOpen = false,
	hitMarkerUntil = 0,
	hitKind = "",
	killUntil = 0,
	killLabel = "",
	nextWarningSound = 0,
	lastIncoming = false,
	lastOverheated = false,
	lastBoosting = false,
	contactCache = {},
	contactCacheAt = 0,
	trailPositions = {},
	engineSound = nil,
	hintUntil = 0,
}

-- A CalcView origin placed directly inside a Source 3D skybox causes the
-- engine to render that same 3D skybox around the camera a second time.
-- Keep the physical remote camera in the skybox volume, but temporarily
-- disable only the engine's projected 3D skybox pass. The ordinary 2D
-- sky material and all live entities around the fighter still render.
local skyboxRenderState = {
	forced = false,
	previous = nil,
}

local function setNestedSkyboxSuppressed(active)
	local enabled = naval.SkyboxPilotSuppressNested3DSkybox ~= false
	local cvar = GetConVar("r_3dsky")
	if not cvar then return end

	if active and enabled then
		if not skyboxRenderState.forced then
			skyboxRenderState.previous = cvar:GetString()
			skyboxRenderState.forced = true
		end
		if cvar:GetBool() then RunConsoleCommand("r_3dsky", "0") end
		return
	end

	if not skyboxRenderState.forced then return end
	local previous = skyboxRenderState.previous
	skyboxRenderState.forced = false
	skyboxRenderState.previous = nil
	if previous ~= nil and cvar:GetString() ~= previous then
		RunConsoleCommand("r_3dsky", previous)
	end
end

local stopEngineSound

local function profileFor(id)
	local profiles = naval.SkyboxPilotProfiles or {}
	local source = profiles[id] or profiles.default or {}
	return {
		maximumSpeed = math.max(20, tonumber(source.maximumSpeed) or 195),
		steering = math.max(10, tonumber(source.steering) or 54),
		bank = math.max(0, tonumber(source.bank) or 15),
		manualBank = math.max(0, tonumber(source.manualBank) or 42),
		cameraDistance = math.max(0.45, tonumber(source.cameraDistance) or 1),
		cameraHeight = math.max(0.35, tonumber(source.cameraHeight) or 1),
		optimalTurnMin = math.Clamp(tonumber(source.optimalTurnMin) or 0.36, 0.05, 0.9),
		optimalTurnMax = math.Clamp(tonumber(source.optimalTurnMax) or 0.78, 0.1, 1.2),
	}
end

local function activeShip()
	local ply = LocalPlayer()
	if not IsValid(ply) then return nil end
	local ship = ply:GetNW2Entity("MBSkyboxPilotShip")
	if IsValid(ship) and ship:GetClass() == "mb_galaxy_ship" then
		state.ship = ship
		return ship
	end
	state.ship = nil
	return nil
end

local function resetState(ship)
	local angle = IsValid(ship) and ship:GetAngles() or EyeAngles()
	angle = Angle(angle.p, angle.y, 0)
	state.aim = Angle(angle.p, angle.y, 0)
	state.predictedAngle = Angle(angle.p, angle.y, 0)
	state.cameraAngle = Angle(angle.p, angle.y, 0)
	state.cameraOrigin = nil
	state.cursorYaw = 0
	state.cursorPitch = 0
	state.cameraZoom = 1
	state.advanced = false
	state.cockpit = false
	state.cameraMode = 1
	state.lookBehind = false
	state.freeLook = false
	state.freeLookYaw = 0
	state.freeLookPitch = 0
	state.assistMode = 1
	state.returnAssist = false
	state.targetSubsystem = 1
	state.wingOrderIndex = 1
	state.radialMode = nil
	state.radialHeld = false
	state.radialX = 0
	state.radialY = -80
	state.radialSelection = 1
	state.hitMarkerUntil = 0
	state.killUntil = 0
	state.roll = 0
	state.nextSend = 0
	state.exitHeld = false
	state.lockHeld = false
	state.cycleHeld = false
	state.orderHeld = false
	state.transmitHeld = false
	state.modeHeld = false
	state.viewHeld = false
	state.freeLookHeld = false
	state.wingHeld = false
	state.friendlyHeld = false
	state.threatHeld = false
	state.secondaryHeld = false
	state.subsystemHeld = false
	state.assistHeld = false
	state.returnHeld = false
	state.settingsHeld = false
	state.lockPulse = false
	state.cyclePulse = false
	state.friendlyPulse = false
	state.threatPulse = false
	state.secondaryPulse = false
	state.transmitPulse = false
	state.wingPulse = false
	state.orderIndex = 1
	state.radio = nil
	state.hintUntil = RealTime()
		+ math.max(3, tonumber(naval.SkyboxPilotControlHintsDuration) or 14)
end

net.Receive(NET_START, function()
	local ship = net.ReadEntity()
	state.ship = IsValid(ship) and ship or nil
	state.squadron = net.ReadString()
	state.throttle = math.Clamp(net.ReadFloat(), 0, 1)
	state.label = net.ReadString()
	resetState(ship)
	setNestedSkyboxSuppressed(IsValid(ship))
end)

net.Receive(NET_STOP, function()
	local reason = net.ReadString()
	setNestedSkyboxSuppressed(false)
	stopEngineSound()
	state.ship = nil
	state.squadron = ""
	state.cameraOrigin = nil
	state.exitHeld = false
	if reason ~= "" and MilBase.Notify then MilBase.Notify(reason, "ok") end
end)

net.Receive(NET_COMMS, function()
	local source = net.ReadEntity()
	local title = net.ReadString()
	local body = net.ReadString()
	local tone = net.ReadString()
	local duration = net.ReadFloat()
	state.radio = {
		source = IsValid(source) and source or nil,
		title = title,
		body = body,
		tone = tone,
		untilTime = RealTime() + math.Clamp(duration, 2, 12),
	}
	if chat and chat.AddText then
		chat.AddText(Color(105, 185, 255), "[FLIGHT COMMS] ", Color(235, 240, 250),
			title .. (body ~= "" and " — " .. body or ""))
	end
end)

net.Receive(NET_FEEDBACK, function()
	local kind = net.ReadString()
	local label = net.ReadString()
	if kind == "kill" then
		state.killUntil = RealTime() + 2.8
		state.killLabel = label ~= "" and label or "TARGET DESTROYED"
		surface.PlaySound("buttons/button15.wav")
	elseif kind == "missile" then
		state.hitMarkerUntil = RealTime() + 0.32
		state.hitKind = "MISSILE"
		surface.PlaySound("weapons/stinger_fire1.wav")
	elseif kind == "shield" then
		state.hitMarkerUntil = RealTime() + 0.2
		state.hitKind = "SHIELD"
		surface.PlaySound("buttons/blip1.wav")
	elseif kind == "hull" then
		state.hitMarkerUntil = RealTime() + 0.22
		state.hitKind = "HULL"
		surface.PlaySound("physics/metal/metal_solid_impact_bullet2.wav")
	elseif kind == "denied" then
		state.radio = {
			title = "FLIGHT COMPUTER",
			body = label,
			tone = "warning",
			untilTime = RealTime() + 3.5,
		}
		surface.PlaySound("buttons/button10.wav")
	end
end)

local function buttonDown(buttons, flag)
	return bit.band(buttons, flag) ~= 0
end

local function approachPilotPrediction(ship, frameTime)
	local profile = profileFor(state.squadron)
	local actual = ship:GetAngles()
	actual = Angle(actual.p, actual.y, actual.r)
	if not isangle(state.predictedAngle) then state.predictedAngle = actual end
	local correction = math.Clamp(frameTime * 2.2, 0, 0.18)
	state.predictedAngle.p = math.ApproachAngle(state.predictedAngle.p,
		actual.p, math.max(0.4, math.abs(math.AngleDifference(actual.p,
			state.predictedAngle.p)) * correction))
	state.predictedAngle.y = math.ApproachAngle(state.predictedAngle.y,
		actual.y, math.max(0.4, math.abs(math.AngleDifference(actual.y,
			state.predictedAngle.y)) * correction))

	local turn = profile.steering * frameTime
	state.predictedAngle.p = math.ApproachAngle(state.predictedAngle.p,
		state.aim.p, turn * 0.68)
	state.predictedAngle.y = math.ApproachAngle(state.predictedAngle.y,
		state.aim.y, turn)
	local autoRoll = state.advanced and 0
		or math.Clamp(-math.AngleDifference(state.aim.y, state.predictedAngle.y) * 0.22,
			-profile.bank, profile.bank)
	local rollTarget = state.advanced and state.roll * profile.manualBank
		or math.Clamp(autoRoll + state.roll * profile.manualBank,
			-profile.manualBank, profile.manualBank)
	state.predictedAngle.r = math.ApproachAngle(state.predictedAngle.r,
		rollTarget, math.max(25, profile.steering * 1.4) * frameTime)
end

stopEngineSound = function()
	if state.engineSound then
		state.engineSound:Stop()
		state.engineSound = nil
	end
end

hook.Add("Think", "MilBase.SkyboxPilot.NestedSkyboxGuard", function()
	local ship = activeShip()
	local linked = IsValid(ship)
	if linked then
		setNestedSkyboxSuppressed(true)
		if not state.engineSound and IsValid(LocalPlayer()) then
			state.engineSound = CreateSound(LocalPlayer(),
				"vehicles/airboat/fan_blade_fullthrottle_loop1.wav")
			if state.engineSound then state.engineSound:PlayEx(0.08, 62) end
		end
		if state.engineSound then
			local fraction = math.Clamp(ship:GetMotionSpeed()
				/ math.max(profileFor(state.squadron).maximumSpeed, 1), 0, 1.4)
			state.engineSound:ChangePitch(math.Clamp(62 + fraction * 42, 55, 125), 0.12)
			state.engineSound:ChangeVolume(math.Clamp(0.06 + fraction * 0.12, 0.04, 0.2), 0.12)
		end
		local incoming = ship:GetNW2Bool("MBSkyboxPilotIncomingLock", false)
		local overheated = ship:GetNW2Bool("MBSkyboxPilotOverheated", false)
		local boosting = ship:GetNW2Bool("MBSkyboxPilotBoost", false)
		if incoming and not state.lastIncoming and RealTime() >= state.nextWarningSound then
			state.nextWarningSound = RealTime() + 1.5
			surface.PlaySound("buttons/button17.wav")
		end
		if overheated and not state.lastOverheated then
			surface.PlaySound("buttons/button10.wav")
		end
		if boosting and not state.lastBoosting then
			surface.PlaySound("vehicles/airboat/pontoon_impact_hard1.wav")
		end
		state.lastIncoming = incoming
		state.lastOverheated = overheated
		state.lastBoosting = boosting
	elseif skyboxRenderState.forced then
		setNestedSkyboxSuppressed(false)
		stopEngineSound()
	end
end)

hook.Add("ShutDown", "MilBase.SkyboxPilot.Restore3DSkybox", function()
	setNestedSkyboxSuppressed(false)
	stopEngineSound()
end)

local function beginRadial(mode)
	state.radialMode = mode
	state.radialHeld = true
	state.radialX = 0
	state.radialY = -90
	state.radialSelection = mode == "wing" and state.wingOrderIndex or state.orderIndex
end

local function updateRadial(mouseX, mouseY)
	state.radialX = math.Clamp(state.radialX + mouseX * 0.8, -130, 130)
	state.radialY = math.Clamp(state.radialY + mouseY * 0.8, -130, 130)
	local count = state.radialMode == "wing" and #WING_ORDERS or #PILOT_ORDERS
	local angle = math.atan2(state.radialY, state.radialX)
	local normalised = (angle + math.pi * 0.5 + math.pi * 2) % (math.pi * 2)
	state.radialSelection = math.Clamp(math.floor(normalised / (math.pi * 2) * count) + 1, 1, count)
end

local function finishRadial()
	if state.radialMode == "wing" then
		state.wingOrderIndex = state.radialSelection
		state.wingPulse = true
	else
		state.orderIndex = state.radialSelection
		state.transmitPulse = true
	end
	state.radialMode = nil
	state.radialHeld = false
end

local function addCheck(panel, label, convar)
	local check = vgui.Create("DCheckBoxLabel", panel)
	check:Dock(TOP)
	check:DockMargin(10, 5, 10, 0)
	check:SetText(label)
	check:SetConVar(convar)
	check:SizeToContents()
	return check
end

local function addSlider(panel, label, convar, minimum, maximum, decimals)
	local slider = vgui.Create("DNumSlider", panel)
	slider:Dock(TOP)
	slider:DockMargin(8, 2, 8, 0)
	slider:SetText(label)
	slider:SetMin(minimum)
	slider:SetMax(maximum)
	slider:SetDecimals(decimals or 2)
	slider:SetConVar(convar)
	return slider
end

local function openPilotSettings()
	if IsValid(state.settingsFrame) then
		state.settingsFrame:MakePopup()
		return
	end
	state.uiOpen = true
	local frame = vgui.Create("DFrame")
	state.settingsFrame = frame
	frame:SetSize(math.min(560, ScrW() - 40), math.min(720, ScrH() - 40))
	frame:Center()
	frame:SetTitle("Remote Flight Comfort & HUD")
	frame:SetSizable(true)
	frame:MakePopup()
	frame.OnClose = function()
		state.uiOpen = false
		state.settingsFrame = nil
	end
	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:Dock(FILL)
	addCheck(scroll, "Comfort mode (no camera roll, minimal shake and fixed FOV)", "mb_flight_comfort")
	addSlider(scroll, "Camera roll inheritance", "mb_flight_camera_roll", 0, 1, 2)
	addSlider(scroll, "Camera smoothing", "mb_flight_camera_smoothing", 2, 18, 1)
	addSlider(scroll, "Field of view", "mb_flight_fov", 70, 105, 0)
	addSlider(scroll, "Boost FOV change", "mb_flight_boost_fov", 0, 12, 1)
	addSlider(scroll, "Damage camera shake", "mb_flight_damage_shake", 0, 1, 2)
	addSlider(scroll, "Mouse sensitivity", "mb_flight_mouse_sensitivity", 0.25, 2.5, 2)
	addCheck(scroll, "Invert vertical aim", "mb_flight_invert_y")
	addSlider(scroll, "HUD scale", "mb_flight_hud_scale", 0.7, 1.35, 2)
	addSlider(scroll, "Contact marker scale", "mb_flight_marker_scale", 0.65, 1.8, 2)
	addCheck(scroll, "Tactical radar", "mb_flight_radar")
	addSlider(scroll, "Radar range", "mb_flight_radar_range", 1500, 12000, 0)
	addCheck(scroll, "Target motion trails", "mb_flight_target_trails")
	addCheck(scroll, "Colour-blind-friendly contact palette", "mb_flight_colourblind")
	addCheck(scroll, "Collision avoidance assist", "mb_flight_collision_assist")
	local reset = vgui.Create("DButton", scroll)
	reset:Dock(TOP)
	reset:DockMargin(10, 14, 10, 10)
	reset:SetTall(34)
	reset:SetText("Restore recommended comfort defaults")
	reset.DoClick = function()
		RunConsoleCommand("mb_flight_comfort", "1")
		RunConsoleCommand("mb_flight_camera_roll", "0")
		RunConsoleCommand("mb_flight_camera_smoothing", "8")
		RunConsoleCommand("mb_flight_fov", "84")
		RunConsoleCommand("mb_flight_boost_fov", "3")
		RunConsoleCommand("mb_flight_damage_shake", "0.35")
		RunConsoleCommand("mb_flight_mouse_sensitivity", "1")
		RunConsoleCommand("mb_flight_invert_y", "0")
	end
end
concommand.Add("mb_flight_settings", openPilotSettings)

hook.Add("CreateMove", "MilBase.SkyboxPilot.CreateMove", function(cmd)
	local ship = activeShip()
	if not IsValid(ship) then return end
	local frameTime = math.Clamp(RealFrameTime(), 0.001, 0.05)
	local sensitivity = math.max(0.001,
		(tonumber(naval.SkyboxPilotMouseSensitivity) or 0.028)
		* cvMouseSensitivity:GetFloat())
	local mouseX = cmd:GetMouseX()
	local mouseY = cmd:GetMouseY() * (cvInvertY:GetBool() and -1 or 1)
	local buttons = cmd:GetButtons()

	local settingsDown = input.IsKeyDown(KEY_P)
	if settingsDown and not state.settingsHeld then openPilotSettings() end
	state.settingsHeld = settingsDown

	local contactRadial = input.IsKeyDown(KEY_X)
	local wingRadial = input.IsKeyDown(KEY_V)
	if not state.radialHeld and (contactRadial or wingRadial) then
		beginRadial(wingRadial and "wing" or "contact")
	elseif state.radialHeld and not contactRadial and not wingRadial then
		finishRadial()
	end
	if state.radialHeld then updateRadial(mouseX, mouseY) end

	local modeDown = input.IsKeyDown(KEY_M)
	if modeDown and not state.modeHeld then
		state.advanced = not state.advanced
		state.cursorYaw = 0
		state.cursorPitch = 0
		state.aim = Angle(state.predictedAngle.p, state.predictedAngle.y, 0)
		state.hintUntil = RealTime() + 4
	end
	state.modeHeld = modeDown

	local freeLookDown = input.IsKeyDown(KEY_LALT)
	state.freeLook = freeLookDown
	if freeLookDown and not state.radialHeld and not state.uiOpen then
		state.freeLookYaw = math.Clamp(state.freeLookYaw - mouseX * sensitivity * 1.8, -150, 150)
		state.freeLookPitch = math.Clamp(state.freeLookPitch + mouseY * sensitivity * 1.8, -75, 75)
	elseif not freeLookDown then
		local recenter = math.Clamp(frameTime * 6, 0, 1)
		state.freeLookYaw = Lerp(recenter, state.freeLookYaw, 0)
		state.freeLookPitch = Lerp(recenter, state.freeLookPitch, 0)
	end

	if not state.freeLook and not state.radialHeld and not state.uiOpen then
		if state.advanced then
			state.aim.y = math.NormalizeAngle(state.aim.y - mouseX * sensitivity * 1.2)
			state.aim.p = math.Clamp(state.aim.p + mouseY * sensitivity * 1.2, -86, 86)
			state.aim.r = 0
		else
			local maxYaw = math.max(12, tonumber(naval.SkyboxPilotCursorYaw) or 52)
			local maxPitch = math.max(8, tonumber(naval.SkyboxPilotCursorPitch) or 34)
			state.cursorYaw = math.Clamp(state.cursorYaw - mouseX * sensitivity, -maxYaw, maxYaw)
			state.cursorPitch = math.Clamp(state.cursorPitch + mouseY * sensitivity, -maxPitch, maxPitch)
			local base = isangle(state.cameraAngle) and state.cameraAngle or state.predictedAngle
			state.aim = Angle(
				math.Clamp(base.p + state.cursorPitch, -86, 86),
				math.NormalizeAngle(base.y + state.cursorYaw), 0)
		end
	end

	local throttleRate = math.max(0.05, tonumber(naval.SkyboxPilotThrottleRate) or 0.34)
	if buttonDown(buttons, IN_FORWARD) then
		state.throttle = math.Clamp(state.throttle + throttleRate * frameTime, 0, 1)
	end
	if buttonDown(buttons, IN_BACK) then
		state.throttle = math.Clamp(state.throttle - throttleRate * frameTime, 0, 1)
	end

	local left = buttonDown(buttons, IN_MOVELEFT)
	local right = buttonDown(buttons, IN_MOVERIGHT)
	state.roll = (right and 1 or 0) - (left and 1 or 0)
	state.lookBehind = buttonDown(buttons, IN_JUMP)

	local lockDown = buttonDown(buttons, IN_ATTACK2)
	if lockDown and not state.lockHeld then state.lockPulse = true end
	state.lockHeld = lockDown
	local cycleDown = buttonDown(buttons, IN_RELOAD)
	if cycleDown and not state.cycleHeld then state.cyclePulse = true end
	state.cycleHeld = cycleDown
	local friendlyDown = input.IsKeyDown(KEY_T)
	if friendlyDown and not state.friendlyHeld then state.friendlyPulse = true end
	state.friendlyHeld = friendlyDown
	local threatDown = input.IsKeyDown(KEY_Y)
	if threatDown and not state.threatHeld then state.threatPulse = true end
	state.threatHeld = threatDown
	local secondaryDown = input.IsMouseDown(MOUSE_MIDDLE)
	if secondaryDown and not state.secondaryHeld then state.secondaryPulse = true end
	state.secondaryHeld = secondaryDown

	local subsystemDown = input.IsKeyDown(KEY_N)
	if subsystemDown and not state.subsystemHeld then
		state.targetSubsystem = state.targetSubsystem % #TARGET_SUBSYSTEMS + 1
		state.hintUntil = RealTime() + 3
	end
	state.subsystemHeld = subsystemDown
	local assistDown = input.IsKeyDown(KEY_B)
	if assistDown and not state.assistHeld then
		state.assistMode = state.assistMode % #ASSIST_MODES + 1
		state.hintUntil = RealTime() + 4
	end
	state.assistHeld = assistDown
	local returnDown = input.IsKeyDown(KEY_J)
	if returnDown and not state.returnHeld then
		state.returnAssist = not state.returnAssist
		state.hintUntil = RealTime() + 4
	end
	state.returnHeld = returnDown

	local orderDown = input.IsKeyDown(KEY_G)
	if orderDown and not state.orderHeld then
		state.orderIndex = state.orderIndex % #PILOT_ORDERS + 1
		state.hintUntil = RealTime() + 4
	end
	state.orderHeld = orderDown
	local transmitDown = input.IsKeyDown(KEY_F)
	if transmitDown and not state.transmitHeld then state.transmitPulse = true end
	state.transmitHeld = transmitDown

	local viewDown = buttonDown(buttons, IN_ZOOM)
	if viewDown and not state.viewHeld then
		state.cameraMode = state.cameraMode % 3 + 1
		state.cockpit = state.cameraMode == 3
		state.cameraOrigin = nil
	end
	state.viewHeld = viewDown

	local exitDown = buttonDown(buttons, IN_USE)
	if exitDown and not state.exitHeld then
		net.Start(NET_EXIT)
		net.SendToServer()
	end
	state.exitHeld = exitDown

	local wheel = cmd:GetMouseWheel()
	if wheel ~= 0 and not state.radialHeld then
		state.cameraZoom = math.Clamp(state.cameraZoom - wheel * 0.08, 0.62, 1.65)
	end

	approachPilotPrediction(ship, frameTime)

	if RealTime() >= state.nextSend then
		state.nextSend = RealTime() + math.max(0.02, tonumber(naval.SkyboxPilotInputRate) or 0.04)
		local flags = 0
		if buttonDown(buttons, IN_ATTACK) and not state.uiOpen and not state.radialHeld then flags = bit.bor(flags, FLAG_FIRE) end
		if buttonDown(buttons, IN_SPEED) then flags = bit.bor(flags, FLAG_BOOST) end
		if buttonDown(buttons, IN_DUCK) then flags = bit.bor(flags, FLAG_BRAKE) end
		if state.lockPulse then flags = bit.bor(flags, FLAG_LOCK) end
		if state.cyclePulse then flags = bit.bor(flags, FLAG_CYCLE) end
		if state.friendlyPulse then flags = bit.bor(flags, FLAG_CYCLE_FRIENDLY) end
		if state.threatPulse then flags = bit.bor(flags, FLAG_THREAT) end
		if state.secondaryPulse then flags = bit.bor(flags, FLAG_SECONDARY) end
		if state.advanced then flags = bit.bor(flags, FLAG_ADVANCED) end
		if state.transmitPulse then flags = bit.bor(flags, FLAG_ORDER) end
		if state.wingPulse then flags = bit.bor(flags, FLAG_WING_ORDER) end
		if state.returnAssist then flags = bit.bor(flags, FLAG_RETURN_ASSIST) end
		if not cvCollisionAssist:GetBool() then flags = bit.bor(flags, FLAG_COLLISION_OFF) end
		net.Start(NET_INPUT)
			net.WriteAngle(state.aim)
			net.WriteFloat(state.throttle)
			net.WriteUInt(flags, 16)
			net.WriteInt(math.Clamp(math.Round(state.roll * 127), -127, 127), 8)
			net.WriteUInt(math.Clamp(state.orderIndex, 1, #PILOT_ORDERS), 4)
			net.WriteUInt(math.Clamp(state.wingOrderIndex, 1, #WING_ORDERS), 4)
			net.WriteUInt(math.Clamp(state.assistMode, 1, #ASSIST_MODES), 2)
			net.WriteUInt(math.Clamp(state.targetSubsystem, 1, #TARGET_SUBSYSTEMS), 3)
		net.SendToServer()
		state.lockPulse = false
		state.cyclePulse = false
		state.friendlyPulse = false
		state.threatPulse = false
		state.secondaryPulse = false
		state.transmitPulse = false
		state.wingPulse = false
	end

	cmd:ClearMovement()
	cmd:ClearButtons()
	cmd:SetImpulse(0)
	cmd:SetViewAngles(state.cameraAngle or state.aim)
end)

local function smoothingAlpha(rate, frameTime)
	return 1 - math.exp(-math.max(0.1, rate) * math.max(0, frameTime))
end

hook.Add("CalcView", "MilBase.SkyboxPilot.CalcView", function(ply, origin, angles, fov)
	local ship = activeShip()
	if not IsValid(ship) then return end
	local frameTime = math.Clamp(RealFrameTime(), 0.001, 0.05)
	local profile = profileFor(state.squadron)
	local radius = math.max(12, ship:GetCombatRadius())
	local speed = math.max(0, ship:GetMotionSpeed())
	local speedFraction = math.Clamp(speed / math.max(profile.maximumSpeed, 1), 0, 1.5)
	local comfort = cvComfort:GetBool()
	local pullback = 1 + speedFraction
		* math.max(0, tonumber(naval.SkyboxPilotCameraSpeedPullback) or 0.32)
	local modeDistance = state.cameraMode == 2 and 0.62 or 1
	local modeHeight = state.cameraMode == 2 and 0.7 or 1
	local distance = radius * math.max(3, tonumber(naval.SkyboxPilotCameraDistance) or 6)
		* profile.cameraDistance * state.cameraZoom * pullback * modeDistance
	local height = radius * math.max(0, tonumber(naval.SkyboxPilotCameraHeight) or 1.35)
		* profile.cameraHeight * modeHeight

	local predicted = isangle(state.predictedAngle)
		and Angle(state.predictedAngle.p, state.predictedAngle.y, state.predictedAngle.r)
		or ship:GetAngles()
	local levelFlight = Angle(predicted.p, predicted.y, 0)
	local influence = math.Clamp(tonumber(naval.SkyboxPilotCameraAimInfluence) or 0.2, 0, 0.65)
	local rollAmount = comfort and 0 or math.Clamp(cvCameraRoll:GetFloat(), 0, 1)
	local targetAngle = Angle(
		levelFlight.p + math.AngleDifference(state.aim.p, levelFlight.p) * influence
			+ state.freeLookPitch,
		levelFlight.y + math.AngleDifference(state.aim.y, levelFlight.y) * influence
			+ state.freeLookYaw,
		predicted.r * rollAmount)
	local alpha = smoothingAlpha(cvCameraSmooth:GetFloat(), frameTime)
	state.cameraAngle = LerpAngle(alpha, state.cameraAngle or targetAngle, targetAngle)

	local center = ship:WorldSpaceCenter()
	local forward = levelFlight:Forward()
	local stableUp = levelFlight:Up()
	local desiredOrigin
	if state.cameraMode == 3 then
		desiredOrigin = center + forward * radius * 0.18 + stableUp * radius * 0.12
	else
		desiredOrigin = center - forward * distance + stableUp * height
		local padding = math.max(1, tonumber(naval.SkyboxPilotCameraCollisionPadding) or 8)
		local trace = util.TraceHull({
			start = center,
			endpos = desiredOrigin,
			mins = Vector(-2, -2, -2),
			maxs = Vector(2, 2, 2),
			mask = MASK_SOLID_BRUSHONLY,
			filter = { ship, ply },
		})
		if trace.Hit then desiredOrigin = trace.HitPos + trace.HitNormal * padding end
	end
	state.cameraOrigin = state.cameraOrigin
		and LerpVector(alpha, state.cameraOrigin, desiredOrigin) or desiredOrigin

	local viewAngle = Angle(state.cameraAngle.p, state.cameraAngle.y, state.cameraAngle.r)
	if state.lookBehind then
		viewAngle.y = math.NormalizeAngle(viewAngle.y + 180)
		viewAngle.p = -viewAngle.p * 0.25
	end

	local hitAt = ship:GetNW2Float("MBSkyboxPilotLastHitAt", 0)
	local hitAge = CurTime() - hitAt
	local shakeStrength = comfort and 0 or math.Clamp(cvDamageShake:GetFloat(), 0, 1)
	if hitAge >= 0 and hitAge < 0.45 and shakeStrength > 0 then
		local fade = 1 - hitAge / 0.45
		viewAngle.p = viewAngle.p + math.sin(RealTime() * 52) * 1.6 * shakeStrength * fade
		viewAngle.y = viewAngle.y + math.cos(RealTime() * 46) * 1.2 * shakeStrength * fade
	end

	local baseFOV = cvCameraFOV:GetFloat()
	local boostExtra = comfort and 0 or cvBoostFOV:GetFloat()
	local speedExtra = comfort and 0 or speedFraction * 2.5
	return {
		origin = state.cameraOrigin,
		angles = viewAngle,
		fov = math.Clamp(baseFOV + speedExtra
			+ (ship:GetNW2Bool("MBSkyboxPilotBoost", false) and boostExtra or 0), 70, 110),
		drawviewer = state.cameraMode ~= 3,
	}
end)

hook.Add("HUDShouldDraw", "MilBase.SkyboxPilot.HideHUD", function(name)
	if not IsValid(activeShip()) then return end
	if name == "CHudCrosshair" or name == "CHudWeaponSelection"
	or name == "CHudHealth" or name == "CHudBattery" then return false end
end)

hook.Add("PreDrawViewModel", "MilBase.SkyboxPilot.HideViewModel", function()
	if IsValid(activeShip()) then return true end
end)

local function screenPoint(vector)
	if not isvector(vector) then return nil end
	local point = vector:ToScreen()
	return point
end

local function pointOnScreen(point, margin)
	margin = margin or 24
	return point and point.visible and point.x >= margin and point.x <= ScrW() - margin
		and point.y >= margin and point.y <= ScrH() - margin
end

local function drawReticle(x, y, color, size)
	size = size or 14
	surface.SetDrawColor(color)
	surface.DrawLine(x - size, y, x - 4, y)
	surface.DrawLine(x + 4, y, x + size, y)
	surface.DrawLine(x, y - size, x, y - 4)
	surface.DrawLine(x, y + 4, x, y + size)
	surface.DrawOutlinedRect(x - 2, y - 2, 4, 4, 1)
end

local function drawBar(x, y, width, height, fraction, label, value, fill, back)
	fraction = math.Clamp(fraction or 0, 0, 1)
	draw.RoundedBox(2, x, y, width, height, back)
	draw.RoundedBox(2, x + 2, y + 2, math.max(0, (width - 4) * fraction),
		height - 4, fill)
	draw.SimpleText(label, "DermaDefaultBold", x, y - 15, Color(215, 228, 242),
		TEXT_ALIGN_LEFT)
	draw.SimpleText(value or "", "DermaDefaultBold", x + width, y - 15,
		Color(215, 228, 242), TEXT_ALIGN_RIGHT)
end

local function drawOffscreenArrow(point, color, label)
	if not point then return end
	local sw, sh = ScrW(), ScrH()
	local cx, cy = sw * 0.5, sh * 0.5
	local dx, dy = point.x - cx, point.y - cy
	if not point.visible then dx, dy = -dx, -dy end
	if math.abs(dx) + math.abs(dy) < 1 then dy = -1 end
	local angle = math.atan2(dy, dx)
	local radius = math.min(sw, sh) * 0.37
	local x = cx + math.cos(angle) * radius
	local y = cy + math.sin(angle) * radius
	local forwardX, forwardY = math.cos(angle), math.sin(angle)
	local sideX, sideY = -forwardY, forwardX
	local tipX, tipY = x + forwardX * 12, y + forwardY * 12
	local leftX, leftY = x - forwardX * 8 + sideX * 7, y - forwardY * 8 + sideY * 7
	local rightX, rightY = x - forwardX * 8 - sideX * 7, y - forwardY * 8 - sideY * 7
	draw.NoTexture()
	surface.SetDrawColor(color)
	surface.DrawPoly({
		{ x = tipX, y = tipY }, { x = leftX, y = leftY }, { x = rightX, y = rightY },
	})
	if label then
		draw.SimpleText(label, "DermaDefaultBold", x, y + 16, color, TEXT_ALIGN_CENTER)
	end
end

local function targetLabel(target)
	if not IsValid(target) then return "CONTACT" end
	if target.GetShipName then return string.upper(target:GetShipName()) end
	return string.upper(target:GetClass() or "CONTACT")
end

local function targetFaction(target)
	if not IsValid(target) or not target.GetFaction then return "UNKNOWN" end
	local faction = string.lower(tostring(target:GetFaction() or "unknown"))
	if faction == "cis" then return "CIS" end
	if faction == "republic" then return "REPUBLIC" end
	if faction == "pirate" then return "PIRATE" end
	if faction == "civilian" then return "CIVILIAN" end
	return string.upper(faction ~= "" and faction or "UNKNOWN")
end

local function wrapText(textValue, font, maximumWidth)
	local lines, current = {}, ""
	surface.SetFont(font)
	for word in string.gmatch(tostring(textValue or ""), "%S+") do
		local candidate = current == "" and word or current .. " " .. word
		local width = surface.GetTextSize(candidate)
		if width > maximumWidth and current ~= "" then
			lines[#lines + 1] = current
			current = word
		else
			current = candidate
		end
	end
	if current ~= "" then lines[#lines + 1] = current end
	return lines
end

local function contactColour(target, selected)
	local faction = string.lower(tostring(IsValid(target) and target:GetFaction() or "unknown"))
	local colourBlind = cvColourBlind:GetBool()
	if faction == "republic" then return colourBlind and Color(70, 170, 255, 235) or Color(105, 235, 155, 235) end
	if faction == "civilian" or faction == "neutral" then return colourBlind and Color(245, 205, 70, 235) or Color(255, 205, 80, 235) end
	if faction == "pirate" then return colourBlind and Color(235, 120, 255, 235) or Color(255, 150, 60, 235) end
	if faction == "cis" then return colourBlind and Color(255, 110, 70, 235) or Color(255, 80, 70, 235) end
	return selected and Color(255, 210, 90, 235) or Color(180, 195, 215, 210)
end

local function cachedContacts(ship)
	if RealTime() < (state.contactCacheAt or 0) then return state.contactCache end
	state.contactCacheAt = RealTime() + 0.12
	state.contactCache = {}
	local range = math.max(1500, cvRadarRange:GetFloat())
	for _, target in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if IsValid(target) and target ~= ship and not target.mb_destroyed
		and target:GetHull() > 0 then
			local distance = ship:GetPos():Distance(target:GetPos())
			if distance <= range * 1.45 then
				state.contactCache[#state.contactCache + 1] = {
					entity = target,
					distance = distance,
				}
			end
		end
	end
	return state.contactCache
end

local function drawContactMarkers(ship, target)
	local markerScale = math.Clamp(cvMarkerScale:GetFloat(), 0.65, 1.8)
	for _, contact in ipairs(cachedContacts(ship)) do
		local ent = contact.entity
		if IsValid(ent) then
			local point = screenPoint(ent:WorldSpaceCenter())
			local selected = ent == target
			local colour = contactColour(ent, selected)
			local sizeClass = string.lower(ent.GetSizeClass and ent:GetSizeClass() or "light")
			local baseSize = sizeClass == "fighter" and 6 or sizeClass == "shuttle" and 8
				or sizeClass == "capital" and 17 or sizeClass == "corvette" and 13 or 10
			local size = math.Clamp(baseSize * markerScale, 4, 28)
			if pointOnScreen(point, 20) then
				if cvTargetTrails:GetBool() then
					local previous = state.trailPositions[ent]
					if previous and previous.visible then
						surface.SetDrawColor(Color(colour.r, colour.g, colour.b, 90))
						surface.DrawLine(previous.x, previous.y, point.x, point.y)
					end
					state.trailPositions[ent] = { x = point.x, y = point.y, visible = point.visible }
				end
				surface.SetDrawColor(colour)
				if sizeClass == "fighter" then
					surface.DrawCircle(point.x, point.y, size, colour)
				else
					surface.DrawOutlinedRect(point.x - size, point.y - size, size * 2, size * 2, selected and 2 or 1)
				end
				if selected or contact.distance < 2500 then
					draw.SimpleText(string.upper(ent:GetShipName() or "CONTACT") .. "  " .. math.floor(contact.distance),
						"DermaDefaultBold", point.x, point.y + size + 7, colour, TEXT_ALIGN_CENTER)
				end
			elseif selected then
				drawOffscreenArrow(point, colour, targetFaction(ent))
			end
		end
	end
end

local function drawRadar(ship, panel, dim, accent)
	if not cvRadarEnabled:GetBool() then return end
	local scale = math.Clamp(cvHUDScale:GetFloat(), 0.7, 1.35)
	local radius = 74 * scale
	local x, y = ScrW() - radius - 30, ScrH() * 0.55
	local range = math.max(1500, cvRadarRange:GetFloat())
	draw.RoundedBox(6, x - radius - 12, y - radius - 24, radius * 2 + 24, radius * 2 + 48, panel)
	draw.SimpleText("TACTICAL RADAR  " .. math.floor(range), "DermaDefaultBold", x, y - radius - 18, dim, TEXT_ALIGN_CENTER)
	surface.SetDrawColor(Color(accent.r, accent.g, accent.b, 120))
	surface.DrawCircle(x, y, radius, accent)
	surface.DrawCircle(x, y, radius * 0.5, accent)
	surface.DrawLine(x - radius, y, x + radius, y)
	surface.DrawLine(x, y - radius, x, y + radius)
	local angle = Angle(0, ship:GetAngles().y, 0)
	for _, contact in ipairs(cachedContacts(ship)) do
		local ent = contact.entity
		if IsValid(ent) and contact.distance <= range then
			local localPos = WorldToLocal(ent:GetPos(), angle_zero, ship:GetPos(), angle)
			local px = math.Clamp(localPos.y / range, -1, 1) * radius
			local py = math.Clamp(-localPos.x / range, -1, 1) * radius
			local colour = contactColour(ent, ent == ship:GetNW2Entity("MBSkyboxPilotTarget"))
			local dot = ent.GetSizeClass and ent:GetSizeClass() == "capital" and 5 or 3
			draw.RoundedBox(1, x + px - dot, y + py - dot, dot * 2, dot * 2, colour)
			if math.abs(localPos.z) > 80 then
				draw.SimpleText(localPos.z > 0 and "+" or "-", "DermaDefaultBold",
					x + px, y + py - 11, colour, TEXT_ALIGN_CENTER)
			end
		end
	end
	draw.NoTexture()
	surface.SetDrawColor(accent)
	surface.DrawPoly({
		{ x = x, y = y - 8 }, { x = x - 5, y = y + 5 }, { x = x + 5, y = y + 5 },
	})
end

local function drawRadialWheel(panel, text, dim, accent)
	if not state.radialHeld or not state.radialMode then return end
	local entries = state.radialMode == "wing" and WING_ORDERS or PILOT_ORDERS
	local cx, cy = ScrW() * 0.5, ScrH() * 0.5
	local radius = math.min(ScrW(), ScrH()) * 0.18
	draw.RoundedBox(10, cx - radius - 70, cy - radius - 70,
		radius * 2 + 140, radius * 2 + 140, panel)
	draw.SimpleText(state.radialMode == "wing" and "WINGMAN COMMANDS" or "CONTACT COMMANDS",
		"DermaLarge", cx, cy - radius - 46, accent, TEXT_ALIGN_CENTER)
	for index, label in ipairs(entries) do
		local angle = -math.pi * 0.5 + (index - 1) / #entries * math.pi * 2
		local x = cx + math.cos(angle) * radius
		local y = cy + math.sin(angle) * radius
		local selected = index == state.radialSelection
		if selected then draw.RoundedBox(5, x - 76, y - 16, 152, 32, Color(accent.r, accent.g, accent.b, 90)) end
		draw.SimpleText(label, "DermaDefaultBold", x, y, selected and text or dim,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	draw.SimpleText("RELEASE KEY TO TRANSMIT", "DermaDefaultBold", cx, cy + radius + 42,
		dim, TEXT_ALIGN_CENTER)
end

hook.Add("HUDPaint", "MilBase.SkyboxPilot.HUD", function()
	local ship = activeShip()
	if not IsValid(ship) then return end
	local sw, sh = ScrW(), ScrH()
	local cx, cy = sw * 0.5, sh * 0.5
	local accent = Color(95, 175, 255, 235)
	local text = Color(230, 240, 255, 245)
	local dim = Color(155, 180, 205, 230)
	local danger = Color(255, 90, 75, 240)
	local warning = Color(255, 205, 80, 240)
	local good = Color(105, 235, 155, 240)
	local panel = Color(8, 18, 31, 205)
	local barBack = Color(25, 42, 60, 225)
	local profile = profileFor(state.squadron)
	local target = ship:GetNW2Entity("MBSkyboxPilotTarget")
	drawContactMarkers(ship, target)

	local aimPoint = screenPoint(ship:WorldSpaceCenter() + state.aim:Forward() * 5000)
	if pointOnScreen(aimPoint, 12) then
		drawReticle(aimPoint.x, aimPoint.y,
			ship:GetNW2Bool("MBSkyboxPilotCanFire", false) and good or accent, 15)
	else
		drawOffscreenArrow(aimPoint, accent, "AIM")
	end

	local nosePoint = screenPoint(ship:WorldSpaceCenter() + ship:GetForward() * 900)
	if pointOnScreen(nosePoint, 8) then
		surface.SetDrawColor(warning)
		surface.DrawOutlinedRect(nosePoint.x - 5, nosePoint.y - 5, 10, 10, 1)
		surface.DrawLine(nosePoint.x - 8, nosePoint.y, nosePoint.x - 4, nosePoint.y)
		surface.DrawLine(nosePoint.x + 4, nosePoint.y, nosePoint.x + 8, nosePoint.y)
	end

	local locked = ship:GetNW2Bool("MBSkyboxPilotLocked", false)
	if IsValid(target) then
		local targetPoint = screenPoint(target:WorldSpaceCenter())
		local faction = string.lower(tostring(target:GetFaction() or ""))
		local factionColor = faction == "republic" and good
			or faction == "civilian" and warning or danger
		local targetColor = locked and factionColor or warning
		if pointOnScreen(targetPoint, 34) then
			local radius = math.Clamp(target:GetCombatRadius() * 0.8, 14, 38)
			surface.SetDrawColor(targetColor)
			surface.DrawOutlinedRect(targetPoint.x - radius, targetPoint.y - radius,
				radius * 2, radius * 2, locked and 2 or 1)
			draw.SimpleText(locked and "LOCK" or "TRACK", "DermaDefaultBold",
				targetPoint.x, targetPoint.y - radius - 16, targetColor, TEXT_ALIGN_CENTER)
		else
			drawOffscreenArrow(targetPoint, targetColor, locked and "LOCK" or "TRACK")
		end

		local lead = ship:GetNW2Vector("MBSkyboxPilotLeadPoint", vector_origin)
		if lead ~= vector_origin then
			local leadPoint = screenPoint(lead)
			if pointOnScreen(leadPoint, 12) then
				surface.SetDrawColor(good)
				surface.DrawCircle(leadPoint.x, leadPoint.y, 9, good)
				surface.DrawLine(leadPoint.x - 12, leadPoint.y, leadPoint.x - 6, leadPoint.y)
				surface.DrawLine(leadPoint.x + 6, leadPoint.y, leadPoint.x + 12, leadPoint.y)
			end
		end
	end

	local panelW, panelH = 390, 204
	local panelX, panelY = 24, sh - panelH - 24
	draw.RoundedBox(6, panelX, panelY, panelW, panelH, panel)
	draw.SimpleText(string.upper(state.label or "STARFIGHTER") .. " REMOTE FLIGHT",
		"DermaLarge", panelX + 14, panelY + 10, text)
	draw.SimpleText(state.advanced and "ADVANCED CONTROL" or "ASSISTED MOUSE AIM",
		"DermaDefaultBold", panelX + panelW - 14, panelY + 18,
		state.advanced and warning or accent, TEXT_ALIGN_RIGHT)
	local throttle = ship:GetNW2Float("MBSkyboxPilotThrottle", state.throttle)
	local speed = math.max(0, ship:GetMotionSpeed())
	local heat = ship:GetNW2Float("MBSkyboxPilotHeat", 0)
	drawBar(panelX + 14, panelY + 63, 165, 12, throttle,
		"THROTTLE", math.floor(throttle * 100) .. "%", accent, barBack)
	drawBar(panelX + 205, panelY + 63, 165, 12,
		math.Clamp(speed / math.max(profile.maximumSpeed, 1), 0, 1),
		"SPEED", math.floor(speed), good, barBack)
	local speedRatio = math.Clamp(speed / math.max(profile.maximumSpeed, 1), 0, 1)
	local optimal = speedRatio >= profile.optimalTurnMin and speedRatio <= profile.optimalTurnMax
	draw.SimpleText("TURN " .. math.floor(profile.optimalTurnMin * 100) .. "-"
		.. math.floor(profile.optimalTurnMax * 100) .. "%", "DermaDefault",
		panelX + 205, panelY + 82, optimal and good or dim)
	drawBar(panelX + 14, panelY + 104, 165, 12, heat,
		"WEAPON HEAT", math.floor(heat * 100) .. "%",
		ship:GetNW2Bool("MBSkyboxPilotOverheated", false) and danger or warning, barBack)
	local hullFraction = ship:GetHullFraction()
	local shieldFraction = ship:GetMaxShield() > 0 and ship:GetShieldFraction() or 0
	drawBar(panelX + 205, panelY + 104, 78, 12, hullFraction,
		"HULL", math.floor(hullFraction * 100) .. "%", good, barBack)
	drawBar(panelX + 292, panelY + 104, 78, 12, shieldFraction,
		"SHIELD", ship:GetMaxShield() > 0 and math.floor(shieldFraction * 100) .. "%" or "N/A",
		accent, barBack)

	local boostReserve = ship:GetNW2Float("MBSkyboxPilotBoostReserve", 0)
	drawBar(panelX + 14, panelY + 145, 165, 10, boostReserve,
		"BOOST RESERVE", math.floor(boostReserve * 100) .. "%", accent, barBack)
	local engines = ship:GetNW2Float("MBSkyboxSystemEngines", 1)
	local controls = ship:GetNW2Float("MBSkyboxSystemControls", 1)
	local weapons = ship:GetNW2Float("MBSkyboxSystemWeapons", 1)
	local systemsText = string.format("ENG %d  CTRL %d  WPN %d", engines * 100, controls * 100, weapons * 100)
	draw.SimpleText(systemsText, "DermaDefaultBold", panelX + 205, panelY + 144,
		(engines < 0.25 or controls < 0.25 or weapons < 0.25) and danger or dim)
	local missiles = ship:GetNW2Int("MBSkyboxPilotMissiles", 0)
	local cooldown = math.max(0, ship:GetNW2Float("MBSkyboxPilotMissileCooldown", 0) - CurTime())
	draw.SimpleText("ORDNANCE " .. missiles .. (cooldown > 0 and "  READY " .. string.format("%.1f", cooldown) or "  READY"),
		"DermaDefaultBold", panelX + 205, panelY + 164, cooldown > 0 and warning or good)
	local assistMode = ship:GetNW2Int("MBSkyboxPilotAssistMode", state.assistMode)
	draw.SimpleText("ASSIST " .. (ASSIST_MODES[assistMode] or "COMBAT")
		.. (ship:GetNW2Bool("MBSkyboxPilotReturnAssist", false) and "  |  RETURN" or ""),
		"DermaDefaultBold", panelX + 14, panelY + 178, accent)

	local status = {}
	if ship:GetNW2Bool("MBSkyboxPilotBoost", false) then status[#status + 1] = "BOOST" end
	if ship:GetNW2Bool("MBSkyboxPilotBrake", false) then status[#status + 1] = "AIR BRAKE" end
	if ship:GetNW2Bool("MBSkyboxPilotOverheated", false) then status[#status + 1] = "WEAPONS HOT" end
	if ship:GetNW2Float("MBSkyboxPilotCollision", 0) > 0.12 then status[#status + 1] = "COLLISION AVOIDANCE" end
	if ship:GetNW2Bool("MBSkyboxPilotCritical", false) then status[#status + 1] = "CRITICAL RETURN" end
	local boundary = ship:GetNW2Float("MBSkyboxPilotBoundary", 0)
	if boundary > 0.08 then
		status[#status + 1] = "BOUNDARY "
			.. math.floor(ship:GetNW2Float("MBSkyboxPilotBoundaryDistance", 0))
	end
	if #status > 0 then
		draw.SimpleText(table.concat(status, "  |  "), "DermaDefaultBold",
			panelX + 14, panelY + panelH - 18,
			boundary > 0.6 and danger or warning)
	end

	if IsValid(target) then
		local targetW, targetH = 330, 148
		local targetX, targetY = sw - targetW - 24, sh - targetH - 24
		draw.RoundedBox(6, targetX, targetY, targetW, targetH, panel)
		draw.SimpleText(targetLabel(target), "DermaLarge", targetX + 14,
			targetY + 10, target:GetFaction() == "republic" and good or danger)
		draw.SimpleText(targetFaction(target), "DermaDefaultBold", targetX + targetW - 14,
			targetY + 18, dim, TEXT_ALIGN_RIGHT)
		local delta = target:GetPos() - ship:GetPos()
		local distance = delta:Length()
		local relativeVelocity = target:GetFlightVelocity() - ship:GetFlightVelocity()
		local closing = distance > 1 and -relativeVelocity:Dot(delta / distance) or 0
		draw.SimpleText((locked and "LOCKED" or "SOFT TRACK") .. "   RANGE "
			.. math.floor(distance) .. "   CLOSING " .. math.floor(closing),
			"DermaDefaultBold", targetX + 14, targetY + 45, locked and danger or warning)
		local subsystemIndex = ship:GetNW2Int("MBSkyboxPilotTargetSubsystem", state.targetSubsystem)
		local subsystem = TARGET_SUBSYSTEMS[subsystemIndex] or "HULL"
		draw.SimpleText("AIM POINT: " .. subsystem, "DermaDefaultBold", targetX + 14,
			targetY + 63, subsystem == "HULL" and dim or warning)
		local targetHull = target.GetHullFraction and target:GetHullFraction() or 0
		local targetShield = target.GetMaxShield and target:GetMaxShield() > 0
			and target:GetShieldFraction() or 0
		drawBar(targetX + 14, targetY + 102, 145, 10, targetHull,
			"HULL", math.floor(targetHull * 100) .. "%", danger, barBack)
		drawBar(targetX + 171, targetY + 102, 145, 10, targetShield,
			"SHIELD", target.GetMaxShield and target:GetMaxShield() > 0
				and math.floor(targetShield * 100) .. "%" or "N/A", accent, barBack)
		local targetSystemValue = subsystem == "ENGINES" and target:GetNW2Float("MBSkyboxSystemEngines", 1)
			or subsystem == "WEAPONS" and target:GetNW2Float("MBSkyboxSystemWeapons", 1)
			or subsystem == "SHIELDS" and target:GetNW2Float("MBSkyboxSystemShields", 1) or targetHull
		draw.SimpleText("SUBSYSTEM " .. math.floor(targetSystemValue * 100) .. "%", "DermaDefaultBold",
			targetX + 14, targetY + 130, targetSystemValue < 0.25 and danger or dim)
	end

	local commandLabel = PILOT_ORDERS[state.orderIndex] or PILOT_ORDERS[1]
	local commandW, commandH = 310, 54
	local commandX, commandY = cx - commandW * 0.5, sh - 176
	draw.RoundedBox(6, commandX, commandY, commandW, commandH, panel)
	draw.SimpleText("COMM ORDER", "DermaDefaultBold", commandX + 12, commandY + 9, dim)
	draw.SimpleText(commandLabel, "DermaLarge", commandX + 12, commandY + 25, accent)
	draw.SimpleText("G/F QUICK   X RADIAL   V WING", "DermaDefaultBold",
		commandX + commandW - 12, commandY + 11, dim, TEXT_ALIGN_RIGHT)

	drawRadar(ship, panel, dim, accent)

	if state.radio and RealTime() <= (state.radio.untilTime or 0) then
		local radio = state.radio
		local radioColor = radio.tone == "hostile" and danger
			or radio.tone == "warning" and warning
			or radio.tone == "distress" and warning
			or radio.tone == "republic" and good or accent
		local radioW = math.min(560, sw - 48)
		local lines = wrapText(radio.body, "DermaDefaultBold", radioW - 28)
		local radioH = 54 + #lines * 18
		local radioX, radioY = cx - radioW * 0.5, 118
		draw.RoundedBox(6, radioX, radioY, radioW, radioH, panel)
		draw.SimpleText(string.upper(radio.title or "INCOMING TRANSMISSION"),
			"DermaLarge", radioX + 14, radioY + 10, radioColor)
		for index, line in ipairs(lines) do
			draw.SimpleText(line, "DermaDefaultBold", radioX + 14,
				radioY + 38 + (index - 1) * 18, text)
		end
	elseif state.radio then
		state.radio = nil
	end

	if RealTime() <= state.hitMarkerUntil then
		local size = 13
		surface.SetDrawColor(state.hitKind == "SHIELD" and accent or warning)
		surface.DrawLine(cx - size, cy - size, cx - 4, cy - 4)
		surface.DrawLine(cx + size, cy - size, cx + 4, cy - 4)
		surface.DrawLine(cx - size, cy + size, cx - 4, cy + 4)
		surface.DrawLine(cx + size, cy + size, cx + 4, cy + 4)
	end
	if RealTime() <= state.killUntil then
		draw.SimpleText("TARGET DESTROYED — " .. string.upper(state.killLabel or "CONTACT"),
			"DermaLarge", cx, cy + 92, good, TEXT_ALIGN_CENTER)
	end

	if ship:GetNW2Bool("MBSkyboxPilotIncomingLock", false) then
		draw.SimpleText("INCOMING TARGET LOCK", "DermaLarge", cx, 62,
			danger, TEXT_ALIGN_CENTER)
	end
	if ship:GetNW2Bool("MBSkyboxPilotOverheated", false) then
		draw.SimpleText("WEAPONS OVERHEATED", "DermaLarge", cx, cy + 62,
			danger, TEXT_ALIGN_CENTER)
	end
	if boundary > 0.65 then
		draw.SimpleText("SKYBOX BOUNDARY — FLIGHT ASSIST CORRECTING COURSE",
			"DermaDefaultBold", cx, 94, warning, TEXT_ALIGN_CENTER)
	end

	local hitAt = ship:GetNW2Float("MBSkyboxPilotLastHitAt", 0)
	local hitDuration = math.max(0.5,
		tonumber(naval.SkyboxPilotDamageIndicatorDuration) or 2.2)
	if CurTime() - hitAt <= hitDuration then
		local hitPoint = screenPoint(ship:GetNW2Vector("MBSkyboxPilotLastHitPos",
			ship:WorldSpaceCenter()))
		drawOffscreenArrow(hitPoint, danger, "HIT")
	end

	if RealTime() <= state.hintUntil then
		draw.SimpleText("W/S THROTTLE   A/D ROLL   CTRL AIR BRAKE   SHIFT BOOST   LMB FIRE",
			"DermaDefaultBold", cx, sh - 48, dim, TEXT_ALIGN_CENTER)
		draw.SimpleText("RMB LOCK   R HOSTILE   T FRIENDLY   Y THREAT   N SUBSYSTEM   M MODE   ALT FREE-LOOK",
			"DermaDefault", cx, sh - 46, dim, TEXT_ALIGN_CENTER)
		draw.SimpleText("MMB MISSILE   B ASSIST   J RETURN   X CONTACT WHEEL   V WING WHEEL   Z VIEW   P SETTINGS   E RELEASE",
			"DermaDefault", cx, sh - 26, dim, TEXT_ALIGN_CENTER)
	end
	drawRadialWheel(panel, text, dim, accent)
end)
