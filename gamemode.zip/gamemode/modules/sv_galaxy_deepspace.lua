--[[
	Galaxy Director LVS deep-space transit.

	A player-flown LVS craft flying into the map's skybox boundary is kept as the
	same live vehicle, but is moved into SWU's physical 3D skybox. The pilot and
	passengers remain in their original LVS seats, so every normal LVS control,
	weapon and damage system continues to work. SWU's native skybox scale makes
	the vehicle appear tiny beside the Republic ship without unsafe model or
	physics resizing.
]]

if not SERVER or MilBase._GalaxyDeepSpaceServerLoaded then return end
MilBase._GalaxyDeepSpaceServerLoaded = true

local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}

G.DeepSpaceVehicles = G.DeepSpaceVehicles or setmetatable({}, { __mode = "k" })

local function flatForward(ang)
	return Angle(0, isangle(ang) and ang.y or 0, 0):Forward()
end

local function deepSpaceReady()
	local bounds = SWU and SWU.config and SWU.config.skyboxBoundaries
	if not (bounds and isvector(bounds.min) and isvector(bounds.max)) then return false end
	local width = math.abs(bounds.max.x - bounds.min.x)
	local length = math.abs(bounds.max.y - bounds.min.y)
	return gd.LVSDeepSpaceEnabled ~= false
		and G.HasSWUUniverseFrame and G.HasSWUUniverseFrame()
		and width >= 512 and length >= 512
end

local function vehiclePassengers(vehicle)
	local passengers, seen = {}, {}
	local list = vehicle.GetEveryone and vehicle:GetEveryone() or { vehicle:GetDriver() }
	for _, ply in ipairs(list or {}) do
		if IsValid(ply) and ply:IsPlayer() and not seen[ply] then
			seen[ply] = true
			passengers[#passengers + 1] = ply
		end
	end
	return passengers
end

local function notifyVehicle(vehicle, message, kind)
	for _, ply in ipairs(vehiclePassengers(vehicle)) do
		if MilBase.Notify then MilBase.Notify(ply, message, kind or "info") end
	end
end

local function vehicleRadius(vehicle)
	local minimum = 80
	local mins, maxs = vehicle:OBBMins(), vehicle:OBBMaxs()
	if isvector(mins) and isvector(maxs) then
		minimum = math.max(minimum, mins:Length(), maxs:Length())
	end
	return minimum
end

local function hasPlayerDriver(vehicle)
	local driver = vehicle.GetDriver and vehicle:GetDriver()
	return IsValid(driver) and driver:IsPlayer()
end

local function skyboxWallAhead(vehicle)
	local velocity = vehicle:GetVelocity()
	local speed = velocity:Length()
	if speed < math.max(1, tonumber(gd.LVSDeepSpaceMinimumEntrySpeed) or 130) then return nil end
	local direction = velocity / speed
	local lookAhead = math.Clamp(speed * math.max(0.02,
		tonumber(gd.LVSDeepSpaceWallLookAheadSeconds) or 0.15),
		math.max(32, tonumber(gd.LVSDeepSpaceWallLookAheadMinimum) or 160),
		math.max(64, tonumber(gd.LVSDeepSpaceWallLookAheadMaximum) or 1500))
	local trace = util.TraceLine({
		start = vehicle:WorldSpaceCenter(),
		endpos = vehicle:WorldSpaceCenter() + direction * lookAhead,
		filter = function(entity)
			return entity == vehicle or entity:GetParent() == vehicle
		end,
		mask = MASK_SOLID_BRUSHONLY,
	})
	local texture = string.lower(tostring(trace.HitTexture or ""))
	if not trace.Hit or not (trace.HitSky or string.find(texture, "toolsskybox", 1, true)) then
		return nil
	end
	return {
		pos = trace.HitPos,
		ang = direction:Angle(),
		label = "Skybox boundary",
	}
end

local function universeDirection(worldDirection, shipAngles)
	local direction = WorldToLocal(worldDirection, angle_zero, vector_origin, shipAngles)
	if direction:LengthSqr() <= 0.0001 then direction = Vector(1, 0, 0) end
	direction:Normalize()
	return direction
end

local function calculateWorld(universePos)
	local ok, worldPos = pcall(SWU.CalculateWorldPos, SWU, universePos)
	if ok and isvector(worldPos) then return worldPos end
	return nil
end

local function worldToUniverse(worldPos, shipAngles, scale)
	local localPos = WorldToLocal(worldPos, angle_zero, SWU.Controller:GetPos(), shipAngles)
	return SWU.Controller:GetShipPos() + localPos / scale
end

local function skyboxBoundsForVehicle(radius)
	local _, _, minimum, maximum = G.SkyboxFrame()
	local inset = math.max(radius + 32, tonumber(gd.LVSDeepSpaceBoundaryInset) or 180)
	if (maximum.x - minimum.x) <= inset * 2 or (maximum.y - minimum.y) <= inset * 2
		or (maximum.z - minimum.z) <= inset * 2 then
		return nil
	end
	return minimum + Vector(inset, inset, inset), maximum - Vector(inset, inset, inset)
end

local function clampToSkybox(position, radius)
	local minimum, maximum = skyboxBoundsForVehicle(radius)
	if not minimum then return nil, false end
	local clamped = Vector(
		math.Clamp(position.x, minimum.x, maximum.x),
		math.Clamp(position.y, minimum.y, maximum.y),
		math.Clamp(position.z, minimum.z, maximum.z)
	)
	return clamped, clamped:DistToSqr(position) > 0.01
end

local function setVehiclePosition(vehicle, position, angles)
	if not IsValid(vehicle) then return end
	vehicle:SetPos(position)
	if isangle(angles) then vehicle:SetAngles(angles) end
	local physics = vehicle:GetPhysicsObject()
	if IsValid(physics) then physics:Wake() end
end

local function stateCount()
	local count = 0
	for vehicle in pairs(G.DeepSpaceVehicles) do
		if IsValid(vehicle) then count = count + 1 end
	end
	return count
end

local function canEnter(vehicle)
	if not deepSpaceReady() or not (IsValid(vehicle) and vehicle.LVS == true)
		or not hasPlayerDriver(vehicle) then return false, "Only a player-flown LVS craft can enter deep space." end
	if G.DeepSpaceVehicles[vehicle] then return false, "This craft is already in deep space." end
	if stateCount() >= math.max(1, math.floor(tonumber(gd.LVSDeepSpaceMaximumVehicles) or 8)) then
		return false, "Deep-space traffic control is at capacity."
	end
	if vehicleRadius(vehicle) > math.max(100, tonumber(gd.LVSDeepSpaceMaximumVehicleRadius) or 950) then
		return false, "This LVS craft is too large for the deep-space transit lane."
	end
	return true
end

function G.EnterDeepSpace(vehicle, gateway)
	local allowed, reason = canEnter(vehicle)
	if not allowed then return false, reason end
	if not gateway or not isvector(gateway.pos) then return false, "No skybox boundary was detected." end

	local controller = SWU.Controller
	local shipAngles = controller:GetInternalShipAngles()
	local scale = math.max(0.0001, math.abs(tonumber(SWU.config.scale) or 1))
	local travelDirection = flatForward(gateway.ang)
	local universeDirectionValue = universeDirection(travelDirection, shipAngles)
	local departureDistance = math.max(0.4, tonumber(gd.LVSDeepSpaceUniverseEntryDistance) or 2.6)
	local returnUniversePos = controller:GetShipPos() + universeDirectionValue * departureDistance
	local spawnUniversePos = returnUniversePos + universeDirectionValue * 0.24
	local spawnWorldPos = calculateWorld(spawnUniversePos)
	local radius = vehicleRadius(vehicle)
	if not spawnWorldPos then return false, "Star Wars Universe could not calculate the skybox position." end
	if not util.IsInWorld(spawnWorldPos) then
		return false, "The SWU deep-space position is outside this map's world bounds."
	end
	spawnWorldPos = clampToSkybox(spawnWorldPos, radius)
	if not spawnWorldPos then return false, "The configured 3D skybox is too small for this LVS craft." end

	local velocity = vehicle:GetVelocity()
	setVehiclePosition(vehicle, spawnWorldPos, vehicle:GetAngles())
	local physics = vehicle:GetPhysicsObject()
	if IsValid(physics) then physics:SetVelocity(velocity) end
	vehicle:SetNW2Bool("MBGalaxyDeepSpace", true)
	vehicle:AddEFlags(EFL_FORCE_CHECK_TRANSMIT)

	G.DeepSpaceVehicles[vehicle] = {
		gateway = gateway,
		universePos = spawnUniversePos,
		returnUniversePos = returnUniversePos,
		universeDirection = universeDirectionValue,
		entryWorldDirection = travelDirection,
		lastWorldPos = Vector(spawnWorldPos),
		enteredAt = CurTime(),
		unoccupiedAt = nil,
		lastBoundaryNotice = 0,
	}
	notifyVehicle(vehicle, "Deep-space transit complete. Your LVS craft is now flying in the SWU skybox.", "ok")
	return true
end

local function restoreMapSpace(vehicle, state, automatic)
	if not (IsValid(vehicle) and state and state.gateway) then return false end
	local gateway = state.gateway
	local inward = -flatForward(gateway.ang)
	local exitInset = math.max(96, tonumber(gd.LVSDeepSpaceMapExitInset) or 540)
	local exitPosition = gateway.pos + inward * exitInset
	if not util.IsInWorld(exitPosition) then
		exitPosition = gateway.pos - flatForward(gateway.ang) * 96
	end
	local oldVelocity = vehicle:GetVelocity()
	local speed = math.Clamp(oldVelocity:Length(), 0,
		math.max(1, tonumber(gd.LVSDeepSpaceMinimumEntrySpeed) or 130) * 8)
	setVehiclePosition(vehicle, exitPosition, inward:Angle())
	local physics = vehicle:GetPhysicsObject()
	if IsValid(physics) then physics:SetVelocity(inward * speed) end
	vehicle:SetNW2Bool("MBGalaxyDeepSpace", false)
	G.DeepSpaceVehicles[vehicle] = nil
	notifyVehicle(vehicle, automatic
		and "Deep-space craft returned to the map after the crew left it unattended."
		or "Deep-space exit complete. You have returned to local map space.", "ok")
	return true
end

function G.ExitDeepSpace(vehicle, automatic)
	return restoreMapSpace(vehicle, G.DeepSpaceVehicles[vehicle], automatic == true)
end

local function returnLaneCrossed(vehicle, state)
	if CurTime() < state.enteredAt + math.max(0.5, tonumber(gd.LVSDeepSpaceTransitGrace) or 4) then
		return false
	end
	local returnWorld = calculateWorld(state.returnUniversePos)
	if not returnWorld then return false end
	local radius = math.max(64, tonumber(gd.LVSDeepSpaceReturnRadius) or 190)
	if vehicle:WorldSpaceCenter():DistToSqr(returnWorld) > radius * radius then return false end
	local direction = state.entryWorldDirection
	local velocity = vehicle:GetVelocity()
	return velocity:Dot(direction) <= -math.max(1,
		tonumber(gd.LVSDeepSpaceReturnMinimumSpeed) or 90)
end

local function updateDeepSpaceVehicle(vehicle, state)
	if not IsValid(vehicle) then
		G.DeepSpaceVehicles[vehicle] = nil
		return
	end
	if not deepSpaceReady() then
		restoreMapSpace(vehicle, state, true)
		return
	end
	local controller = SWU.Controller
	local now = CurTime()
	local shipAngles = controller:GetInternalShipAngles()
	local scale = math.max(0.0001, math.abs(tonumber(SWU.config.scale) or 1))
	local currentPosition = vehicle:GetPos()
	local physicalDelta = currentPosition - (state.lastWorldPos or currentPosition)
	if physicalDelta:LengthSqr() > 0.0001 then
		local universeDelta = WorldToLocal(physicalDelta, angle_zero, vector_origin, shipAngles) / scale
		state.universePos = state.universePos + universeDelta
	end

	local desiredWorld = calculateWorld(state.universePos)
	if not desiredWorld then
		restoreMapSpace(vehicle, state, true)
		return
	end
	local clampedWorld, hitBoundary = clampToSkybox(desiredWorld, vehicleRadius(vehicle))
	if not clampedWorld then
		restoreMapSpace(vehicle, state, true)
		return
	end
	if hitBoundary then
		state.universePos = worldToUniverse(clampedWorld, shipAngles, scale)
		desiredWorld = clampedWorld
		local physics = vehicle:GetPhysicsObject()
		if IsValid(physics) then physics:SetVelocity(vector_origin) end
		if now >= (state.lastBoundaryNotice or 0) + 4 then
			state.lastBoundaryNotice = now
			notifyVehicle(vehicle, "Deep-space boundary reached. Turn back toward the transit lane.", "warn")
		end
	end

	if desiredWorld:DistToSqr(currentPosition) > 0.01 then
		setVehiclePosition(vehicle, desiredWorld)
	end
	state.lastWorldPos = Vector(desiredWorld)

	if returnLaneCrossed(vehicle, state) then
		restoreMapSpace(vehicle, state, false)
		return
	end
	if #vehiclePassengers(vehicle) == 0 then
		state.unoccupiedAt = state.unoccupiedAt or now
		if now >= state.unoccupiedAt + math.max(5,
			tonumber(gd.LVSDeepSpaceUnoccupiedReturnDelay) or 20) then
			restoreMapSpace(vehicle, state, true)
		end
	else
		state.unoccupiedAt = nil
	end
end

timer.Create("MilBase.GalaxyDeepSpaceThink", math.max(0.02,
	tonumber(gd.LVSDeepSpaceUpdateInterval) or 0.05), 0, function()
	if not deepSpaceReady() then return end
	for vehicle, state in pairs(G.DeepSpaceVehicles) do
		updateDeepSpaceVehicle(vehicle, state)
	end
	if not LVS or not LVS.GetVehicles then return end
	for _, vehicle in pairs(LVS:GetVehicles()) do
		if IsValid(vehicle) and not G.DeepSpaceVehicles[vehicle] and hasPlayerDriver(vehicle) then
			local boundary = skyboxWallAhead(vehicle)
			if boundary then G.EnterDeepSpace(vehicle, boundary) end
		end
	end
end)

hook.Add("SetupPlayerVisibility", "MilBase.GalaxyDeepSpacePVS", function()
	for vehicle in pairs(G.DeepSpaceVehicles) do
		if IsValid(vehicle) then AddOriginToPVS(vehicle:GetPos()) end
	end
end)

concommand.Add("mb_galaxy_deepspace_return", function(ply)
	if not IsValid(ply) then return end
	local vehicle = ply.lvsGetVehicle and ply:lvsGetVehicle() or nil
	if not (IsValid(vehicle) and vehicle:GetDriver() == ply and G.DeepSpaceVehicles[vehicle]) then
		if MilBase.Notify then MilBase.Notify(ply, "You are not piloting a deep-space LVS craft.", "warn") end
		return
	end
	G.ExitDeepSpace(vehicle, false)
end)

hook.Add("PostCleanupMap", "MilBase.GalaxyDeepSpaceMapCleanup", function()
	G.DeepSpaceVehicles = setmetatable({}, { __mode = "k" })
end)
