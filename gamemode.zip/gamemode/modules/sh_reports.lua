--[[
	Reports & admin sits.

	Players alert staff with @ <text>. Online staff see alerts as
	popup cards top-left (hold C for the cursor, then CLAIM or DISMISS).
	Claiming starts a SIT: the staff member and the reporter are teleported
	to a sit area (/sitspot add|remove, persisted per map); everyone in a
	sit is protected - no damage dealt or taken - and is returned to their
	original position by /endsit.

	Commands: @ <text>, /sit (aimed player), /sitadd <name>, /endsit,
	/sitspot add|remove (level 3+).
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Commands (registered SHARED so they list in F4 HELP; funcs run server-side)
--------------------------------------------------------------------------

-- The @ staff-alert prefix is handled in core/sv_chat.lua.

MilBase.RegisterChatCommand("sit", {
	help = "(Staff) Start a sit with the player you're aiming at (or alone).",
	func = function(ply) MilBase.SitCmd(ply) end,
})

MilBase.RegisterChatCommand("sitadd", {
	help = "(Staff) Pull a player into your sit: /sitadd <part of name>",
	func = function(ply, args) MilBase.SitAdd(ply, string.lower(table.concat(args, " "))) end,
})

MilBase.RegisterChatCommand("endsit", {
	help = "(Staff) End your sit and return everyone to where they were.",
	func = function(ply)
		if not MilBase.EndSit(ply) then MilBase.Notify(ply, "You have no sit running.") end
	end,
})

MilBase.RegisterChatCommand("sitspot", {
	help = "(Staff 3+) Sit areas: /sitspot add|remove",
	func = function(ply, args) MilBase.SitSpotCmd(ply, string.lower(args[1] or "")) end,
})

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_Reports")
	util.AddNetworkString("MilBase_ReportAct")

	MilBase.Reports = MilBase.Reports or {}   -- [id] = { reporter=ply, text, time }
	local nextReportID = 1

	-- Periodic player-facing reminder. Recreating/removing the timer here also
	-- makes config changes take effect cleanly after a Lua refresh.
	local reminderTimer = "MilBase.StaffAlertReminder"
	timer.Remove(reminderTimer)
	if cfg.StaffReminderEnabled ~= false then
		local interval = math.max(60, tonumber(cfg.StaffReminderInterval) or 1800)
		timer.Create(reminderTimer, interval, 0, function()
			MilBase.ChatMsg(nil, Color(255, 198, 60),
				tostring(cfg.StaffReminderText or "If you need staff alert them with @"))
		end)
	end

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_sitspots ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map VARCHAR(64), pos TEXT )")

	local sitSpots = {}
	local function loadSpots(cb)
		MilBase.DB.Query(string.format(
			"SELECT * FROM frontier_sitspots WHERE map = %s", MilBase.SQLStr(game.GetMap())), function(rows)
			sitSpots = {}
			for _, row in ipairs(rows) do
				sitSpots[#sitSpots + 1] = { id = tonumber(row.id), pos = util.StringToType(row.pos, "Vector") }
			end
			if cb then cb() end
		end)
	end
	hook.Add("InitPostEntity", "MilBase.SitSpots", function() loadSpots() end)

	local function staffTargets(level)
		local out = {}
		for _, p in ipairs(player.GetAll()) do
			if p:MBStaffLevel() >= (level or 1) then out[#out + 1] = p end
		end
		return out
	end

	local function syncReports()
		local list = {}
		for id, r in pairs(MilBase.Reports) do
			list[#list + 1] = {
				id = id,
				name = IsValid(r.reporter) and r.reporter:MBName() or "(disconnected)",
				text = r.text,
				time = r.time,
			}
		end
		net.Start("MilBase_Reports")
			net.WriteString(util.TableToJSON(list))
		net.Send(staffTargets(cfg.StaffModeLevel or 1))
	end

	----------------------------------------------------------------
	-- Sits
	----------------------------------------------------------------

	local activeSits = {}  -- [staffPly] = { members = {ply...}, spot = idx or nil }
	local spotInUse = {}   -- [spotIdx] = true

	local function addToSit(sit, ply, spotPos, offset)
		if ply:GetNWBool("mb_insit", false) then return end
		ply.mb_sitReturn = ply:GetPos()
		ply:SetNWBool("mb_insit", true)
		if MilBase.CloseCharacterSwitchMenu then
			MilBase.CloseCharacterSwitchMenu(ply)
		end
		table.insert(sit.members, ply)
		if spotPos then
			ply:SetPos(spotPos + Vector(math.cos(offset) * 60, math.sin(offset) * 60, 4))
		end
	end

	function MilBase.StartSit(staff, players)
		if activeSits[staff] then
			MilBase.Notify(staff, "You already have a sit running — /endsit first.")
			return false
		end

		-- Pick a free sit spot (round-robin over unused ones).
		local spotIdx, spotPos
		for i, s in ipairs(sitSpots) do
			if not spotInUse[i] then spotIdx, spotPos = i, s.pos break end
		end
		if spotIdx then spotInUse[spotIdx] = true end

		local sit = { members = {}, spot = spotIdx }
		activeSits[staff] = sit

		addToSit(sit, staff, spotPos, 0)
		local n = 1
		for _, p in ipairs(players or {}) do
			if IsValid(p) and p:Alive() then
				addToSit(sit, p, spotPos, n * (math.pi * 2 / math.max(#players + 1, 2)))
				n = n + 1
				MilBase.Notify(p, "You've been brought into an admin sit with " .. staff:MBName() .. ".")
			end
		end

		if not spotPos then
			MilBase.Notify(staff, "Sit started in place (no /sitspot areas on this map).")
		end
		if MilBase.Log then
			MilBase.Log("staff", MilBase.LogTag(staff) .. " started a sit ("
				.. (#sit.members - 1) .. " player(s))", staff)
		end
		return true
	end

	function MilBase.EndSit(staff)
		local sit = activeSits[staff]
		if not sit then return false end
		activeSits[staff] = nil
		if sit.spot then spotInUse[sit.spot] = nil end

		for _, p in ipairs(sit.members) do
			if IsValid(p) then
				p:SetNWBool("mb_insit", false)
				if p.mb_sitReturn and p:Alive() then p:SetPos(p.mb_sitReturn) end
				p.mb_sitReturn = nil
			end
		end
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(staff) .. " ended their sit", staff) end
		return true
	end

	-- Nobody in a sit deals or takes damage.
	hook.Add("EntityTakeDamage", "MilBase.SitProtect", function(ent, dmg)
		if IsValid(ent) and ent:IsPlayer() and ent:GetNWBool("mb_insit", false) then return true end
		local attacker = dmg:GetAttacker()
		if IsValid(attacker) and attacker:IsPlayer() and attacker:GetNWBool("mb_insit", false) then
			return true
		end
	end)

	-- Death/respawn or disconnect drop you out of the sit cleanly.
	hook.Add("PlayerSpawn", "MilBase.SitReset", function(ply)
		if ply:GetNWBool("mb_insit", false) then
			ply:SetNWBool("mb_insit", false)
			ply.mb_sitReturn = nil
			for _, sit in pairs(activeSits) do table.RemoveByValue(sit.members, ply) end
		end
	end)

	hook.Add("PlayerDisconnected", "MilBase.SitLeave", function(ply)
		if activeSits[ply] then MilBase.EndSit(ply) end
		for _, sit in pairs(activeSits) do table.RemoveByValue(sit.members, ply) end
	end)

	----------------------------------------------------------------
	-- Reports
	----------------------------------------------------------------

	function MilBase.FileReport(ply, text)
		if #text < 3 then
			MilBase.Notify(ply, "Describe the problem: @ <what happened>")
			return
		end
		if (ply.mb_nextReport or 0) > CurTime() then
			MilBase.Notify(ply, "Please wait before reporting again.")
			return
		end
		ply.mb_nextReport = CurTime() + (cfg.ReportCooldown or 30)

		local id = nextReportID
		nextReportID = nextReportID + 1
		MilBase.Reports[id] = { reporter = ply, text = string.sub(text, 1, 180), time = os.time() }

		syncReports()
		MilBase.Notify(ply, "Report filed — staff have been alerted.")
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " reported: " .. text, ply) end
	end

	net.Receive("MilBase_ReportAct", function(_, ply)
		if ply:MBStaffLevel() < (cfg.StaffModeLevel or 1) then return end
		local id = net.ReadUInt(16)
		local claim = net.ReadBool()

		local report = MilBase.Reports[id]
		if not report then return end
		MilBase.Reports[id] = nil

		if claim then
			if IsValid(report.reporter) then
				MilBase.Notify(report.reporter, ply:MBName() .. " is handling your report.")
				MilBase.StartSit(ply, { report.reporter })
			else
				MilBase.Notify(ply, "The reporter has disconnected.")
			end
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " claimed report #" .. id, ply) end
		else
			if IsValid(report.reporter) then
				MilBase.Notify(report.reporter, "Your report was reviewed and closed.")
			end
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " dismissed report #" .. id, ply) end
		end
		syncReports()
	end)

	hook.Add("PlayerDisconnected", "MilBase.ReportLeave", function(ply)
		local changed = false
		for id, r in pairs(MilBase.Reports) do
			if r.reporter == ply then r.reporter = nil changed = true end
		end
		if changed then syncReports() end
	end)

	----------------------------------------------------------------
	-- Sit commands
	----------------------------------------------------------------

	local function isStaff(ply) return ply:MBStaffLevel() >= (cfg.StaffModeLevel or 1) end

	function MilBase.SitCmd(ply, target)
		if not isStaff(ply) then MilBase.Notify(ply, "Staff only.") return end
		target = target or ply:GetEyeTrace().Entity
		local list = {}
		if IsValid(target) and target:IsPlayer() and target ~= ply then list[1] = target end
		MilBase.StartSit(ply, list)
	end

	function MilBase.SitAdd(ply, needle)
		if not isStaff(ply) then MilBase.Notify(ply, "Staff only.") return end
		local sit = activeSits[ply]
		if not sit then MilBase.Notify(ply, "Start a sit first (/sit).") return end
		if needle == "" then MilBase.Notify(ply, "/sitadd <part of name>") return end

		for _, p in ipairs(player.GetAll()) do
			if string.find(string.lower(p:MBName()), needle, 1, true)
			or string.find(string.lower(p:Nick()), needle, 1, true) then
				local spotPos = sit.spot and sitSpots[sit.spot] and sitSpots[sit.spot].pos or ply:GetPos()
				addToSit(sit, p, spotPos, math.Rand(0, math.pi * 2))
				MilBase.Notify(p, "You've been brought into an admin sit with " .. ply:MBName() .. ".")
				MilBase.Notify(ply, "Added " .. p:MBName() .. " to the sit.")
				if MilBase.Log then
					MilBase.Log("staff", MilBase.LogTag(ply) .. " added " .. MilBase.LogTag(p) .. " to their sit", ply, p)
				end
				return
			end
		end
		MilBase.Notify(ply, "No player matching '" .. needle .. "'.")
	end

	function MilBase.SitSpotCmd(ply, sub)
		if ply:MBStaffLevel() < 3 then MilBase.Notify(ply, "Staff level 3+ only.") return end

		if sub == "add" then
			local pos = ply:GetEyeTrace().HitPos + Vector(0, 0, 8)
			MilBase.DB.Run(string.format("INSERT INTO frontier_sitspots (map, pos) VALUES (%s, %s)",
				MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(tostring(pos))))
			loadSpots(function()
				MilBase.Notify(ply, "Sit area added (" .. #sitSpots .. " on this map).")
			end)
		elseif sub == "remove" then
			local nearest, dist
			for _, s in ipairs(sitSpots) do
				local d = s.pos:DistToSqr(ply:GetPos())
				if not dist or d < dist then nearest, dist = s, d end
			end
			if not nearest or dist > 500 * 500 then
				MilBase.Notify(ply, "No sit area within 500 units.")
				return
			end
			MilBase.DB.Run("DELETE FROM frontier_sitspots WHERE id = " .. nearest.id)
			loadSpots()
			MilBase.Notify(ply, "Sit area removed.")
		else
			MilBase.Notify(ply, "Usage: /sitspot add|remove (" .. #sitSpots .. " on this map).")
		end
	end

	return
end

--------------------------------------------------------------------------
-- Client: report popup cards (top-left) + sit banner
--------------------------------------------------------------------------

local openReports = {}
local cardPanel

local function rebuildCards()
	if IsValid(cardPanel) then cardPanel:Remove() end
	if #openReports == 0 then return end

	local ui = MilBase.UI
	local W, CARD_H, GAP = 320, 78, 8

	cardPanel = vgui.Create("DPanel")
	cardPanel:SetPos(16, 90)
	cardPanel:SetSize(W, #openReports * (CARD_H + GAP))
	cardPanel:SetMouseInputEnabled(true) -- clickable while the cursor is up (hold C)
	cardPanel:SetKeyboardInputEnabled(false)
	cardPanel.Paint = nil

	for i, r in ipairs(openReports) do
		local card = vgui.Create("DPanel", cardPanel)
		card:SetPos(0, (i - 1) * (CARD_H + GAP))
		card:SetSize(W, CARD_H)
		card.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8, accent = ui.danger })
			draw.SimpleText("REPORT — " .. r.name, "MB.Small", 12, 8, ui.text)
			draw.SimpleText(string.sub(r.text, 1, 46), "MB.Tiny", 12, 28, ui.dim)
			local age = math.max(0, os.time() - (r.time or os.time()))
			draw.SimpleText(math.floor(age / 60) .. "m " .. (age % 60) .. "s ago  •  hold [C] to act",
				"MB.Tiny", 12, h - 18, ui.faint)
		end

		local function act(claim)
			net.Start("MilBase_ReportAct")
				net.WriteUInt(r.id, 16)
				net.WriteBool(claim)
			net.SendToServer()
		end

		local claim = vgui.Create("DButton", card)
		claim:SetText(""); claim:SetSize(70, 24); claim:SetPos(W - 78, 10)
		claim.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
				color = s:IsHovered() and Color(ui.ok.r, ui.ok.g, ui.ok.b, 60) or ui.raised, accent = ui.ok })
			draw.SimpleText("CLAIM", "MB.Tiny", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		claim.DoClick = function() act(true) end

		local dismiss = vgui.Create("DButton", card)
		dismiss:SetText(""); dismiss:SetSize(70, 24); dismiss:SetPos(W - 78, 42)
		dismiss.Paint = function(s, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
				color = s:IsHovered() and Color(ui.danger.r, ui.danger.g, ui.danger.b, 50) or ui.raised })
			draw.SimpleText("DISMISS", "MB.Tiny", w / 2, h / 2, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		dismiss.DoClick = function() act(false) end
	end
end

net.Receive("MilBase_Reports", function()
	local hadReports = #openReports
	openReports = util.JSONToTable(net.ReadString()) or {}
	table.SortByMember(openReports, "id", true)
	rebuildCards()
	if #openReports > hadReports then
		MilBase.PlayUISound("notify")
	end
end)

-- "You are in a sit" banner.
hook.Add("HUDPaint", "MilBase.SitBanner", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:GetNWBool("mb_insit", false) then return end

	local ui = MilBase.UI
	local w, h = 380, 44
	local x, y = ScrW() / 2 - w / 2, 60
	MilBase.DrawPanelBF2(x, y, w, h, { cut = 8, accent = ui.warn })
	draw.SimpleText("⚠ ADMIN SIT — damage disabled", "MB.Small", x + w / 2, y + 13,
		ui.warn, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("You'll be returned to your position when the sit ends.", "MB.Tiny",
		x + w / 2, y + 30, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)
