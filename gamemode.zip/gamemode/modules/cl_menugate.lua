--[[
	Menu gate: the sandbox Spawn menu (Q) and Context menu (C) are staff
	only. Players never needed the spawn menu (prop/tool spawning is already
	admin-restricted), and the context menu only surfaced the RP interaction
	for them anyway.

	So non-staff keep RP access: pressing the context-menu key opens the
	MilBase player menu on whoever they're looking at, instead of the
	sandbox context menu. Staff get both menus as normal.
]]

if SERVER then return end

local function isStaff()
	local lp = LocalPlayer()
	if not IsValid(lp) then return false end
	-- MilBase staff rank OR an actual server admin (so a superadmin who
	-- hasn't been given a MilBase staff rank isn't locked out of sandbox).
	return lp:MBStaffLevel() > 0 or lp:IsAdmin()
end

-- Spawn menu (Q): staff only. Returning false blocks the open.
hook.Add("SpawnMenuOpen", "MilBase.GateSpawn", function()
	return isStaff()
end)

-- Context menu (C): staff only. Backstop in case it's opened by other means.
hook.Add("ContextMenuOpen", "MilBase.GateContext", function()
	if isStaff() then return end
	return false
end)

-- Non-staff: the context-menu key opens the RP player menu on the soldier
-- they're aiming at (line of sight required). Always blocks the sandbox
-- context menu for them.
hook.Add("PlayerBindPress", "MilBase.GateContextRP", function(_, bind, pressed)
	if not pressed then return end
	if not string.find(bind, "+menu_context", 1, true) then return end
	if isStaff() then return end

	local lp = LocalPlayer()
	local ent = lp:GetEyeTrace().Entity
	if IsValid(ent) and ent:IsPlayer() and ent ~= lp then
		MilBase.OpenPlayerMenu(ent)
	end
	return true
end)
