--[[
	Two-life character slots.

	Slot 1 intentionally uses the historical SteamID64 database key. Additional
	slots append :2, :3, etc., so existing characters continue working without a
	migration. Account-wide moderation/staff systems still use SteamID64.
]]

local cfg = MilBase.Config
local NET_OPEN = "MilBase_CharactersOpen"
local NET_SELECT = "MilBase_CharactersSelect"
local NET_REQUEST = "MilBase_CharactersRequest"
local NET_CLOSE = "MilBase_CharactersClose"

local function maxSlots()
	return math.Clamp(math.floor(tonumber(cfg.CharacterSlots) or 2), 1, 8)
end

if SERVER then
	util.AddNetworkString(NET_OPEN)
	util.AddNetworkString(NET_SELECT)
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_CLOSE)

	local function closeCharacterMenu(ply)
		if not IsValid(ply) then return end
		ply.mb_characterMenuOpen = nil
		net.Start(NET_CLOSE)
		net.Send(ply)
	end

	-- Called by custody/moderation systems when a player becomes restrained,
	-- jailed, placed in a sit, or enters staff mode. The server-side SELECT
	-- handler remains authoritative; this also removes any selector that was
	-- opened before the restriction was applied.
	function MilBase.CloseCharacterSwitchMenu(ply)
		if not IsValid(ply) or ply.mb_characterSelectionRequired then return end
		closeCharacterMenu(ply)
	end

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_character_accounts (
		steamid VARCHAR(32) PRIMARY KEY,
		active_slot INTEGER
	)]])

	local function characterKeys(ply)
		local keys = {}
		for slot = 1, maxSlots() do
			keys[slot] = MilBase.CharacterStorageID(ply:SteamID64(), slot)
		end
		return keys
	end

	local function switchBlockedReason(ply, slot)
		if not IsValid(ply) then return "Character switching is unavailable." end
		if slot ~= nil then
			slot = math.floor(tonumber(slot) or 0)
			if slot < 1 or slot > maxSlots() then return "Invalid character slot." end
			if slot == ply:MBCharacterSlot() then return "That character is already active." end
		end
		if ply.mb_characterSwitching then return "A character switch is already in progress." end
		if not ply.mb_fullyLoaded then return "Your current character is still loading." end
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return "Leave the event-enemy role before switching characters." end
		if ply:GetNWBool("mb_staffmode", false) then return "Leave staff mode before switching characters." end
		if ply:GetNWBool("mb_insit", false) then return "You cannot switch characters during an admin sit." end
		if ply:GetNWBool("mb_wounded", false) then return "You cannot switch characters while wounded." end
		if ply:GetNWBool("mb_cuffed", false) then return "You cannot switch characters while restrained." end

		-- Jail is account-wide. Fail closed until the persistent jail query has
		-- completed, otherwise a reconnecting prisoner could switch in the short
		-- window before frontier_jail_active is returned by the database.
		if MilBase.JailLoadActive then
			if ply.mb_jailStateLoadFailed then
				return "Your custody status could not be verified. Try again shortly or contact staff."
			end
			if ply.mb_jailStateLoaded == false then
				return "Your custody status is still loading."
			end
		end
		if ply:GetNWBool("mb_jailed", false) or ply.mb_jailActive
			or (MilBase.JailIsJailed and MilBase.JailIsJailed(ply)) then
			return "You cannot switch characters while jailed or in prison."
		end
		if ply.mb_spawn_selecting and not ply.mb_characterSelectionRequired then
			return "Finish deployment before switching characters."
		end
		if ply:InVehicle() then return "Exit your vehicle before switching characters." end
		if cfg.CharacterSwitchRequiresAlive ~= false and not ply:Alive() and not ply.mb_characterSelectionRequired then
			return "You must be alive to switch characters."
		end
		if (ply.mb_characterCombatUntil or 0) > CurTime() then
			return "You cannot switch characters during combat."
		end
		if (ply.mb_nextCharacterSwitch or 0) > CurTime() then
			return "Wait " .. math.ceil(ply.mb_nextCharacterSwitch - CurTime()) .. " seconds before switching again."
		end
	end

	MilBase.CharacterSwitchBlockedReason = switchBlockedReason

	function MilBase.SendCharacterMenu(ply, openStandalone)
		if not IsValid(ply) then return false end
		if not ply.mb_characterSelectionRequired then
			local blocked = switchBlockedReason(ply)
			if blocked then
				closeCharacterMenu(ply)
				MilBase.Notify(ply, blocked, "warn")
				return false
			end
		end
		local keys = characterKeys(ply)
		local quoted = {}
		for _, key in ipairs(keys) do quoted[#quoted + 1] = MilBase.SQLStr(key) end

		local function sendRows(rows)
			if not IsValid(ply) then return end
			if not ply.mb_characterSelectionRequired then
				local blocked = switchBlockedReason(ply)
				if blocked then
					closeCharacterMenu(ply)
					return
				end
			end
			rows = rows or {}
			local byKey = {}
			for _, row in ipairs(rows) do byKey[tostring(row.steamid or "")] = row end
			local summaries = {}
			for slot, key in ipairs(keys) do
				local row = byKey[key]
				if slot == ply:MBCharacterSlot() and ply.mb_dataLoaded then
					row = {
						steamid = key, name = ply:GetNWString("mb_name", ""),
						faction = ply:MBFactionID(), rank = ply:MBRankIndex(), money = ply:MBMoney(),
					}
				end
				local factionID = row and tostring(row.faction or "") or cfg.DefaultFaction
				local faction = MilBase.GetFaction(factionID) or MilBase.GetFaction(cfg.DefaultFaction)
				local rankIndex = row and tonumber(row.rank) or 1
				rankIndex = math.Clamp(math.floor(rankIndex or 1), 1, faction and #faction.ranks or 1)
				local rank = faction and faction.ranks[rankIndex]
				local models = (rank and rank.models) or (faction and faction.models) or {}
				local model = models[1] or "models/player/group01/male_02.mdl"
				if slot == ply:MBCharacterSlot() and ply.mb_dataLoaded and util.IsValidModel(ply:GetModel()) then
					model = ply:GetModel()
				end
				local factionColor = faction and faction.color or color_white
				summaries[#summaries + 1] = {
					slot = slot,
					exists = row ~= nil,
					name = row and tostring(row.name or "") or "",
					faction = factionID,
					factionName = faction and faction.name or factionID,
					factionDescription = faction and tostring(faction.description or "") or "",
					factionLogo = faction and tostring(faction.logo or "") or "",
					factionColor = {
						r = factionColor.r or 255, g = factionColor.g or 255,
						b = factionColor.b or 255, a = factionColor.a or 255,
					},
					model = model,
					rank = rankIndex,
					rankName = rank and rank.name or ("Rank " .. rankIndex),
					money = row and tonumber(row.money) or cfg.StartingMoney,
				}
			end
			ply.mb_characterMenuOpen = true
			net.Start(NET_OPEN)
				net.WriteTable({
					active = ply:MBCharacterSlot(),
					slots = summaries,
					open = openStandalone == true,
					required = ply.mb_characterSelectionRequired == true,
					switching = ply.mb_characterSwitching == true,
				})
			net.Send(ply)
		end

		MilBase.DB.Query("SELECT steamid, name, faction, `rank`, money FROM frontier_players WHERE steamid IN ("
			.. table.concat(quoted, ",") .. ")", sendRows, function()
			-- A database error should still release the UI with safe empty slots.
			sendRows({})
		end)
	end


	function MilBase.SaveCharacterState(ply)
		if not IsValid(ply) then return end
		MilBase.SavePlayer(ply)
		MilBase.SaveInventory(ply)
		MilBase.SaveProgress(ply)
		if MilBase.SaveArcCWAssets then MilBase.SaveArcCWAssets(ply) end
		if MilBase.SaveNameData then MilBase.SaveNameData(ply) end
		if MilBase.LSCS then
			timer.Remove("MilBase.LSCSInventorySave." .. ply:MBCharacterKey())
			if MilBase.LSCS.SaveProgress then MilBase.LSCS.SaveProgress(ply) end
			if MilBase.LSCS.SaveInventory then MilBase.LSCS.SaveInventory(ply) end
			if MilBase.LSCS.SaveAdvanced then MilBase.LSCS.SaveAdvanced(ply) end
		end
	end

	local function clearCharacterRuntime(ply)
		ply.mb_loadState = {}
		ply.mb_fullyLoaded = false
		ply.mb_dataLoaded = false
		ply.mb_inv = nil
		ply.mb_realInv = nil
		ply.mb_invUID = nil
		ply.mb_unlocked = nil
		ply.mb_equipped = nil
		ply.mb_arccwAssetsLoaded = false
		ply.mb_arccwInventorySynced = false
		ply.mb_arccwLastEntitlement = nil
		ply.mb_arccwOwnedAttachments = {}
		ply.mb_weaponUnlocks = {}
		ply.mb_appearance = {}
		ply:SetNWString("mb_faction", cfg.DefaultFaction)
		ply:SetNWInt("mb_rank", 1)
		ply:SetNWInt("mb_money", 0)
		ply:SetNWString("mb_certs", "")
		ply:SetNWString("mb_temp_certs", "")
		ply:SetNWString("mb_name", "")
		ply:SetNWString("mb_clone_number", "")
		ply:SetNWString("mb_medic_rank", "")
		ply:SetNWInt("mb_spawn_choice", 0)
		ply:SetNWInt("mb_xp", 0)
		ply:SetNWString("mb_equipped", "")
		ply:SetNWFloat("mb_booster_mult", 1)
		ply:SetNWInt("mb_booster_expires", 0)
		ply:SetNWInt("mb_lscs_points", 0)
		ply:SetNWInt("mb_lscs_xp_milestones", 0)
		ply:SetNWBool("mb_lscs_access", false)
		ply:SetNWInt("mb_lscs_alignment", 0)
		ply:SetNWBool("mb_lscs_force_sensitive", false)
		ply:SetNWString("mb_lscs_mentor", "")
		ply:SetNWString("mb_lscs_trial", "")
		ply.mb_characterSpawnChoiceLoadedToken = nil
		ply.mb_characterAwaitSpawnChoice = nil
		ply.mb_spawn_selecting = false
		ply:SetNWBool("mb_spawn_selecting", false)
		ply:SetNWString("mb_spawn_select_reason", "")

		ply.mb_lscsProgressLoaded = false
		ply.mb_lscsInventoryLoaded = false
		ply.mb_lscsInventoryRestored = false
		ply.mb_lscsAdvancedLoaded = false
		ply.mb_lscsSavedInventory = {}
		ply.mb_lscsUnlocked = {}
		ply.mb_lscsActive = {}
		ply.mb_lscsAlignment = 0
		ply.mb_lscsPresets = {}
		ply.mb_lscsTrials = {}
		ply.mb_lscsDiscoveries = {}
		ply.mb_lscsForceSensitive = false
		ply.mb_lscsLastRespec = 0
		ply.mb_lscsMentorSID = ""
		ply.mb_lscsMentorRequests = {}
		ply.mb_lscsWorkbench = nil
		ply.mb_lscsWorkbenchUntil = 0
		ply:SetNWFloat("mb_lscs_workbench_until", 0)
		ply:SetNWBool("mb_lscs_loaded", false)
		ply:SetNWBool("mb_lscs_advanced_loaded", false)
		ply:StripWeapons()
		ply:StripAmmo()
		ply:SetArmor(0)
		ply:StripWeapon("weapon_lscs")
		if ply.lscsWipeInventory then pcall(ply.lscsWipeInventory, ply) end
	end

	function MilBase.LoadCharacterSlot(ply, slot, initialRestore)
		if not IsValid(ply) then return false end
		slot = math.Clamp(math.floor(tonumber(slot) or 1), 1, maxSlots())
		if not initialRestore then
			local blocked = switchBlockedReason(ply, slot)
			if blocked then
				closeCharacterMenu(ply)
				MilBase.Notify(ply, blocked, "warn")
				return false
			end
			ply.mb_characterSelectionMade = true
			ply.mb_characterSelectionRequired = nil
			ply:SetNWBool("mb_character_selecting", false)
		end

		MilBase.SaveCharacterState(ply)
		ply.mb_characterSwitching = true
		ply:SetNWBool("mb_character_switching", true)
		ply:Freeze(true)
		ply:GodEnable()
		clearCharacterRuntime(ply)
		ply:SetNWInt("mb_character_slot", slot)
		ply.mb_characterLoadToken = (ply.mb_characterLoadToken or 0) + 1
		ply.mb_characterSwitchTarget = slot
		ply.mb_characterInitialRestore = initialRestore == true
		if not initialRestore then
			ply.mb_nextCharacterSwitch = CurTime() + math.max(0, tonumber(cfg.CharacterSwitchCooldown) or 30)
		end

		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_character_accounts (steamid, active_slot) VALUES (%s, %d)",
			MilBase.SQLStr(ply:SteamID64()), slot))

		MilBase.LoadPlayer(ply)
		MilBase.LoadInventory(ply)
		MilBase.LoadProgress(ply)
		if MilBase.LoadArcCWAssets then MilBase.LoadArcCWAssets(ply) end
		MilBase.LoadCerts(ply)
		if MilBase.LoadAppearance then MilBase.LoadAppearance(ply) end
		if MilBase.LoadNameData then MilBase.LoadNameData(ply) end
		if MilBase.LSCS then
			if MilBase.LSCS.LoadProgress then MilBase.LSCS.LoadProgress(ply) end
			if MilBase.LSCS.LoadInventory then MilBase.LSCS.LoadInventory(ply) end
			if MilBase.LSCS.LoadAdvanced then MilBase.LSCS.LoadAdvanced(ply) end
			if MilBase.LSCS.ScheduleBootstrap then MilBase.LSCS.ScheduleBootstrap(ply, true) end
		end
		return true
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if (ply.mb_nextCharacterMenuRequest or 0) > CurTime() then return end
		ply.mb_nextCharacterMenuRequest = CurTime() + 0.5
		local openStandalone = net.ReadBool()
		MilBase.SendCharacterMenu(ply, openStandalone)
	end)

	local function continueToDeployment(ply)
		if not IsValid(ply) then return end
		ply.mb_characterSelectionRequired = nil
		ply.mb_characterSelectionMade = true
		ply.mb_characterMenuShown = true
		ply:SetNWBool("mb_character_selecting", false)

		-- The character UI previously depended on the spawn selector opening in
		-- order to close itself. Maps with no eligible deployment points take the
		-- fallback spawn path, so the player spawned behind an infinite loading
		-- overlay. Explicitly acknowledge the accepted character selection first.
		closeCharacterMenu(ply)

		if MilBase.SpawnSelectorBeginSelection then
			if MilBase.SpawnSelectorBeginSelection(ply, "character") then return end
		end

		-- Maps without an eligible deployment point should never leave the
		-- player hidden in the pre-deployment hold state.
		ply.mb_spawn_selecting = false
		ply:SetNWBool("mb_spawn_selecting", false)
		ply:SetNWString("mb_spawn_select_reason", "")
		ply.mb_spawn_allow_next_spawn = true
		timer.Simple(0, function()
			if IsValid(ply) then ply:Spawn() end
		end)
	end

	net.Receive(NET_SELECT, function(_, ply)
		if (ply.mb_nextCharacterSelectRequest or 0) > CurTime() then return end
		ply.mb_nextCharacterSelectRequest = CurTime() + 0.35
		local slot = math.Clamp(net.ReadUInt(4), 1, maxSlots())
		if ply.mb_characterSelectionRequired and slot == ply:MBCharacterSlot() then
			if not ply.mb_fullyLoaded then
				MilBase.Notify(ply, "That character is still loading.", "warn")
				MilBase.SendCharacterMenu(ply, true)
				return
			end
			continueToDeployment(ply)
			return
		end

		MilBase.LoadCharacterSlot(ply, slot, false)
	end)

	MilBase.RegisterChatCommand("characters", {
		help = "Open your character selector.",
		func = function(ply) MilBase.SendCharacterMenu(ply, true) end,
	})
	MilBase.RegisterChatCommand("char", {
		help = "Open your character selector.",
		func = function(ply) MilBase.SendCharacterMenu(ply, true) end,
	})

	hook.Add("EntityTakeDamage", "MilBase.CharacterCombatLock", function(target, dmg)
		local untilTime = CurTime() + math.max(0, tonumber(cfg.CharacterCombatLock) or 30)
		if IsValid(target) and target:IsPlayer() then target.mb_characterCombatUntil = untilTime end
		local attacker = dmg:GetAttacker()
		if IsValid(attacker) and attacker:IsPlayer() and attacker ~= target then
			attacker.mb_characterCombatUntil = untilTime
		end
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.CharacterSlots.Initialise", function(ply)
		ply:SetNWInt("mb_character_slot", 1)
		ply.mb_characterLoadToken = 1
		ply.mb_characterSelectionRequired = cfg.CharacterRequireSelectionBeforeDeploy ~= false
		ply:SetNWBool("mb_character_selecting", ply.mb_characterSelectionRequired == true)
		local function restoreSlot(rows)
			if not IsValid(ply) then return end
			local wanted = rows and rows[1] and tonumber(rows[1].active_slot) or 1
			wanted = math.Clamp(math.floor(wanted or 1), 1, maxSlots())
			if ply.mb_characterSelectionMade then return end
			if ply.mb_fullyLoaded and wanted ~= ply:MBCharacterSlot() then
				MilBase.LoadCharacterSlot(ply, wanted, true)
			else
				ply.mb_characterRestoreSlot = wanted
			end
		end
		MilBase.DB.Query("SELECT active_slot FROM frontier_character_accounts WHERE steamid = "
			.. MilBase.SQLStr(ply:SteamID64()), restoreSlot, function() restoreSlot({}) end)
	end)

	local function finishCharacterSwitch(ply)
		if not IsValid(ply) or not ply.mb_characterSwitching then return end
		local slot = ply.mb_characterSwitchTarget or ply:MBCharacterSlot()
		local initialRestore = ply.mb_characterInitialRestore == true
		ply.mb_characterSwitching = nil
		ply.mb_characterSwitchTarget = nil
		ply.mb_characterInitialRestore = nil
		ply.mb_characterAwaitSpawnChoice = nil
		ply:SetNWBool("mb_character_switching", false)
		if not initialRestore then closeCharacterMenu(ply) end
		if not initialRestore and cfg.SpawnSelectorEnabled ~= false
			and cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false then
			ply.mb_spawn_selecting = true
			ply:SetNWBool("mb_spawn_selecting", true)
			ply:SetNWString("mb_spawn_select_reason", "character")
		end
		timer.Simple(0, function()
			if not IsValid(ply) then return end
			ply:Spawn()
			-- The deployment selector may intentionally keep the player frozen and
			-- hidden until a spawn is chosen. Do not undo that hold here.
			if not ply.mb_spawn_selecting then
				ply:Freeze(false)
				ply:GodDisable()
			end

			if initialRestore then
				ply.mb_characterMenuShown = true
				MilBase.SendCharacterMenu(ply, ply.mb_characterSelectionRequired or cfg.CharacterMenuOpenOnJoin ~= false)
			else
				MilBase.Notify(ply, "Character " .. slot .. " is now active.", "ok")
				-- GM:PlayerSpawn opens the forced deployment selector because the
				-- selected character was marked pending immediately before the spawn.
			end
		end)
	end

	hook.Add("MilBase.SpawnChoiceLoaded", "MilBase.CharacterSlots.SpawnChoiceReady", function(ply, _, token)
		if not IsValid(ply) or not ply.mb_characterSwitching then return end
		if token ~= ply:MBCharacterLoadToken() then return end
		ply.mb_characterSpawnChoiceLoadedToken = token
		finishCharacterSwitch(ply)
	end)

	hook.Add("MilBase.PlayerLoaded", "MilBase.CharacterSlots.Complete", function(ply)
		if not IsValid(ply) then return end
		local restore = ply.mb_characterRestoreSlot
		if restore then
			ply.mb_characterRestoreSlot = nil
			if restore ~= ply:MBCharacterSlot() then
				timer.Simple(0, function()
					if IsValid(ply) then MilBase.LoadCharacterSlot(ply, restore, true) end
				end)
				return
			end
		end

		if ply.mb_characterSwitching then
			local token = ply:MBCharacterLoadToken()
			local waitsForSpawnChoice = cfg.SpawnSelectorEnabled ~= false
				and MilBase.SpawnSelector ~= nil
			if waitsForSpawnChoice and ply.mb_characterSpawnChoiceLoadedToken ~= token then
				ply.mb_characterAwaitSpawnChoice = true
				-- A failed external DB response must not leave a player frozen forever.
				timer.Simple(5, function()
					if not IsValid(ply) or not ply.mb_characterSwitching then return end
					if ply:MBCharacterLoadToken() ~= token then return end
					if cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false then
						ply.mb_spawn_selecting = true
						ply:SetNWBool("mb_spawn_selecting", true)
						ply:SetNWString("mb_spawn_select_reason", "character")
					end
					finishCharacterSwitch(ply)
				end)
			else
				finishCharacterSwitch(ply)
			end
		elseif not ply.mb_characterMenuShown then
			ply.mb_characterMenuShown = true
			if ply.mb_characterSelectionRequired or cfg.CharacterMenuOpenOnJoin ~= false then
				timer.Simple(0.35, function()
					if IsValid(ply) then MilBase.SendCharacterMenu(ply, true) end
				end)
			end
		end
	end)

	return
end

-- Client -----------------------------------------------------------------

MilBase.CharacterSummaries = MilBase.CharacterSummaries or {}
MilBase.CharacterActiveSlot = MilBase.CharacterActiveSlot or 1
local characterFrame

local function requestCharacters(openStandalone)
	net.Start(NET_REQUEST)
		net.WriteBool(openStandalone == true)
	net.SendToServer()
end

local function summaryColor(summary)
	local c = summary and summary.factionColor or nil
	return Color(
		math.Clamp(tonumber(c and c.r) or 255, 0, 255),
		math.Clamp(tonumber(c and c.g) or 198, 0, 255),
		math.Clamp(tonumber(c and c.b) or 60, 0, 255),
		math.Clamp(tonumber(c and c.a) or 255, 0, 255)
	)
end

local function closeCharacterSelector()
	if IsValid(characterFrame) then characterFrame:Remove() end
	characterFrame = nil
end

function MilBase.CloseCharacterSelector()
	closeCharacterSelector()
end

local function submitCharacter(slot)
	if IsValid(characterFrame) then
		if characterFrame.mb_pending then return end
		characterFrame.mb_pending = true
		characterFrame.mb_pendingSlot = slot
		characterFrame.mb_pendingStarted = CurTime()
		characterFrame.mb_pendingRefreshSent = nil
	end
	MilBase.PlayUISound("select")
	net.Start(NET_SELECT)
		net.WriteUInt(slot, 4)
	net.SendToServer()
end

local function selectCharacter(slot, required)
	if required then
		submitCharacter(slot)
		return
	end

	Derma_Query("Switch to character " .. slot .. "? Your current life will be saved before the new one is loaded.",
		"Switch Character", "SWITCH", function() submitCharacter(slot) end, "CANCEL")
end

local function characterName(summary)
	if summary.name and summary.name ~= "" then return summary.name end
	return summary.exists and "UNNAMED CHARACTER" or "NEW CHARACTER"
end

local function selectionLabel(summary, required)
	local active = summary.slot == MilBase.CharacterActiveSlot
	if required then
		if active then return "CONTINUE TO DEPLOYMENT" end
		return summary.exists and "SELECT & DEPLOY" or "CREATE & DEPLOY"
	end
	if active then return "CURRENTLY ACTIVE" end
	return summary.exists and "SWITCH CHARACTER" or "CREATE CHARACTER"
end

local function configureModelPanel(panel, model)
	model = tostring(model or "")
	if model == "" or not util.IsValidModel(model) then
		model = "models/player/group01/male_02.mdl"
	end
	panel:SetModel(model)
	panel:SetFOV(34)
	panel:SetCamPos(Vector(72, 8, 58))
	panel:SetLookAt(Vector(0, 0, 48))
	panel:SetAnimated(false)
	function panel:LayoutEntity(ent)
		if not IsValid(ent) then return end
		ent:SetAngles(Angle(0, 25, 0))
	end
end

local function buildSelectorCard(parent, summary, required, cardW, cardH)
	local ui = MilBase.UI
	local accent = summaryColor(summary)
	local active = summary.slot == MilBase.CharacterActiveSlot

	local card = vgui.Create("DPanel", parent)
	card:SetSize(cardW, cardH)
	card.Paint = function(self, w, h)
		local hovered = IsValid(self.mb_button) and self.mb_button:IsHovered() and self.mb_button:IsEnabled()
		local fill = active and Color(accent.r, accent.g, accent.b, 20)
			or (hovered and ui.hover or Color(7, 7, 8, 224))
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 11,
			color = fill,
			accent = accent,
			outlineColor = active and Color(accent.r, accent.g, accent.b, 120) or ui.outline,
		})
		MilBase.DrawIcon(ui.art.bf2.sheen, 2, 2, w - 4, 62)
		if hovered then MilBase.DrawBrackets(4, 4, w - 8, h - 8, accent, 13) end

		draw.SimpleText("CHARACTER " .. summary.slot, "MB.Tiny", 18, 16, ui.dim)
		if active then
			draw.SimpleText("ACTIVE LIFE", "MB.Tiny", w - 18, 16, accent, TEXT_ALIGN_RIGHT)
		elseif not summary.exists then
			draw.SimpleText("EMPTY SLOT", "MB.Tiny", w - 18, 16, ui.warn, TEXT_ALIGN_RIGHT)
		end

		local infoY = h - 176
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(1, infoY, w - 2, 175)
		surface.SetDrawColor(accent.r, accent.g, accent.b, 80)
		surface.DrawRect(18, infoY, w - 36, 1)

		draw.SimpleText(string.upper(characterName(summary)), "MB.Big", 18, infoY + 17, ui.text)
		draw.SimpleText(string.upper(summary.rankName or "UNASSIGNED"), "MB.Small", 18, infoY + 57, accent)
		draw.SimpleText(string.upper(summary.factionName or summary.faction or "UNASSIGNED"),
			"MB.Tiny", 18, infoY + 81, ui.dim)

		local credits = (MilBase.Config.CurrencySymbol or "$") .. string.Comma(tonumber(summary.money) or 0)
		draw.SimpleText(credits, "MB.Small", w - 18, infoY + 58, ui.text, TEXT_ALIGN_RIGHT)
		draw.SimpleText(string.upper(MilBase.Config.CurrencyName or "credits"),
			"MB.Tiny", w - 18, infoY + 81, ui.faint, TEXT_ALIGN_RIGHT)
	end

	local model = vgui.Create("DModelPanel", card)
	model:SetPos(12, 42)
	model:SetSize(cardW - 24, cardH - 224)
	configureModelPanel(model, summary.model)
	model:SetMouseInputEnabled(false)

	local logo = tostring(summary.factionLogo or "")
	if logo ~= "" then
		local emblem = vgui.Create("DPanel", card)
		emblem:SetPos(18, 48)
		emblem:SetSize(54, 54)
		emblem.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = Color(0, 0, 0, 155), accent = accent })
			MilBase.DrawIcon(logo, 8, 8, w - 16, h - 16, color_white)
		end
	end

	local button = vgui.Create("DButton", card)
	card.mb_button = button
	button:SetText("")
	button:SetPos(18, cardH - 55)
	button:SetSize(cardW - 36, 38)
	button:SetEnabled(required or not active)
	button.Paint = function(self, w, h)
		local enabled = self:IsEnabled() and not (IsValid(characterFrame) and characterFrame.mb_pending)
		local col = enabled and (self:IsHovered() and Color(accent.r, accent.g, accent.b, 62) or ui.raised)
			or Color(255, 255, 255, 4)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = col, accent = enabled and accent or nil })
		draw.SimpleText(selectionLabel(summary, required), "MB.Small", w / 2, h / 2,
			enabled and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		if IsValid(characterFrame) and characterFrame.mb_pending then return end
		selectCharacter(summary.slot, required)
	end

	return card
end

local function buildStandaloneSelector(payload)
	closeCharacterSelector()
	if MilBase.CloseMenu then MilBase.CloseMenu() end

	local ui = MilBase.UI
	local required = payload.required == true
	local slots = MilBase.CharacterSummaries or {}
	local margin = math.floor(ScrW() * 0.055)
	local bottomH = 44

	local frame = vgui.Create("DFrame")
	characterFrame = frame
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame:SetKeyboardInputEnabled(true)
	frame.mb_required = required
	frame.mb_pending = payload.switching == true
	frame.mb_pendingStarted = frame.mb_pending and CurTime() or nil
	frame.OnRemove = function()
		if characterFrame == frame then characterFrame = nil end
	end
	frame.Think = function(self)
		if gui.IsGameUIVisible() then
			gui.HideGameUI()
			if not self.mb_required and not self.mb_pending then self:Remove() return end
		end

		if not self.mb_pending then return end
		self.mb_pendingStarted = self.mb_pendingStarted or CurTime()
		local elapsed = CurTime() - self.mb_pendingStarted
		local client = LocalPlayer()

		-- Reliable net messages normally close this immediately. This state check
		-- is a second line of defence for old servers, dropped transitions, and the
		-- no-eligible-spawn fallback path. A short grace period avoids closing while
		-- the character_switching NWBool is still being replicated.
		if elapsed >= 1.5 and IsValid(client)
			and not client:GetNWBool("mb_character_switching", false)
			and not client:GetNWBool("mb_character_selecting", false) then
			self:Remove()
			return
		end

		-- If the server rejected or never received the request, refresh the menu
		-- instead of leaving the controls disabled forever.
		if elapsed >= 15 and not self.mb_pendingRefreshSent then
			self.mb_pendingRefreshSent = true
			requestCharacters(true)
		end
	end
	frame.Paint = function(self, w, h)
		if not MilBase.DrawIcon(ui.art.scoreboard, 0, 0, w, h) then MilBase.DrawBlur(self, 6) end
		surface.SetDrawColor(0, 0, 0, 168)
		surface.DrawRect(0, 0, w, h)

		-- F4-style identity header and a deployment-style two-step indicator.
		draw.SimpleText("PERSONNEL", "MB.Med", margin, 24, ui.text)
		draw.SimpleText("SELECT CHARACTER", "MB.Huge", margin, 46, ui.text)
		draw.SimpleText("CHOOSE WHICH LIFE YOU WANT TO DEPLOY AS", "MB.Small", margin + 2, 111, ui.accent)

		if w >= 960 then
			local stepX = w - margin - 310
			draw.SimpleText("01", "MB.NumSmall", stepX, 27, ui.accent)
			draw.SimpleText("CHARACTER", "MB.Small", stepX + 42, 38, ui.text)
			surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 120)
			surface.DrawRect(stepX + 134, 45, 54, 1)
			draw.SimpleText("02", "MB.NumSmall", stepX + 205, 27, ui.faint)
			draw.SimpleText("DEPLOY", "MB.Small", stepX + 247, 38, ui.faint)
		end

		surface.SetDrawColor(255, 255, 255, 22)
		surface.DrawRect(margin, 137, w - margin * 2, 1)
		surface.SetDrawColor(ui.accent)
		surface.DrawRect(margin, 136, 90, 2)

		MilBase.DrawPanelBF2(margin, 156, w - margin * 2, h - 156 - bottomH - 16, {
			cut = 12, color = Color(6, 6, 7, 190), accent = ui.accent,
		})

		surface.SetDrawColor(0, 0, 0, 178)
		surface.DrawRect(0, h - bottomH, w, bottomH)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 70)
		surface.DrawRect(0, h - bottomH, w, 1)
		MilBase.DrawIcon(ui.art.bf2.hex, margin, h - bottomH / 2 - 5, 10, 10, ui.accent)
		draw.SimpleText(required and "SELECT A CHARACTER TO CONTINUE TO DEPLOYMENT" or "CHARACTER MANAGEMENT",
			"MB.Tiny", margin + 18, h - bottomH / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	end
	frame.PaintOver = function(self, w, h)
		if not self.mb_pending then return end
		surface.SetDrawColor(0, 0, 0, 215)
		surface.DrawRect(0, 0, w, h)
		MilBase.DrawPanelBF2(w / 2 - 210, h / 2 - 58, 420, 116, {
			cut = 10, color = Color(8, 8, 9, 245), accent = ui.accent,
		})
		draw.SimpleText("LOADING CHARACTER", "MB.Big", w / 2, h / 2 - 20,
			ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Preparing faction, equipment and deployment access...", "MB.Small",
			w / 2, h / 2 + 20, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local contentX = margin + 24
	local contentY = 176
	local contentW = ScrW() - margin * 2 - 48
	local contentH = ScrH() - contentY - bottomH - 36
	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:SetPos(contentX, contentY)
	scroll:SetSize(contentW, contentH)

	local count = math.max(1, #slots)
	local perRow = math.min(count, ScrW() >= 1500 and 3 or 2)
	local gap = 18
	local cardW = math.Clamp(math.floor((contentW - gap * (perRow - 1)) / perRow), 310, 500)
	local cardH = math.Clamp(contentH - 12, 430, 560)
	local gridW = math.min(contentW, perRow * cardW + (perRow - 1) * gap)

	local grid = scroll:Add("DIconLayout")
	grid:SetPos(math.max(0, math.floor((contentW - gridW) / 2)), 0)
	grid:SetSize(gridW, contentH)
	grid:SetSpaceX(gap)
	grid:SetSpaceY(gap)
	for _, summary in ipairs(slots) do
		buildSelectorCard(grid, summary, required, cardW, cardH)
	end
	grid:Layout()
	grid:SizeToChildren(false, true)

	if not required then
		local close = vgui.Create("DButton", frame)
		close:SetText("")
		close:SetSize(150, bottomH)
		close:SetPos(ScrW() - margin - 150, ScrH() - bottomH)
		close.Paint = function(self, w, h)
			local col = self:IsHovered() and ui.text or ui.dim
			draw.SimpleText("CLOSE  [ESC]", "MB.Small", w, h / 2, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			MilBase.DrawIcon(ui.art.close, 12, h / 2 - 8, 16, 16, col)
		end
		close.DoClick = function()
			if not frame.mb_pending then closeCharacterSelector() end
		end
	end
end

-- Compact F4 tab version. The mandatory join selector above is intentionally
-- fullscreen; this panel remains useful for reviewing and switching lives later.
local function paintCompactCharacterCard(panel, summary)
	local ui = MilBase.UI
	local accent = summaryColor(summary)
	panel.Paint = function(self, w, h)
		local active = summary.slot == MilBase.CharacterActiveSlot
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 8,
			color = active and Color(accent.r, accent.g, accent.b, 22) or ui.panel,
			accent = accent,
		})
		draw.SimpleText("CHARACTER " .. summary.slot, "MB.Med", 18, 16, ui.text)
		draw.SimpleText(characterName(summary), "MB.Big", 18, 47, ui.text)
		draw.SimpleText((summary.factionName or "Unassigned") .. "  •  " .. (summary.rankName or "Unassigned"),
			"MB.Small", 18, 86, accent)
		draw.SimpleText((MilBase.Config.CurrencySymbol or "$") .. string.Comma(tonumber(summary.money) or 0),
			"MB.Small", 18, 112, ui.dim)
		if active then draw.SimpleText("ACTIVE LIFE", "MB.Tiny", w - 18, 18, accent, TEXT_ALIGN_RIGHT) end
	end
end

local function populateCharacterPanel(content)
	if not IsValid(content) then return end
	content:Clear()
	local ui = MilBase.UI

	local intro = vgui.Create("DLabel", content)
	intro:Dock(TOP)
	intro:SetTall(48)
	intro:SetFont("MB.Small")
	intro:SetText("Each life has its own faction, rank, credits, certifications, inventory, progression, appearance and Jedi/LSCS data.")
	intro:SetTextColor(ui.dim)
	intro:SetWrap(true)

	for _, summary in ipairs(MilBase.CharacterSummaries or {}) do
		local card = vgui.Create("DPanel", content)
		card:Dock(TOP)
		card:SetTall(150)
		card:DockMargin(0, 0, 0, 10)
		paintCompactCharacterCard(card, summary)

		local button = vgui.Create("DButton", card)
		button:SetText("")
		button:SetSize(170, 38)
		button:SetEnabled(summary.slot ~= MilBase.CharacterActiveSlot)
		button.Paint = function(self, w, h)
			local accent = summaryColor(summary)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
				color = self:IsEnabled() and (self:IsHovered() and Color(accent.r, accent.g, accent.b, 50) or ui.raised) or ui.panel,
				accent = self:IsEnabled() and accent or nil })
			draw.SimpleText(self:IsEnabled() and (summary.exists and "SWITCH CHARACTER" or "CREATE CHARACTER") or "ACTIVE",
				"MB.Small", w / 2, h / 2, self:IsEnabled() and ui.text or ui.faint,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function() selectCharacter(summary.slot, false) end
		card.PerformLayout = function(self, w, h)
			button:SetPos(w - button:GetWide() - 18, h - button:GetTall() - 16)
		end
	end

	local open = vgui.Create("DButton", content)
	open:Dock(TOP)
	open:SetTall(38)
	open:SetText("")
	open.Paint = function(self, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6, color = self:IsHovered() and ui.hover or ui.raised, accent = ui.accent })
		draw.SimpleText("OPEN FULL CHARACTER SELECTOR", "MB.Small", w / 2, h / 2, ui.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	open.DoClick = function() requestCharacters(true) end
end

net.Receive(NET_CLOSE, function()
	closeCharacterSelector()
end)

net.Receive(NET_OPEN, function()
	local payload = net.ReadTable() or {}
	MilBase.CharacterActiveSlot = tonumber(payload.active) or 1
	MilBase.CharacterSummaries = istable(payload.slots) and payload.slots or {}
	hook.Run("MilBase.CharacterSummariesUpdated")

	if payload.open == true then
		buildStandaloneSelector(payload)
	elseif IsValid(characterFrame) then
		buildStandaloneSelector(payload)
	end
end)

MilBase.AddMenuTab("CHARACTERS", 5, function(content)
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)
	local hookID = "MilBase.CharacterTab." .. tostring(scroll)
	local function refresh()
		if IsValid(scroll) then populateCharacterPanel(scroll) end
	end
	hook.Add("MilBase.CharacterSummariesUpdated", hookID, refresh)
	scroll.OnRemove = function() hook.Remove("MilBase.CharacterSummariesUpdated", hookID) end
	requestCharacters(false)
	refresh()
end)
