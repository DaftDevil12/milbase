SWInfil = SWInfil or {}

if SWInfil.SharedLoaded then
    return
end

SWInfil.SharedLoaded = true

SWInfil.Version = "1.0.0"
SWInfil.DefaultModel = "models/blu/laat.mdl"

-- These positions match the troop bay passenger layout in the default LVS Star Wars LAAT.
-- Custom seat layouts saved by the in-game editor replace this at runtime.
SWInfil.DefaultSeats = SWInfil.DefaultSeats or {
    { pos = Vector(10, 30, 10),    ang = Angle(0, 0, 0) },
    { pos = Vector(10, -30, 10),   ang = Angle(0, 180, 0) },
    { pos = Vector(-25, 27, 10),   ang = Angle(0, 0, 0) },
    { pos = Vector(-25, -27, 10),  ang = Angle(0, 180, 0) },
    { pos = Vector(-60, 24, 10),   ang = Angle(0, 0, 0) },
    { pos = Vector(-60, -24, 10),  ang = Angle(0, 180, 0) },
    { pos = Vector(-95, 21, 10),   ang = Angle(0, 0, 0) },
    { pos = Vector(-95, -21, 10),  ang = Angle(0, 180, 0) },
    { pos = Vector(-130, 18, 10),  ang = Angle(0, 0, 0) },
    { pos = Vector(-130, -18, 10), ang = Angle(0, 180, 0) },
    { pos = Vector(-165, 15, 10),  ang = Angle(0, 0, 0) },
    { pos = Vector(-165, -15, 10), ang = Angle(0, 180, 0) }
}

SWInfil.Seats = SWInfil.Seats or table.Copy(SWInfil.DefaultSeats)
SWInfil.CameraOffset = SWInfil.CameraOffset or Vector(0, 8, 54)
SWInfil.RideAnchorOffset = SWInfil.RideAnchorOffset or vector_origin

local function settingFloat(name, fallback)
    if not GetConVar then return fallback end

    local convar = GetConVar(name)
    if not convar then return fallback end

    return convar:GetFloat()
end

local function smootherStep(value)
    local t = math.Clamp(value, 0, 1)
    return t * t * t * (t * (t * 6 - 15) + 10)
end

local function cubicBezier(p0, p1, p2, p3, t)
    local inv = 1 - t
    return p0 * (inv * inv * inv)
        + p1 * (3 * inv * inv * t)
        + p2 * (3 * inv * t * t)
        + p3 * (t * t * t)
end

local function cubicBezierDerivative(p0, p1, p2, p3, t)
    local inv = 1 - t
    return (p1 - p0) * (3 * inv * inv)
        + (p2 - p1) * (6 * inv * t)
        + (p3 - p2) * (3 * t * t)
end

local function approachValue(value, target, amount)
    if value < target then
        return math.min(value + amount, target)
    end

    return math.max(value - amount, target)
end

function SWInfil.SmootherStep(value)
    return smootherStep(value)
end

function SWInfil.CubicBezier(p0, p1, p2, p3, t)
    return cubicBezier(p0, p1, p2, p3, t)
end

function SWInfil.GetBankedBezierTransform(p0, p1, p2, p3, raw, fallbackAng, landingBlend)
    local t = smootherStep(raw)
    local pos = cubicBezier(p0, p1, p2, p3, t)
    local tangent = cubicBezierDerivative(p0, p1, p2, p3, math.Clamp(t, 0.001, 0.999))

    if tangent:LengthSqr() < 0.001 then
        return pos, fallbackAng or angle_zero
    end

    local ang = tangent:Angle()
    local lookAhead = math.Clamp(settingFloat("sw_infil_turn_lookahead", 0.055), 0.01, 0.2)
    local futureT = math.Clamp(t + lookAhead, 0.001, 0.999)
    local futureTangent = cubicBezierDerivative(p0, p1, p2, p3, futureT)
    local maxBank = settingFloat("sw_infil_max_bank", 20)
    local bankStrength = settingFloat("sw_infil_bank_strength", 1.1)
    local turnDelta = 0

    if futureTangent:LengthSqr() > 0.001 then
        turnDelta = math.AngleDifference(futureTangent:Angle().y, ang.y)
    end

    local bankDamping = 1
    local settle = landingBlend or 0
    if settle > 0 then
        bankDamping = 1 - smootherStep(settle)
    end

    ang.p = math.Clamp(ang.p, -16, 16)
    ang.r = math.Clamp(-turnDelta * bankStrength, -maxBank, maxBank) * bankDamping

    return pos, ang
end

function SWInfil.MakeCurveMidpoint(startPos, endPos, startAng, endAng, lift, side)
    local startForward = (startAng or angle_zero):Forward()
    local endForward = (endAng or startAng or angle_zero):Forward()
    local middle = (startPos + endPos) * 0.5
    local sideVector = (startAng or angle_zero):Right() * (side or 0)
    local forwardPull = (startForward - endForward) * 120

    return middle + Vector(0, 0, lift or 0) + sideVector + forwardPull
end

function SWInfil.GetSeat(index)
    local seats = SWInfil.Seats
    if not istable(seats) or #seats <= 0 then
        seats = SWInfil.DefaultSeats
    end

    return seats[math.Clamp(index or 1, 1, #seats)] or seats[1]
end

function SWInfil.GetSeatWorld(ent, seatIndex, atTime)
    if not IsValid(ent) then return vector_origin, angle_zero end

    local pos, ang = SWInfil.GetFlightTransform(ent, atTime or CurTime())
    local seat = SWInfil.GetSeat(seatIndex or ent:GetSeatNumber())
    return LocalToWorld(seat.pos, seat.ang, pos, ang)
end

function SWInfil.GetSeatPoint(ent, seatIndex, offset, atTime)
    local seatPos, seatAng = SWInfil.GetSeatWorld(ent, seatIndex, atTime)
    return LocalToWorld(offset or vector_origin, angle_zero, seatPos, seatAng)
end

function SWInfil.GetRideAnchor(ent, atTime, seatIndex, offset)
    return SWInfil.GetSeatPoint(ent, seatIndex, offset or SWInfil.RideAnchorOffset, atTime)
end

function SWInfil.GetPhase(ent, atTime)
    if not IsValid(ent) then return "finished", 1 end

    local now = atTime or CurTime()
    local elapsed = now - ent:GetSequenceStarted()
    local approach = math.max(ent:GetApproachDuration(), 0.01)
    local hold = math.max(ent:GetHoldDuration(), 0)
    local departure = math.max(ent:GetDepartureDuration(), 0.01)

    if elapsed < approach then
        return "approach", math.Clamp(elapsed / approach, 0, 1)
    end

    if elapsed < approach + hold then
        return "landed", math.Clamp((elapsed - approach) / math.max(hold, 0.01), 0, 1)
    end

    if elapsed < approach + hold + departure then
        return "departure", math.Clamp((elapsed - approach - hold) / departure, 0, 1)
    end

    return "finished", 1
end

-- Both realms use the same time-based path, keeping the camera smooth even if
-- a busy server sends entity positions less frequently for a moment.
function SWInfil.GetFlightTransform(ent, atTime)
    if not IsValid(ent) then return vector_origin, angle_zero end

    local phase, raw = SWInfil.GetPhase(ent, atTime)
    local startPos = ent:GetRouteStart()
    local landPos = ent:GetRouteLand()
    local departPos = ent:GetRouteDepart()
    local startAng = ent:GetRouteStartAngle()
    local landAng = ent:GetRouteLandAngle()

    if phase == "approach" then
        local distance = startPos:Distance(landPos)
        local controlDistance = math.Clamp(distance * 0.28, 450, 1800)
        local p1 = startPos + startAng:Forward() * controlDistance
        local p2 = landPos - landAng:Forward() * math.Clamp(controlDistance * 0.75, 350, 1200)
            + Vector(0, 0, math.Clamp(distance * 0.06, 100, 320))
        local align = smootherStep((raw - 0.72) / 0.28)
        local pos, pathAng = SWInfil.GetBankedBezierTransform(startPos, p1, p2, landPos, raw, startAng, align)
        local ang = LerpAngle(align, pathAng, landAng)
        local landingPitch = settingFloat("sw_infil_landing_pitch", 7)

        ang.p = ang.p - math.sin(raw * math.pi) * 2.5 + math.sin(align * math.pi) * landingPitch
        ang.r = ang.r + math.sin(raw * math.pi * 2) * 1.5 * (1 - align)

        return pos, ang
    end

    if phase == "departure" or phase == "finished" then
        local distance = landPos:Distance(departPos)
        local p1 = landPos + landAng:Forward() * math.Clamp(distance * 0.2, 400, 900)
            + Vector(0, 0, 80)
        local p2 = landPos + (departPos - landPos) * 0.7 + Vector(0, 0, 240)
        local departAng = (departPos - landPos):Angle()
        local pos, ang = SWInfil.GetBankedBezierTransform(landPos, p1, p2, departPos, raw, departAng, 0)

        ang.p = ang.p - math.sin(raw * math.pi) * 4
        return pos, ang
    end

    return landPos, landAng
end
