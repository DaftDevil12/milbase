-- Client UI for physical customs inspections.
if not CLIENT or MilBase._SmugglingInspectionsClientLoaded then return end
MilBase._SmugglingInspectionsClientLoaded = true

local function readCompressed()
	local length = net.ReadUInt(24)
	if length <= 0 then return {} end
	local raw = util.Decompress(net.ReadData(length))
	local data = raw and util.JSONToTable(raw) or nil
	return istable(data) and data or {}
end

local function sendAction(data, action)
	net.Start("MilBase_InspectionAction")
		net.WriteString(tostring(data.caseID or ""))
		net.WriteString(tostring(data.kind or "ship"))
		net.WriteUInt(math.Clamp(math.floor(tonumber(data.index) or 0), 0, 255), 8)
		net.WriteString(tostring(action or ""))
	net.SendToServer()
end

local function openInspection(data)
	if not istable(data) then return end
	if IsValid(MilBase.InspectionFrame) then MilBase.InspectionFrame:Remove() end
	local ui = MilBase.UI
	local frame = vgui.Create("DFrame")
	MilBase.InspectionFrame = frame
	frame:SetSize(math.min(720, ScrW() - 60), math.min(700, ScrH() - 80))
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(true)
	frame.Paint = function(self, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 12,
			color = Color(4, 10, 17, 246),
			accent = ui and ui.accent or Color(80, 160, 240),
		})
		draw.SimpleText(data.title or "REPUBLIC CUSTOMS", "MB.Big", 20, 16,
			ui and ui.text or color_white)
		draw.SimpleText("PHYSICAL SHIP INSPECTION / EVIDENCE IS SERVER-AUTHORITATIVE",
			"MB.Tiny", 22, 52, ui and ui.dim or Color(180, 190, 200))
	end

	local scroll = vgui.Create("DScrollPanel", frame)
	scroll:SetPos(18, 80)
	scroll:SetSize(frame:GetWide() - 36, frame:GetTall() - 148)

	local body = vgui.Create("DLabel", scroll)
	body:Dock(TOP)
	body:DockMargin(8, 8, 8, 16)
	body:SetFont("MB.Small")
	body:SetTextColor(ui and ui.text or color_white)
	body:SetWrap(true)
	body:SetAutoStretchVertical(true)
	body:SetText(tostring(data.body or "No case information available."))

	for _, action in ipairs(data.actions or {}) do
		local button = vgui.Create("DButton", scroll)
		button:Dock(TOP)
		button:DockMargin(8, 0, 8, 7)
		button:SetTall(38)
		button:SetText("")
		button.Paint = function(self, w, h)
			local accent = ui and ui.accent or Color(80, 160, 240)
			local alpha = self:IsHovered() and 42 or 18
			surface.SetDrawColor(accent.r, accent.g, accent.b, alpha)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(accent.r, accent.g, accent.b, self:IsHovered() and 255 or 150)
			surface.DrawOutlinedRect(0, 0, w, h, 1)
			draw.SimpleText(string.upper(tostring(action.label or action.id or "ACTION")),
				"MB.Small", 14, h / 2, ui and ui.text or color_white,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function()
			sendAction(data, action.id)
		end
	end

	local close = vgui.Create("DButton", frame)
	close:SetPos(18, frame:GetTall() - 56)
	close:SetSize(frame:GetWide() - 36, 38)
	close:SetText("")
	close.Paint = function(self, w, h)
		surface.SetDrawColor(255, 255, 255, self:IsHovered() and 22 or 10)
		surface.DrawRect(0, 0, w, h)
		draw.SimpleText("CLOSE TERMINAL", "MB.Small", w / 2, h / 2,
			ui and ui.dim or Color(180, 190, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Close() end
end

net.Receive("MilBase_InspectionOpen", function()
	openInspection(readCompressed())
end)
