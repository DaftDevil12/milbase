--[[
	Persistent server-wide DEFCON system.

	The current alert condition is replicated through global network variables,
	stored in the MilBase database, displayed on the HUD, and exposed to the
	unified RP Datapad. All changes are validated server-side.
]]

local cfg = MilBase.Config

MilBase.Defcon = MilBase.Defcon or {}
MilBase.Defcon.State = MilBase.Defcon.State or {}

local GLOBAL_LEVEL = "mb_defcon_level"
local GLOBAL_REASON = "mb_defcon_reason"
local GLOBAL_CHANGED_BY = "mb_defcon_changed_by"
local GLOBAL_CHANGED_AT = "mb_defcon_changed_at"
local NET_SYNC = "MilBase_Defcon_Sync"

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function clampLevel(value)
	return math.Clamp(math.floor(tonumber(value or cfg.DefconDefaultLevel or 5) or 5), 1, 5)
end

local function valueMatches(list, id, name)
	if not istable(list) then return false end
	id = string.lower(trim(id))
	name = string.lower(trim(name))

	for key, value in pairs(list) do
		local candidate
		local enabled = true
		if isnumber(key) then
			candidate = value
		else
			candidate = key
			enabled = value == true or tonumber(value) == 1
		end

		candidate = string.lower(trim(candidate))
		if enabled and candidate ~= "" and (candidate == id or candidate == name) then
			return true
		end
	end
	return false
end

function MilBase.DefconGetDefinition(level)
	level = clampLevel(level)
	local definitions = cfg.DefconLevels or {}
	local definition = definitions[level] or {}
	return {
		level = level,
		name = trim(definition.name) ~= "" and trim(definition.name) or ("DEFCON " .. level),
		description = trim(definition.description),
		color = IsColor(definition.color) and definition.color or Color(255, 198, 60),
	}
end

function MilBase.DefconGetLevel()
	if SERVER then
		return clampLevel(MilBase.Defcon.State.level)
	end
	return clampLevel(GetGlobalInt(GLOBAL_LEVEL, cfg.DefconDefaultLevel or 5))
end

function MilBase.DefconGetState()
	if SERVER then
		return table.Copy(MilBase.Defcon.State)
	end
	return {
		level = MilBase.DefconGetLevel(),
		reason = GetGlobalString(GLOBAL_REASON, ""),
		changed_by = GetGlobalString(GLOBAL_CHANGED_BY, "System"),
		changed_at = GetGlobalInt(GLOBAL_CHANGED_AT, 0),
	}
end

function MilBase.DefconCanChange(ply)
	if cfg.DefconEnabled == false then return false end
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	if game.SinglePlayer() then return true end

	local staffLevel = ply.MBStaffLevel and ply:MBStaffLevel() or 0
	local requiredStaff = tonumber(cfg.DefconChangeStaffLevel)
	if requiredStaff and requiredStaff >= 0 and staffLevel >= requiredStaff then return true end
	if ply:IsSuperAdmin() and cfg.DefconAllowSuperAdmin ~= false then return true end

	local faction = ply.MBFaction and ply:MBFaction()
	local factionID = ply.MBFactionID and ply:MBFactionID() or ""
	if not valueMatches(cfg.DefconCommandFactions, factionID, faction and faction.name or "") then return false end

	if faction and faction.defconControl == true then return true end
	local rank = ply.MBRank and ply:MBRank()
	if rank and rank.defconControl == true then return true end

	local minimumRank = math.max(1, math.floor(tonumber(cfg.DefconCommandMinRankIndex or 8) or 8))
	local rankIndex = ply.MBRankIndex and ply:MBRankIndex() or 0
	return rankIndex >= minimumRank
end

if SERVER then
	util.AddNetworkString(NET_SYNC)

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_defcon_state ("
		.. "id INTEGER PRIMARY KEY, level INTEGER, reason TEXT, changed_by TEXT, changed_by_sid VARCHAR(32), changed_at INTEGER )")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_defcon_history ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", level INTEGER, reason TEXT, changed_by TEXT, changed_by_sid VARCHAR(32), changed_at INTEGER )")

	local function defaultState()
		return {
			level = clampLevel(cfg.DefconDefaultLevel or 5),
			reason = "Normal operations.",
			changed_by = "System",
			changed_by_sid = "",
			changed_at = os.time(),
		}
	end

	local function publishState(state)
		state = state or defaultState()
		state.level = clampLevel(state.level)
		state.reason = string.sub(trim(state.reason), 1, 180)
		state.changed_by = string.sub(trim(state.changed_by), 1, 96)
		state.changed_by_sid = string.sub(trim(state.changed_by_sid), 1, 32)
		state.changed_at = math.floor(tonumber(state.changed_at or os.time()) or os.time())
		if state.reason == "" then state.reason = "No reason supplied." end
		if state.changed_by == "" then state.changed_by = "System" end

		MilBase.Defcon.State = state
		SetGlobalInt(GLOBAL_LEVEL, state.level)
		SetGlobalString(GLOBAL_REASON, state.reason)
		SetGlobalString(GLOBAL_CHANGED_BY, state.changed_by)
		SetGlobalInt(GLOBAL_CHANGED_AT, state.changed_at)
	end

	local function persistState(state)
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_defcon_state (id, level, reason, changed_by, changed_by_sid, changed_at) VALUES (1, %d, %s, %s, %s, %d)",
			state.level,
			MilBase.SQLStr(state.reason),
			MilBase.SQLStr(state.changed_by),
			MilBase.SQLStr(state.changed_by_sid),
			state.changed_at
		))
	end

	local function syncState(target, changed)
		local state = MilBase.Defcon.State
		net.Start(NET_SYNC)
			net.WriteUInt(clampLevel(state.level), 3)
			net.WriteString(state.reason or "")
			net.WriteString(state.changed_by or "System")
			net.WriteUInt(math.max(0, tonumber(state.changed_at or 0) or 0), 32)
			net.WriteBool(changed == true)
		if target then net.Send(target) else net.Broadcast() end
	end

	publishState(defaultState())
	MilBase.DB.Query("SELECT level, reason, changed_by, changed_by_sid, changed_at FROM frontier_defcon_state WHERE id = 1 LIMIT 1", function(rows)
		local row = rows and rows[1]
		if row then
			publishState({
				level = tonumber(row.level),
				reason = row.reason,
				changed_by = row.changed_by,
				changed_by_sid = row.changed_by_sid,
				changed_at = tonumber(row.changed_at),
			})
		else
			persistState(MilBase.Defcon.State)
		end
		syncState(nil, false)
	end)

	function MilBase.DefconSetLevel(level, actor, reason, source)
		if cfg.DefconEnabled == false then return false, "DEFCON system is disabled." end
		level = tonumber(level)
		if not level or level < 1 or level > 5 or level ~= math.floor(level) then
			return false, "DEFCON must be a whole number from 1 to 5."
		end
		if IsValid(actor) and not MilBase.DefconCanChange(actor) then
			return false, "You are not authorised to change DEFCON."
		end

		level = clampLevel(level)
		reason = string.sub(trim(reason), 1, 180)
		if reason == "" then reason = "No reason supplied." end
		local oldLevel = MilBase.DefconGetLevel()
		if oldLevel == level and reason == (MilBase.Defcon.State.reason or "") then
			return false, "DEFCON is already set to that state."
		end

		local changedBy = IsValid(actor)
			and (actor.MBName and actor:MBName() or actor:Nick())
			or "Server Console"
		local sid = IsValid(actor) and actor:SteamID64() or ""
		local state = {
			level = level,
			reason = reason,
			changed_by = changedBy,
			changed_by_sid = sid,
			changed_at = os.time(),
		}
		publishState(state)
		persistState(state)
		MilBase.DB.Run(string.format(
			"INSERT INTO frontier_defcon_history (level, reason, changed_by, changed_by_sid, changed_at) VALUES (%d, %s, %s, %s, %d)",
			state.level,
			MilBase.SQLStr(state.reason),
			MilBase.SQLStr(state.changed_by),
			MilBase.SQLStr(state.changed_by_sid),
			state.changed_at
		))

		local definition = MilBase.DefconGetDefinition(level)
		local message = "DEFCON " .. level .. " — " .. definition.name .. ": " .. state.reason
		local kind = level <= 2 and "danger" or (level <= 4 and "warn" or "ok")
		MilBase.Notify(player.GetAll(), message, kind)
		if MilBase.ChatMsg then
			MilBase.ChatMsg(nil, definition.color, "[DEFCON " .. level .. "] ", color_white, definition.name .. " — " .. state.reason)
		end
		if MilBase.Log then
			MilBase.Log("staff", (MilBase.LogTag and MilBase.LogTag(actor) or changedBy)
				.. " changed DEFCON from " .. oldLevel .. " to " .. level
				.. " via " .. tostring(source or "system") .. ": " .. state.reason, actor)
		end

		syncState(nil, true)
		hook.Run("MilBase.DefconChanged", level, oldLevel, state, actor)
		return true
	end

	function MilBase.DefconBuildDatapadPayload(ply, callback)
		local limit = math.Clamp(math.floor(tonumber(cfg.DefconHistoryLimit or 20) or 20), 5, 100)
		MilBase.DB.Query("SELECT level, reason, changed_by, changed_at FROM frontier_defcon_history ORDER BY id DESC LIMIT " .. limit, function(rows)
			local history = {}
			for _, row in ipairs(rows or {}) do
				history[#history + 1] = {
					level = clampLevel(row.level),
					reason = row.reason or "",
					changed_by = row.changed_by or "System",
					changed_at = tonumber(row.changed_at or 0) or 0,
				}
			end
			if callback then
				callback({
					state = MilBase.DefconGetState(),
					can_change = MilBase.DefconCanChange(ply),
					history = history,
				})
			end
		end)
	end

	hook.Add("PlayerInitialSpawn", "MilBase.Defcon.Sync", function(ply)
		timer.Simple(2, function()
			if IsValid(ply) then syncState(ply, false) end
		end)
	end)

	concommand.Add("mb_defcon_set", function(ply, _, args)
		if IsValid(ply) and not MilBase.DefconCanChange(ply) then
			MilBase.Notify(ply, "You are not authorised to change DEFCON.", "warn")
			return
		end
		local level = tonumber(args[1])
		local reason = table.concat(args, " ", 2)
		local ok, err = MilBase.DefconSetLevel(level, IsValid(ply) and ply or nil, reason, "console command")
		if IsValid(ply) and not ok then MilBase.Notify(ply, err or "Unable to change DEFCON.", "warn") end
	end)

	return
end

net.Receive(NET_SYNC, function()
	local state = {
		level = net.ReadUInt(3),
		reason = net.ReadString(),
		changed_by = net.ReadString(),
		changed_at = net.ReadUInt(32),
	}
	local changed = net.ReadBool()
	MilBase.Defcon.State = state
	hook.Run("MilBase.DefconUpdated", state, changed)
end)

hook.Add("HUDPaint", "MilBase.DefconHUD", function()
	if cfg.DefconEnabled == false or cfg.DefconHUDEnabled == false then return end
	if MilBase.InEventView and MilBase.InEventView() then return end
	local ply = LocalPlayer()
	if not IsValid(ply) then return end
	if cfg.DefconHUDAliveOnly ~= false and not ply:Alive() then return end

	local level = MilBase.DefconGetLevel()
	local definition = MilBase.DefconGetDefinition(level)
	local ui = MilBase.UI
	if not ui then return end

	local w = math.Clamp(tonumber(cfg.DefconHUDWidth or 250) or 250, 200, 360)
	local h = 64
	local x = 20
	local y = 20
	if cfg.DefconHUDPosition == "top_right" then x = ScrW() - w - 20 end

	local accent = definition.color
	if level == 1 then
		local pulse = 0.72 + math.sin(RealTime() * 2.5) * 0.18
		accent = Color(accent.r, accent.g, accent.b, 255 * pulse)
	end

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 9, color = Color(7, 8, 10, 210), accent = accent })
	draw.SimpleText("DEFCON " .. level, "MB.Big", x + 14, y + 9, definition.color)
	draw.SimpleText(string.upper(definition.name), "MB.Small", x + 14, y + 42, ui.text)
	draw.SimpleText(level <= 2 and "CRITICAL" or (level == 3 and "ALERT" or "STATUS"), "MB.Tiny",
		x + w - 14, y + 18, level <= 2 and ui.danger or ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end)
