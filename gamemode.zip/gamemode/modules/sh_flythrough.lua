--[[
	Flythrough camera path: stores the per-map cinematic tour authored with the
	Flythrough Camera toolgun (entities/.../stools/mb_flythrough.lua) and plays
	it back with a smooth spline camera. The new-player tutorial
	(modules/sh_tutorial.lua) plays it as the opening shot.

	  Server: persists the path (frontier_flythrough) and syncs it to clients.
	  Client: MilBase.PlayFlythrough(opts, onDone) glides the camera along it.

	MilBase.FlyPath  = { { pos = Vector, ang = Angle }, ... }  (the saved tour)
	MilBase.FlySeconds = travel time per keyframe.
]]

MilBase.FlyPath = MilBase.FlyPath or {}
MilBase.FlySeconds = MilBase.FlySeconds or 3

function MilBase.HasFlythrough()
	return MilBase.FlyPath and #MilBase.FlyPath >= 2
end

--------------------------------------------------------------------------
-- Server: storage, persistence, sync
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_FlySync")
	util.AddNetworkString("MilBase_FlySave")
	util.AddNetworkString("MilBase_FlyClear")

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_flythrough (
		map VARCHAR(64) PRIMARY KEY,
		data TEXT
	)]])

	-- Broadcast (or send to one player) the current map's tour.
	function MilBase.SyncFlythrough(target)
		net.Start("MilBase_FlySync")
			net.WriteFloat(MilBase.FlySeconds or 3)
			net.WriteUInt(#MilBase.FlyPath, 10)
			for _, kf in ipairs(MilBase.FlyPath) do
				net.WriteVector(kf.pos)
				net.WriteAngle(kf.ang)
			end
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	local function persist()
		local out = { seconds = MilBase.FlySeconds, points = {} }
		for _, kf in ipairs(MilBase.FlyPath) do
			out.points[#out.points + 1] = {
				kf.pos.x, kf.pos.y, kf.pos.z, kf.ang.p, kf.ang.y, kf.ang.r,
			}
		end

		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_flythrough (map, data) VALUES (%s, %s)",
			MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(util.TableToJSON(out))))
	end

	-- Load this map's saved tour on startup.
	local function load()
		MilBase.DB.Query(string.format(
			"SELECT data FROM frontier_flythrough WHERE map = %s",
			MilBase.SQLStr(game.GetMap())), function(rows)
			local row = rows and rows[1]
			if not row then return end

			local data = util.JSONToTable(row.data or "")
			if not data or not data.points then return end

			MilBase.FlySeconds = tonumber(data.seconds) or 3
			MilBase.FlyPath = {}
			for _, p in ipairs(data.points) do
				MilBase.FlyPath[#MilBase.FlyPath + 1] = {
					pos = Vector(p[1], p[2], p[3]),
					ang = Angle(p[4], p[5], p[6]),
				}
			end
			MilBase.SyncFlythrough()
		end)
	end

	-- Queries queue until the DB connects, so calling this directly is safe
	-- (it runs after the CREATE above regardless of backend).
	load()

	-- Late-joiners get the tour once they're in.
	hook.Add("PlayerInitialSpawn", "MilBase.FlythroughSync", function(ply)
		timer.Simple(3, function()
			if IsValid(ply) then MilBase.SyncFlythrough(ply) end
		end)
	end)

	net.Receive("MilBase_FlySave", function(_, ply)
		if not (ply:IsAdmin() or ply:IsSuperAdmin()) then return end

		local seconds = math.Clamp(net.ReadFloat(), 0.25, 30)
		local count = net.ReadUInt(10)
		if count < 2 or count > 256 then
			MilBase.Notify(ply, "A tour needs 2-256 keyframes.")
			return
		end

		local path = {}
		for _ = 1, count do
			path[#path + 1] = { pos = net.ReadVector(), ang = net.ReadAngle() }
		end

		MilBase.FlyPath = path
		MilBase.FlySeconds = seconds
		persist()
		MilBase.SyncFlythrough()
		MilBase.Notify(ply, "Flythrough tour saved (" .. count .. " keyframes) for "
			.. game.GetMap() .. ".", "ok")
	end)

	net.Receive("MilBase_FlyClear", function(_, ply)
		if not (ply:IsAdmin() or ply:IsSuperAdmin()) then return end

		MilBase.FlyPath = {}
		MilBase.DB.Run("DELETE FROM frontier_flythrough WHERE map = "
			.. MilBase.SQLStr(game.GetMap()))
		MilBase.SyncFlythrough()
		MilBase.Notify(ply, "Saved flythrough tour deleted for " .. game.GetMap() .. ".", "warn")
	end)

	return
end

--------------------------------------------------------------------------
-- Client: receive the tour + play the spline camera
--------------------------------------------------------------------------

net.Receive("MilBase_FlySync", function()
	MilBase.FlySeconds = net.ReadFloat()
	local count = net.ReadUInt(10)
	local path = {}
	for _ = 1, count do
		path[#path + 1] = { pos = net.ReadVector(), ang = net.ReadAngle() }
	end
	MilBase.FlyPath = path
end)

-- Catmull-Rom interpolation for smooth position travel through the keyframes.
local function catmull(p0, p1, p2, p3, t)
	local t2 = t * t
	local t3 = t2 * t
	return 0.5 * ((2 * p1)
		+ (-p0 + p2) * t
		+ (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
		+ (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
end

local playing -- { points, seconds, total, start, caption, onDone, skippable }

local function stopFlythrough(fireDone)
	if not playing then return end
	local onDone = playing.onDone
	playing = nil
	MilBase.CinematicActive = false
	hook.Remove("CalcView", "MilBase.Flythrough")
	hook.Remove("HUDPaint", "MilBase.FlythroughHUD")
	hook.Remove("Think", "MilBase.FlythroughThink")
	hook.Remove("PlayerBindPress", "MilBase.FlythroughSkip")
	hook.Remove("HUDShouldDraw", "MilBase.FlythroughHideHUD")
	if fireDone and onDone then onDone() end
end
MilBase.StopFlythrough = stopFlythrough

-- opts: points (defaults to the saved tour), seconds, caption, skippable, onDone.
function MilBase.PlayFlythrough(opts, onDone)
	opts = opts or {}
	local points = opts.points or MilBase.FlyPath
	onDone = onDone or opts.onDone

	if not points or #points < 2 then
		if onDone then onDone() end
		return false
	end

	stopFlythrough(false) -- never stack two

	local seconds = opts.seconds or MilBase.FlySeconds or 3
	playing = {
		points    = points,
		seconds   = seconds,
		total     = (#points - 1) * seconds,
		start     = CurTime(),
		caption   = opts.caption,
		onDone    = onDone,
		skippable = opts.skippable ~= false,
	}
	MilBase.CinematicActive = true

	hook.Add("CalcView", "MilBase.Flythrough", function(ply, origin, angles, fov)
		if not playing then return end
		local pts = playing.points
		local n = #pts

		-- Ease the overall progress for a soft start / stop.
		local raw = math.Clamp((CurTime() - playing.start) / playing.total, 0, 1)
		local prog = raw * raw * (3 - 2 * raw) -- smoothstep

		local f = prog * (n - 1)
		local i = math.floor(f) + 1
		i = math.Clamp(i, 1, n - 1)
		local lt = f - (i - 1)

		local p0 = pts[i - 1] or pts[i]
		local p1 = pts[i]
		local p2 = pts[i + 1]
		local p3 = pts[i + 2] or pts[i + 1]

		return {
			origin = catmull(p0.pos, p1.pos, p2.pos, p3.pos, lt),
			angles = LerpAngle(lt, p1.ang, p2.ang),
			fov    = fov,
		}
	end)

	-- Hide the default engine HUD (health, ammo, crosshair) during the shot.
	hook.Add("HUDShouldDraw", "MilBase.FlythroughHideHUD", function()
		return false
	end)

	hook.Add("Think", "MilBase.FlythroughThink", function()
		if not playing then return end
		if CurTime() - playing.start >= playing.total then
			stopFlythrough(true)
		end
	end)

	if playing.skippable then
		hook.Add("PlayerBindPress", "MilBase.FlythroughSkip", function(_, bind, pressed)
			if not playing or not pressed then return end
			if string.find(bind, "+jump", 1, true) or string.find(bind, "+attack", 1, true) then
				stopFlythrough(true)
				return true
			end
		end)
	end

	hook.Add("HUDPaint", "MilBase.FlythroughHUD", function()
		if not playing then return end
		local ui = MilBase.UI
		local w, h = ScrW(), ScrH()

		-- Cinematic letterbox (also masks the edge HUD).
		local bar = math.floor(h * 0.12)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(0, 0, w, bar)
		surface.DrawRect(0, h - bar, w, bar)

		-- Fade in from black over the first second.
		local age = CurTime() - playing.start
		if age < 1 then
			surface.SetDrawColor(0, 0, 0, 255 * (1 - age))
			surface.DrawRect(0, 0, w, h)
		end

		if playing.caption then
			draw.SimpleText(playing.caption, "MB.Tab", 40, bar - 30, ui.accent,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		end

		-- Progress ticker + skip hint along the bottom bar.
		local frac = math.Clamp(age / playing.total, 0, 1)
		local barW = w - 80
		surface.SetDrawColor(255, 255, 255, 30)
		surface.DrawRect(40, h - bar + 14, barW, 2)
		surface.SetDrawColor(ui.accent)
		surface.DrawRect(40, h - bar + 14, barW * frac, 2)

		if playing.skippable then
			draw.SimpleText("HOLD [SPACE] TO SKIP", "MB.Tiny", w - 40, h - bar + 26,
				ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		end
	end)

	return true
end
