--[[
	COMMS F4 tab: set your push-to-talk key, tune radio receive volume, and mute
	individual comm channels. Pairs with modules/sh_comms.lua (the radio system);
	all three settings are client-owned (muting is synced to the server).
]]

if SERVER then return end

--------------------------------------------------------------------------
-- Small styled widgets (mirror sh_stafftab.lua / sh_music.lua).
--------------------------------------------------------------------------

local function actionBtn(parent, label, accent, onClick)
	local ui = MilBase.UI
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(s, w, h)
		local col = (isfunction(label) and select(2, label())) or accent or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = s:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised,
			accent = col })
		if s:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(isfunction(label) and label() or label, "MB.Small", w / 2, h / 2,
			ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

-- Minimal draggable 0-100 slider. onChange(v) fires while dragging.
local function makeSlider(parent, getValue, onChange)
	local ui = MilBase.UI
	local s = vgui.Create("DPanel", parent)
	local dragging = false
	local function setFromX(x)
		onChange(math.Round(math.Clamp(x / s:GetWide(), 0, 1) * 100))
	end
	s.OnMousePressed = function(self) dragging = true self:MouseCapture(true) setFromX(self:CursorPos()) end
	s.OnMouseReleased = function(self) dragging = false self:MouseCapture(false) end
	s.OnCursorMoved = function(self, x) if dragging then setFromX(x) end end
	s.Paint = function(self, w, h)
		local v = math.Clamp(getValue(), 0, 100) / 100
		local cy = h / 2
		surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, cy - 2, w, 4)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 220); surface.DrawRect(0, cy - 2, w * v, 4)
		surface.SetDrawColor(ui.text.r, ui.text.g, ui.text.b, 255)
		surface.DrawRect(math.Clamp(w * v - 3, 0, w - 6), cy - 7, 6, 14)
	end
	return s
end

--------------------------------------------------------------------------
-- The tab
--------------------------------------------------------------------------

MilBase.AddMenuTab("COMMS", 55, function(content)
	local ui = MilBase.UI
	local root = vgui.Create("DScrollPanel", content)
	root:Dock(FILL)

	local function section(text)
		local pnl = vgui.Create("DPanel", root)
		pnl:Dock(TOP); pnl:SetTall(24); pnl:DockMargin(0, 10, 8, 6)
		pnl.Paint = function(s, w, h)
			draw.SimpleText(text, "MB.Small", 2, h / 2, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetFont("MB.Small")
			local tw = surface.GetTextSize(text)
			surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 45)
			surface.DrawRect(tw + 12, h / 2, math.max(0, w - tw - 14), 1)
		end
	end

	----------------------------------------------------------------
	-- PUSH-TO-TALK
	----------------------------------------------------------------
	section("PUSH-TO-TALK")

	local ptt = vgui.Create("DPanel", root)
	ptt:Dock(TOP); ptt:SetTall(38); ptt:DockMargin(0, 0, 8, 4); ptt.Paint = nil

	local capturing = false
	local keyBtn = actionBtn(ptt, function()
		if capturing then return "PRESS A KEY…" end
		local kc = GetConVar("mb_radio_key"):GetInt()
		local bind = kc > 0 and input.GetKeyName(kc) or input.LookupBinding("+mb_radio")
		return "PTT KEY:  " .. (bind and string.upper(bind) or "UNSET")
	end, ui.accent)
	keyBtn:Dock(FILL); keyBtn:DockMargin(0, 0, 8, 0)
	keyBtn:SetKeyboardInputEnabled(true) -- so OnKeyCodePressed fires when focused
	keyBtn.DoClick = function(self)
		capturing = true
		self:RequestFocus()
	end
	keyBtn.OnKeyCodePressed = function(self, key)
		if not capturing then return end
		capturing = false
		if key == KEY_ESCAPE then return end
		RunConsoleCommand("mb_radio_key", tostring(key))
	end
	-- Clicking away cancels capture.
	keyBtn.OnLoseFocus = function() capturing = false end

	local clearBtn = actionBtn(ptt, "USE BIND", ui.dim, function()
		RunConsoleCommand("mb_radio_key", "0")
	end)
	clearBtn:Dock(RIGHT); clearBtn:SetWide(110)

	local note = vgui.Create("DPanel", root)
	note:Dock(TOP); note:SetTall(18); note:DockMargin(0, 0, 8, 2)
	note.Paint = function(s, w, h)
		draw.SimpleText("Hold this key to transmit on your comm channel. USE BIND falls back to a console +mb_radio bind.",
			"MB.Tiny", 2, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	----------------------------------------------------------------
	-- RADIO VOLUME
	----------------------------------------------------------------
	section("RADIO RECEIVE VOLUME")

	local volRow = vgui.Create("DPanel", root)
	volRow:Dock(TOP); volRow:SetTall(30); volRow:DockMargin(0, 0, 8, 4); volRow.Paint = nil

	local volLabel = vgui.Create("DPanel", volRow)
	volLabel:Dock(RIGHT); volLabel:SetWide(56)
	volLabel.Paint = function(s, w, h)
		draw.SimpleText(GetConVar("mb_radio_volume"):GetInt() .. "%", "MB.Small", w - 4, h / 2,
			ui.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	local volSlider = makeSlider(volRow, function() return GetConVar("mb_radio_volume"):GetInt() end,
		function(v) RunConsoleCommand("mb_radio_volume", tostring(v)) end)
	volSlider:Dock(FILL); volSlider:DockMargin(0, 0, 10, 0)

	----------------------------------------------------------------
	-- MUTE CHANNELS
	----------------------------------------------------------------
	section("MUTE CHANNELS")

	local hint = vgui.Create("DPanel", root)
	hint:Dock(TOP); hint:SetTall(18); hint:DockMargin(0, 0, 8, 2)
	hint.Paint = function(s, w, h)
		draw.SimpleText("Muted channels are silenced for both voice and chat. (Also: hold [H], highlight a channel, press [R].)",
			"MB.Tiny", 2, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	for _, id in ipairs(MilBase.CommOrder) do
		if id == "local" then continue end
		local ch = MilBase.CommChannels[id]
		local row = vgui.Create("DPanel", root)
		row:Dock(TOP); row:SetTall(30); row:DockMargin(0, 0, 8, 4)
		row.Paint = function(s, w, h)
			surface.SetDrawColor(255, 255, 255, 6); surface.DrawRect(0, 0, w, h)
			MilBase.DrawDiamond(14, h / 2, 4, ch.color)
			draw.SimpleText(ch.name, "MB.Small", 28, h / 2, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local toggle = actionBtn(row, function()
			local muted = MilBase.IsChannelMutedLocal(id)
			return muted and "MUTED" or "LISTENING", muted and ui.danger or ui.ok
		end, ui.ok, function()
			MilBase.SetChannelMute(id, not MilBase.IsChannelMutedLocal(id))
		end)
		toggle:Dock(RIGHT); toggle:SetWide(120); toggle:DockMargin(0, 4, 6, 4)
	end
end, function() return true end)
