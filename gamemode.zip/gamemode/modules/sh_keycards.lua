--[[
	Keycard access system (MilBase-native, inspired by keypad/keycard mods).

	* Keycards have TIERS (level 1..N, each a name + colour).
	* Which rank of which faction is issued which tier is set in-game on the
	  F4 "KEYCARDS" tab (admin) and persisted in SQLite.
	* A soldier's keycard level is derived live from their faction + rank.
	* Keypads (mb_keypad, placed with the Keypad tool) require a level; USE
	  them, or swipe with the mb_keycard weapon, to open linked door(s).

	Everything here is ours — no third-party code, no DRM.
]]

local cfg = MilBase.Config

MilBase.Keycard = MilBase.Keycard or {}

-- level -> { name, r, g, b }
local DEFAULT_TIERS = {
	{ name = "Level 1 - Clearance", r = 220, g = 70,  b = 60 },
	{ name = "Level 2 - Restricted", r = 230, g = 145, b = 50 },
	{ name = "Level 3 - Secure",    r = 235, g = 205, b = 70 },
	{ name = "Level 4 - Command",   r = 110, g = 195, b = 115 },
	{ name = "Level 5 - Overwatch", r = 90,  g = 150, b = 235 },
}

-- JSON decode can turn a tiers ARRAY into a string-keyed table, which makes
-- #Tiers == 0 and collapses every grant to 0 ("no keycard"). Rebuild it as a
-- clean sequential array, ordered by numeric key, with sane fallbacks.
local function normalizeTiers(t)
	if not istable(t) then return table.Copy(DEFAULT_TIERS) end

	local keys = {}
	for k in pairs(t) do keys[#keys + 1] = k end
	table.sort(keys, function(a, b) return (tonumber(a) or 0) < (tonumber(b) or 0) end)

	local out = {}
	for _, k in ipairs(keys) do
		local v = t[k]
		if istable(v) then
			out[#out + 1] = {
				name = v.name or ("Level " .. (#out + 1)),
				r = tonumber(v.r) or 200,
				g = tonumber(v.g) or 200,
				b = tonumber(v.b) or 200,
			}
		end
	end

	if #out == 0 then return table.Copy(DEFAULT_TIERS) end
	return out
end
MilBase.NormalizeKeycardTiers = normalizeTiers

-- Same JSON hazard as tiers, other direction: util.JSONToTable can hand back
-- rank keys as NUMBERS ("1" -> 1). Every lookup here is by string key
-- (tostring(rank)), so a number-keyed grant silently reads as "no keycard" and
-- the config row snaps back the instant the server's sync arrives. Rebuild the
-- table with string rank keys and numeric (>0) levels so it survives the trip.
local function normalizeGrants(g)
	if not istable(g) then return {} end

	local out = {}
	for fid, ranks in pairs(g) do
		if istable(ranks) then
			local clean = {}
			for k, v in pairs(ranks) do
				local lvl = tonumber(v)
				if lvl and lvl > 0 then
					clean[tostring(k)] = lvl
				end
			end
			out[tostring(fid)] = clean
		end
	end
	return out
end
MilBase.NormalizeKeycardGrants = normalizeGrants

MilBase.Keycard.Tiers = normalizeTiers(MilBase.Keycard.Tiers)
MilBase.Keycard.Grants = MilBase.Keycard.Grants or {} -- Grants[factionID][ "rankIndex" ] = level

--------------------------------------------------------------------------
-- Shared helpers
--------------------------------------------------------------------------

function MilBase.KeycardTier(level)
	return MilBase.Keycard.Tiers[level]
end

function MilBase.KeycardTierColor(level)
	local t = MilBase.Keycard.Tiers[level]
	if not t then return Color(150, 150, 150) end
	return Color(t.r or 200, t.g or 200, t.b or 200)
end

function MilBase.KeycardTierName(level)
	local t = MilBase.Keycard.Tiers[level]
	return t and t.name or ("Level " .. tostring(level))
end

-- Doors a keypad can be linked to. Map doors accept Open/Close/Lock/Unlock
-- inputs; props are toggled as "fading doors" (non-solid + translucent).
local MAP_DOORS = {
	func_door = true, func_door_rotating = true, prop_door_rotating = true,
}

local READER_BUTTONS = {
	func_button = true,
	func_rot_button = true,
	momentary_rot_button = true,
	gmod_button = true,
	gmod_button_toggle = true,
}

function MilBase.IsMapDoor(ent)
	return IsValid(ent) and MAP_DOORS[ent:GetClass()] or false
end

function MilBase.IsLinkableDoor(ent)
	if not IsValid(ent) then return false end
	local c = ent:GetClass()
	return MAP_DOORS[c] or c == "prop_physics" or c == "prop_dynamic" or false
end

function MilBase.IsReaderButton(ent)
	return IsValid(ent) and READER_BUTTONS[ent:GetClass()] or false
end

function MilBase.KeypadReaderAngleFromNormal(normal)
	local ang = (normal or Vector(0, 0, 1)):Angle()
	ang:RotateAroundAxis(ang:Up(), tonumber(MilBase.Config and MilBase.Config.KeypadModelYawOffset) or -90)
	return ang
end

function MilBase.KeypadReaderSurfaceOffset()
	return tonumber(MilBase.Config and MilBase.Config.KeypadModelSurfaceOffset) or 2.5
end

-- A player's issued keycard level (0 = none), from their faction + rank.
function MilBase.PlayerKeycardLevel(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return 0 end
	if not ply.MBFactionID or not ply.MBRankIndex then return 0 end

	local grants = MilBase.Keycard.Grants[ply:MBFactionID()]
	if not grants then return 0 end

	return tonumber(grants[tostring(ply:MBRankIndex())]) or 0
end

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_KeycardData")
	util.AddNetworkString("MilBase_KC_SetTiers")
	util.AddNetworkString("MilBase_KC_SetGrant")
	util.AddNetworkString("MilBase_KeypadSave")
	util.AddNetworkString("MilBase_KeypadClear")
	util.AddNetworkString("MilBase_KeypadPIN")
	util.AddNetworkString("MilBase_KeypadPINEnter")

	-- MySQL queries are asynchronous. Starting all CREATE statements and then
	-- immediately reading from the tables can race on a fresh database. Run the
	-- schema migration serially and gate every keypad operation behind it.
	local schemaReady = false
	local schemaCreating = false
	local schemaWaiters = {}
	local schemaStatements = {
		[[CREATE TABLE IF NOT EXISTS frontier_keycards (k VARCHAR(32) PRIMARY KEY, v TEXT)]],
		[[CREATE TABLE IF NOT EXISTS frontier_keypads (
			map VARCHAR(64), px REAL, py REAL, pz REAL, ap REAL, ay REAL, ar REAL,
			lvl INTEGER, hold REAL, dx REAL, dy REAL, dz REAL,
			mode INTEGER, pin TEXT )]],
		[[CREATE TABLE IF NOT EXISTS frontier_keypad_links (
			map VARCHAR(64), kx REAL, ky REAL, kz REAL, dx REAL, dy REAL, dz REAL )]],
		[[CREATE TABLE IF NOT EXISTS frontier_keypad_buttons (
			map VARCHAR(64), kx REAL, ky REAL, kz REAL, bx REAL, `by` REAL, bz REAL )]],
	}

	local function finishKeycardSchema(ok)
		schemaCreating = false
		if ok then schemaReady = true end

		local waiters = schemaWaiters
		schemaWaiters = {}
		for _, callback in ipairs(waiters) do
			callback(ok)
		end
	end

	local function ensureKeycardSchema(onReady)
		if schemaReady then
			if onReady then onReady(true) end
			return
		end

		if onReady then schemaWaiters[#schemaWaiters + 1] = onReady end
		if schemaCreating then return end
		schemaCreating = true

		local index = 0
		local function runNext()
			index = index + 1
			local statement = schemaStatements[index]
			if not statement then
				finishKeycardSchema(true)
				return
			end

			MilBase.DB.Query(statement, runNext, function()
				finishKeycardSchema(false)
			end)
		end

		runNext()
	end

	local function setKV(k, v)
		MilBase.DB.Run(string.format("REPLACE INTO frontier_keycards (k, v) VALUES (%s, %s)",
			MilBase.SQLStr(k), MilBase.SQLStr(v)))
	end

	-- Load saved tiers / grants only after the table is confirmed available.
	ensureKeycardSchema(function(ok)
		if not ok then return end
		MilBase.DB.Query("SELECT k, v FROM frontier_keycards", function(rows)
			for _, row in ipairs(rows) do
				if row.k == "tiers" then
					MilBase.Keycard.Tiers = normalizeTiers(util.JSONToTable(row.v or ""))
					setKV("tiers", util.TableToJSON(MilBase.Keycard.Tiers)) -- heal corrupt rows
				elseif row.k == "grants" then
					MilBase.Keycard.Grants = normalizeGrants(util.JSONToTable(row.v or ""))
					setKV("grants", util.TableToJSON(MilBase.Keycard.Grants)) -- heal corrupt rows
				end
			end
			-- SQLite runs this callback inline (before SyncKeycardData is defined);
			-- there are no players at boot anyway, so guard it.
			if MilBase.SyncKeycardData then MilBase.SyncKeycardData() end
		end)
	end)

	function MilBase.SyncKeycardData(target)
		net.Start("MilBase_KeycardData")
			net.WriteString(util.TableToJSON(MilBase.Keycard.Tiers))
			net.WriteString(util.TableToJSON(MilBase.Keycard.Grants))
		if target then net.Send(target) else net.Broadcast() end
	end

	hook.Add("PlayerInitialSpawn", "MilBase.KeycardSync", function(ply)
		timer.Simple(2, function()
			if IsValid(ply) then MilBase.SyncKeycardData(ply) end
		end)
	end)

	-- Issue the keycard weapon on spawn if the soldier's rank grants a tier.
	hook.Add("PlayerSpawn", "MilBase.GiveKeycard", function(ply)
		if cfg.KeycardsEnabled == false then return end
		timer.Simple(0.2, function()
			if not IsValid(ply) or not ply:Alive() then return end
			if MilBase.PlayerKeycardLevel(ply) > 0 and not IsValid(ply:GetWeapon("mb_keycard")) then
				ply:Give("mb_keycard")
			end
		end)
	end)

	-- Config edits (admin only).
	local function canConfig(ply)
		return IsValid(ply) and (ply:IsAdmin() or ply:IsSuperAdmin())
	end

	net.Receive("MilBase_KC_SetTiers", function(_, ply)
		if not canConfig(ply) then return end
		local tiers = util.JSONToTable(net.ReadString() or "")
		if not istable(tiers) then return end

		-- Sanitise: at least one tier, clamp fields.
		local clean = {}
		for i, t in ipairs(tiers) do
			if i > 12 then break end
			clean[i] = {
				name = string.sub(tostring(t.name or ("Level " .. i)), 1, 40),
				r = math.Clamp(tonumber(t.r) or 200, 0, 255),
				g = math.Clamp(tonumber(t.g) or 200, 0, 255),
				b = math.Clamp(tonumber(t.b) or 200, 0, 255),
			}
		end
		if #clean == 0 then clean = table.Copy(DEFAULT_TIERS) end

		MilBase.Keycard.Tiers = clean
		setKV("tiers", util.TableToJSON(clean))
		MilBase.SyncKeycardData()
	end)

	net.Receive("MilBase_KC_SetGrant", function(_, ply)
		if not canConfig(ply) then return end
		local fid = net.ReadString()
		local rank = net.ReadUInt(8)
		local level = net.ReadUInt(8)

		local faction = MilBase.GetFaction(fid)
		if not faction then return end
		MilBase.Keycard.Grants[fid] = MilBase.Keycard.Grants[fid] or {}
		if level <= 0 then
			MilBase.Keycard.Grants[fid][tostring(rank)] = nil
		else
			-- Never let a bad tier count collapse a valid grant to 0.
			local maxTier = #MilBase.Keycard.Tiers
			if maxTier < 1 then maxTier = #DEFAULT_TIERS end
			MilBase.Keycard.Grants[fid][tostring(rank)] = math.min(level, maxTier)
		end

		setKV("grants", util.TableToJSON(MilBase.Keycard.Grants))
		MilBase.SyncKeycardData()

		-- Confirmation back to the editing admin.
		local stored = MilBase.Keycard.Grants[fid][tostring(rank)]
		local rankName = (faction.ranks[rank] and faction.ranks[rank].name) or ("rank " .. rank)
		MilBase.Notify(ply, rankName .. " -> " .. (stored and MilBase.KeycardTierName(stored) or "no keycard"),
			"ok")
	end)

	----------------------------------------------------------------------
	-- Keypad placement + persistence (per map, like the CCTV cameras)
	----------------------------------------------------------------------

	function MilBase.SpawnKeypad(pos, ang, level, hold)
		local kp = ents.Create("mb_keypad")
		if not IsValid(kp) then return end
		kp:SetPos(pos)
		kp:SetAngles(ang)
		kp:Spawn()
		kp:Activate()
		kp:SetRequiredLevel(math.max(1, tonumber(level) or 1))
		kp:SetHoldTime(tonumber(hold) or (cfg.KeypadHoldTime or 4))
		return kp
	end

	--------------------------------------------------------------------
	-- Door locking: a keypad-controlled door can be linked to multiple
	-- keypads/readers. Any linked reader can open it, but the door's own
	-- USE/handle stays blocked while at least one reader controls it.
	--------------------------------------------------------------------

	local function cleanDoorKeypads(door)
		if not IsValid(door) then return {} end
		local list = door.mb_keypads or {}

		-- Compatibility with older saves/runtime state that had one owner.
		if IsValid(door.mb_keypad) then list[door.mb_keypad] = true end

		local any
		for kp in pairs(list) do
			if not IsValid(kp) then
				list[kp] = nil
			else
				any = kp
			end
		end

		door.mb_keypads = next(list) and list or nil
		door.mb_keypad = any or nil -- legacy / quick lookup
		return list
	end

	function MilBase.DoorHasKeypad(door, keypad)
		if not IsValid(door) or not IsValid(keypad) then return false end
		local list = cleanDoorKeypads(door)
		return list[keypad] == true
	end

	function MilBase.IsDoorKeypadLocked(door)
		if not IsValid(door) then return false end
		return next(cleanDoorKeypads(door)) ~= nil
	end

	function MilBase.LockDoor(door, keypad)
		if not IsValid(door) or not IsValid(keypad) then return end

		local list = cleanDoorKeypads(door)
		list[keypad] = true
		door.mb_keypads = list
		door.mb_keypad = door.mb_keypad or keypad

		if MilBase.IsMapDoor(door) then
			door:Fire("Close")
			door:Fire("Lock")
		end
	end

	function MilBase.UnlockDoor(door, keypad)
		if not IsValid(door) then return end

		local list = cleanDoorKeypads(door)
		if IsValid(keypad) then
			list[keypad] = nil
		else
			list = {}
		end

		local remaining
		for kp in pairs(list) do
			if IsValid(kp) then
				remaining = kp
			else
				list[kp] = nil
			end
		end

		if remaining then
			door.mb_keypads = list
			door.mb_keypad = remaining
			if MilBase.IsMapDoor(door) then door:Fire("Lock") end
			return
		end

		door.mb_keypads = nil
		door.mb_keypad = nil
		if MilBase.IsMapDoor(door) then
			door:Fire("Unlock")
		end
		if door.mb_fading then -- restore a mid-fade prop door
			door:SetNotSolid(false)
			door:SetRenderMode(RENDERMODE_NORMAL)
			door:SetColor(Color(255, 255, 255, 255))
			door.mb_fading = nil
		end
	end

	-- Button-readers redirect USE to their linked keypad; keypad-controlled doors stay locked.
	hook.Add("PlayerUse", "MilBase.KeypadDoorLock", function(ply, ent)
		if MilBase.IsReaderButton(ent) and IsValid(ent.mb_keypad) then
			ent.mb_keypad:Use(ply)
			return false
		end
		if MilBase.IsDoorKeypadLocked and MilBase.IsDoorKeypadLocked(ent) then return false end
	end)

	local function keypadPosKey(x, y, z)
		if isvector(x) then
			return string.format("%.2f|%.2f|%.2f", x.x, x.y, x.z)
		end
		return string.format("%.2f|%.2f|%.2f", tonumber(x) or 0, tonumber(y) or 0, tonumber(z) or 0)
	end

	local function findDoorNear(pos)
		local best, bestD
		for _, e in ipairs(ents.FindInSphere(pos, 24)) do
			if MilBase.IsLinkableDoor(e) then
				local dd = e:GetPos():DistToSqr(pos)
				if not bestD or dd < bestD then best, bestD = e, dd end
			end
		end
		return best
	end

	local function findButtonNear(pos)
		local best, bestD
		for _, e in ipairs(ents.FindInSphere(pos, 24)) do
			if MilBase.IsReaderButton(e) then
				local dd = e:GetPos():DistToSqr(pos)
				if not bestD or dd < bestD then best, bestD = e, dd end
			end
		end
		return best
	end

	local function linkedDoors(kp)
		if IsValid(kp) and kp.GetLinkedDoors then
			return kp:GetLinkedDoors()
		end
		local door = IsValid(kp) and kp:GetDoor() or nil
		return IsValid(door) and { door } or {}
	end

	function MilBase.SaveKeypads()
		if not schemaReady then
			ensureKeycardSchema(function(ok)
				if ok then MilBase.SaveKeypads() end
			end)
			return
		end

		local map = game.GetMap()
		MilBase.DB.Run("DELETE FROM frontier_keypads WHERE map = " .. MilBase.SQLStr(map))
		MilBase.DB.Run("DELETE FROM frontier_keypad_links WHERE map = " .. MilBase.SQLStr(map))
		MilBase.DB.Run("DELETE FROM frontier_keypad_buttons WHERE map = " .. MilBase.SQLStr(map))

		for _, kp in ipairs(ents.FindByClass("mb_keypad")) do
			local p, a = kp:GetPos(), kp:GetAngles()
			local doors = linkedDoors(kp)
			local first = doors[1]
			local d = IsValid(first) and first:GetPos() or nil

			MilBase.DB.Run(string.format(
				"INSERT INTO frontier_keypads (map,px,py,pz,ap,ay,ar,lvl,hold,dx,dy,dz,mode,pin) "
				.. "VALUES (%s,%f,%f,%f,%f,%f,%f,%d,%f,%s,%s,%s,%d,%s)",
				MilBase.SQLStr(map), p.x, p.y, p.z, a.p, a.y, a.r,
				kp:GetRequiredLevel(), kp:GetHoldTime(),
				d and d.x or "NULL", d and d.y or "NULL", d and d.z or "NULL",
				kp:GetMode(), MilBase.SQLStr(kp.mb_pin or "")))

			for _, door in ipairs(doors) do
				if IsValid(door) then
					local dp = door:GetPos()
					MilBase.DB.Run(string.format(
						"INSERT INTO frontier_keypad_links (map,kx,ky,kz,dx,dy,dz) "
						.. "VALUES (%s,%f,%f,%f,%f,%f,%f)",
						MilBase.SQLStr(map), p.x, p.y, p.z, dp.x, dp.y, dp.z))
				end
			end

			local btn = kp.GetReaderButton and kp:GetReaderButton() or NULL
			if IsValid(btn) then
				local bp = btn:GetPos()
				MilBase.DB.Run(string.format(
					"INSERT INTO frontier_keypad_buttons (map,kx,ky,kz,bx,`by`,bz) VALUES (%s,%f,%f,%f,%f,%f,%f)",
					MilBase.SQLStr(map), p.x, p.y, p.z, bp.x, bp.y, bp.z))
			end
		end
	end

	function MilBase.LoadKeypads()
		if not schemaReady then
			ensureKeycardSchema(function(ok)
				if ok then MilBase.LoadKeypads() end
			end)
			return
		end

		local map = game.GetMap()

		-- IMPORTANT: spawn the keypads FIRST, from their own table, before
		-- touching the links/buttons tables. Those two are secondary detail;
		-- if either query fails (missing table on an older DB, transient error)
		-- MilBase.DB.Query never fires onData, so nesting the keypad spawn
		-- inside them would silently drop every keypad. Keep it flat and let the
		-- links/buttons queries fail harmlessly.
		MilBase.DB.Query("SELECT * FROM frontier_keypads WHERE map = " .. MilBase.SQLStr(map), function(rows)
			local keypadsByKey = {}

			for _, r in ipairs(rows or {}) do
				local kp = MilBase.SpawnKeypad(
					Vector(tonumber(r.px), tonumber(r.py), tonumber(r.pz)),
					Angle(tonumber(r.ap), tonumber(r.ay), tonumber(r.ar)),
					tonumber(r.lvl), tonumber(r.hold))

				if IsValid(kp) then
					kp:SetMode(tonumber(r.mode) or 0)
					kp.mb_pin = r.pin or ""
					keypadsByKey[keypadPosKey(r.px, r.py, r.pz)] = kp

					-- Legacy single-door link stored on the keypad row itself.
					-- Multi-door links from frontier_keypad_links are applied
					-- below; LinkDoor is idempotent so re-linking is harmless.
					if r.dx ~= nil and r.dx ~= "NULL" and tonumber(r.dx) then
						local door = findDoorNear(Vector(tonumber(r.dx), tonumber(r.dy), tonumber(r.dz)))
						if IsValid(door) then kp:LinkDoor(door) end
					end
				end
			end

			-- Re-attach button readers (optional; failure must not matter).
			MilBase.DB.Query("SELECT * FROM frontier_keypad_buttons WHERE map = " .. MilBase.SQLStr(map), function(buttonRows)
				for _, br in ipairs(buttonRows or {}) do
					local kp = keypadsByKey[keypadPosKey(br.kx, br.ky, br.kz)]
					if IsValid(kp) and kp.AttachToButton and tonumber(br.bx) and tonumber(br.by) and tonumber(br.bz) then
						local button = findButtonNear(Vector(tonumber(br.bx), tonumber(br.by), tonumber(br.bz)))
						if IsValid(button) then kp:AttachToButton(button) end
					end
				end
			end, function() end)

			-- Re-apply multi-door links (optional; failure must not matter).
			MilBase.DB.Query("SELECT * FROM frontier_keypad_links WHERE map = " .. MilBase.SQLStr(map), function(linkRows)
				for _, lr in ipairs(linkRows or {}) do
					local kp = keypadsByKey[keypadPosKey(lr.kx, lr.ky, lr.kz)]
					if IsValid(kp) and tonumber(lr.dx) and tonumber(lr.dy) and tonumber(lr.dz) then
						local door = findDoorNear(Vector(tonumber(lr.dx), tonumber(lr.dy), tonumber(lr.dz)))
						if IsValid(door) then kp:LinkDoor(door) end
					end
				end
			end, function() end)
		end)
	end

	function MilBase.ClearKeypads()
		if not schemaReady then
			ensureKeycardSchema(function(ok)
				if ok then MilBase.ClearKeypads() end
			end)
			return
		end

		local map = game.GetMap()
		MilBase.DB.Run("DELETE FROM frontier_keypads WHERE map = " .. MilBase.SQLStr(map))
		MilBase.DB.Run("DELETE FROM frontier_keypad_links WHERE map = " .. MilBase.SQLStr(map))
		MilBase.DB.Run("DELETE FROM frontier_keypad_buttons WHERE map = " .. MilBase.SQLStr(map))
		for _, kp in ipairs(ents.FindByClass("mb_keypad")) do kp:Remove() end
	end

	net.Receive("MilBase_KeypadSave", function(_, ply)
		if not canConfig(ply) then return end
		MilBase.SaveKeypads()
		MilBase.Notify(ply, "Keypads saved for " .. game.GetMap() .. ".", "ok")
	end)

	net.Receive("MilBase_KeypadClear", function(_, ply)
		if not canConfig(ply) then return end
		MilBase.ClearKeypads()
		MilBase.Notify(ply, "All keypads on this map cleared.", "warn")
	end)

	net.Receive("MilBase_KeypadPINEnter", function(_, ply)
		local kp = net.ReadEntity()
		local pin = string.sub(net.ReadString() or "", 1, 12)
		if IsValid(kp) and kp:GetClass() == "mb_keypad" and kp.SubmitPIN then
			kp:SubmitPIN(ply, pin)
		end
	end)

	hook.Add("InitPostEntity", "MilBase.LoadKeypads", function()
		timer.Simple(1, MilBase.LoadKeypads)
	end)
	hook.Add("PostCleanupMap", "MilBase.LoadKeypads", function()
		timer.Simple(0.5, MilBase.LoadKeypads)
	end)

	return
end

--------------------------------------------------------------------------
-- Client: receive data + the KEYCARDS config tab
--------------------------------------------------------------------------

net.Receive("MilBase_KeycardData", function()
	MilBase.Keycard.Tiers = normalizeTiers(util.JSONToTable(net.ReadString() or ""))
	MilBase.Keycard.Grants = normalizeGrants(util.JSONToTable(net.ReadString() or ""))
	if MilBase.RefreshMenu then MilBase.RefreshMenu() end
end)

--------------------------------------------------------------------------
-- KEYCARDS config tab (admin): define tiers + assign rank -> tier
--------------------------------------------------------------------------

local PALETTE = {
	{ 220, 70, 60 }, { 230, 145, 50 }, { 235, 205, 70 }, { 110, 195, 115 },
	{ 90, 150, 235 }, { 160, 110, 220 }, { 235, 120, 190 }, { 205, 205, 210 },
}

local menuFaction -- currently-edited faction id (persists across rebuilds)

local function smallBtn(parent, label, onClick)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.mb = label
	b.DoClick = onClick
	b.Paint = function(self, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 5,
			color = self:IsHovered() and ui.hover or ui.raised,
		})
		draw.SimpleText(self.mb, "MB.Small", w / 2, h / 2, ui.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	return b
end

local function sendTiers()
	net.Start("MilBase_KC_SetTiers")
		net.WriteString(util.TableToJSON(MilBase.Keycard.Tiers))
	net.SendToServer()
end

local function sendGrant(fid, rank, level)
	net.Start("MilBase_KC_SetGrant")
		net.WriteString(fid)
		net.WriteUInt(rank, 8)
		net.WriteUInt(level, 8)
	net.SendToServer()
end

MilBase.AddMenuTab("KEYCARDS", 93, function(content)
	local ui = MilBase.UI
	local tiers = MilBase.Keycard.Tiers

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	-- Re-run this tab's builder (structural changes: add/remove tier, faction).
	local function rebuild()
		content:Clear()
		timer.Simple(0, function()
			if not IsValid(content) then return end
			for _, tab in ipairs(MilBase.MenuTabs) do
				if tab.name == "KEYCARDS" then tab.build(content) break end
			end
		end)
	end

	local function header(text)
		local h = vgui.Create("DLabel", scroll)
		h:Dock(TOP)
		h:SetFont("MB.Med")
		h:SetText(text)
		h:SetTextColor(ui.accent)
		h:DockMargin(0, 6, 0, 6)
		h:SizeToContents()
	end

	local function hint(text)
		local l = vgui.Create("DLabel", scroll)
		l:Dock(TOP)
		l:SetFont("MB.Tiny")
		l:SetText(text)
		l:SetTextColor(ui.dim)
		l:DockMargin(0, 0, 0, 8)
		l:SetWrap(true)
		l:SetAutoStretchVertical(true)
	end

	----------------------------------------------------------------
	-- TIERS
	----------------------------------------------------------------
	header("KEYCARD TIERS")
	hint("Level 1 is the lowest clearance. Rename a tier, click its colour to "
		.. "recycle it, or remove it. Keypads require a tier level to open.")

	for i, tier in ipairs(tiers) do
		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(40)
		row:DockMargin(0, 0, 8, 6)
		row.Paint = function(_, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText("LVL " .. i, "MB.Tiny", 12, h / 2,
				MilBase.KeycardTierColor(i), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local name = vgui.Create("DTextEntry", row)
		name:SetText(tier.name or ("Level " .. i))
		name:SetFont("MB.Small")
		name.Paint = function(self, w, h)
			surface.SetDrawColor(0, 0, 0, 150)
			surface.DrawRect(0, 0, w, h)
			self:DrawTextEntryText(ui.text, ui.dim, ui.text)
		end
		name.OnEnter = function(self) self:KillFocus() end
		name.OnLoseFocus = function(self)
			tier.name = string.sub(self:GetValue(), 1, 40)
			sendTiers()
		end

		local swatch = vgui.Create("DButton", row)
		swatch:SetText("")
		swatch.Paint = function(_, w, h)
			surface.SetDrawColor(tier.r or 200, tier.g or 200, tier.b or 200)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255, 40)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		swatch.DoClick = function()
			-- Advance to the next palette colour.
			local idx = 1
			for k, c in ipairs(PALETTE) do
				if c[1] == tier.r and c[2] == tier.g and c[3] == tier.b then idx = k break end
			end
			local nxt = PALETTE[idx % #PALETTE + 1]
			tier.r, tier.g, tier.b = nxt[1], nxt[2], nxt[3]
			sendTiers()
		end

		local del = smallBtn(row, "REMOVE", function()
			if #MilBase.Keycard.Tiers <= 1 then return end
			table.remove(MilBase.Keycard.Tiers, i)
			sendTiers()
			rebuild()
		end)

		row.PerformLayout = function(_, w, h)
			name:SetPos(64, 8); name:SetSize(w - 64 - 40 - 90 - 24, h - 16)
			swatch:SetPos(w - 40 - 90 - 12, 8); swatch:SetSize(40, h - 16)
			del:SetPos(w - 90 - 4, 8); del:SetSize(90, h - 16)
		end
	end

	local add = smallBtn(scroll, "+ ADD TIER", function()
		if #MilBase.Keycard.Tiers >= 12 then return end
		local n = #MilBase.Keycard.Tiers + 1
		local c = PALETTE[(n - 1) % #PALETTE + 1]
		table.insert(MilBase.Keycard.Tiers, { name = "Level " .. n, r = c[1], g = c[2], b = c[3] })
		sendTiers()
		rebuild()
	end)
	add:Dock(TOP)
	add:SetTall(30)
	add:DockMargin(0, 2, 8, 14)

	----------------------------------------------------------------
	-- RANK ACCESS
	----------------------------------------------------------------
	header("RANK ACCESS")
	hint("Pick a regiment, then set which keycard tier each rank is issued. "
		.. "0 = no keycard. Soldiers get their card on spawn.")

	-- Faction selector strip.
	local pick = vgui.Create("DPanel", scroll)
	pick:Dock(TOP)
	pick:SetTall(30)
	pick:DockMargin(0, 0, 8, 8)
	pick.Paint = nil

	if not menuFaction or not MilBase.GetFaction(menuFaction) then
		menuFaction = MilBase.FactionOrder[1]
	end

	for _, fid in ipairs(MilBase.FactionOrder) do
		local f = MilBase.GetFaction(fid)
		local btn = vgui.Create("DButton", pick)
		btn:Dock(LEFT)
		btn:DockMargin(0, 0, 6, 0)
		btn:SetText("")
		surface.SetFont("MB.Tiny")
		btn:SetWide(surface.GetTextSize(f.name) + 20)
		btn.Paint = function(self, w, h)
			local on = menuFaction == fid
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 5,
				color = on and Color(f.color.r, f.color.g, f.color.b, 60) or MilBase.UI.raised,
			})
			draw.SimpleText(f.name, "MB.Tiny", w / 2, h / 2,
				on and MilBase.UI.text or MilBase.UI.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = function() menuFaction = fid rebuild() end
	end

	local faction = MilBase.GetFaction(menuFaction)
	local grants = MilBase.Keycard.Grants[menuFaction] or {}

	for i, rank in ipairs(faction.ranks or {}) do
		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(38)
		row:DockMargin(0, 0, 8, 4)
		row.Paint = function(_, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText(rank.name, "MB.Small", 12, h / 2, ui.text,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			local lvl = tonumber((MilBase.Keycard.Grants[menuFaction] or {})[tostring(i)]) or 0
			local txt = lvl > 0 and MilBase.KeycardTierName(lvl) or "No keycard"
			draw.SimpleText(txt, "MB.Small", w - 96, h / 2,
				lvl > 0 and MilBase.KeycardTierColor(lvl) or ui.faint,
				TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local function setLvl(d)
			local cur = tonumber((MilBase.Keycard.Grants[menuFaction] or {})[tostring(i)]) or 0
			local maxTier = #MilBase.Keycard.Tiers
			if maxTier < 1 then maxTier = #DEFAULT_TIERS end
			local nl = math.Clamp(cur + d, 0, maxTier)
			MilBase.Keycard.Grants[menuFaction] = MilBase.Keycard.Grants[menuFaction] or {}
			MilBase.Keycard.Grants[menuFaction][tostring(i)] = nl > 0 and nl or nil
			sendGrant(menuFaction, i, nl)
		end

		local dec = smallBtn(row, "-", function() setLvl(-1) end)
		local inc = smallBtn(row, "+", function() setLvl(1) end)
		row.PerformLayout = function(_, w, h)
			inc:SetPos(w - 36, 7); inc:SetSize(30, h - 14)
			dec:SetPos(w - 72, 7); dec:SetSize(30, h - 14)
		end
	end

	header("KEYPADS")
	hint("Use the Keypad tool (Q -> MilBase category, admin) to place keypads, "
		.. "link them to one or more doors, set the mode / tier / PIN, then SAVE them there. "
		.. "Shoot a keypad to breach its linked door(s); Saboteurs crouch+E to crack; "
		.. "Engineers USE a broken keypad (repair kit) to fix it.")
end, function(lp) return lp:IsAdmin() or lp:IsSuperAdmin() end)

--------------------------------------------------------------------------
-- Client: PIN entry pad
--------------------------------------------------------------------------

local DIGIT_KEYS = {
	[KEY_0] = "0", [KEY_1] = "1", [KEY_2] = "2", [KEY_3] = "3", [KEY_4] = "4",
	[KEY_5] = "5", [KEY_6] = "6", [KEY_7] = "7", [KEY_8] = "8", [KEY_9] = "9",
	[KEY_PAD_0] = "0", [KEY_PAD_1] = "1", [KEY_PAD_2] = "2", [KEY_PAD_3] = "3",
	[KEY_PAD_4] = "4", [KEY_PAD_5] = "5", [KEY_PAD_6] = "6", [KEY_PAD_7] = "7",
	[KEY_PAD_8] = "8", [KEY_PAD_9] = "9",
}

function MilBase.OpenKeypadPIN(kp)
	if IsValid(MilBase._pinFrame) then MilBase._pinFrame:Remove() end
	local ui = MilBase.UI
	local entered = ""

	local frame = vgui.Create("DFrame")
	MilBase._pinFrame = frame
	frame:SetSize(240, 320)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:MakePopup()
	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 10, color = Color(10, 10, 12, 245), accent = ui.accent })
		draw.SimpleText("ENTER PIN", "MB.Med", w / 2, 22, ui.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(0, 0, 0, 160)
		surface.DrawRect(20, 42, w - 40, 34)
		draw.SimpleText(entered == "" and "----" or string.rep("*", #entered), "MB.Big",
			w / 2, 60, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local function submit()
		if IsValid(kp) then
			net.Start("MilBase_KeypadPINEnter")
				net.WriteEntity(kp)
				net.WriteString(entered)
			net.SendToServer()
		end
		frame:Remove()
	end

	local grid = vgui.Create("DPanel", frame)
	grid:SetPos(20, 88)
	grid:SetSize(200, 216)
	grid.Paint = nil

	for i, lab in ipairs({ "1", "2", "3", "4", "5", "6", "7", "8", "9", "CLR", "0", "OK" }) do
		local b = vgui.Create("DButton", grid)
		b:SetPos(((i - 1) % 3) * 68, math.floor((i - 1) / 3) * 54)
		b:SetSize(62, 48)
		b:SetText("")
		b.Paint = function(self, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6, color = self:IsHovered() and ui.hover or ui.raised })
			local c = lab == "OK" and ui.ok or lab == "CLR" and ui.warn or ui.text
			draw.SimpleText(lab, "MB.Med", w / 2, h / 2, c, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = function()
			surface.PlaySound("buttons/button24.wav")
			if lab == "CLR" then entered = ""
			elseif lab == "OK" then submit()
			elseif #entered < 12 then entered = entered .. lab end
		end
	end

	-- Keyboard support (digits / backspace / enter).
	frame.OnKeyCodeTyped = function(_, code)
		if DIGIT_KEYS[code] then
			if #entered < 12 then entered = entered .. DIGIT_KEYS[code] end
		elseif code == KEY_BACKSPACE then
			entered = string.sub(entered, 1, -2)
		elseif code == KEY_ENTER or code == KEY_PAD_ENTER then
			submit()
		end
	end
end

net.Receive("MilBase_KeypadPIN", function()
	local kp = net.ReadEntity()
	if IsValid(kp) then MilBase.OpenKeypadPIN(kp) end
end)

--------------------------------------------------------------------------
-- Client: crack / repair progress bars over keypads
--------------------------------------------------------------------------

hook.Add("HUDPaint", "MilBase.KeypadActionHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local cfg = MilBase.Config

	for _, kp in ipairs(ents.FindByClass("mb_keypad")) do
		local act = kp:GetAction()
		if act == 0 then continue end
		if lp:GetPos():DistToSqr(kp:GetPos()) > 700 * 700 then continue end

		local sp = (kp:GetPos() + kp:GetUp() * 12):ToScreen()
		if not sp.visible then continue end

		local dur = act == 1 and (cfg.KeypadCrackTime or 8) or (cfg.KeypadRepairTime or 6)
		local frac = math.Clamp(1 - (kp:GetActionEnd() - CurTime()) / dur, 0, 1)
		local col = act == 1 and Color(255, 140, 0) or Color(90, 180, 255)
		local bw = 120

		surface.SetDrawColor(0, 0, 0, 200)
		surface.DrawRect(sp.x - bw / 2 - 2, sp.y - 2, bw + 4, 14)
		surface.SetDrawColor(col.r, col.g, col.b, 255)
		surface.DrawRect(sp.x - bw / 2, sp.y, bw * frac, 10)
		draw.SimpleTextOutlined(act == 1 and "CRACKING" or "REPAIRING", "MB.Tiny",
			sp.x, sp.y - 12, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, color_black)
	end
end)
