--[[
	Custom notifications: a stacked BF2-styled toast queue on the right
	edge, replacing GMod's notification.AddLegacy. Toasts slide in from the
	right, hold, then fade. An optional "kind" (ok/warn/danger/info) colours
	the accent bar and dot.

	Server:  MilBase.Notify(ply, text[, kind])
	Client:  MilBase.Notify(text[, kind])  /  MilBase.AddNotification(text, kind)
]]

surface.CreateFont("MB.Notify", { font = "D-DIN", size = 17, weight = 600 })

local toasts = {}
local PAD = 12
local WIDTH = 300
local LIFE = 5.5   -- seconds fully shown
local SLIDE = 0.22 -- slide-in time
local FADE = 0.6   -- fade-out time

local function kindColor(kind)
	local ui = MilBase.UI
	if kind == "ok" or kind == "good" then return ui.ok end
	if kind == "warn" then return ui.warn end
	if kind == "danger" or kind == "bad" then return ui.danger end
	return ui.accent
end

-- Word-wrap text to WIDTH (inside padding) using the notify font.
local function wrap(text)
	surface.SetFont("MB.Notify")
	local maxW = WIDTH - 24
	local lines, line = {}, ""

	for word in string.gmatch(text, "%S+%s*") do
		local test = line .. word
		if surface.GetTextSize(test) > maxW and line ~= "" then
			lines[#lines + 1] = string.TrimRight(line)
			line = word
		else
			line = test
		end
	end
	if line ~= "" then lines[#lines + 1] = string.TrimRight(line) end
	if #lines == 0 then lines[1] = "" end
	return lines
end

function MilBase.AddNotification(text, kind)
	if not isstring(text) or text == "" then return end

	local lines = wrap(text)
	toasts[#toasts + 1] = {
		lines = lines,
		kind = kind or "info",
		born = CurTime(),
		h = math.max(46, #lines * 19 + 22),
	}

	-- Cap the on-screen count.
	while #toasts > 8 do table.remove(toasts, 1) end
end

-- Override the shared client notify so every existing MilBase.Notify call
-- routes here. Tolerates ("text"), ("text","kind") and the legacy
-- (anything, "text") form.
function MilBase.Notify(a, b, c)
	local text, kind
	if isstring(a) then
		text, kind = a, (isstring(b) and b or c)
	else
		text, kind = (isstring(b) and b or nil), (isstring(c) and c or nil)
	end
	if not isstring(text) then return end

	MilBase.AddNotification(text, kind)
	if MilBase.PlayUISound then MilBase.PlayUISound("notify") else surface.PlaySound("buttons/button15.wav") end
end

-- Server-sent notifications (now carry an optional kind string).
net.Receive("MilBase_Notify", function()
	local text = net.ReadString()
	local kind = net.ReadString()
	MilBase.AddNotification(text, kind ~= "" and kind or "info")
	if MilBase.PlayUISound then MilBase.PlayUISound("notify") else surface.PlaySound("buttons/button15.wav") end
end)

hook.Add("HUDPaint", "MilBase.Notifications", function()
	if #toasts == 0 then return end

	local ui = MilBase.UI
	local now = CurTime()
	local baseX = ScrW() - 24
	local y = math.floor(ScrH() * 0.30)

	for i = #toasts, 1, -1 do
		local t = toasts[i]
		local age = now - t.born

		if age > SLIDE + LIFE + FADE then
			table.remove(toasts, i)
		else
			-- alpha + slide easing
			local alpha, slide = 255, 0
			if age < SLIDE then
				local f = age / SLIDE
				alpha = 255 * f
				slide = (1 - f) * (WIDTH + 40)
			elseif age > SLIDE + LIFE then
				alpha = 255 * (1 - (age - SLIDE - LIFE) / FADE)
			end

			local col = kindColor(t.kind)
			local x = baseX - WIDTH + slide

			MilBase.DrawPanelBF2(x, y, WIDTH, t.h, {
				cut = 8,
				color = Color(12, 12, 14, alpha * 0.92),
				outlineColor = Color(col.r, col.g, col.b, alpha * 0.5),
			})

			-- Accent bar + status dot.
			surface.SetDrawColor(col.r, col.g, col.b, alpha)
			surface.DrawRect(x, y + 8, 3, t.h - 16)
			surface.DrawRect(x + 13, y + 13, 6, 6)

			for li, line in ipairs(t.lines) do
				draw.SimpleText(line, "MB.Notify", x + 30, y + 12 + (li - 1) * 19,
					Color(ui.text.r, ui.text.g, ui.text.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end

			y = y + t.h + PAD
		end
	end
end)
