--[[
	MilBase x LSCS core.

	Server-authoritative skill progression, LSCS inventory persistence, access
	control, and staff actions. The F4/F2 interfaces and custom HUD live in
	cl_lscs.lua; all gameplay decisions remain on the server.
]]

if MilBase._LSCSCoreLoaded then return end
MilBase._LSCSCoreLoaded = true

MilBase.LSCS = MilBase.LSCS or {}
local MBLSCS = MilBase.LSCS
local cfg = MilBase.Config.LSCS or {}

MBLSCS.Branches = {}
MBLSCS.BranchOrder = {}
MBLSCS.Nodes = cfg.Nodes or {}
MBLSCS.NodeOrder = {}
MBLSCS.ManagedItems = {}

for index, branch in ipairs(cfg.Branches or {}) do
	branch.index = index
	MBLSCS.Branches[branch.id] = branch
	MBLSCS.BranchOrder[#MBLSCS.BranchOrder + 1] = branch.id
end

for id, node in pairs(MBLSCS.Nodes) do
	node.id = id
	node.cost = math.max(0, math.floor(tonumber(node.cost) or 0))
	node.row = math.max(1, math.floor(tonumber(node.row) or 1))
	node.requires = node.requires or {}
	MBLSCS.NodeOrder[#MBLSCS.NodeOrder + 1] = id
	if node.item then
		MBLSCS.ManagedItems[node.item] = MBLSCS.ManagedItems[node.item] or {}
		table.insert(MBLSCS.ManagedItems[node.item], id)
	end
end

table.sort(MBLSCS.NodeOrder, function(a, b)
	local na, nb = MBLSCS.Nodes[a], MBLSCS.Nodes[b]
	local ba = MBLSCS.Branches[na.branch]
	local bb = MBLSCS.Branches[nb.branch]
	local ai, bi = ba and ba.index or 999, bb and bb.index or 999
	if ai ~= bi then return ai < bi end
	if na.row ~= nb.row then return na.row < nb.row end
	return a < b
end)

function MBLSCS.GetNode(id)
	return MBLSCS.Nodes[id]
end

function MBLSCS.MeetsRequirements(unlocked, node)
	for _, required in ipairs((node and node.requires) or {}) do
		if not unlocked[required] then return false, required end
	end
	return true
end

function MBLSCS.IsInstalled()
	return istable(LSCS) and isfunction(LSCS.ClassToItem)
end

-- Keep all calls into LSCS behind a small compatibility layer. LSCS is an
-- addon and may finish loading after the gamemode, or be refreshed while
-- players are already connected. Direct method calls made during that window
-- used to leave the MilBase restore pipeline permanently stalled.
function MBLSCS.ClassToItem(class)
	if not MBLSCS.IsInstalled() or not isstring(class) or class == "" then return nil end
	local ok, item = pcall(LSCS.ClassToItem, LSCS, class)
	if not ok then return nil end
	return item
end

function MBLSCS.IsNetworkReady(ply)
	if not IsValid(ply) then return false end
	-- `_lscsNetworkingReady` is LSCS's authoritative server-side readiness
	-- marker. The public hook that sets it is intentionally one-shot, so using
	-- it as a fallback also repairs late gamemode loads and Lua refreshes.
	if ply._lscsNetworkingReady == true then
		ply.mb_lscsNetworkReady = true
	end
	return ply.mb_lscsNetworkReady == true
end

function MBLSCS.HasInventoryAPI(ply)
	return IsValid(ply)
		and isfunction(ply.lscsGetInventory)
		and isfunction(ply.lscsGetEquipped)
		and isfunction(ply.lscsAddInventory)
end

function MBLSCS.IsSaberWeapon(entity)
	if not IsValid(entity) then return false end
	if entity.LSCS == true then return true end
	local class = entity.GetClass and entity:GetClass() or ""
	return class == "weapon_lscs" or string.StartWith(class, "weapon_lscs_")
end

function MBLSCS.IsSaberDamage(dmg)
	if not dmg then return false end
	local inflictor = dmg:GetInflictor()
	if MBLSCS.IsSaberWeapon(inflictor) then return true end

	-- Some LSCS-derived weapons report the player as inflictor. Only accept
	-- that fallback for saber-like damage so Force powers are not scaled as
	-- lightsaber strikes.
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker:IsPlayer() and inflictor == attacker
	and (dmg:IsDamageType(DMG_ENERGYBEAM) or dmg:IsDamageType(DMG_SLASH)) then
		return MBLSCS.IsSaberWeapon(attacker:GetActiveWeapon())
	end
	return false
end

local PLAYER = FindMetaTable("Player")

function PLAYER:MBLSCSHasSkill(id)
	if SERVER then return self.mb_lscsUnlocked and self.mb_lscsUnlocked[id] == true end
	if self ~= LocalPlayer() then return false end
	return MBLSCS.ClientUnlocked and MBLSCS.ClientUnlocked[id] == true
end

function PLAYER:MBLSCSPoints()
	return self:GetNWInt("mb_lscs_points", 0)
end

function PLAYER:MBLSCSAccess()
	return self:MBIsJedi() and self:GetNWBool("mb_lscs_access", true)
end

if CLIENT then return end

if cfg.Enabled == false then return end

util.AddNetworkString("MilBase_LSCSSync")
util.AddNetworkString("MilBase_LSCSPurchase")
util.AddNetworkString("MilBase_LSCSAdmin")
util.AddNetworkString("MilBase_LSCSAdminState")

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_lscs_progress (
	steamid VARCHAR(32) PRIMARY KEY,
	points INTEGER,
	xp_milestones INTEGER,
	unlocked TEXT,
	access_enabled INTEGER
)]])

MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_lscs_inventory (
	steamid VARCHAR(32),
	slot_id INTEGER,
	item_class VARCHAR(128),
	equipped INTEGER,
	PRIMARY KEY (steamid, slot_id)
)]])

local function clampPoints(value)
	return math.Clamp(math.floor(tonumber(value) or 0), 0, cfg.MaxPoints or 9999)
end

local function factionDefaultAccess(ply)
	local allowed = cfg.AllowedFactions
	if not istable(allowed) or table.IsEmpty(allowed) then return true end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local id = ply.MBFactionID and ply:MBFactionID() or ""
	return allowed[id] == true or (faction and allowed[faction.name] == true) or false
end

local function encodeUnlocks(unlocked)
	local ids = {}
	for id in pairs(unlocked or {}) do
		if MBLSCS.Nodes[id] then ids[#ids + 1] = id end
	end
	table.sort(ids)
	return table.concat(ids, ",")
end

local function decodeUnlocks(raw)
	local result = {}
	for id in string.gmatch(raw or "", "([^,]+)") do
		if MBLSCS.Nodes[id] then result[id] = true end
	end
	return result
end

local function syncProgress(ply)
	if not IsValid(ply) then return end
	ply:SetNWInt("mb_lscs_points", clampPoints(ply.mb_lscsPoints))
	ply:SetNWInt("mb_lscs_xp_milestones", math.max(0, ply.mb_lscsMilestones or 0))
	ply:SetNWBool("mb_lscs_access", ply.mb_lscsAccess ~= false)
	ply:SetNWBool("mb_lscs_loaded", ply.mb_lscsProgressLoaded == true)

	net.Start("MilBase_LSCSSync")
		net.WriteTable(ply.mb_lscsUnlocked or {})
	net.Send(ply)
end

MBLSCS.SyncProgress = syncProgress

function MBLSCS.SaveProgress(ply)
	if not IsValid(ply) or not ply.mb_lscsProgressLoaded then return end
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_lscs_progress (steamid, points, xp_milestones, unlocked, access_enabled) VALUES (%s, %d, %d, %s, %d)",
		MilBase.SQLStr(ply:MBCharacterKey()),
		clampPoints(ply.mb_lscsPoints),
		math.max(0, math.floor(ply.mb_lscsMilestones or 0)),
		MilBase.SQLStr(encodeUnlocks(ply.mb_lscsUnlocked)),
		ply.mb_lscsAccess == false and 0 or 1
	))
end

local function calculateEffects(ply)
	local effects = {
		maxForce = tonumber(cfg.BaseMaxForce) or 100,
		forceRegen = tonumber(cfg.BaseForceRegen) or 1,
		saberDamage = 1,
		saberDefense = 0,
	}

	for id in pairs(ply.mb_lscsUnlocked or {}) do
		local node = MBLSCS.Nodes[id]
		local add = node and node.effects or nil
		local advancedAllowed = not MBLSCS.CanLearnAdvanced
			or (node and MBLSCS.CanLearnAdvanced(ply, node))
		if add and advancedAllowed then
			effects.maxForce = effects.maxForce + (tonumber(add.maxForce) or 0)
			effects.forceRegen = effects.forceRegen + (tonumber(add.forceRegen) or 0)
			effects.saberDamage = effects.saberDamage + (tonumber(add.saberDamage) or 0)
			effects.saberDefense = effects.saberDefense + (tonumber(add.saberDefense) or 0)
		end
	end

	effects.maxForce = math.max(0, effects.maxForce)
	effects.forceRegen = math.max(0, effects.forceRegen)
	effects.saberDamage = math.Clamp(effects.saberDamage, 0, 5)
	effects.saberDefense = math.Clamp(effects.saberDefense, 0, 0.75)
	return effects
end

function MBLSCS.ApplySkills(ply, refill)
	if not IsValid(ply) or not ply.mb_lscsProgressLoaded then return end
	local effects = calculateEffects(ply)
	ply:SetNWFloat("mb_lscs_damage_mult", effects.saberDamage)
	ply:SetNWFloat("mb_lscs_defense", effects.saberDefense)

	if not MBLSCS.IsInstalled() or not isfunction(ply.lscsSetMaxForce) then return end
	if not ply:MBLSCSAccess() then
		if isfunction(ply.lscsSetForceAllowed) then ply:lscsSetForceAllowed(false) end
		ply:StripWeapon("weapon_lscs")
		return
	end

	-- Re-enable first for older LSCS builds where max/regen setters were
	-- ignored while Force usage was disabled.
	if isfunction(ply.lscsSetForceAllowed) then ply:lscsSetForceAllowed(true) end
	ply:lscsSetMaxForce(effects.maxForce)
	if isfunction(ply.lscsSetForceRegenAmount) then ply:lscsSetForceRegenAmount(effects.forceRegen) end
	if isfunction(ply.lscsSetForce) and isfunction(ply.lscsGetForce) then
		local current = tonumber(ply:lscsGetForce()) or effects.maxForce
		ply:lscsSetForce(refill and effects.maxForce or math.min(current, effects.maxForce))
	end
end

local function findInventoryClass(ply, class)
	if not ply.lscsGetInventory then return nil end
	for index, itemClass in pairs(ply:lscsGetInventory()) do
		if itemClass == class then return index end
	end
end

local function managedItemShouldExist(ply, class)
	for _, nodeID in ipairs(MBLSCS.ManagedItems[class] or {}) do
		if ply.mb_lscsUnlocked and ply.mb_lscsUnlocked[nodeID] then return true end
	end
	return false
end

function MBLSCS.ReconcileItems(ply, prune, equipExisting)
	if not IsValid(ply) or not ply.mb_lscsProgressLoaded then return end
	if not MBLSCS.IsNetworkReady(ply) or not ply.mb_lscsInventoryRestored then return end
	if not ply:MBLSCSAccess() or not MBLSCS.IsInstalled() then return end
	if not MBLSCS.HasInventoryAPI(ply) then return end

	ply.mb_lscsReconciling = true
	local removed = false

	if prune and ply.lscsRemoveItem then
		local remove = {}
		for index, class in pairs(ply:lscsGetInventory()) do
			if MBLSCS.ManagedItems[class] and not managedItemShouldExist(ply, class) then
				remove[#remove + 1] = index
			end
		end
		table.sort(remove, function(a, b) return a > b end)
		for _, index in ipairs(remove) do
			local equipped = ply:lscsGetEquipped()[index]
			if isbool(equipped) and ply.lscsEquipItem then ply:lscsEquipItem(index, nil) end
			ply:lscsRemoveItem(index)
			removed = true
		end
	end

	for class in pairs(MBLSCS.ManagedItems) do
		if managedItemShouldExist(ply, class) then
			local index = findInventoryClass(ply, class)
			local loadoutManaged = MBLSCS.IsLoadoutClass and MBLSCS.IsLoadoutClass(class)
			local shouldEquip = not loadoutManaged
				or (MBLSCS.ShouldEquipClass and MBLSCS.ShouldEquipClass(ply, class))
			if not index then
				ply:lscsAddInventory(class, shouldEquip and true or nil)
			elseif loadoutManaged and ply.lscsEquipItem then
				local equipped = ply:lscsGetEquipped()[index]
				if shouldEquip and not isbool(equipped) then
					ply:lscsEquipItem(index, true)
				elseif not shouldEquip and isbool(equipped) then
					ply:lscsEquipItem(index, nil)
				end
			elseif equipExisting then
				local equipped = ply:lscsGetEquipped()[index]
				if not isbool(equipped) and ply.lscsEquipItem then
					ply:lscsEquipItem(index, true)
				end
			end
		end
	end

	if removed and ply.lscsBuildPlayerInfo then ply:lscsBuildPlayerInfo() end
	if ply.lscsSyncInventory then ply:lscsSyncInventory() end
	ply.mb_lscsReconciling = nil

	if MBLSCS.QueueInventorySave then MBLSCS.QueueInventorySave(ply) end
end

local function setAccess(ply, enabled)
	ply.mb_lscsPendingFactionAccess = nil
	ply.mb_lscsAccess = enabled == true
	syncProgress(ply)
	MBLSCS.ApplySkills(ply, enabled == true and ply:MBIsJedi())
	if enabled and ply:MBIsJedi() then
		if not ply.mb_lscsInventoryRestored then
			MBLSCS.TryRestoreInventory(ply)
		else
			MBLSCS.ReconcileItems(ply, false)
		end
	end
	MBLSCS.SaveProgress(ply)
	if MBLSCS.ScheduleBootstrap then MBLSCS.ScheduleBootstrap(ply, enabled == true and ply:MBIsJedi()) end
end

function MBLSCS.LoadProgress(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	local sid = MilBase.SQLStr(key)
	MilBase.DB.Query("SELECT * FROM frontier_lscs_progress WHERE steamid = " .. sid, function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		local row = rows[1]
		ply.mb_lscsPoints = row and clampPoints(row.points) or clampPoints(cfg.StartingPoints or 0)
		ply.mb_lscsMilestones = row and math.max(0, tonumber(row.xp_milestones) or 0) or 0
		ply.mb_lscsUnlocked = decodeUnlocks(row and row.unlocked or "")
		if row then
			ply.mb_lscsAccess = tonumber(row.access_enabled) ~= 0
		elseif ply.mb_fullyLoaded then
			ply.mb_lscsAccess = factionDefaultAccess(ply)
		else
			ply.mb_lscsAccess = true
			ply.mb_lscsPendingFactionAccess = true
		end
		ply.mb_lscsProgressLoaded = true
		syncProgress(ply)
		MBLSCS.ApplySkills(ply, true)
		MBLSCS.TryRestoreInventory(ply)
		MBLSCS.ReconcileItems(ply, false)
		if MBLSCS.OnBaseProgressLoaded then MBLSCS.OnBaseProgressLoaded(ply) end
		if not row then MBLSCS.SaveProgress(ply) end
	end)
end

local function inventorySnapshot(ply)
	local result = {}
	if not IsValid(ply) or not ply.lscsGetInventory or not ply.lscsGetEquipped then return result end
	local equipped = ply:lscsGetEquipped()
	for index, class in pairs(ply:lscsGetInventory()) do
		local state = -1
		if equipped[index] == true then state = 1 elseif equipped[index] == false then state = 0 end
		result[#result + 1] = {
			index = math.Clamp(math.floor(tonumber(index) or 1), 1, 127),
			class = string.sub(tostring(class or ""), 1, 128),
			equipped = state,
		}
	end
	table.sort(result, function(a, b) return a.index < b.index end)
	return result
end

MBLSCS.InventorySaves = MBLSCS.InventorySaves or {}

function MBLSCS.SaveInventory(ply)
	if cfg.PersistInventory == false or not IsValid(ply) then return end
	if not ply.mb_lscsInventoryLoaded or ply.mb_lscsRestoring then return end
	local sid64 = ply:MBCharacterKey()
	local snapshot = inventorySnapshot(ply)
	local state = MBLSCS.InventorySaves[sid64] or { busy = false }
	MBLSCS.InventorySaves[sid64] = state
	state.pending = snapshot
	if state.busy then return end

	local writeNext
	writeNext = function()
		local current = state.pending
		if not current then
			state.busy = false
			MBLSCS.InventorySaves[sid64] = nil
			return
		end

		state.pending = nil
		state.busy = true
		local function finished()
			state.busy = false
			writeNext()
		end

		MilBase.DB.Query("DELETE FROM frontier_lscs_inventory WHERE steamid = " .. MilBase.SQLStr(sid64), function()
			local values = {}
			for _, item in ipairs(current) do
				if item.class ~= "" then
					values[#values + 1] = string.format("(%s, %d, %s, %d)",
						MilBase.SQLStr(sid64), item.index, MilBase.SQLStr(item.class), item.equipped)
				end
			end
			if #values == 0 then finished() return end
			MilBase.DB.Query(
				"REPLACE INTO frontier_lscs_inventory (steamid, slot_id, item_class, equipped) VALUES "
					.. table.concat(values, ","),
				finished,
				finished
			)
		end, finished)
	end

	writeNext()
end

function MBLSCS.QueueInventorySave(ply)
	if cfg.PersistInventory == false or not IsValid(ply) then return end
	if ply.mb_lscsRestoring or ply.mb_lscsReconciling then return end
	local timerName = "MilBase.LSCSInventorySave." .. ply:MBCharacterKey()
	timer.Create(timerName, 0.5, 1, function()
		if IsValid(ply) then MBLSCS.SaveInventory(ply) end
	end)
end

function MBLSCS.TryRestoreInventory(ply)
	if not IsValid(ply) or ply.mb_lscsInventoryRestored then return end
	if not ply.mb_lscsProgressLoaded then return end
	if ply.mb_lscsPendingFactionAccess then return end
	if not ply.mb_lscsInventoryLoaded or not MBLSCS.IsNetworkReady(ply) then return end
	if not ply:MBLSCSAccess() or not MBLSCS.IsInstalled() then return end
	if not MBLSCS.HasInventoryAPI(ply) then return end

	local saved = ply.mb_lscsSavedInventory or {}
	ply.mb_lscsRestoring = true
	if #saved > 0 and ply.lscsWipeInventory then
		ply:lscsWipeInventory()
		for _, item in ipairs(saved) do
			local equip
			if item.equipped == 1 then equip = true elseif item.equipped == 0 then equip = false end
			if MBLSCS.ClassToItem(item.class) then
				ply:lscsAddInventory(item.class, equip, item.index)
			end
		end
	end
	ply.mb_lscsRestoring = nil
	ply.mb_lscsInventoryRestored = true
	MBLSCS.ReconcileItems(ply, true)
	MBLSCS.ApplySkills(ply, true)
	if MBLSCS.TryCraftSaber then MBLSCS.TryCraftSaber(ply, true) end
end

function MBLSCS.TryCraftSaber(ply, forceRebuild)
	if not IsValid(ply) or not ply:Alive() or not ply:MBLSCSAccess() then return true end
	if not MBLSCS.IsInstalled() or not MBLSCS.IsNetworkReady(ply) then return false end
	if not ply.mb_lscsProgressLoaded or not ply.mb_lscsInventoryRestored then return false end
	if not isfunction(ply.lscsIsValid) or not isfunction(ply.lscsCraftSaber) then return false end

	local ok, valid = pcall(ply.lscsIsValid, ply)
	if not ok then return false end
	if not valid then
		-- An incomplete hilt/crystal build is a valid settled state; there is
		-- simply no saber to issue yet.
		ply:StripWeapon("weapon_lscs")
		return true
	end
	if ply:HasWeapon("weapon_lscs") and not forceRebuild then return true end

	local crafted = pcall(ply.lscsCraftSaber, ply, true)
	return crafted and ply:HasWeapon("weapon_lscs")
end

function MBLSCS.BootstrapPlayer(ply, refill)
	if not IsValid(ply) then return true end
	if not MBLSCS.IsInstalled() then return false end
	MBLSCS.IsNetworkReady(ply)

	if ply.mb_lscsProgressLoaded then MBLSCS.ApplySkills(ply, refill == true) end
	if not ply.mb_lscsProgressLoaded or not ply.mb_lscsInventoryLoaded
	or ply.mb_lscsPendingFactionAccess or not MBLSCS.IsNetworkReady(ply) then
		return false
	end

	if not ply:MBLSCSAccess() then return true end
	MBLSCS.TryRestoreInventory(ply)
	if not ply.mb_lscsInventoryRestored then return false end
	MBLSCS.ReconcileItems(ply, false)
	return MBLSCS.TryCraftSaber(ply)
end

local function bootstrapTimerName(ply)
	return "MilBase.LSCSBootstrap." .. tostring(ply:UserID())
end

function MBLSCS.ScheduleBootstrap(ply, refill)
	if not IsValid(ply) then return end
	local name = bootstrapTimerName(ply)
	local interval = math.max(0.1, tonumber(cfg.BootstrapInterval) or 0.5)
	local attempts = math.max(1, math.floor(tonumber(cfg.BootstrapAttempts) or 30))
	ply.mb_lscsBootstrapRefill = ply.mb_lscsBootstrapRefill == true or refill == true

	timer.Create(name, interval, attempts, function()
		if not IsValid(ply) then timer.Remove(name) return end
		local settled = MBLSCS.BootstrapPlayer(ply, ply.mb_lscsBootstrapRefill == true)
		-- Keep the requested refill until progress has loaded; after that first
		-- application, retries should repair inventory/saber state without
		-- repeatedly refilling Force.
		if ply.mb_lscsProgressLoaded then ply.mb_lscsBootstrapRefill = nil end
		if settled then
			ply.mb_lscsBootstrapRefill = nil
			timer.Remove(name)
		end
	end)
end

function MBLSCS.LoadInventory(ply)
	local key = ply:MBCharacterKey()
	local token = ply:MBCharacterLoadToken()
	if cfg.PersistInventory == false then
		ply.mb_lscsSavedInventory = {}
		ply.mb_lscsInventoryLoaded = true
		MBLSCS.TryRestoreInventory(ply)
		return
	end

	MilBase.DB.Query(string.format(
		"SELECT slot_id, item_class, equipped FROM frontier_lscs_inventory WHERE steamid = %s ORDER BY slot_id ASC",
		MilBase.SQLStr(key)), function(rows)
		if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
		ply.mb_lscsSavedInventory = {}
		for _, row in ipairs(rows) do
			ply.mb_lscsSavedInventory[#ply.mb_lscsSavedInventory + 1] = {
				index = math.Clamp(math.floor(tonumber(row.slot_id) or 1), 1, 127),
				class = tostring(row.item_class or ""),
				equipped = tonumber(row.equipped) or -1,
			}
		end
		ply.mb_lscsInventoryLoaded = true
		MBLSCS.TryRestoreInventory(ply)
	end)
end

hook.Add("PlayerInitialSpawn", "MilBase.LSCSLoad", function(ply)
	ply:SetNWBool("mb_lscs_loaded", false)
	MBLSCS.LoadProgress(ply)
	MBLSCS.LoadInventory(ply)
	MBLSCS.ScheduleBootstrap(ply, true)
end)

hook.Add("MilBase.PlayerLoaded", "MilBase.LSCSFactionDefault", function(ply)
	if not IsValid(ply) or not ply.mb_lscsPendingFactionAccess then return end
	ply.mb_lscsPendingFactionAccess = nil
	ply.mb_lscsAccess = factionDefaultAccess(ply)
	syncProgress(ply)
	MBLSCS.ApplySkills(ply, true)
	MBLSCS.TryRestoreInventory(ply)
	MBLSCS.ScheduleBootstrap(ply, true)
	MBLSCS.SaveProgress(ply)
end)

hook.Add("LSCS:OnPlayerFullySpawned", "MilBase.LSCSReady", function(ply)
	if not IsValid(ply) then return end
	ply.mb_lscsNetworkReady = true
	MBLSCS.TryRestoreInventory(ply)
	MBLSCS.ApplySkills(ply, true)
	MBLSCS.ScheduleBootstrap(ply, true)
end)

hook.Add("PlayerSpawn", "MilBase.LSCSApplyOnSpawn", function(ply)
	-- PlayerLoadout strips all weapons. Retry briefly rather than relying on a
	-- single 0.5-second race against DB loading and LSCS's own spawn hook.
	MBLSCS.ScheduleBootstrap(ply, true)
end)

hook.Add("OnReloaded", "MilBase.LSCSLateBootstrap", function()
	for _, ply in ipairs(player.GetAll()) do MBLSCS.ScheduleBootstrap(ply, true) end
end)

timer.Simple(0, function()
	for _, ply in ipairs(player.GetAll()) do MBLSCS.ScheduleBootstrap(ply, true) end
end)

hook.Add("PlayerCanPickupWeapon", "MilBase.LSCSAccessWeapons", function(ply, weapon)
	if IsValid(weapon) and weapon:GetClass() == "weapon_lscs" and not ply:MBLSCSAccess() then
		return false
	end
end)

hook.Add("PlayerGiveSWEP", "MilBase.LSCSAccessGive", function(ply, class)
	if class == "weapon_lscs" and not ply:MBLSCSAccess() then return false end
end)

-- Also catch direct Player:Give calls from third-party staff or loadout addons.
hook.Add("WeaponEquip", "MilBase.LSCSAccessEquip", function(weapon, ply)
	if not IsValid(weapon) or not IsValid(ply) or not ply:IsPlayer() then return end
	if weapon:GetClass() ~= "weapon_lscs" then return end
	if ply:MBLSCSAccess() then return end
	timer.Simple(0, function()
		if IsValid(ply) then ply:StripWeapon("weapon_lscs") end
	end)
end)

hook.Add("LSCS:PlayerInventory", "MilBase.LSCSAccessInventory", function(ply)
	if IsValid(ply) and not ply:MBLSCSAccess() and not ply.mb_lscsRestoring then return true end
end)

hook.Add("LSCS:OnPlayerForceUse", "MilBase.LSCSAccessForce", function(ply)
	if IsValid(ply) and not ply:MBLSCSAccess() then return false end
end)

hook.Add("LSCS:OnPlayerDroppedItem", "MilBase.LSCSProtectLearnedItems", function(ply, entity, _, class)
	if not IsValid(ply) or not ply:MBLSCSAccess() then return end
	if not MBLSCS.ManagedItems[class] or not managedItemShouldExist(ply, class) then return end
	if IsValid(entity) then entity:Remove() end
	timer.Simple(0, function()
		if IsValid(ply) then MBLSCS.ReconcileItems(ply, false, true) end
	end)
end)

for _, hookName in ipairs({
	"LSCS:PostPlayerInventory", "LSCS:OnPlayerEquippedItem",
	"LSCS:OnPlayerUnEquippedItem", "LSCS:OnPlayerDroppedItem",
}) do
	hook.Add(hookName, "MilBase.LSCSInventoryPersistence", function(ply)
		if IsValid(ply) then MBLSCS.QueueInventorySave(ply) end
	end)
end

hook.Add("EntityTakeDamage", "MilBase.LSCSSkillDamage", function(target, dmg)
	if not MBLSCS.IsSaberDamage(dmg) then return end

	local multiplier = 1
	local attacker = dmg:GetAttacker()
	if IsValid(attacker) and attacker:IsPlayer() and attacker:MBLSCSAccess() then
		multiplier = multiplier * attacker:GetNWFloat("mb_lscs_damage_mult", 1)
	end
	if IsValid(target) and target:IsPlayer() and target:MBLSCSAccess() then
		multiplier = multiplier * (1 - target:GetNWFloat("mb_lscs_defense", 0))
	end
	dmg:ScaleDamage(math.Clamp(multiplier, 0, 5))
end)

hook.Add("PlayerDisconnected", "MilBase.LSCSSave", function(ply)
	timer.Remove("MilBase.LSCSInventorySave." .. ply:MBCharacterKey())
	timer.Remove(bootstrapTimerName(ply))
	MBLSCS.SaveProgress(ply)
	MBLSCS.SaveInventory(ply)
end)

local function diagnosticLine(ply)
	local inventoryCount = 0
	if IsValid(ply) and isfunction(ply.lscsGetInventory) then
		inventoryCount = table.Count(ply:lscsGetInventory())
	end
	return string.format(
		"%s | installed=%s network=%s progress=%s inventoryDB=%s restored=%s access=%s items=%d saber=%s",
		IsValid(ply) and (ply:Nick() .. " [" .. ply:SteamID64() .. "]") or "invalid player",
		tostring(MBLSCS.IsInstalled()), tostring(MBLSCS.IsNetworkReady(ply)),
		tostring(ply.mb_lscsProgressLoaded == true), tostring(ply.mb_lscsInventoryLoaded == true),
		tostring(ply.mb_lscsInventoryRestored == true), tostring(ply:MBLSCSAccess()), inventoryCount,
		tostring(ply:HasWeapon("weapon_lscs")))
end

local function canRunDiagnostics(actor)
	if not IsValid(actor) or actor:IsListenServerHost() or actor:IsAdmin() then return true end
	return isfunction(actor.MBStaffLevel) and actor:MBStaffLevel() >= (cfg.AdminLevel or 3)
end

concommand.Add("mb_lscs_diag", function(actor, _, args)
	if not canRunDiagnostics(actor) then return end
	local query = string.lower(string.Trim(table.concat(args or {}, " ")))
	local found = false
	for _, target in ipairs(player.GetAll()) do
		if query == "" or string.find(string.lower(target:Nick()), query, 1, true)
		or target:SteamID64() == query then
			found = true
			local line = "[MilBase LSCS] " .. diagnosticLine(target)
			if IsValid(actor) then actor:PrintMessage(HUD_PRINTCONSOLE, line) else print(line) end
		end
	end
	if IsValid(actor) then
		actor:PrintMessage(HUD_PRINTCONSOLE, "[MilBase LSCS] ClassToItem=" .. tostring(MBLSCS.IsInstalled())
			.. " | use mb_lscs_retry [name/SteamID64] to rerun integration bootstrap.")
	elseif not found then
		print("[MilBase LSCS] No connected players.")
	end
end)

concommand.Add("mb_lscs_retry", function(actor, _, args)
	if not canRunDiagnostics(actor) then return end
	local query = string.lower(string.Trim(table.concat(args or {}, " ")))
	for _, target in ipairs(player.GetAll()) do
		if query == "" or string.find(string.lower(target:Nick()), query, 1, true)
		or target:SteamID64() == query then
			MBLSCS.ScheduleBootstrap(target, true)
		end
	end
end)

hook.Add("ShutDown", "MilBase.LSCSSaveAll", function()
	for _, ply in ipairs(player.GetAll()) do
		MBLSCS.SaveProgress(ply)
		MBLSCS.SaveInventory(ply)
	end
end)

timer.Create("MilBase.LSCSXPMilestones", 2, 0, function()
	local step = math.max(1, math.floor(tonumber(cfg.XPPerPoint) or 500))
	for _, ply in ipairs(player.GetAll()) do
		if ply.mb_lscsProgressLoaded and ply:MBIsJedi() then
			local earned = math.floor(math.max(0, ply:GetNWInt("mb_xp", 0)) / step)
			local claimed = math.max(0, ply.mb_lscsMilestones or 0)
			if earned > claimed then
				local gained = earned - claimed
				ply.mb_lscsMilestones = earned
				ply.mb_lscsPoints = clampPoints((ply.mb_lscsPoints or 0) + gained)
				syncProgress(ply)
				MBLSCS.SaveProgress(ply)
				MilBase.Notify(ply, gained .. " LSCS training point" .. (gained == 1 and "" or "s")
					.. " earned! You now have " .. ply.mb_lscsPoints .. ".")
			end
		end
	end
end)

net.Receive("MilBase_LSCSPurchase", function(_, ply)
	if (ply.mb_lscsNextPurchase or 0) > CurTime() then return end
	ply.mb_lscsNextPurchase = CurTime() + 0.2
	local id = string.sub(net.ReadString() or "", 1, 64)
	local node = MBLSCS.Nodes[id]

	if not ply.mb_lscsProgressLoaded then MilBase.Notify(ply, "Your LSCS training data is still loading.") return end
	if not ply:MBIsJedi() then MilBase.Notify(ply, "Only Jedi factions can train LSCS skills.") return end
	if not ply:MBLSCSAccess() then MilBase.Notify(ply, "Your LSCS access is disabled.") return end
	if not MBLSCS.IsInstalled() then MilBase.Notify(ply, "LSCS is not installed on this server.") return end
	if not node then return end
	if ply.mb_lscsUnlocked[id] then MilBase.Notify(ply, "You already know that skill.") return end

	local requirementsMet, missing = MBLSCS.MeetsRequirements(ply.mb_lscsUnlocked, node)
	if not requirementsMet then
		local required = MBLSCS.Nodes[missing]
		MilBase.Notify(ply, "Requires " .. (required and required.name or missing) .. ".")
		return
	end
	if MBLSCS.CanLearnAdvanced then
		local advancedOK, advancedReason = MBLSCS.CanLearnAdvanced(ply, node)
		if not advancedOK then MilBase.Notify(ply, advancedReason or "Advanced Jedi requirement not met.") return end
	end
	if (ply.mb_lscsPoints or 0) < node.cost then
		MilBase.Notify(ply, "You need " .. node.cost .. " training point(s).")
		return
	end
	if node.item and not MBLSCS.ClassToItem(node.item) then
		MilBase.Notify(ply, "That LSCS item is unavailable: " .. node.item)
		return
	end

	local auditBefore = MBLSCS.CaptureSnapshot and MBLSCS.CaptureSnapshot(ply) or nil
	ply.mb_lscsPoints = clampPoints(ply.mb_lscsPoints - node.cost)
	ply.mb_lscsUnlocked[id] = true
	if MBLSCS.AutoEquipNode then MBLSCS.AutoEquipNode(ply, id) end
	syncProgress(ply)
	MBLSCS.ApplySkills(ply, false)
	MBLSCS.ReconcileItems(ply, false, true)
	MBLSCS.ScheduleBootstrap(ply, false)
	MBLSCS.SaveProgress(ply)
	if MBLSCS.RecordAudit then MBLSCS.RecordAudit(ply, ply, "learned " .. node.name, auditBefore) end
	MilBase.Notify(ply, "Learned " .. node.name .. ".")
	if MilBase.Log then MilBase.Log("progression", MilBase.LogTag(ply) .. " learned LSCS skill " .. node.name, ply) end
end)

local function canAdmin(actor)
	return IsValid(actor) and (actor:IsListenServerHost()
		or actor:MBStaffLevel() >= (cfg.AdminLevel or 3))
end

local function canAdminTarget(actor, target)
	if actor:IsListenServerHost() or actor == target then return true end
	return target:MBStaffLevel() < actor:MBStaffLevel()
end

local function adminInventory(ply)
	local result = {}
	if not ply.lscsGetInventory or not ply.lscsGetEquipped then return result end
	local eq = ply:lscsGetEquipped()
	for index, class in pairs(ply:lscsGetInventory()) do
		local state = "UNEQUIPPED"
		local item = MBLSCS.ClassToItem(class)
		local handed = item and (item.type == "hilt" or item.type == "crystal")
		if eq[index] == true then
			state = handed and "RIGHT HAND" or "ACTIVE"
		elseif eq[index] == false then
			state = handed and "LEFT HAND" or "ACTIVE"
		end
		result[#result + 1] = { index = index, class = class, state = state }
	end
	table.sort(result, function(a, b) return a.index < b.index end)
	return result
end

local function sendAdminState(actor, target)
	if not canAdmin(actor) or not IsValid(target) then return end
	net.Start("MilBase_LSCSAdminState")
		net.WriteEntity(target)
		net.WriteInt(clampPoints(target.mb_lscsPoints), 32)
		net.WriteUInt(math.max(0, target.mb_lscsMilestones or 0), 32)
		net.WriteBool(target:MBLSCSAccess())
		net.WriteBool(target:MBIsJedi())
		net.WriteBool(target.mb_lscsProgressLoaded == true)
		net.WriteTable(target.mb_lscsUnlocked or {})
		net.WriteTable(adminInventory(target))
	net.Send(actor)
end

local function unlockWithRequirements(target, id, seen)
	seen = seen or {}
	if seen[id] then return end
	seen[id] = true
	local node = MBLSCS.Nodes[id]
	if not node then return end
	for _, required in ipairs(node.requires or {}) do unlockWithRequirements(target, required, seen) end
	target.mb_lscsUnlocked[id] = true
end

local function refundNodeAndDependents(target, id)
	local remove = { [id] = true }
	local changed = true
	while changed do
		changed = false
		for nodeID in pairs(target.mb_lscsUnlocked or {}) do
			if not remove[nodeID] then
				local node = MBLSCS.Nodes[nodeID]
				for _, required in ipairs((node and node.requires) or {}) do
					if remove[required] then
						remove[nodeID] = true
						changed = true
						break
					end
				end
			end
		end
	end

	local refund = 0
	for nodeID in pairs(remove) do
		if target.mb_lscsUnlocked[nodeID] then
			local node = MBLSCS.Nodes[nodeID]
			refund = refund + (node and node.cost or 0)
			target.mb_lscsUnlocked[nodeID] = nil
		end
	end
	target.mb_lscsPoints = clampPoints((target.mb_lscsPoints or 0) + refund)
	return refund
end

local function finishAdminMutation(actor, target, description, prune, auditBefore)
	syncProgress(target)
	if MBLSCS.EnsureActiveLoadout then MBLSCS.EnsureActiveLoadout(target) end
	MBLSCS.ApplySkills(target, false)
	MBLSCS.ReconcileItems(target, prune == true)
	MBLSCS.ScheduleBootstrap(target, false)
	MBLSCS.SaveProgress(target)
	MBLSCS.QueueInventorySave(target)
	MilBase.Notify(actor, description)
	if actor ~= target then MilBase.Notify(target, "LSCS profile updated by staff.") end
	if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " " .. description .. " for " .. MilBase.LogTag(target), actor, target) end
	if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, description, auditBefore) end
	sendAdminState(actor, target)
end

net.Receive("MilBase_LSCSAdmin", function(_, actor)
	if not canAdmin(actor) then return end
	if (actor.mb_lscsNextAdmin or 0) > CurTime() then return end
	actor.mb_lscsNextAdmin = CurTime() + 0.15

	local action = string.sub(net.ReadString() or "", 1, 32)
	local target = net.ReadEntity()
	local arg = string.sub(net.ReadString() or "", 1, 128)
	if not IsValid(target) or not target:IsPlayer() then return end
	if action == "request" then sendAdminState(actor, target) return end
	if not target.mb_lscsProgressLoaded then MilBase.Notify(actor, "That LSCS profile is still loading.") return end
	if not canAdminTarget(actor, target) then MilBase.Notify(actor, "You cannot edit equal or higher staff.") return end
	local auditBefore = MBLSCS.CaptureSnapshot and MBLSCS.CaptureSnapshot(target) or nil

	if action == "addpoints" then
		local amount = math.Clamp(math.floor(tonumber(arg) or 0), -9999, 9999)
		target.mb_lscsPoints = clampPoints((target.mb_lscsPoints or 0) + amount)
		finishAdminMutation(actor, target, "adjusted LSCS points by " .. amount, false, auditBefore)
	elseif action == "setpoints" then
		target.mb_lscsPoints = clampPoints(arg)
		finishAdminMutation(actor, target, "set LSCS points to " .. target.mb_lscsPoints, false, auditBefore)
	elseif action == "setaccess" then
		local enable = arg == "1" or string.lower(arg) == "true" or string.lower(arg) == "on"
		if enable and not target:MBIsJedi() then
			MilBase.Notify(actor, "That player's faction is not marked as Jedi in sh_factions.lua.")
			return
		end
		setAccess(target, enable)
		MilBase.Notify(actor, "LSCS access " .. (target:MBLSCSAccess() and "enabled." or "disabled."))
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " changed LSCS access for " .. MilBase.LogTag(target), actor, target) end
		if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, "changed LSCS access", auditBefore) end
		sendAdminState(actor, target)
	elseif action == "unlock" then
		if not MBLSCS.Nodes[arg] then return end
		unlockWithRequirements(target, arg)
		finishAdminMutation(actor, target, "unlocked " .. MBLSCS.Nodes[arg].name .. " (with prerequisites)", false, auditBefore)
	elseif action == "refund" then
		if not MBLSCS.Nodes[arg] then return end
		local refunded = refundNodeAndDependents(target, arg)
		finishAdminMutation(actor, target, "refunded " .. refunded .. " LSCS point(s)", true, auditBefore)
	elseif action == "reset" then
		local refund = 0
		for id in pairs(target.mb_lscsUnlocked or {}) do
			refund = refund + (MBLSCS.Nodes[id] and MBLSCS.Nodes[id].cost or 0)
		end
		target.mb_lscsUnlocked = {}
		target.mb_lscsPoints = clampPoints((target.mb_lscsPoints or 0) + refund)
		finishAdminMutation(actor, target, "reset the LSCS tree and refunded " .. refund .. " point(s)", true, auditBefore)
	elseif action == "grantall" then
		for id in pairs(MBLSCS.Nodes) do target.mb_lscsUnlocked[id] = true end
		finishAdminMutation(actor, target, "granted every LSCS skill", false, auditBefore)
	elseif action == "giveitem" then
		if not MBLSCS.IsInstalled() or not MBLSCS.ClassToItem(arg) or not target.lscsAddInventory then
			MilBase.Notify(actor, "Unknown or unavailable LSCS item class.") return
		end
		if not target:MBLSCSAccess() then MilBase.Notify(actor, "The target must be an enabled Jedi.") return end
		target:lscsAddInventory(arg, true)
		MBLSCS.QueueInventorySave(target)
		MilBase.Notify(actor, "Gave " .. arg .. ".")
		if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, "gave LSCS item " .. arg, auditBefore) end
		sendAdminState(actor, target)
	elseif action == "removeitem" then
		if not target.lscsGetInventory or not target.lscsRemoveItem then return end
		local remove = {}
		for index, class in pairs(target:lscsGetInventory()) do
			if class == arg then remove[#remove + 1] = index end
		end
		for _, index in ipairs(remove) do
			if isbool(target:lscsGetEquipped()[index]) and target.lscsEquipItem then target:lscsEquipItem(index, nil) end
			target:lscsRemoveItem(index)
		end
		if target.lscsBuildPlayerInfo then target:lscsBuildPlayerInfo() end
		MBLSCS.ReconcileItems(target, false)
		MBLSCS.QueueInventorySave(target)
		MilBase.Notify(actor, "Removed " .. #remove .. " matching LSCS item(s). Skill entitlements were restored.")
		if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, "removed LSCS item " .. arg, auditBefore) end
		sendAdminState(actor, target)
	elseif action == "wipeinventory" then
		if target.lscsWipeInventory then target:lscsWipeInventory() end
		MBLSCS.ReconcileItems(target, false)
		MBLSCS.QueueInventorySave(target)
		MilBase.Notify(actor, "Wiped LSCS inventory; learned skill items were restored.")
		if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, "wiped LSCS inventory", auditBefore) end
		sendAdminState(actor, target)
	elseif action == "craft" then
		if not target:MBLSCSAccess() then
			MilBase.Notify(actor, "The target must be an enabled Jedi.")
		elseif MBLSCS.TryCraftSaber(target, true) and target:HasWeapon("weapon_lscs") then
			MilBase.Notify(actor, "Crafted and issued the selected LSCS saber.")
			if MBLSCS.RecordAudit then MBLSCS.RecordAudit(actor, target, "crafted LSCS saber", auditBefore) end
		else
			MilBase.Notify(actor, "That player needs an equipped hilt and crystal first.")
		end
		sendAdminState(actor, target)
	end
end)
