-- Blocks the console kill/suicide command when enabled in config.
-- Garry's Mod routes the engine kill command through CanPlayerSuicide.

local function killCommandDisabled()
	local cfg = MilBase and MilBase.Config or {}
	return cfg.DisableKillCommand ~= false
end

local function notifyBlocked(ply)
	if not IsValid(ply) then return end
	if (ply.mb_nextKillCommandNotice or 0) > CurTime() then return end
	ply.mb_nextKillCommandNotice = CurTime() + 2
	if MilBase and MilBase.Notify then
		MilBase.Notify(ply, "The kill command is disabled on this server.", "warn")
	else
		ply:ChatPrint("The kill command is disabled on this server.")
	end
end

hook.Add("CanPlayerSuicide", "MilBase.DisableKillCommand", function(ply)
	if not killCommandDisabled() then return end
	notifyBlocked(ply)
	return false
end)

hook.Add("PlayerSay", "MilBase.DisableKillChatCommands", function(ply, text)
	if not killCommandDisabled() then return end
	local msg = string.lower(string.Trim(tostring(text or "")))
	if msg == "/kill" or msg == "!kill" or msg == "/suicide" or msg == "!suicide" then
		notifyBlocked(ply)
		return ""
	end
end)
