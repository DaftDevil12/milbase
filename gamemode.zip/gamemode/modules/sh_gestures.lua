--[[
	Gestures module: military hand signals and courtesies as chat commands.
	/salute, /halt, /forward, /group, /wave, /agree, /disagree, /bow
]]

local gestures = {
	salute   = ACT_GMOD_TAUNT_SALUTE,
	wave     = ACT_GMOD_GESTURE_WAVE,
	halt     = ACT_GMOD_GESTURE_SIGNAL_HALT,
	forward  = ACT_GMOD_GESTURE_SIGNAL_FORWARD,
	group    = ACT_GMOD_GESTURE_SIGNAL_GROUP,
	agree    = ACT_GMOD_GESTURE_AGREE,
	disagree = ACT_GMOD_GESTURE_DISAGREE,
	bow      = ACT_GMOD_GESTURE_BOW,
}

if SERVER then
	util.AddNetworkString("MilBase_Gesture")

	for name, act in pairs(gestures) do
		MilBase.RegisterChatCommand(name, {
			help = "Perform the " .. name .. " gesture.",
			func = function(ply)
				if not ply:Alive() or ply:GetNWBool("mb_wounded", false) then return end

				ply:AnimRestartGesture(GESTURE_SLOT_CUSTOM, act, true)

				net.Start("MilBase_Gesture")
					net.WriteEntity(ply)
					net.WriteString(name)
				net.Broadcast()
			end,
		})
	end
else
	net.Receive("MilBase_Gesture", function()
		local ply = net.ReadEntity()
		local act = gestures[net.ReadString()]

		if IsValid(ply) and ply:IsPlayer() and act then
			ply:AnimRestartGesture(GESTURE_SLOT_CUSTOM, act, true)
		end
	end)
end
