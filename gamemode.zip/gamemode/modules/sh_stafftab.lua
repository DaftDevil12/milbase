--[[
	STAFF F4 tab (staff only): online staff overview, one-click moderation
	(staff mode, sits, goto/bring/freeze/kick on a selected player), map
	change (level 4+), and a reference of every chat command.

	Tab buttons use a dedicated net (MilBase_StaffTab) so they work even if
	chat command dispatch is unavailable. All actions re-validated server-side.
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Server: the action net
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_StaffTab")

	local function level(ply) return ply:MBStaffLevel() end
	local function canGiveItems(ply)
		return ply:IsAdmin() or level(ply) >= (cfg.StaffGiveItemLevel or 3)
	end

	net.Receive("MilBase_StaffTab", function(_, ply)
		if level(ply) < (cfg.StaffModeLevel or 1) then return end
		if (ply.mb_nextStaffTab or 0) > CurTime() then return end
		ply.mb_nextStaffTab = CurTime() + 0.3

		local action = net.ReadString()
		local target = net.ReadEntity()
		local arg = net.ReadString()

		if action == "staffmode" then
			if MilBase.ToggleStaffMode then MilBase.ToggleStaffMode(ply) end

		elseif action == "sit" then
			if MilBase.SitCmd then
				MilBase.SitCmd(ply, IsValid(target) and target or nil)
			end

		elseif action == "endsit" then
			if MilBase.EndSit and not MilBase.EndSit(ply) then
				MilBase.Notify(ply, "You have no sit running.")
			end

		elseif action == "goto" then
			if not (IsValid(target) and target:IsPlayer()) then return end
			ply:SetPos(target:GetPos() + target:GetForward() * 48 + Vector(0, 0, 4))
			MilBase.Notify(ply, "Teleported to " .. target:MBName() .. ".")
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " went to " .. MilBase.LogTag(target), ply, target) end

		elseif action == "bring" then
			if not (IsValid(target) and target:IsPlayer()) then return end
			target:SetPos(ply:GetPos() + ply:GetForward() * 64 + Vector(0, 0, 4))
			MilBase.Notify(ply, "Brought " .. target:MBName() .. ".")
			MilBase.Notify(target, "You were teleported by " .. ply:MBName() .. ".")
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " brought " .. MilBase.LogTag(target), ply, target) end

		elseif action == "freeze" then
			if not (IsValid(target) and target:IsPlayer()) then return end
			local freeze = not target:IsFlagSet(FL_FROZEN)
			target:Freeze(freeze)
			MilBase.Notify(ply, (freeze and "Froze " or "Unfroze ") .. target:MBName() .. ".")
			MilBase.Notify(target, freeze and "You've been frozen by staff." or "You've been unfrozen.")
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(ply) .. (freeze and " froze " or " unfroze ")
					.. MilBase.LogTag(target), ply, target)
			end

		elseif action == "kick" then
			if level(ply) < 2 then MilBase.Notify(ply, "Kick requires staff level 2+.") return end
			if not (IsValid(target) and target:IsPlayer()) then return end
			if target:MBStaffLevel() >= level(ply) then
				MilBase.Notify(ply, "You can't kick equal or higher staff.")
				return
			end
			local reason = arg ~= "" and arg or "Kicked by staff"
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(ply) .. " kicked " .. MilBase.LogTag(target)
					.. " (" .. reason .. ")", ply, target)
			end
			target:Kick(reason)

		elseif action == "giveitem" then
			if not canGiveItems(ply) then
				MilBase.Notify(ply, "Give Items requires staff level 3+.")
				return
			end

			if not (IsValid(target) and target:IsPlayer()) then
				MilBase.Notify(ply, "Select a player first.")
				return
			end

			local data = util.JSONToTable(arg or "") or {}
			local itemName = string.Trim(tostring(data.name or ""))
			local amount = math.Clamp(math.floor(tonumber(data.amount) or 1), 1, 1000)
			local id, def, err, matches = MilBase.FindItemByName(itemName)

			if not id then
				if err == "ambiguous" and matches then
					local names = {}
					for i, match in ipairs(matches) do
						if i > 6 then break end
						names[#names + 1] = match.def.name or match.id
					end
					MilBase.Notify(ply, "Multiple items match that name: " .. table.concat(names, ", "))
				else
					MilBase.Notify(ply, "Unknown item name: " .. itemName)
				end
				return
			end

			local given = MilBase.GiveItem(target, id, amount)
			MilBase.Notify(ply, "Gave " .. given .. "x " .. def.name
				.. " to " .. target:MBName() .. (given < amount and " (inventory full)" or ""))
			if given > 0 and MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(ply) .. " gave " .. given .. "x "
					.. def.name .. " to " .. MilBase.LogTag(target), ply, target)
			end

		elseif action == "mapchange" then
			if level(ply) < 4 then MilBase.Notify(ply, "Map change requires staff level 4+.") return end
			local map = string.lower(string.Trim(arg))
			if map == "" or not file.Exists("maps/" .. map .. ".bsp", "GAME") then
				MilBase.Notify(ply, "Map not found: " .. map)
				return
			end
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(ply) .. " changed map to " .. map, ply) end
			MilBase.ChatMsg(nil, Color(220, 90, 80), "[SERVER] ", color_white,
				"Map changing to " .. map .. " in 5 seconds — " .. ply:MBName() .. ".")
			timer.Simple(5, function() RunConsoleCommand("changelevel", map) end)
		end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: the STAFF tab
--------------------------------------------------------------------------

local function send(action, target, arg)
	net.Start("MilBase_StaffTab")
		net.WriteString(action)
		net.WriteEntity(IsValid(target) and target or game.GetWorld())
		net.WriteString(arg or "")
	net.SendToServer()
end

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["GIVE ITEMS"] = true

local function actionBtn(parent, label, accent, onClick)
	local ui = MilBase.UI
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(s, w, h)
		local col = accent or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = s:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised,
			accent = col })
		if s:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

MilBase.AddMenuTab("STAFF", 91, function(content)
	local ui = MilBase.UI
	local lp = LocalPlayer()
	local myLevel = lp:MBStaffLevel()
	local selected -- selected player entity

	----------------------------------------------------------------
	-- LEFT: online staff
	----------------------------------------------------------------

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(280)
	left:DockMargin(0, 0, 14, 0)
	left.Paint = function(s, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("ONLINE STAFF", "MB.Tab", 14, 8, ui.text)
	end

	local staffScroll = vgui.Create("DScrollPanel", left)
	staffScroll:Dock(FILL)
	staffScroll:DockMargin(10, 44, 10, 10)

	for _, p in ipairs(player.GetAll()) do
		if p:MBStaffLevel() < 1 then continue end
		local row = vgui.Create("DPanel", staffScroll)
		row:Dock(TOP)
		row:SetTall(42)
		row:DockMargin(0, 0, 0, 4)
		row.Paint = function(s, w, h)
			if not IsValid(p) then return end
			local rank = p:MBStaffRank()
			local col = rank and rank.color or ui.dim
			surface.SetDrawColor(255, 255, 255, 5)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(col.r, col.g, col.b, 220)
			surface.DrawRect(0, 3, 3, h - 6)
			draw.SimpleText(p:MBName(), "MB.Small", 12, 6, ui.text)
			local status = rank and rank.name or "Staff"
			if p:GetNWBool("mb_staffmode", false) then status = status .. "  •  STAFF MODE" end
			if p:GetNWBool("mb_insit", false) then status = status .. "  •  IN SIT" end
			draw.SimpleText(status, "MB.Tiny", 12, 24, col)
		end
	end

	----------------------------------------------------------------
	-- RIGHT: actions + players + command reference
	----------------------------------------------------------------

	local right = vgui.Create("DScrollPanel", content)
	right:Dock(FILL)

	local function section(text)
		local pnl = vgui.Create("DPanel", right)
		pnl:Dock(TOP); pnl:SetTall(24); pnl:DockMargin(0, 10, 8, 6)
		pnl.Paint = function(s, w, h)
			draw.SimpleText(text, "MB.Small", 2, h / 2, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetFont("MB.Small")
			local tw = surface.GetTextSize(text)
			surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 45)
			surface.DrawRect(tw + 12, h / 2, math.max(0, w - tw - 14), 1)
		end
	end

	-- QUICK ACTIONS ------------------------------------------------
	section("QUICK ACTIONS")

	local quick = vgui.Create("DPanel", right)
	quick:Dock(TOP); quick:SetTall(38); quick:DockMargin(0, 0, 8, 4); quick.Paint = nil

	local sm = actionBtn(quick, "STAFF MODE", ui.accent, function() send("staffmode") end)
	sm:Dock(LEFT); sm:SetWide(130); sm:DockMargin(0, 0, 8, 0)

	local es = actionBtn(quick, "END SIT", ui.warn, function() send("endsit") end)
	es:Dock(LEFT); es:SetWide(110); es:DockMargin(0, 0, 8, 0)

	-- Map change (level 4+) ---------------------------------------
	if myLevel >= 4 then
		section("MAP CHANGE  (staff 4+)")

		local entry -- forward-declared so the picker can fill it

		-- Installed-map picker (dropdown). Populated from maps/*.bsp.
		local maps = {}
		for _, f in ipairs(file.Find("maps/*.bsp", "GAME") or {}) do
			local name = string.StripExtension(f)
			if string.sub(name, 1, 10) ~= "background" then maps[#maps + 1] = name end
		end
		table.sort(maps)

		local chosen
		local combo = vgui.Create("DComboBox", right)
		combo:Dock(TOP); combo:SetTall(30); combo:DockMargin(0, 0, 8, 4)
		combo:SetSortItems(false)
		combo.Paint = function(self, w, h)
			surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(self:IsHovered() and ui.accent or ui.outline)
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(chosen or ("Select an installed map…  (" .. #maps .. ")"),
				"MB.Small", 8, h / 2, chosen and ui.text or ui.dim,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("▾", "MB.Small", w - 14, h / 2, ui.dim,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		for _, m in ipairs(maps) do combo:AddChoice(m) end
		combo.OnSelect = function(_, _, value)
			chosen = value
			if IsValid(entry) then entry:SetText(value) end
		end

		local mapRow = vgui.Create("DPanel", right)
		mapRow:Dock(TOP); mapRow:SetTall(34); mapRow:DockMargin(0, 0, 8, 4); mapRow.Paint = nil

		entry = vgui.Create("DTextEntry", mapRow)
		entry:Dock(FILL); entry:DockMargin(0, 2, 8, 2)
		entry:SetFont("MB.Small"); entry:SetPaintBackground(false)
		entry:SetPlaceholderText("…or type a map name, e.g. rp_venator")
		entry.Paint = function(self, w, h)
			surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
			surface.DrawOutlinedRect(0, 0, w, h)
			self:DrawTextEntryText(ui.text, ui.accent, ui.text)
		end

		local go = actionBtn(mapRow, "CHANGE MAP", ui.danger, function()
			local map = string.Trim(entry:GetValue())
			if map ~= "" then send("mapchange", nil, map) end
		end)
		go:Dock(RIGHT); go:SetWide(130)
	end

	-- Global ArcCW tuning is deliberately management-only. The editor itself
	-- repeats this check server-side before it will reveal or change any data.
	local weaponEditorLevel = tonumber(MilBase.Config.ArcCWWeaponEditorStaffLevel) or 6
	if myLevel >= weaponEditorLevel and MilBase.OpenArcCWWeaponEditor then
		section("ARCCW WEAPON TUNING  (management+)")

		local weaponEditor = vgui.Create("DPanel", right)
		weaponEditor:Dock(TOP)
		weaponEditor:SetTall(48)
		weaponEditor:DockMargin(0, 0, 8, 4)
		weaponEditor.Paint = function(_, w, h)
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = Color(255, 255, 255, 4), accent = ui.warn })
			draw.SimpleText("Persistent global damage, RPM, range, recoil and magazine overrides.",
				"MB.Tiny", 14, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		local openWeaponEditor = actionBtn(weaponEditor, "OPEN WEAPON EDITOR", ui.warn,
			function() MilBase.OpenArcCWWeaponEditor() end)
		openWeaponEditor:Dock(RIGHT)
		openWeaponEditor:SetWide(192)
		openWeaponEditor:DockMargin(0, 6, 8, 6)
	end

	-- PLAYERS ------------------------------------------------------
	section("PLAYERS — select, then act")

	local plyList = vgui.Create("DPanel", right)
	plyList:Dock(TOP); plyList:DockMargin(0, 0, 8, 4); plyList.Paint = nil

	local rows = {}
	local all = player.GetAll()
	plyList:SetTall(#all * 28 + 4)

	for _, p in ipairs(all) do
		local row = vgui.Create("DButton", plyList)
		row:Dock(TOP); row:SetTall(24); row:DockMargin(0, 0, 0, 4); row:SetText("")
		row.Paint = function(s, w, h)
			if not IsValid(p) then return end
			local on = selected == p
			local faction = p:MBFaction()
			local fcol = faction and faction.color or ui.dim
			MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
				color = on and Color(ui.accent.r, ui.accent.g, ui.accent.b, 35)
					or (s:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
				accent = on and ui.accent or nil })
			draw.SimpleText(p:MBName(), "MB.Small", 10, h / 2, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText((faction and faction.name or "") ..
				(p:MBStaffLevel() >= 1 and "  •  STAFF" or ""), "MB.Tiny",
				w - 10, h / 2, fcol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			selected = p
			MilBase.PlayUISound("select")
		end
		rows[#rows + 1] = row
	end

	local acts = vgui.Create("DPanel", right)
	acts:Dock(TOP); acts:SetTall(34); acts:DockMargin(0, 0, 8, 4); acts.Paint = nil

	local function targetAct(label, accent, action, needArg)
		local b = actionBtn(acts, label, accent, function()
			if not IsValid(selected) then
				MilBase.Notify(LocalPlayer(), "Select a player first.")
				return
			end
			send(action, selected, needArg and needArg() or "")
		end)
		b:Dock(LEFT); b:SetWide(92); b:DockMargin(0, 0, 6, 0)
		return b
	end

	local reason = vgui.Create("DTextEntry", right)

	targetAct("GOTO", ui.ok, "goto")
	targetAct("BRING", ui.ok, "bring")
	targetAct("FREEZE", ui.warn, "freeze")
	targetAct("SIT WITH", ui.warn, "sit")
	if myLevel >= 2 then
		targetAct("KICK", ui.danger, "kick", function() return reason:GetValue() end)
	end

	reason:Dock(TOP); reason:SetTall(28); reason:DockMargin(0, 0, 8, 4)
	reason:SetFont("MB.Small"); reason:SetPaintBackground(false)
	reason:SetPlaceholderText("kick reason (optional)")
	reason.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end

	-- COMMAND REFERENCE --------------------------------------------
	section("ALL COMMANDS")

	for name, cmd in SortedPairs(MilBase.Commands) do
		if MilBase.HiddenCommands and MilBase.HiddenCommands[name] then continue end
		local row = vgui.Create("DPanel", right)
		row:Dock(TOP); row:SetTall(24); row:DockMargin(0, 0, 8, 2)
		row.Paint = function(s, w, h)
			surface.SetDrawColor(255, 255, 255, 4)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText("/" .. name, "MB.Small", 10, h / 2,
				cmd.adminOnly and ui.danger or ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(cmd.help or "", "MB.Tiny", 130, h / 2, ui.dim,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end
end, function(lp) return lp:MBStaffLevel() >= (MilBase.Config.StaffModeLevel or 1) end)


MilBase.AddMenuTab("GIVE ITEMS", 93, function(content)
	local ui = MilBase.UI
	local selectedPlayer
	local selectedItem

	local function paintEntry(self, w, h)
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(ui.text, ui.accent, ui.text)
	end

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(300)
	left:DockMargin(0, 0, 14, 0)
	left.Paint = function(s, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("TARGET PLAYER", "MB.Tab", 14, 8, ui.text)
	end

	local playerScroll = vgui.Create("DScrollPanel", left)
	playerScroll:Dock(FILL)
	playerScroll:DockMargin(10, 44, 10, 10)

	for _, p in ipairs(player.GetAll()) do
		local row = vgui.Create("DButton", playerScroll)
		row:Dock(TOP)
		row:SetTall(36)
		row:DockMargin(0, 0, 0, 4)
		row:SetText("")
		row.Paint = function(s, w, h)
			if not IsValid(p) then return end
			local on = selectedPlayer == p
			local faction = p:MBFaction()
			local fcol = faction and faction.color or ui.dim
			MilBase.DrawPanelBF2(0, 0, w, h, {
				cut = 5,
				color = on and Color(ui.accent.r, ui.accent.g, ui.accent.b, 35)
					or (s:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
				accent = on and ui.accent or nil,
			})
			draw.SimpleText(p:MBName(), "MB.Small", 10, 8, ui.text)
			draw.SimpleText(faction and faction.name or "No faction", "MB.Tiny", 10, 24, fcol)
		end
		row.DoClick = function()
			selectedPlayer = p
			MilBase.PlayUISound("select")
		end
	end

	local right = vgui.Create("DPanel", content)
	right:Dock(FILL)
	right.Paint = function(s, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("GIVE INVENTORY ITEM", "MB.Tab", 14, 8, ui.text)
		draw.SimpleText("Search uses the item Name shown in inventory, not the internal ID.",
			"MB.Tiny", 14, 30, ui.dim)
	end

	local top = vgui.Create("DPanel", right)
	top:Dock(TOP)
	top:SetTall(112)
	top:DockMargin(10, 54, 10, 8)
	top.Paint = nil

	local search = vgui.Create("DTextEntry", top)
	search:Dock(TOP)
	search:SetTall(32)
	search:DockMargin(0, 0, 0, 8)
	search:SetFont("MB.Small")
	search:SetPaintBackground(false)
	search:SetPlaceholderText("Search by item name, e.g. Field Medkit")
	search:SetUpdateOnType(true)
	search.Paint = paintEntry

	local giveRow = vgui.Create("DPanel", top)
	giveRow:Dock(TOP)
	giveRow:SetTall(34)
	giveRow.Paint = nil

	local amount = vgui.Create("DTextEntry", giveRow)
	amount:Dock(LEFT)
	amount:SetWide(84)
	amount:DockMargin(0, 2, 8, 2)
	amount:SetFont("MB.Small")
	amount:SetPaintBackground(false)
	amount:SetNumeric(true)
	amount:SetText("1")
	amount.Paint = paintEntry

	local selectedLabel = vgui.Create("DLabel", giveRow)
	selectedLabel:Dock(FILL)
	selectedLabel:SetFont("MB.Small")
	selectedLabel:SetTextColor(ui.dim)
	selectedLabel:SetText("Select an item by name below.")

	local give = actionBtn(giveRow, "GIVE", ui.ok, function()
		if not IsValid(selectedPlayer) then
			MilBase.Notify(LocalPlayer(), "Select a player first.")
			return
		end
		if not selectedItem then
			MilBase.Notify(LocalPlayer(), "Select an item first.")
			return
		end

		local giveAmount = math.Clamp(math.floor(tonumber(amount:GetValue()) or 1), 1, 1000)
		send("giveitem", selectedPlayer, util.TableToJSON({
			name = selectedItem.name,
			amount = giveAmount,
		}))
	end)
	give:Dock(RIGHT)
	give:SetWide(104)

	local hint = vgui.Create("DLabel", top)
	hint:Dock(TOP)
	hint:SetTall(26)
	hint:SetFont("MB.Tiny")
	hint:SetTextColor(ui.faint)
	hint:SetText("Tip: click a result, set amount, then press GIVE. Partial name matches are allowed.")

	local itemScroll = vgui.Create("DScrollPanel", right)
	itemScroll:Dock(FILL)
	itemScroll:DockMargin(10, 0, 10, 10)

	local function refreshItems()
		itemScroll:Clear()

		local q = string.lower(string.Trim(search:GetValue() or ""))
		local shown = 0

		for _, entry in ipairs(MilBase.SortedItemsByName()) do
			local id, def, name = entry.id, entry.def, entry.name
			if q ~= "" and not string.find(string.lower(name), q, 1, true) then continue end

			shown = shown + 1
			local row = vgui.Create("DButton", itemScroll)
			row:Dock(TOP)
			row:SetTall(52)
			row:DockMargin(0, 0, 0, 5)
			row:SetText("")
			row.Paint = function(s, w, h)
				local on = selectedItem and selectedItem.id == id
				MilBase.DrawPanelBF2(0, 0, w, h, {
					cut = 6,
					color = on and Color(ui.accent.r, ui.accent.g, ui.accent.b, 35)
						or (s:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
					accent = on and ui.accent or nil,
				})

				draw.SimpleText(name, "MB.Small", 12, 9, ui.text)
				local meta = (def.w or 1) .. "x" .. (def.h or 1)
				if (def.stack or 1) > 1 then meta = meta .. "  •  stack " .. def.stack end
				if def.slot then meta = meta .. "  •  " .. string.upper(def.slot) end
				draw.SimpleText(meta, "MB.Tiny", 12, 29, ui.dim)
				if def.desc and def.desc ~= "" then
					draw.SimpleText(def.desc, "MB.Tiny", w - 12, 29, ui.faint,
						TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			row.DoClick = function()
				selectedItem = { id = id, name = name, def = def }
				selectedLabel:SetText("Selected: " .. name)
				selectedLabel:SetTextColor(ui.text)
				MilBase.PlayUISound("select")
			end
		end

		if shown == 0 then
			local empty = vgui.Create("DLabel", itemScroll)
			empty:Dock(TOP)
			empty:SetTall(34)
			empty:SetFont("MB.Small")
			empty:SetTextColor(ui.dim)
			empty:SetText("No items found by that name.")
		end
	end

	search.OnValueChange = refreshItems
	refreshItems()
end, function(lp)
	return lp:IsAdmin() or lp:MBStaffLevel() >= (MilBase.Config.StaffGiveItemLevel or 3)
end)
