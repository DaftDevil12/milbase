--[[
	Engineering incidents: hull breaches & terminal malfunctions.

	Admins place invisible spots per map with /engspot:
	  /engspot breach    - hull breach spot where you're aiming
	  /engspot terminal  - engineering terminal where you're aiming
	  /engspot break     - trigger the nearest spot now (testing)
	  /engspot remove    - delete the nearest spot

	Spots persist in SQLite per map. Every cfg.EngIncidentInterval seconds
	one random dormant spot malfunctions, announced server-wide:
	  BREACH   - vents sparks/steam; equip the LVS repair tool
	             (weapon_lvsrepair) and hold MOUSE1 while sweeping your aim
	             across the weld seam (a row of nodes) to seal it, like
	             tracing a weld. Engineers see breach markers from afar.
	  TERMINAL - glows red and sparks; press E for the "type the code"
	             minigame (engineers get a shorter sequence).
	Fixing pays cfg.EngRepairReward credits.
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Server: spot persistence, incidents, rewards
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_TerminalGame")
	util.AddNetworkString("MilBase_TerminalFix")
	util.AddNetworkString("MilBase_BreachWeld")

	-- A welder completed a seam node on a breach. Validate they're holding
	-- the repair tool, in range and aiming at it, then advance the weld.
	net.Receive("MilBase_BreachWeld", function(_, ply)
		local ent = net.ReadEntity()
		if not IsValid(ent) or not ply:Alive() then return end

		-- Weldable = a breached hull spot, or a destroyed ship part at its weld
		-- stage (stage 1). Both expose GetWeld/AddWeld.
		local class = ent:GetClass()
		local weldable = (class == "mb_breach" and ent:GetBreached())
			or (class == "mb_shippart" and ent:GetStage() == 1)
		if not weldable then return end
		if ent:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end

		local wep = ply:GetActiveWeapon()
		if not (IsValid(wep) and wep:GetClass() == "weapon_lvsrepair") then return end

		local aim = ent:GetPos() - ply:EyePos()
		aim:Normalize()
		if aim:Dot(ply:GetAimVector()) < 0.6 then return end

		-- One node at a time (matches the 6-node client pattern).
		if (ply.mb_nextWeldNode or 0) > CurTime() then return end
		ply.mb_nextWeldNode = CurTime() + 0.15

		ent:AddWeld(1 / 6, ply)
	end)

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_engspots ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "map VARCHAR(64), kind VARCHAR(64), pos TEXT, ang TEXT )")

	local KIND_CLASS = {
		breach = "mb_breach",
		terminal = "mb_terminal",
		shipnode = "mb_shipnode",       -- SWU ship-system console (sh_shipsystems.lua)
		hackconsole = "mb_hackconsole", -- hackable security console (sh_shipsabotage.lua)
		shippart = "mb_shippart",       -- bomb-able engine/hyperdrive part (sh_shipsabotage.lua)
		analyzer = "mb_analyzer",       -- bio-analyzer console (sh_biolab.lua)
	}

	local function spawnSpot(row)
		-- Ship nodes may carry an assigned system: kind = "shipnode:engines".
		local kind, meta = string.match(row.kind, "^([^:]+):?(.*)$")
		local class = KIND_CLASS[kind]
		if not class then return end

		local ent = ents.Create(class)
		if not IsValid(ent) then return end

		ent:SetPos(util.StringToType(row.pos, "Vector"))
		ent:SetAngles(util.StringToType(row.ang, "Angle"))
		-- Set before Spawn so the entity can pick a model from its system.
		if meta and meta ~= "" then ent.mb_assigned = meta end
		ent:Spawn()
		ent.mb_spotID = tonumber(row.id)
		return ent
	end

	local function loadSpots()
		for _, class in pairs(KIND_CLASS) do
			for _, ent in ipairs(ents.FindByClass(class)) do
				if ent.mb_spotID then ent:Remove() end
			end
		end

		MilBase.DB.Query(string.format(
			"SELECT * FROM frontier_engspots WHERE map = %s",
			MilBase.SQLStr(game.GetMap())), function(rows)
			for _, row in ipairs(rows) do
				spawnSpot(row)
			end
		end)
	end

	hook.Add("InitPostEntity", "MilBase.EngSpots", loadSpots)
	hook.Add("PostCleanupMap", "MilBase.EngSpots", function()
		timer.Simple(0, loadSpots)
	end)

	-- Reward + announcement, also called by mb_breach when welded shut.
	function MilBase.EngIncidentFixed(ply, verb)
		local reward = cfg.EngRepairReward or 0
		if reward > 0 then ply:MBAddMoney(reward) end

		MilBase.ChatMsg(nil, Color(215, 165, 70), "[ENGINEERING] ", color_white,
			ply:MBName() .. " " .. verb
			.. (reward > 0 and (" (+" .. cfg.CurrencySymbol .. reward .. ")") or "") .. ".")
	end

	net.Receive("MilBase_TerminalFix", function(_, ply)
		local term = net.ReadEntity()

		if not IsValid(term) or term:GetClass() ~= "mb_terminal" then return end
		if not term:GetBroken() then return end
		if term:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end
		-- Three timed hits take at least a couple of seconds.
		if (ply.mb_termOpen or 0) > CurTime() - 2 then return end

		term:Fix()
		MilBase.EngIncidentFixed(ply, "repaired an engineering terminal")
	end)

	-- Random malfunctions.
	timer.Create("MilBase.EngIncidents", 30, 0, function()
		local interval = cfg.EngIncidentInterval or 0
		if interval <= 0 then return end

		MilBase.EngNextIncident = MilBase.EngNextIncident or (CurTime() + interval)
		if CurTime() < MilBase.EngNextIncident then return end
		MilBase.EngNextIncident = CurTime() + interval

		local dormant = {}
		for _, ent in ipairs(ents.FindByClass("mb_breach")) do
			if not ent:GetBreached() then table.insert(dormant, ent) end
		end
		for _, ent in ipairs(ents.FindByClass("mb_terminal")) do
			if not ent:GetBroken() then table.insert(dormant, ent) end
		end
		if #dormant == 0 then return end

		local ent = dormant[math.random(#dormant)]
		ent:Break()

		MilBase.ChatMsg(nil, Color(215, 165, 70), "[ENGINEERING] ", color_white,
			ent:GetClass() == "mb_breach"
			and "Hull breach detected! Engineers to stations."
			or "An engineering terminal is malfunctioning!")
	end)

	--------------------------------------------------------------------
	-- /engspot (admin)
	--------------------------------------------------------------------

	MilBase.RegisterChatCommand("engspot", {
		help = "(Admin) Spots: /engspot breach|terminal|shipnode|shippart <system>|hackconsole|break|remove",
		adminOnly = true,
		func = function(ply, args)
			local sub = string.lower(args[1] or "")
			local tr = ply:GetEyeTrace()

			if sub == "breach" or sub == "terminal" or sub == "shipnode"
			or sub == "shippart" or sub == "hackconsole" or sub == "analyzer" then
				local pos = tr.HitPos + tr.HitNormal * (sub == "breach" and 6 or 1)
				local ang = sub == "breach" and tr.HitNormal:Angle()
					or Angle(0, ply:EyeAngles().y + 180, 0)

				-- Optional system assignment for consoles / parts:
				-- /engspot shipnode engines   /engspot shippart hyperspace
				-- (a shipnode with no system binds to the nearest terminal instead)
				local kind = sub
				if (sub == "shipnode" or sub == "shippart") and args[2] then
					kind = sub .. ":" .. string.lower(args[2])
				end

				local posStr, angStr = tostring(pos), tostring(ang)
				MilBase.DB.Insert(string.format(
					"INSERT INTO frontier_engspots (map, kind, pos, ang) VALUES (%s, %s, %s, %s)",
					MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(kind),
					MilBase.SQLStr(posStr), MilBase.SQLStr(angStr)), function(id)
					if not IsValid(ply) then return end
					spawnSpot({ id = id, kind = kind, pos = posStr, ang = angStr })
					MilBase.Notify(ply, "Placed " .. kind .. " spot #" .. tostring(id)
						.. ". /engspot break to test, /engspot remove to delete.")
				end)

			elseif sub == "break" or sub == "remove" then
				local nearest, nearestDist

				for _, class in pairs(KIND_CLASS) do
					for _, ent in ipairs(ents.FindByClass(class)) do
						local dist = ent:GetPos():DistToSqr(ply:GetPos())
						if dist < 250 * 250 and (not nearestDist or dist < nearestDist) then
							nearest, nearestDist = ent, dist
						end
					end
				end

				if not IsValid(nearest) then
					MilBase.Notify(ply, "No engineering spot within 250 units.")
					return
				end

				if sub == "break" then
					nearest:Break()
					MilBase.Notify(ply, "Triggered " .. nearest:GetClass() .. ".")
				else
					if nearest.mb_spotID then
						MilBase.DB.Run("DELETE FROM frontier_engspots WHERE id = " .. nearest.mb_spotID)
					end
					nearest:Remove()
					MilBase.Notify(ply, "Removed the spot.")
				end

			else
				local count = #ents.FindByClass("mb_breach") + #ents.FindByClass("mb_terminal")
						+ #ents.FindByClass("mb_shipnode") + #ents.FindByClass("mb_shippart")
						+ #ents.FindByClass("mb_hackconsole")
				MilBase.Notify(ply, "Usage: /engspot breach|terminal|shipnode|shippart|hackconsole|break|remove ("
					.. count .. " spots on this map).")
			end
		end,
	})

else

	--------------------------------------------------------------------
	-- Client: breach welding (trace the seam with the repair tool)
	--------------------------------------------------------------------

	local WELD_NODES = 6

	-- Six weld points forming a zig-zag seam across the face. Works for any
	-- entity with GetPos/GetAngles (hull breaches and ship parts share this).
	local function weldNodes(breach)
		local ang = breach:GetAngles()  -- Forward = wall normal
		local right, up = ang:Right(), ang:Up()
		local base = breach:GetPos()
		local nodes = {}
		for i = 0, WELD_NODES - 1 do
			local t = i / (WELD_NODES - 1) - 0.5
			local zig = (i % 2 == 0) and 5 or -5
			nodes[i + 1] = base + right * (t * 26) + up * zig
		end
		return nodes
	end
	MilBase.WeldNodes = weldNodes -- reused by the ship-part weld (sh_shipsabotage)

	local function holdingTorch(lp)
		local wep = lp:GetActiveWeapon()
		return IsValid(wep) and wep:GetClass() == "weapon_lvsrepair"
	end
	MilBase.HoldingTorch = holdingTorch

	-- Is this entity currently weldable? A breached hull spot, or a destroyed
	-- ship part sitting at its weld stage.
	local function needsWeld(ent)
		local c = ent:GetClass()
		if c == "mb_breach" then return ent:GetBreached() end
		if c == "mb_shippart" then return ent:GetStage() == 1 end
		return false
	end

	-- The weldable the player is currently servicing (torch out, near, aiming).
	local function aimedBreach(lp)
		for _, class in ipairs({ "mb_breach", "mb_shippart" }) do
			for _, ent in ipairs(ents.FindByClass(class)) do
				if needsWeld(ent) and ent:GetPos():DistToSqr(lp:GetPos()) < 150 * 150 then
					local aim = ent:GetPos() - lp:EyePos()
					aim:Normalize()
					if aim:Dot(lp:GetAimVector()) > 0.7 then return ent end
				end
			end
		end
	end

	-- Sweep the crosshair across the seam while holding MOUSE1 to weld.
	local nextWeldSend = 0
	hook.Add("Think", "MilBase.BreachWeld", function()
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() or MilBase.InEventView() then return end
		if not holdingTorch(lp) or not input.IsMouseDown(MOUSE_LEFT) then return end
		if CurTime() < nextWeldSend then return end

		local breach = aimedBreach(lp)
		if not IsValid(breach) then return end

		local node = math.Round(breach:GetWeld() * WELD_NODES) + 1
		if node > WELD_NODES then return end

		local scr = weldNodes(breach)[node]:ToScreen()
		if not scr.visible then return end

		local dx, dy = scr.x - ScrW() / 2, scr.y - ScrH() / 2
		if dx * dx + dy * dy < 72 * 72 then
			nextWeldSend = CurTime() + 0.14
			net.Start("MilBase_BreachWeld")
				net.WriteEntity(breach)
			net.SendToServer()
		end
	end)

	-- Draw the seam over a breach the player is welding.
	local function drawWeldSeam(breach)
		local nodes = weldNodes(breach)
		local done = math.Round(breach:GetWeld() * WELD_NODES)

		local screens = {}
		for i, n in ipairs(nodes) do screens[i] = n:ToScreen() end

		-- Connecting seam line.
		for i = 1, #screens - 1 do
			if screens[i].visible and screens[i + 1].visible then
				surface.SetDrawColor(i <= done and MilBase.UI.ok or Color(255, 255, 255, 40))
				surface.DrawLine(screens[i].x, screens[i].y, screens[i + 1].x, screens[i + 1].y)
			end
		end

		for i, s in ipairs(screens) do
			if not s.visible then continue end
			if i <= done then
				MilBase.DrawDiamond(s.x, s.y, 6, MilBase.UI.ok)
			elseif i == done + 1 then
				local p = 5 + 3 * math.sin(RealTime() * 8)
				MilBase.DrawDiamond(s.x, s.y, p, MilBase.UI.accent) -- current: aim here
				surface.SetDrawColor(MilBase.UI.accent)
				surface.DrawOutlinedRect(s.x - 11, s.y - 11, 22, 22)
			else
				MilBase.DrawDiamond(s.x, s.y, 5, Color(200, 200, 200), true)
			end
		end
	end

	MilBase.DrawWeldSeam = drawWeldSeam -- reused by ship-part weld (sh_shipsabotage)

	--------------------------------------------------------------------
	-- Client: breach/terminal markers
	--------------------------------------------------------------------

	hook.Add("HUDPaint", "MilBase.EngMarkers", function()
		if MilBase.InEventView() then return end
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then return end

		local ui = MilBase.UI
		local engineer = lp:MBHasCert("engineer") or lp:IsAdmin()
		local maxDist = engineer and 600 or 180

		local torch = holdingTorch(lp)

		for _, breach in ipairs(ents.FindByClass("mb_breach")) do
			if breach:GetBreached() then
				local dist = lp:GetPos():Distance(breach:GetPos())
				if dist <= maxDist then
					local screen = breach:GetPos():ToScreen()

					-- Close with the repair tool: draw the weld seam to trace.
					if torch and dist < 150 then
						drawWeldSeam(breach)
					end

					if screen.visible then
						draw.SimpleTextOutlined("⚠ HULL BREACH", "MB.Small",
							screen.x, screen.y - 26, ui.danger,
							TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

						local weld = breach:GetWeld()
						if weld > 0 then
							surface.SetDrawColor(0, 0, 0, 180)
							surface.DrawRect(screen.x - 40, screen.y - 12, 80, 6)
							surface.SetDrawColor(ui.ok)
							surface.DrawRect(screen.x - 40, screen.y - 12, math.floor(80 * weld), 6)
						elseif dist < 150 then
							draw.SimpleTextOutlined(torch
								and "HOLD [MOUSE1] AND SWEEP ACROSS THE SEAM"
								or "EQUIP THE REPAIR TOOL TO WELD", "MB.Tiny",
								screen.x, screen.y - 12, torch and ui.accent or ui.dim,
								TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
						end
					end
				end
			end
		end

		for _, term in ipairs(ents.FindByClass("mb_terminal")) do
			if term:GetBroken() then
				local dist = lp:GetPos():Distance(term:GetPos())
				if dist <= (engineer and 600 or 300) then
					local screen = (term:GetPos() + Vector(0, 0, 20)):ToScreen()
					if screen.visible then
						draw.SimpleTextOutlined("⚠ TERMINAL FAULT", "MB.Small",
							screen.x, screen.y - 10, ui.warn,
							TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
						if dist < 160 then
							draw.SimpleTextOutlined("PRESS [E] TO REPAIR", "MB.Tiny",
								screen.x, screen.y + 8, ui.dim,
								TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
						end
					end
				end
			end
		end
	end)

	--------------------------------------------------------------------
	-- Client: terminal repair = the "type the code" minigame
	--------------------------------------------------------------------

	local function openGame(term)
		local lp = LocalPlayer()
		local engineer = lp:MBHasCert("engineer") or lp:IsAdmin()

		MilBase.OpenCodeMinigame({
			title = "POWER CONDUIT REPAIR",
			subtitle = "Type the recovery sequence to reboot the terminal.",
			-- Engineers get a shorter sequence (they know the shortcuts).
			lines = MilBase.GenCodeLines(engineer and 3 or 5),
			valid = function()
				return IsValid(term) and term:GetBroken()
					and term:GetPos():DistToSqr(LocalPlayer():GetPos()) < 150 * 150
			end,
			onSuccess = function()
				net.Start("MilBase_TerminalFix")
					net.WriteEntity(term)
				net.SendToServer()
			end,
		})
	end

	net.Receive("MilBase_TerminalGame", function()
		local term = net.ReadEntity()
		if IsValid(term) then openGame(term) end
	end)

end
