--[[
	Galaxy Director shared definitions.

	Server implementation: modules/sv_galaxy.lua
	Client UI/HUD:        modules/cl_galaxy.lua
]]

if MilBase._GalaxySharedLoaded then return end
MilBase._GalaxySharedLoaded = true

MilBase.Galaxy = MilBase.Galaxy or {}
local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}

G.Version = 2
G.ValidAllegiances = {
	republic = true,
	neutral = true,
	contested = true,
	cis = true,
}

G.AllegianceNames = {
	republic = "Galactic Republic",
	neutral = "Independent / Neutral",
	contested = "Contested",
	cis = "Confederacy of Independent Systems",
}

G.EncounterNames = {
	civilian = "Civilian Contact",
	pirate = "Pirate Contact",
	republic = "Republic Patrol",
	distress = "Distress Signal",
	cis = "CIS Contact",
	cis_raid = "CIS Capital Assault",
}

G.RaidPhaseNames = {
	warning = "CIS FORCE DETECTED",
	arrival = "CAPITAL SHIP ASSAULT",
	breach = "HANGAR BREACH",
	boarding = "BOARDING ACTION",
	retreat = "CIS WITHDRAWAL",
	resolved = "ACTION COMPLETE",
}

function G.PlanetKey(name)
	name = string.lower(string.Trim(tostring(name or "")))
	name = string.gsub(name, "[^%w%s%-_'%.]", "")
	name = string.gsub(name, "%s+", " ")
	return string.sub(name, 1, 96)
end

function G.CleanText(value, maxLength)
	value = string.Trim(tostring(value or ""))
	value = string.gsub(value, "[%c]", " ")
	return string.sub(value, 1, maxLength or 256)
end

function G.GetRuntimeField(key)
	for _, field in ipairs(gd.RuntimeFields or {}) do
		if field.key == key then return field end
	end
end

function G.CopyChoices(kind)
	local result = {}
	for _, choice in ipairs(gd.EncounterChoices and gd.EncounterChoices[kind] or {}) do
		result[#result + 1] = { id = choice.id, label = choice.label }
	end
	return result
end

function G.AllegianceColor(id)
	return gd.FactionColors and gd.FactionColors[id]
		or gd.FactionColors and gd.FactionColors.neutral
		or Color(190, 190, 190)
end

function G.AllegianceLabel(id)
	return G.AllegianceNames[id] or G.AllegianceNames.neutral
end

function G.FormatDuration(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	local minutes = math.floor(seconds / 60)
	local remain = seconds % 60
	if minutes > 0 then return string.format("%dm %02ds", minutes, remain) end
	return remain .. "s"
end
