--[[
	Galaxy Director local-space CIS combat.

	Hostile ships physically fly into the battle, use their model collision
	mesh when available, and take ordinary LVS damage. Shields regenerate after
	a quiet period; hull damage is permanent and ultimately destroys the ship.

	Capital ships can use a persistent map-space position so a Munificent flies
	into the playable map sky instead of only existing at the skybox boundary.
]]

if not SERVER or MilBase._GalaxyCombatServerLoaded then return end
MilBase._GalaxyCombatServerLoaded = true

local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}
if gd.CISSkyboxCombatEnabled == false then return end

local function announce(text, color)
	if G.AnnounceNavy then
		G.AnnounceNavy(text, color or Color(235, 75, 60), "[GALAXY COMBAT] ")
	end
end

local function scheduleStateUpdate(ship)
	if not IsValid(ship) or ship.mb_nextDefenseBroadcast then return end
	ship.mb_nextDefenseBroadcast = true
	timer.Simple(0.2, function()
		if IsValid(ship) then ship.mb_nextDefenseBroadcast = nil end
		if G.BroadcastState then G.BroadcastState() end
	end)
end

G.ScheduleCombatStateUpdate = scheduleStateUpdate

local function damagePosition(ship, dmg)
	local position = dmg:GetDamagePosition()
	if (not isvector(position) or position == vector_origin)
	and dmg.GetReportedPosition then
		position = dmg:GetReportedPosition()
	end
	if not isvector(position) or position == vector_origin then
		position = ship:WorldSpaceCenter()
	end
	return position
end

local function sourceIsLVS(entity, visited)
	if not IsValid(entity) then return false end
	visited = visited or {}
	if visited[entity] then return false end
	visited[entity] = true
	if entity.LVS == true then return true end
	local class = string.lower(entity:GetClass() or "")
	if string.StartWith(class, "lvs_") or string.find(class, "_lvs_", 1, true) then
		return true
	end
	if entity:IsPlayer() and entity:InVehicle() then
		local vehicle = entity:GetVehicle()
		if sourceIsLVS(vehicle, visited) or sourceIsLVS(vehicle:GetParent(), visited) then
			return true
		end
	end
	if entity.GetOwner then
		local owner = entity:GetOwner()
		if owner ~= entity and sourceIsLVS(owner, visited) then return true end
	end
	if entity.GetParent then
		local parent = entity:GetParent()
		if parent ~= entity and sourceIsLVS(parent, visited) then return true end
	end
	return false
end

function G.NormalizeGalaxyShipDamage(ship, dmg)
	local raw = math.max(0, tonumber(dmg:GetDamage()) or 0)
	if raw <= 0 then return 0 end
	if not ship.mb_galaxyFleetVolleyDamage
	and not sourceIsLVS(dmg:GetAttacker())
	and not sourceIsLVS(dmg:GetInflictor()) then
		raw = raw * math.Clamp(tonumber(gd.CISNonLVSDamageScale) or 0.2, 0, 1)
	end
	local cap = ship:GetCapital()
		and (tonumber(gd.CISCapitalMaximumDamagePerHit) or 2600)
		or (tonumber(gd.CISScoutMaximumDamagePerHit) or 1400)
	return math.max(0, math.min(raw, math.max(1, cap)))
end

local function worldToUniverse(pos)
	if not isvector(pos) or not G.HasSWUUniverseFrame or not G.HasSWUUniverseFrame() then
		return nil
	end
	local controller = SWU.Controller
	local scale = math.max(0.0001,
		math.abs(tonumber(SWU.config and SWU.config.scale) or 1))
	local shipAngles = controller:GetInternalShipAngles()
	local delta = WorldToLocal(pos, angle_zero, controller:GetPos(), shipAngles)
	return controller:GetShipPos() + delta / scale
end

local function universeToWorld(pos)
	if not isvector(pos) or not G.HasSWUUniverseFrame or not G.HasSWUUniverseFrame() then
		return nil
	end
	local ok, result = pcall(SWU.CalculateWorldPos, SWU, pos)
	return ok and isvector(result) and result or nil
end

local function setWorldAngle(ship, desired)
	if not IsValid(ship) or not isangle(desired) then return end
	desired = Angle(desired.p, desired.y, desired.r)
	ship:SetAngles(desired)
	if not ship.mb_galaxyMapSpace and G.HasSWUUniverseFrame
	and G.HasSWUUniverseFrame() then
		ship.mb_galaxyUniverseAng = desired
			- SWU.Controller:GetInternalShipAngles()
	end
end

local function facingForDirection(ship, direction, level)
	if not IsValid(ship) or not isvector(direction) or direction:LengthSqr() < 0.01 then return end
	local desired = G.ShipTravelFacing
		and G.ShipTravelFacing(ship:GetRole(), direction) or direction:Angle()
	if isangle(desired) and level then
		desired.p = 0
		desired.r = 0
	end
	return desired
end

local function faceDirection(ship, direction, level)
	local desired = facingForDirection(ship, direction, level)
	if not isangle(desired) then return end
	setWorldAngle(ship, desired)
end

local function activePlayerCentre()
	local total = vector_origin
	local count = 0
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:Alive() and not ply:IsBot() then
			total = total + ply:GetPos()
			count = count + 1
		end
	end
	if count > 0 then return total / count end
	return vector_origin
end

local function configuredCapitalAnchors()
	local anchors = {}
	local function addAnchor(pos, ang)
		if not isvector(pos) or not util.IsInWorld(pos) then return end
		for _, existing in ipairs(anchors) do
			if existing.pos:DistToSqr(pos) < 16 * 16 then return end
		end
		anchors[#anchors + 1] = {
			pos = Vector(pos),
			ang = isangle(ang) and Angle(ang.p, ang.y, ang.r) or nil,
		}
	end
	for _, anchor in ipairs(G.Anchors or {}) do
		if anchor.kind == "capital" and isvector(anchor.pos)
		and util.IsInWorld(anchor.pos) then
			addAnchor(anchor.pos, anchor.ang)
		end
	end
	local configured = (gd.MapAnchors or {})[game.GetMap()] or {}
	for _, entry in ipairs(configured.capital or {}) do
		if isvector(entry) and util.IsInWorld(entry) then
			addAnchor(entry)
		end
		if istable(entry) and isvector(entry.pos) and util.IsInWorld(entry.pos) then
			addAnchor(entry.pos, entry.ang)
		end
	end
	return anchors
end

local function configuredCapitalAnchor()
	local anchor = configuredCapitalAnchors()[1]
	if not anchor then return nil end
	return Vector(anchor.pos),
		isangle(anchor.ang) and Angle(anchor.ang.p, anchor.ang.y, anchor.ang.r) or nil,
		true
end

local function savedCapitalPosition()
	local saved = G.SavedCapitalMapPosition
	if not istable(saved) or not isvector(saved.pos) or not util.IsInWorld(saved.pos) then
		return nil
	end
	return Vector(saved.pos),
		isangle(saved.ang) and Angle(saved.ang.p, saved.ang.y, saved.ang.r) or nil,
		false,
		true
end

local function findDefaultCapitalPosition(ship)
	local centre = activePlayerCentre()
	if centre == vector_origin then centre = select(1, G.SkyboxFrame()) end
	local sideYaw = tonumber(ship and ship.mb_galaxySideYaw) or math.Rand(0, 360)
	local radial = Angle(0, sideYaw + 180, 0):Forward()
	local desiredDistance = math.max(200, tonumber(gd.CISCapitalMapDistance) or 1700)
	local desiredAltitude = math.max(300, tonumber(gd.CISCapitalMapAltitude) or 1500)
	local traceStart = centre + Vector(0, 0, 64)
	local ceilingTrace = util.TraceLine({
		start = traceStart,
		endpos = traceStart + Vector(0, 0, 32768),
		mask = MASK_SOLID_BRUSHONLY,
	})
	local ceilingZ = ceilingTrace.Hit and ceilingTrace.HitPos.z
		or centre.z + desiredAltitude * 1.5
	local verticalRoom = math.max(350, ceilingZ - centre.z)
	local altitude = math.min(desiredAltitude, verticalRoom * 0.68)
	for _, distanceScale in ipairs({ 1, 0.75, 0.5, 0.25, 0 }) do
		for _, altitudeScale in ipairs({ 1, 0.82, 0.64, 0.46 }) do
			local candidate = centre + radial * desiredDistance * distanceScale
			candidate.z = centre.z + altitude * altitudeScale
			if util.IsInWorld(candidate) then
				return candidate, (centre - candidate):Angle(), false
			end
		end
	end
	local fallback = centre + Vector(0, 0, math.min(600, verticalRoom * 0.45))
	return fallback, (centre - fallback):Angle(), false
end

function G.CISCapitalMapPosition(ship)
	local pos, ang, manual, exactAngle = configuredCapitalAnchor()
	if isvector(pos) then return pos, ang, manual, true end
	pos, ang, manual, exactAngle = savedCapitalPosition()
	if isvector(pos) then return pos, ang, manual, exactAngle end
	return findDefaultCapitalPosition(ship)
end

local function capitalSettingKey()
	return "capitalMapPosition:" .. string.sub(game.GetMap(), 1, 43)
end

function G.SaveCISCapitalMapPosition(pos, ang)
	if not isvector(pos) or not util.IsInWorld(pos) then return end
	ang = isangle(ang) and ang or angle_zero
	G.SavedCapitalMapPosition = {
		pos = Vector(pos),
		ang = Angle(ang.p, ang.y, ang.r),
	}
	local value = {
		x = pos.x, y = pos.y, z = pos.z,
		p = ang.p, yaw = ang.y, r = ang.r,
	}
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_settings (setting_key, setting_value) VALUES (%s, %s)",
		MilBase.SQLStr(capitalSettingKey()),
		MilBase.SQLStr(util.TableToJSON({ value = value }))))
end

local function shipArrivalRadius(ship, mapSpace, lateral)
	if not IsValid(ship) then return 80 end
	if mapSpace then
		local mins, maxs = ship:GetModelRenderBounds()
		if isvector(mins) and isvector(maxs) then
			local scales = gd.MapSpaceShipModelScale or {}
			local scale = math.max(0.005, tonumber(scales[ship:GetRole()])
				or tonumber(scales.default) or tonumber(ship:GetModelSize()) or 1)
			local halfX = math.max(math.abs(mins.x), math.abs(maxs.x))
			local halfY = math.max(math.abs(mins.y), math.abs(maxs.y))
			if lateral then
				local corrections = gd.ShipModelFacingYaw or {}
				local correction = math.rad(tonumber(corrections[ship:GetRole()])
					or tonumber(corrections.default) or 0)
				return math.max(20, (math.abs(math.sin(correction)) * halfX
					+ math.abs(math.cos(correction)) * halfY) * scale)
			end
			return math.max(20, math.max(halfX, halfY) * scale)
		end
	end
	return math.max(6, tonumber(ship.mb_galaxyVisualRadius)
		or tonumber(ship:GetCombatRadius())
		or (G.MaximumShipRadius and G.MaximumShipRadius(ship))
		or 100)
end

local function combatPositionClear(ship, candidate, mapSpace, useIngressStart)
	if not IsValid(ship) or not isvector(candidate) then return false end
	local ownRadius = shipArrivalRadius(ship, mapSpace, mapSpace)
	local configuredPadding = math.max(20,
		tonumber(gd.CISCombatSeparationPadding) or 140)
	local padding = math.Clamp(ownRadius * 0.8 + 24, 24, configuredPadding)
	for _, other in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if other ~= ship and IsValid(other) and not other.mb_destroyed
		and (other.mb_galaxyMapSpace == true) == (mapSpace == true)
		and (other.mb_galaxyCombatPrepared or other.mb_galaxyOrbitalBlockade) then
			local occupied = useIngressStart and other.mb_galaxyIngressStartWorld
				or other.mb_galaxyCombatTargetWorld
			if not isvector(occupied) and other:GetFlightVelocity():LengthSqr() < 1 then
				occupied = other:GetPos()
			end
			if isvector(occupied) then
				local required = ownRadius
					+ shipArrivalRadius(other, mapSpace, mapSpace) + padding
				if candidate:DistToSqr(occupied) < required * required then
					return false
				end
			end
		end
	end
	return true
end

local function mapIngressStart(target, ship, sharedOutward)
	local centre = activePlayerCentre()
	local outward = isvector(sharedOutward) and Vector(sharedOutward)
		or target - centre
	outward.z = 0
	if outward:LengthSqr() < 1 then
		outward = Angle(0, tonumber(ship.mb_galaxySideYaw) or 0, 0):Forward()
	end
	outward:Normalize()
	local distance = math.max(600, tonumber(gd.CISCapitalMapIngressDistance) or 3200)
	local rise = tonumber(gd.CISCapitalMapIngressRise) or 250
	local wanted = target + outward * distance + Vector(0, 0, rise)
	local trace = util.TraceLine({
		start = target,
		endpos = wanted,
		mask = MASK_SOLID_BRUSHONLY,
	})
	if trace.Hit then wanted = trace.HitPos - outward * 180 end
	for step = 10, 1, -1 do
		local candidate = LerpVector(step / 10, target, wanted)
		if util.IsInWorld(candidate)
		and combatPositionClear(ship, candidate, true, true) then
			return candidate
		end
	end
	return Vector(target)
end

local function raidParkingPointAvailable(ship, candidate, planned, required)
	if not isvector(candidate) or not util.IsInWorld(candidate) then return false end
	for _, point in ipairs(planned or {}) do
		if isvector(point.pos)
		and candidate:DistToSqr(point.pos) < required * required then
			return false
		end
	end
	return combatPositionClear(ship, candidate, true, false)
end

local function buildRaidCapitalParking(active, ship, target)
	if not active or active.kind ~= "cis_raid" or not isvector(target) then return nil end
	if istable(active.mb_galaxyMunificentParking)
	and istable(active.mb_galaxyMunificentParking.byEntity) then
		return active.mb_galaxyMunificentParking
	end

	local ordered = {}
	for _, capital in ipairs(active.capitals or {}) do
		if IsValid(capital) then ordered[#ordered + 1] = capital end
	end
	table.sort(ordered, function(left, right)
		local leftIndex = tonumber(left.mb_galaxyRaidCapitalIndex) or left:EntIndex()
		local rightIndex = tonumber(right.mb_galaxyRaidCapitalIndex) or right:EntIndex()
		return leftIndex == rightIndex and left:EntIndex() < right:EntIndex()
			or leftIndex < rightIndex
	end)
	if #ordered == 0 and IsValid(ship) then ordered[1] = ship end

	local centre = activePlayerCentre()
	local forward = centre - target
	forward.z = 0
	if forward:LengthSqr() <= 1 then forward = Vector(1, 0, 0) end
	forward:Normalize()
	local outward = forward * -1
	local right = forward:Cross(Vector(0, 0, 1))
	if right:LengthSqr() <= 0.001 then right = Vector(0, 1, 0) end
	right:Normalize()

	local widest = shipArrivalRadius(ship, true, true)
	for _, capital in ipairs(ordered) do
		widest = math.max(widest, shipArrivalRadius(capital, true, true))
	end
	local padding = math.max(20, tonumber(gd.CISCombatSeparationPadding) or 140)
	local spacing = math.max(200, tonumber(gd.RaidMunificentMapSpacing) or 900,
		widest * 2 + padding)
	local altitude = math.max(0, tonumber(gd.RaidMunificentMapAltitudeStep) or 120)
	local anchors = configuredCapitalAnchors()
	local useDedicatedAnchors = #anchors >= #ordered
	local parking = {
		points = {},
		byEntity = {},
		spacing = spacing,
		outward = Vector(outward),
	}

	for rank, capital in ipairs(ordered) do
		local candidate
		local angle
		if useDedicatedAnchors then
			local anchor = anchors[rank]
			if anchor and raidParkingPointAvailable(
				capital, anchor.pos, parking.points, spacing) then
				candidate = Vector(anchor.pos)
				angle = isangle(anchor.ang)
					and Angle(anchor.ang.p, anchor.ang.y, anchor.ang.r) or nil
			end
		end

		local slot = rank - (#ordered + 1) * 0.5
		if not isvector(candidate) then
			for _, scale in ipairs({ 1, 1.2, 1.45, 1.75, 2.1 }) do
				for _, row in ipairs({ 0, 1, -1, 2, -2 }) do
					local point = target + right * slot * spacing * scale
						+ outward * math.abs(row) * spacing * 0.42
						+ Vector(0, 0, row * math.max(altitude, widest * 0.36))
					if raidParkingPointAvailable(
						capital, point, parking.points, spacing) then
						candidate = point
						break
					end
				end
				if isvector(candidate) then break end
			end
		end

		-- A valid map may be too narrow for the preferred formation. Keep the
		-- numbered slot distinct even in that case; never collapse back to the
		-- shared centre point used by older raids.
		if not isvector(candidate) then
			candidate = target + right * slot * spacing
				+ Vector(0, 0, (rank % 2 == 0 and 1 or -1)
					* math.abs(slot) * math.max(altitude, padding))
		end
		if not isangle(angle) then
			angle = facingForDirection(capital, centre - candidate, true)
		end
		local point = {
			index = rank,
			pos = Vector(candidate),
			ang = isangle(angle) and Angle(angle.p, angle.y, angle.r) or nil,
			outward = Vector(outward),
		}
		parking.points[rank] = point
		parking.byEntity[capital] = point
		capital.mb_galaxyRaidParkingIndex = rank
		capital.mb_galaxyRaidParkingPoint = Vector(candidate)
	end
	active.mb_galaxyMunificentParking = parking
	return parking
end

local function raidCapitalMapPosition(ship, target)
	local active = G.Active
	if not active or active.kind ~= "cis_raid"
	or not isvector(target) then return target, nil end
	local parking = buildRaidCapitalParking(active, ship, target)
	local point = parking and parking.byEntity and parking.byEntity[ship]
	if not point then return target, parking and parking.outward or nil end
	return Vector(point.pos), Vector(point.outward), point.ang
end

local function combatPathClear(ship, destination, shipRadius)
	if not G.PlanetClearanceAt then return true end
	local origin = ship:GetPos()
	for index = 0, 12 do
		if not G.PlanetClearanceAt(
			LerpVector(index / 12, origin, destination), shipRadius) then
			return false
		end
	end
	return true
end

local function skyboxCombatPosition(ship)
	local center, radius, min, max = G.SkyboxFrame()
	local radial = ship:GetPos() - center
	radial.z = 0
	if radial:LengthSqr() < 1 then
		radial = Angle(0, tonumber(ship.mb_galaxySideYaw) or 0, 0):Forward()
	end
	radial:Normalize()
	local fraction = math.Clamp(tonumber(gd.CISCombatPositionRadius) or 0.34, 0.18, 0.72)
	local desiredRadius = radius * fraction
	local shipRadius = math.max(8, tonumber(ship.mb_galaxyVisualRadius)
		or (G.MaximumShipRadius and G.MaximumShipRadius(ship)) or 100)
	local zInset = math.min(90, math.max(24, (max.z - min.z) * 0.12))
	local targetZ = math.Clamp(ship:GetPos().z, min.z + zInset, max.z - zInset)
	for _, angleOffset in ipairs({ 0, 18, -18, 36, -36, 58, -58, 90, -90, 135, -135, 180 }) do
		local direction = Vector(radial)
		direction:Rotate(Angle(0, angleOffset, 0))
		for _, heightOffset in ipairs({ 0, 120, -120, 240, -240 }) do
			local candidate = center + direction * desiredRadius
			candidate.z = math.Clamp(targetZ + heightOffset, min.z + zInset, max.z - zInset)
			if combatPathClear(ship, candidate, shipRadius)
			and combatPositionClear(ship, candidate, false, false) then
				return candidate
			end
		end
	end
	return nil
end

function G.EmitShipShieldImpact(ship, position)
	if not IsValid(ship) then return end
	position = isvector(position) and position or ship:WorldSpaceCenter()
	local effect = EffectData()
	effect:SetOrigin(position)
	effect:SetNormal((position - ship:WorldSpaceCenter()):GetNormalized())
	effect:SetScale(ship:GetCapital() and 1.4 or 0.8)
	util.Effect("StunstickImpact", effect, true, true)
end

function G.OnGalaxyHullDamaged(ship, dmg)
	if not IsValid(ship) then return end
	local position = damagePosition(ship, dmg)
	local normal = position - ship:WorldSpaceCenter()
	if normal:LengthSqr() < 0.01 then normal = ship:GetUp() end
	normal:Normalize()
	util.Decal("FadingScorch", position + normal * 8,
		position - normal * 18)
	scheduleStateUpdate(ship)
	hook.Run("MilBase.GalaxyHullDamaged", ship, dmg)
end

function G.UpdateShipDamageEffects(ship, now)
	if not IsValid(ship) or not ship.mb_galaxyCombatPrepared or ship.mb_destroyed then return end
	local fraction = ship:GetHullFraction()
	local threshold = math.Clamp(tonumber(gd.CISHullEffectsStartAt) or 0.7, 0.1, 0.95)
	if fraction > threshold or now < (ship.mb_nextHullEffect or 0) then return end
	local severity = 1 - fraction
	ship.mb_nextHullEffect = now + math.Rand(
		math.max(0.35, 1.6 - severity), math.max(0.7, 2.3 - severity))
	local radius = math.max(20, tonumber(ship:GetCombatRadius()) or 80)
	local position = ship:WorldSpaceCenter() + VectorRand() * radius * 0.48
	local smoke = EffectData()
	smoke:SetOrigin(position)
	smoke:SetScale(math.Clamp(radius / 160, 0.5, 2.4))
	smoke:SetMagnitude(1 + severity * 2)
	util.Effect("Smoke", smoke, true, true)
	if fraction <= 0.48 then util.Effect("Sparks", smoke, true, true) end
	if fraction <= 0.2 and math.Rand(0, 1) < 0.28 then
		local blast = EffectData()
		blast:SetOrigin(position)
		blast:SetScale(0.45)
		util.Effect("Explosion", blast, true, true)
	end
end

function G.BeginCISRetreat(ship)
	if not IsValid(ship) or ship.mb_destroyed or ship.mb_galaxyRetreating then
		return false
	end
	ship.mb_galaxyRetreating = true
	ship.mb_galaxyCombatIngress = false
	ship.mb_galaxyCombatReady = false
	ship:SetCombatReady(false)
	ship:ClearCombatTarget()
	ship:SetShipState("retreating")
	ship.mb_galaxyHoldForPlayerDeparture = false
	ship.mb_galaxyPlayerDeparting = true
	local direction
	if ship.mb_galaxyMapSpace and isvector(ship.mb_galaxyIngressStartWorld) then
		direction = ship.mb_galaxyIngressStartWorld - ship:GetPos()
	else
		direction = ship:GetPos() - select(1, G.SkyboxFrame())
		direction.z = 0
	end
	if direction:LengthSqr() < 1 then direction = ship:GetForward() end
	direction:Normalize()
	local speed = ship.mb_galaxyMapSpace
		and (tonumber(gd.CISCapitalMapRetreatSpeed) or 650)
		or (tonumber(gd.CISRetreatSpeed) or 110)
	ship:SetFlightVelocity(direction * speed)
	if gd.ShipFlightSmoothingEnabled == false then faceDirection(ship, direction) end
	ship:SetDieAt(CurTime() + math.max(4, tonumber(gd.CISRetreatLifetime) or 18))
	scheduleStateUpdate(ship)
	return true
end

function G.HandleGalaxyShipDamage(ship, dmg)
	if not IsValid(ship) or not ship.mb_galaxyCombatPrepared then return false end
	if ship.mb_galaxyRetreating or ship.mb_destroyed then return true end
	local amount = G.NormalizeGalaxyShipDamage(ship, dmg)
	if amount <= 0 then return true end
	local position = damagePosition(ship, dmg)
	ship.mb_galaxyLastCombatDamage = CurTime()
	ship.mb_galaxyShieldRegenBuffer = 0

	if ship:GetShield() > 0 then
		local before = ship:GetShield()
		local overflow = math.max(0, amount - before)
		ship:SetShield(math.max(0, math.ceil(before - amount)))
		ship:SetShieldHitPosition(position)
		ship:SetShieldHitUntil(CurTime() + 0.32)
		G.EmitShipShieldImpact(ship, position)
		if before > 0 and ship:GetShield() <= 0 then
			announce(ship:GetShipName()
				.. ": deflector shield collapsed. Hull damage is now permanent.",
				Color(75, 190, 255))
			hook.Run("MilBase.GalaxyShieldBroken", ship, dmg:GetAttacker())
		end
		scheduleStateUpdate(ship)
		if overflow <= 0 then return true end
		dmg:SetDamage(overflow)
		return false, overflow
	end

	dmg:SetDamage(amount)
	return false, amount
end

function G.UpdateCISCombatIngress(ship)
	if not IsValid(ship) or not ship.mb_galaxyCombatIngress
	or ship.mb_galaxyCombatReady or ship.mb_galaxyRetreating then return end
	if CurTime() < (tonumber(ship.mb_galaxyCombatIngressReleaseAt) or 0) then
		ship:SetFlightVelocity(vector_origin)
		ship.mb_galaxyUniverseVelocity = vector_origin
		ship.mb_galaxyLocalVelocity = vector_origin
		ship.mb_galaxyLongitudinalAcceleration = 0
		ship:SetShipState("forming attack approach")
		return
	end
	ship.mb_galaxyCombatIngressReleaseAt = nil
	local target = ship.mb_galaxyMapSpace and ship.mb_galaxyCombatTargetWorld
		or universeToWorld(ship.mb_galaxyCombatTargetUniverse)
		or ship.mb_galaxyCombatTargetWorld
	if not isvector(target) then
		ship.mb_galaxyCombatIngress = false
		ship.mb_galaxyCombatReady = true
		ship:SetCombatReady(true)
		ship:SetFlightVelocity(vector_origin)
		ship.mb_galaxyUniverseVelocity = vector_origin
		ship.mb_galaxyLocalVelocity = vector_origin
		ship.mb_galaxyLongitudinalAcceleration = 0
		return
	end
	local delta = target - ship:GetPos()
	local distance = delta:Length()
	local tolerance = math.max(25, tonumber(gd.CISCombatArrivalTolerance) or 70)
		+ math.min(80, (tonumber(ship.mb_galaxyVisualRadius) or 0) * 0.18)
	if distance <= tolerance then
		ship:SetPos(target)
		ship:SetFlightVelocity(vector_origin)
		ship.mb_galaxyUniverseVelocity = vector_origin
		ship.mb_galaxyLocalVelocity = vector_origin
		ship.mb_galaxyLongitudinalAcceleration = 0
		ship.mb_galaxyCombatIngress = false
		ship.mb_galaxyCombatReady = true
		ship:SetCombatReady(true)
		ship:SetShipState("holding attack position")
		if isangle(ship.mb_galaxyCombatTargetAngle) then
			setWorldAngle(ship, ship.mb_galaxyCombatTargetAngle)
		else
			local centre = ship.mb_galaxyMapSpace and activePlayerCentre()
				or select(1, G.SkyboxFrame())
			faceDirection(ship, centre - ship:GetPos(), true)
		end
		if not ship.mb_galaxyMapSpace and G.BindShipToSWUUniverse then
			G.BindShipToSWUUniverse(ship)
		end
		if ship.mb_galaxyMapSpace and ship:GetCapital()
		and not ship.mb_galaxyCapitalTargetManual
		and not ship.mb_galaxyRaidCapitalIndex then
			G.SaveCISCapitalMapPosition(ship:GetPos(), ship:GetAngles())
		end
		scheduleStateUpdate(ship)
		return
	end
	local speed = ship.mb_galaxyMapSpace and ship.mb_galaxyEscortBattle
		and (tonumber(gd.EscortMapHostileIngressSpeed) or 340)
		or ship.mb_galaxyMapSpace and ship:GetCapital()
		and (tonumber(gd.CISCapitalMapIngressSpeed) or 420)
		or ship:GetCapital() and (tonumber(gd.CISCapitalIngressSpeed) or 58)
		or (tonumber(gd.CISCombatIngressSpeed) or 82)
	local profile = G.ShipFlightProfile and G.ShipFlightProfile(ship) or {}
	local motionScale = ship.mb_galaxyMapSpace
		and math.max(1, tonumber(gd.ShipMapSpaceMotionScale) or 8) or 1
	local brake = math.max(1, tonumber(profile.brake) or 24) * motionScale
	local remaining = math.max(0, distance - tolerance)
	speed = math.min(speed, math.max(6, math.sqrt(2 * brake * remaining)))
	local direction = delta:GetNormalized()
	ship:SetFlightVelocity(direction * speed)
	if gd.ShipFlightSmoothingEnabled == false then faceDirection(ship, direction) end
end

function G.UpdateShipDefense(ship, now, dt)
	if not IsValid(ship) or not ship.mb_galaxyCombatPrepared then return end
	G.UpdateCISCombatIngress(ship)
	if ship.mb_galaxyRetreating then return end
	if ship:GetShield() >= ship:GetMaxShield() or ship:GetMaxShield() <= 0 then return end
	local delay = math.max(1, tonumber(gd.CISShieldRegenDelay) or 12)
	if now - (ship.mb_galaxyLastCombatDamage or now) < delay then return end
	local rate = math.max(0, tonumber(gd.CISShieldRegenPerSecond) or 0.04)
	rate = rate * math.Clamp(tonumber(ship.mb_galaxyShieldRegenMultiplier) or 1, 0, 1)
	ship.mb_galaxyShieldRegenBuffer = (ship.mb_galaxyShieldRegenBuffer or 0)
		+ ship:GetMaxShield() * rate * math.max(0, dt)
	local whole = math.floor(ship.mb_galaxyShieldRegenBuffer)
	if whole <= 0 then return end
	ship.mb_galaxyShieldRegenBuffer = ship.mb_galaxyShieldRegenBuffer - whole
	local before = ship:GetShield()
	ship:SetShield(math.min(ship:GetMaxShield(), before + whole))
	if before <= 0 and ship:GetShield() > 0 then
		announce(ship:GetShipName()
			.. ": deflector shield regeneration detected.",
			Color(75, 190, 255))
	end
	scheduleStateUpdate(ship)
end

function G.PrepareCISCombatShip(ship)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship"
	or ship.mb_galaxyCombatPrepared then return ship end
	local trueFaction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	if trueFaction ~= "cis" or not ship:GetHostile() then return ship end
	-- Ambient battles still use the proper model hitbox, hull and regenerating
	-- shields, but must continue their visible transit instead of being pulled
	-- into the normal CIS assault ingress routine.
	if ship.mb_galaxyBackgroundBattle then
		ship.mb_galaxyCombatPrepared = true
		ship:SetInvulnerable(false)
		ship:SetHull(ship:GetMaxHull())
		local players = G.ActivePlayerCount and G.ActivePlayerCount() or #player.GetAll()
		local definition = G.ShipSizeDefinition and G.ShipSizeDefinition(
			ship.GetSizeClass and ship:GetSizeClass() or "") or {}
		local shieldScale = math.max(0.05,
			tonumber(definition.shieldMultiplier) or 1)
		local shieldBase = (tonumber(gd.CISScoutShield) or 2600)
			+ math.max(0, players - 1)
				* (tonumber(gd.CISShieldPerPlayer) or 350) * 0.3
		local shield = math.max(50, math.floor(shieldBase * shieldScale))
		ship:SetMaxShield(shield)
		ship:SetShield(shield)
		ship:SetShieldHitUntil(0)
		ship:SetShieldHitPosition(ship:WorldSpaceCenter())
		ship.mb_galaxyLastCombatDamage = CurTime()
		if ship.RefreshCombatCollision then
			ship:RefreshCombatCollision(gd.CISUseModelCollision ~= false)
		end
		ship:SetCombatReady(true)
		scheduleStateUpdate(ship)
		return ship
	end

	ship.mb_galaxyCombatPrepared = true
	ship:SetInvulnerable(false)
	ship:SetDieAt(0)
	ship.mb_galaxyHoldForPlayerDeparture = true
	ship.mb_galaxyPlayerDeparting = false
	ship:SetHull(ship:GetMaxHull())
	local players = G.ActivePlayerCount and G.ActivePlayerCount() or #player.GetAll()
	local raidCapital = ship.mb_galaxyRaidCapital == true
	local baseShield = raidCapital
		and (tonumber(gd.RaidMunificentShieldBase) or 5200)
		or ship:GetCapital()
		and (tonumber(gd.CISCapitalShield) or 9000)
		or (tonumber(gd.CISScoutShield) or 2600)
	local playerShield = raidCapital
		and (tonumber(gd.RaidMunificentShieldPerPlayer) or 220)
		or (tonumber(gd.CISShieldPerPlayer) or 350)
	local playerScale = ship:GetCapital() and 1 or 0.3
	local definition = G.ShipSizeDefinition and G.ShipSizeDefinition(
		ship.GetSizeClass and ship:GetSizeClass() or "") or {}
	local shieldScale = ship:GetCapital() and 1 or math.max(0.05,
		tonumber(definition.shieldMultiplier) or 1)
	local shield = math.max(50, math.floor((baseShield
		+ math.max(0, players - 1)
			* playerShield * playerScale) * shieldScale))
	ship:SetMaxShield(shield)
	ship:SetShield(shield)
	ship:SetShieldHitUntil(0)
	ship:SetShieldHitPosition(ship:WorldSpaceCenter())
	ship.mb_galaxyLastCombatDamage = CurTime()
	if ship.RefreshCombatCollision then
		ship:RefreshCombatCollision(gd.CISUseModelCollision ~= false)
	end

	local target, targetAngle, targetIsManual, targetAngleIsExact
	local raidApproachOutward, raidParkingAngle
	if ship.mb_galaxyEscortBattle and isvector(ship.mb_galaxyEscortBattleTarget) then
		target = Vector(ship.mb_galaxyEscortBattleTarget)
		targetAngle = isangle(ship.mb_galaxyEscortBattleAngle)
			and Angle(ship.mb_galaxyEscortBattleAngle.p,
				ship.mb_galaxyEscortBattleAngle.y, ship.mb_galaxyEscortBattleAngle.r) or nil
		targetAngleIsExact = isangle(targetAngle)
		local start = isvector(ship.mb_galaxyEscortBattleIngressStart)
			and Vector(ship.mb_galaxyEscortBattleIngressStart)
			or mapIngressStart(target, ship)
		ship.mb_galaxyMapSpace = true
		ship.mb_galaxySkyboxManaged = false
		ship.mb_galaxyUniversePos = nil
		ship.mb_galaxyUniverseAng = nil
		ship.mb_galaxyUniverseVelocity = nil
		ship.mb_galaxyLastFlightVelocity = nil
		ship.mb_galaxyIngressStartWorld = Vector(start)
		if G.ApplyMapSpaceShipScale then G.ApplyMapSpaceShipScale(ship, ship:GetRole()) end
		ship:SetPos(start)
		faceDirection(ship, target - start)
	elseif ship:GetCapital() and gd.CISCapitalUsesMapSpace ~= false then
		if G.ApplyMapSpaceShipScale then G.ApplyMapSpaceShipScale(ship, ship:GetRole()) end
		target, targetAngle, targetIsManual, targetAngleIsExact
			= G.CISCapitalMapPosition(ship)
		if isvector(target) then
			target, raidApproachOutward, raidParkingAngle
				= raidCapitalMapPosition(ship, target)
			if ship.mb_galaxyRaidCapitalIndex then
				targetAngle = isangle(raidParkingAngle)
					and Angle(raidParkingAngle.p, raidParkingAngle.y, raidParkingAngle.r)
					or facingForDirection(ship, activePlayerCentre() - target, true)
				targetAngleIsExact = true
			elseif isangle(targetAngle) and not targetAngleIsExact then
				targetAngle = facingForDirection(ship, targetAngle:Forward(), true)
				targetAngleIsExact = true
			end
			local start = mapIngressStart(target, ship, raidApproachOutward)
			ship.mb_galaxyMapSpace = true
			ship.mb_galaxySkyboxManaged = false
			ship.mb_galaxyUniversePos = nil
			ship.mb_galaxyUniverseAng = nil
			ship.mb_galaxyUniverseVelocity = nil
			ship.mb_galaxyLastFlightVelocity = nil
			ship.mb_galaxyIngressStartWorld = Vector(start)
			ship.mb_galaxyCapitalTargetManual = targetIsManual == true
			ship:SetPos(start)
			faceDirection(ship, target - start)
		end
	else
		target = skyboxCombatPosition(ship)
	end

	if isvector(target) then
		ship.mb_galaxyCombatTargetWorld = Vector(target)
		ship.mb_galaxyCombatTargetAngle = isangle(targetAngle)
			and Angle(targetAngle.p, targetAngle.y, targetAngle.r) or nil
		ship.mb_galaxyCombatTargetUniverse = ship.mb_galaxyMapSpace and nil
			or worldToUniverse(target)
		ship.mb_galaxyCombatIngress = true
		if ship.mb_galaxyRaidCapitalIndex then
			ship.mb_galaxyCombatIngressReleaseAt = CurTime()
				+ math.max(0, tonumber(gd.RaidMunificentIngressStagger) or 0.65)
				* math.max(0, ship.mb_galaxyRaidCapitalIndex - 1)
		end
		ship.mb_galaxyCombatReady = false
		ship:SetCombatReady(false)
		ship:SetShipState(ship.mb_galaxyMapSpace
			and "entering local airspace" or "entering weapons range")
		G.UpdateCISCombatIngress(ship)
	else
		ship.mb_galaxyCombatReady = true
		ship:SetCombatReady(true)
		ship:SetShipState("holding attack position")
		ship:SetFlightVelocity(vector_origin)
	end
	scheduleStateUpdate(ship)
	return ship
end

local baseSpawnShip = G.SpawnShip
function G.SpawnShip(role, opts)
	opts = opts or {}
	local ship = baseSpawnShip(role, opts)
	if IsValid(ship) and opts.hostile == true
	and (opts.faction == "cis" or role == "cis_scout" or role == "cis_capital") then
		timer.Simple(0, function()
			if IsValid(ship) then G.PrepareCISCombatShip(ship) end
		end)
	end
	return ship
end

local baseBombardMainShip = G.BombardMainShip
function G.BombardMainShip(active, heavy)
	if active and active.kind == "cis_raid" and G.RaidCapitals then
		local ready = false
		for _, attacker in ipairs(G.RaidCapitals(active)) do
			if not attacker.mb_galaxyCombatPrepared
			or attacker:GetCombatReady() and not attacker.mb_galaxyRetreating then
				ready = true
				break
			end
		end
		if not ready then return end
	else
		local attacker = IsValid(active and active.capital) and active.capital
			or IsValid(active and active.contactShip) and active.contactShip
		if IsValid(attacker) and attacker.mb_galaxyCombatPrepared
		and (not attacker.mb_galaxyCombatReady or attacker.mb_galaxyRetreating) then
			return
		end
	end
	return baseBombardMainShip(active, heavy)
end

local baseDamageCapital = G.DamageCapital
function G.DamageCapital(amount, attacker, reason, requestedTarget)
	local capital = IsValid(requestedTarget) and requestedTarget
		or G.PrimaryRaidCapital and G.PrimaryRaidCapital(G.Active)
		or G.Active and G.Active.capital
	if IsValid(capital) then capital.mb_galaxyFleetVolleyDamage = true end
	local ok, message = baseDamageCapital(amount, attacker, reason, capital)
	if IsValid(capital) then capital.mb_galaxyFleetVolleyDamage = nil end
	return ok, message
end

local basePublicSnapshot = G.PublicSnapshot
function G.PublicSnapshot()
	local snapshot = basePublicSnapshot()
	local active = G.Active
	local target = active and active.kind == "cis_raid" and G.PrimaryRaidCapital
		and G.PrimaryRaidCapital(active)
		or active and (IsValid(active.capital) and active.capital
		or IsValid(active.contactShip) and active.contactShip)
	if snapshot and snapshot.active and IsValid(target)
	and target.mb_galaxyCombatPrepared then
		snapshot.active.targetEntity = target:EntIndex()
		snapshot.active.targetName = target:GetShipName()
		snapshot.active.targetState = target:GetShipState()
		snapshot.active.targetReady = target:GetCombatReady()
		snapshot.active.targetHull = target:GetHull()
		snapshot.active.targetMaxHull = target:GetMaxHull()
		snapshot.active.targetShield = target:GetShield()
		snapshot.active.targetMaxShield = target:GetMaxShield()
		snapshot.active.mapSpace = target.mb_galaxyMapSpace == true
	end
	return snapshot
end

for _, obsolete in ipairs(ents.FindByClass("mb_galaxy_weakpoint")) do
	obsolete:Remove()
end

for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
	if ship:GetHostile()
	and (ship.mb_galaxyTrueFaction or ship:GetFaction()) == "cis" then
		G.PrepareCISCombatShip(ship)
	end
end
