-- Prison gameplay upgrade: hybrid navigation, physical guard commands,
-- staged incidents, surveillance, alarms and safe lockdown control.
if not SERVER or MilBase._PrisonUpgradeServerLoaded then return end
MilBase._PrisonUpgradeServerLoaded = true

local P = MilBase.Prison
local cfg = MilBase.Config.Prison or {}
if cfg.Enabled == false or not P then return end

local NET_ALERT = "MilBase_Prison_Alert"
local NET_SPEECH = "MilBase_Prison_Speech"
util.AddNetworkString(NET_ALERT)
util.AddNetworkString(NET_SPEECH)

P.CameraRuntime = P.CameraRuntime or {}
P.PathGraph = P.PathGraph or { nodes = {}, edges = {} }
P.RouteDoorRuntime = P.RouteDoorRuntime or {}

local TAKEOVER_OBJECTIVES = {
	{ kind = "takeover_armory", label = "ARMORY", role = "raider" },
	{ kind = "takeover_engineering", label = "ENGINEERING", role = "saboteur" },
	{ kind = "takeover_comms", label = "COMMUNICATIONS", role = "saboteur" },
	{ kind = "takeover_bridge", label = "BRIDGE", role = "seizer" },
}

local function unix()
	return os.time()
end

local function clamp(value, minimum, maximum)
	return math.Clamp(tonumber(value) or 0, minimum, maximum)
end

local function trait(record, wanted)
	for _, value in ipairs(record and record.traits or {}) do
		if value == wanted then return true end
	end
	return false
end

local function recordFor(value)
	if istable(value) and value.id then return value end
	if IsValid(value) and value.GetPrisonerID then
		return P.State and P.State.prisoners and P.State.prisoners[value:GetPrisonerID()]
	end
	return P.State and P.State.prisoners and P.State.prisoners[tostring(value or "")]
end

local function playerName(ply)
	if not IsValid(ply) then return "SYSTEM" end
	return tostring(ply.MBName and ply:MBName() or ply:Nick())
end

local function assignCivilianPackModel(record)
	if not record or record.speciesModelAssigned
	or cfg.UseCivilianPackPrisonerModels == false then return end
	if (record.sourceInspection or record.civilianPackModel
	or tostring(record.caseID or "") ~= "")
	and util.IsValidModel(record.model or "") then
		record.speciesModelAssigned = true
		return
	end
	if not MilBase.ChooseSpeciesProfile then return end
	local profile = MilBase.ChooseSpeciesProfile("prisoner", cfg.PrisonerSpeciesWeights)
	if not profile or not profile.species or not profile.model then return end
	record.model = profile.model
	record.skin = 0
	record.bodygroups = {}
	record.civilianPackModel = true
	record.civilianPackAlias = profile.alias or ""
	record.speciesID = profile.species.id
	record.speciesModelAssigned = true
	record.civilianPackAppearanceCaptured = false
end

local function choosePrisonerLanguage(record)
	if not record then return "basic" end
	local species
	if record.speciesID and MilBase.GetSpecies then
		species = MilBase.GetSpecies(record.speciesID)
	end
	if not species and MilBase.SpeciesForModel then
		species = MilBase.SpeciesForModel(record.civilianPackAlias or record.model)
	end
	record.speciesID = species and species.id or "human"
	local native = P.CleanID(species and species.nativeLanguage or "basic", "basic")
	if not (MilBase.Languages and MilBase.Languages[native]) then
		native = "basic"
	end
	return native
end

function P.ResolvePrisonerLanguage(record, listener)
	record = recordFor(record)
	if not record or not IsValid(listener) then return false, nil end
	local languageID = choosePrisonerLanguage(record)
	record.languageID = languageID
	local position = IsValid(record.entity) and record.entity:GetPos() or listener:GetPos()
	if MilBase.ResolveLanguageForListener then
		return MilBase.ResolveLanguageForListener(listener, languageID, position,
			cfg.LanguageTranslatorRadius or 320)
	end
	return P.PlayerUnderstandsLanguage(listener, languageID), nil
end

function P.BroadcastPrisonerSpeech(record, readableText)
	record = recordFor(record)
	if not record or not IsValid(record.entity) then return end
	readableText = string.sub(string.Trim(tostring(readableText or "")), 1, 260)
	if readableText == "" then return end
	local languageID = choosePrisonerLanguage(record)
	record.languageID = languageID
	local language = P.Language(languageID) or {}
	local range = math.max(160, tonumber(cfg.LanguageSpeechRadius) or 720)
	local rangeSquared = range * range
	for _, listener in ipairs(player.GetHumans()) do
		if listener:Alive()
		and listener:GetPos():DistToSqr(record.entity:GetPos()) <= rangeSquared then
			local understood, translator = P.ResolvePrisonerLanguage(record, listener)
			local displayed = understood and readableText
				or tostring(language.untranslated or "[Unintelligible speech]")
			net.Start(NET_SPEECH)
				net.WriteEntity(record.entity)
				net.WriteString(string.sub(tostring(record.name or "Prisoner"), 1, 96))
				net.WriteString(string.sub(tostring(language.name or languageID), 1, 80))
				net.WriteString(displayed)
				net.WriteBool(understood)
				net.WriteString(IsValid(translator) and playerName(translator) or "")
			net.Send(listener)
		end
	end
end

local function normaliseRecord(record)
	if not record then return nil end
	assignCivilianPackModel(record)
	record.languageID = choosePrisonerLanguage(record)
	record.speciesName = MilBase.SpeciesName and MilBase.SpeciesName(record.speciesID) or "Human"
	if record.status == "escaping" then
		record.status = "rioting"
		record.riotRole = "assault"
		record.escapeNode = nil
	end
	for index, value in ipairs(record.traits or {}) do
		if value == "escape_focused" then record.traits[index] = "takeover_planner" end
	end
	if record.suspicion and record.suspicion.kind == "escape" then
		record.suspicion.kind = "takeover"
		record.suspicion.label = "mapping restricted ship systems"
	end
	record.restraintLevel = math.Clamp(tonumber(record.restraintLevel)
		or (record.restrained == false and 0 or 1), 0, 2)
	record.restrained = record.restraintLevel > 0
	record.escortAssistSteamID = tostring(record.escortAssistSteamID or "")
	record.intakeStage = tostring(record.intakeStage
		or (record.intakeComplete and "complete" or "search"))
	record.property = istable(record.property) and record.property or {}
	record.contraband = istable(record.contraband) and record.contraband or {}
	record.evidence = istable(record.evidence) and record.evidence or {}
	record.interviews = istable(record.interviews) and record.interviews or {}
	record.needs = istable(record.needs) and record.needs or table.Copy(cfg.InitialNeeds or {})
	record.knownAssociates = istable(record.knownAssociates) and record.knownAssociates or {}
	record.guardRelations = istable(record.guardRelations) and record.guardRelations or {}
	record.memories = istable(record.memories) and record.memories or {}
	record.intelligence = istable(record.intelligence) and record.intelligence or {}
	record.commandHistory = istable(record.commandHistory) and record.commandHistory or {}
	record.suspicion = istable(record.suspicion) and record.suspicion or nil
	record.lastIncidentAt = tonumber(record.lastIncidentAt) or 0
	record.lastKnownZone = tostring(record.lastKnownZone or "")
	record.riotRole = tostring(record.riotRole or "")
	return record
end

local function addMemory(record, kind, text, actor, weight)
	if not record then return end
	record.memories = record.memories or {}
	table.insert(record.memories, 1, {
		time = unix(),
		kind = tostring(kind or "custody"),
		text = string.sub(tostring(text or ""), 1, 180),
		actor = IsValid(actor) and actor:SteamID64() or "",
		actorName = playerName(actor),
		weight = clamp(weight or 0, -5, 5),
	})
	while #record.memories > math.max(8, tonumber(cfg.MaximumPrisonerMemories) or 24) do
		table.remove(record.memories)
	end
end

local function changeRelationship(record, ply, amount, reason)
	if not record or not IsValid(ply) then return end
	local id = ply:SteamID64()
	record.guardRelations = record.guardRelations or {}
	record.guardRelations[id] = clamp((record.guardRelations[id] or 0) + amount, -100, 100)
	if reason then addMemory(record, "guard", reason, ply, amount) end
end

local function relationship(record, ply)
	return IsValid(ply) and tonumber((record.guardRelations or {})[ply:SteamID64()]) or 0
end

local VOICE_LINES = {
	obey = { "ok01.wav", "ok02.wav", "answer02.wav" },
	refuse = { "no01.wav", "no02.wav", "answer17.wav" },
	surrender = { "getdown02.wav", "answer25.wav" },
	concern = { "watchout.wav", "answer12.wav" },
}

local function prisonerVoice(record, kind)
	if not record or not IsValid(record.entity) then return end
	if cfg.PrisonerVoiceResponses == false then return end
	if CurTime() < (record.entity.mb_nextPrisonVoice or 0) then return end
	local lines = VOICE_LINES[kind] or VOICE_LINES.obey
	local model = string.lower(record.entity:GetModel() or "")
	if string.find(model, "droid", 1, true) or string.find(model, "robot", 1, true) then return end
	-- The stock citizen voice files are spoken English. Foreign-language
	-- prisoners use the translated/garbled dialogue channel instead so they
	-- never audibly contradict their assigned language.
	if choosePrisonerLanguage(record) ~= "basic" then return end
	local female = string.find(model, "female", 1, true)
	record.entity:EmitSound("vo/npc/" .. (female and "female01/" or "male01/")
		.. lines[math.random(1, #lines)], 68, math.random(96, 104), 0.7)
	record.entity.mb_nextPrisonVoice = CurTime() + 2.5
end

local baseSpawn = P.SpawnPrisonerEntity
function P.SpawnPrisonerEntity(record, pos, ang)
	normaliseRecord(record)
	local ent = baseSpawn(record, pos, ang)
	if IsValid(ent) then
		ent:SetMovementState("idle")
		ent:SetCommandPose(tostring(record.commandPose or ""))
		if ent.SetLanguageID then ent:SetLanguageID(record.languageID or "basic") end
		if ent.SetLanguageName then ent:SetLanguageName(P.LanguageName(record.languageID)) end
		if ent.SetSpeciesName then ent:SetSpeciesName(record.speciesName or "Human") end
		ent.mb_nextAmbientLanguageSpeech = CurTime()
			+ math.Rand(math.max(8, tonumber(cfg.LanguageSpeechMinimumDelay) or 38),
				math.max(12, tonumber(cfg.LanguageSpeechMaximumDelay) or 82))
		if record.civilianPackModel and not record.civilianPackAppearanceCaptured then
			timer.Simple(0, function()
				if not IsValid(ent) or record.entity ~= ent then return end
				record.model = ent:GetModel()
				record.skin = ent:GetSkin()
				record.bodygroups = {}
				for index = 0, math.max(0, ent:GetNumBodyGroups() - 1) do
					record.bodygroups[tostring(index)] = ent:GetBodygroup(index)
				end
				record.civilianPackAppearanceCaptured = true
				P.SaveState()
			end)
		end
	end
	return ent
end

local baseUpdateNetwork = P.UpdateNetwork
function P.UpdateNetwork(record)
	baseUpdateNetwork(record)
	local ent = record and record.entity
	if not IsValid(ent) then return end
	normaliseRecord(record)
	if ent.SetLanguageID then ent:SetLanguageID(record.languageID or "basic") end
	if ent.SetLanguageName then ent:SetLanguageName(P.LanguageName(record.languageID)) end
	if ent.SetSpeciesName then ent:SetSpeciesName(record.speciesName or "Human") end
end

local function cellZone(cellID)
	local cell = P.Cells and P.Cells[tostring(cellID or "")]
	local origin = cell and cell.markers and cell.markers.cell_origin
	return P.CleanID(origin and origin.data and origin.data.zone or "cellblock", "cellblock")
end

function P.CellZone(cellID)
	return cellZone(cellID)
end

local function hullClear(startPos, endPos, filter, brushOnly)
	if not isvector(startPos) or not isvector(endPos) then return false end
	local tr = util.TraceHull({
		start = startPos + Vector(0, 0, 4),
		endpos = endPos + Vector(0, 0, 4),
		mins = Vector(-14, -14, 0),
		maxs = Vector(14, 14, 70),
		filter = filter,
		mask = brushOnly and MASK_PLAYERSOLID_BRUSHONLY or MASK_PLAYERSOLID,
	})
	return not tr.StartSolid and not tr.Hit
end

function P.BuildPathGraph()
	local nodes, edges = {}, {}
	for _, marker in ipairs(P.GetMarkers and P.GetMarkers("path_node") or {}) do
		nodes[#nodes + 1] = marker
	end
	local maxDistance = math.max(160, tonumber(cfg.PathNodeLinkDistance) or 760)
	local vertical = math.max(48, tonumber(cfg.PathNodeVerticalTolerance) or 180)
	for index = 1, #nodes do edges[index] = {} end
	for a = 1, #nodes do
		for b = a + 1, #nodes do
			local first, second = nodes[a], nodes[b]
			if math.abs(first.pos.z - second.pos.z) <= vertical
			and first.pos:DistToSqr(second.pos) <= maxDistance * maxDistance
			and hullClear(first.pos, second.pos, nil, true) then
				local cost = first.pos:Distance(second.pos)
				edges[a][#edges[a] + 1] = { to = b, cost = cost }
				edges[b][#edges[b] + 1] = { to = a, cost = cost }
			end
		end
	end
	P.PathGraph = { nodes = nodes, edges = edges }
end

local baseRebuildLayout = P.RebuildLayout
function P.RebuildLayout()
	baseRebuildLayout()
	for id, cell in pairs(P.Cells or {}) do cell.zone = cellZone(id) end
	P.BuildPathGraph()
end

local function nearestGraphNode(pos, ent)
	local graph = P.PathGraph or {}
	local best, bestDistance
	local maximum = math.max(240, tonumber(cfg.PathNodeStartDistance) or 900)
	for index, marker in ipairs(graph.nodes or {}) do
		local distance = pos:DistToSqr(marker.pos)
		if distance <= maximum * maximum and (not bestDistance or distance < bestDistance)
		and hullClear(pos, marker.pos, ent, true) then
			best, bestDistance = index, distance
		end
	end
	if best then return best end
	for index, marker in ipairs(graph.nodes or {}) do
		local distance = pos:DistToSqr(marker.pos)
		if not bestDistance or distance < bestDistance then best, bestDistance = index, distance end
	end
	return best
end

local function graphRoute(ent, startPos, targetPos)
	if hullClear(startPos, targetPos, ent, false) then return { targetPos } end
	local graph = P.PathGraph or {}
	if #(graph.nodes or {}) == 0 then return { targetPos } end
	local startIndex = nearestGraphNode(startPos, ent)
	local goalIndex = nearestGraphNode(targetPos, ent)
	if not startIndex or not goalIndex then return { targetPos } end

	local open, openSet = { startIndex }, { [startIndex] = true }
	local cameFrom, gScore, fScore = {}, { [startIndex] = 0 }, {}
	fScore[startIndex] = graph.nodes[startIndex].pos:Distance(graph.nodes[goalIndex].pos)

	while #open > 0 do
		local bestAt = 1
		for index = 2, #open do
			if (fScore[open[index]] or math.huge) < (fScore[open[bestAt]] or math.huge) then
				bestAt = index
			end
		end
		local current = table.remove(open, bestAt)
		openSet[current] = nil
		if current == goalIndex then
			local reverse, cursor = { current }, current
			while cameFrom[cursor] do
				cursor = cameFrom[cursor]
				table.insert(reverse, 1, cursor)
			end
			local route = {}
			for _, nodeIndex in ipairs(reverse) do
				route[#route + 1] = graph.nodes[nodeIndex].pos
			end
			route[#route + 1] = targetPos
			return route
		end
		for _, edge in ipairs((graph.edges or {})[current] or {}) do
			local score = (gScore[current] or math.huge) + edge.cost
			if score < (gScore[edge.to] or math.huge) then
				cameFrom[edge.to] = current
				gScore[edge.to] = score
				fScore[edge.to] = score
					+ graph.nodes[edge.to].pos:Distance(graph.nodes[goalIndex].pos)
				if not openSet[edge.to] then
					open[#open + 1] = edge.to
					openSet[edge.to] = true
				end
			end
		end
	end
	return { targetPos }
end

local navmeshAvailable
local function hasNavmesh()
	if navmeshAvailable ~= nil then return navmeshAvailable end
	navmeshAvailable = false
	if navmesh and navmesh.GetAllNavAreas then
		local areas = navmesh.GetAllNavAreas()
		navmeshAvailable = istable(areas) and #areas > 0
	end
	return navmeshAvailable
end

local function resetNavigation(ent)
	if not IsValid(ent) then return end
	ent.mb_prisonPath = nil
	ent.mb_prisonRoute = nil
	ent.mb_prisonRouteIndex = nil
	ent.mb_prisonPathTarget = nil
	ent.mb_prisonNextRepath = 0
end

local function localAvoidance(ent, direction)
	if CurTime() < (ent.mb_prisonNextAvoidance or 0)
	and isvector(ent.mb_prisonAvoidanceDirection) then
		local cached = direction + ent.mb_prisonAvoidanceDirection
		cached.z = 0
		return cached:LengthSqr() > 0.001 and cached:GetNormalized() or direction
	end
	local radius = math.max(24, tonumber(cfg.LocalAvoidanceRadius) or 58)
	local repel = vector_origin
	for _, other in ipairs(ents.FindInSphere(ent:GetPos(), radius)) do
		if other ~= ent and IsValid(other)
		and (P.IsPrisonerEntity(other) or other:IsPlayer()) then
			local away = ent:GetPos() - other:GetPos()
			away.z = 0
			local distance = math.max(1, away:Length())
			if distance < radius then repel = repel + away:GetNormalized() * (1 - distance / radius) end
		end
	end
	ent.mb_prisonAvoidanceDirection = repel * 0.9
	ent.mb_prisonNextAvoidance = CurTime() + 0.12
	local result = direction + repel * 0.9
	result.z = 0
	return result:LengthSqr() > 0.001 and result:GetNormalized() or direction
end

local function steerAroundObstacle(ent, target)
	local pos = ent:GetPos()
	local delta = target - pos
	delta.z = 0
	if delta:LengthSqr() <= 1 then return target end
	local direction = localAvoidance(ent, delta:GetNormalized())
	local lookAhead = math.min(72, math.max(34, delta:Length()))
	local straight = pos + direction * lookAhead
	if hullClear(pos, straight, ent, false) then return straight end
	local yaw = direction:Angle().y
	local best, bestFraction
	for _, offset in ipairs({ -70, 70, -110, 110, 180 }) do
		local candidateDirection = Angle(0, yaw + offset, 0):Forward()
		local candidate = pos + candidateDirection * lookAhead
		local tr = util.TraceHull({
			start = pos + Vector(0, 0, 4),
			endpos = candidate + Vector(0, 0, 4),
			mins = Vector(-14, -14, 0),
			maxs = Vector(14, 14, 70),
			filter = ent,
			mask = MASK_PLAYERSOLID,
		})
		if not tr.StartSolid and (not bestFraction or tr.Fraction > bestFraction) then
			best, bestFraction = candidate, tr.Fraction
		end
	end
	return best or pos
end

local function buildNavigation(ent, target)
	resetNavigation(ent)
	ent.mb_prisonPathTarget = Vector(target.x, target.y, target.z)
	ent.mb_prisonNextRepath = CurTime() + math.max(0.25, tonumber(cfg.MovementRepathSeconds) or 0.8)
	if hasNavmesh() and Path then
		local path = Path("Follow")
		path:SetMinLookAheadDistance(math.max(60,
			tonumber(cfg.MovementLookAheadDistance) or 135))
		path:SetGoalTolerance(math.max(10,
			tonumber(cfg.MovementGoalTolerance) or 20))
		path:Compute(ent, target)
		if path:IsValid() then
			ent.mb_prisonPath = path
			ent.mb_prisonNavigationMode = "navmesh"
			return
		end
	end
	ent.mb_prisonRoute = graphRoute(ent, ent:GetPos(), target)
	ent.mb_prisonRouteIndex = 1
	ent.mb_prisonNavigationMode = #(P.PathGraph.nodes or {}) > 0 and "nodes" or "steering"
end

local function stopMovement(ent, pose)
	if ent.loco then
		ent.loco:SetDesiredSpeed(0)
	end
	ent:SetMovementState("idle")
	ent:SetCommandPose(tostring(pose or ""))
	if ent.SelectPrisonActivity then ent:SelectPrisonActivity(pose ~= "" and pose or "idle") end
end

local function hiddenFromPlayers(pos)
	local radius = math.max(250, tonumber(cfg.SafeRelocationHiddenRadius) or 650)
	for _, ply in ipairs(player.GetAll()) do
		if ply:Alive() then
			local distance = ply:EyePos():DistToSqr(pos)
			if distance <= radius * radius then return false end
			if distance <= 2200 * 2200 then
				local tr = util.TraceLine({
					start = ply:EyePos(),
					endpos = pos + Vector(0, 0, 42),
					filter = { ply },
					mask = MASK_VISIBLE,
				})
				if not tr.Hit then return false end
			end
		end
	end
	return true
end

local function safeGroundPosition(pos, ent)
	local down = util.TraceHull({
		start = pos + Vector(0, 0, 72),
		endpos = pos - Vector(0, 0, 256),
		mins = Vector(-14, -14, 0),
		maxs = Vector(14, 14, 70),
		filter = ent,
		mask = MASK_PLAYERSOLID,
	})
	if down.StartSolid or not down.Hit then return nil end
	local candidate = down.HitPos + Vector(0, 0, 2)
	local occupied = util.TraceHull({
		start = candidate,
		endpos = candidate,
		mins = Vector(-14, -14, 0),
		maxs = Vector(14, 14, 70),
		filter = ent,
		mask = MASK_PLAYERSOLID,
	})
	return not occupied.StartSolid and candidate or nil
end

local function attemptSafeRecovery(ent, target)
	if not hiddenFromPlayers(ent:GetPos()) or not hiddenFromPlayers(target) then return false end
	local position = safeGroundPosition(target, ent)
	if not position then return false end
	ent:SetPos(position)
	if ent.loco then ent.loco:ClearStuck() end
	resetNavigation(ent)
	ent.mb_prisonStuckAttempts = 0
	return true
end

function P.HandlePrisonerStuck(ent)
	if not IsValid(ent) then return end
	ent.mb_prisonStuckAttempts = (ent.mb_prisonStuckAttempts or 0) + 1
	resetNavigation(ent)
	if ent.loco then ent.loco:ClearStuck() end
	ent:SetMovementState("repathing")
end

local function checkProgress(ent, target)
	local now = CurTime()
	if now < (ent.mb_prisonNextProgressCheck or 0) then return end
	local previous = ent.mb_prisonProgressPos or ent:GetPos()
	local progress = previous:Distance(ent:GetPos())
	ent.mb_prisonProgressPos = ent:GetPos()
	ent.mb_prisonNextProgressCheck = now + math.max(0.5, tonumber(cfg.StuckCheckSeconds) or 1.25)
	if ent:GetPos():Distance(target) <= (cfg.MovementArrivalDistance or 28) * 1.5 then
		ent.mb_prisonStuckAttempts = 0
		return
	end
	if progress < math.max(4, tonumber(cfg.StuckMinimumProgress) or 16) then
		ent.mb_prisonStuckAttempts = (ent.mb_prisonStuckAttempts or 0) + 1
		resetNavigation(ent)
		if ent.loco then ent.loco:ClearStuck() end
		if ent.mb_prisonStuckAttempts >= 2 then
			local delta = target - ent:GetPos()
			delta.z = 0
			local forward = delta:LengthSqr() > 1 and delta:GetNormalized() or ent:GetForward()
			local right = forward:Angle():Right()
			local side = ent:EntIndex() % 2 == 0 and 1 or -1
			local distance = math.max(30, tonumber(cfg.MovementNudgeDistance) or 56)
			local candidate = safeGroundPosition(ent:GetPos() + right * distance * side
				+ forward * distance * 0.35, ent)
			if candidate and hullClear(ent:GetPos(), candidate, ent, false) then
				ent.mb_prisonNudgeTarget = candidate
				ent.mb_prisonNudgeUntil = now + 0.7
			end
		end
		if ent.mb_prisonStuckAttempts >= 4 then attemptSafeRecovery(ent, target) end
	else
		ent.mb_prisonStuckAttempts = 0
	end
end

local function routeDoorClear(marker)
	local radius = math.max(64, tonumber(cfg.DoorClearDistance) or 105)
	for _, value in ipairs(ents.FindInSphere(marker.pos, radius)) do
		if IsValid(value) and (value:IsPlayer() or P.IsPrisonerEntity(value)) then return false end
	end
	return true
end

local function scheduleRouteDoorClose(marker)
	if not marker then return end
	local timerName = "MilBase.Prison.RouteDoor." .. tostring(marker.id or 0)
	timer.Create(timerName, math.max(0.5, tonumber(cfg.RouteDoorCloseSeconds) or 3), 0, function()
		if not P._layoutLoaded then timer.Remove(timerName) return end
		if not routeDoorClear(marker) then return end
		local door = P.ResolveLinkedEntity and P.ResolveLinkedEntity(marker)
		if IsValid(door) then
			door:Fire("Close", "", 0)
			if cfg.RouteDoorsRelock ~= false then door:Fire("Lock", "", 0.8) end
		end
		timer.Remove(timerName)
	end)
end

local function openNearbyRouteDoor(ent)
	local approach = math.max(80, tonumber(cfg.DoorApproachDistance) or 190)
	local nearest, nearestDistance
	for _, marker in ipairs(P.GetMarkers("route_door")) do
		local distance = ent:GetPos():DistToSqr(marker.pos)
		if distance <= approach * approach and (not nearestDistance or distance < nearestDistance) then
			nearest, nearestDistance = marker, distance
		end
	end
	if not nearest then return false end
	local key = tostring(nearest.id or 0)
	ent.mb_prisonDoorPass = ent.mb_prisonDoorPass or {}
	local firstOpen = CurTime() >= (ent.mb_prisonDoorPass[key] or 0)
	local door = P.ResolveLinkedEntity and P.ResolveLinkedEntity(nearest)
	local runtime = P.RouteDoorRuntime[key] or {}
	P.RouteDoorRuntime[key] = runtime
	if IsValid(door) and CurTime() >= (runtime.nextOpenAt or 0) then
		door:Fire("Unlock", "", 0)
		door:Fire("Open", "", 0.05)
		runtime.nextOpenAt = CurTime() + 0.5
	end
	if IsValid(door) then scheduleRouteDoorClose(nearest) end
	if firstOpen then
		ent.mb_prisonDoorPass[key] = CurTime() + math.max(1.5,
			(tonumber(cfg.RouteDoorCloseSeconds) or 3) * 0.75)
		ent.mb_prisonDoorWaitUntil = CurTime()
			+ math.max(0.1, tonumber(cfg.DoorOpenWaitSeconds) or 0.45)
		resetNavigation(ent)
	end
	return IsValid(door) and firstOpen
end

function P.MovePrisoner(ent, target, speed, activity, dynamicTarget)
	if not IsValid(ent) or not isvector(target) then return true end
	if CurTime() < (ent.mb_prisonNudgeUntil or 0)
	and isvector(ent.mb_prisonNudgeTarget) then
		if ent.loco then
			ent.loco:SetDesiredSpeed(math.max(30, tonumber(cfg.MovementMinimumSpeed) or 72))
			ent.loco:Approach(ent.mb_prisonNudgeTarget, 1)
			ent.loco:FaceTowards(ent.mb_prisonNudgeTarget)
		end
		ent:SetMovementState("unsticking")
		return false
	end
	ent.mb_prisonNudgeTarget = nil
	if CurTime() < (ent.mb_prisonDoorWaitUntil or 0) then
		stopMovement(ent, "")
		ent:SetMovementState("waiting_for_door")
		return false
	end
	local arrival = dynamicTarget
		and math.max(8, tonumber(cfg.MovementDynamicArrivalDistance) or 14)
		or math.max(12, tonumber(cfg.MovementArrivalDistance) or 24)
	if ent:GetPos():Distance(target) <= arrival then
		resetNavigation(ent)
		if not dynamicTarget then stopMovement(ent, "") end
		return true
	end

	local targetRepathDistance = math.max(20,
		tonumber(cfg.MovementTargetRepathDistance) or 40)
	local movedTarget = not isvector(ent.mb_prisonPathTarget)
		or ent.mb_prisonPathTarget:DistToSqr(target)
			> targetRepathDistance ^ 2
	local dynamicRefresh = dynamicTarget
		and CurTime() >= (ent.mb_prisonNextRepath or 0)
		and isvector(ent.mb_prisonPathTarget)
		and ent.mb_prisonPathTarget:DistToSqr(target) > (targetRepathDistance * 0.5) ^ 2
	if movedTarget or dynamicRefresh
	or (ent.mb_prisonPath and not ent.mb_prisonPath:IsValid()) then
		buildNavigation(ent, target)
	end
	if openNearbyRouteDoor(ent) then
		stopMovement(ent, "")
		ent:SetMovementState("opening_door")
		return false
	end

	speed = math.max(20, tonumber(speed) or cfg.PrisonerWalkSpeed or 165)
	local remaining = ent:GetPos():Distance(target)
	local slowRadius = math.max(arrival * 2, tonumber(cfg.MovementSlowRadius) or 92)
	-- Breadcrumbs and moving guards are intermediate targets. Applying final
	-- destination braking to them made escorts slow down and restart every few
	-- metres, so only fixed destinations use the arrival easing curve.
	if not dynamicTarget and remaining < slowRadius then
		local minimum = math.max(20, tonumber(cfg.MovementMinimumSpeed) or 72)
		speed = math.max(minimum, speed * math.Clamp(remaining / slowRadius, 0.35, 1))
	end
	local crowdRadius = math.max(28, tonumber(cfg.LocalAvoidanceRadius) or 58)
	for _, other in ipairs(ents.FindInSphere(ent:GetPos(), crowdRadius)) do
		if other ~= ent and P.IsPrisonerEntity(other) then
			speed = math.max(tonumber(cfg.MovementMinimumSpeed) or 72, speed * 0.72)
			break
		end
	end
	if ent.loco then
		ent.loco:SetDesiredSpeed(speed)
		ent.loco:SetAcceleration(cfg.PrisonerAcceleration or 850)
		ent.loco:SetDeceleration(cfg.PrisonerDeceleration or 680)
	end
	ent:SetMovementState(ent.mb_prisonNavigationMode or "moving")
	ent:SetCommandPose("")
	ent:SetNWVector("mb_prison_target", target)
	if ent.SelectPrisonActivity then
		ent:SelectPrisonActivity(activity or (speed > (cfg.PrisonerWalkSpeed or 165) + 15 and "run" or "walk"))
	end

	if ent.mb_prisonPath and ent.mb_prisonPath:IsValid() then
		ent.mb_prisonPath:Update(ent)
	else
		local route = ent.mb_prisonRoute or { target }
		local index = math.max(1, tonumber(ent.mb_prisonRouteIndex) or 1)
		while route[index] and ent:GetPos():Distance(route[index]) <= arrival * 1.25 do
			index = index + 1
		end
		ent.mb_prisonRouteIndex = index
		local waypoint = route[index] or target
		local steering = steerAroundObstacle(ent, waypoint)
		if ent.loco then
			ent.loco:Approach(steering, 1)
			ent.loco:FaceTowards(steering)
		end
	end
	checkProgress(ent, target)
	return false
end

local function activitySlot(marker, record, total)
	if not marker or not isvector(marker.pos) then return marker end
	local hash = 0
	for index = 1, #tostring(record.id or "") do
		hash = (hash * 33 + string.byte(tostring(record.id), index)) % 2147483647
	end
	local columns = math.max(2, math.floor(tonumber(cfg.ActivitySlotColumns) or 4))
	local count = math.max(columns, tonumber(total) or columns * 3)
	local slot
	for index, prisoner in ipairs(P.ActivePrisoners()) do
		if prisoner.id == record.id then slot = index - 1 break end
	end
	slot = slot or (hash % count)
	local row = math.floor(slot / columns)
	local column = slot % columns
	local spacing = math.max(30, tonumber(cfg.ActivitySlotSpacing) or 54)
	local right = (column - (columns - 1) * 0.5) * spacing
	local forward = row * spacing
	local candidate = marker.pos + marker.ang:Right() * right + marker.ang:Forward() * forward
	local grounded = safeGroundPosition(candidate)
	if not grounded or not hullClear(marker.pos, grounded, nil, true) then
		grounded = marker.pos
	end
	return {
		pos = grounded,
		ang = marker.ang,
		kind = marker.kind,
		group = marker.group,
	}
end

local function assignedCellMarker(record)
	local cell = P.Cells and P.Cells[record.cellID or ""]
	return cell and P.CellMarkerForRecord and P.CellMarkerForRecord(record, cell) or nil
end

local function setRecordTarget(record, marker, status, pose)
	if not record then return end
	if marker and isvector(marker.pos) then
		record.targetPos = marker.pos
		record.targetAng = marker.ang or angle_zero
	end
	if status then record.status = status end
	record.commandPose = tostring(pose or "")
	if P.UpdateNetwork then P.UpdateNetwork(record) end
end

local function insideCellVolume(pos, cell)
	local a = cell and cell.markers and cell.markers.cell_corner_a
	local b = cell and cell.markers and cell.markers.cell_corner_b
	if not a or not b then return false end
	local minimum = Vector(math.min(a.pos.x, b.pos.x), math.min(a.pos.y, b.pos.y),
		math.min(a.pos.z, b.pos.z) - 12)
	local maximum = Vector(math.max(a.pos.x, b.pos.x), math.max(a.pos.y, b.pos.y),
		math.max(a.pos.z, b.pos.z) + 84)
	return pos.x >= minimum.x and pos.x <= maximum.x
		and pos.y >= minimum.y and pos.y <= maximum.y
		and pos.z >= minimum.z and pos.z <= maximum.z
end

local function scheduleDoorClose(cellID, lock)
	if tostring(cellID or "") == "" then return end
	local timerName = "MilBase.Prison.DoorClear." .. P.CleanID(cellID)
	timer.Create(timerName, 0.5, 20, function()
		local cell = P.Cells and P.Cells[cellID]
		local doorMarker = cell and cell.markers and cell.markers.cell_door
		if not doorMarker then timer.Remove(timerName) return end
		local clear = true
		local radius = math.max(64, tonumber(cfg.DoorClearDistance) or 105)
		for _, prisoner in ipairs(P.ActivePrisoners()) do
			if IsValid(prisoner.entity)
			and prisoner.entity:GetPos():DistToSqr(doorMarker.pos) <= radius * radius
			and not insideCellVolume(prisoner.entity:GetPos(), cell) then
				clear = false
				break
			end
		end
		if clear then
			P.SetCellDoor(cellID, false, lock ~= false)
			timer.Remove(timerName)
		end
	end)
end
P.ScheduleCellDoorClose = scheduleDoorClose

local function manageCellDoor(record, ent, target)
	if not record.cellID or record.cellID == "" then return end
	local cell = P.Cells and P.Cells[record.cellID]
	local door = cell and cell.markers and cell.markers.cell_door
	if not door then return end
	local inside = insideCellVolume(ent:GetPos(), cell)
	local targetInside = isvector(target) and insideCellVolume(target, cell)
	local crossing = inside ~= targetInside
	local distance = ent:GetPos():DistToSqr(door.pos)
	local approach = math.max(80, tonumber(cfg.DoorApproachDistance) or 190)
	if crossing and distance <= approach ^ 2 then
		local firstOpen = ent.mb_prisonCellDoor ~= record.cellID
		if firstOpen or CurTime() >= (ent.mb_prisonNextCellDoorOpen or 0) then
			P.SetCellDoor(record.cellID, true, false)
			ent.mb_prisonNextCellDoorOpen = CurTime() + 0.5
		end
		ent.mb_prisonCellDoor = record.cellID
		ent.mb_prisonCellDoorTargetInside = targetInside
		if firstOpen then
			ent.mb_prisonDoorWaitUntil = CurTime()
				+ math.max(0.1, tonumber(cfg.DoorOpenWaitSeconds) or 0.45)
			resetNavigation(ent)
		end
	elseif ent.mb_prisonCellDoor == record.cellID
	and inside == ent.mb_prisonCellDoorTargetInside then
		scheduleDoorClose(record.cellID, true)
		ent.mb_prisonCellDoor = nil
		ent.mb_prisonCellDoorTargetInside = nil
	end
end

local function resolveEscort(id)
	id = tostring(id or "")
	if id == "" then return nil end
	if player.GetBySteamID64 then
		local ply = player.GetBySteamID64(id)
		if IsValid(ply) then return ply end
	end
	for _, ply in ipairs(player.GetAll()) do
		if ply:SteamID64() == id then return ply end
	end
end

local function appendEscortBreadcrumb(ent, escort)
	ent.mb_escortTrail = ent.mb_escortTrail or { ent:GetPos() }
	local trail = ent.mb_escortTrail
	local position = escort:GetPos()
	local spacing = math.max(28, tonumber(cfg.EscortBreadcrumbSpacing) or 52)
	if not trail[#trail]
	or trail[#trail]:DistToSqr(position)
		>= spacing ^ 2 then
		trail[#trail + 1] = Vector(position.x, position.y, position.z)
	end
	while #trail > 48 do table.remove(trail, 1) end
	local reach = math.Clamp(tonumber(cfg.EscortBreadcrumbReachDistance) or 28,
		12, spacing * 0.8)
	while #trail > 1 and ent:GetPos():DistToSqr(trail[1])
		<= reach ^ 2 do
		table.remove(trail, 1)
	end
end

local function releaseEscort(record, status)
	record.escortSteamID = ""
	record.escortAssistSteamID = ""
	record.status = status or (record.cellID ~= "" and "incarcerated" or "awaiting_escort")
	if IsValid(record.entity) then
		record.entity.mb_escortTrail = nil
		record.entity.mb_escortHolding = nil
		resetNavigation(record.entity)
	end
	if P.UpdateNetwork then P.UpdateNetwork(record) end
end

local function nearestGuard(pos)
	local target, best
	for _, ply in ipairs(player.GetAll()) do
		if ply:Alive() and P.CanUse(ply) then
			local distance = pos:DistToSqr(ply:GetPos())
			if not best or distance < best then target, best = ply, distance end
		end
	end
	return target, best
end

local function takeoverState()
	P.State.takeover = istable(P.State.takeover) and P.State.takeover or {}
	local state = P.State.takeover
	state.active = state.active == true
	state.controlled = state.controlled == true
	state.stage = tostring(state.stage or "idle")
	state.currentIndex = math.max(1, tonumber(state.currentIndex) or 1)
	state.startedAt = tonumber(state.startedAt) or 0
	state.progress = math.max(0, tonumber(state.progress) or 0)
	state.captured = istable(state.captured) and state.captured or {}
	state.armed = state.armed == true
	state.systemsThreatened = state.systemsThreatened == true
	state.commsCaptured = state.commsCaptured == true
	return state
end

local function takeoverObjectives()
	local rows, missing = {}, {}
	for index, definition in ipairs(TAKEOVER_OBJECTIVES) do
		local marker = P.GetMarker(definition.kind)
		rows[index] = {
			index = index,
			kind = definition.kind,
			label = definition.label,
			role = definition.role,
			marker = marker,
		}
		if not marker then missing[#missing + 1] = definition.label end
	end
	return rows, missing
end

function P.TakeoverObjectives()
	return takeoverObjectives()
end

local function currentTakeoverObjective()
	local state = takeoverState()
	local rows = takeoverObjectives()
	return rows[state.currentIndex], state
end

local function riotersNearPosition(pos, radius)
	local count = 0
	if not isvector(pos) then return count end
	for _, record in ipairs(P.ActivePrisoners()) do
		if record.status == "rioting" and IsValid(record.entity)
		and record.entity:GetPos():DistToSqr(pos) <= radius * radius then
			count = count + 1
		end
	end
	return count
end

local function guardsNearPosition(pos, radius)
	local count = 0
	if not isvector(pos) then return count end
	for _, ply in ipairs(player.GetAll()) do
		if ply:Alive() and P.CanUse(ply)
		and ply:GetPos():DistToSqr(pos) <= radius * radius then count = count + 1 end
	end
	return count
end

local function activeRioters()
	local rows = {}
	for _, record in ipairs(P.ActivePrisoners()) do
		if record.status == "rioting" then rows[#rows + 1] = record end
	end
	return rows
end

local function recomputeTakeoverBenefits(state)
	state.armed = state.captured.takeover_armory == true
	state.systemsThreatened = state.captured.takeover_engineering == true
	state.commsCaptured = state.captured.takeover_comms == true
end

function P.StartShipTakeover(reason, force)
	local state = takeoverState()
	if state.active then return true, "The ship takeover is already in progress." end
	local objectives, missing = takeoverObjectives()
	if #missing > 0 then
		return false, "Takeover setup is missing: " .. table.concat(missing, ", ") .. "."
	end
	local rioters = activeRioters()
	local required = math.max(1, tonumber(cfg.TakeoverMinimumRioters) or 3)
	if not force and #rioters < required then
		return false, "The riot has not gathered enough prisoners for a ship takeover."
	end
	if #rioters == 0 then return false, "There are no active rioters." end

	state.active = true
	state.controlled = false
	state.stage = objectives[1].kind
	state.currentIndex = 1
	state.startedAt = unix()
	state.progress = 0
	state.captured = {}
	state.armed = false
	state.systemsThreatened = false
	state.commsCaptured = false
	local roles = { "assault", "raider", "saboteur", "seizer", "defender" }
	for index, record in ipairs(rioters) do
		record.riotRole = trait(record, "riot_leader") and "leader"
			or roles[(index - 1) % #roles + 1]
		record.riotActionAt = CurTime()
		record.targetPos = nil
		record.targetAng = nil
		if IsValid(record.entity) then resetNavigation(record.entity) end
	end
	P.State.alert = "riot"
	if P.ApplySchedule then
		P.ApplySchedule("riot_lockdown", nil, true, cfg.LockdownDefaultSeconds or 600, true)
	end
	P.AddIncident("takeover", "Rioters began an organised assault on the ship"
		.. (reason and reason ~= "" and (" (" .. tostring(reason) .. ")") or "")
		.. ". First objective: ARMORY.", nil, nil, 5)
	P.SetAlarm(true, "RIOTERS ATTEMPTING SHIP TAKEOVER: ARMORY", "critical", "facility")
	if P.NotifyGuards then
		P.NotifyGuards("SHIP TAKEOVER: rioters are advancing on the ARMORY.", "warn")
	end
	P.SaveState()
	return true, "Ship takeover started. First objective: ARMORY."
end

local function takeoverTarget(record)
	local objective, state = currentTakeoverObjective()
	if not state.active or not objective or not objective.marker then return nil, objective, state end
	if record.riotRole == "defender" and state.currentIndex > 1 then
		local objectives = takeoverObjectives()
		local previous = objectives[state.currentIndex - 1]
		if previous and previous.marker and state.captured[previous.kind] then
			return activitySlot(previous.marker, record, 10), previous, state
		end
	end
	return activitySlot(objective.marker, record, 10), objective, state
end

local baseRequestTransfer = P.RequestTransfer
function P.RequestTransfer(ply, destination, ids)
	if takeoverState().commsCaptured then
		return false, "Prison transfer communications are under riot control"
	end
	return baseRequestTransfer(ply, destination, ids)
end

local baseBeginTransferBoarding = P.BeginTransferBoarding
function P.BeginTransferBoarding(ply, transferID)
	if takeoverState().commsCaptured then
		return false, "Transfer boarding is suspended while communications are under riot control"
	end
	return baseBeginTransferBoarding(ply, transferID)
end

local baseDispatchTransfer = P.DispatchTransfer
function P.DispatchTransfer(ply, transferID)
	if takeoverState().commsCaptured then
		return false, "Transfer launch control is unavailable while communications are under riot control"
	end
	return baseDispatchTransfer(ply, transferID)
end

local function finishArrival(record, ent)
	local targetAng = record.targetAng
	record.targetPos = nil
	record.targetAng = nil
	record.lastKnownZone = record.cellID ~= "" and cellZone(record.cellID)
		or tostring(record.activityZone or "facility")
	if isangle(targetAng) then
		ent.mb_prisonFinalYaw = targetAng.y
	end
	if record.status == "boarding" then
		record.boarded = true
		ent:SetNoDraw(true)
		ent:SetSolid(SOLID_NONE)
	elseif record.status == "incarcerated" or record.status == "isolation" then
		scheduleDoorClose(record.cellID, true)
		record.commandPose = P.State.schedule == "lockdown" and "sleep"
			or P.State.schedule == "meal" and "sit" or ""
	elseif record.status == "medical" then
		record.commandPose = "sit"
	elseif record.status == "social" and math.random(1, 3) == 1 then
		record.commandPose = "sit"
	elseif record.status == "kneeling" then
		record.commandPose = "kneel"
	elseif record.status == "facing_wall" then
		record.commandPose = "wall"
	end
	stopMovement(ent, record.commandPose or "")
	P.SaveState()
end

function P.UpdatePrisonerEntity(ent, dt)
	local record = IsValid(ent) and recordFor(ent) or nil
	if not record then return end
	normaliseRecord(record)
	record.entity = ent
	local now = CurTime()
	local movingState = record.status == "escorting" or record.status == "escort_waiting"
		or record.status == "rioting"
		or isvector(record.targetPos)
	if not movingState and now < (ent.mb_prisonNextIdleThink or 0) then return end
	if not movingState then ent.mb_prisonNextIdleThink = now + 0.35 end
	local target, speed, activity, dynamicTarget

	if now < (ent.mb_cinematicConversationUntil or 0) then
		stopMovement(ent, record.restraintLevel > 0 and "restrained" or "")
	elseif record.status == "escort_waiting" then
		local escort = resolveEscort(record.escortSteamID)
		local assistant = resolveEscort(record.escortAssistSteamID)
		if not IsValid(escort) or not escort:Alive() then
			releaseEscort(record, "awaiting_escort")
		elseif IsValid(assistant) and assistant:Alive()
		and assistant:GetPos():DistToSqr(ent:GetPos())
			<= math.max(160, tonumber(cfg.EscortAssistDistance) or 520) ^ 2 then
			record.status = "escorting"
			if P.UpdateNetwork then P.UpdateNetwork(record) end
		else
			stopMovement(ent, "restrained")
		end
	elseif record.status == "escorting" then
		dynamicTarget = true
		local escort = resolveEscort(record.escortSteamID)
		if not IsValid(escort) or not escort:Alive() then
			local transfer = P.State.transfers and P.State.transfers[tostring(record.transfer or "")]
			releaseEscort(record, transfer and (transfer.status == "pickup_landed"
				or transfer.status == "boarding") and "transfer_ready"
				or (record.cellID ~= "" and "holding" or "awaiting_escort"))
			P.SaveState()
			return
		end
		if record.risk == "critical" and cfg.RequireTwoGuardsForCritical ~= false then
			local assistant = resolveEscort(record.escortAssistSteamID)
			if not IsValid(assistant) or not assistant:Alive()
			or assistant:GetPos():DistToSqr(ent:GetPos())
				> math.max(160, tonumber(cfg.EscortAssistDistance) or 520) ^ 2 then
				record.status = "escort_waiting"
				stopMovement(ent, "restrained")
				if CurTime() >= (ent.mb_nextEscortAssistNotice or 0) then
					MilBase.Notify(escort, "Critical-risk escort paused: the assisting guard is out of position.", "warn")
					ent.mb_nextEscortAssistNotice = CurTime() + 4
				end
				if P.UpdateNetwork then P.UpdateNetwork(record) end
				P.SaveState()
				return
			end
		end
		if P.TryBoardTransfer and P.TryBoardTransfer(record, escort) then return end
		appendEscortBreadcrumb(ent, escort)
		local distance = ent:GetPos():Distance(escort:GetPos())
		local trail = ent.mb_escortTrail or {}
		local followingTrail = #trail > 1
		local escortTarget = followingTrail and trail[1]
			or escort:GetPos() - escort:GetForward() * (cfg.EscortFollowDistance or 88)
		manageCellDoor(record, ent, escortTarget)
		local escortVelocity = escort:GetVelocity()
		escortVelocity.z = 0
		local escortSpeed = escortVelocity:Length()
		local escortMoving = escortSpeed > 35
		local stopDistance = math.max(48, tonumber(cfg.EscortStopDistance) or 76)
		local resumeDistance = math.max(stopDistance + 20,
			tonumber(cfg.EscortResumeDistance) or 120)
		local followPointReached = not followingTrail
			and ent:GetPos():DistToSqr(escortTarget)
				<= math.max(18, (tonumber(cfg.MovementDynamicArrivalDistance) or 14) + 6) ^ 2
		if followingTrail or escortMoving then
			ent.mb_escortHolding = false
		elseif followPointReached or distance <= stopDistance then
			ent.mb_escortHolding = true
		elseif distance >= resumeDistance then
			ent.mb_escortHolding = false
		end
		if ent.mb_escortHolding then
			stopMovement(ent, "restrained")
		else
			target = escortTarget
			local walkSpeed = math.max(100, tonumber(cfg.PrisonerWalkSpeed) or 165)
			local runSpeed = math.max(walkSpeed + 30, tonumber(cfg.PrisonerRunSpeed) or 265)
			local catchUpDistance = math.max(220, tonumber(cfg.EscortCatchUpDistance) or 340)
			if distance >= catchUpDistance then
				speed = math.max(tonumber(cfg.EscortCatchUpSpeed) or 310, escortSpeed + 40)
			elseif distance >= math.max(resumeDistance + 20,
				tonumber(cfg.EscortJogDistance) or 185) then
				speed = math.max(runSpeed, escortSpeed + 25)
			else
				speed = math.max(walkSpeed, math.min(runSpeed, escortSpeed + 18))
			end
			speed = math.min(math.max(runSpeed, tonumber(cfg.EscortMaximumSpeed) or 340), speed)
			activity = speed >= walkSpeed + 45 and "run" or "walk"
		end
		if distance > (cfg.EscortBreakDistance or 850) then
			ent.mb_prisonFarSince = ent.mb_prisonFarSince or now
			if now - ent.mb_prisonFarSince >= (cfg.StuckRecoverySeconds or 7)
			and attemptSafeRecovery(ent, target or escort:GetPos()) then
				P.AddIncident("movement", record.name
					.. " was safely recovered to an escort route after becoming stuck.",
					record, nil, 1)
				ent.mb_prisonFarSince = nil
			end
		else
			ent.mb_prisonFarSince = nil
		end
	elseif record.status == "rioting" then
		dynamicTarget = true
		if record.riotRole == "" then record.riotRole = "assault" end
		if not (P.State.alarm and P.State.alarm.active)
		or P.State.alarm.level ~= "critical" then
			P.SetAlarm(true, "Prison disturbance involving " .. record.name, "critical",
				record.cellID ~= "" and cellZone(record.cellID) or "facility")
		end
		local objectiveMarker, objective, takeover = takeoverTarget(record)
		local guard, distance = nearestGuard(ent:GetPos())
		local contestRadius = math.max(100, tonumber(cfg.TakeoverGuardContestRadius) or 240)
		local guardAtObjective = IsValid(guard) and objectiveMarker
			and guard:GetPos():DistToSqr(objectiveMarker.pos) <= contestRadius * contestRadius
		local immediateThreat = IsValid(guard) and distance <= 150 ^ 2
		if IsValid(guard) and (guardAtObjective or immediateThreat) then
			if distance <= 75 ^ 2 and now >= (record.nextMeleeAt or 0) then
				record.nextMeleeAt = now + (cfg.PrisonerMeleeCooldown or 1.1)
				stopMovement(ent, "")
				if ent.SelectPrisonActivity then ent:SelectPrisonActivity("attack", true) end
				local damage = (cfg.PrisonerMeleeDamage or 8)
					* (takeover and takeover.armed
						and (cfg.TakeoverArmedDamageMultiplier or 1.6) or 1)
				local dmg = DamageInfo()
				dmg:SetDamage(damage)
				dmg:SetAttacker(ent)
				dmg:SetInflictor(ent)
				dmg:SetDamageType(DMG_CLUB)
				guard:TakeDamageInfo(dmg)
			else
				target, speed, activity = guard:GetPos(), cfg.PrisonerRunSpeed or 132, "run"
			end
		elseif objectiveMarker then
			if ent:GetPos():Distance(objectiveMarker.pos)
				> math.max(32, tonumber(cfg.MovementArrivalDistance) or 28) then
				target, speed, activity = objectiveMarker.pos, cfg.PrisonerRunSpeed or 132, "run"
			else
				stopMovement(ent, objective and objective.kind == "takeover_bridge" and "surrender" or "")
			end
		else
			local marker = P.GetMarker("guard_control") or P.GetMarker("riot_response")
				or P.GetMarker("social")
			if marker and ent:GetPos():Distance(marker.pos) > 55 then
				target, speed, activity = marker.pos, cfg.PrisonerRunSpeed or 132, "run"
			elseif IsValid(guard) then
				target, speed, activity = guard:GetPos(), cfg.PrisonerRunSpeed or 132, "run"
			else
				stopMovement(ent, "")
			end
		end
	elseif isvector(record.targetPos) then
		target = record.targetPos
		speed = record.movementSpeed or cfg.PrisonerWalkSpeed or 82
		manageCellDoor(record, ent, target)
	elseif record.status == "kneeling" then
		stopMovement(ent, "kneel")
	elseif record.status == "facing_wall" then
		stopMovement(ent, "wall")
	elseif record.status == "holding" then
		stopMovement(ent, record.commandPose or "restrained")
	else
		local sleepDistance = math.max(500, tonumber(cfg.AISleepDistance) or 2200)
		local awake = false
		for _, ply in ipairs(player.GetAll()) do
			if ply:GetPos():DistToSqr(ent:GetPos()) <= sleepDistance * sleepDistance then awake = true break end
		end
		if awake or now >= (ent.mb_prisonNextIdleRefresh or 0) then
			stopMovement(ent, record.commandPose
				or ((record.status == "incarcerated" and P.State.schedule == "lockdown") and "sleep" or ""))
			ent.mb_prisonNextIdleRefresh = now + (awake and 1 or 4)
		end
	end

	if target and P.MovePrisoner(ent, target, speed, activity, dynamicTarget) then
		if isvector(record.targetPos) and record.targetPos:DistToSqr(target) < 4 then
			finishArrival(record, ent)
		end
	end
	if not target and ent.mb_prisonFinalYaw then
		local angles = ent:GetAngles()
		angles.y = math.ApproachAngle(angles.y, ent.mb_prisonFinalYaw,
			(cfg.PrisonerTurnRate or 220) * math.max(0.01, dt or 0.05))
		ent:SetAngles(Angle(0, angles.y, 0))
		if math.abs(math.AngleDifference(angles.y, ent.mb_prisonFinalYaw)) < 1 then
			ent.mb_prisonFinalYaw = nil
		end
	end
	if now >= (ent.mb_prisonNextNetwork or 0) then
		ent.mb_prisonNextNetwork = now + 0.25
		if P.UpdateNetwork then P.UpdateNetwork(record) end
		ent:SetCommandPose(tostring(record.commandPose or ""))
	end
end

local function guardsNear(record, radius)
	if not record or not IsValid(record.entity) then return 0 end
	local count = 0
	radius = radius or 360
	for _, ply in ipairs(player.GetAll()) do
		if ply:Alive() and P.CanUse(ply)
		and ply:GetPos():DistToSqr(record.entity:GetPos()) <= radius * radius then count = count + 1 end
	end
	return count
end

local function commandObeyed(record, ply, command)
	if record.restraintLevel >= 1 and command ~= "surrender" then return true end
	if record.status ~= "rioting"
	and (command == "halt" or command == "kneel" or command == "face_wall") then
		local score = (record.compliance or 50) + relationship(record, ply) * 0.25
			+ guardsNear(record, 320) * 8 - P.RiskWeight(record.risk) * 6
		return math.Rand(0, 100) <= clamp(score, 15, 98)
	end
	local score = (record.compliance or 50) + relationship(record, ply) * 0.35
		+ guardsNear(record, 360) * 10 - P.RiskWeight(record.risk) * 8
	if command == "surrender" then score = score + (record.health or 100) < 45 and 22 or 0 end
	return math.Rand(0, 100) <= clamp(score, 5, 92)
end

function P.StartEscort(ply, record)
	record = recordFor(record)
	if not P.CanUse(ply) or not record or not IsValid(record.entity) then
		return false, "Prisoner unavailable"
	end
	if ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then
		return false, "Move closer to the prisoner"
	end
	if record.status == "rioting" then
		return false, "Order surrender and secure the prisoner first"
	end
	local transfer = P.State.transfers and P.State.transfers[tostring(record.transfer or "")]
	local pickupReady = record.status == "transfer_ready" and transfer
		and (transfer.status == "pickup_landed" or transfer.status == "boarding")
	if record.status == "transfer_pending" or record.status == "boarding"
	or (record.status == "transfer_ready" and not pickupReady) then
		return false, "Transfer control currently owns this prisoner's movement"
	end
	if not commandObeyed(record, ply, "follow") then
		record.compliance = clamp((record.compliance or 50) - 3, 0, 100)
		addMemory(record, "order_refused", "Refused an escort order.", ply, -1)
		prisonerVoice(record, "refuse")
		return false, record.name .. " refuses to follow."
	end
	if record.risk == "critical" and cfg.RequireTwoGuardsForCritical ~= false
	and record.restraintLevel < 2 then
		return false, "Critical-risk prisoners require secure restraints before escort"
	end
	record.escortSteamID = ply:SteamID64()
	record.escortAssistSteamID = ""
	record.boarded = false
	record.commandPose = ""
	record.entity.mb_escortTrail = { record.entity:GetPos(), ply:GetPos() }
	record.entity.mb_escortHolding = false
	resetNavigation(record.entity)
	if record.risk == "critical" and cfg.RequireTwoGuardsForCritical ~= false then
		record.status = "escort_waiting"
		P.AddIncident("escort", playerName(ply) .. " prepared " .. record.name
			.. " for a two-guard escort.", record, ply, 1)
		P.SaveState()
		if P.UpdateNetwork then P.UpdateNetwork(record) end
		return true, "Escort lead assigned. A second guard must select Assist Escort."
	end
	record.status = "escorting"
	prisonerVoice(record, "obey")
	P.AddIncident("escort", playerName(ply) .. " took escort custody of "
		.. record.name .. ".", record, ply, 1)
	P.SaveState()
	if P.UpdateNetwork then P.UpdateNetwork(record) end
	return true, record.name .. " is following your route."
end

function P.AssistEscort(ply, record)
	record = recordFor(record)
	if not P.CanUse(ply) or not record or record.status ~= "escort_waiting" then
		return false, "This prisoner is not awaiting an escort assistant"
	end
	if record.escortSteamID == ply:SteamID64() then
		return false, "The escort lead cannot also be the assistant"
	end
	if not IsValid(record.entity)
	or ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then
		return false, "Move closer to the prisoner"
	end
	record.escortAssistSteamID = ply:SteamID64()
	record.status = "escorting"
	P.AddIncident("escort", playerName(ply) .. " joined the escort of "
		.. record.name .. ".", record, ply, 1)
	P.SaveState()
	if P.UpdateNetwork then P.UpdateNetwork(record) end
	return true, "You are assisting this critical-risk escort."
end

local function interactionCheck(ply, record)
	if not P.CanUse(ply) or not record or not IsValid(record.entity) then
		return false, "Prisoner unavailable"
	end
	if ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then
		return false, "Move closer to the prisoner"
	end
	return true
end

function P.SearchPrisoner(ply, record)
	record = recordFor(record)
	local ok, reason = interactionCheck(ply, record)
	if not ok then return false, reason end
	record.searched = true
	local found = {}
	for _, item in ipairs(record.contraband or {}) do found[#found + 1] = item end
	record.contraband = {}
	if record.suspicion then
		found[#found + 1] = "evidence of " .. tostring(record.suspicion.label or record.suspicion.kind)
		record.suspicion = nil
	end
	if #found == 0 then
		changeRelationship(record, ply, -1, "Was searched and no prohibited property was found.")
	else
		changeRelationship(record, ply, -2, "Had prohibited property confiscated.")
		record.compliance = clamp((record.compliance or 50) - 2, 0, 100)
	end
	local text = #found > 0 and table.concat(found, ", ") or "nothing prohibited"
	P.AddIncident("search", playerName(ply) .. " searched " .. record.name
		.. " and found " .. text .. ".", record, ply, #found > 0 and 2 or 0)
	P.SaveState()
	return true, "Search recovered " .. text .. "."
end

function P.SecurePrisoner(ply, record)
	record = recordFor(record)
	local ok, reason = interactionCheck(ply, record)
	if not ok then return false, reason end
	record.restraintLevel = math.min(2, (record.restraintLevel or 0) + 1)
	record.restrained = true
	record.commandPose = "restrained"
	if record.status == "rioting" then
		record.status = record.cellID ~= "" and "holding" or "awaiting_escort"
	end
	record.compliance = clamp((record.compliance or 50) + 8, 0, 100)
	record.suspicion = nil
	addMemory(record, "restraint", "Was placed in "
		.. (record.restraintLevel >= 2 and "secure" or "standard") .. " restraints.", ply, -1)
	P.AddIncident("restraint", playerName(ply) .. " applied "
		.. (record.restraintLevel >= 2 and "secure" or "standard")
		.. " restraints to " .. record.name .. ".", record, ply, 2)
	P.SaveState()
	if P.UpdateNetwork then P.UpdateNetwork(record) end
	return true, record.restraintLevel >= 2 and "Secure restraints applied."
		or "Standard restraints applied. Repeat to secure a critical-risk prisoner."
end

function P.RunGuardCommand(ply, target, command)
	local record = recordFor(target)
	if not record then return false, "Prisoner unavailable" end
	if (ply.mb_nextPrisonCommand or 0) > CurTime() then return false end
	ply.mb_nextPrisonCommand = CurTime() + (cfg.CommandCooldownSeconds or 0.65)
	command = tostring(command or "")
	local allowed = {
		record = true, follow = true, assist = true, search = true, restrain = true,
		halt = true, kneel = true, face_wall = true, return_cell = true,
		unrestrain = true, surrender = true,
	}
	if not allowed[command] then return false, "Unknown prisoner command" end
	local ok, message
	if command == "record" then
		P.OpenDatapad(ply, record.id)
		return true
	elseif command == "follow" then
		ok, message = P.StartEscort(ply, record)
	elseif command == "assist" then
		ok, message = P.AssistEscort(ply, record)
	elseif command == "search" then
		ok, message = P.SearchPrisoner(ply, record)
	elseif command == "restrain" then
		ok, message = P.SecurePrisoner(ply, record)
	else
		ok, message = interactionCheck(ply, record)
		if ok and not commandObeyed(record, ply, command) then
			ok = false
			message = record.name .. " refuses the order."
			record.compliance = clamp((record.compliance or 50) - 3, 0, 100)
			addMemory(record, "order_refused", "Refused the order: " .. command, ply, -1)
			prisonerVoice(record, "refuse")
		elseif ok and command == "halt" then
			releaseEscort(record, "holding")
			record.targetPos = nil
			record.targetAng = nil
			record.commandPose = record.restraintLevel > 0 and "restrained" or ""
			message = record.name .. " is holding position."
		elseif ok and command == "kneel" then
			releaseEscort(record, "kneeling")
			record.targetPos = nil
			record.commandPose = "kneel"
			message = record.name .. " is kneeling."
		elseif ok and command == "face_wall" then
			local tr = ply:GetEyeTrace()
			if not tr.Hit or tr.HitPos:DistToSqr(ply:GetPos()) > 260 ^ 2 then
				ok, message = false, "Aim at a nearby wall position"
			else
				local wallPosition = safeGroundPosition(tr.HitPos + tr.HitNormal * 22)
				if not wallPosition then
					ok, message = false, "No safe standing position was found by that wall"
				else
				releaseEscort(record, "facing_wall")
				setRecordTarget(record, {
					pos = wallPosition,
					ang = Angle(0, (-tr.HitNormal):Angle().y, 0),
				}, "facing_wall", "wall")
				message = record.name .. " is moving to the wall."
				end
			end
		elseif ok and command == "return_cell" then
			local marker = assignedCellMarker(record)
			if not marker then
				ok, message = false, "This prisoner has no assigned cell"
			else
				releaseEscort(record, record.risk == "critical" and "isolation" or "incarcerated")
				P.SetCellDoor(record.cellID, true, false)
				setRecordTarget(record, marker, record.status, "")
				message = record.name .. " was ordered back to " .. string.upper(record.cellID) .. "."
			end
		elseif ok and command == "unrestrain" then
			if record.status == "rioting" then
				ok, message = false, "The prisoner must surrender before restraints can be loosened"
			else
				record.restraintLevel = math.max(0, (record.restraintLevel or 0) - 1)
				record.restrained = record.restraintLevel > 0
				record.commandPose = record.restrained and "restrained" or ""
				message = record.restraintLevel == 1 and "Restraints reduced to standard security."
					or "Restraints removed."
				addMemory(record, "restraint", message, ply, 1)
			end
		elseif ok and command == "surrender" then
			record.status = record.cellID ~= "" and "holding" or "awaiting_escort"
			record.restraintLevel = math.max(1, record.restraintLevel or 0)
			record.restrained = true
			record.commandPose = "surrender"
			record.suspicion = nil
			message = record.name .. " surrendered. Secure their restraints."
			prisonerVoice(record, "surrender")
			P.AddIncident("surrender", record.name .. " surrendered to " .. playerName(ply)
				.. ".", record, ply, 2)
		end
	end
	if message then MilBase.Notify(ply, message, ok and "ok" or "warn") end
	if ok and command ~= "record" then
		if command ~= "surrender" then prisonerVoice(record, "obey") end
		record.commandHistory = record.commandHistory or {}
		table.insert(record.commandHistory, 1, {
			time = unix(), command = command, guard = playerName(ply), obeyed = true,
		})
		while #record.commandHistory > 20 do table.remove(record.commandHistory) end
		P.SaveState()
		if P.UpdateNetwork then P.UpdateNetwork(record) end
	end
	return ok, message
end

local INTAKE_STAGES = {
	{ id = "search", label = "SEARCH AND CONTRABAND CHECK", marker = "search" },
	{ id = "property", label = "SEAL PERSONAL PROPERTY", marker = "property" },
	{ id = "mugshot", label = "IDENTITY PHOTOGRAPH", marker = "mugshot" },
	{ id = "charges", label = "CONFIRM CHARGES", marker = "intake" },
	{ id = "classification", label = "CONFIRM RISK CLASSIFICATION", marker = "intake" },
	{ id = "assignment", label = "ASSIGN CELL", marker = "intake" },
}
local INTAKE_INDEX = {}
for index, stage in ipairs(INTAKE_STAGES) do INTAKE_INDEX[stage.id] = index end

local function currentIntakeStage(record)
	local index = INTAKE_INDEX[tostring(record.intakeStage or "search")] or 1
	return INTAKE_STAGES[index], index
end

function P.ProcessIntake(ply, record, forceComplete)
	record = recordFor(record)
	local ok, reason = interactionCheck(ply, record)
	if not ok then return false, reason end
	if record.intakeComplete or record.intakeStage == "complete" then
		return false, "This prisoner's intake is already complete"
	end
	if record.escortSteamID ~= ply:SteamID64()
	or (record.status ~= "escorting" and record.status ~= "escort_waiting") then
		return false, "Take escort custody before processing intake"
	end

	local intake = P.GetMarker("intake") or P.GetMarker("entrance") or P.GetMarker("search")
	if not intake then return false, "No prison intake marker is configured" end

	local stage, stageIndex = currentIntakeStage(record)
	local marker = P.GetMarker(stage.marker) or intake

	local plyDist = ply:GetPos():DistToSqr(marker.pos)
	local intakeDist = ply:GetPos():DistToSqr(intake.pos)

	if plyDist > 650 ^ 2 and intakeDist > 650 ^ 2 then
		return false, "Escort the prisoner to the intake area or " .. string.lower(stage.label)
	end

	if forceComplete or stage.id == "assignment" then
		local found = {}
		for _, item in ipairs(record.contraband or {}) do found[#found + 1] = item end
		record.contraband = {}
		record.searched = true
		record.property.sealedAt = unix()
		record.property.sealedBy = playerName(ply)
		record.mugshotAt = unix()
		record.identityConfirmed = true
		record.chargesConfirmedAt = unix()
		record.chargesConfirmedBy = playerName(ply)
		record.classificationConfirmedAt = unix()
		record.classificationConfirmedBy = playerName(ply)
		if record.risk == "critical" then record.restraintLevel = 2 end

		local cellID = P.ChooseCell and P.ChooseCell(record)
		record.intakeComplete = true
		record.intakeStage = "complete"
		record.escortSteamID = ""
		record.escortAssistSteamID = ""

		if cellID then
			record.cellID = cellID
			record.status = record.risk == "critical" and "isolation" or "incarcerated"
			for _, other in ipairs(P.ActivePrisoners()) do
				if other ~= record and other.cellID == cellID then
					addMemory(record, "cellmate", "Assigned to a cell with " .. other.name .. ".", nil, 0)
					addMemory(other, "cellmate", record.name .. " became their cellmate.", nil, 0)
				end
			end
			P.SetCellDoor(cellID, false, false)
			setRecordTarget(record, assignedCellMarker(record), record.status, "")
		else
			record.cellID = ""
			record.status = "overflow"
			setRecordTarget(record, activitySlot(P.GetMarker("overflow") or intake, record, 16),
				"overflow", "")
			P.AddIncident("overcrowding", record.name
				.. " was placed in overflow holding because no proper bed was available.",
				record, ply, 3)
		end
		P.AddIncident("intake", record.name .. " completed intake and was assigned to "
			.. (record.cellID ~= "" and record.cellID or "overflow") .. ".", record, ply, 1)
		P.SaveState()
		return true, "Intake complete! Assigned to "
			.. (record.cellID ~= "" and string.upper(record.cellID) or "OVERFLOW HOLDING") .. ". Prisoner is moving to cell."
	end

	local detail = ""
	if stage.id == "search" then
		local found = {}
		for _, item in ipairs(record.contraband or {}) do found[#found + 1] = item end
		record.contraband = {}
		record.searched = true
		detail = #found > 0 and (" Confiscated: " .. table.concat(found, ", ") .. ".")
			or " No prohibited items found."
	elseif stage.id == "property" then
		record.property.sealedAt = unix()
		record.property.sealedBy = playerName(ply)
		detail = " Personal property sealed."
	elseif stage.id == "mugshot" then
		record.mugshotAt = unix()
		record.identityConfirmed = true
		detail = " Identity image registered."
	elseif stage.id == "charges" then
		record.chargesConfirmedAt = unix()
		record.chargesConfirmedBy = playerName(ply)
		detail = " Charges confirmed."
	elseif stage.id == "classification" then
		record.classificationConfirmedAt = unix()
		record.classificationConfirmedBy = playerName(ply)
		if record.risk == "critical" then record.restraintLevel = 2 end
		detail = " Risk class confirmed as " .. P.RiskLabel(record.risk) .. "."
	end

	local nextStage = INTAKE_STAGES[stageIndex + 1]
	record.intakeStage = nextStage and nextStage.id or "assignment"
	record.status = record.status == "escort_waiting" and "escort_waiting" or "escorting"
	addMemory(record, "intake", stage.label .. " completed.", ply, 0)
	P.AddIncident("intake", playerName(ply) .. " completed "
		.. string.lower(stage.label) .. " for " .. record.name .. ".", record, ply, 0)
	P.SaveState()
	return true, stage.label .. " complete." .. detail .. " Next: "
		.. tostring(nextStage and nextStage.label or "ASSIGN CELL") .. "."
end

local function homeTarget(record)
	local marker = assignedCellMarker(record)
	if marker then
		return marker, record.risk == "critical" and "isolation" or "incarcerated"
	end
	return activitySlot(P.GetMarker("overflow") or P.GetMarker("intake"), record, 16), "overflow"
end

local function scheduleTarget(record, schedule)
	if schedule == "social" then
		return activitySlot(P.GetMarker("social") or P.GetMarker("exercise"),
			record, #P.ActivePrisoners()), "social"
	elseif schedule == "work" then
		return activitySlot(P.GetMarker("work"), record, #P.ActivePrisoners()), "work"
	elseif schedule == "interviews" then
		return activitySlot(P.GetMarker("interview") or P.GetMarker("medical"),
			record, #P.ActivePrisoners()), "medical"
	elseif schedule == "shower" then
		return activitySlot(P.GetMarker("shower"), record, #P.ActivePrisoners()), "social"
	end
	return homeTarget(record)
end

local function recordLockdownActive(record)
	local state = P.State.lockdowns or {}
	local cellID = tostring(record and record.cellID or "")
	if cellID == "" then return state.facility == true end
	return state.facility == true
		or ((state.zones or {})[cellZone(cellID)] == true)
		or ((state.cells or {})[cellID] == true)
end

function P.ApplySchedule(id, actor, manual, duration, silent)
	id = P.CleanID(id, "lockdown")
	P.State.schedule = id
	P.State.manualSchedule = manual == true
	P.State.scheduleEndsAt = unix() + math.max(30, tonumber(duration) or 300)
	if id == "riot_lockdown" then
		P.State.alert = "riot"
		P.State.lockdowns = P.State.lockdowns or { facility = false, zones = {}, cells = {} }
		P.State.lockdowns.facility = true
	elseif id == "lockdown" and P.State.alert ~= "riot" then
		P.State.alert = "normal"
	end
	for _, record in ipairs(P.ActivePrisoners()) do
		normaliseRecord(record)
		if record.status ~= "awaiting_escort" and record.status ~= "escort_waiting"
		and record.status ~= "escorting" and record.status ~= "transfer_pending"
		and record.status ~= "transfer_ready" and record.status ~= "boarding"
		and record.status ~= "rioting" then
			local locked = recordLockdownActive(record)
			local marker, status = scheduleTarget(record,
				locked and "riot_lockdown" or id)
			if marker then
				if record.cellID ~= "" then P.SetCellDoor(record.cellID, true, false) end
				setRecordTarget(record, marker, status, "")
				if locked and record.cellID ~= "" then scheduleDoorClose(record.cellID, true) end
			end
		end
	end
	if id == "lockdown" or id == "riot_lockdown" then
		for cellID in pairs(P.Cells or {}) do scheduleDoorClose(cellID, true) end
	end
	if id == "riot_lockdown" and not silent then
		P.SetAlarm(true, "Emergency prison lockdown", "critical", "facility", actor)
	end
	if not silent then
		P.AddIncident("schedule", "Prison schedule changed to "
			.. (P.ScheduleLabels[id] or string.upper(id)) .. ".", nil, actor, 1)
	end
	P.SaveState()
	return true
end

local function cellsForLockdown(scope, id)
	local result = {}
	for cellID in pairs(P.Cells or {}) do
		if scope == "facility"
		or (scope == "zone" and cellZone(cellID) == P.CleanID(id, "cellblock"))
		or (scope == "cell" and cellID == P.CleanID(id)) then
			result[#result + 1] = cellID
		end
	end
	return result
end

local function cellLockdownActive(cellID)
	local state = P.State.lockdowns or {}
	return state.facility == true
		or ((state.zones or {})[cellZone(cellID)] == true)
		or ((state.cells or {})[cellID] == true)
end

function P.SetLockdown(scope, id, enabled, actor)
	if not P.CanCommand(actor) and IsValid(actor) then return false, "Command authorisation required" end
	scope = P.CleanID(scope, "facility")
	enabled = enabled == true
	P.State.lockdowns = P.State.lockdowns or { facility = false, zones = {}, cells = {} }
	P.State.lockdowns.zones = P.State.lockdowns.zones or {}
	P.State.lockdowns.cells = P.State.lockdowns.cells or {}
	if scope == "facility" then
		P.State.lockdowns.facility = enabled
	elseif scope == "zone" then
		id = P.CleanID(id, "cellblock")
		P.State.lockdowns.zones[id] = enabled or nil
	elseif scope == "cell" then
		id = P.CleanID(id)
		if not P.Cells[id] then return false, "Unknown prison cell" end
		P.State.lockdowns.cells[id] = enabled or nil
	else
		return false, "Unknown lockdown scope"
	end

	local affected = cellsForLockdown(scope, id)
	for _, cellID in ipairs(affected) do
		if enabled then
			for _, record in ipairs(P.ActivePrisoners()) do
				if record.cellID == cellID and record.status ~= "rioting"
				and record.status ~= "boarding" then
					local marker, status = homeTarget(record)
					setRecordTarget(record, marker, status, "")
				end
			end
			scheduleDoorClose(cellID, true)
		else
			if cellLockdownActive(cellID) then
				scheduleDoorClose(cellID, true)
			else
				P.SetCellDoor(cellID, false, false)
			end
		end
	end
	if enabled and scope == "facility" then
		P.State.schedule = "riot_lockdown"
		P.State.manualSchedule = true
		P.State.scheduleEndsAt = unix() + (cfg.LockdownDefaultSeconds or 600)
	elseif not enabled and scope == "facility" then
		P.State.alert = "restricted"
		P.State.schedule = "restricted"
		P.State.manualSchedule = true
		P.State.scheduleEndsAt = unix() + 300
	end
	local label = scope == "facility" and "facility" or (scope .. " " .. tostring(id))
	P.AddIncident("lockdown", playerName(actor) .. (enabled and " engaged " or " cleared ")
		.. label .. " lockdown.", nil, actor, enabled and 3 or 1)
	if enabled then P.SetAlarm(true, string.upper(label) .. " LOCKDOWN", "critical", id, actor) end
	P.SaveState()
	return true, string.upper(label) .. (enabled and " lockdown engaged." or " lockdown cleared.")
end

local function broadcastAlarm()
	local receivers = {}
	for _, ply in ipairs(player.GetAll()) do
		if P.CanUse(ply) then receivers[#receivers + 1] = ply end
	end
	if #receivers == 0 then return end
	net.Start(NET_ALERT)
		net.WriteTable(P.State.alarm or {})
	net.Send(receivers)
end

function P.SetAlarm(active, reason, level, zone, actor)
	P.State.alarm = P.State.alarm
		or { active = false, reason = "", level = "normal", zone = "", startedAt = 0 }
	local changed = P.State.alarm.active ~= (active == true)
		or tostring(P.State.alarm.reason or "") ~= tostring(reason or "")
	P.State.alarm.active = active == true
	P.State.alarm.reason = active and string.sub(tostring(reason or "Prison alarm"), 1, 160) or ""
	P.State.alarm.level = active and P.CleanID(level, "warning") or "normal"
	P.State.alarm.zone = active and P.CleanID(zone, "facility") or ""
	P.State.alarm.startedAt = active and unix() or 0
	if changed then
		if active then
			for _, marker in ipairs(P.GetMarkers("alarm")) do
				sound.Play("ambient/alarms/klaxon1.wav", marker.pos, 82, 100, 0.75)
			end
			P.AddIncident("alarm", "Prison alarm activated: " .. P.State.alarm.reason .. ".",
				nil, actor, level == "critical" and 5 or 3)
			if P.NotifyGuards then P.NotifyGuards("PRISON ALARM: " .. P.State.alarm.reason, "warn") end
		else
			P.AddIncident("alarm", "Prison alarm cleared.", nil, actor, 1)
		end
	end
	broadcastAlarm()
	P.SaveState()
	return true, active and "Prison alarm activated." or "Prison alarm cleared."
end

local baseStartRiot = P.StartRiot
function P.StartRiot(record, reason)
	normaliseRecord(record)
	local result = baseStartRiot(record, reason)
	if result then
		local roles = { "assault", "raider", "saboteur", "seizer", "defender" }
		record.riotRole = trait(record, "riot_leader") and "leader"
			or roles[math.random(1, #roles)]
		record.riotActionAt = CurTime() + math.Rand(4, 10)
		record.suspicion = nil
		P.SetAlarm(true, "Prison disturbance involving " .. record.name, "critical",
			record.cellID ~= "" and cellZone(record.cellID) or "facility")
		if #activeRioters() >= math.max(1, tonumber(cfg.TakeoverMinimumRioters) or 3) then
			P.StartShipTakeover(reason or "riot escalation")
		end
	end
	return result
end

function P.NegotiateRiot(ply)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	local resolved, total = 0, 0
	for _, record in ipairs(P.ActivePrisoners()) do
		if record.status == "rioting" then
			total = total + 1
			local needs = record.needs or {}
			local average = ((needs.food or 0) + (needs.water or 0) + (needs.sleep or 0)
				+ (needs.hygiene or 0) + (needs.social or 0)) / 5
			local score = (record.compliance or 50) + average * 0.35
				+ relationship(record, ply) * 0.4 + guardsNear(record, 500) * 6
				- P.RiskWeight(record.risk) * 8
			if record.riotRole ~= "leader" and math.Rand(0, 100) <= clamp(score, 10, 92) then
				record.status = record.cellID ~= "" and "holding" or "awaiting_escort"
				record.restraintLevel = math.max(1, record.restraintLevel or 0)
				record.restrained = true
				record.commandPose = "surrender"
				resolved = resolved + 1
				addMemory(record, "negotiation", "Surrendered following negotiation.", ply, 1)
				if P.UpdateNetwork then P.UpdateNetwork(record) end
			end
		end
	end
	if total == 0 then return false, "There is no active riot to negotiate" end
	P.AddIncident("riot", playerName(ply) .. " negotiated with rioters; "
		.. resolved .. " of " .. total .. " surrendered.", nil, ply, resolved > 0 and 2 or 3)
	if resolved == total then
		P.State.alert = "restricted"
		P.SetAlarm(false, "", "normal", "", ply)
	end
	P.SaveState()
	return true, resolved .. " of " .. total .. " rioters surrendered."
end

local function needAverage(record)
	local needs = record.needs or {}
	return ((needs.food or 0) + (needs.water or 0) + (needs.sleep or 0)
		+ (needs.hygiene or 0) + (needs.social or 0)) / 5
end

local WARNING_LABELS = {
	riot = {
		"organising a refusal", "passing improvised signals", "gathering prisoners",
		"stockpiling loose objects",
	},
	takeover = {
		"mapping restricted ship systems", "watching security patrol changes",
		"coordinating an assault team", "identifying routes to the bridge",
	},
}

local function beginWarning(record, kind)
	local labels = WARNING_LABELS[kind]
	record.suspicion = {
		kind = kind,
		stage = "warning",
		label = labels[math.random(1, #labels)],
		startedAt = unix(),
		activatesAt = unix() + math.random(
			math.max(10, cfg.IncidentWarningMinimum or 25),
			math.max(cfg.IncidentWarningMinimum or 25, cfg.IncidentWarningMaximum or 55)),
		discovered = false,
	}
	record.lastIncidentAt = unix()
	if (kind == "riot" or kind == "takeover") and record.cellID ~= "" and P.CellRuntime then
		local cell = P.CellRuntime(record.cellID)
		if #cell.contraband < 4 then cell.contraband[#cell.contraband + 1] = "improvised riot tool" end
	end
	P.AddIncident("suspicion", record.name .. " began " .. record.suspicion.label .. ".",
		record, nil, 2)
end

local function transferTimeouts()
	for _, transfer in pairs(P.State.transfers or {}) do
		if (transfer.status == "pickup_queued" or transfer.status == "pickup_inbound")
		and unix() - (tonumber(transfer.pickupRequestedAt) or unix())
			> (cfg.TransferPickupArrivalTimeout or 300) then
			if P.AbortTransferPickup then
				P.AbortTransferPickup(transfer, "LAAT approach timed out")
			end
		elseif (transfer.status == "pickup_landed" or transfer.status == "boarding")
		and unix() - (tonumber(transfer.landedAt) or tonumber(transfer.boardingAt) or unix())
			> (cfg.TransferBoardingTimeout or 600) then
			if P.AbortTransferPickup then
				P.AbortTransferPickup(transfer, "Boarding window expired")
			end
		end
	end
end

local function securityTick()
	if not P._loaded then return end
	local active = P.ActivePrisoners()
	local capacity = P.CapacitySnapshot()
	local riotCount = 0
	for _, record in ipairs(active) do
		normaliseRecord(record)
		if record.status == "rioting" then riotCount = riotCount + 1 end
		if record.suspicion and unix() >= (record.suspicion.activatesAt or math.huge) then
			P.StartRiot(record, "uninterrupted warning signs")
		elseif not record.suspicion and record.status ~= "awaiting_escort"
		and record.status ~= "escort_waiting" and record.status ~= "escorting"
		and record.status ~= "boarding" and record.status ~= "rioting"
		and unix() - (record.lastIncidentAt or 0) >= (cfg.IncidentCooldownSeconds or 90) then
			local neglect = math.max(0, (45 - needAverage(record)) / 45)
			local overcrowd = math.max(0, capacity.ratio - 1)
			local guardFactor = guardsNear(record, cfg.GuardPresenceRadius or 900) <= 0 and 1.6 or 0.55
			local riotChance = ((cfg.RiotBaseChance or 0.012) + neglect * 0.026
				+ overcrowd * 0.03 + (trait(record, "riot_leader") and 0.03
					or trait(record, "takeover_planner") and 0.022
					or trait(record, "aggressive") and 0.012 or 0)) * guardFactor
			if record.status == "overflow" then
				riotChance = riotChance * (cfg.OverflowRiotMultiplier or 2.5)
			end
			if #active >= (cfg.RiotMinimumPrisoners or 3)
			and math.Rand(0, 1) < riotChance then
				beginWarning(record, trait(record, "takeover_planner") and "takeover" or "riot")
			end
		end

		if record.status == "social" and #record.contraband > 0
		and math.Rand(0, 1) < (cfg.ContrabandMoveChance or 0.14) then
			local candidates = {}
			for _, other in ipairs(active) do
				if other ~= record and other.status == "social" then candidates[#candidates + 1] = other end
			end
			if #candidates > 0 then
				local item = table.remove(record.contraband, math.random(1, #record.contraband))
				local receiver = candidates[math.random(1, #candidates)]
				receiver.contraband = receiver.contraband or {}
				receiver.contraband[#receiver.contraband + 1] = item
				record.knownAssociates = istable(record.knownAssociates) and record.knownAssociates or {}
				receiver.knownAssociates = istable(receiver.knownAssociates)
					and receiver.knownAssociates or {}
				if not table.HasValue(record.knownAssociates, receiver.id) then
					record.knownAssociates[#record.knownAssociates + 1] = receiver.id
				end
				if not table.HasValue(receiver.knownAssociates, record.id) then
					receiver.knownAssociates[#receiver.knownAssociates + 1] = record.id
				end
				addMemory(record, "contraband", "Transferred concealed property during social time.", nil, -1)
				addMemory(receiver, "contraband", "Received concealed property during social time.", nil, -1)
			end
		end
	end
	riotCount = #activeRioters()
	local takeoverMinimum = math.max(1, tonumber(cfg.TakeoverMinimumRioters) or 3)
	if riotCount > 0 and riotCount < takeoverMinimum and #active >= takeoverMinimum then
		for _, record in ipairs(active) do
			if record.status ~= "rioting" and record.status ~= "boarding"
			and record.status ~= "awaiting_escort" and record.status ~= "escorting"
			and math.Rand(0, 1) <= (trait(record, "aggressive") and 0.42
				or trait(record, "takeover_planner") and 0.5 or 0.2) then
				P.StartRiot(record, "cellblock unrest spread")
				break
			end
		end
	end
	riotCount = #activeRioters()
	if riotCount >= takeoverMinimum and not takeoverState().active then
		P.StartShipTakeover("riot escalation")
	end
	if riotCount >= math.max(2, math.ceil(#active * 0.35)) then
		P.State.alert = "riot"
		for cellID in pairs(P.Cells or {}) do
			local runtime = P.CellRuntime and P.CellRuntime(cellID)
			if runtime and math.Rand(0, 1) < 0.22 then
				runtime.damage = clamp((runtime.damage or 0) + math.random(3, 10), 0, 100)
			end
			if runtime and math.Rand(0, 1) < 0.1 and #runtime.contraband < 4 then
				runtime.contraband[#runtime.contraband + 1] = "improvised riot tool"
			end
		end
	end
	transferTimeouts()
	local alarm = P.State.alarm or {}
	local activeThreat = takeoverState().active or #activeRioters() > 0
	if not activeThreat and P.State.alert == "riot" then P.State.alert = "restricted" end
	if alarm.active and not activeThreat and alarm.startedAt > 0
	and unix() - alarm.startedAt >= (cfg.AlarmAutoClearSeconds or 180)
	and not (P.State.lockdowns and P.State.lockdowns.facility) then
		P.SetAlarm(false)
	end
	P.SaveState()
end

timer.Remove("MilBase.Prison.Security")
timer.Create("MilBase.Prison.Security", math.max(5, tonumber(cfg.SecurityTickSeconds) or 15), 0,
	securityTick)

local function finishTakeoverCapture(objective, state)
	state.captured[objective.kind] = true
	recomputeTakeoverBenefits(state)
	P.AddIncident("takeover", "Rioters captured " .. objective.label
		.. " during the ship takeover.", nil, nil, 5)
	if objective.kind == "takeover_bridge" then
		state.controlled = true
		state.stage = "ship_controlled"
		state.progress = math.max(1, tonumber(cfg.TakeoverObjectiveHoldSeconds) or 24)
		P.SetAlarm(true, "BRIDGE CAPTURED: RIOTERS CONTROL THE SHIP", "critical", "bridge")
		if P.NotifyGuards then
			P.NotifyGuards("SHIP LOST: rioters have seized the BRIDGE. Retake it room by room.", "warn")
		end
	else
		state.currentIndex = math.min(#TAKEOVER_OBJECTIVES, state.currentIndex + 1)
		local nextObjective = TAKEOVER_OBJECTIVES[state.currentIndex]
		state.stage = nextObjective.kind
		state.progress = 0
		P.SetAlarm(true, objective.label .. " CAPTURED: RIOTERS ADVANCING ON "
			.. nextObjective.label, "critical", "facility")
		if P.NotifyGuards then
			P.NotifyGuards("TAKEOVER: " .. objective.label .. " captured. Next target: "
				.. nextObjective.label .. ".", "warn")
		end
	end
	P.SaveState()
end

local function takeoverTick()
	if not P._loaded then return end
	local state = takeoverState()
	if not state.active then return end
	local rioters = activeRioters()
	if #rioters == 0 then
		local wasControlled = state.controlled
		state.active = false
		state.controlled = false
		state.stage = "resecured"
		state.currentIndex = 1
		state.progress = 0
		state.captured = {}
		recomputeTakeoverBenefits(state)
		P.State.alert = "restricted"
		P.AddIncident("takeover", wasControlled
			and "Security suppressed the rioters and restored control of the ship."
			or "Security suppressed the ship takeover.", nil, nil, 4)
		P.SetAlarm(false)
		if P.NotifyGuards then P.NotifyGuards("SHIP SECURE: all rioters have been suppressed.", "ok") end
		P.SaveState()
		return
	end
	if state.controlled then return end

	local objective = currentTakeoverObjective()
	if not objective or not objective.marker then
		state.stage = "setup_missing"
		return
	end
	local captureRadius = math.max(100, tonumber(cfg.TakeoverCaptureRadius) or 190)
	local contestRadius = math.max(captureRadius,
		tonumber(cfg.TakeoverGuardContestRadius) or 240)
	local riotCount = riotersNearPosition(objective.marker.pos, captureRadius)
	local guardCount = guardsNearPosition(objective.marker.pos, contestRadius)
	if riotCount > guardCount and riotCount > 0 then
		state.progress = state.progress + 1
			+ math.max(0, riotCount - guardCount - 1)
				* (tonumber(cfg.TakeoverProgressPerRiot) or 0.35)
	elseif guardCount > 0 then
		state.progress = math.max(0, state.progress - math.max(1, guardCount * 0.75))
	end
	if state.progress >= math.max(5, tonumber(cfg.TakeoverObjectiveHoldSeconds) or 24) then
		finishTakeoverCapture(objective, state)
	end
end

timer.Remove("MilBase.Prison.Takeover")
timer.Create("MilBase.Prison.Takeover", 1, 0, takeoverTick)

function P.SecureTakeoverObjective(ply)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	local state = takeoverState()
	if not state.active then return false, "There is no active ship takeover" end
	local objectives = takeoverObjectives()
	local index = state.currentIndex
	local current = objectives[index]
	local currentCaptured = current and state.captured[current.kind] == true
	local clearingBreach = current and not currentCaptured and state.progress > 0
	if not clearingBreach and not currentCaptured then
		index = index - 1
	end
	local objective = objectives[index]
	if not objective or not objective.marker then
		return false, "No breached takeover objective is ready to secure"
	end
	local distance = math.max(100, tonumber(cfg.TakeoverRetakeDistance) or 220)
	if ply:GetPos():DistToSqr(objective.marker.pos) > distance * distance then
		return false, "Move into " .. objective.label .. " to secure it"
	end
	local contestRadius = math.max(100, tonumber(cfg.TakeoverGuardContestRadius) or 240)
	local remaining = riotersNearPosition(objective.marker.pos, contestRadius)
	if remaining > 0 then
		return false, remaining .. " rioter(s) are still contesting " .. objective.label
	end

	if state.captured[objective.kind] then
		state.captured[objective.kind] = nil
		state.currentIndex = objective.index
		state.controlled = false
		state.stage = objective.kind
		state.progress = 0
		recomputeTakeoverBenefits(state)
		P.AddIncident("takeover", playerName(ply) .. " retook " .. objective.label
			.. " from the rioters.", nil, ply, 4)
		if P.NotifyGuards then
			P.NotifyGuards("OBJECTIVE SECURE: " .. objective.label .. " has been retaken.", "ok")
		end
		P.SetAlarm(true, objective.label .. " RETAKEN: TAKEOVER STILL ACTIVE",
			"critical", "facility", ply)
		P.SaveState()
		return true, objective.label .. " retaken. Hold it against the next assault."
	end

	state.progress = 0
	P.AddIncident("takeover", playerName(ply) .. " cleared the breach at "
		.. objective.label .. ".", nil, ply, 3)
	P.SaveState()
	return true, objective.label .. " capture progress cleared."
end

local function cameraCanSee(marker, ent)
	if not marker or not IsValid(ent) then return false end
	local data = marker.data or {}
	local range = math.max(200, tonumber(data.range) or cfg.CameraRange or 1100)
	local delta = ent:WorldSpaceCenter() - marker.pos
	if delta:LengthSqr() > range * range then return false end
	local fov = math.Clamp(tonumber(data.fov) or cfg.CameraFOV or 78, 20, 160)
	if marker.ang:Forward():Dot(delta:GetNormalized()) < math.cos(math.rad(fov * 0.5)) then
		return false
	end
	local tr = util.TraceLine({
		start = marker.pos,
		endpos = ent:WorldSpaceCenter(),
		filter = ent,
		mask = MASK_VISIBLE,
	})
	return not tr.Hit
end

local function cameraScan()
	if not P._loaded then return end
	for _, marker in ipairs(P.GetMarkers("camera")) do
		local runtime = P.CameraRuntime[marker.id] or {
			online = true, lastSeenAt = 0, prisonerID = "", event = "CLEAR",
		}
		P.CameraRuntime[marker.id] = runtime
		runtime.online = runtime.online ~= false
		runtime.jammed = takeoverState().systemsThreatened
		if runtime.jammed then
			runtime.event = "SYSTEMS JAMMED"
			runtime.prisonerID = ""
			runtime.prisonerName = ""
		elseif runtime.event == "SYSTEMS JAMMED" then
			runtime.event = "CLEAR"
		end
		if not runtime.jammed and runtime.lastSeenAt > 0 and unix() - runtime.lastSeenAt > 12 then
			runtime.event = "CLEAR"
			runtime.prisonerID = ""
			runtime.prisonerName = ""
		end
		if runtime.online and not runtime.jammed then
			for _, record in ipairs(P.ActivePrisoners()) do
				if cameraCanSee(marker, record.entity) then
					local event
					if record.status == "rioting" then
						event = takeoverState().active and "SHIP TAKEOVER" or "RIOT"
					elseif record.suspicion then event = "SUSPICIOUS ACTIVITY" end
					if event then
						runtime.lastSeenAt = unix()
						runtime.prisonerID = record.id
						runtime.prisonerName = record.name
						runtime.event = event
						if record.suspicion then
							record.suspicion.discovered = true
							record.suspicion.cameraID = marker.id
						end
						if CurTime() >= (runtime.nextAlertAt or 0) then
							runtime.nextAlertAt = CurTime() + (cfg.CameraAlertCooldown or 8)
							P.SetAlarm(true, marker.name .. ": " .. event .. " — " .. record.name,
								event == "SUSPICIOUS ACTIVITY" and "warning" or "critical",
								marker.data and marker.data.zone or "facility")
						end
					end
				end
			end
		end
	end
end
timer.Create("MilBase.Prison.Cameras", math.max(0.25, tonumber(cfg.CameraScanSeconds) or 0.5),
	0, cameraScan)

local function ambientSpeechLine(record)
	local configured = cfg.PrisonerAmbientLines or {}
	local pool
	local needs = record.needs or {}
	if record.status == "rioting" then
		pool = configured.rioting
	elseif record.status == "transfer_ready" then
		pool = configured.transfer_ready
	elseif math.min(tonumber(needs.food) or 100, tonumber(needs.water) or 100,
		tonumber(needs.medical) or 100) < 30 then
		pool = configured.needs
	elseif record.status == "incarcerated" then
		pool = configured.incarcerated
	end
	if not istable(pool) or #pool == 0 then pool = configured.default end
	if not istable(pool) or #pool == 0 then return nil end
	return pool[math.random(1, #pool)]
end

local function ambientSpeechTick()
	if cfg.AmbientPrisonerSpeech == false or not P._loaded then return end
	local now = CurTime()
	local range = math.max(160, tonumber(cfg.LanguageSpeechRadius) or 720)
	local rangeSquared = range * range
	local ready = {}
	for _, record in ipairs(P.ActivePrisoners()) do
		local ent = record.entity
		if IsValid(ent) and not ent:GetNoDraw()
		and now >= (ent.mb_nextAmbientLanguageSpeech or 0) then
			local heard = false
			for _, listener in ipairs(player.GetHumans()) do
				if listener:Alive()
				and listener:GetPos():DistToSqr(ent:GetPos()) <= rangeSquared then
					heard = true
					break
				end
			end
			if heard then ready[#ready + 1] = record
			else ent.mb_nextAmbientLanguageSpeech = now + 10 end
		end
	end
	if #ready == 0 then return end
	local record = ready[math.random(1, #ready)]
	local line = ambientSpeechLine(record)
	if line then P.BroadcastPrisonerSpeech(record, line) end
	local minimum = math.max(8, tonumber(cfg.LanguageSpeechMinimumDelay) or 38)
	local maximum = math.max(minimum, tonumber(cfg.LanguageSpeechMaximumDelay) or 82)
	record.entity.mb_nextAmbientLanguageSpeech = now + math.Rand(minimum, maximum)
	-- Stagger other ready prisoners so a large cell block does not speak in a
	-- burst immediately after players enter its hearing radius.
	for _, other in ipairs(ready) do
		if other ~= record and IsValid(other.entity) then
			other.entity.mb_nextAmbientLanguageSpeech = now + math.Rand(5, 14)
		end
	end
end

timer.Remove("MilBase.Prison.LanguageSpeech")
timer.Create("MilBase.Prison.LanguageSpeech", 3, 0, ambientSpeechTick)

hook.Add("EntityTakeDamage", "MilBase.Prison.CameraAssaultDetection", function(target, damage)
	if not P.IsPrisonerEntity(target) or CurTime() < (target.mb_nextPrisonDamageAlert or 0) then return end
	target.mb_nextPrisonDamageAlert = CurTime() + 4
	local attacker = damage:GetAttacker()
	timer.Simple(0, function()
		if not IsValid(target) then return end
		local record = recordFor(target)
		if not record or record.status == "deceased" then return end
		for _, marker in ipairs(P.GetMarkers("camera")) do
			if cameraCanSee(marker, target) then
				P.AddIncident("assault", record.name .. " was injured in view of "
					.. marker.name .. ".", record, IsValid(attacker) and attacker or nil, 3)
				P.SetAlarm(true, marker.name .. ": violence involving " .. record.name,
					"warning", marker.data and marker.data.zone or "facility")
				break
			end
		end
	end)
end)

function P.RollCall(ply)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	if P.State.schedule ~= "rollcall" or not P.State.rollCallStartedAt then
		P.State.rollCallStartedAt = unix()
		P.ApplySchedule("rollcall", ply, true, 120)
		return true, "Roll call ordered. Run the check again after prisoners reach their positions."
	end
	if unix() - P.State.rollCallStartedAt < 8 then
		return false, "Allow prisoners time to reach their roll-call positions"
	end
	local missing = {}
	for _, record in ipairs(P.ActivePrisoners()) do
		local marker = assignedCellMarker(record)
		if not marker and record.intakeComplete and record.status == "overflow" then
			marker = activitySlot(P.GetMarker("overflow") or P.GetMarker("intake"), record, 16)
		end
		if marker and (not IsValid(record.entity)
		or record.entity:GetPos():DistToSqr(marker.pos) > 180 ^ 2) then
			missing[#missing + 1] = record.name
		end
	end
	if #missing > 0 then
		P.SetAlarm(true, "ROLL CALL MISMATCH: " .. table.concat(missing, ", "),
			"critical", "facility", ply)
		P.AddIncident("rollcall", "Roll call reported missing prisoners: "
			.. table.concat(missing, ", ") .. ".", nil, ply, 5)
		return false, "Missing from assigned positions: " .. table.concat(missing, ", ")
	end
	P.State.rollCallStartedAt = nil
	P.AddIncident("rollcall", playerName(ply) .. " completed a clear roll call.",
		nil, ply, 0)
	return true, "Roll call complete. All assigned prisoners accounted for."
end

function P.InterviewPrisoner(ply, record, topic)
	record = recordFor(record)
	local ok, reason = interactionCheck(ply, record)
	if not ok then return false, reason end
	topic = P.CleanID(topic, "case")
	local history = record.interviews or {}
	local repeats = 0
	for _, row in ipairs(history) do if row.topic == topic then repeats = repeats + 1 end end
	local score = (record.compliance or 50) + relationship(record, ply) * 0.4
		+ needAverage(record) * 0.25 - repeats * 8
		+ (trait(record, "informant") and 24 or 0)
		- (trait(record, "ideological") and 22 or 0)
	local reliable = math.Rand(0, 100) <= clamp(score, 8, 95)
	local responses = {
		case = reliable and "The inspection record is accurate. The captain controlled the operation."
			or "You already wrote your version of the inspection.",
		crew = reliable and "One of the crew handled contacts away from the others."
			or "I have nothing useful to say about the crew.",
		cargo = reliable and "The sealed cargo was kept separate from the declared manifest."
			or "I never controlled the cargo manifest.",
		contacts = reliable and "I can identify a contact if my cooperation is entered into the record."
			or "I do not know who arranged the route.",
		cooperation = needAverage(record) < 40 and "Improve the conditions first, then we can discuss cooperation."
			or reliable and "Record that I am cooperating and I will continue."
			or "What does cooperation get me?",
		medical = (record.needs and (record.needs.medical or 100) < 60)
			and "I need medical treatment. Check the intake record."
			or "I do not require treatment right now.",
		contraband = reliable and (#(record.contraband or {}) > 0
			and "There is prohibited property moving through the block."
			or "Search the shared areas after social period.")
			or "Search me if you think I am hiding something.",
		takeover = reliable and record.suspicion
			and ("You should investigate " .. tostring(record.suspicion.label or "the cell block") .. ".")
			or "I have not heard a credible plan to seize the ship.",
	}
	local response = responses[topic] or "I have no statement on that subject."
	local understood, translator = P.ResolvePrisonerLanguage(record, ply)
	P.BroadcastPrisonerSpeech(record, response)
	if not understood then
		local languageName = P.LanguageName(record.languageID)
		local qualification = P.LanguageQualification(record.languageID)
		return false, record.name .. " answered in " .. languageName
			.. ". A nearby translator with " .. qualification .. " is required."
	end
	local intelligence
	if reliable and (topic == "cargo" or topic == "contacts" or topic == "crew") then
		intelligence = "Interview lead: " .. response
		record.intelligence[#record.intelligence + 1] = {
			time = unix(), topic = topic, text = intelligence, reliability = math.floor(score),
		}
		if not table.HasValue(record.evidence or {}, intelligence) then
			record.evidence[#record.evidence + 1] = intelligence
		end
	elseif reliable and (topic == "takeover" or topic == "contraband") and record.suspicion then
		record.suspicion.discovered = true
		intelligence = "Security warning corroborated by prisoner interview."
	end
	record.interviews = record.interviews or {}
	table.insert(record.interviews, 1, {
		time = unix(), topic = topic, questioner = playerName(ply),
		response = response, reliable = reliable, intelligence = intelligence,
		languageID = record.languageID,
		translator = IsValid(translator) and playerName(translator) or "",
		translatorSteamID = IsValid(translator) and translator:SteamID64() or "",
	})
	while #record.interviews > 20 do table.remove(record.interviews) end
	record.compliance = clamp((record.compliance or 50)
		+ (topic == "cooperation" and reliable and 2 or repeats > 1 and -1 or 0), 0, 100)
	changeRelationship(record, ply, reliable and 1 or 0, "Completed a custody interview.")
	P.AddIncident("interview", playerName(ply) .. " interviewed " .. record.name
		.. " about " .. topic .. ".", record, ply, intelligence and 1 or 0)
	P.SaveState()
	return true, IsValid(translator)
		and ("Translated by " .. playerName(translator) .. ": " .. response)
		or response, response
end

local function cinematicInterviewChoices()
	return {
		{ id = "case", label = "ASK ABOUT THE INSPECTION CASE" },
		{ id = "crew", label = "ASK ABOUT THE OTHER CREW" },
		{ id = "cargo", label = "ASK ABOUT THE CARGO AND MANIFEST" },
		{ id = "contacts", label = "ASK ABOUT CRIMINAL CONTACTS" },
		{ id = "cooperation", label = "DISCUSS COOPERATION" },
		{ id = "medical", label = "ASK ABOUT MEDICAL NEEDS" },
		{ id = "contraband", label = "ASK ABOUT CONTRABAND IN THE BLOCK" },
		{ id = "takeover", label = "ASK ABOUT RIOT OR TAKEOVER PLANS" },
	}
end

local function prisonerGreeting(record)
	if record.status == "rioting" then return "You have nothing to offer me. This ship will be ours." end
	if record.personality == "nervous" then return "Are you here about my case? I will answer what I can." end
	if record.personality == "defiant" or trait(record, "aggressive") then
		return "You already have your report. Ask your questions."
	end
	if trait(record, "informant") then return "Keep this conversation quiet and I may have something useful." end
	if needAverage(record) < 40 then return "Deal with the conditions in this block before asking for help." end
	return "I am listening. What do you want to know?"
end

function P.OpenCinematicInterview(ply, value)
	if cfg.CinematicInterviews == false or not MilBase.CinematicDialogue then return false end
	local record = recordFor(value)
	local ok, reason = interactionCheck(ply, record)
	if not ok then
		if IsValid(ply) and MilBase.Notify then MilBase.Notify(ply, reason, "warn") end
		return false
	end
	record.entity.mb_cinematicConversationUntil = CurTime() + 180
	return MilBase.CinematicDialogue.Open(ply, {
		mode = "physical",
		speaker = record.entity,
		speakerName = record.name,
		speciesName = record.speciesName or (MilBase.SpeciesName
			and MilBase.SpeciesName(record.speciesID)) or "Human",
		languageID = record.languageID or "basic",
		model = record.model,
		title = "REPUBLIC CUSTODY INTERVIEW",
		subtitle = record.id .. " / " .. P.StatusLabel(record.status),
		line = prisonerGreeting(record),
		choices = cinematicInterviewChoices(),
		maxDistance = cfg.CinematicInterviewDistance or 230,
		translatorRadius = cfg.LanguageTranslatorRadius or 320,
		onClose = function()
			if recordFor(record.id) == record and IsValid(record.entity) then
				record.entity.mb_cinematicConversationUntil = nil
			end
		end,
	}, function(actor, topic)
		if recordFor(record.id) ~= record or not IsValid(record.entity) then return false end
		local interviewed, message, canonical = P.InterviewPrisoner(actor, record, topic)
		if not interviewed then
			return { line = message or "The interview cannot continue." }
		end
		return {
			line = canonical or message,
			subtitle = record.id .. " / " .. P.StatusLabel(record.status),
			choices = cinematicInterviewChoices(),
		}
	end)
end

local basePayload = P.DatapadPayload
function P.DatapadPayload(ply, selectedID, message)
	local payload = basePayload(ply, selectedID, message)
	payload.alarm = table.Copy(P.State.alarm or {})
	payload.lockdowns = table.Copy(P.State.lockdowns or {})
	payload.cameras = {}
	payload.zones = {}
	payload.navigation = {
		navmesh = hasNavmesh(),
		pathNodes = #(P.PathGraph.nodes or {}),
	}
	local takeover = takeoverState()
	local objectives = takeoverObjectives()
	payload.takeover = {
		active = takeover.active,
		controlled = takeover.controlled,
		stage = takeover.stage,
		currentIndex = takeover.currentIndex,
		progress = takeover.progress,
		holdSeconds = math.max(5, tonumber(cfg.TakeoverObjectiveHoldSeconds) or 24),
		armed = takeover.armed,
		systemsThreatened = takeover.systemsThreatened,
		commsCaptured = takeover.commsCaptured,
		objectives = {},
	}
	for _, objective in ipairs(objectives) do
		payload.takeover.objectives[#payload.takeover.objectives + 1] = {
			index = objective.index,
			kind = objective.kind,
			label = objective.label,
			configured = objective.marker ~= nil,
			captured = takeover.captured[objective.kind] == true,
			current = takeover.active and takeover.currentIndex == objective.index,
		}
	end
	local zoneSet = {}
	for _, marker in ipairs(P.GetMarkers("camera")) do
		local runtime = P.CameraRuntime[marker.id] or {}
		payload.cameras[#payload.cameras + 1] = {
			id = marker.id,
			name = marker.name,
			pos = marker.pos,
			ang = marker.ang,
			zone = P.CleanID(marker.data and marker.data.zone or "facility", "facility"),
			range = tonumber(marker.data and marker.data.range) or cfg.CameraRange or 1100,
			fov = tonumber(marker.data and marker.data.fov) or cfg.CameraFOV or 78,
			online = runtime.online ~= false and runtime.jammed ~= true,
			lastSeenAt = runtime.lastSeenAt or 0,
			prisonerName = runtime.prisonerName or "",
			event = runtime.event or "CLEAR",
		}
	end
	for _, cell in ipairs(payload.cells or {}) do
		cell.zone = cellZone(cell.id)
		zoneSet[cell.zone] = true
		cell.lockedDown = (payload.lockdowns.facility == true)
			or ((payload.lockdowns.zones or {})[cell.zone] == true)
			or ((payload.lockdowns.cells or {})[cell.id] == true)
	end
	for zone in pairs(zoneSet) do payload.zones[#payload.zones + 1] = zone end
	table.sort(payload.zones)
	for _, summary in ipairs(payload.prisoners or {}) do
		local record = recordFor(summary.id)
		if record then
			normaliseRecord(record)
			local stage, index = currentIntakeStage(record)
			summary.restraintLevel = record.restraintLevel
			summary.restraintLabel = record.restraintLevel >= 2 and "SECURE"
				or record.restraintLevel == 1 and "STANDARD" or "NONE"
			summary.intakeStage = record.intakeStage
			summary.intakeStageLabel = record.intakeStage == "complete" and "COMPLETE"
				or (stage and stage.label or "SEARCH")
			summary.intakeProgress = record.intakeStage == "complete" and #INTAKE_STAGES
				or math.max(0, index - 1)
			summary.intakeTotal = #INTAKE_STAGES
			summary.relation = relationship(record, ply)
			if tostring(summary.id) == tostring(selectedID or payload.selectedID or "") then
				summary.memories = {}
				summary.intelligence = {}
				for index = 1, math.min(8, #(record.memories or {})) do
					summary.memories[#summary.memories + 1] = table.Copy(record.memories[index])
				end
				for index = math.max(1, #(record.intelligence or {}) - 7),
				#(record.intelligence or {}) do
					summary.intelligence[#summary.intelligence + 1]
						= table.Copy(record.intelligence[index])
				end
			end
			summary.suspicion = record.suspicion and record.suspicion.discovered
				and table.Copy(record.suspicion) or nil
			summary.escortAssist = record.escortAssistSteamID
			summary.movementState = IsValid(record.entity)
				and record.entity:GetMovementState() or "offline"
			summary.zone = record.cellID ~= "" and cellZone(record.cellID) or record.lastKnownZone
			local direct = P.PlayerUnderstandsLanguage(ply, record.languageID)
			local resolved, translator = P.ResolvePrisonerLanguage(record, ply)
			summary.languageID = record.languageID
			summary.languageName = P.LanguageName(record.languageID)
			summary.speciesID = record.speciesID or "human"
			summary.speciesName = record.speciesName or (MilBase.SpeciesName
				and MilBase.SpeciesName(record.speciesID)) or "Human"
			summary.languageCertification = P.LanguageCertification(record.languageID)
			summary.languageQualification = P.LanguageQualification(record.languageID)
			summary.languageUnderstood = direct
			summary.translationAvailable = resolved
			summary.translatorName = IsValid(translator) and playerName(translator) or ""
			if summary.lastInterview then
				summary.lastInterview = table.Copy(summary.lastInterview)
				summary.lastInterview.languageID = summary.lastInterview.languageID
					or record.languageID
				if not resolved then
					local language = P.Language(record.languageID) or {}
					summary.lastInterview.response = tostring(language.untranslated
						or "[Unintelligible speech]")
					summary.lastInterview.untranslated = true
					summary.lastInterview.translator = ""
				elseif IsValid(translator) then
					summary.lastInterview.translator = playerName(translator)
				end
			end
		end
	end
	return payload
end

local baseHandleDatapad = P.HandleDatapadRequest
function P.HandleDatapadRequest(ply, action, data, sendData)
	data = istable(data) and data or {}
	local record = recordFor(data.prisonerID or data.id)
	local handled, ok, message = false, false, nil
	if action == "open_interview" and record then
		handled = true
		ok = P.OpenCinematicInterview(ply, record)
		message = ok and "Cinematic interview opened." or "Unable to begin the interview."
	elseif action == "interview" and record then
		handled = true
		ok, message = P.InterviewPrisoner(ply, record, data.topic)
	elseif action == "search" and record then
		handled = true
		ok, message = P.SearchPrisoner(ply, record)
	elseif action == "restrain" and record then
		handled = true
		ok, message = P.SecurePrisoner(ply, record)
	elseif action == "command" and record then
		handled = true
		ok, message = P.RunGuardCommand(ply, record.entity, data.command)
	elseif action == "negotiate" then
		handled = true
		ok, message = P.NegotiateRiot(ply)
	elseif action == "secure_takeover" then
		handled = true
		ok, message = P.SecureTakeoverObjective(ply)
	elseif action == "manual_alarm" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetAlarm(true, data.reason or "Manual guard alarm",
			data.level or "warning", data.zone or "facility", ply)
	elseif action == "clear_alarm" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetAlarm(false, "", "normal", "", ply)
	elseif action == "lockdown" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetLockdown("facility", "", true, ply)
	elseif action == "clear_lockdown" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetLockdown("facility", "", false, ply)
	elseif action == "lockdown_zone" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetLockdown("zone", data.zone, data.enabled ~= false, ply)
	elseif action == "lockdown_cell" and P.CanCommand(ply) then
		handled = true
		ok, message = P.SetLockdown("cell", data.cellID, data.enabled ~= false, ply)
	elseif action == "rollcall" and P.CanCommand(ply) then
		handled = true
		ok, message = P.RollCall(ply)
	elseif action == "automatic_schedule" and P.CanCommand(ply) then
		handled = true
		P.State.lockdowns = P.State.lockdowns or { facility = false, zones = {}, cells = {} }
		P.State.lockdowns.facility = false
		local rows = cfg.Schedule or {}
		if #rows > 0 then
			P.State.scheduleIndex = (tonumber(P.State.scheduleIndex) or 0) % #rows + 1
			local row = rows[P.State.scheduleIndex]
			P.ApplySchedule(row.id, ply, false, row.seconds)
			ok, message = true, "Automatic prison schedule resumed."
		else
			ok, message = false, "No automatic schedule is configured"
		end
	end
	if not handled then return baseHandleDatapad(ply, action, data, sendData) end
	if record then
		ply:SetNWString("mb_prisonSelected", record.id)
	end
	if sendData then
		sendData(ply, "prison_ops", "state",
			P.DatapadPayload(ply, record and record.id or data.prisonerID, message))
	end
end

hook.Add("PlayerInitialSpawn", "MilBase.Prison.UpgradeAlarmState", function(ply)
	timer.Simple(6, function()
		if IsValid(ply) and P.CanUse(ply) and P.State and P.State.alarm then
			net.Start(NET_ALERT)
				net.WriteTable(P.State.alarm)
			net.Send(ply)
		end
	end)
end)

hook.Add("PlayerUse", "MilBase.Prison.PhysicalAlarmPanel", function(ply, ent)
	if not IsValid(ply) or not IsValid(ent) or not P.CanCommand(ply)
	or ply:GetNWBool("mb_cuffed", false)
	or CurTime() < (ply.mb_nextPrisonAlarmPanel or 0) then return end
	local mapID = ent.MapCreationID and tonumber(ent:MapCreationID()) or -1
	for _, marker in ipairs(P.GetMarkers("alarm")) do
		local linked = (tonumber(marker.mapID) or -2) >= 0
			and (tonumber(marker.mapID) or -2) == mapID
		if not linked and marker.class ~= "" and ent:GetClass() == marker.class
		and ent:GetPos():DistToSqr(marker.pos) <= 96 ^ 2 then linked = true end
		if linked then
			ply.mb_nextPrisonAlarmPanel = CurTime() + 1
			local active = not (P.State.alarm and P.State.alarm.active)
			local _, message = P.SetAlarm(active,
				active and ("Manual alarm panel: " .. marker.name) or "",
				active and "warning" or "normal",
				marker.data and marker.data.zone or "facility", ply)
			MilBase.Notify(ply, message, active and "warn" or "ok")
			return false
		end
	end
end)

hook.Add("PlayerDisconnected", "MilBase.Prison.ReleaseEscortAssist", function(ply)
	local id = ply:SteamID64()
	for _, record in pairs(P.State.prisoners or {}) do
		if record.escortSteamID == id then
			record.escortSteamID = ""
			record.escortAssistSteamID = ""
			local transfer = P.State.transfers and P.State.transfers[tostring(record.transfer or "")]
			record.status = transfer and (transfer.status == "pickup_landed"
				or transfer.status == "boarding") and "transfer_ready"
				or (record.cellID ~= "" and "holding" or "awaiting_escort")
			record.targetPos = nil
			record.targetAng = nil
			if P.UpdateNetwork then P.UpdateNetwork(record) end
		end
		if record.escortAssistSteamID == id then
			record.escortAssistSteamID = ""
			if record.status == "escorting" and record.risk == "critical" then
				record.status = "escort_waiting"
			end
		end
	end
	P.SaveState()
end)

timer.Create("MilBase.Prison.UpgradeRestore", 1, 0, function()
	if not P._loaded or not P._layoutLoaded then return end
	timer.Remove("MilBase.Prison.UpgradeRestore")
	for _, transfer in pairs(P.State.transfers or {}) do
		if transfer.status == "pickup_queued" or transfer.status == "pickup_inbound"
		or transfer.status == "pickup_landed" or transfer.status == "boarding"
		or transfer.status == "departing" then
			transfer.status = "accepted"
			transfer.transport = nil
			transfer.pickupError = "Pickup reset after server restart"
		end
	end
	for _, record in pairs(P.State.prisoners or {}) do
		normaliseRecord(record)
		local transfer = P.State.transfers and P.State.transfers[tostring(record.transfer or "")]
		if transfer and transfer.status == "accepted"
		and (record.status == "boarding" or record.status == "escorting"
			or record.status == "escort_waiting") then
			record.escortSteamID = ""
			record.escortAssistSteamID = ""
			record.boarded = false
			if IsValid(record.entity) then
				record.entity:SetNoDraw(false)
				record.entity:SetSolid(SOLID_BBOX)
			end
			local marker = homeTarget(record)
			setRecordTarget(record, marker, "transfer_ready", "")
		elseif record.status == "escorting" or record.status == "escort_waiting" then
			record.escortSteamID = ""
			record.escortAssistSteamID = ""
			record.status = record.intakeComplete
				and (record.cellID ~= "" and "incarcerated" or "overflow")
				or "awaiting_escort"
		elseif record.status ~= "rioting"
		and record.status ~= "awaiting_escort"
		and record.status ~= "transfer_pending"
		and record.status ~= "transfer_ready" then
			local marker, status = scheduleTarget(record, P.State.schedule)
			setRecordTarget(record, marker, status, "")
		end
	end
	P.SaveState()
end)

MilBase.RegisterChatCommand("prisonalarm", {
	help = "Prison alarm: /prisonalarm on [reason] or /prisonalarm off",
	func = function(ply, args)
		if not P.CanCommand(ply) then return end
		if P.CleanID(args[1], "on") == "off" then
			local _, message = P.SetAlarm(false, "", "normal", "", ply)
			MilBase.Notify(ply, message, "ok")
		else
			local reason = table.concat(args, " ", 2)
			local _, message = P.SetAlarm(true,
				reason ~= "" and reason or "Manual guard alarm", "warning", "facility", ply)
			MilBase.Notify(ply, message, "warn")
		end
	end,
})

MilBase.RegisterChatCommand("prisonnav", {
	help = "(Staff) Show prison navigation diagnostics.",
	func = function(ply)
		if not P.CanConfigure(ply) then return end
		ply:SetNWBool("mb_prison_debug", not ply:GetNWBool("mb_prison_debug", false))
		MilBase.Notify(ply, string.format("Prison navigation debug %s: %s navmesh, %d path nodes.",
			ply:GetNWBool("mb_prison_debug") and "enabled" or "disabled",
			hasNavmesh() and "using" or "no", #(P.PathGraph.nodes or {})), "info")
	end,
})

MilBase.RegisterChatCommand("prisonlanguage", {
	help = "(Staff) Reapply a prisoner's species-native language: /prisonlanguage <prisoner id>",
	func = function(ply, args)
		if not P.CanCommand(ply) then return end
		local prisonerID = tostring(args[1] or "")
		local record = recordFor(prisonerID)
		if not record then
			MilBase.Notify(ply, "Prisoner not found. Use the PR-... custody ID.", "warn")
			return
		end
		local languageID = MilBase.SpeciesNativeLanguage
			and MilBase.SpeciesNativeLanguage(record.speciesID) or "basic"
		record.languageID = languageID
		record.languageManuallyAssigned = false
		record.language = nil
		record.civilianPackLanguage = ""
		if P.UpdateNetwork then P.UpdateNetwork(record) end
		P.AddIncident("language", playerName(ply) .. " updated " .. record.name
			.. "'s custody language to " .. P.LanguageName(languageID) .. ".",
			record, ply, 0)
		P.SaveState()
		MilBase.Notify(ply, record.name .. " now speaks "
			.. P.LanguageName(languageID) .. ".", "ok")
	end,
})
