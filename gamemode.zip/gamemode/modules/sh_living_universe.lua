-- Shared labels for the persistent vessel-life simulation.

if MilBase._LivingUniverseSharedLoaded then return end
MilBase._LivingUniverseSharedLoaded = true

MilBase.LivingUniverse = MilBase.LivingUniverse or {}
local L = MilBase.LivingUniverse

L.Version = 1

L.ProfessionNames = {
	freight = "INDEPENDENT FREIGHT HAULER",
	courier = "COURIER SERVICE",
	passenger = "PASSENGER TRANSPORT",
	relief = "RELIEF AND MEDICAL LOGISTICS",
	salvage = "LICENSED SALVAGE CREW",
	smuggler = "UNREGISTERED FREIGHT OPERATOR",
	raider = "PIRATE RAIDER",
	republic_patrol = "REPUBLIC PATROL CREW",
	republic_logistics = "REPUBLIC FLEET LOGISTICS",
	republic_scout = "REPUBLIC RECONNAISSANCE",
	cis_patrol = "CIS PATROL UNIT",
	cis_logistics = "CIS LOGISTICS UNIT",
	cis_recon = "CIS RECONNAISSANCE UNIT",
	orbital_service = "LOCAL ORBITAL SERVICE",
}

L.EventNames = {
	contract = "CONTRACT",
	arrival = "ARRIVAL",
	departure = "DEPARTURE",
	family = "FAMILY",
	crew = "CREW",
	maintenance = "MAINTENANCE",
	training = "TRAINING",
	medical = "MEDICAL",
	danger = "DANGER",
	battle = "BATTLE",
	trade = "TRADE",
	reputation = "REPUTATION",
}

L.DialogueActions = {
	crew_manifest = true,
	crew_story = true,
	crew_work = true,
	crew_news = true,
	crew_supplies = true,
}
