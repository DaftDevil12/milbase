--[[
	Engineering module: field maintenance for LVS vehicles (lvs_base).
	https://github.com/SpaxscE/lvs_base

	CROUCH + hold [E] on any LVS vehicle for the service menu:
	  Check Condition - anyone: hull, fuel, wreck state
	  Repair          - Combat Engineers with a Repair Kit; timed channel,
	                    200 hull per use from a 600 pool. Destroyed wrecks
	                    take a long REBUILD instead (double time & parts)
	  Refuel          - Combat Engineers with a Jerry Can (up to 50%/use)

	While crouched you can't accidentally climb in - standing E enters
	the vehicle as normal. Aiming at an LVS vehicle shows its condition.

	Every LVS call (GetHP/SetHP/Repair/GetFuel...) is guarded, so this
	module is inert without lvs_base installed and tolerant of vehicles
	that lack fuel or destruction mechanics.
]]

local cfg = MilBase.Config

local function isLVS(ent)
	return IsValid(ent) and ent.LVS == true
end

local function isEngineer(ply)
	return ply:MBHasCert("engineer") or ply:IsAdmin()
end

local function hullInfo(veh)
	if not veh.GetHP or not veh.GetMaxHP then return nil end
	return veh:GetHP(), math.max(veh:GetMaxHP(), 1)
end

local function fuelInfo(veh)
	if not veh.GetFuel then return nil end
	local max = veh.GetMaxFuel and veh:GetMaxFuel() or 1
	return veh:GetFuel(), math.max(max, 0.001)
end

local function isWrecked(veh)
	return veh.GetDestroyed and veh:GetDestroyed() or false
end

-- First usable kit of the right kind in the engineer's inventory (server;
-- searches both the stash and the backpack).
local function findEngItem(ply, action)
	local inv = MilBase.GetInventory(ply)
	local pools = { inv.items }
	if inv.pack then table.insert(pools, inv.pack.items) end

	for _, pool in ipairs(pools) do
		for _, it in ipairs(pool) do
			local def = MilBase.Items[it.id]
			if def and def.eng and def.eng.action == action
			and (not def.cert or ply:MBHasCert(def.cert) or ply:IsAdmin()) then
				return it
			end
		end
	end
end

MilBase.FindEngItem = findEngItem -- reused by the subsystem repairs

--------------------------------------------------------------------------
-- Server: the engineering channel
--------------------------------------------------------------------------

if SERVER then

	-- Crouching = service mode: don't enter the vehicle.
	hook.Add("PlayerUse", "MilBase.EngineeringServiceMode", function(ply, ent)
		if isLVS(ent) and ply:Crouching() then return false end
	end)

	local function cancelChannel(ply, notify)
		if not ply.mb_eng then return end
		ply.mb_eng = nil
		ply:SetNWFloat("mb_medprog", 0)
		if notify then MilBase.Notify(ply, "Work interrupted!") end
	end

	-- vehicle = optional; resolved from aim when used straight from the
	-- inventory. subsystem = "hull" (default), "shields", "engines", "weapons".
	function MilBase.UseEngineeringItem(ply, item, vehicle, subsystem)
		local def = MilBase.Items[item.id]
		local eng = def and def.eng
		if not eng then return end

		if def.cert and not ply:MBHasCert(def.cert) and not ply:IsAdmin() then
			local cert = MilBase.Certs[def.cert]
			MilBase.Notify(ply, "Requires certification: " .. (cert and cert.name or def.cert))
			return
		end
		if ply.mb_eng or ply.mb_med then
			MilBase.Notify(ply, "Your hands are already busy.")
			return
		end

		vehicle = vehicle or ply:GetEyeTrace().Entity
		if not isLVS(vehicle) then
			MilBase.Notify(ply, "Look at an LVS vehicle to use that.")
			return
		end
		if vehicle:NearestPoint(ply:GetPos()):DistToSqr(ply:GetPos()) > 160 * 160 then
			MilBase.Notify(ply, "Get closer to the vehicle.")
			return
		end

		local rebuild = false
		subsystem = subsystem or "hull"

		if eng.action == "repair" and subsystem ~= "hull" then
			-- Subsystem repair (shields / engines / weapons / ...).
			if not MilBase.VehSysApplies or not MilBase.VehSysApplies(vehicle, subsystem) then
				MilBase.Notify(ply, "That system isn't fitted on this vehicle.")
				return
			end
			if MilBase.GetVehSysCondition(vehicle, subsystem) >= 100 then
				MilBase.Notify(ply, "That system is fully operational.")
				return
			end

		elseif eng.action == "repair" then
			local hp, maxhp = hullInfo(vehicle)
			if not hp then
				MilBase.Notify(ply, "This vehicle can't be field-repaired.")
				return
			end

			rebuild = isWrecked(vehicle)
			if rebuild and not vehicle.Repair then
				MilBase.Notify(ply, "This wreck is beyond repair.")
				return
			end
			if not rebuild and hp >= maxhp then
				MilBase.Notify(ply, "The hull is at full integrity.")
				return
			end
			if rebuild and (item.charges or 0) < eng.amount * 2 then
				MilBase.Notify(ply, "Not enough parts left to rebuild a wreck ("
					.. (eng.amount * 2) .. " needed).")
				return
			end

		elseif eng.action == "fuel" then
			local fuel, maxFuel = fuelInfo(vehicle)
			if not fuel then
				MilBase.Notify(ply, "This vehicle doesn't take fuel.")
				return
			end
			if fuel >= maxFuel then
				MilBase.Notify(ply, "The tank is full.")
				return
			end
		end

		local duration = eng.time * (rebuild and 2.5 or 1)

		ply.mb_eng = {
			uid = item.uid,
			veh = vehicle,
			action = eng.action,
			rebuild = rebuild,
			subsystem = subsystem,
			finish = CurTime() + duration,
			duration = duration,
		}

		local label
		if rebuild then
			label = "REBUILDING"
		elseif eng.action == "repair" and subsystem ~= "hull" then
			label = "REPAIR " .. string.upper(subsystem)
		else
			label = string.upper(def.name)
		end
		ply:SetNWString("mb_medaction", label .. " — " .. string.upper(vehicle.PrintName or "VEHICLE"))
		ply:SetNWFloat("mb_medprog", 0.01)
	end

	local function finishChannel(ply, item, eng, ch)
		local veh = ch.veh
		if not isLVS(veh) then return end

		local used = 0

		if ch.action == "repair" and ch.subsystem and ch.subsystem ~= "hull" then
			if MilBase.RepairVehSubsystem then
				MilBase.RepairVehSubsystem(veh, ch.subsystem, cfg.SubsystemRepairPerUse or 50)
			end
			used = 100 -- parts cost per subsystem repair
			MilBase.Notify(ply, string.upper(ch.subsystem) .. " restored to "
				.. math.Round(MilBase.GetVehSysCondition(veh, ch.subsystem)) .. "%.")

		elseif ch.action == "repair" then
			local hp, maxhp = hullInfo(veh)
			if not hp then return end

			if ch.rebuild then
				veh:Repair()
				if veh.SetHP then
					veh:SetHP(math.ceil(maxhp * 0.3))
				end
				used = eng.amount * 2
				MilBase.Notify(ply, (veh.PrintName or "The vehicle") .. " is running again (30% hull).")
			else
				local heal = math.min(eng.amount, maxhp - hp, item.charges or eng.amount)
				if veh.SetHP then
					veh:SetHP(hp + heal)
				end
				used = heal
				MilBase.Notify(ply, "Repaired " .. math.Round(heal) .. " hull.")
			end

		elseif ch.action == "fuel" then
			local fuel, maxFuel = fuelInfo(veh)
			if not fuel then return end

			local missingPct = (maxFuel - fuel) / maxFuel * 100
			local addPct = math.min(eng.amount, missingPct, item.charges or eng.amount)

			if veh.SetFuel then
				veh:SetFuel(math.min(maxFuel, fuel + maxFuel * addPct / 100))
			end
			used = addPct
			MilBase.Notify(ply, "Refueled " .. math.Round(addPct) .. "%.")
		end

		if used > 0 then hook.Run("MilBase.EngineeringRepairCompleted", ply, veh, used, ch.action, ch.subsystem) end

		if item.charges then
			item.charges = item.charges - math.ceil(used)
			if item.charges <= 0 then
				MilBase.RemoveItemUID(ply, item.uid)
			else
				MilBase.MarkInvDirty(ply)
			end
		else
			MilBase.RemoveItemUID(ply, item.uid, 1)
		end

		veh:EmitSound("items/battery_pickup.wav")
	end

	local TICK = 0.2
	local nextTick = 0

	hook.Add("Think", "MilBase.EngineeringThink", function()
		if CurTime() < nextTick then return end
		nextTick = CurTime() + TICK

		for _, ply in ipairs(player.GetAll()) do
			local ch = ply.mb_eng
			if not ch then continue end

			local item = MilBase.InvFindAny(MilBase.GetInventory(ply), ch.uid)
			local def = item and MilBase.Items[item.id]

			if not ply:Alive() or not isLVS(ch.veh) or not def or not def.eng
			or ch.veh:NearestPoint(ply:GetPos()):DistToSqr(ply:GetPos()) > 180 * 180 then
				cancelChannel(ply, true)
				continue
			end

			if CurTime() >= ch.finish then
				ply.mb_eng = nil
				ply:SetNWFloat("mb_medprog", 0)
				finishChannel(ply, item, def.eng, ch)
			else
				ply:SetNWFloat("mb_medprog", 1 - (ch.finish - CurTime()) / ch.duration)

				-- Wrench clanks while working.
				if (ply.mb_engClank or 0) < CurTime() then
					ply.mb_engClank = CurTime() + 0.9
					ch.veh:EmitSound("physics/metal/metal_box_impact_medium"
						.. math.random(1, 3) .. ".wav", 70, math.random(95, 105))
				end
			end
		end
	end)

	hook.Add("PlayerDeath", "MilBase.EngineeringCancel", function(ply)
		cancelChannel(ply)
	end)

else -- CLIENT

	-- Condition readout when aiming at an LVS vehicle.
	hook.Add("HUDPaint", "MilBase.VehicleID", function()
		if MilBase.InEventView() then return end
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then return end

		local tr = lp:GetEyeTrace()
		local veh = tr.Entity
		if not isLVS(veh) then return end
		if tr.HitPos:DistToSqr(lp:GetPos()) > 320 * 320 then return end

		local ui = MilBase.UI
		local screen = (veh:GetPos() + Vector(0, 0, veh:OBBMaxs().z + 16)):ToScreen()
		if not screen.visible then return end

		draw.SimpleTextOutlined(string.upper(veh.PrintName or "VEHICLE"), "MB.Small",
			screen.x, screen.y - 20, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)

		-- Subsystem status board.
		local yoff = -4
		for _, s in ipairs(MilBase.VehSubsystems or {}) do
			if MilBase.VehSysApplies(veh, s.id) then
				local cond = MilBase.GetVehSysCondition(veh, s.id)
				local col = cond > 60 and ui.ok or (cond > 0 and ui.warn or ui.danger)
				local txt = cond <= 0 and (string.upper(s.name) .. "  OFFLINE")
					or (string.upper(s.name) .. "  " .. math.Round(cond) .. "%")
				draw.SimpleTextOutlined(txt, "MB.Tiny", screen.x, screen.y + yoff,
					col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
				yoff = yoff + 15
			end
		end

		local fuel, maxFuel = fuelInfo(veh)
		if fuel then
			draw.SimpleTextOutlined("FUEL  " .. math.Round(fuel / maxFuel * 100) .. "%", "MB.Tiny",
				screen.x, screen.y + yoff, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
			yoff = yoff + 15
		end

		if isWrecked(veh) then
			draw.SimpleTextOutlined("WRECKED — ENGINEER REQUIRED", "MB.Small",
				screen.x, screen.y + yoff + 2, ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		else
			draw.SimpleTextOutlined("HOLD [G] — VEHICLE SERVICE", "MB.Tiny",
				screen.x, screen.y + yoff + 2, ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end
	end)

end

--------------------------------------------------------------------------
-- Vehicle self-menu actions (hold [G] near / aimed at an LVS vehicle)
--------------------------------------------------------------------------

-- The LVS vehicle a player is servicing: the one they're aiming at, else the
-- nearest within range. Used by every hold-G vehicle action.
function MilBase.ServiceableLVS(ply, range)
	range = range or 260
	local origin = ply:GetPos()

	local tr = ply:GetEyeTrace()
	if isLVS(tr.Entity)
	and tr.Entity:NearestPoint(origin):DistToSqr(origin) <= range * range then
		return tr.Entity
	end

	local best, bd
	for _, e in ipairs(ents.FindInSphere(origin, range)) do
		if isLVS(e) then
			local d = e:NearestPoint(origin):DistToSqr(origin)
			if not bd or d < bd then best, bd = e, d end
		end
	end
	return best
end

MilBase.RegisterSelfAction("veh_status", {
	name = "Check Vehicle Condition",
	order = 40,
	visible = function(lp) return IsValid(MilBase.ServiceableLVS(lp)) end,
	run = function(ply)
		local veh = MilBase.ServiceableLVS(ply)
		if not IsValid(veh) then return end

		local info = {}
		for _, s in ipairs(MilBase.VehSubsystems or {}) do
			if MilBase.VehSysApplies(veh, s.id) then
				local cond = math.Round(MilBase.GetVehSysCondition(veh, s.id))
				table.insert(info, s.name .. " " .. (cond <= 0 and "OFFLINE" or (cond .. "%")))
			end
		end
		if isWrecked(veh) then table.insert(info, "WRECKED") end

		local fuel, maxFuel = fuelInfo(veh)
		if fuel then table.insert(info, "Fuel " .. math.Round(fuel / maxFuel * 100) .. "%") end

		MilBase.Notify(ply, (veh.PrintName or "Vehicle") .. " — "
			.. (#info > 0 and table.concat(info, "  •  ") or "no diagnostics available"))
	end,
})

MilBase.RegisterSelfAction("veh_repair", {
	name = function(lp)
		local veh = MilBase.ServiceableLVS(lp)
		return (IsValid(veh) and isWrecked(veh)) and "Rebuild Wreck" or "Repair Hull"
	end,
	order = 41,
	visible = function(lp)
		local veh = MilBase.ServiceableLVS(lp)
		if not IsValid(veh) or not isEngineer(lp) or veh.GetHP == nil then return false end
		if isWrecked(veh) then return true end
		if MilBase.GetVehSysCondition then
			return MilBase.GetVehSysCondition(veh, "hull") < 100
		end
		return true
	end,
	run = function(ply)
		local veh = MilBase.ServiceableLVS(ply)
		if not IsValid(veh) then return end
		local item = findEngItem(ply, "repair")
		if not item then
			MilBase.Notify(ply, "You need a Repair Kit.")
			return
		end
		MilBase.UseEngineeringItem(ply, item, veh, "hull")
	end,
})

MilBase.RegisterSelfAction("veh_refuel", {
	name = "Refuel Vehicle",
	order = 42,
	visible = function(lp)
		local veh = MilBase.ServiceableLVS(lp)
		return IsValid(veh) and isEngineer(lp) and veh.GetFuel ~= nil
	end,
	run = function(ply)
		local veh = MilBase.ServiceableLVS(ply)
		if not IsValid(veh) then return end
		local item = findEngItem(ply, "fuel")
		if not item then
			MilBase.Notify(ply, "You need a Jerry Can.")
			return
		end
		MilBase.UseEngineeringItem(ply, item, veh)
	end,
})
