--[[
	Comms / radio: hold [H] to pick a channel; your voice AND typed chat then
	go out on that channel to everyone allowed to hear it.

	Channels: Local (proximity), Republic, Command, Regimental, Training, ATC,
	Joint Ops, Event Enemy. High Command hears every friendly channel and can
	speak on any.
	Radio is private - non-listeners don't hear it, even up close (switch to
	Local for proximity RP). A Jammer can black out radio in an area / map-wide.

	Roles are defined in config/sh_comms.lua. Encrypted comms + the Relay
	entities and corpse-comms hacking are separate follow-up layers.
]]

local cfg = MilBase.Config

MilBase.CommChannels = MilBase.CommChannels or {}
MilBase.CommOrder = MilBase.CommOrder or {}

function MilBase.RegisterCommChannel(id, data)
	data.id = id
	data.order = data.order or 50
	data.name = data.name or id
	data.color = data.color or Color(200, 200, 200)
	if data.radio == nil then data.radio = true end
	if not MilBase.CommChannels[id] then table.insert(MilBase.CommOrder, id) end
	MilBase.CommChannels[id] = data
	table.sort(MilBase.CommOrder, function(a, b)
		return MilBase.CommChannels[a].order < MilBase.CommChannels[b].order
	end)
end

local function HC(p)  return MilBase.CommsIsHighCommand and MilBase.CommsIsHighCommand(p) end
local function OFF(p) return MilBase.CommsIsOfficer and MilBase.CommsIsOfficer(p) end
local function PILOT(p) return MilBase.CommsIsPilot and MilBase.CommsIsPilot(p) end
local function isStaff(p) return MilBase.CommsIsStaff and MilBase.CommsIsStaff(p) end
local function sameFaction(a, b) return a:MBFactionID() == b:MBFactionID() end
local function isEE(p) return MilBase.IsEventEnemy and MilBase.IsEventEnemy(p) end
local function isGM(p) return p:GetNWBool("mb_eventmode", false) end

-- A friendly soldier who sliced a fallen enemy's transceiver (sh_eventenemies.lua)
-- taps the encrypted Hostile Net until they die.
function MilBase.HasHackedEEComms(ply)
	return IsValid(ply) and ply:GetNWBool("mb_ee_hacked", false)
end
local function hackedEE(p) return MilBase.HasHackedEEComms(p) end

-- Event enemies live entirely on the Hostile Net - they neither hear nor speak
-- on friendly channels (even though they keep their old faction id). The "ee"
-- side is always permitted here; WHO on the friendly side actually hears/speaks
-- it (High Command, staff, or a corpse-comms hacker) is gated by the "ee"
-- channel's own canSpeak/canHear/clearFor (registered further down).
local function sideOK(listener, talker, chId)
	if chId == "ee" then return true end
	return not isEE(listener) and not isEE(talker)
end

--------------------------------------------------------------------------
-- Joint operations (temporary faction<->faction shared comms), synced
--------------------------------------------------------------------------

MilBase.JointOps = MilBase.JointOps or {} -- { { a = factionId, b = factionId }, ... }

function MilBase.InJointOp(ply)
	local f = ply:MBFactionID()
	for _, op in ipairs(MilBase.JointOps) do
		if op.a == f or op.b == f then return true end
	end
	return false
end

function MilBase.JointOpShared(l, t)
	local lf, tf = l:MBFactionID(), t:MBFactionID()
	for _, op in ipairs(MilBase.JointOps) do
		if (op.a == lf or op.b == lf) and (op.a == tf or op.b == tf) then return true end
	end
	return false
end

--------------------------------------------------------------------------
-- Jamming (radio only; local proximity voice is never jammed)
--------------------------------------------------------------------------

-- Is a radio channel jammed at a world point? Reads the per-player jammer NW
-- vars so it resolves on both realms.
function MilBase.CommsJammed(pos, chId)
	if cfg.CommsJammerEnabled == false then return false end
	for _, j in ipairs(player.GetAll()) do
		local mode = j:GetNWString("mb_jam_mode", "")
		if mode == "" then continue end
		-- Permission is checked continuously so a class/cert change disables a
		-- previously deployed jammer immediately rather than leaving stale NW state active.
		if MilBase.CommsCanJam and not MilBase.CommsCanJam(j) then continue end

		local jamsThis = (mode == "ee" and chId == "ee") or (mode == "friendly" and chId ~= "ee")
		if not jamsThis then continue end

		if j:GetNWBool("mb_jam_mapwide", false) then return true end
		local r = j:GetNWInt("mb_jam_radius", cfg.CommsJammerRadius or 3500)
		if pos:DistToSqr(j:GetPos()) <= r * r then return true end
	end
	return false
end

--------------------------------------------------------------------------
-- Channels
--------------------------------------------------------------------------

MilBase.RegisterCommChannel("local", {
	name = "Local / Proximity", color = Color(210, 210, 210), order = 0, radio = false,
	canSpeak = function(ply) return true end,
})

-- Republic-wide radio. Unlike Command comms, every friendly regiment can use
-- this net, making /c and /comms the simple all-Republic text channel.
MilBase.RegisterCommChannel("republic", {
	name = "Republic", color = Color(90, 170, 255), order = 5,
	cmds = { "c", "comms" },
	canSpeak = function(ply) return not isEE(ply) end,
	canHear = function(listener) return not isEE(listener) end,
})

MilBase.RegisterCommChannel("command", {
	name = "Command", color = Color(232, 120, 90), order = 10,
	cmds = { "command" },
	canSpeak = function(ply) return OFF(ply) end,
	canHear = function(l, t) return sameFaction(l, t) or HC(l) end,
})

MilBase.RegisterCommChannel("regiment", {
	name = "Regimental", color = Color(120, 180, 240), order = 20,
	cmds = { "reg", "regiment" },
	canSpeak = function(ply) return true end,
	canHear = function(l, t) return sameFaction(l, t) or HC(l) end,
})

-- Squad radio: routes to your current fireteam (sh_squads.lua). No chat alias
-- here - /s routes squad chat through this channel so muting/jamming apply -
-- but voice and hold-[H] selection work natively. Only usable while squadded.
MilBase.RegisterCommChannel("squad", {
	name = "Squad", color = Color(255, 198, 60), order = 22,
	canSpeak = function(ply) return ply:GetNWString("mb_squad", "") ~= "" end,
	canHear = function(l, t)
		local s = t:GetNWString("mb_squad", "")
		return s ~= "" and l:GetNWString("mb_squad", "") == s
	end,
})

MilBase.RegisterCommChannel("training", {
	name = "Training", color = Color(150, 205, 150), order = 30,
	cmds = { "training", "train" },
	canSpeak = function(ply) return true end,
	canHear = function(l, t) return sameFaction(l, t) or HC(l) end,
})

MilBase.RegisterCommChannel("atc", {
	name = "ATC", color = Color(232, 200, 120), order = 40,
	cmds = { "atc" },
	canSpeak = function(ply) return PILOT(ply) or HC(ply) end,
	canHear = function(l, t) return (sameFaction(l, t) and (PILOT(l) or HC(l))) or HC(l) end,
})

MilBase.RegisterCommChannel("jointop", {
	name = "Joint Operations", color = Color(200, 150, 232), order = 50,
	cmds = { "joint", "jo" },
	canSpeak = function(ply) return MilBase.InJointOp(ply) or HC(ply) end,
	canHear = function(l, t) return HC(l) or MilBase.JointOpShared(l, t) end,
})

-- The Hostile Net is ENCRYPTED enemy comms: event enemies (and game masters)
-- speak and hear it clear; friendly High Command and staff receive only static
-- (voice) / gibberish (chat) until they hack a working Relay to decrypt it
-- temporarily. Regular friendly players don't hear it at all - UNLESS they've
-- sliced a fallen enemy's transceiver (hackedEE), which gives clear access
-- (hear + transmit) to the hostile net until they die (see sh_eventenemies.lua).
MilBase.RegisterCommChannel("ee", {
	name = "Hostile Net", color = Color(220, 90, 80), order = 60,
	cmds = { "enemy", "hostile" },
	encrypted = true,
	canSpeak = function(ply) return isEE(ply) or isGM(ply) or hackedEE(ply) end,
	canHear = function(l, t) return isEE(l) or isGM(l) or HC(l) or isStaff(l) or hackedEE(l) end,
	clearFor = function(ply) return isEE(ply) or isGM(ply) or hackedEE(ply) end, -- hear it natively
})

--------------------------------------------------------------------------
-- Shared routing helpers
--------------------------------------------------------------------------

local function currentChannel(ply)
	local id = ply:GetNWString("mb_comm", "local")
	return id, MilBase.CommChannels[id]
end
MilBase.CurrentChannel = currentChannel

-- Per-listener channel muting. The client owns the preference (persisted to a
-- data file) and syncs the muted set to the server, which stores it on the
-- player so both voice (VoiceCanHear) and chat (SendCommsChat) honour it.
-- Local / proximity is never mutable.
MilBase.CommMute = MilBase.CommMute or {}

function MilBase.IsChannelMuted(listener, chId)
	if chId == "local" then return false end
	if CLIENT then
		if listener == LocalPlayer() then return MilBase.CommMute[chId] == true end
		return false
	end
	return listener.mb_commMute ~= nil and listener.mb_commMute[chId] == true
end

-- Can a listener understand an encrypted channel (vs static / gibberish)?
-- Native participants (clearFor) hear it clear; everyone else - the friendly
-- High Command / staff who intercept it - need a live Relay decrypt.
function MilBase.CanDecrypt(ply, chId)
	local ch = MilBase.CommChannels[chId]
	if not ch or not ch.encrypted then return true end
	if ch.clearFor and ch.clearFor(ply) then return true end
	return ply:GetNWFloat("mb_decrypt", 0) > CurTime()
end

-- Scramble text into radio-noise symbols for un-decrypted listeners.
local GIB = { "░", "▒", "▓", "█", "╫", "╪", "┼", "╬", "╣", "╠", "◘", "►", "◄", "▲", "§", "¶", "∆", "Ø" }
function MilBase.Gibberish(text)
	local n = math.Clamp(#tostring(text), 5, 64)
	local out = {}
	for i = 1, n do
		out[i] = (math.random(7) == 1) and " " or GIB[math.random(#GIB)]
	end
	return table.concat(out)
end

-- Voice: radio is private (non-listeners hear nothing). Only routes to the
-- channel while the talker holds their radio push-to-talk (+mb_radio); the
-- normal voice key (X) stays local proximity. Returns (canHear, is3D) or nil
-- to fall back to the proximity default.
function MilBase.VoiceCanHear(listener, talker)
	if cfg.CommsEnabled == false then return end
	if not talker:GetNWBool("mb_radio_ptt", false) then return end -- normal voice = local
	local id, ch = currentChannel(talker)
	if id == "local" or not ch or not ch.radio then return end
	if not ch.canSpeak(talker) then return end -- can't use it -> treat as local
	if MilBase.IsChannelMuted(listener, id) then return false, false end
	if not sideOK(listener, talker, id) then return false, false end

	if MilBase.CommsJammed(talker:GetPos(), id) or MilBase.CommsJammed(listener:GetPos(), id) then
		return false, false
	end
	local can = ch.canHear(listener, talker) == true
	-- Encrypted: un-decrypted listeners just get static (no audio).
	if can and ch.encrypted and not MilBase.CanDecrypt(listener, id) then
		return false, false
	end
	return can, false
end

-- Client-side helper for the on-air readout (mirrors VoiceCanHear's audience).
function MilBase.CanHearTalker(listener, talker)
	local id, ch = currentChannel(talker)
	if id == "local" or not ch or not ch.radio then return false end
	if not ch.canSpeak(talker) then return false end
	if MilBase.IsChannelMuted(listener, id) then return false end
	if not sideOK(listener, talker, id) then return false end
	if MilBase.CommsJammed(talker:GetPos(), id) or MilBase.CommsJammed(listener:GetPos(), id) then
		return false
	end
	return ch.canHear(listener, talker) == true
end

--------------------------------------------------------------------------
-- Jammer (hold-[G] self action; registered on both realms so the client
-- menu shows it and the server runs it).
--------------------------------------------------------------------------

MilBase.RegisterSelfAction("comms_jammer", {
	name = function(lp)
		return lp:GetNWString("mb_jam_mode", "") ~= "" and "Disable Comms Jammer" or "Deploy Comms Jammer"
	end,
	order = 60,
	visible = function(lp) return MilBase.CommsCanJam and MilBase.CommsCanJam(lp) end,
	run = function(ply)
		if not MilBase.CommsCanJam(ply) then return end

		if ply:GetNWString("mb_jam_mode", "") ~= "" then
			ply:SetNWString("mb_jam_mode", "")
			MilBase.Notify(ply, "Comms jammer offline.")
			return
		end

		-- Enemies / staff jam friendly comms map-wide; spec-ops jam
		-- Event-Enemy comms in a radius.
		local friendly = isEE(ply) or ply:GetNWBool("mb_eventmode", false)
			or ply:GetNWBool("mb_staffmode", false) or ply:GetNWBool("mb_cloaked", false)

		ply:SetNWString("mb_jam_mode", friendly and "friendly" or "ee")
		ply:SetNWBool("mb_jam_mapwide", friendly)
		ply:SetNWInt("mb_jam_radius", cfg.CommsJammerRadius or 3500)
		MilBase.Notify(ply, "Comms jammer online — jamming " ..
			(friendly and "all friendly comms (map-wide)" or "Event-Enemy comms nearby") .. ".")
	end,
})

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_SetComm")
	util.AddNetworkString("MilBase_JointOps")
	util.AddNetworkString("MilBase_RadioPTT")
	util.AddNetworkString("MilBase_CommMute")

	net.Receive("MilBase_RadioPTT", function(_, ply)
		ply:SetNWBool("mb_radio_ptt", net.ReadBool())
	end)

	-- The client's set of muted channel ids (see MilBase.IsChannelMuted).
	net.Receive("MilBase_CommMute", function(_, ply)
		local set = {}
		local n = net.ReadUInt(6)
		for i = 1, n do
			local id = net.ReadString()
			if MilBase.CommChannels[id] and id ~= "local" then set[id] = true end
		end
		ply.mb_commMute = set
	end)

	local function syncJointOps(target)
		net.Start("MilBase_JointOps")
			net.WriteUInt(#MilBase.JointOps, 6)
			for _, op in ipairs(MilBase.JointOps) do
				net.WriteString(op.a)
				net.WriteString(op.b)
			end
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	MilBase.SyncJointOps = syncJointOps

	net.Receive("MilBase_SetComm", function(_, ply)
		local id = net.ReadString()
		local ch = MilBase.CommChannels[id]
		if not ch then return end
		if isEE(ply) and id ~= "ee" and id ~= "local" then return end
		if id ~= "local" and not ch.canSpeak(ply) then return end
		ply:SetNWString("mb_comm", id)
	end)

	-- Send a chat message on a channel (defaults to the player's current one).
	-- Returns true if it handled the message.
	function MilBase.SendCommsChat(ply, text, chId)
		if cfg.CommsEnabled == false then return false end
		local id = chId or ply:GetNWString("mb_comm", "local")
		local ch = MilBase.CommChannels[id]
		if id == "local" or not ch or not ch.radio then return false end
		if not ch.canSpeak(ply) then return false end
		if isEE(ply) and id ~= "ee" then return false end -- EEs stay on the hostile net

		local sourceJammed = MilBase.CommsJammed(ply:GetPos(), id)
		local prefix = "[" .. string.upper(ch.name) .. "] "

		local clear, garbled = {}, {}
		for _, l in ipairs(player.GetAll()) do
			if l ~= ply and ch.canHear(l, ply) and sideOK(l, ply, id)
			and not MilBase.IsChannelMuted(l, id)
			and not sourceJammed and not MilBase.CommsJammed(l:GetPos(), id) then
				if ch.encrypted and not MilBase.CanDecrypt(l, id) then
					garbled[#garbled + 1] = l
				else
					clear[#clear + 1] = l
				end
			end
		end
		clear[#clear + 1] = ply -- the sender always reads their own message

		local messageColor = id == "republic" and ch.color or Color(220, 220, 220)
		MilBase.ChatMsg(clear, ch.color, prefix,
			color_white, ply:MBName(), messageColor, ": " .. text)

		-- Encrypted: un-decrypted listeners (High Command) see gibberish.
		if #garbled > 0 then
			MilBase.ChatMsg(garbled, ch.color, prefix, Color(150, 120, 175),
				MilBase.Gibberish(ply:MBName() .. " " .. text))
		end

		if sourceJammed then MilBase.Notify(ply, "!! Your comms are being jammed !!") end
		return true
	end

	-- One chat command per channel alias: /reg, /command, /enemy, ...
	for _, cid in ipairs(MilBase.CommOrder) do
		local ch = MilBase.CommChannels[cid]
		for _, cmd in ipairs(ch.cmds or {}) do
			MilBase.RegisterChatCommand(cmd, {
				help = "Send a message on " .. ch.name .. " comms: /" .. cmd .. " <message>",
				func = function(ply, args, rawText)
					if rawText == "" then return end
					if not MilBase.SendCommsChat(ply, rawText, cid) then
						MilBase.Notify(ply, "You can't transmit on " .. ch.name .. ".")
					end
				end,
			})
		end
	end

	-- Grant a player CLEAR access to the encrypted Hostile Net by slicing a
	-- fallen enemy's transceiver (sh_eventenemies.lua). Lasts until they die.
	function MilBase.GrantEEComms(ply)
		if not IsValid(ply) then return end
		ply:SetNWBool("mb_ee_hacked", true)
		MilBase.Notify(ply, "Enemy transceiver sliced — you're tapped into the Hostile Net until you're killed.")
	end

	-- Grant a player temporary decrypt access to encrypted comms (from a Relay
	-- hack). Expires after `seconds`, then the "frequency changes" back to noise.
	function MilBase.GrantDecrypt(ply, seconds)
		seconds = seconds or MilBase.Config.EncryptedDecryptTime or 90
		ply:SetNWFloat("mb_decrypt", CurTime() + seconds)
		MilBase.Notify(ply, "Encrypted channel decrypted for " .. math.Round(seconds) .. "s.")
		timer.Simple(seconds, function()
			if IsValid(ply) then MilBase.Notify(ply, "Encryption frequency changed - decrypt lost.") end
		end)
	end

	-- Reset volatile comm state on (re)spawn.
	hook.Add("PlayerSpawn", "MilBase.CommsReset", function(ply)
		if ply:GetNWString("mb_comm", "") == "" then ply:SetNWString("mb_comm", "local") end
		ply:SetNWString("mb_jam_mode", "")
		ply:SetNWBool("mb_radio_ptt", false)
		ply:SetNWFloat("mb_decrypt", 0)
		ply:SetNWBool("mb_ee_hacked", false)
	end)

	-- Corpse-comms access ends the instant the hacker dies (not just on respawn).
	hook.Add("PlayerDeath", "MilBase.CommsEEHackClear", function(ply)
		ply:SetNWBool("mb_ee_hacked", false)
	end)
	hook.Add("PlayerInitialSpawn", "MilBase.CommsJoin", function(ply)
		timer.Simple(3, function() if IsValid(ply) then syncJointOps(ply) end end)
	end)

	----------------------------------------------------------------
	-- Joint-op commands
	----------------------------------------------------------------

	MilBase.RegisterChatCommand("jointop", {
		help = "(Officer) Open joint-op comms with another faction: /jointop <faction id>",
		func = function(ply, args)
			if not OFF(ply) then MilBase.Notify(ply, "Officers only.") return end
			local other = args[1] and MilBase.GetFaction(args[1])
			if not other then
				MilBase.Notify(ply, "Usage: /jointop <faction id>. Factions: "
					.. table.concat(MilBase.FactionOrder or {}, ", "))
				return
			end
			local mine = ply:MBFactionID()
			if other.id == mine then MilBase.Notify(ply, "Pick a different faction.") return end

			for _, op in ipairs(MilBase.JointOps) do
				if (op.a == mine or op.b == mine) and (op.a == other.id or op.b == other.id) then
					MilBase.Notify(ply, "That joint op is already open.")
					return
				end
			end

			table.insert(MilBase.JointOps, { a = mine, b = other.id })
			syncJointOps()
			MilBase.ChatMsg(nil, Color(200, 150, 232), "[JOINT OPS] ", color_white,
				ply:MBName() .. " opened joint-op comms between " ..
				(ply:MBFaction().name) .. " and " .. other.name .. ".")
		end,
	})

	MilBase.RegisterChatCommand("jointopclose", {
		help = "(Officer) Close joint-op comms your faction is part of.",
		func = function(ply, args)
			if not OFF(ply) then MilBase.Notify(ply, "Officers only.") return end
			local mine = ply:MBFactionID()
			local n = 0
			for i = #MilBase.JointOps, 1, -1 do
				local op = MilBase.JointOps[i]
				if op.a == mine or op.b == mine then table.remove(MilBase.JointOps, i) n = n + 1 end
			end
			if n > 0 then
				syncJointOps()
				MilBase.ChatMsg(nil, Color(200, 150, 232), "[JOINT OPS] ", color_white,
					ply:MBName() .. " closed joint-op comms.")
			else
				MilBase.Notify(ply, "Your faction isn't in a joint op.")
			end
		end,
	})

	hook.Add("PostCleanupMap", "MilBase.CommsClear", function() MilBase.JointOps = {} end)

	return
end

--------------------------------------------------------------------------
-- Client: hold-H channel selector + HUD
--------------------------------------------------------------------------

net.Receive("MilBase_JointOps", function()
	local ops = {}
	local n = net.ReadUInt(6)
	for i = 1, n do ops[i] = { a = net.ReadString(), b = net.ReadString() } end
	MilBase.JointOps = ops
end)

-- Per-player radio settings (also surfaced in the F4 COMMS tab).
--   mb_radio_key    - push-to-talk key code (0 = use a +mb_radio bind instead)
--   mb_radio_volume - radio receive volume 0-100
CreateClientConVar("mb_radio_key", "0", true, false, "Push-to-talk key code (0 = use +mb_radio bind)")
CreateClientConVar("mb_radio_volume", "100", true, false, "Radio receive volume (0-100)", 0, 100)

--------------------------------------------------------------------------
-- Channel muting: client-owned preference, persisted to a data file and
-- synced to the server (which enforces it for voice + chat).
--------------------------------------------------------------------------

local MUTE_FILE = "milbase/commmute.txt"

local function mutedList()
	local ids = {}
	for id, on in pairs(MilBase.CommMute) do if on then ids[#ids + 1] = id end end
	return ids
end

local function sendMute()
	local ids = mutedList()
	net.Start("MilBase_CommMute")
		net.WriteUInt(#ids, 6)
		for _, id in ipairs(ids) do net.WriteString(id) end
	net.SendToServer()
end
MilBase.SendCommMute = sendMute

local function loadMute()
	MilBase.CommMute = {}
	local raw = file.Read(MUTE_FILE, "DATA")
	if raw then
		local t = util.JSONToTable(raw)
		if istable(t) then for _, id in ipairs(t) do MilBase.CommMute[id] = true end end
	end
end

function MilBase.IsChannelMutedLocal(chId)
	return MilBase.CommMute[chId] == true
end

function MilBase.SetChannelMute(chId, muted)
	if chId == "local" then return end
	MilBase.CommMute[chId] = muted and true or nil
	file.CreateDir("milbase")
	file.Write(MUTE_FILE, util.TableToJSON(mutedList()))
	sendMute()
end

hook.Add("InitPostEntity", "MilBase.CommMuteSync", function()
	loadMute()
	timer.Simple(3, function() sendMute() end)
end)

local function availableChannels(lp)
	local ee = isEE(lp)
	local out = {}
	for _, id in ipairs(MilBase.CommOrder) do
		local ch = MilBase.CommChannels[id]
		local show
		if ee then
			show = (id == "local" or id == "ee")
		else
			show = (id == "local" or (ch.canSpeak and ch.canSpeak(lp)))
		end
		if show then out[#out + 1] = { id = id, ch = ch } end
	end
	return out
end

local active -- { options, sel, opened }

hook.Add("Think", "MilBase.CommsMenu", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then active = nil return end
	if MilBase.InEventView and MilBase.InEventView() then active = nil return end

	-- If our channel became unusable (joint op closed, lost a role), drop to
	-- Local (throttled so we don't spam while the NW value catches up).
	local cur = lp:GetNWString("mb_comm", "local")
	local curCh = MilBase.CommChannels[cur]
	if cur ~= "local" and (not curCh or (curCh.canSpeak and not curCh.canSpeak(lp)))
	and (lp.mb_commResetAt or 0) < CurTime() then
		lp.mb_commResetAt = CurTime() + 1.5
		net.Start("MilBase_SetComm") net.WriteString("local") net.SendToServer()
	end

	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible() then
		active = nil
		lp.mb_wasCommKey = true
		return
	end

	local holding = input.IsKeyDown(KEY_H)

	if not active then
		if holding and not lp.mb_wasCommKey and not lp:GetNWBool("mb_cuffed", false) then
			local options = availableChannels(lp)
			if #options > 0 then
				active = { options = options, sel = 1, opened = CurTime() }
				surface.PlaySound("ui/buttonrollover.wav")
			end
		end
	elseif not holding then
		local choice = active.options[active.sel]
		if choice and CurTime() - active.opened > 0.1 then
			net.Start("MilBase_SetComm")
				net.WriteString(choice.id)
			net.SendToServer()
			surface.PlaySound("ui/buttonclickrelease.wav")
		end
		active = nil
	end

	lp.mb_wasCommKey = holding
end)

hook.Add("PlayerBindPress", "MilBase.CommsScroll", function(ply, bind, pressed)
	if not active or not pressed then return end
	if string.find(bind, "invprev", 1, true) then
		active.sel = ((active.sel - 2) % #active.options) + 1
		surface.PlaySound("ui/buttonrollover.wav")
		return true
	elseif string.find(bind, "invnext", 1, true) then
		active.sel = (active.sel % #active.options) + 1
		surface.PlaySound("ui/buttonrollover.wav")
		return true
	elseif string.find(bind, "reload", 1, true) then
		-- [R] toggles listening-mute on the highlighted channel.
		local opt = active.options[active.sel]
		if opt and opt.id ~= "local" then
			local muted = not MilBase.IsChannelMutedLocal(opt.id)
			MilBase.SetChannelMute(opt.id, muted)
			surface.PlaySound(muted and "buttons/button19.wav" or "buttons/button14.wav")
		end
		return true
	end
end)

-- The radial-ish list menu (mirrors the self-menu look, on the right).
hook.Add("HUDPaint", "MilBase.CommsMenuHUD", function()
	if not active then return end
	local ui = MilBase.UI
	local rowH, w = 26, 250
	local h = 40 + #active.options * rowH + 22
	local x = math.floor(ScrW() / 2 + 70)
	local y = math.floor(ScrH() / 2 - h / 2)

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10 })
	draw.SimpleText("COMMS", "MB.Tab", x + 12, y + 4, ui.text)

	for i, option in ipairs(active.options) do
		local oy = y + 36 + (i - 1) * rowH
		local selected = active.sel == i
		if selected then
			surface.SetDrawColor(255, 198, 60, 22)
			surface.DrawRect(x + 4, oy, w - 8, rowH - 2)
			MilBase.DrawBrackets(x + 4, oy, w - 8, rowH - 2, ui.accent, 6)
		end
		MilBase.DrawDiamond(x + 16, oy + (rowH - 2) / 2, 4, option.ch.color)
		draw.SimpleText(option.ch.name, "MB.Small", x + 28, oy + (rowH - 2) / 2,
			selected and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		if option.id ~= "local" and MilBase.IsChannelMutedLocal(option.id) then
			draw.SimpleText("MUTED", "MB.Tiny", x + w - 14, oy + (rowH - 2) / 2,
				ui.danger, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	draw.SimpleText("SCROLL choose  •  [R] mute  •  RELEASE [H]", "MB.Tiny",
		x + 12, y + h - 14, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)

--------------------------------------------------------------------------
-- Radio push-to-talk. RunConsoleCommand("+voicerecord") is blocked, so we use
-- permissions.EnableVoiceChat() - the Lua-sanctioned way to start/stop mic
-- recording (this is how Helios does it). Bind a key to +mb_radio and hold it
-- to transmit on your comm channel; the normal voice key (X) stays local.
--     mb_radiobind <key>        e.g.  mb_radiobind b
--------------------------------------------------------------------------

local radioKeyDown = false

local function enableVoice(on)
	if permissions and permissions.EnableVoiceChat then permissions.EnableVoiceChat(on) end
end

local function setRadio(on)
	on = on and true or false
	if radioKeyDown == on then return end
	radioKeyDown = on
	enableVoice(on)
	-- Local push-to-talk squelch feedback.
	local sfx = MilBase.Config.RadioSFX
	if sfx then
		local s = on and sfx.txOn or sfx.txOff
		if s and s ~= "" then surface.PlaySound(s) end
	end
	net.Start("MilBase_RadioPTT")
		net.WriteBool(on)
	net.SendToServer()
end

concommand.Add("+mb_radio", function() setRadio(true) end)
concommand.Add("-mb_radio", function() setRadio(false) end)

-- One-step bind helper.
concommand.Add("mb_radiobind", function(_, _, args)
	local key = args[1]
	if not key or key == "" then
		chat.AddText(Color(255, 198, 60), "[MilBase] ", color_white,
			"Usage: mb_radiobind <key>   e.g.  mb_radiobind b")
		return
	end
	RunConsoleCommand("bind", key, "+mb_radio")
	chat.AddText(Color(255, 198, 60), "[MilBase] ", color_white,
		"Radio push-to-talk bound to " .. string.upper(key) .. ".")
end)

hook.Add("Think", "MilBase.RadioPTTGuard", function()
	local lp = LocalPlayer()
	local blocked = not IsValid(lp) or not lp:Alive() or gui.IsGameUIVisible()
		or IsValid(vgui.GetKeyboardFocus())

	-- Convar-key push-to-talk (set in the F4 COMMS tab). A +mb_radio bind still
	-- works when the key is left at 0.
	local kc = GetConVar("mb_radio_key"):GetInt()
	if kc > 0 then
		setRadio(not blocked and input.IsKeyDown(kc))
	elseif radioKeyDown and blocked then
		setRadio(false)
	end
end)

--------------------------------------------------------------------------
-- Voice indicator: track who we can hear, suppress GMod's default panels.
--------------------------------------------------------------------------

local talking = {}
hook.Add("PlayerStartVoice", "MilBase.CommsVoice", function(p)
	if IsValid(p) then
		talking[p] = true
		local lp = LocalPlayer()
		if IsValid(lp) and p ~= lp then
			local radio = p:GetNWBool("mb_radio_ptt", false) and MilBase.CanHearTalker(lp, p)
			-- Radio receive volume; local proximity voice stays at full volume.
			local volume = radio and (GetConVar("mb_radio_volume"):GetInt() / 100) or 1
			-- SetVoiceVolume does not exist in Garry's Mod. The supported
			-- clientside API is SetVoiceVolumeScale; guard it for compatibility
			-- with unusual engine branches and mocked player objects.
			if isfunction(p.SetVoiceVolumeScale) then
				p:SetVoiceVolumeScale(math.Clamp(volume, 0, 1))
			end
			if radio then
				local sfx = MilBase.Config.RadioSFX
				if sfx and sfx.rx and sfx.rx ~= "" then surface.PlaySound(sfx.rx) end
			end
		end
	end
	return true -- we draw our own ON AIR panel
end)
hook.Add("PlayerEndVoice", "MilBase.CommsVoice", function(p)
	talking[p] = nil
	return true
end)

-- ON AIR (top-left) — who you can hear + which channel they're on.
hook.Add("HUDPaint", "MilBase.CommsOnAir", function()
	if MilBase.InEventView and MilBase.InEventView() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) then return end
	local ui = MilBase.UI

	local list = {}
	-- PlayerStartVoice normally reports the local player too, while IsSpeaking
	-- and radioKeyDown cover engine branches where that hook arrives late.
	local selfTalking = talking[lp] == true or radioKeyDown
		or (isfunction(lp.IsSpeaking) and lp:IsSpeaking())
	if selfTalking then list[#list + 1] = lp end
	for p in pairs(talking) do
		if IsValid(p) and p ~= lp then list[#list + 1] = p end
	end
	if #list == 0 then return end

	local x, y, w, rowH = 20, 100, 252, 24
	local h = 28 + #list * rowH
	MilBase.DrawPanelBF2(x, y, w, h, { cut = 8, accent = ui.accent })
	draw.SimpleText("ON AIR", "MB.Tiny", x + 12, y + 8, ui.dim)

	local ry = y + 24
	for _, p in ipairs(list) do
		local isSelf = p == lp
		local _, pch = MilBase.CurrentChannel(p)
		local ptt = p:GetNWBool("mb_radio_ptt", false) or (isSelf and radioKeyDown)
		local radio = ptt and pch and pch.radio
			and (isSelf or MilBase.CanHearTalker(lp, p))
		local label = radio and (pch and pch.name or "Radio") or "Local"
		local col = radio and (pch and pch.color or ui.accent) or ui.dim

		MilBase.DrawDiamond(x + 16, ry + rowH / 2, 4, col)
		draw.SimpleText(isSelf and "YOU" or p:MBName(), "MB.Small", x + 30, ry + rowH / 2,
			isSelf and ui.ok or ui.text,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.upper(label), "MB.Tiny", x + w - 10, ry + rowH / 2, col,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		ry = ry + rowH
	end
end)

-- Current-channel badge (bottom-right, fracture-badge style), above the ammo.
hook.Add("HUDPaint", "MilBase.CommsChannel", function()
	if MilBase.InEventView and MilBase.InEventView() then return end
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local ui = MilBase.UI

	local id, ch = MilBase.CurrentChannel(lp)
	if not ch then return end

	local jammed = ch.radio and MilBase.CommsJammed(lp:GetPos(), id)
	local col = jammed and ui.danger or (ch.radio and ch.color or ui.dim)

	local w, bh = 210, 22
	local x, y = ScrW() - w - 20, ScrH() - 108
	MilBase.DrawPanelBF2(x, y, w, bh, { cut = 5, accent = col })
	draw.SimpleText("COMMS: " .. string.upper(ch.name) .. (jammed and "  [JAMMED]" or ""),
		"MB.Tiny", x + 12, y + bh / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	if radioKeyDown and ch.radio then
		draw.SimpleText("● TX", "MB.Tiny", x + w - 10, y + bh / 2, ui.ok,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	elseif ch.radio then
		local kc = GetConVar("mb_radio_key"):GetInt()
		local key = kc > 0 and input.GetKeyName(kc) or input.LookupBinding("+mb_radio")
		draw.SimpleText(key and ("HOLD " .. string.upper(key)) or "SET PTT KEY (F4)",
			"MB.Tiny", x + w - 10, y + bh / 2, ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end)
