--[[
	First-load tutorial. The first time a player joins they get:

	  1. A cinematic flythrough tour of the map (authored by staff with the
	     Flythrough Camera toolgun — see modules/sh_flythrough.lua). Skipped
	     automatically if no tour has been saved for this map.
	  2. Their regiment + role.
	  3. A rundown of every keybind and what it does.
	  4. A hands-on step: open the Self Menu (hold G) and Roll Dice.
	  5. How to interact with other soldiers (hold E).
	  6. Basic comms (hold H).
	  7. How the health / wounded system works.

	Shows once (persisted in frontier_tutorial); replay anytime with /tutorial.
]]

--------------------------------------------------------------------------
-- Server: trigger on first join, persist "seen", /tutorial to replay
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_TutorialStart")
	util.AddNetworkString("MilBase_TutorialFreeze")

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_tutorial (
		steamid VARCHAR(32) PRIMARY KEY,
		seen INTEGER
	)]])

	-- Send the tutorial to a player once they're alive and in the world.
	local function beginFor(ply)
		if not IsValid(ply) then return end
		if not ply:Alive() then
			timer.Simple(1, function() beginFor(ply) end)
			return
		end
		net.Start("MilBase_TutorialStart")
		net.Send(ply)
	end

	hook.Add("MilBase.PlayerLoaded", "MilBase.TutorialFirstJoin", function(ply)
		local sid = MilBase.SQLStr(ply:SteamID64())
		MilBase.DB.Query("SELECT seen FROM frontier_tutorial WHERE steamid = " .. sid, function(rows)
			if not IsValid(ply) then return end
			if rows and rows[1] and tonumber(rows[1].seen) == 1 then return end

			MilBase.DB.Run(string.format(
				"REPLACE INTO frontier_tutorial (steamid, seen) VALUES (%s, 1)", sid))
			timer.Simple(2, function() beginFor(ply) end)
		end)
	end)

	-- Cinematic freeze: the client asks to be locked in place during the
	-- flythrough. Only ever affects the requesting player, with a safety
	-- auto-unlock so a lost "unfreeze" can't strand anyone.
	net.Receive("MilBase_TutorialFreeze", function(_, ply)
		local on = net.ReadBool()
		if on then
			if not ply:Alive() then return end
			ply:Lock()
			ply.mb_tutLocked = true
			timer.Create("MilBase.TutUnlock_" .. ply:SteamID64(), 45, 1, function()
				if IsValid(ply) and ply.mb_tutLocked then
					ply:UnLock()
					ply.mb_tutLocked = false
				end
			end)
		else
			if ply.mb_tutLocked then
				ply:UnLock()
				ply.mb_tutLocked = false
			end
			timer.Remove("MilBase.TutUnlock_" .. ply:SteamID64())
		end
	end)

	-- Never leave a disconnecting player's timer dangling.
	hook.Add("PlayerDisconnected", "MilBase.TutorialCleanup", function(ply)
		timer.Remove("MilBase.TutUnlock_" .. ply:SteamID64())
	end)

	MilBase.RegisterChatCommand("tutorial", {
		help = "Replay the new-player tutorial.",
		func = function(ply)
			net.Start("MilBase_TutorialStart")
			net.Send(ply)
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: the step-by-step overlay
--------------------------------------------------------------------------

local tut -- { steps, index }

local function requestFreeze(on)
	net.Start("MilBase_TutorialFreeze")
		net.WriteBool(on)
	net.SendToServer()
end

-- Word-wrap `text` to `maxW` in `font`.
local function wrap(text, font, maxW)
	surface.SetFont(font)
	local lines, line = {}, ""
	for word in string.gmatch(text, "%S+%s*") do
		local test = line .. word
		if surface.GetTextSize(test) > maxW and line ~= "" then
			lines[#lines + 1] = string.TrimRight(line)
			line = word
		else
			line = test
		end
	end
	if line ~= "" then lines[#lines + 1] = string.TrimRight(line) end
	return lines
end

--------------------------------------------------------------------------
-- Step content (built fresh each run so faction/rank are current)
--------------------------------------------------------------------------

local function buildSteps()
	local lp = LocalPlayer()
	local faction = lp:MBFaction()
	local rank = lp:MBRank()
	local steps = {}

	-- 1. Cinematic tour (only if staff have authored one for this map).
	if MilBase.HasFlythrough and MilBase.HasFlythrough() then
		steps[#steps + 1] = { type = "cinematic", caption = "WELCOME, SOLDIER" }
	end

	-- 2. Regiment + role.
	local roleLines = {}
	if faction.medic then
		roleLines[#roleLines + 1] = "Role: Combat Medic — your regiment stabilizes the wounded faster."
	end
	if faction.police then
		roleLines[#roleLines + 1] = "Role: Military Police — you can cuff and drag soldiers (hold E)."
	end
	if #roleLines == 0 then
		roleLines[#roleLines + 1] = "Role: Line soldier — hold the front and follow your officers' orders."
	end
	if rank and rank.canPromote then
		roleLines[#roleLines + 1] = "As an officer you can promote, demote and assign soldiers."
	end

	steps[#steps + 1] = {
		type    = "info",
		title   = "YOUR REGIMENT",
		accent  = faction.color,
		big     = faction.name,
		bigColor = faction.color,
		lines   = table.Add({
			"Rank: " .. (rank and rank.name or "Recruit"),
			faction.description or "",
		}, roleLines),
		prompt  = "PRESS [SPACE] OR CLICK TO CONTINUE",
	}

	-- 3. Keybinds.
	local binds = {
		{ "F4 / F1",        "Open the Personnel menu (roster, gear, health, certs, help)" },
		{ "Custom",         "Toggle third person — choose a key in F4 → THIRD PERSON" },
		{ "Hold G",         "Self menu — gestures, roll dice, drop weapon, squad" },
		{ "Hold H",         "Comms — pick a radio channel to talk on" },
		{ "Middle Mouse",   "Squad ping — tap for a quick marker, hold for tactical orders" },
		{ "Hold E",         "Interact — stabilize the wounded, dogtags, pick up items" },
		{ "Hold C + RMB",   "Player menu — actions on the soldier you're aiming at" },
		{ "ALT",            "Lower / raise your weapon (can't fire while lowered)" },
		{ "Mouse Wheel",    "Weapon wheel — scroll to switch weapons" },
		{ "R",              "Rotate an item while dragging it in the inventory" },
		{ "SPACE",          "Give up while wounded / respawn when dead" },
	}
	if lp:IsAdmin() or (lp.MBStaffLevel and lp:MBStaffLevel() > 0) then
		table.insert(binds, 2, { "F2", "Staff menu (staff only)" })
	end
	steps[#steps + 1] = {
		type   = "info",
		title  = "CONTROLS",
		binds  = binds,
		prompt = "PRESS [SPACE] OR CLICK TO CONTINUE",
	}

	-- 4. Interactive: roll the dice from the Self Menu.
	steps[#steps + 1] = {
		type  = "roll",
		title = "TRY IT — ROLL THE DICE",
		lines = {
			"Open your Self Menu: hold [G], scroll down to \"Roll Dice\", then release [G].",
			"The Self Menu is also where you gesture, drop your weapon and manage your squad.",
		},
		prompt = "ROLL THE DICE TO CONTINUE…",
	}

	-- 5. Interacting with players.
	steps[#steps + 1] = {
		type  = "info",
		title = "INTERACTING WITH SOLDIERS",
		lines = {
			"Hold [E] while looking at a soldier, scroll to an action, release to confirm.",
			"Anyone can Check Dogtags. Medics Treat the wounded. Officers Promote / Demote.",
			"Military Police can Cuff and Drag. Hold [E] on dropped weapons / items to pick them up.",
		},
		prompt = "PRESS [SPACE] OR CLICK TO CONTINUE",
	}

	-- 6. Comms.
	steps[#steps + 1] = {
		type  = "info",
		title = "COMMS & RADIO",
		lines = {
			"Hold [H] to open the comms wheel, scroll to a channel, release to select.",
			"Your voice AND typed chat then go out on that channel — radio is private, Local is proximity.",
			"Channels include Local, Regimental, Command, Training, ATC and Joint Ops.",
			"Set a push-to-talk key in console:  mb_radiobind b   — then hold [B] to transmit on radio.",
		},
		prompt = "PRESS [SPACE] OR CLICK TO CONTINUE",
	}

	-- 7. Health system.
	steps[#steps + 1] = {
		type  = "info",
		title = "STAYING ALIVE",
		lines = {
			"You have seven limbs, each with its own HP — see the HEALTH tab in the F4 menu.",
			"BLEEDING: use a Bandage or you'll bleed out.  FRACTURE: use a Splint or you'll limp.",
			"Painkillers suppress pain for a while. Taking damage interrupts any healing you start.",
			"A killing blow DOWNS you instead of killing — a teammate holds [E] to stabilize you, or press [SPACE] to give up. A second hit finishes you.",
		},
		prompt = "PRESS [SPACE] OR CLICK TO CONTINUE",
	}

	-- 8. Done.
	steps[#steps + 1] = {
		type  = "info",
		title = "YOU'RE READY",
		lines = {
			"That's the basics, soldier. Replay this anytime with  /tutorial.",
			"Report to your officers for your assignment and orders. Good hunting.",
		},
		prompt = "PRESS [SPACE] OR CLICK TO FINISH",
	}

	return steps
end

--------------------------------------------------------------------------
-- Flow control
--------------------------------------------------------------------------

local advance -- forward declaration

local function finish()
	if not tut then return end
	tut = nil
	requestFreeze(false)
	MilBase.PlayUISound("select")
end

advance = function()
	if not tut then return end
	tut.index = tut.index + 1
	local step = tut.steps[tut.index]
	if not step then finish() return end

	step.shownAt = CurTime()

	if step.type == "cinematic" then
		requestFreeze(true)
		MilBase.PlayFlythrough({ points = MilBase.FlyPath, caption = step.caption }, function()
			requestFreeze(false)
			advance()
		end)
	else
		MilBase.PlayUISound("hover")
	end
end

local function startTutorial()
	if not IsValid(LocalPlayer()) then return end
	tut = { steps = buildSteps(), index = 0 }
	advance()
end

net.Receive("MilBase_TutorialStart", function()
	-- A tiny delay lets networked faction/rank settle on a very first spawn.
	timer.Simple(0.5, startTutorial)
end)

-- Roll step auto-advances when the player actually rolls (hook fired by
-- modules/sh_selfmenu.lua on a confirmed self-action).
hook.Add("MilBase.SelfActionConfirm", "MilBase.TutorialRoll", function(id)
	if not tut then return end
	local step = tut.steps[tut.index]
	if step and step.type == "roll" and id == "roll" then
		advance()
	end
end)

--------------------------------------------------------------------------
-- Input: advance info cards; skip the roll step after a grace period
--------------------------------------------------------------------------

hook.Add("PlayerBindPress", "MilBase.TutorialInput", function(_, bind, pressed)
	if not tut or not pressed then return end
	local step = tut.steps[tut.index]
	if not step or step.type == "cinematic" then return end
	if (CurTime() - (step.shownAt or 0)) < 0.25 then return end

	local space = string.find(bind, "+jump", 1, true)
	local click = string.find(bind, "+attack", 1, true)

	if step.type == "roll" then
		-- Let them get on with it; offer a skip after a few seconds.
		if space and (CurTime() - (step.shownAt or 0)) > 3 then
			advance()
			return true
		end
		return
	end

	if space or click then
		advance()
		return true
	end
end)

--------------------------------------------------------------------------
-- Rendering
--------------------------------------------------------------------------

hook.Add("HUDPaint", "MilBase.TutorialHUD", function()
	if not tut then return end
	if not IsValid(LocalPlayer()) then return end
	local step = tut.steps[tut.index]
	if not step or step.type == "cinematic" then return end -- flythrough draws itself

	local ui = MilBase.UI
	local w = 640
	local innerW = w - 56
	local x = math.floor(ScrW() / 2 - w / 2)

	-- Build a flat render list (big line / body line / paragraph gap) and let
	-- the card size to it, so measurement and drawing can never disagree.
	local HEIGHTS = { big = 40, line = 24, gap = 6 }
	local rendered = {}

	if step.big then
		rendered[#rendered + 1] = { kind = "big", text = step.big }
	end

	for _, ln in ipairs(step.lines or {}) do
		if ln ~= "" then
			for _, wl in ipairs(wrap(ln, "MB.Med", innerW)) do
				rendered[#rendered + 1] = { kind = "line", text = wl }
			end
		end
		rendered[#rendered + 1] = { kind = "gap" }
	end

	local bodyH = 0
	for _, r in ipairs(rendered) do bodyH = bodyH + (HEIGHTS[r.kind] or 0) end
	if step.binds then bodyH = bodyH + #step.binds * 26 end

	local headerH = 58
	local promptH = 34
	local h = headerH + bodyH + promptH + 20
	local y = math.floor(ScrH() * 0.52 - h / 2)

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 14, accent = step.accent or ui.accent })

	-- Header
	draw.SimpleText(step.title or "", "MB.Big", x + 28, y + 16, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	surface.SetDrawColor(step.accent or ui.accent)
	surface.DrawRect(x + 28, y + headerH - 8, 60, 2)

	-- Body
	local cy = y + headerH
	for _, r in ipairs(rendered) do
		if r.kind == "big" then
			draw.SimpleText(r.text, "MB.Tab", x + 28, cy, step.bigColor or ui.accent,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		elseif r.kind == "line" then
			draw.SimpleText(r.text, "MB.Med", x + 28, cy, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end
		cy = cy + (HEIGHTS[r.kind] or 0)
	end

	if step.binds then
		for _, b in ipairs(step.binds) do
			MilBase.DrawDiamond(x + 34, cy + 11, 3, ui.accent)
			draw.SimpleText(b[1], "MB.Small", x + 48, cy + 4, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(b[2], "MB.Tiny", x + 210, cy + 5, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			cy = cy + 26
		end
	end

	-- Prompt (blinks gently). Roll step turns green once available.
	local promptCol = ui.faint
	local prompt = step.prompt or ""
	if step.type == "roll" then
		if (CurTime() - (step.shownAt or 0)) > 3 then
			prompt = "ROLL THE DICE TO CONTINUE…    (or press [SPACE] to skip)"
		end
		promptCol = ui.accent
	end
	local a = 150 + math.sin(CurTime() * 3) * 60
	draw.SimpleText(prompt, "MB.Small", x + w / 2, y + h - 22,
		Color(promptCol.r, promptCol.g, promptCol.b, a), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Step counter, top-right.
	draw.SimpleText(tut.index .. " / " .. #tut.steps, "MB.Tiny", x + w - 24, y + 22,
		ui.faint, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end)
