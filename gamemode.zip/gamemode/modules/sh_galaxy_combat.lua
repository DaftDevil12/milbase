-- Galaxy Director local-space combat shared definitions.

if MilBase._GalaxyCombatSharedLoaded then return end
MilBase._GalaxyCombatSharedLoaded = true

local G = MilBase.Galaxy
G.Version = math.max(tonumber(G.Version) or 3, 6)

function G.DefenseStage(ship)
	if not IsValid(ship) then return "none", "NO TARGET" end
	if ship:GetShipState() == "retreating" then
		return "retreat", "BREAKING CONTACT"
	end
	if ship.GetCombatReady and not ship:GetCombatReady() then
		return "ingress", "ENTERING THE BATTLESPACE"
	end
	if ship.GetShield and ship:GetShield() > 0 then
		return "shield", "DEFLECTOR SHIELD ACTIVE"
	end
	return "hull", "HULL EXPOSED"
end
