-- Prison layout visualisation, prison datapad app and allied-transfer comms UI.
if not CLIENT or MilBase._PrisonClientLoaded then return end
MilBase._PrisonClientLoaded = true

local P = MilBase.Prison
P.ClientLayout = P.ClientLayout or {}
local cfg = MilBase.Config.Prison or {}
local transferFrame

net.Receive("MilBase_Prison_Layout", function()
	P.ClientLayout = net.ReadTable() or {}
end)

local function textList(rows)
	if not istable(rows) or #rows == 0 then return "None recorded" end
	return table.concat(rows, "\n• ")
end
local function needColour(value, ui)
	value = tonumber(value) or 0
	return value <= 20 and ui.danger or value <= 45 and ui.warn or ui.ok
end
local function makeBar(parent, label, value, helpers)
	local ui = helpers.ui()
	local row = vgui.Create("DPanel", parent); row:Dock(TOP); row:SetTall(24); row:DockMargin(0,0,0,4)
	row.Paint = function(self,w,h)
		draw.SimpleText(label, helpers.font("MB.Tiny","DermaDefault"), 0, 4, ui.dim)
		surface.SetDrawColor(255,255,255,15); surface.DrawRect(88,8,w-126,8)
		local col=needColour(value,ui); surface.SetDrawColor(col); surface.DrawRect(88,8,(w-126)*math.Clamp((tonumber(value) or 0)/100,0,1),8)
		draw.SimpleText(math.floor(tonumber(value) or 0).."%",helpers.font("MB.Tiny","DermaDefault"),w,4,col,TEXT_ALIGN_RIGHT)
	end
	return row
end
local function panelButton(parent, label, colour, helpers, callback)
	local b=helpers.button(parent,label,colour,callback); b:Dock(TOP); b:SetTall(36); b:DockMargin(0,0,0,6); return b
end

function MilBase.BuildPrisonDatapad(parent, request, helpers)
	local ui=helpers.ui(); local selectedID=""; local payload={}
	local left=vgui.Create("DPanel",parent); left:Dock(LEFT); left:SetWide(310); left:DockMargin(0,0,10,0); left.Paint=nil
	local right=vgui.Create("DPanel",parent); right:Dock(FILL); right.Paint=nil
	parent.PerformLayout=function(self,w) left:SetWide(math.Clamp(math.floor(w*0.36),265,350)) end

	local function render(data)
		payload=data or {}; left:Clear(); right:Clear()
		if payload.alarm and MilBase.Prison then MilBase.Prison.ClientAlarm=payload.alarm end
		if selectedID=="" then selectedID=tostring(payload.selectedID or LocalPlayer():GetNWString("mb_prisonSelected", "")) end
		local cap=payload.capacity or {}; local summary=helpers.section(left,"FACILITY STATUS",180)
		summary.Paint=function(self,w,h)
			helpers.drawPanel(0,0,w,h,{cut=8,color=Color(0,0,0,130),accent=cap.level=="normal" and ui.ok or ui.warn})
			draw.SimpleText("SHIPBOARD DETENTION",helpers.font("MB.Small","DermaDefaultBold"),12,10,ui.text)
			local alarm=payload.alarm or {}
			draw.SimpleText(string.upper(payload.alert or "normal").."  •  "..string.upper(payload.scheduleLabel or "LOCKDOWN"),helpers.font("MB.Tiny","DermaDefault"),12,36,(alarm.active or payload.alert=="riot") and ui.danger or ui.accent)
			draw.SimpleText("PRISONERS",helpers.font("MB.Tiny","DermaDefault"),12,68,ui.faint)
			draw.SimpleText(tostring(cap.active or 0).." / "..tostring(cap.capacity or 0).." PROPER BEDS",helpers.font("MB.Small","DermaDefaultBold"),12,88,cap.level=="normal" and ui.ok or ui.warn)
			draw.SimpleText("OVERCROWDING: "..string.upper(cap.level or "normal").."  •  OVERFLOW "..tostring(cap.overflow or 0),helpers.font("MB.Tiny","DermaDefault"),12,118,ui.dim)
			local facility=payload.facility or {}; draw.SimpleText(alarm.active and ("ALARM: "..string.upper(tostring(alarm.reason or "ACTIVE"))) or ("FOOD "..math.floor(facility.food or 0).."  WATER "..math.floor(facility.water or 0).."  CLEAN "..math.floor(facility.cleanliness or 0)),helpers.font("MB.Tiny","DermaDefault"),12,143,alarm.active and ui.danger or ui.faint)
		end
		local list=vgui.Create("DScrollPanel",left); list:Dock(FILL)
		for _,pr in ipairs(payload.prisoners or {}) do
			local row=vgui.Create("DButton",list); row:Dock(TOP); row:SetTall(68); row:DockMargin(0,0,4,6); row:SetText("")
			row.Paint=function(self,w,h)
				local active=selectedID==pr.id
				local col=pr.status=="rioting" and ui.danger
					or ((pr.risk=="high" or pr.risk=="critical") and ui.warn or ui.accent)
				helpers.drawPanel(0,0,w,h,{cut=7,color=active and Color(col.r,col.g,col.b,35) or (self:IsHovered() and ui.hover or Color(255,255,255,4)),accent=active and col or nil})
				helpers.drawFitText(pr.name or pr.id,helpers.font("MB.Small","DermaDefaultBold"),10,8,ui.text,w-20)
				helpers.drawFitText((pr.statusLabel or pr.status).."  •  "..(pr.cellID~="" and string.upper(pr.cellID) or "NO CELL"),helpers.font("MB.Tiny","DermaDefault"),10,34,col,w-20)
				draw.SimpleText(pr.riskLabel or string.upper(pr.risk or "low"),helpers.font("MB.Tiny","DermaDefault"),w-10,50,col,TEXT_ALIGN_RIGHT)
			end
			row.DoClick=function() selectedID=pr.id; request("prison_ops","select",{prisonerID=selectedID}) end
		end

		local selected
		for _,pr in ipairs(payload.prisoners or {}) do if pr.id==selectedID then selected=pr break end end
		local top=vgui.Create("DPanel",right); top:Dock(TOP); top:SetTall(100); top:DockMargin(0,0,0,8)
		top.Paint=function(self,w,h)
			helpers.drawPanel(0,0,w,h,{cut=8,color=Color(0,0,0,135),accent=payload.alert=="riot" and ui.danger or ui.accent})
			draw.SimpleText(selected and selected.name or "PRISON OPERATIONS",helpers.font("MB.Med","DermaDefaultBold"),14,10,ui.text)
			draw.SimpleText(selected and ((selected.statusLabel or selected.status).."  •  RISK "..(selected.riskLabel or selected.risk)) or "Select a prisoner to review custody, needs and transfer status.",helpers.font("MB.Tiny","DermaDefault"),15,46,selected and ui.accent or ui.dim)
			draw.SimpleText(payload.message or ("CURRENT SCHEDULE: "..tostring(payload.scheduleLabel or "LOCKDOWN")),helpers.font("MB.Tiny","DermaDefault"),15,70,payload.message and ui.warn or ui.faint)
		end
		local scroll=vgui.Create("DScrollPanel",right); scroll:Dock(FILL)
		if selected then
			local needs=helpers.section(scroll,"PRISONER NEEDS",190); local inner=vgui.Create("DPanel",needs); inner:Dock(FILL); inner:DockMargin(14,40,14,10); inner.Paint=nil
			makeBar(inner,"FOOD",selected.needs and selected.needs.food,helpers); makeBar(inner,"WATER",selected.needs and selected.needs.water,helpers); makeBar(inner,"SLEEP",selected.needs and selected.needs.sleep,helpers); makeBar(inner,"HYGIENE",selected.needs and selected.needs.hygiene,helpers); makeBar(inner,"SOCIAL",selected.needs and selected.needs.social,helpers)
			local languageState=(selected.languageCertification or "")=="" and "UNDERSTOOD BY ALL" or selected.languageUnderstood and ("CERTIFIED: "..tostring(selected.languageQualification or "")) or (selected.translatorName or "")~="" and ("TRANSLATOR PRESENT: "..selected.translatorName) or ("TRANSLATOR REQUIRED: "..tostring(selected.languageQualification or selected.languageCertification or "LANGUAGE CERTIFICATION"))
			local details=helpers.section(scroll,"CUSTODY RECORD",350); local label=vgui.Create("DLabel",details); label:Dock(FILL); label:DockMargin(14,40,14,10); label:SetFont(helpers.font("MB.Tiny","DermaDefault")); label:SetTextColor(ui.dim); label:SetWrap(true); label:SetText("ID: "..selected.id.."\nROLE: "..tostring(selected.role).."\nFACTION: "..string.upper(tostring(selected.faction)).."\nSPECIES: "..string.upper(tostring(selected.speciesName or "HUMAN")).."\nLANGUAGE: "..string.upper(tostring(selected.languageName or "GALACTIC BASIC")).."\nCOMPREHENSION: "..languageState.."\nTRAITS: "..table.concat(selected.traits or {},", ").."\nRESTRAINTS: "..tostring(selected.restraintLabel or "STANDARD").."  •  MOVEMENT: "..string.upper(tostring(selected.movementState or "IDLE")).."\nINTAKE: "..tostring(selected.intakeStageLabel or (selected.intakeComplete and "COMPLETE" or "PENDING")).."  •  GUARD RELATION: "..tostring(selected.relation or 0).."\n"..(selected.suspicion and ("\nSECURITY WARNING: "..string.upper(tostring(selected.suspicion.label or selected.suspicion.kind)).."\n") or "").."\nCHARGES:\n• "..textList(selected.charges).."\n\nEVIDENCE:\n• "..textList(selected.evidence))
			local interview=helpers.section(scroll,"PRISONER INTERVIEW",220); local ii=vgui.Create("DPanel",interview); ii:Dock(FILL); ii:DockMargin(14,40,14,10); ii.Paint=nil
			local topic=vgui.Create("DLabel",ii); topic:Dock(TOP); topic:SetTall(32); topic:DockMargin(0,0,0,7); topic:SetFont(helpers.font("MB.Tiny","DermaDefault")); topic:SetTextColor(ui.dim); topic:SetText("Questions and translated replies appear in the cinematic interview.")
			panelButton(ii,"BEGIN CINEMATIC INTERVIEW",ui.accent,helpers,function() request("prison_ops","open_interview",{prisonerID=selected.id}) end)
			local last=selected.lastInterview; local interviewText=vgui.Create("DLabel",ii); interviewText:Dock(FILL); interviewText:SetWrap(true); interviewText:SetFont(helpers.font("MB.Tiny","DermaDefault")); interviewText:SetTextColor(last and last.untranslated and ui.warn or ui.dim); interviewText:SetText(last and ((last.untranslated and "LATEST - UNTRANSLATED: " or (last.translator or "")~="" and ("LATEST - TRANSLATED BY "..string.upper(last.translator)..": ") or "LATEST: ")..tostring(last.response or "")) or ((selected.translationAvailable==false and (selected.languageCertification or "")~="") and ("A nearby player with "..tostring(selected.languageQualification or selected.languageCertification).." must translate this interview.") or "No recorded interview responses."))
			if #(selected.memories or {})>0 or #(selected.intelligence or {})>0 then
				local memory=helpers.section(scroll,"CUSTODY MEMORY AND INTELLIGENCE",210); local memoryText=vgui.Create("DLabel",memory); memoryText:Dock(FILL); memoryText:DockMargin(14,40,14,10); memoryText:SetFont(helpers.font("MB.Tiny","DermaDefault")); memoryText:SetTextColor(ui.dim); memoryText:SetWrap(true)
				local rows={}
				for index,item in ipairs(selected.memories or {}) do if index<=4 then rows[#rows+1]=os.date("%H:%M",tonumber(item.time) or os.time()).."  "..tostring(item.text or item.kind) end end
				for index,item in ipairs(selected.intelligence or {}) do if index<=3 then rows[#rows+1]="INTEL: "..tostring(item.text or "") end end
				memoryText:SetText(table.concat(rows,"\n"))
			end
			local actions=helpers.section(scroll,"CUSTODY ACTIONS",900); local actionInner=vgui.Create("DPanel",actions); actionInner:Dock(FILL); actionInner:DockMargin(14,40,14,10); actionInner.Paint=nil
			panelButton(actionInner,"START / TAKE ESCORT",ui.accent,helpers,function() request("prison_ops","start_escort",{prisonerID=selected.id}) end)
			if selected.status=="escort_waiting" then panelButton(actionInner,"ASSIST CRITICAL-RISK ESCORT",ui.warn,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="assist"}) end) end
			if not selected.intakeComplete then panelButton(actionInner,"INTAKE: "..tostring(selected.intakeStageLabel or "PROCESS NEXT STEP"),ui.ok,helpers,function() request("prison_ops","process_intake",{prisonerID=selected.id}) end) end
			panelButton(actionInner,"ORDER: HALT",ui.accent,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="halt"}) end)
			panelButton(actionInner,"ORDER: KNEEL",ui.accent,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="kneel"}) end)
			panelButton(actionInner,"ORDER: FACE AIMED WALL",ui.accent,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="face_wall"}) end)
			if selected.cellID and selected.cellID ~= "" then panelButton(actionInner,"ORDER: RETURN TO CELL",ui.warn,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="return_cell"}) end) end
			panelButton(actionInner,"DELIVER MEAL",ui.accent,helpers,function() request("prison_ops","meal",{prisonerID=selected.id}) end)
			panelButton(actionInner,"SUPPLY WATER",ui.accent,helpers,function() request("prison_ops","water",{prisonerID=selected.id}) end)
			panelButton(actionInner,"MEDICAL TREATMENT",ui.ok,helpers,function() request("prison_ops","medical",{prisonerID=selected.id}) end)
			panelButton(actionInner,"SEARCH PRISONER",ui.warn,helpers,function() request("prison_ops","search",{prisonerID=selected.id}) end)
			if selected.cellID and selected.cellID ~= "" then
				panelButton(actionInner,"SEARCH ASSIGNED CELL",ui.warn,helpers,function() request("prison_ops","search_cell",{prisonerID=selected.id}) end)
				panelButton(actionInner,"CLEAN ASSIGNED CELL",ui.ok,helpers,function() request("prison_ops","clean_cell",{prisonerID=selected.id}) end)
				panelButton(actionInner,"REPAIR CELL / DOOR",ui.accent,helpers,function() request("prison_ops","repair_cell",{prisonerID=selected.id}) end)
			end
			panelButton(actionInner,"SECURE RESTRAINTS",ui.warn,helpers,function() request("prison_ops","restrain",{prisonerID=selected.id}) end)
			panelButton(actionInner,"LOOSEN / REMOVE RESTRAINTS",ui.ok,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="unrestrain"}) end)
			if selected.status=="rioting" then panelButton(actionInner,"ORDER SURRENDER",ui.danger,helpers,function() request("prison_ops","command",{prisonerID=selected.id,command="surrender"}) end) end
			if payload.canCommand then panelButton(actionInner,"MOVE TO ISOLATION",ui.warn,helpers,function() request("prison_ops","isolate",{prisonerID=selected.id}) end); panelButton(actionInner,"AUTHORISE RELEASE",ui.danger,helpers,function() request("prison_ops","release",{prisonerID=selected.id}) end) end
		end
		local supply=helpers.section(scroll,"GUARD SUPPLIES",145); local si=vgui.Create("DPanel",supply); si:Dock(FILL); si:DockMargin(14,40,14,10); si.Paint=nil
		local carried=payload.carried or {}; local carryLabel=vgui.Create("DLabel",si); carryLabel:Dock(TOP); carryLabel:SetTall(24); carryLabel:SetFont(helpers.font("MB.Tiny","DermaDefault")); carryLabel:SetTextColor(ui.dim); carryLabel:SetText("CARRYING: "..tostring(carried.meals or 0).." MEALS  •  "..tostring(carried.water or 0).." WATER")
		panelButton(si,"COLLECT MEAL TRAYS",ui.accent,helpers,function() request("prison_ops","collect_meals",{}) end)
		panelButton(si,"COLLECT WATER SUPPLIES",ui.accent,helpers,function() request("prison_ops","collect_water",{}) end)
		local cellsSection=helpers.section(scroll,"CELL BLOCK STATUS",190); local ci=vgui.Create("DScrollPanel",cellsSection); ci:Dock(FILL); ci:DockMargin(10,38,10,8)
		for _,cell in ipairs(payload.cells or {}) do
			local row=vgui.Create("DPanel",ci); row:Dock(TOP); row:SetTall(30); row:DockMargin(0,0,0,3)
			row.Paint=function(self,w,h) local bad=(cell.occupied or 0)>=(cell.capacity or 2) or (cell.damage or 0)>35; surface.SetDrawColor(255,255,255,5); surface.DrawRect(0,0,w,h); draw.SimpleText(string.upper(cell.id or "CELL").."  "..tostring(cell.occupied or 0).."/"..tostring(cell.capacity or 2).."  •  "..string.upper(tostring(cell.zone or "CELLBLOCK")),helpers.font("MB.Tiny","DermaDefaultBold"),7,7,cell.lockedDown and ui.danger or bad and ui.warn or ui.text); draw.SimpleText((cell.lockedDown and "LOCKDOWN  " or "").."CLEAN "..math.floor(cell.cleanliness or 0).."%  DAMAGE "..math.floor(cell.damage or 0).."%",helpers.font("MB.Tiny","DermaDefault"),w-7,7,cell.lockedDown and ui.danger or (cell.damage or 0)>35 and ui.danger or ui.dim,TEXT_ALIGN_RIGHT) end
		end
		local takeover=payload.takeover or {}; local takeoverSection=helpers.section(scroll,"SHIP TAKEOVER",205); local takeoverInner=vgui.Create("DPanel",takeoverSection); takeoverInner:Dock(FILL); takeoverInner:DockMargin(14,40,14,10); takeoverInner.Paint=nil
		local currentLabel="NONE"; local objectiveLines={}
		for _,objective in ipairs(takeover.objectives or {}) do
			if objective.current then currentLabel=objective.label or objective.kind end
			local objectiveState=not objective.configured and "MISSING" or objective.captured and "CAPTURED" or objective.current and "TARGET" or "SECURE"
			objectiveLines[#objectiveLines+1]=string.upper(tostring(objective.label or objective.kind))..": "..objectiveState
		end
		local takeoverText=vgui.Create("DLabel",takeoverInner); takeoverText:Dock(TOP); takeoverText:SetTall(92); takeoverText:SetWrap(true); takeoverText:SetFont(helpers.font("MB.Tiny","DermaDefault")); takeoverText:SetTextColor(takeover.active and ui.danger or ui.dim)
		local effects={}; if takeover.armed then effects[#effects+1]="ARMORY WEAPONS" end; if takeover.systemsThreatened then effects[#effects+1]="CAMERAS JAMMED" end; if takeover.commsCaptured then effects[#effects+1]="COMMS SEIZED" end
		takeoverText:SetText((takeover.controlled and "RIOTERS CONTROL THE BRIDGE" or takeover.active and ("ACTIVE ASSAULT - TARGET "..string.upper(tostring(currentLabel))) or "NO ACTIVE TAKEOVER").."\n"..table.concat(objectiveLines,"  |  ")..(#effects>0 and ("\nEFFECTS: "..table.concat(effects," / ")) or ""))
		local progress=vgui.Create("DPanel",takeoverInner); progress:Dock(TOP); progress:SetTall(26); progress:DockMargin(0,4,0,0)
		progress.Paint=function(self,w,h) local fraction=math.Clamp((takeover.progress or 0)/math.max(1,takeover.holdSeconds or 1),0,1); surface.SetDrawColor(255,255,255,10); surface.DrawRect(0,5,w,16); surface.SetDrawColor(ui.danger); surface.DrawRect(0,5,w*fraction,16); draw.SimpleText("OBJECTIVE CONTROL "..math.floor(fraction*100).."%",helpers.font("MB.Tiny","DermaDefaultBold"),w/2,13,ui.text,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER) end
		local incidents=helpers.section(scroll,"RECENT INCIDENTS",190); local il=vgui.Create("DScrollPanel",incidents); il:Dock(FILL); il:DockMargin(10,38,10,8)
		for index,rowData in ipairs(payload.incidents or {}) do if index<=12 then local l=vgui.Create("DLabel",il); l:Dock(TOP); l:SetTall(34); l:DockMargin(2,0,2,3); l:SetWrap(true); l:SetFont(helpers.font("MB.Tiny","DermaDefault")); l:SetTextColor((rowData.severity or 0)>=4 and ui.danger or (rowData.severity or 0)>=2 and ui.warn or ui.dim); l:SetText(os.date("%H:%M",tonumber(rowData.time) or os.time()).."  "..tostring(rowData.text or "")) end end
		if payload.canCommand then
			local ops=helpers.section(scroll,"FACILITY COMMAND",650); local oi=vgui.Create("DPanel",ops); oi:Dock(FILL); oi:DockMargin(14,40,14,10); oi.Paint=nil
			local schedule=vgui.Create("DComboBox",oi); schedule:Dock(TOP); schedule:SetTall(32); schedule:DockMargin(0,0,0,7); schedule:SetValue("Select schedule mode")
			for id,label in SortedPairs(P.ScheduleLabels or {}) do schedule:AddChoice(label,id) end
			panelButton(oi,"APPLY SCHEDULE",ui.accent,helpers,function() local _,id=schedule:GetSelected(); if id then request("prison_ops","schedule",{schedule=id,duration=300}) end end)
			panelButton(oi,"RESUME AUTOMATIC SCHEDULE",ui.ok,helpers,function() request("prison_ops","automatic_schedule",{}) end)
			panelButton(oi,"RUN PHYSICAL ROLL CALL",ui.accent,helpers,function() request("prison_ops","rollcall",{}) end)
			panelButton(oi,"ENGAGE FACILITY LOCKDOWN",ui.danger,helpers,function() request("prison_ops","lockdown",{}) end)
			panelButton(oi,"CLEAR FACILITY LOCKDOWN",ui.ok,helpers,function() request("prison_ops","clear_lockdown",{}) end)
			if selected and selected.zone and selected.zone~="" then panelButton(oi,"LOCK DOWN ZONE: "..string.upper(selected.zone),ui.warn,helpers,function() request("prison_ops","lockdown_zone",{zone=selected.zone,enabled=true}) end) end
			if selected and selected.zone and selected.zone~="" then panelButton(oi,"CLEAR ZONE LOCKDOWN: "..string.upper(selected.zone),ui.ok,helpers,function() request("prison_ops","lockdown_zone",{zone=selected.zone,enabled=false}) end) end
			if selected and selected.cellID and selected.cellID~="" then panelButton(oi,"LOCK DOWN CELL: "..string.upper(selected.cellID),ui.warn,helpers,function() request("prison_ops","lockdown_cell",{cellID=selected.cellID,enabled=true}) end) end
			if selected and selected.cellID and selected.cellID~="" then panelButton(oi,"CLEAR CELL LOCKDOWN: "..string.upper(selected.cellID),ui.ok,helpers,function() request("prison_ops","lockdown_cell",{cellID=selected.cellID,enabled=false}) end) end
			panelButton(oi,"NEGOTIATE WITH RIOTERS",ui.warn,helpers,function() request("prison_ops","negotiate",{}) end)
			if takeover.active then panelButton(oi,"SECURE FRONT-LINE OBJECTIVE",ui.danger,helpers,function() request("prison_ops","secure_takeover",{}) end) end
			panelButton(oi,"COMPLETE FACILITY CLEANING",ui.ok,helpers,function() request("prison_ops","clean_facility",{}) end)
			local security=helpers.section(scroll,"CAMERAS AND ALARM",math.max(230,130+#(payload.cameras or {})*42)); local sec=vgui.Create("DPanel",security); sec:Dock(FILL); sec:DockMargin(14,40,14,10); sec.Paint=nil
			local alarm=payload.alarm or {}; local alarmText=vgui.Create("DLabel",sec); alarmText:Dock(TOP); alarmText:SetTall(28); alarmText:SetFont(helpers.font("MB.Tiny","DermaDefaultBold")); alarmText:SetTextColor(alarm.active and ui.danger or ui.ok); alarmText:SetText(alarm.active and ("ACTIVE: "..string.upper(tostring(alarm.reason or "PRISON ALARM"))) or "ALARM CLEAR")
			panelButton(sec,"ACTIVATE MANUAL ALARM",ui.danger,helpers,function() request("prison_ops","manual_alarm",{reason="Manual guard alarm",level="warning",zone=selected and selected.zone or "facility"}) end)
			panelButton(sec,"CLEAR ALARM",ui.ok,helpers,function() request("prison_ops","clear_alarm",{}) end)
			for _,camera in ipairs(payload.cameras or {}) do panelButton(sec,(camera.online and "VIEW " or "OFFLINE ")..string.upper(camera.name or "CAMERA").."  •  "..string.upper(camera.event or "CLEAR"),camera.event and camera.event~="CLEAR" and ui.warn or ui.accent,helpers,function() if MilBase.Prison.OpenCameraFeed then MilBase.Prison.OpenCameraFeed(camera) end end) end
			local transfers=helpers.section(scroll,"ALLIED PRISON TRANSFERS",math.max(300,145+#(payload.transfers or {})*74)); local ti=vgui.Create("DPanel",transfers); ti:Dock(FILL); ti:DockMargin(14,40,14,10); ti.Paint=nil
			local transferInfo=vgui.Create("DLabel",ti); transferInfo:Dock(TOP); transferInfo:SetTall(70); transferInfo:SetWrap(true); transferInfo:SetFont(helpers.font("MB.Tiny","DermaDefault")); transferInfo:SetTextColor(ui.dim); transferInfo:SetText("Contact an allied planet from the communications console. After acceptance, call its LAAT. When it lands, select each assigned prisoner, start an escort and walk them to the marked boarding ramp.")
			for _,tx in ipairs(payload.transfers or {}) do
				local transferStatus=vgui.Create("DLabel",ti); transferStatus:Dock(TOP); transferStatus:SetTall(24); transferStatus:SetFont(helpers.font("MB.Tiny","DermaDefaultBold")); transferStatus:SetTextColor((tx.status=="pickup_landed" or tx.status=="boarding") and ui.ok or tx.status=="departing" and ui.warn or ui.dim); transferStatus:SetText(string.upper(tostring(tx.destinationName or tx.destination or "PLANET")).."  -  "..string.upper(string.gsub(tostring(tx.status or "UNKNOWN"),"_"," ")))
				if tx.status=="accepted" then panelButton(ti,"CALL PICKUP LAAT  "..tx.id,ui.ok,helpers,function() request("prison_ops","begin_boarding",{transferID=tx.id}) end)
				elseif tx.status=="pickup_landed" or tx.status=="boarding" then panelButton(ti,"AUTHORISE LAAT DEPARTURE  "..tx.id,ui.warn,helpers,function() request("prison_ops","dispatch_transfer",{transferID=tx.id}) end) end
			end
		end
	end
	helpers.pending.prison_ops=render
	request("prison_ops","get",{prisonerID=LocalPlayer():GetNWString("mb_prisonSelected","")})
end

local function openTransferComms(data)
	if IsValid(transferFrame) then transferFrame:Remove() end
	local ui=MilBase.UI; local frame=vgui.Create("DFrame"); transferFrame=frame
	frame:SetSize(math.min(720,ScrW()-40),math.min(620,ScrH()-40)); frame:Center(); frame:SetTitle(""); frame:ShowCloseButton(false); frame:MakePopup()
	frame.Paint=function(self,w,h) if MilBase.DrawBlur then MilBase.DrawBlur(self,2) end MilBase.DrawPanelBF2(0,0,w,h,{cut=12,color=Color(3,8,14,246),accent=ui.accent}); draw.SimpleText("ALLIED PRISON TRANSFER CHANNEL","MB.Med",18,14,ui.text); draw.SimpleText(data.message or "Select detainees and an aligned detention facility.","MB.Tiny",18,45,data.message and ui.warn or ui.dim) end
	local close=vgui.Create("DButton",frame); close:SetText("X"); close:SetPos(frame:GetWide()-48,12); close:SetSize(34,28); close.DoClick=function() frame:Remove() end
	frame.PerformLayout=function(self,w) close:SetPos(w-48,12) end
	local content=vgui.Create("DPanel",frame); content:SetPos(16,76); content:SetSize(frame:GetWide()-32,frame:GetTall()-92); content.Paint=nil; frame.PerformLayout=function(self,w,h) close:SetPos(w-48,12); content:SetSize(w-32,h-92) end
	local destination=vgui.Create("DComboBox",content); destination:Dock(TOP); destination:SetTall(36); destination:DockMargin(0,0,0,8); destination:SetValue("Select destination")
	for _,dest in ipairs(data.destinations or {}) do destination:AddChoice(dest.name.." — capacity "..dest.used.."/"..dest.capacity,dest.id) end
	local list=vgui.Create("DScrollPanel",content); list:Dock(FILL); local selected={}
	for _,pr in ipairs(data.prisoners or {}) do local c=vgui.Create("DCheckBoxLabel",list); c:Dock(TOP); c:SetTall(32); c:DockMargin(6,2,6,2); c:SetText(pr.name.."  •  "..pr.riskLabel.."  •  "..pr.statusLabel); c:SetTextColor(ui.text); c.OnChange=function(_,on) selected[pr.id]=on==true end end
	local send=vgui.Create("DButton",content); send:Dock(BOTTOM); send:SetTall(42); send:SetText("TRANSMIT TRANSFER REQUEST"); send.DoClick=function() local _,dest=destination:GetSelected(); if not dest then return end local ids={}; for id,on in pairs(selected) do if on then ids[#ids+1]=id end end net.Start("MilBase_Prison_Comms"); net.WriteString("request"); net.WriteTable({destination=dest,prisonerIDs=ids}); net.SendToServer() end
end

net.Receive("MilBase_Prison_CommsData", function() openTransferComms(net.ReadTable() or {}) end)
