--[[
	Self-action menu: hold [G], scroll to choose, release to confirm - the
	same feel as the hold-E interaction menu, but the actions apply to
	YOURSELF (detonate charges, and more to come).

	Register actions from any module:
	MilBase.RegisterSelfAction("detonate", {
		name = "Detonate Charges",       -- or function(lp) return "..." end
		order = 10,
		visible = function(lp) return ... end,  -- CLIENT
		run = function(ply) ... end,            -- SERVER
		-- or client = function(lp) ... end      (runs clientside)
	})
]]

if SERVER then

	util.AddNetworkString("MilBase_SelfAction")

	net.Receive("MilBase_SelfAction", function(_, ply)
		local id = net.ReadString()

		if (ply.mb_lastSelf or 0) > CurTime() - 0.3 then return end
		ply.mb_lastSelf = CurTime()

		local action = MilBase.SelfActions[id]
		if not action or not action.run then return end
		if not ply:Alive() then return end

		action.run(ply)
	end)

	return
end

--------------------------------------------------------------------------
-- Client: hold G, scroll, release
--------------------------------------------------------------------------

local active -- { options = { {id, name, def} }, sel, opened }

local function buildOptions(lp)
	local out = { { id = nil, name = "Close" } }

	for _, id in ipairs(MilBase.SelfOrder) do
		local action = MilBase.SelfActions[id]
		if not action.visible or action.visible(lp) then
			local name = isfunction(action.name) and action.name(lp) or action.name
			out[#out + 1] = { id = id, name = name, def = action }
		end
	end

	return out
end

hook.Add("Think", "MilBase.SelfMenu", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then active = nil return end
	if MilBase.InEventView and MilBase.InEventView() then active = nil return end

	-- Don't hijack the G key while typing in chat or with a menu open.
	if IsValid(vgui.GetKeyboardFocus()) or gui.IsGameUIVisible() then
		active = nil
		lp.mb_wasSelfKey = true -- require a fresh press afterwards
		return
	end

	local holding = input.IsKeyDown(KEY_G)

	if not active then
		if holding and not lp.mb_wasSelfKey
		and not lp:GetNWBool("mb_wounded", false)
		and not lp:GetNWBool("mb_cuffed", false) then
			local options = buildOptions(lp)
			if #options > 1 then
				active = { options = options, sel = 1, opened = CurTime() }
				surface.PlaySound("ui/buttonrollover.wav")
			end
		end
	elseif not holding then
		local choice = active.options[active.sel]
		if choice and choice.id and CurTime() - active.opened > 0.12 then
			if choice.def.client then
				choice.def.client(lp)
			else
				net.Start("MilBase_SelfAction")
					net.WriteString(choice.id)
				net.SendToServer()
			end
			surface.PlaySound("ui/buttonclickrelease.wav")
			-- Let other systems (e.g. the tutorial) react to a confirmed action.
			hook.Run("MilBase.SelfActionConfirm", choice.id)
		end
		active = nil
	end

	lp.mb_wasSelfKey = holding
end)

-- Scroll wheel drives the selection while the menu is up.
hook.Add("PlayerBindPress", "MilBase.SelfScroll", function(ply, bind, pressed)
	if not active or not pressed then return end

	if string.find(bind, "invprev", 1, true) then
		active.sel = ((active.sel - 2) % #active.options) + 1
		surface.PlaySound("ui/buttonrollover.wav")
		return true
	elseif string.find(bind, "invnext", 1, true) then
		active.sel = (active.sel % #active.options) + 1
		surface.PlaySound("ui/buttonrollover.wav")
		return true
	end
end)

hook.Add("HUDPaint", "MilBase.SelfMenuHUD", function()
	if not active then return end

	local ui = MilBase.UI
	local rowH = 26
	local w = 240
	local h = 40 + #active.options * rowH + 22
	local x = math.floor(ScrW() / 2 - w - 70)
	local y = math.floor(ScrH() / 2 - h / 2)

	MilBase.DrawPanelBF2(x, y, w, h, { cut = 10 })
	draw.SimpleText("SELF", "MB.Tab", x + 12, y + 4, ui.text)

	for i, option in ipairs(active.options) do
		local oy = y + 36 + (i - 1) * rowH
		local selected = active.sel == i

		if selected then
			surface.SetDrawColor(255, 198, 60, 22)
			surface.DrawRect(x + 4, oy, w - 8, rowH - 2)
			MilBase.DrawBrackets(x + 4, oy, w - 8, rowH - 2, ui.accent, 6)
		end

		draw.SimpleText(option.name, "MB.Small", x + 16, oy + (rowH - 2) / 2,
			selected and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	draw.SimpleText("SCROLL to choose  •  RELEASE [G]", "MB.Tiny",
		x + 12, y + h - 14, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)
