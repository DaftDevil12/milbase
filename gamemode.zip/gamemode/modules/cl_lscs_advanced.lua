-- Player Jedi profile and staff Jedi management interfaces.

local cfg = MilBase.Config.LSCS or {}
if cfg.Enabled == false then return end

local MBLSCS = MilBase.LSCS
if not MBLSCS then return end

MBLSCS.AdvancedState = MBLSCS.AdvancedState or {}
MBLSCS.AdvancedAdminState = MBLSCS.AdvancedAdminState or {}
MBLSCS.AuditRows = MBLSCS.AuditRows or {}

if MilBase.UI and MilBase.UI.art and MilBase.UI.art.menuTabIcons then
	MilBase.UI.art.menuTabIcons["JEDI PROFILE"] = MilBase.Asset("menu/f4/bfui/avatar.png")
	MilBase.UI.art.menuTabIcons["JEDI MANAGEMENT"] = MilBase.Asset("menu/f4/bfui/cogwheel.png")
end

net.Receive("MilBase_LSCSAdvancedSync", function()
	MBLSCS.AdvancedState = net.ReadTable() or {}
	if isfunction(MBLSCS.RefreshAdvancedUI) then MBLSCS.RefreshAdvancedUI() end
	if isfunction(MBLSCS.RefreshTrainingUI) then MBLSCS.RefreshTrainingUI() end
	if isfunction(MBLSCS.RefreshForgeUI) then MBLSCS.RefreshForgeUI() end
end)

net.Receive("MilBase_LSCSMentorRequest", function()
	local padawan = net.ReadEntity()
	if not IsValid(padawan) then return end
	Derma_Query(padawan:MBName() .. " has asked to become your Padawan.", "Mentorship request",
		"ACCEPT", function()
			net.Start("MilBase_LSCSAdvancedAction")
				net.WriteString("mentor_accept") net.WriteEntity(padawan) net.WriteString("")
			net.SendToServer()
		end,
		"DECLINE", function()
			net.Start("MilBase_LSCSAdvancedAction")
				net.WriteString("mentor_decline") net.WriteEntity(padawan) net.WriteString("")
			net.SendToServer()
		end)
end)

net.Receive("MilBase_LSCSWorkbenchOpen", function()
	MBLSCS.WorkbenchClientUntil = CurTime() + (cfg.WorkbenchUseTime or 120)
	if MilBase.OpenMenu then MilBase.OpenMenu("LIGHTSABER FORGE") end
end)

net.Receive("MilBase_LSCSAdvancedAdminState", function()
	local target = net.ReadEntity()
	if not IsValid(target) then return end
	MBLSCS.AdvancedAdminState[target] = net.ReadTable() or {}
	if isfunction(MBLSCS.RefreshAdvancedAdminUI) then MBLSCS.RefreshAdvancedAdminUI(target) end
end)

net.Receive("MilBase_LSCSAuditRows", function()
	local target = net.ReadEntity()
	if not IsValid(target) then return end
	MBLSCS.AuditRows[target] = net.ReadTable() or {}
	if isfunction(MBLSCS.RefreshAdvancedAdminUI) then MBLSCS.RefreshAdvancedAdminUI(target) end
end)

local function sendAction(action, target, arg)
	net.Start("MilBase_LSCSAdvancedAction")
		net.WriteString(action or "")
		net.WriteEntity(IsValid(target) and target or game.GetWorld())
		net.WriteString(tostring(arg or ""))
	net.SendToServer()
end

local function sendAdmin(action, target, arg)
	if not IsValid(target) then MilBase.Notify(LocalPlayer(), "Select a player first.") return end
	net.Start("MilBase_LSCSAdvancedAdmin")
		net.WriteString(action or "") net.WriteEntity(target) net.WriteString(tostring(arg or ""))
	net.SendToServer()
end

local function actionButton(parent, label, accent, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		local enabled = self:IsEnabled()
		local col = enabled and (accent or ui.accent) or ui.faint
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6, color = enabled and self:IsHovered() and Color(col.r, col.g, col.b, 42) or ui.raised,
			accent = enabled and col or nil,
		})
		if enabled and self:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, enabled and ui.text or ui.faint,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		MilBase.PlayUISound("select")
		if callback then callback() end
	end
	return button
end

local function section(parent, title, height, accent)
	local panel = vgui.Create("DPanel", parent)
	panel:Dock(TOP)
	panel:SetTall(height)
	panel:DockMargin(0, 0, 8, 10)
	panel.Paint = function(_, w, h)
		local ui = MilBase.UI
		MilBase.PaintPanel(w, h, accent or ui.accent)
		draw.SimpleText(title, "MB.Tab", 16, 12, accent or ui.accent)
	end
	return panel
end

local function alignmentColor(value)
	if value > 10 then return Color(90, 175, 255) end
	if value < -10 then return Color(210, 75, 100) end
	return Color(210, 190, 120)
end

local function findOnlineByCharacterKey(sid)
	for _, ply in ipairs(player.GetAll()) do if ply:MBCharacterKey() == sid then return ply end end
end

local function buildProfileContent(content)
	local ui = MilBase.UI
	local ply = LocalPlayer()
	local state = MBLSCS.AdvancedState or {}
	local workbenchActive = math.max(ply:GetNWFloat("mb_lscs_workbench_until", 0),
		MBLSCS.WorkbenchClientUntil or 0) > CurTime()
	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local alignment = ply:MBLSCSAlignment()
	local acol = alignmentColor(alignment)
	local header = section(scroll, "JEDI PROFILE", 116, acol)
	header.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h, acol)
		draw.SimpleText(ply:MBIsJedi() and ply:MBJediTitle() or "FORCE-SENSITIVE CANDIDATE", "MB.Big", 18, 13, ui.text)
		draw.SimpleText(ply:MBFaction().name, "MB.Small", 18, 48, ui.dim)
		draw.SimpleText(MBLSCS.AlignmentName(alignment) .. "  " .. alignment, "MB.Med", w - 18, 24,
			acol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		MilBase.DrawBar(18, 82, w - 36, 9, (alignment + 100) / 200, acol)
		draw.SimpleText("DARK", "MB.Tiny", 18, 99, ui.faint)
		draw.SimpleText("LIGHT", "MB.Tiny", w - 18, 99, ui.faint, TEXT_ALIGN_RIGHT)
	end

	if not ply:MBIsJedi() then
		local potential = section(scroll, "FORCE POTENTIAL", 170, ui.warn)
		local text = vgui.Create("DLabel", potential)
		text:SetPos(18, 50)
		text:SetSize(760, 100)
		text:SetFont("MB.Med")
		text:SetTextColor(ui.text)
		text:SetWrap(true)
		text:SetText("Your profile shows Force sensitivity, but LSCS powers, lightsabers, and Jedi training remain locked until you are assigned to a faction configured with jedi = true. Holocron discoveries are retained if you later enter the Order.")
		local discoveries = section(scroll, "DISCOVERED HOLOCRONS", 60 + table.Count(state.discoveries or {}) * 28, ui.accent)
		local y = 48
		for id in pairs(state.discoveries or {}) do
			local def = (cfg.Holocrons or {})[id] or { name = id }
			local label = vgui.Create("DLabel", discoveries)
			label:SetPos(18, y) label:SetSize(600, 24) label:SetFont("MB.Small")
			label:SetTextColor(def.color or ui.accent) label:SetText(def.name)
			y = y + 28
		end
		return
	end

	local activeNodes = {}
	for _, id in ipairs(MBLSCS.NodeOrder) do
		local node = MBLSCS.Nodes[id]
		if node.active and (MBLSCS.ClientUnlocked or {})[id] then activeNodes[#activeNodes + 1] = id end
	end
	local loadout = section(scroll, "ACTIVE FORCE LOADOUT  " .. MBLSCS.ActiveCount(ply) .. "/" .. (cfg.ForceSlots or 4),
		58 + math.max(1, #activeNodes) * 42, ui.accent)
	if #activeNodes == 0 then
		local empty = vgui.Create("DLabel", loadout)
		empty:SetPos(18, 48) empty:SetSize(500, 28) empty:SetFont("MB.Small")
		empty:SetTextColor(ui.dim) empty:SetText("Learn a Force power from LSCS TRAINING first.")
	end
	for index, id in ipairs(activeNodes) do
		local nodeID, node = id, MBLSCS.Nodes[id]
		local row = vgui.Create("DPanel", loadout)
		row:SetPos(16, 45 + (index - 1) * 42) row:SetSize(780, 36) row.Paint = nil
		local allowed, reason = MBLSCS.CanLearnAdvanced(ply, node)
		local enabled = (state.active or {})[nodeID] == true
		local label = enabled and (allowed and "EQUIPPED" or "SUSPENDED") or "EQUIP"
		local button = actionButton(row, label, enabled and (allowed and ui.ok or ui.danger) or ui.accent, function()
			sendAction("toggle_power", nil, nodeID)
		end)
		button:Dock(RIGHT) button:SetWide(120)
		button:SetEnabled(workbenchActive and (enabled or allowed))
		row.Paint = function(_, w, h)
			draw.SimpleText(node.name, "MB.Med", 2, 8, enabled and ui.ok or ui.text)
			if not allowed then draw.SimpleText(reason or "Locked", "MB.Tiny", 270, 18, ui.danger) end
		end
	end

	local presetPanel = section(scroll, "FORCE & SABER PRESETS", 62 + (cfg.PresetSlots or 3) * 45, ui.ok)
	for slot = 1, cfg.PresetSlots or 3 do
		local slotID = slot
		local preset = (state.presets or {})[tostring(slot)] or {}
		local row = vgui.Create("DPanel", presetPanel)
		row:SetPos(16, 46 + (slot - 1) * 45) row:SetSize(820, 38) row.Paint = nil
		local name = vgui.Create("DTextEntry", row)
		name:Dock(LEFT) name:SetWide(260) name:SetFont("MB.Small")
		name:SetText(preset.name or ("Preset " .. slot))
		local save = actionButton(row, "SAVE", ui.ok, function()
			sendAction("preset_save", nil, slotID .. "|" .. name:GetValue())
		end)
		save:Dock(LEFT) save:SetWide(105) save:DockMargin(8, 0, 8, 0)
		save:SetEnabled(workbenchActive)
		local load = actionButton(row, "LOAD", ui.accent, function() sendAction("preset_load", nil, slotID) end)
		load:Dock(LEFT) load:SetWide(105) load:SetEnabled(preset.name ~= nil and workbenchActive)
	end

	local trialPanel = section(scroll, "JEDI TRIALS", 58 + table.Count(cfg.Trials or {}) * 70, ui.warn)
	local trialIDs = {}
	for id in pairs(cfg.Trials or {}) do trialIDs[#trialIDs + 1] = id end
	table.sort(trialIDs)
	for index, id in ipairs(trialIDs) do
		local trialID, def = id, cfg.Trials[id]
		local progress = tonumber(((state.trials or {}).progress or {})[id]) or 0
		local completed = ((state.trials or {}).completed or {})[id] ~= nil
		local ready = ((state.trials or {}).ready or {})[id] == true
		local active = (state.trials or {}).active == id
		local row = vgui.Create("DPanel", trialPanel)
		row:SetPos(16, 46 + (index - 1) * 70) row:SetSize(900, 62)
		row.Paint = function(_, w, h)
			surface.SetDrawColor(255, 255, 255, 5) surface.DrawRect(0, 0, w, h)
			draw.SimpleText(def.name, "MB.Med", 10, 7, completed and ui.ok or ui.text)
			draw.SimpleText(def.description or "", "MB.Tiny", 10, 31, ui.dim)
			local status = completed and "COMPLETE" or (ready and "AWAITING APPROVAL" or (active and "ACTIVE" or (progress .. "/" .. (def.target or 1))))
			draw.SimpleText(status, "MB.Small", w - 150, 12, completed and ui.ok or (ready and ui.warn or ui.accent), TEXT_ALIGN_RIGHT)
		end
		if not completed and not ready then
			local start = actionButton(row, active and "ACTIVE" or "START", ui.warn, function() sendAction("trial_start", nil, trialID) end)
			start:SetPos(755, 30) start:SetSize(130, 27)
			start:SetEnabled(not active and ply:MBJediLevel() >= (def.minLevel or 1))
		end
	end

	local mentorPanel = section(scroll, "MASTER–PADAWAN", 145, ui.accent)
	local mentor = findOnlineByCharacterKey(state.mentor or "")
	local mentorText = vgui.Create("DLabel", mentorPanel)
	mentorText:SetPos(18, 48) mentorText:SetSize(520, 28) mentorText:SetFont("MB.Med") mentorText:SetTextColor(ui.text)
	mentorText:SetText((state.mentor or "") ~= "" and ("MASTER: " .. (IsValid(mentor) and mentor:MBName() or "Offline / " .. state.mentor)) or "NO MASTER ASSIGNED")
	if (state.mentor or "") ~= "" then
		local endBond = actionButton(mentorPanel, "END BOND", ui.danger, function()
			Derma_Query("End your Master-Padawan bond?", "Confirm", "END BOND", function() sendAction("mentor_end", nil, "") end, "CANCEL")
		end)
		endBond:SetPos(550, 45) endBond:SetSize(140, 32)
	elseif ply:MBJediLevel() <= (cfg.PadawanMaxLevel or 2) then
		local masters = vgui.Create("DComboBox", mentorPanel)
		masters:SetPos(18, 86) masters:SetSize(310, 32) masters:SetValue("Select an online Jedi Master")
		local selectedMaster
		for _, candidate in ipairs(player.GetAll()) do
			if candidate ~= ply and candidate:MBIsJedi() and candidate:MBJediLevel() >= (cfg.MasterLevel or 4) then
				masters:AddChoice(candidate:MBName(), candidate)
			end
		end
		masters.OnSelect = function(_, _, _, data) selectedMaster = data end
		local request = actionButton(mentorPanel, "REQUEST MENTOR", ui.accent, function()
			if IsValid(selectedMaster) then sendAction("mentor_request", selectedMaster, "") end
		end)
		request:SetPos(340, 86) request:SetSize(165, 32)
	end

	if ply:MBJediLevel() >= (cfg.MasterLevel or 4) then
		local padawans = {}
		for _, candidate in ipairs(player.GetAll()) do
			if candidate:GetNWString("mb_lscs_mentor", "") == ply:MBCharacterKey() then padawans[#padawans + 1] = candidate end
		end
		mentorPanel:SetTall(145 + #padawans * 38)
		for index, padawan in ipairs(padawans) do
			local student = padawan
			local readyID = student:GetNWString("mb_lscs_trial_ready", "")
			if readyID == "" then readyID = nil end
			local activeID = student:GetNWString("mb_lscs_trial", "")
			local activeTrial = (cfg.Trials or {})[activeID]
			local progressText = readyID and ("READY: " .. (((cfg.Trials or {})[readyID] or {}).name or readyID))
				or (activeTrial and (activeTrial.name .. "  " .. student:GetNWInt("mb_lscs_trial_progress", 0)
					.. "/" .. (activeTrial.target or 1)) or "NO ACTIVE TRIAL")
			local row = vgui.Create("DPanel", mentorPanel)
			row:SetPos(18, 130 + (index - 1) * 38) row:SetSize(720, 32) row.Paint = function(_, w, h)
				draw.SimpleText("PADAWAN  " .. student:MBName(), "MB.Small", 2, h / 2, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(progressText, "MB.Tiny", 270, h / 2, readyID and ui.warn or ui.dim,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			if readyID then
				local approveID = readyID
				local approve = actionButton(row, "APPROVE TRIAL", ui.ok, function() sendAction("trial_approve", student, approveID) end)
				approve:Dock(RIGHT) approve:SetWide(145)
			end
		end
	end

	local workbench = section(scroll, "SABER WORKBENCH  " .. (workbenchActive and "CONNECTED" or "NOT CONNECTED"), 185,
		workbenchActive and ui.ok or ui.danger)
	local hiltCombo = vgui.Create("DComboBox", workbench)
	hiltCombo:SetPos(18, 52) hiltCombo:SetSize(300, 34) hiltCombo:SetValue("Select inventory hilt")
	local crystalCombo = vgui.Create("DComboBox", workbench)
	crystalCombo:SetPos(330, 52) crystalCombo:SetSize(300, 34) crystalCombo:SetValue("Select inventory crystal")
	local selectedHilt, selectedCrystal
	if MBLSCS.IsInstalled() and ply.lscsGetInventory then
		for _, class in pairs(ply:lscsGetInventory()) do
			local item = MBLSCS.ClassToItem(class)
			if item and item.type == "hilt" then hiltCombo:AddChoice(item.name or class, class) end
			if item and item.type == "crystal" then crystalCombo:AddChoice(item.name or class, class) end
		end
	end
	hiltCombo.OnSelect = function(_, _, _, data) selectedHilt = data end
	crystalCombo.OnSelect = function(_, _, _, data) selectedCrystal = data end
	local craft = actionButton(workbench, "ASSEMBLE SABER", ui.accent, function()
		if selectedHilt and selectedCrystal then sendAction("craft", nil, selectedHilt .. "|" .. selectedCrystal) end
	end)
	craft:SetPos(642, 52) craft:SetSize(170, 34) craft:SetEnabled(workbenchActive)
	local respec = actionButton(workbench, "RESET TREE + REFUND", ui.danger, function()
		Derma_Query("Reset every learned LSCS skill and refund its cost? Trials, alignment, and discoveries remain.",
			"Confirm Jedi respec", "RESET TREE", function() sendAction("respec", nil, "") end, "CANCEL")
	end)
	respec:SetPos(18, 111) respec:SetSize(210, 36) respec:SetEnabled(workbenchActive)
	local remaining = math.max(0, (tonumber(state.lastRespec) or 0) + (cfg.RespecCooldown or 21600) - os.time())
	local note = vgui.Create("DLabel", workbench)
	note:SetPos(244, 113) note:SetSize(620, 34) note:SetFont("MB.Small") note:SetTextColor(ui.dim)
	note:SetText(workbenchActive and (remaining > 0 and ("Respec cooldown: " .. math.ceil(remaining / 60) .. " minute(s)") or "Loadout editing and respec are available.")
		or "Use a placed Jedi workbench to modify loadouts, presets, or your saber.")

	local holocronPanel = section(scroll, "HOLOCRON ARCHIVE", 58 + table.Count(cfg.Holocrons or {}) * 34, ui.accent)
	local holocronIDs = {}
	for id in pairs(cfg.Holocrons or {}) do holocronIDs[#holocronIDs + 1] = id end
	table.sort(holocronIDs)
	for index, id in ipairs(holocronIDs) do
		local def = cfg.Holocrons[id]
		local found = (state.discoveries or {})[id] ~= nil
		local label = vgui.Create("DLabel", holocronPanel)
		label:SetPos(18, 46 + (index - 1) * 34) label:SetSize(700, 28) label:SetFont("MB.Med")
		label:SetTextColor(found and (def.color or ui.accent) or ui.faint)
		label:SetText((found and "DISCOVERED  " or "UNDISCOVERED  ") .. def.name)
	end
end

local function buildProfileTab(content)
	local function rebuild()
		if not IsValid(content) then MBLSCS.RefreshAdvancedUI = nil return end
		content:Clear()
		buildProfileContent(content)
	end
	MBLSCS.RefreshAdvancedUI = rebuild
	rebuild()
end

MilBase.AddMenuTab("JEDI PROFILE", 23.5, buildProfileTab, function(lp)
	return IsValid(lp) and lp:MBIsForceSensitive()
end)

-- Staff Jedi management --------------------------------------------------

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["JEDI MANAGEMENT"] = true

local function buildAdvancedAdmin(content)
	local ui = MilBase.UI
	local selected

	local function rebuild()
		if not IsValid(content) then MBLSCS.RefreshAdvancedAdminUI = nil return end
		content:Clear()
		local left = vgui.Create("DScrollPanel", content)
		left:Dock(LEFT) left:SetWide(285) left:DockMargin(0, 0, 14, 0)
		for _, playerEntity in ipairs(player.GetAll()) do
			local target = playerEntity
			local row = actionButton(left, target:MBName(), target:MBIsJedi() and ui.accent or ui.dim, function()
				selected = target
				sendAdmin("request", target, "")
			end)
			row:Dock(TOP) row:SetTall(42) row:DockMargin(0, 0, 0, 5)
		end

		local right = vgui.Create("DScrollPanel", content)
		right:Dock(FILL)
		if not IsValid(selected) then
			local empty = vgui.Create("DLabel", right)
			empty:Dock(TOP) empty:SetTall(80) empty:SetFont("MB.Tab") empty:SetTextColor(ui.dim)
			empty:SetText("Select a player to inspect their Jedi profile.")
			return
		end

		local state = MBLSCS.AdvancedAdminState[selected]
		local status = section(right, "JEDI PROFILE — " .. selected:MBName(), 100, selected:MBIsJedi() and ui.accent or ui.danger)
		status.Paint = function(_, w, h)
			MilBase.PaintPanel(w, h, selected:MBIsJedi() and ui.accent or ui.danger)
			draw.SimpleText(selected:MBName(), "MB.Big", 16, 12, ui.text)
			if state then
				draw.SimpleText((state.jedi and ((cfg.JediLevels or {})[state.level] or "Jedi") or "NON-JEDI")
					.. "  •  " .. MBLSCS.AlignmentName(state.alignment) .. " " .. state.alignment,
					"MB.Med", 16, 53, alignmentColor(state.alignment))
			else
				draw.SimpleText("REQUESTING PROFILE…", "MB.Small", 16, 57, ui.dim)
			end
		end
		if not state then return end

		local alignmentPanel = section(right, "ALIGNMENT & POTENTIAL", 105, ui.warn)
		local entry = vgui.Create("DTextEntry", alignmentPanel)
		entry:SetPos(16, 51) entry:SetSize(120, 34) entry:SetFont("MB.Small") entry:SetText("10")
		local add = actionButton(alignmentPanel, "ADD / REMOVE", ui.warn, function() sendAdmin("alignment_add", selected, entry:GetValue()) end)
		add:SetPos(146, 51) add:SetSize(145, 34)
		local set = actionButton(alignmentPanel, "SET EXACT", ui.accent, function() sendAdmin("alignment_set", selected, entry:GetValue()) end)
		set:SetPos(301, 51) set:SetSize(125, 34)
		local sensitive = actionButton(alignmentPanel, state.forceSensitive and "REMOVE SENSITIVITY" or "MARK FORCE-SENSITIVE",
			ui.accent, function() sendAdmin("sensitive", selected, state.forceSensitive and "0" or "1") end)
		sensitive:SetPos(446, 51) sensitive:SetSize(205, 34)

		local trials = section(right, "TRIAL CONTROL", 150, ui.ok)
		local combo = vgui.Create("DComboBox", trials)
		combo:SetPos(16, 51) combo:SetSize(280, 34) combo:SetValue("Select a trial")
		local trialID
		for id, def in pairs(cfg.Trials or {}) do combo:AddChoice(def.name, id) end
		combo.OnSelect = function(_, _, _, data) trialID = data end
		local start = actionButton(trials, "START", ui.accent, function() if trialID then sendAdmin("trial_start", selected, trialID) end end)
		start:SetPos(306, 51) start:SetSize(100, 34)
		local complete = actionButton(trials, "PASS", ui.ok, function() if trialID then sendAdmin("trial_complete", selected, trialID) end end)
		complete:SetPos(416, 51) complete:SetSize(100, 34)
		local reset = actionButton(trials, "FAIL / RESET", ui.danger, function() if trialID then sendAdmin("trial_reset", selected, trialID) end end)
		reset:SetPos(526, 51) reset:SetSize(120, 34)
		local mentorEnd = actionButton(trials, "END MENTORSHIP", ui.warn, function() sendAdmin("mentor_end", selected, "") end)
		mentorEnd:SetPos(16, 100) mentorEnd:SetSize(165, 34)
		local respecReady = actionButton(trials, "CLEAR RESPEC CD", ui.accent, function() sendAdmin("respec_ready", selected, "") end)
		respecReady:SetPos(191, 100) respecReady:SetSize(155, 34)

		local rows = MBLSCS.AuditRows[selected] or {}
		local audit = section(right, "PROFILE AUDIT & ROLLBACK", 60 + math.max(1, #rows) * 46, ui.danger)
		if #rows == 0 then
			local empty = vgui.Create("DLabel", audit)
			empty:SetPos(16, 48) empty:SetSize(500, 28) empty:SetFont("MB.Small") empty:SetTextColor(ui.dim)
			empty:SetText("No Jedi profile changes recorded yet.")
		end
		for index, rowData in ipairs(rows) do
			local auditRow = rowData
			local row = vgui.Create("DPanel", audit)
			row:SetPos(16, 45 + (index - 1) * 46) row:SetSize(900, 39)
			row.Paint = function(_, w, h)
				surface.SetDrawColor(255, 255, 255, 5) surface.DrawRect(0, 0, w, h)
				draw.SimpleText("#" .. auditRow.id .. "  " .. os.date("%d/%m %H:%M", tonumber(auditRow.time) or 0)
					.. "  " .. tostring(auditRow.actor_name or "SYSTEM"), "MB.Tiny", 10, 7, ui.dim)
				draw.SimpleText(tostring(auditRow.action or "Profile update"), "MB.Small", 10, 21, ui.text)
			end
			local rollback = actionButton(row, "ROLL BACK", ui.danger, function()
				Derma_Query("Restore the profile state from before audit #" .. auditRow.id .. "?",
					"Confirm rollback", "ROLL BACK", function() sendAdmin("rollback", selected, auditRow.id) end, "CANCEL")
			end)
			rollback:Dock(RIGHT) rollback:SetWide(125)
		end
	end

	MBLSCS.RefreshAdvancedAdminUI = function(target)
		if not IsValid(content) then MBLSCS.RefreshAdvancedAdminUI = nil return end
		if not target or target == selected then rebuild() end
	end
	rebuild()
end

MilBase.AddMenuTab("JEDI MANAGEMENT", 95, buildAdvancedAdmin, function(lp)
	return lp:IsListenServerHost() or lp:MBStaffLevel() >= (cfg.AdminLevel or 3)
end)
