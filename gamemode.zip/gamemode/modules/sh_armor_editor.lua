--[[
	Persistent armor-item creator/editor for the staff menu.

	Armor remains part of the normal MilBase inventory/equipment system. File
	definitions are treated as defaults, database rows are live overrides, and
	certification assignments are stored on the certification itself through its
	optional `armor` field. This keeps Quartermaster reconciliation authoritative.
]]

local cfg = MilBase.Config
local EDIT_LEVEL = tonumber(cfg.ArmorEditorLevel) or 4
local NET_REQUEST = "MilBase_ArmorEditorRequest"
local NET_SYNC = "MilBase_ArmorEditorSync"
local NET_ACTION = "MilBase_ArmorEditorAction"
local MAX_RAW = 256 * 1024

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function cleanList(source)
	local out, seen = {}, {}
	for _, value in ipairs(istable(source) and source or {}) do
		value = string.lower(trim(value))
		if value ~= "" and not seen[value] then
			out[#out + 1] = value
			seen[value] = true
		end
	end
	table.sort(out)
	return out
end

local function cleanBodygroups(source)
	local out = {}
	for key, value in pairs(istable(source) and source or {}) do
		local index = math.floor(tonumber(key) or -1)
		local bodygroup = math.floor(tonumber(value) or -1)
		if index >= 0 and index <= 128 and bodygroup >= 0 and bodygroup <= 255 then
			out[index] = bodygroup
		end
	end
	return out
end

local function assignedCertifications(armorID)
	local out = {}
	for _, certID in ipairs(MilBase.CertOrder or {}) do
		local cert = MilBase.Certs and MilBase.Certs[certID]
		if cert and cert.armor == armorID then out[#out + 1] = certID end
	end
	return out
end

function MilBase.ArmorToStored(item)
	if not istable(item) then return nil end
	return {
		id = trim(item.id),
		name = trim(item.name),
		desc = tostring(item.desc or ""),
		icon = trim(item.icon),
		model = trim(item.model),
		playerModel = trim(item.playerModel),
		armor = math.floor(tonumber(item.armor) or 0),
		w = math.floor(tonumber(item.w) or 3),
		h = math.floor(tonumber(item.h) or 3),
		bodygroups = cleanBodygroups(item.bodygroups),
	}
end

function MilBase.ArmorToEditable(item)
	local out = MilBase.ArmorToStored(item)
	if not out then return nil end
	out.certifications = assignedCertifications(out.id)
	return out
end

MilBase.ArmorFileDefaults = MilBase.ArmorFileDefaults or {}
if not MilBase._ArmorFileDefaultsCaptured then
	for id, item in pairs(MilBase.Items or {}) do
		if item and item.slot == "armor" then
			local copy = table.Copy(item)
			copy.id = nil
			MilBase.ArmorFileDefaults[id] = copy
		end
	end
	MilBase._ArmorFileDefaultsCaptured = true
end

local function cleanText(value, label, minimum, maximum)
	value = trim(value)
	value = string.gsub(value, "[%z\1-\8\11\12\14-\31]", "")
	if #value < (minimum or 0) then return nil, label .. " is required." end
	if #value > maximum then return nil, label .. " is too long." end
	return value
end

local function validateArmor(source, allowUnknownCertifications)
	if not istable(source) then return nil, "Malformed armor data." end
	local out, err = {}
	out.id, err = cleanText(source.id, "Armor id", 1, 64)
	if not out.id then return nil, err end
	out.id = string.lower(out.id)
	if not string.match(out.id, "^[%w_%-]+$") then
		return nil, "Armor id may contain only letters, numbers, underscores and hyphens."
	end
	out.name, err = cleanText(source.name, "Name", 1, 96)
	if not out.name then return nil, err end
	out.desc, err = cleanText(source.desc or "", "Description", 0, 1200)
	if not out.desc then return nil, err end
	out.icon, err = cleanText(source.icon or "", "Icon", 0, 192)
	if not out.icon then return nil, err end
	out.model, err = cleanText(source.model or "models/aussiwozzi/cgi/base/chest.mdl", "World model", 1, 192)
	if not out.model then return nil, err end
	out.playerModel, err = cleanText(source.playerModel or "", "Player model", 0, 192)
	if not out.playerModel then return nil, err end
	if out.playerModel == "" then out.playerModel = nil end
	out.armor = math.Clamp(math.floor(tonumber(source.armor) or 0), 0,
		math.max(0, math.floor(tonumber(cfg.ArmorMaximum) or 255)))
	out.w = math.Clamp(math.floor(tonumber(source.w) or 3), 1, 10)
	out.h = math.Clamp(math.floor(tonumber(source.h) or 3), 1, 10)
	out.bodygroups = cleanBodygroups(source.bodygroups)
	out.certifications = cleanList(source.certifications)
	if #out.certifications > 64 then return nil, "Too many certification assignments." end
	for _, certID in ipairs(out.certifications) do
		if not string.match(certID, "^[%w_%-]+$") then return nil, "Invalid certification id: " .. certID end
		if not allowUnknownCertifications and not (MilBase.Certs and MilBase.Certs[certID]) then
			return nil, "Unknown certification: " .. certID
		end
	end
	out.slot = "armor"
	out.stack = 1
	return out
end

MilBase.ValidateArmorDefinition = validateArmor

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_SYNC)
	util.AddNetworkString(NET_ACTION)

	local TABLE_SQL = [[CREATE TABLE IF NOT EXISTS frontier_armor_definitions (
		id VARCHAR(64) PRIMARY KEY,
		data TEXT,
		source VARCHAR(16),
		updated_by VARCHAR(32),
		updated_at INTEGER
	)]]
	MilBase.DB.Run(TABLE_SQL)
	hook.Add("MilBase.DBReady", "MilBase.ArmorEditor.CreateTable", function() MilBase.DB.Run(TABLE_SQL) end)

	MilBase.ArmorEditorOverrides = MilBase.ArmorEditorOverrides or {}

	local function canEdit(ply)
		return IsValid(ply) and (ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL)
	end

	local function payload()
		local definitions, meta = {}, {}
		for id, item in pairs(MilBase.Items or {}) do
			if item and item.slot == "armor" then
				definitions[#definitions + 1] = MilBase.ArmorToEditable(item)
				meta[id] = {
					file = MilBase.ArmorFileDefaults[id] ~= nil,
					overridden = MilBase.ArmorEditorOverrides[id] == true,
				}
			end
		end
		table.sort(definitions, function(a, b)
			return string.lower(a.name or a.id) < string.lower(b.name or b.id)
		end)
		return { definitions = definitions, meta = meta }
	end

	local function sendSync(target)
		local compressed = util.Compress(util.TableToJSON(payload()) or "{}")
		if not compressed then return end
		net.Start(NET_SYNC)
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	MilBase.SyncArmorDefinitions = sendSync

	local function refreshArmorUsers(armorID)
		for _, ply in ipairs(player.GetAll()) do
			if ply.mb_inv then
				local equipped = ply.mb_inv.equip and ply.mb_inv.equip.armor
				if equipped and equipped.id == armorID and ply:Alive() and MilBase.ApplyEquipment then
					MilBase.ApplyEquipment(ply)
				end
				if MilBase.SyncInventory then MilBase.SyncInventory(ply) end
			end
			if MilBase.QuartermasterUpdateArmorObjective then
				MilBase.QuartermasterUpdateArmorObjective(ply, "armor_editor")
			end
		end
	end

	local function refreshChangedCertificationHolders(changed)
		if table.IsEmpty(changed) then return end
		for _, ply in ipairs(player.GetAll()) do
			local affected = false
			for certID in pairs(changed) do
				if ply:MBHasPersistentCert(certID) or ply:MBHasTemporaryCert(certID) then
					affected = true
					break
				end
			end
			if affected then
				MilBase.Notify(ply, "Your certification armor assignment was updated.", "warn")
				if ply:Alive() and not (MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)) then
					timer.Simple(0, function() if IsValid(ply) then ply:Spawn() end end)
				end
			end
		end
	end

	local function applyCertificationMappings(actor, armorID, certificationIDs)
		if not MilBase.SaveCertificationDefinition then
			return false, "Certification editor backend is unavailable."
		end
		local selected = {}
		for _, certID in ipairs(certificationIDs or {}) do selected[certID] = true end
		local changed = {}
		for _, certID in ipairs(MilBase.CertOrder or {}) do
			local cert = MilBase.Certs[certID]
			local currentlyAssigned = cert and cert.armor == armorID
			local shouldAssign = selected[certID] == true
			if cert and currentlyAssigned ~= shouldAssign then
				local editable = MilBase.CertificationToEditable(cert)
				editable.armor = shouldAssign and armorID or ""
				local ok, err = MilBase.SaveCertificationDefinition(actor, editable, {
					skipRefresh = true, skipSync = true, skipLog = true,
				})
				if not ok then return false, err or ("Unable to update certification " .. certID .. ".") end
				changed[certID] = true
			end
		end
		if not table.IsEmpty(changed) then
			refreshChangedCertificationHolders(changed)
			if MilBase.SyncCertificationDefinitions then MilBase.SyncCertificationDefinitions() end
		end
		return true, nil, changed
	end

	local function storedArmor(clean)
		local copy = table.Copy(clean)
		copy.certifications = nil
		copy.slot = "armor"
		copy.stack = 1
		return copy
	end

	local function saveArmor(actor, source)
		local clean, err = validateArmor(source)
		if not clean then return false, err end
		local existed = MilBase.Items[clean.id] ~= nil
		if existed and MilBase.Items[clean.id].slot ~= "armor" then
			return false, "That id belongs to a non-armor item."
		end
		local item = storedArmor(clean)
		MilBase.RegisterItem(clean.id, item)
		MilBase.ArmorEditorOverrides[clean.id] = true
		local fileBacked = MilBase.ArmorFileDefaults[clean.id] ~= nil
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_armor_definitions (id, data, source, updated_by, updated_at) VALUES (%s,%s,%s,%s,%d)",
			MilBase.SQLStr(clean.id), MilBase.SQLStr(util.TableToJSON(MilBase.ArmorToStored(item))),
			MilBase.SQLStr(fileBacked and "override" or "custom"),
			MilBase.SQLStr(actor:SteamID64()), os.time()))

		local mapped, mappingError, changed = applyCertificationMappings(actor, clean.id, clean.certifications)
		if not mapped then return false, mappingError end
		refreshArmorUsers(clean.id)
		sendSync()
		if MilBase.Log then
			local certCount = table.Count(changed or {})
			MilBase.Log("staff", MilBase.LogTag(actor)
				.. (existed and " updated armor " or " created armor ") .. clean.id
				.. (certCount > 0 and (" and changed " .. certCount .. " certification mapping(s)") or ""), actor)
		end
		return true, existed and "Armor profile updated." or "Armor profile created."
	end

	local function resetArmor(actor, id)
		local default = MilBase.ArmorFileDefaults[id]
		if not default then return false, "That armor has no file default." end
		MilBase.RegisterItem(id, table.Copy(default))
		MilBase.ArmorEditorOverrides[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_armor_definitions WHERE id = " .. MilBase.SQLStr(id))
		refreshArmorUsers(id)
		sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " reset armor " .. id, actor) end
		return true, "Armor reset to its file definition. Certification assignments were preserved."
	end

	local function referencedByDefinitions(id)
		for _, faction in pairs(MilBase.Factions or {}) do
			if faction.issue and faction.issue[id] then return "a faction issue list" end
			for _, rank in ipairs(faction.ranks or {}) do
				if rank.issue and rank.issue[id] then return "a faction rank issue list" end
			end
		end
		for certID, cert in pairs(MilBase.Certs or {}) do
			if cert.armor == id then return "certification " .. certID end
			if cert.issue and cert.issue[id] then return "certification " .. certID .. " issue list" end
		end
		for cardID, card in pairs(MilBase.StarCards or {}) do
			if card.issue and card.issue[id] then return "Star Card " .. cardID end
		end
		return nil
	end

	local function deleteArmor(actor, id, done)
		if MilBase.ArmorFileDefaults[id] then done(false, "File armor must be reset, not deleted.") return end
		local item = MilBase.Items[id]
		if not item or item.slot ~= "armor" then done(false, "Unknown custom armor.") return end
		local reference = referencedByDefinitions(id)
		if reference then done(false, "Cannot delete: armor is referenced by " .. reference .. ".") return end
		MilBase.DB.Query("SELECT steamid FROM frontier_inventories WHERE data LIKE "
			.. MilBase.SQLStr("%" .. id .. "%") .. " LIMIT 1", function(rows)
			if rows and rows[1] then done(false, "Cannot delete: at least one character still owns this armor.") return end
			MilBase.Items[id] = nil
			MilBase.ArmorEditorOverrides[id] = nil
			MilBase.DB.Run("DELETE FROM frontier_armor_definitions WHERE id = " .. MilBase.SQLStr(id))
			sendSync()
			if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " deleted custom armor " .. id, actor) end
			done(true, "Custom armor deleted.")
		end)
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if not canEdit(ply) then return end
		if (ply.mb_nextArmorDefinitionRequest or 0) > CurTime() then return end
		ply.mb_nextArmorDefinitionRequest = CurTime() + 1
		sendSync(ply)
	end)

	net.Receive(NET_ACTION, function(_, ply)
		if not canEdit(ply) then return end
		if (ply.mb_nextArmorEditorAction or 0) > CurTime() then return end
		ply.mb_nextArmorEditorAction = CurTime() + 0.25
		local action = net.ReadString()
		if action == "save" then
			local length = net.ReadUInt(20)
			if length <= 0 or length > MAX_RAW then return end
			local compressed = net.ReadData(length)
			local raw = compressed and util.Decompress(compressed)
			if not raw or #raw > MAX_RAW then return end
			local ok, message = saveArmor(ply, util.JSONToTable(raw))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "reset" then
			local ok, message = resetArmor(ply, string.lower(trim(net.ReadString())))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "delete" then
			deleteArmor(ply, string.lower(trim(net.ReadString())), function(ok, message)
				if IsValid(ply) then MilBase.Notify(ply, message, ok and "ok" or "warn") end
			end)
		end
	end)

	local function loadOverrides()
		MilBase.DB.Query("SELECT id, data FROM frontier_armor_definitions", function(rows)
			rows = rows or {}
			table.sort(rows, function(a, b) return tostring(a.id or "") < tostring(b.id or "") end)
			for _, row in ipairs(rows) do
				local clean = validateArmor(util.JSONToTable(row.data or ""), true)
				if clean and clean.id == tostring(row.id or "") then
					MilBase.RegisterItem(clean.id, storedArmor(clean))
					MilBase.ArmorEditorOverrides[clean.id] = true
				end
			end
			sendSync()
			for armorID in pairs(MilBase.ArmorEditorOverrides) do refreshArmorUsers(armorID) end
		end)
	end
	loadOverrides()

	hook.Add("PlayerInitialSpawn", "MilBase.ArmorEditorSync", function(ply)
		timer.Simple(2, function() if IsValid(ply) then sendSync(ply) end end)
	end)

	return
end

-- Client -----------------------------------------------------------------

MilBase.ArmorEditorMeta = MilBase.ArmorEditorMeta or {}

local function decodeSync()
	local length = net.ReadUInt(20)
	local compressed = net.ReadData(length)
	local raw = compressed and util.Decompress(compressed)
	local payload = raw and util.JSONToTable(raw) or {}
	for id, item in pairs(MilBase.Items or {}) do
		if item and item.slot == "armor" then MilBase.Items[id] = nil end
	end
	for _, armor in ipairs(payload.definitions or {}) do
		local item = table.Copy(armor)
		item.certifications = nil
		item.slot = "armor"
		item.stack = 1
		MilBase.RegisterItem(item.id, item)
	end
	MilBase.ArmorEditorMeta = istable(payload.meta) and payload.meta or {}
	hook.Run("MilBase.ArmorEditorUpdated", payload)
end
net.Receive(NET_SYNC, decodeSync)

local function requestSync()
	net.Start(NET_REQUEST)
	net.SendToServer()
end

local function sendAction(action, value)
	net.Start(NET_ACTION)
		net.WriteString(action)
		if action == "save" then
			local compressed = util.Compress(util.TableToJSON(value) or "{}") or ""
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		else
			net.WriteString(tostring(value or ""))
		end
	net.SendToServer()
end

local function parseBodygroups(raw)
	local out = {}
	for entry in string.gmatch(tostring(raw or ""), "[^,\n]+") do
		local index, value = string.match(entry, "^%s*(%d+)%s*[=:]%s*(%d+)%s*$")
		if index then out[tonumber(index)] = tonumber(value) end
	end
	return out
end

local function bodygroupText(bodygroups)
	local out = {}
	for index, value in SortedPairs(bodygroups or {}) do out[#out + 1] = index .. "=" .. value end
	return table.concat(out, ", ")
end

local function currentArmorRows()
	local rows = {}
	for id, item in pairs(MilBase.Items or {}) do
		if item and item.slot == "armor" then rows[#rows + 1] = MilBase.ArmorToEditable(item) end
	end
	table.sort(rows, function(a, b) return string.lower(a.name or a.id) < string.lower(b.name or b.id) end)
	return rows
end

MilBase.StaffMenuTabs["ARMOR EDITOR"] = true
MilBase.AddMenuTab("ARMOR EDITOR", 93.5, function(content)
	local ui = MilBase.UI
	local selectedID
	local fields, certificationChecks = {}, {}

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(290)
	left:DockMargin(0, 0, 12, 0)
	left.Paint = function(_, w, h) MilBase.PaintPanel(w, h) end

	local newButton = vgui.Create("DButton", left)
	newButton:Dock(TOP)
	newButton:SetTall(38)
	newButton:SetText("NEW ARMOR PROFILE")

	local list = vgui.Create("DScrollPanel", left)
	list:Dock(FILL)
	list:DockMargin(8, 8, 8, 8)

	local form = vgui.Create("DScrollPanel", content)
	form:Dock(FILL)

	local function label(text)
		local control = vgui.Create("DLabel", form)
		control:Dock(TOP)
		control:SetTall(20)
		control:SetFont("MB.Tiny")
		control:SetText(text)
		control:SetTextColor(ui.dim)
		control:DockMargin(0, 5, 0, 2)
		return control
	end

	local function entry(key, text, multiline)
		label(text)
		local control = vgui.Create("DTextEntry", form)
		control:Dock(TOP)
		control:SetTall(multiline and 64 or 30)
		control:SetMultiline(multiline == true)
		fields[key] = control
		return control
	end

	entry("id", "ID (cannot be changed after creation)")
	entry("name", "DISPLAY NAME")
	entry("desc", "DESCRIPTION", true)
	entry("icon", "ICON MATERIAL PATH")
	entry("model", "WORLD ITEM MODEL")
	entry("playerModel", "PLAYER MODEL WHILE EQUIPPED (optional)")
	entry("armor", "ARMOR POINTS")
	entry("w", "INVENTORY WIDTH")
	entry("h", "INVENTORY HEIGHT")
	entry("bodygroups", "BODYGROUP OVERRIDES (index=value, comma separated)")

	label("CERTIFICATIONS THAT OVERRIDE TO THIS ARMOR")
	local certPanel = vgui.Create("DIconLayout", form)
	certPanel:Dock(TOP)
	certPanel:SetSpaceX(8)
	certPanel:SetSpaceY(4)
	certPanel:SetTall(math.max(34, math.ceil(math.max(1, #(MilBase.CertOrder or {})) / 3) * 28))
	for _, certID in ipairs(MilBase.CertOrder or {}) do
		local cert = MilBase.Certs[certID]
		local check = certPanel:Add("DCheckBoxLabel")
		check:SetSize(210, 24)
		check:SetText((cert and cert.name or certID) .. "  [" .. certID .. "]")
		check:SetTooltip("Characters with this certification receive this armor instead of their faction/rank armor.")
		certificationChecks[certID] = check
	end

	local actions = vgui.Create("DPanel", form)
	actions:Dock(TOP)
	actions:SetTall(48)
	actions:DockMargin(0, 12, 0, 0)
	actions.Paint = nil
	local save = vgui.Create("DButton", actions)
	save:SetText("SAVE")
	save:SetSize(120, 36)
	local reset = vgui.Create("DButton", actions)
	reset:SetText("RESET TO FILE")
	reset:SetSize(140, 36)
	local delete = vgui.Create("DButton", actions)
	delete:SetText("DELETE CUSTOM")
	delete:SetSize(140, 36)
	actions.PerformLayout = function()
		save:SetPos(0, 5)
		reset:SetPos(128, 5)
		delete:SetPos(276, 5)
	end

	local function loadForm(armor)
		armor = armor or {
			id = "", name = "", desc = "", icon = "armorstore/ui/commander_torso.png",
			model = "models/aussiwozzi/cgi/base/chest.mdl", playerModel = "",
			armor = 30, w = 3, h = 3, bodygroups = {}, certifications = {},
		}
		fields.id:SetText(armor.id or "")
		fields.id:SetEditable(selectedID == nil)
		fields.name:SetText(armor.name or "")
		fields.desc:SetText(armor.desc or "")
		fields.icon:SetText(armor.icon or "")
		fields.model:SetText(armor.model or "")
		fields.playerModel:SetText(armor.playerModel or "")
		fields.armor:SetText(tostring(armor.armor or 0))
		fields.w:SetText(tostring(armor.w or 3))
		fields.h:SetText(tostring(armor.h or 3))
		fields.bodygroups:SetText(bodygroupText(armor.bodygroups))
		local selected = {}
		for _, certID in ipairs(armor.certifications or {}) do selected[certID] = true end
		for certID, check in pairs(certificationChecks) do check:SetChecked(selected[certID] == true) end
		local meta = selectedID and MilBase.ArmorEditorMeta[selectedID] or {}
		reset:SetEnabled(meta.file == true and meta.overridden == true)
		delete:SetEnabled(selectedID ~= nil and meta.file ~= true)
	end

	local function selectArmor(id)
		selectedID = id
		local item = MilBase.Items[id]
		loadForm(MilBase.ArmorToEditable(item))
	end

	local function rebuildList()
		list:Clear()
		for _, armor in ipairs(currentArmorRows()) do
			local button = list:Add("DButton")
			button:Dock(TOP)
			button:SetTall(44)
			button:DockMargin(0, 0, 0, 4)
			button:SetText((armor.name or armor.id) .. "  [" .. armor.id .. "]\n"
				.. tostring(armor.armor or 0) .. " armor  •  " .. #(armor.certifications or {}) .. " cert override(s)")
			button.DoClick = function() selectArmor(armor.id) end
		end
		if selectedID and MilBase.Items[selectedID] then selectArmor(selectedID) else loadForm(nil) end
	end

	newButton.DoClick = function()
		selectedID = nil
		loadForm(nil)
	end

	save.DoClick = function()
		local certifications = {}
		for certID, check in pairs(certificationChecks) do
			if check:GetChecked() then certifications[#certifications + 1] = certID end
		end
		table.sort(certifications)
		sendAction("save", {
			id = selectedID or fields.id:GetValue(),
			name = fields.name:GetValue(),
			desc = fields.desc:GetValue(),
			icon = fields.icon:GetValue(),
			model = fields.model:GetValue(),
			playerModel = fields.playerModel:GetValue(),
			armor = tonumber(fields.armor:GetValue()) or 0,
			w = tonumber(fields.w:GetValue()) or 3,
			h = tonumber(fields.h:GetValue()) or 3,
			bodygroups = parseBodygroups(fields.bodygroups:GetValue()),
			certifications = certifications,
		})
	end
	reset.DoClick = function()
		if selectedID then
			Derma_Query("Discard this armor's database override and restore its Lua file definition? Certification assignments will remain.",
				"Reset Armor", "RESET", function() sendAction("reset", selectedID) end, "CANCEL")
		end
	end
	delete.DoClick = function()
		if selectedID then
			Derma_Query("Permanently delete this custom armor? Deletion is blocked while any character or definition references it.",
				"Delete Armor", "DELETE", function() sendAction("delete", selectedID) selectedID = nil end, "CANCEL")
		end
	end

	local hookID = "MilBase.ArmorEditorPanel." .. tostring(content)
	hook.Add("MilBase.ArmorEditorUpdated", hookID, rebuildList)
	hook.Add("MilBase.CertEditorUpdated", hookID, rebuildList)
	content.OnRemove = function()
		hook.Remove("MilBase.ArmorEditorUpdated", hookID)
		hook.Remove("MilBase.CertEditorUpdated", hookID)
	end
	requestSync()
	rebuildList()
end, function(ply)
	return ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL
end)
