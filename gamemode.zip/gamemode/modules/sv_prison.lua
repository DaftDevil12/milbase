-- Persistent shipboard prison, custody, riots, ship takeovers and allied transfers.
if not SERVER or MilBase._PrisonServerLoaded then return end
MilBase._PrisonServerLoaded = true

local P = MilBase.Prison
local cfg = MilBase.Config.Prison or {}
if cfg.Enabled == false then return end

local N = MilBase.Naval
local G = MilBase.Galaxy
local STATE_TABLE = "frontier_prison_state"
local LAYOUT_TABLE = "frontier_prison_layout"
local mapKey = game.GetMap()

P.State = P.State or {}
P.Layout = P.Layout or {}
P.Cells = P.Cells or {}
P.MarkersByKind = P.MarkersByKind or {}
P.PrisonerEntities = P.PrisonerEntities or {}
P._loaded = P._loaded or false
P._layoutLoaded = P._layoutLoaded or false

local NET_LAYOUT = "MilBase_Prison_Layout"
local NET_LAYOUT_REQUEST = "MilBase_Prison_LayoutRequest"
local NET_COMMS = "MilBase_Prison_Comms"
local NET_COMMS_DATA = "MilBase_Prison_CommsData"
util.AddNetworkString(NET_LAYOUT)
util.AddNetworkString(NET_LAYOUT_REQUEST)
util.AddNetworkString(NET_COMMS)
util.AddNetworkString(NET_COMMS_DATA)

local function unix() return os.time() end
local function clean(value, length)
	return string.sub(string.Trim(tostring(value or "")), 1, length or 512)
end
local function clamp(value, minimum, maximum)
	value = tonumber(value or 0) or 0
	if minimum then value = math.max(minimum, value) end
	if maximum then value = math.min(maximum, value) end
	return value
end
local function tableCopy(value)
	return istable(value) and table.Copy(value) or {}
end
local function vecRecord(value)
	if not isvector(value) then return { x = 0, y = 0, z = 0 } end
	return { x = value.x, y = value.y, z = value.z }
end
local function angRecord(value)
	if not isangle(value) then return { p = 0, y = 0, r = 0 } end
	return { p = value.p, y = value.y, r = value.r }
end
local function recordVec(value)
	if isvector(value) then return value end
	if not istable(value) then return vector_origin end
	return Vector(tonumber(value.x or value[1]) or 0,
		tonumber(value.y or value[2]) or 0,
		tonumber(value.z or value[3]) or 0)
end
local function recordAng(value)
	if isangle(value) then return value end
	if not istable(value) then return angle_zero end
	return Angle(tonumber(value.p or value[1]) or 0,
		tonumber(value.y or value[2]) or 0,
		tonumber(value.r or value[3]) or 0)
end
local function playerName(ply)
	if not IsValid(ply) then return "SYSTEM" end
	return clean(ply.MBName and ply:MBName() or ply:Nick(), 96)
end
local function steamID(ply)
	return IsValid(ply) and ply:SteamID64() or "0"
end

local function defaultState()
	return {
		version = 3,
		nextPrisoner = 0,
		alert = "normal",
		schedule = "lockdown",
		scheduleIndex = 1,
		scheduleEndsAt = unix() + 600,
		manualSchedule = false,
		prisoners = {},
		incidents = {},
		transfers = {},
		destinationUsage = {},
		cellState = {},
		alarm = { active = false, reason = "", level = "normal", zone = "", startedAt = 0 },
		lockdowns = { facility = false, zones = {}, cells = {} },
		takeover = {
			active = false, controlled = false, stage = "idle", currentIndex = 1,
			startedAt = 0, progress = 0, captured = {}, armed = false,
			systemsThreatened = false, commsCaptured = false,
		},
		facility = { food = 100, water = 100, cleanliness = 100, power = 100 },
	}
end

local function normaliseState(state)
	state = istable(state) and state or defaultState()
	state.version = math.max(3, tonumber(state.version) or 1)
	state.nextPrisoner = tonumber(state.nextPrisoner) or 0
	state.alert = clean(state.alert ~= "" and state.alert or "normal", 24)
	state.schedule = clean(state.schedule ~= "" and state.schedule or "lockdown", 32)
	state.scheduleIndex = math.max(1, tonumber(state.scheduleIndex) or 1)
	state.scheduleEndsAt = tonumber(state.scheduleEndsAt) or (unix() + 600)
	state.manualSchedule = state.manualSchedule == true
	state.prisoners = istable(state.prisoners) and state.prisoners or {}
	state.incidents = istable(state.incidents) and state.incidents or {}
	state.transfers = istable(state.transfers) and state.transfers or {}
	state.destinationUsage = istable(state.destinationUsage) and state.destinationUsage or {}
	state.cellState = istable(state.cellState) and state.cellState or {}
	state.alarm = istable(state.alarm) and state.alarm
		or { active = false, reason = "", level = "normal", zone = "", startedAt = 0 }
	state.alarm.active = state.alarm.active == true
	state.alarm.reason = clean(state.alarm.reason or "", 160)
	state.alarm.level = clean(state.alarm.level or "normal", 24)
	state.alarm.zone = clean(state.alarm.zone or "", 48)
	state.alarm.startedAt = tonumber(state.alarm.startedAt) or 0
	state.lockdowns = istable(state.lockdowns) and state.lockdowns
		or { facility = false, zones = {}, cells = {} }
	state.lockdowns.facility = state.lockdowns.facility == true
	state.lockdowns.zones = istable(state.lockdowns.zones) and state.lockdowns.zones or {}
	state.lockdowns.cells = istable(state.lockdowns.cells) and state.lockdowns.cells or {}
	state.takeover = istable(state.takeover) and state.takeover or {}
	state.takeover.active = state.takeover.active == true
	state.takeover.controlled = state.takeover.controlled == true
	state.takeover.stage = clean(state.takeover.stage or "idle", 32)
	state.takeover.currentIndex = math.max(1, tonumber(state.takeover.currentIndex) or 1)
	state.takeover.startedAt = tonumber(state.takeover.startedAt) or 0
	state.takeover.progress = math.max(0, tonumber(state.takeover.progress) or 0)
	state.takeover.captured = istable(state.takeover.captured) and state.takeover.captured or {}
	state.takeover.armed = state.takeover.armed == true
	state.takeover.systemsThreatened = state.takeover.systemsThreatened == true
	state.takeover.commsCaptured = state.takeover.commsCaptured == true
	for _, record in pairs(state.prisoners) do
		if record.status == "escaping" then
			record.status = "rioting"
			record.riotRole = "assault"
			record.escapeNode = nil
		end
		for index, value in ipairs(record.traits or {}) do
			if value == "escape_focused" then record.traits[index] = "takeover_planner" end
		end
		if record.suspicion and record.suspicion.kind == "escape" then
			record.suspicion.kind = "takeover"
			record.suspicion.label = "mapping restricted ship systems"
		end
	end
	state.facility = istable(state.facility) and state.facility or {}
	state.facility.food = clamp(state.facility.food or 100, 0, 100)
	state.facility.water = clamp(state.facility.water or 100, 0, 100)
	state.facility.cleanliness = clamp(state.facility.cleanliness or 100, 0, 100)
	state.facility.power = clamp(state.facility.power or 100, 0, 100)
	return state
end

local function serialisableState()
	local state = table.Copy(P.State or defaultState())
	for _, record in pairs(state.prisoners or {}) do
		record.entity = nil
		record.targetPos = nil
		record.targetAng = nil
		record.nextActionAt = nil
		record.lastThinkAt = nil
		record.escortEntity = nil
		record.escortAssistEntity = nil
		record.nextMeleeAt = nil
		record.riotActionAt = nil
		record.movementSpeed = nil
	end
	for _, transfer in pairs(state.transfers or {}) do transfer.transport = nil end
	return state
end

function P.SaveState(immediate)
	if not P._loaded then return end
	local function save()
		timer.Remove("MilBase.Prison.Save")
		local json = util.TableToJSON(serialisableState(), false) or "{}"
		MilBase.DB.Run("REPLACE INTO " .. STATE_TABLE
			.. " (map_key,state_json,updated_at) VALUES ("
			.. MilBase.SQLStr(mapKey) .. "," .. MilBase.SQLStr(json) .. "," .. unix() .. ")")
	end
	if immediate then save() return end
	timer.Create("MilBase.Prison.Save", math.max(0.1, tonumber(cfg.StateSaveDelay) or 2), 1, save)
end

function P.AddIncident(kind, text, prisoner, actor, severity)
	P.State.incidents = P.State.incidents or {}
	local row = {
		time = unix(), kind = clean(kind, 32), text = clean(text, 512),
		prisonerID = prisoner and prisoner.id or "",
		prisonerName = prisoner and prisoner.name or "",
		actor = playerName(actor), severity = clamp(severity or 1, 0, 5),
	}
	table.insert(P.State.incidents, 1, row)
	while #P.State.incidents > math.max(10, tonumber(cfg.MaximumIncidentHistory) or 80) do
		table.remove(P.State.incidents)
	end
	P.SaveState()
	return row
end

local function notifyGuards(text, kind)
	for _, ply in ipairs(player.GetAll()) do
		if P.CanUse(ply) then MilBase.Notify(ply, text, kind or "warn") end
	end
end
P.NotifyGuards = notifyGuards

local function markerPayload(row)
	return {
		id = row.id,
		kind = row.kind,
		group = row.group,
		name = row.name,
		pos = row.pos,
		ang = row.ang,
		data = row.data or {},
		mapID = row.mapID or -1,
		class = row.class or "",
		model = row.model or "",
	}
end

function P.BroadcastLayout(target)
	local rows = {}
	for _, row in pairs(P.Layout or {}) do rows[#rows + 1] = markerPayload(row) end
	table.sort(rows, function(a, b) return tonumber(a.id) < tonumber(b.id) end)
	local receivers = {}
	if IsValid(target) then
		if P.CanConfigure(target) then receivers[1] = target end
	else
		for _, ply in ipairs(player.GetAll()) do if P.CanConfigure(ply) then receivers[#receivers + 1] = ply end end
	end
	if #receivers == 0 then return end
	net.Start(NET_LAYOUT)
		net.WriteTable(rows)
	net.Send(receivers)
end

local function resolveLinkedEntity(row)
	if not row then return nil end
	local mapID = tonumber(row.mapID) or -1
	if mapID >= 0 and ents.GetMapCreatedEntity then
		local ent = ents.GetMapCreatedEntity(mapID)
		if IsValid(ent) then return ent end
	end
	local best, bestDistance
	for _, ent in ipairs(ents.FindInSphere(row.pos, 128)) do
		if IsValid(ent) and (row.class == "" or ent:GetClass() == row.class) then
			if row.model == "" or ent:GetModel() == row.model then
				local distance = ent:GetPos():DistToSqr(row.pos)
				if not bestDistance or distance < bestDistance then best, bestDistance = ent, distance end
			end
		end
	end
	return best
end
P.ResolveLinkedEntity = resolveLinkedEntity

function P.RebuildLayout()
	P.MarkersByKind = {}
	P.Cells = {}
	for _, row in pairs(P.Layout or {}) do
		P.MarkersByKind[row.kind] = P.MarkersByKind[row.kind] or {}
		table.insert(P.MarkersByKind[row.kind], row)
		if string.StartWith(row.kind, "cell_") then
			local id = P.CleanID(row.group, "cell_1")
			P.Cells[id] = P.Cells[id] or {
				id = id, name = string.upper(string.gsub(id, "_", " ")),
				capacity = tonumber(cfg.StandardCellCapacity) or 2, markers = {},
				security = "general", cleanliness = 100, damage = 0,
			}
			P.Cells[id].markers[row.kind] = row
			if row.kind == "cell_origin" then
				P.Cells[id].name = clean(row.name ~= "" and row.name or P.Cells[id].name, 80)
				P.Cells[id].security = clean(row.data and row.data.security or "general", 24)
				local requestedCapacity = tonumber(row.data and row.data.capacity) or tonumber(cfg.StandardCellCapacity) or 2
				P.Cells[id].capacity = P.Cells[id].security == "isolation" and 1 or math.Clamp(requestedCapacity, 1, 2)
			end
		end
	end
	for _, rows in pairs(P.MarkersByKind) do
		table.sort(rows, function(a, b)
			local ai = tonumber(a.data and a.data.index) or tonumber(a.id) or 0
			local bi = tonumber(b.data and b.data.index) or tonumber(b.id) or 0
			return ai < bi
		end)
	end
end

function P.GetMarker(kind, group)
	local rows = P.MarkersByKind[tostring(kind or "")] or {}
	if group and group ~= "" then
		local wanted = P.CleanID(group)
		for _, row in ipairs(rows) do if P.CleanID(row.group) == wanted then return row end end
	end
	return rows[1]
end

function P.GetMarkers(kind, group)
	local out = {}
	for _, row in ipairs(P.MarkersByKind[tostring(kind or "")] or {}) do
		if not group or group == "" or P.CleanID(row.group) == P.CleanID(group) then out[#out + 1] = row end
	end
	return out
end

local function validLayoutKind(kind)
	kind = P.CleanID(kind)
	for _, allowed in ipairs(cfg.LayoutKinds or {}) do if allowed == kind then return true end end
	return false
end

function P.AddLayoutMarker(ply, kind, pos, ang, group, name, data, linked)
	if not P.CanConfigure(ply) or not isvector(pos) then return false, "Access denied" end
	kind = P.CleanID(kind, "intake")
	if not validLayoutKind(kind) then return false, "Unknown prison marker type" end
	group = P.CleanID(group, string.StartWith(kind, "cell_") and "cell_1" or "facility")
	name = clean(name ~= "" and name or ((cfg.LayoutLabels or {})[kind] or kind), 80)
	data = istable(data) and data or {}
	local mapID, class, model = -1, "", ""
	if IsValid(linked) and not linked:IsPlayer() and not linked:IsWorld() then
		mapID = linked.MapCreationID and tonumber(linked:MapCreationID()) or -1
		class, model = linked:GetClass(), linked:GetModel() or ""
		pos, ang = linked:GetPos(), linked:GetAngles()
	end
	local json = util.TableToJSON(data, false) or "{}"
	local sql = "INSERT INTO " .. LAYOUT_TABLE
		.. " (map_key,kind_name,group_id,label,pos_json,ang_json,data_json,map_entity_id,entity_class,entity_model) VALUES ("
		.. MilBase.SQLStr(mapKey) .. "," .. MilBase.SQLStr(kind) .. "," .. MilBase.SQLStr(group) .. ","
		.. MilBase.SQLStr(name) .. "," .. MilBase.SQLStr(util.TableToJSON(vecRecord(pos)) or "{}") .. ","
		.. MilBase.SQLStr(util.TableToJSON(angRecord(ang)) or "{}") .. "," .. MilBase.SQLStr(json) .. ","
		.. math.floor(mapID or -1) .. "," .. MilBase.SQLStr(class) .. "," .. MilBase.SQLStr(model) .. ")"
	MilBase.DB.Insert(sql, function(id)
		if not id then return end
		P.Layout[id] = { id = id, kind = kind, group = group, name = name, pos = pos, ang = ang,
			data = data, mapID = mapID, class = class, model = model }
		P.RebuildLayout()
		P.BroadcastLayout()
	end)
	return true, "Prison marker added: " .. name
end

local function nearestLayout(kind, group, pos, radius)
	local best, bestDistance
	for _, row in pairs(P.Layout or {}) do
		if (not kind or row.kind == kind) and (not group or group == "" or row.group == group) then
			local distance = row.pos:DistToSqr(pos)
			if distance <= (radius or 350) ^ 2 and (not bestDistance or distance < bestDistance) then
				best, bestDistance = row, distance
			end
		end
	end
	return best
end

function P.UpdateNearestLayout(ply, kind, pos, ang, group, name, data, linked)
	if not P.CanConfigure(ply) then return false, "Access denied" end
	kind, group = P.CleanID(kind), P.CleanID(group)
	local row = nearestLayout(kind, group, pos, 420)
	if not row then return false, "No nearby matching marker" end
	name = clean(name ~= "" and name or row.name, 80)
	data = istable(data) and data or row.data or {}
	local mapID, class, model = row.mapID or -1, row.class or "", row.model or ""
	if IsValid(linked) and not linked:IsWorld() and not linked:IsPlayer() then
		mapID = linked.MapCreationID and tonumber(linked:MapCreationID()) or -1
		class, model = linked:GetClass(), linked:GetModel() or ""
		pos, ang = linked:GetPos(), linked:GetAngles()
	end
	MilBase.DB.Run("UPDATE " .. LAYOUT_TABLE .. " SET label=" .. MilBase.SQLStr(name)
		.. ",pos_json=" .. MilBase.SQLStr(util.TableToJSON(vecRecord(pos)) or "{}")
		.. ",ang_json=" .. MilBase.SQLStr(util.TableToJSON(angRecord(ang)) or "{}")
		.. ",data_json=" .. MilBase.SQLStr(util.TableToJSON(data) or "{}")
		.. ",map_entity_id=" .. math.floor(mapID or -1)
		.. ",entity_class=" .. MilBase.SQLStr(class) .. ",entity_model=" .. MilBase.SQLStr(model)
		.. " WHERE id=" .. tonumber(row.id))
	row.name, row.pos, row.ang, row.data = name, pos, ang, data
	row.mapID, row.class, row.model = mapID, class, model
	P.RebuildLayout(); P.BroadcastLayout()
	return true, "Prison marker updated: " .. name
end

function P.RemoveNearestLayout(ply, kind, pos, group)
	if not P.CanConfigure(ply) then return false, "Access denied" end
	local row = nearestLayout(P.CleanID(kind), P.CleanID(group), pos, 420)
	if not row then return false, "No nearby matching marker" end
	MilBase.DB.Run("DELETE FROM " .. LAYOUT_TABLE .. " WHERE id=" .. tonumber(row.id))
	P.Layout[row.id] = nil
	P.RebuildLayout(); P.BroadcastLayout()
	return true, "Prison marker removed: " .. row.name
end

local function cellOccupants(cellID)
	local result = {}
	for _, record in pairs(P.State.prisoners or {}) do
		if record.cellID == cellID and record.status ~= "transferred" and record.status ~= "released"
		and record.status ~= "escaped" and record.status ~= "deceased" then result[#result + 1] = record end
	end
	return result
end

function P.ActivePrisoners()
	local result = {}
	for _, record in pairs(P.State.prisoners or {}) do
		if record.status ~= "transferred" and record.status ~= "released"
		and record.status ~= "escaped" and record.status ~= "deceased" then result[#result + 1] = record end
	end
	table.sort(result, function(a, b) return tostring(a.name) < tostring(b.name) end)
	return result
end

function P.CapacitySnapshot()
	local proper, occupied = 0, 0
	for id, cell in pairs(P.Cells or {}) do
		proper = proper + math.max(1, tonumber(cell.capacity) or 2)
		occupied = occupied + #cellOccupants(id)
	end
	local active = #P.ActivePrisoners()
	local ratio = proper > 0 and active / proper or (active > 0 and 2 or 0)
	local level = ratio >= (cfg.CriticalOvercrowdingRatio or 1.5) and "critical"
		or ratio >= (cfg.SevereOvercrowdingRatio or 1.2) and "severe"
		or ratio >= (cfg.MildOvercrowdingRatio or 1.01) and "mild" or "normal"
	return { capacity = proper, occupied = occupied, active = active, ratio = ratio, level = level,
		overflow = math.max(0, active - proper) }
end

local function chooseCell(record)
	local desired = record.risk == "critical" and "isolation" or nil
	local candidates = {}
	for id, cell in pairs(P.Cells or {}) do
		local count = #cellOccupants(id)
		local capacity = math.max(1, tonumber(cell.capacity) or 2)
		if count < capacity and (not desired or cell.security == desired or cell.security == "high") then
			candidates[#candidates + 1] = { id = id, count = count, capacity = capacity, cell = cell }
		end
	end
	if #candidates == 0 and desired then
		for id, cell in pairs(P.Cells or {}) do
			local count = #cellOccupants(id)
			if count < math.max(1, tonumber(cell.capacity) or 2) then candidates[#candidates + 1] = { id=id,count=count,cell=cell } end
		end
	end
	table.sort(candidates, function(a, b) return a.count < b.count end)
	return candidates[1] and candidates[1].id or nil
end
P.ChooseCell = chooseCell

local function bodygroupSnapshot(ent)
	local out = {}
	if not IsValid(ent) then return out end
	for index = 0, math.max(0, ent:GetNumBodyGroups() - 1) do out[tostring(index)] = ent:GetBodygroup(index) end
	return out
end

local function applyAppearance(ent, record)
	if not IsValid(ent) then return end
	local model = clean(record.model, 260)
	if util.IsValidModel(model) then ent:SetModel(model) end
	ent:SetSkin(math.max(0, tonumber(record.skin) or 0))
	for index, value in pairs(record.bodygroups or {}) do ent:SetBodygroup(tonumber(index) or 0, tonumber(value) or 0) end
end

local function cellMarkerForRecord(record, cell)
	if not record or not cell then return nil end
	local occupants = cellOccupants(cell.id)
	table.sort(occupants, function(a, b) return tostring(a.createdAt or 0) .. tostring(a.id or "") < tostring(b.createdAt or 0) .. tostring(b.id or "") end)
	local slot = 1
	for index, other in ipairs(occupants) do if other.id == record.id then slot = index break end end
	if slot > 2 then return cell.markers.cell_origin end
	return cell.markers[slot == 1 and "cell_spawn_1" or "cell_spawn_2"] or cell.markers.cell_origin
end
P.CellMarkerForRecord = cellMarkerForRecord

local function recordPosition(record)
	if record.status == "overflow" then
		local marker = P.GetMarker("overflow") or P.GetMarker("intake")
		return marker and marker.pos or vector_origin, marker and marker.ang or angle_zero
	end
	if record.status == "awaiting_escort" or record.status == "intake" then
		local marker = P.GetMarker("intake") or P.GetMarker("entrance")
		return marker and marker.pos or vector_origin, marker and marker.ang or angle_zero
	end
	local cell = P.Cells[record.cellID or ""]
	if cell then
		local marker = cellMarkerForRecord(record, cell)
		if marker then return marker.pos, marker.ang end
	end
	local overflow = P.GetMarker("overflow") or P.GetMarker("intake")
	return overflow and overflow.pos or vector_origin, overflow and overflow.ang or angle_zero
end

function P.SpawnPrisonerEntity(record, pos, ang)
	if not record or record.status == "transferred" or record.status == "released"
	or record.status == "escaped" or record.status == "deceased" then return nil end
	local existing = P.PrisonerEntities[record.id]
	if IsValid(existing) then return existing end
	if not isvector(pos) then pos, ang = recordPosition(record) end
	ang = isangle(ang) and ang or angle_zero
	local ent = ents.Create("mb_prisoner")
	if not IsValid(ent) then return nil end
	applyAppearance(ent, record)
	ent:SetPos(pos)
	ent:SetAngles(Angle(0, (ang or angle_zero).y, 0))
	ent:SetPrisonerID(record.id)
	ent:SetDisplayName(record.name)
	ent:SetPrisonerRole(record.role or "DETAINEE")
	ent:SetPrisonStatus(record.status or "incarcerated")
	ent:SetCellID(record.cellID or "")
	ent:SetRiskLevel(record.risk or "low")
	ent:SetRestrained(record.restrained ~= false)
	ent:SetRioting(record.status == "rioting")
	ent:SetHealth(math.max(1, tonumber(record.health) or cfg.PrisonerHealth or 100))
	ent:Spawn(); ent:Activate()
	applyAppearance(ent, record)
	ent.mb_prisonRecord = record
	record.entity = ent
	P.PrisonerEntities[record.id] = ent
	return ent
end

local function removePrisonerEntity(record)
	if not record then return end
	local ent = record.entity or P.PrisonerEntities[record.id]
	record.entity = nil
	P.PrisonerEntities[record.id] = nil
	if IsValid(ent) then ent.mb_prisonRemoving = true ent:Remove() end
end
P.RemovePrisonerEntity = removePrisonerEntity

local function riskFromInspection(case, member)
	if case.trueFaction == "cis" or case.resistanceTriggered then return "critical" end
	if case.trueFaction == "pirate" or member.armed then return "high" end
	if case.criminal then return "medium" end
	return "low"
end

local function randomTraits(risk)
	local pool = cfg.PrisonerTraits or {}
	local traits = {}
	local count = risk == "critical" and 3 or risk == "high" and 2 or 1
	for _ = 1, count do
		local trait = pool[math.random(1, math.max(1, #pool))]
		if trait and not table.HasValue(traits, trait) then traits[#traits + 1] = trait end
	end
	if risk == "critical" and not table.HasValue(traits, "takeover_planner") then traits[#traits + 1] = "takeover_planner" end
	return traits
end

function P.CreateDetaineeFromInspection(case, member, index, actor)
	if not case or not member then return nil, "Invalid inspection detainee" end
	if member.prisonerID and P.State.prisoners[member.prisonerID] then return P.State.prisoners[member.prisonerID] end
	P.State.nextPrisoner = (tonumber(P.State.nextPrisoner) or 0) + 1
	local id = string.format("PR-%s-%04d", os.date("%y%m%d"), P.State.nextPrisoner)
	local source = member.entity
	local model = IsValid(source) and source:GetModel() or member.model or cfg.DefaultPrisonerModel
	if not util.IsValidModel(model or "") then model = (MilBase.Config.SmugglingInspections or {}).CrewModel or "models/Humans/Group03/male_07.mdl" end
	local species = MilBase.GetSpecies and MilBase.GetSpecies(member.speciesID)
		or (MilBase.SpeciesForModel and MilBase.SpeciesForModel(member.modelAlias or model))
	local speciesID = species and species.id or "human"
	local languageID = species and species.nativeLanguage or "basic"
	local skin = IsValid(source) and source:GetSkin() or member.skin or 0
	local bodygroups = IsValid(source) and bodygroupSnapshot(source) or tableCopy(member.bodygroups)
	local modelAlias = member.modelAlias or ""
	if speciesID == "human" and MilBase.ResolveSpeciesModel then
		local custodyModel, custodyAlias = MilBase.ResolveSpeciesModel("human", "prisoner")
		if custodyModel and util.IsValidModel(custodyModel) then
			model, modelAlias, skin, bodygroups = custodyModel, custodyAlias or "", 0, {}
		end
	end
	local pos = IsValid(source) and source:GetPos() or (P.GetMarker("entrance") and P.GetMarker("entrance").pos) or vector_origin
	local ang = IsValid(source) and source:GetAngles() or angle_zero
	local evidence = {}
	for _, row in pairs(case.evidence or {}) do evidence[#evidence + 1] = clean(row.label or row.text or row, 180) end
	local charges = {}
	if case.trueFaction == "pirate" then charges[#charges + 1] = "Piracy / armed criminal association" end
	if case.trueFaction == "cis" then charges[#charges + 1] = "CIS espionage / hostile infiltration" end
	if case.criminal then charges[#charges + 1] = "Smuggling and false identification" end
	if case.resistanceTriggered then charges[#charges + 1] = "Violent resistance to Republic custody" end
	local risk = riskFromInspection(case, member)
	local record = {
		id = id, name = clean(member.name, 96), role = clean(member.role, 64),
		trueFaction = clean(case.trueFaction or "civilian", 32), caseID = clean(case.id, 64), crewIndex = index,
		model = model, skin = skin, bodygroups = bodygroups,
		speciesID = speciesID,
		speciesName = species and species.name or "Human",
		languageID = languageID,
		languageManuallyAssigned = false,
		modelAlias = modelAlias,
		civilianPackAlias = modelAlias,
		civilianPackModel = modelAlias ~= "",
		speciesModelAssigned = true,
		sourceInspection = true,
		personality = member.personality or "guarded",
		inspectionQuestioned = tableCopy(member.questioned),
		inspectionStatements = tableCopy((member.statementRecords
			and #member.statementRecords > 0) and member.statementRecords or member.statements),
		guardRelations = tableCopy(member.relationships),
		charges = charges, evidence = evidence, arrestingOfficer = playerName(actor), arrestingSteamID = steamID(actor),
		createdAt = unix(), status = "awaiting_escort", risk = risk, traits = randomTraits(risk),
		needs = tableCopy(cfg.InitialNeeds), morale = clamp(member.morale or math.random(40, 80), 0, 100),
		compliance = risk == "low" and math.random(70, 95) or risk == "medium" and math.random(45, 75)
			or math.random(18, 55), health = cfg.PrisonerHealth or 100, restrained = true,
		cellID = "", escortSteamID = "", incidents = {}, contraband = {}, knownAssociates = {},
		intakeComplete = false, searched = member.searched == true, property = {},
		transfer = nil, interviews = {}, lastNeedUpdate = unix(), testCase = case.testCase == true,
	}
	if risk == "high" or risk == "critical" then
		if math.Rand(0, 1) < 0.35 then record.contraband[#record.contraband + 1] = "concealed lockpick" end
	end
	P.State.prisoners[id] = record
	member.prisonerID = id
	member.model, member.skin, member.bodygroups = model, record.skin, record.bodygroups
	member.speciesID, member.speciesName, member.languageID = speciesID, record.speciesName, languageID
	if IsValid(source) then source.mb_prisonRemoving = true source:Remove() member.entity = nil end
	P.SpawnPrisonerEntity(record, pos, ang)
	P.AddIncident("intake", record.name .. " entered Republic custody from customs case " .. case.id .. ".", record, actor, 1)
	P.SaveState()
	return record
end

local function updateNetwork(record)
	local ent = record and record.entity
	if not IsValid(ent) then return end
	ent:SetDisplayName(record.name or "DETAINEE")
	ent:SetPrisonerRole(record.role or "DETAINEE")
	ent:SetPrisonStatus(record.status or "incarcerated")
	ent:SetCellID(record.cellID or "")
	ent:SetRiskLevel(record.risk or "low")
	ent:SetRestrained(record.restrained ~= false)
	ent:SetRioting(record.status == "rioting")
	local needs = record.needs or {}
	ent:SetNeedSummary(string.format("F%02d W%02d S%02d H%02d", needs.food or 0, needs.water or 0, needs.sleep or 0, needs.hygiene or 0))
end
P.UpdateNetwork = updateNetwork

local function setDoor(cellID, open, lock)
	local cell = P.Cells[cellID or ""]
	local row = cell and cell.markers.cell_door
	local door = resolveLinkedEntity(row)
	if not IsValid(door) then return false end
	if open then
		door:Fire("Unlock", "", 0); door:Fire("Open", "", 0.05)
	else
		door:Fire("Close", "", 0)
		door:Fire(lock ~= false and "Lock" or "Unlock", "", lock ~= false and 0.8 or 0)
	end
	return true
end
P.SetCellDoor = setDoor

local function setTarget(record, marker, status)
	if not record then return end
	if marker then record.targetPos, record.targetAng = marker.pos, marker.ang end
	if status then record.status = status end
	updateNetwork(record)
end
P.SetPrisonerTarget = setTarget

local function nearbyGuards(pos)
	local count = 0
	for _, ply in ipairs(player.GetAll()) do
		if ply:Alive() and P.CanUse(ply) and ply:GetPos():DistToSqr(pos) <= (cfg.GuardPresenceRadius or 900) ^ 2 then count = count + 1 end
	end
	return count
end

local function safeMove(ent, target, speed, dt)
	if not IsValid(ent) or not isvector(target) then return true end
	local pos = ent:GetPos()
	local delta = target - pos
	delta.z = 0
	local distance = delta:Length()
	if distance <= 24 then return true end
	local direction = delta:GetNormalized()
	local step = math.min(distance, math.max(1, speed) * math.max(0.02, dt or 0.1))
	local desired = pos + direction * step
	local trace = util.TraceHull({ start = pos + Vector(0,0,2), endpos = desired + Vector(0,0,2),
		mins = Vector(-14,-14,0), maxs = Vector(14,14,72), filter = ent, mask = MASK_PLAYERSOLID })
	if trace.Hit then
		local side = direction:Cross(vector_up):GetNormalized()
		desired = pos + side * step
	end
	ent:SetPos(desired)
	ent:SetAngles(Angle(0, direction:Angle().y, 0))
	if ent.SelectPrisonActivity then ent:SelectPrisonActivity(speed > (cfg.PrisonerWalkSpeed or 82) + 10 and "run" or "walk") end
	return false
end

function P.UpdatePrisonerEntity(ent, dt)
	local record = IsValid(ent) and (ent.mb_prisonRecord or P.State.prisoners[ent:GetPrisonerID()]) or nil
	if not record then return end
	record.entity = ent
	local now = CurTime()
	if record.status == "escorting" then
		local escort
		for _, ply in ipairs(player.GetAll()) do if ply:SteamID64() == record.escortSteamID then escort = ply break end end
		if not IsValid(escort) or not escort:Alive() then
			record.escortSteamID = ""; record.status = "awaiting_escort"; updateNetwork(record); P.SaveState(); return
		end
		local target = escort:GetPos() - escort:GetForward() * (cfg.EscortFollowDistance or 82)
		if ent:GetPos():DistToSqr(escort:GetPos()) > (cfg.EscortBreakDistance or 850) ^ 2 then
			ent:SetPos(target + Vector(0,0,4))
		else safeMove(ent, target, cfg.PrisonerWalkSpeed or 82, dt) end
	elseif record.status == "rioting" then
		local target, distance
		for _, ply in ipairs(player.GetAll()) do
			if ply:Alive() and P.CanUse(ply) then
				local d = ent:GetPos():DistToSqr(ply:GetPos())
				if not distance or d < distance then target, distance = ply, d end
			end
		end
		if IsValid(target) then
			if distance <= 75 ^ 2 and now >= (record.nextMeleeAt or 0) then
				record.nextMeleeAt = now + (cfg.PrisonerMeleeCooldown or 1.1)
				if ent.SelectPrisonActivity then ent:SelectPrisonActivity("attack") end
				local dmg = DamageInfo(); dmg:SetDamage(cfg.PrisonerMeleeDamage or 8); dmg:SetAttacker(ent); dmg:SetInflictor(ent); dmg:SetDamageType(DMG_CLUB)
				target:TakeDamageInfo(dmg)
			else safeMove(ent, target:GetPos(), cfg.PrisonerRunSpeed or 132, dt) end
		end
	elseif isvector(record.targetPos) then
		if safeMove(ent, record.targetPos, cfg.PrisonerWalkSpeed or 82, dt) then
			record.targetPos = nil
			if record.status == "boarding" then
				record.boarded = true; ent:SetNoDraw(true); ent:SetSolid(SOLID_NONE)
			elseif record.status == "social" or record.status == "work" or record.status == "medical" then
				if ent.SelectPrisonActivity then ent:SelectPrisonActivity("idle") end
			else
				if ent.SelectPrisonActivity then ent:SelectPrisonActivity("idle") end
			end
			P.SaveState()
		end
	else
		if ent.SelectPrisonActivity then ent:SelectPrisonActivity("idle") end
	end
	updateNetwork(record)
end

function P.OnPrisonerRemoved(ent)
	if not IsValid(ent) or ent.mb_prisonRemoving then return end
	local record = P.State.prisoners[ent:GetPrisonerID()]
	if record then record.entity = nil P.PrisonerEntities[record.id] = nil end
end

function P.OnPrisonerDamaged(ent, dmg)
	local record = IsValid(ent) and P.State.prisoners[ent:GetPrisonerID()] or nil
	if not record then return end
	record.health = math.max(0, ent:Health())
	if record.health <= 0 then
		record.status = "deceased"; record.deceasedAt = unix(); P.AddIncident("death", record.name .. " died in Republic custody.", record, IsValid(dmg:GetAttacker()) and dmg:GetAttacker() or nil, 5)
		removePrisonerEntity(record)
	end
	P.SaveState()
end

local function playerNearMarker(ply, marker, distance)
	return IsValid(ply) and marker and ply:GetPos():DistToSqr(marker.pos) <= (distance or cfg.InteractionDistance or 190) ^ 2
end

local function isEngineer(ply)
	if not IsValid(ply) then return false end
	if ply:IsAdmin() then return true end
	if ply.MBHasCert and (ply:MBHasCert("engineer") or ply:MBHasCert("engineering")) then return true end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local name = string.lower(tostring(faction and faction.name or ""))
	return string.find(name, "engineer", 1, true) ~= nil or string.find(name, "maintenance", 1, true) ~= nil
end

function P.StartEscort(ply, record)
	if not P.CanUse(ply) or not record or not IsValid(record.entity) then return false, "Prisoner unavailable" end
	if ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then return false, "Move closer to the prisoner" end
	if record.status == "rioting" then return false, "Restrain the prisoner first" end
	record.escortSteamID = ply:SteamID64(); record.status = "escorting"; record.boarded = false
	updateNetwork(record); P.AddIncident("escort", playerName(ply) .. " took escort custody of " .. record.name .. ".", record, ply, 1); P.SaveState()
	return true, record.name .. " is following your escort."
end

function P.ProcessIntake(ply, record)
	local intake = P.GetMarker("intake")
	if not intake then return false, "No prison intake marker is configured" end
	if not playerNearMarker(ply, intake, 240) or not IsValid(record.entity)
	or record.entity:GetPos():DistToSqr(intake.pos) > 260 ^ 2 then return false, "Escort the prisoner to intake" end
	record.intakeComplete = true; record.escortSteamID = ""; record.searched = true
	local cellID = chooseCell(record)
	if cellID then
		record.cellID = cellID; record.status = record.risk == "critical" and "isolation" or "incarcerated"
		local cell = P.Cells[cellID]; setDoor(cellID, true, false)
		local marker = cellMarkerForRecord(record, cell)
		setTarget(record, marker, record.status)
		if P.ScheduleCellDoorClose then P.ScheduleCellDoorClose(cellID, true) end
	else
		record.cellID = ""; record.status = "overflow"; setTarget(record, P.GetMarker("overflow") or intake, "overflow")
		P.AddIncident("overcrowding", record.name .. " was placed in overflow holding because no proper bed was available.", record, ply, 3)
	end
	P.AddIncident("intake", record.name .. " completed intake and was assigned to " .. (record.cellID ~= "" and record.cellID or "overflow") .. ".", record, ply, 1)
	P.SaveState()
	return true, "Intake complete. Assigned to " .. (record.cellID ~= "" and string.upper(record.cellID) or "OVERFLOW HOLDING") .. "."
end

local function scheduleTarget(record, schedule)
	if schedule == "social" then return P.GetMarker("social") or P.GetMarker("exercise"), "social" end
	if schedule == "work" then return P.GetMarker("work"), "work" end
	if schedule == "interviews" then return P.GetMarker("interview") or P.GetMarker("medical"), "medical" end
	if schedule == "shower" then return P.GetMarker("shower"), "social" end
	local cell = P.Cells[record.cellID or ""]
	if cell then return cellMarkerForRecord(record, cell), record.risk == "critical" and "isolation" or "incarcerated" end
	return P.GetMarker("overflow") or P.GetMarker("intake"), "overflow"
end

function P.ApplySchedule(id, actor, manual, duration)
	id = P.CleanID(id, "lockdown")
	P.State.schedule = id
	P.State.manualSchedule = manual == true
	P.State.scheduleEndsAt = unix() + math.max(30, tonumber(duration) or 300)
	if id == "riot_lockdown" then P.State.alert = "riot" elseif id == "lockdown" and P.State.alert ~= "riot" then P.State.alert = "normal" end
	for _, record in ipairs(P.ActivePrisoners()) do
		if record.status ~= "awaiting_escort" and record.status ~= "escorting" and record.status ~= "transfer_pending"
		and record.status ~= "transfer_ready" and record.status ~= "boarding" and record.status ~= "rioting" then
			local marker, status = scheduleTarget(record, id)
			if record.cellID ~= "" then setDoor(record.cellID, id ~= "lockdown" and id ~= "riot_lockdown", false) end
			setTarget(record, marker, status)
		end
	end
	if id == "lockdown" or id == "riot_lockdown" then
		if P.ScheduleCellDoorClose then
			for cellID in pairs(P.Cells) do P.ScheduleCellDoorClose(cellID, true) end
		end
	end
	P.AddIncident("schedule", "Prison schedule changed to " .. (P.ScheduleLabels[id] or string.upper(id)) .. ".", nil, actor, 1)
	P.SaveState()
	return true
end

local function advanceSchedule()
	local rows = cfg.Schedule or {}
	if #rows == 0 then return end
	P.State.scheduleIndex = (tonumber(P.State.scheduleIndex) or 0) + 1
	if P.State.scheduleIndex > #rows then P.State.scheduleIndex = 1 end
	local row = rows[P.State.scheduleIndex]
	P.ApplySchedule(row.id, nil, false, row.seconds)
end

local function trait(record, name)
	for _, value in ipairs(record.traits or {}) do if value == name then return true end end
	return false
end

local cellRuntime

local function needAverage(record)
	local n = record.needs or {}
	return ((n.food or 0) + (n.water or 0) + (n.sleep or 0) + (n.hygiene or 0) + (n.social or 0)) / 5
end

local function startRiot(record, reason)
	if not record or record.status == "rioting" then return false end
	record.status = "rioting"; record.escortSteamID = ""; record.restrained = false
	if record.cellID ~= "" then setDoor(record.cellID, true, false) end
	updateNetwork(record)
	P.AddIncident("riot", record.name .. " joined a prison disturbance" .. (reason and (" (" .. reason .. ")") or "") .. ".", record, nil, 4)
	P.SaveState(); return true
end
P.StartRiot = startRiot

local function securityTick()
	if not P._loaded then return end
	local capacity = P.CapacitySnapshot()
	local active = P.ActivePrisoners()
	local riotCount = 0
	for _, record in ipairs(active) do if record.status == "rioting" then riotCount = riotCount + 1 end end
	if riotCount > 0 then P.State.alert = "riot" end
	for _, record in ipairs(active) do
		if record.status ~= "awaiting_escort" and record.status ~= "escorting" and record.status ~= "boarding"
		and record.status ~= "rioting" then
			local ent = record.entity
			local guards = IsValid(ent) and nearbyGuards(ent:GetPos()) or 0
			local neglect = math.max(0, (45 - needAverage(record)) / 45)
			local overcrowd = math.max(0, capacity.ratio - 1)
			local traitRiot = trait(record, "riot_leader") and 0.03 or trait(record, "aggressive") and 0.012 or 0
			local guardFactor = guards <= 0 and 1.7 or 1 / math.min(2, guards)
			local overflow = record.status == "overflow"
			local riotChance = (cfg.RiotBaseChance or 0.012) + neglect * 0.026 + overcrowd * 0.03 + traitRiot
			if overflow then riotChance = riotChance * (cfg.OverflowRiotMultiplier or 2.5) end
			riotChance = riotChance * guardFactor
			if #active >= (cfg.RiotMinimumPrisoners or 3)
			and math.Rand(0, 1) < riotChance then startRiot(record, capacity.level .. " overcrowding") end
		end
	end
	local newRiotCount = 0
	for _, record in ipairs(active) do if record.status == "rioting" then newRiotCount = newRiotCount + 1 end end
	if newRiotCount >= math.max(2, math.ceil(#active * 0.35)) then
		if P.State.alert ~= "riot" then notifyGuards("PRISON RIOT: multiple detainees are resisting custody.", "warn") end
		P.State.alert = "riot"
		for cellID in pairs(P.Cells) do
			if math.Rand(0, 1) < 0.45 then setDoor(cellID, true, false) end
			local runtime = cellRuntime(cellID)
			if math.Rand(0, 1) < 0.25 then runtime.damage = clamp(runtime.damage + math.random(3, 12), 0, 100) end
			if math.Rand(0, 1) < 0.12 and #runtime.contraband < 4 then runtime.contraband[#runtime.contraband + 1] = "improvised riot tool" end
		end
	end
	for _, transfer in pairs(P.State.transfers or {}) do
		if (transfer.status == "pickup_landed" or transfer.status == "boarding")
		and unix() - (tonumber(transfer.landedAt) or tonumber(transfer.boardingAt) or unix())
			> (cfg.TransferBoardingTimeout or 600)
		and P.AbortTransferPickup then
			P.AbortTransferPickup(transfer, "Boarding window expired")
		end
	end
	P.SaveState()
end

timer.Create("MilBase.Prison.Security", math.max(5, tonumber(cfg.SecurityTickSeconds) or 15), 0, securityTick)

local function needsTick()
	if not P._loaded then return end
	local decay = cfg.NeedDecayPerTick or {}
	local automatic = cfg.AutomaticLowPopulationCare ~= false and #player.GetAll() <= (cfg.AutomaticCareMaximumPlayers or 4)
	for _, record in ipairs(P.ActivePrisoners()) do
		record.needs = record.needs or tableCopy(cfg.InitialNeeds)
		for key, value in pairs(decay) do record.needs[key] = clamp((record.needs[key] or 100) - value, 0, 100) end
		if record.status == "incarcerated" or record.status == "isolation" then
			record.needs.sleep = clamp((record.needs.sleep or 0) + (P.State.schedule == "lockdown" and 2.8 or 0.25), 0, 100)
		end
		if record.status == "social" then record.needs.social = clamp((record.needs.social or 0) + 3.8, 0, 100) end
		if P.State.schedule == "shower" and record.status == "social" then record.needs.hygiene = clamp((record.needs.hygiene or 0) + 5, 0, 100) end
		if automatic and (record.needs.food or 100) <= (cfg.AutomaticCareMinimumNeed or 22) then record.needs.food = 65 end
		if automatic and (record.needs.water or 100) <= (cfg.AutomaticCareMinimumNeed or 22) then record.needs.water = 70 end
		if cfg.NeglectDamageEnabled ~= false and IsValid(record.entity) then
			if (record.needs.water or 100) <= (cfg.WaterCriticalThreshold or 8) then record.entity:SetHealth(math.max(1, record.entity:Health() - 2)) record.health = record.entity:Health() end
			if (record.needs.food or 100) <= (cfg.FoodCriticalThreshold or 5) then record.entity:SetHealth(math.max(1, record.entity:Health() - 1)) record.health = record.entity:Health() end
		end
		record.morale = clamp((record.morale or 60) + (needAverage(record) >= 65 and 0.4 or -0.8), 0, 100)
		updateNetwork(record)
	end
	P.State.facility.cleanliness = clamp((P.State.facility.cleanliness or 100) - #P.ActivePrisoners() * 0.06, 0, 100)
	for cellID in pairs(P.Cells or {}) do
		local runtime = cellRuntime(cellID)
		runtime.cleanliness = clamp(runtime.cleanliness - math.max(0.02, #cellOccupants(cellID) * 0.08), 0, 100)
	end
	if cfg.ScheduleAutomatic ~= false and not P.State.manualSchedule and unix() >= (P.State.scheduleEndsAt or 0) then advanceSchedule() end
	P.SaveState()
end

timer.Create("MilBase.Prison.Needs", math.max(10, tonumber(cfg.NeedsTickSeconds) or 30), 0, needsTick)

local function consumeNavalSupply(amount, reason, actor)
	amount = math.max(0, math.floor(tonumber(amount) or 0))
	if amount <= 0 or cfg.ConsumeNavalSupplies == false then return true end
	if not MilBase.Naval or not MilBase.Naval.State or not MilBase.Naval.ChangeResources then return true end
	local available = tonumber(MilBase.Naval.State.resources and MilBase.Naval.State.resources.supplies) or 0
	if available < amount then return false end
	MilBase.Naval.ChangeResources({ supplies = -amount }, reason, actor, true)
	return true
end

local function carePrisoner(ply, record, kind)
	if not record or not IsValid(record.entity) then return false, "Prisoner unavailable" end
	if ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then return false, "Move closer to the prisoner" end
	record.needs = record.needs or tableCopy(cfg.InitialNeeds)
	if kind == "meal" then
		local carried = ply:GetNWInt("mb_prison_meals", 0)
		if carried <= 0 and not ply:IsAdmin() then return false, "Collect meal trays from the marked food store first" end
		if carried > 0 then ply:SetNWInt("mb_prison_meals", carried - 1) end
		record.needs.food = 100; record.needs.water = clamp((record.needs.water or 0) + 12, 0, 100)
		P.AddIncident("meal", playerName(ply) .. " issued a meal to " .. record.name .. ".", record, ply, 0)
		return true, "Meal delivered."
	elseif kind == "water" then
		local carried = ply:GetNWInt("mb_prison_water", 0)
		if carried <= 0 and not ply:IsAdmin() then return false, "Collect water supplies from the marked water store first" end
		if carried > 0 then ply:SetNWInt("mb_prison_water", carried - 1) end
		record.needs.water = 100
		P.AddIncident("water", playerName(ply) .. " supplied water to " .. record.name .. ".", record, ply, 0)
		return true, "Water delivered."
	elseif kind == "medical" then
		record.needs.medical = 100; record.health = cfg.PrisonerHealth or 100; record.entity:SetHealth(record.health)
		P.AddIncident("medical", playerName(ply) .. " treated " .. record.name .. ".", record, ply, 1)
		return true, "Medical treatment completed."
	end
	return false, "Unknown care action"
end

local function transferDestinationAvailable(key, record)
	local dest = (cfg.AlliedPrisons or {})[key]
	if not dest then return false, "Unknown allied prison" end
	if not (dest.acceptedRisk or {})[record.risk or "low"] then return false, "Facility cannot accept this risk classification" end
	local used = tonumber((P.State.destinationUsage or {})[key]) or 0
	if used >= (tonumber(dest.capacity) or 0) then return false, "Facility reports no available cells" end
	local planet = G and G.Planets and (G.Planets[key] or G.Planets[string.lower(dest.planet or "")])
	local controller = string.lower(tostring(planet and (planet.control or planet.controller or planet.faction) or "republic"))
	if controller == "cis" or controller == "pirate" or controller == "hostile" then return false, "Destination is not under aligned control" end
	return true
end

function P.RequestTransfer(ply, destination, ids)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	destination = P.CleanID(destination)
	local dest = (cfg.AlliedPrisons or {})[destination]
	if not dest then return false, "Unknown destination" end
	local selected = {}
	for _, id in ipairs(ids or {}) do
		local record = P.State.prisoners[tostring(id)]
		if record and record.status ~= "transferred" and record.status ~= "released" and record.status ~= "escaped" then
			local existing = record.transfer and P.State.transfers[tostring(record.transfer)] or nil
			if existing and existing.status ~= "refused" and existing.status ~= "completed" then
				return false, record.name .. " is already assigned to " .. existing.id
			end
			local ok, reason = transferDestinationAvailable(destination, record)
			if not ok then return false, record.name .. ": " .. reason end
			selected[#selected + 1] = record
		end
	end
	if #selected == 0 then return false, "Select at least one active prisoner" end
	local transferID = "TX-" .. tostring(unix()) .. "-" .. tostring(math.random(100, 999))
	local transfer = { id = transferID, destination = destination, destinationName = dest.name,
		requestedAt = unix(), requestedBy = playerName(ply), prisonerIDs = {}, status = "pending" }
	for _, record in ipairs(selected) do
		record.transfer = transferID; record.status = "transfer_pending"; transfer.prisonerIDs[#transfer.prisonerIDs + 1] = record.id; updateNetwork(record)
	end
	P.State.transfers[transferID] = transfer
	P.AddIncident("transfer", "Transfer request " .. transferID .. " transmitted to " .. dest.name .. ".", nil, ply, 1)
	P.SaveState()
	local delay = math.Rand(cfg.TransferResponseMinimum or 4, cfg.TransferResponseMaximum or 9)
	timer.Simple(delay, function()
		local live = P.State.transfers[transferID]
		if not live or live.status ~= "pending" then return end
		local accepted, reason = true, "Custody accepted"
		for _, id in ipairs(live.prisonerIDs) do
			local record = P.State.prisoners[id]
			local ok, why = record and transferDestinationAvailable(destination, record)
			if not ok then accepted, reason = false, why break end
		end
		live.status = accepted and "accepted" or "refused"; live.responseAt = unix(); live.response = reason
		for _, id in ipairs(live.prisonerIDs) do
			local record = P.State.prisoners[id]
			if record then
				record.status = accepted and "transfer_ready" or (record.cellID ~= "" and "incarcerated" or "overflow")
				if not accepted then record.transfer = nil end
				updateNetwork(record)
			end
		end
		P.AddIncident("transfer", dest.name .. (accepted and " accepted " or " refused ") .. transferID .. ": " .. reason .. ".", nil, nil, accepted and 1 or 2)
		notifyGuards("TRANSFER " .. transferID .. ": " .. string.upper(reason) .. ".", accepted and "ok" or "warn")
		P.SaveState()
	end)
	return true, "Transfer request transmitted to " .. dest.name .. "."
end

local function navalPath(groupKey, field)
	local group = N and N.HangarConfig and N.HangarConfig.groups and N.HangarConfig.groups[groupKey]
	local path = {}
	for _, point in ipairs(group and group[field] or {}) do
		path[#path + 1] = { pos = recordVec(point.pos), ang = recordAng(point.ang) }
	end
	return path
end

local function transferLandingMarker()
	return P.GetMarker("transfer_laat")
end

local function transferBoardingMarker()
	return P.GetMarker("transfer_boarding")
end

local function copyFlightPoint(point)
	return { pos = Vector(point.pos.x, point.pos.y, point.pos.z),
		ang = isangle(point.ang) and Angle(point.ang.p, point.ang.y, point.ang.r) or angle_zero }
end

local function inboundTransferPath(groupKey, landing)
	local path = navalPath(groupKey, "returnPath")
	if #path < 1 then
		local launch = navalPath(groupKey, "launch")
		for index = #launch, 1, -1 do path[#path + 1] = copyFlightPoint(launch[index]) end
	end
	if #path < 1 then
		path[1] = {
			pos = landing.pos - landing.ang:Forward()
				* math.max(500, tonumber(cfg.TransferPickupApproachDistance) or 1800)
				+ Vector(0, 0, math.max(180, tonumber(cfg.TransferPickupApproachHeight) or 520)),
			ang = landing.ang,
		}
	end
	path[#path + 1] = { pos = landing.pos, ang = landing.ang }
	return path
end

local function outboundTransferPath(groupKey, landing)
	local path = { { pos = landing.pos, ang = landing.ang } }
	for _, point in ipairs(navalPath(groupKey, "launch")) do
		path[#path + 1] = copyFlightPoint(point)
	end
	if #path < 2 then
		path[2] = {
			pos = landing.pos - landing.ang:Forward()
				* math.max(500, tonumber(cfg.TransferPickupApproachDistance) or 1800)
				+ Vector(0, 0, math.max(180, tonumber(cfg.TransferPickupApproachHeight) or 520)),
			ang = landing.ang,
		}
	end
	return path
end

local function finishTransfer(transfer)
	if not transfer then return end
	local dest = (cfg.AlliedPrisons or {})[transfer.destination] or {}
	local names = {}
	for _, id in ipairs(transfer.prisonerIDs or {}) do
		local record = P.State.prisoners[id]
		if record then
			names[#names + 1] = record.name
			record.status = "transferred"
			record.transferredAt = unix()
			record.transferDestination = transfer.destination
			removePrisonerEntity(record)
			P.State.destinationUsage[transfer.destination] = (tonumber(P.State.destinationUsage[transfer.destination]) or 0) + 1
			P.State.prisoners[id] = nil
		end
	end
	transfer.status = "completed"
	transfer.completedAt = unix()
	transfer.prisonerNames = names
	transfer.transport = nil
	P.AddIncident("transfer", "LAAT transfer " .. transfer.id .. " departed for "
		.. (dest.name or transfer.destination) .. " with "
		.. (#names > 0 and table.concat(names, ", ") or "its assigned prisoners")
		.. ". Custody records were handed off and their cells are now free.", nil, nil, 1)
	notifyGuards("TRANSFER COMPLETE: " .. #names .. " prisoner(s) handed to "
		.. (dest.name or transfer.destination) .. ". Cells released.", "ok")
	P.SaveState()
end

local function pickupFailure(transfer, groupKey, reason)
	if not transfer then return end
	local previousStatus = transfer.status
	if IsValid(transfer.transport) then transfer.transport:Remove() end
	transfer.transport = nil
	transfer.status = "accepted"
	transfer.pickupError = tostring(reason or "Pickup unavailable")
	if previousStatus ~= "pickup_queued" and N and N.CloseHangar then
		N.CloseHangar(groupKey, "Prison pickup aborted")
	elseif previousStatus ~= "pickup_queued" and N and N.ReleaseExternalHangarOperation then
		N.ReleaseExternalHangarOperation(groupKey)
	end
	P.AddIncident("transfer", "LAAT pickup " .. transfer.id .. " aborted: "
		.. transfer.pickupError .. ".", nil, nil, 3)
	P.SaveState()
end

function P.CallTransferPickup(ply, transferID)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	local transfer = P.State.transfers[tostring(transferID or "")]
	if not transfer or transfer.status ~= "accepted" then return false, "Transfer has not been accepted" end
	local landing = transferLandingMarker()
	local boarding = transferBoardingMarker()
	if not landing then return false, "No Transfer LAAT landing marker is configured" end
	if not boarding then return false, "No Transfer LAAT boarding-ramp marker is configured" end
	local groupKey = P.CleanID(cfg.TransferHangarGroup, "main")
	transfer.status = "pickup_queued"
	transfer.pickupRequestedAt = unix()
	transfer.pickupRequestedBy = playerName(ply)
	transfer.pickupError = nil
	for _, id in ipairs(transfer.prisonerIDs or {}) do
		local record = P.State.prisoners[id]
		if record then
			record.status = "transfer_ready"
			record.boarded = false
			record.targetPos = nil
			record.targetAng = nil
			updateNetwork(record)
		end
	end

	local function spawnInbound()
		if transfer.status ~= "pickup_queued" then
			if N and N.ReleaseExternalHangarOperation then N.ReleaseExternalHangarOperation(groupKey) end
			return
		end
		local function spawn()
			local transport = ents.Create("mb_prison_transport")
			if not IsValid(transport) then
				pickupFailure(transfer, groupKey, "LAAT entity could not be created")
				return
			end
			local model = cfg.TransferTransportModel or "models/blu/laat.mdl"
			if util.IsValidModel(model) then transport:SetModel(model) end
			transport:SetTransferID(transfer.id)
			transport:SetDestinationName(transfer.destinationName or transfer.destination)
			local path = inboundTransferPath(groupKey, landing)
			transport:SetPos(path[1].pos)
			transport:SetAngles(path[1].ang)
			transport:Spawn()
			transport:Activate()
			transfer.transport = transport
			transfer.status = "pickup_inbound"
			P.AddIncident("transfer", "A prison-transfer LAAT entered the hangar approach for "
				.. transfer.id .. ".", nil, ply, 1)
			notifyGuards("TRANSFER LAAT INBOUND: clear the hangar landing area.", "info")
			P.SaveState()
			transport:BeginTransferArrival(path, function(craft)
				if not P.State.transfers[transfer.id] or transfer.status ~= "pickup_inbound" then return end
				transfer.transport = craft
				transfer.status = "pickup_landed"
				transfer.landedAt = unix()
				P.AddIncident("transfer", "Transfer LAAT landed for " .. transfer.id
					.. ". Guards must escort each prisoner to the boarding ramp.", nil, ply, 1)
				notifyGuards("TRANSFER LAAT LANDED: escort assigned prisoners to the boarding ramp.", "ok")
				P.SaveState()
			end)
		end
		if N and N.OpenHangar then
			N.OpenHangar(groupKey, "Inbound prison transfer LAAT", spawn)
		else
			spawn()
		end
	end

	if cfg.UseNavalLaunchRoute ~= false and N and N.RequestExternalHangarOperation then
		local ok, position, state = N.RequestExternalHangarOperation(groupKey,
			"Prison pickup " .. transfer.id, spawnInbound)
		if not ok then
			pickupFailure(transfer, groupKey, "Hangar operation could not be scheduled")
			return false, "The hangar could not schedule this LAAT pickup"
		end
		P.SaveState()
		return true, state == "queued" and ("LAAT pickup queued at hangar position " .. position .. ".")
			or "LAAT pickup cleared for approach."
	end
	spawnInbound()
	return true, "LAAT pickup cleared for approach."
end

P.BeginTransferBoarding = P.CallTransferPickup

local function transferAllBoarded(transfer)
	for _, id in ipairs(transfer and transfer.prisonerIDs or {}) do
		local record = P.State.prisoners[id]
		if record and record.boarded ~= true then return false, record end
	end
	return true
end

function P.TryBoardTransfer(record, escort)
	if not record or not IsValid(record.entity) or not IsValid(escort) then return false end
	local transfer = P.State.transfers[tostring(record.transfer or "")]
	if not transfer or (transfer.status ~= "pickup_landed" and transfer.status ~= "boarding")
	or not IsValid(transfer.transport) then return false end
	local boarding = transferBoardingMarker()
	if not boarding then return false end
	local radius = math.max(100, tonumber(cfg.TransferPickupBoardingRadius) or 180)
	if record.entity:GetPos():DistToSqr(boarding.pos) > radius * radius
	or escort:GetPos():DistToSqr(boarding.pos) > radius * radius then return false end

	record.boarded = true
	record.status = "boarding"
	record.escortSteamID = ""
	record.escortAssistSteamID = ""
	record.targetPos = nil
	record.targetAng = nil
	record.entity:SetNoDraw(true)
	record.entity:SetSolid(SOLID_NONE)
	record.entity:SetPos(transfer.transport:GetPos())
	transfer.status = "boarding"
	transfer.boardingAt = transfer.boardingAt or unix()
	updateNetwork(record)
	P.AddIncident("transfer", playerName(escort) .. " escorted " .. record.name
		.. " aboard the LAAT for " .. transfer.destinationName .. ".", record, escort, 1)
	local allBoarded = transferAllBoarded(transfer)
	MilBase.Notify(escort, record.name .. " is secured aboard the transfer LAAT.", "ok")
	if allBoarded then
		notifyGuards("TRANSFER READY: all prisoners are aboard " .. transfer.id
			.. ". Authorise LAAT departure from Prison Operations.", "ok")
	end
	P.SaveState()
	return true
end

function P.AbortTransferPickup(transfer, reason)
	if not transfer then return false end
	local groupKey = P.CleanID(cfg.TransferHangarGroup, "main")
	for _, id in ipairs(transfer.prisonerIDs or {}) do
		local record = P.State.prisoners[id]
		if record then
			record.boarded = false
			record.status = "transfer_ready"
			record.escortSteamID = ""
			record.escortAssistSteamID = ""
			if IsValid(record.entity) then
				record.entity:SetNoDraw(false)
				record.entity:SetSolid(SOLID_BBOX)
				local staging = P.GetMarker("transfer") or transferBoardingMarker()
				if staging then record.entity:SetPos(staging.pos + Vector(0, 0, 4)) end
			end
			updateNetwork(record)
		end
	end
	pickupFailure(transfer, groupKey, reason or "Boarding timed out")
	return true
end

function P.OnTransferTransportRemoved(transport)
	local transferID = transport and transport.GetTransferID
		and transport:GetTransferID() or ""
	if transferID == "" then return end
	timer.Simple(0, function()
		local transfer = P.State and P.State.transfers
			and P.State.transfers[tostring(transferID)] or nil
		if transfer and (transfer.status == "pickup_inbound"
			or transfer.status == "pickup_landed" or transfer.status == "boarding"
			or transfer.status == "departing") then
			P.AbortTransferPickup(transfer, "Transfer LAAT was lost before custody handoff")
		end
	end)
end

function P.DispatchTransfer(ply, transferID)
	if not P.CanCommand(ply) then return false, "Command authorisation required" end
	local transfer = P.State.transfers[tostring(transferID or "")]
	if not transfer or (transfer.status ~= "boarding" and transfer.status ~= "pickup_landed") then
		return false, "The transfer LAAT is not ready for departure"
	end
	local ready, missing = transferAllBoarded(transfer)
	if not ready then return false, missing.name .. " has not been escorted aboard the LAAT" end
	if not IsValid(transfer.transport) then return false, "The transfer LAAT is no longer present" end
	local landing = transferLandingMarker()
	if not landing then return false, "No Transfer LAAT landing marker is configured" end
	local groupKey = P.CleanID(cfg.TransferHangarGroup, "main")
	local path = outboundTransferPath(groupKey, landing)
	local transport = transfer.transport
	transfer.status = "departing"
	transfer.departedAt = unix()
	P.AddIncident("transfer", playerName(ply) .. " authorised LAAT departure for "
		.. transfer.id .. ".", nil, ply, 1)
	P.SaveState()
	timer.Simple(math.max(0, tonumber(cfg.TransferPickupDepartureDelay) or 2), function()
		if not IsValid(transport) or transfer.status ~= "departing" then return end
		transport:BeginTransferDeparture(path, function()
			finishTransfer(transfer)
			if N and N.CloseHangar then
				N.CloseHangar(groupKey, "Prison-transfer LAAT departed")
			elseif N and N.ReleaseExternalHangarOperation then
				N.ReleaseExternalHangarOperation(groupKey)
			end
		end)
	end)
	return true, "LAAT departure authorised. Cells will be released after it clears the hangar."
end

local function prisonerSummary(record)
	return {
		id = record.id, name = record.name, role = record.role, faction = record.trueFaction,
		status = record.status, statusLabel = P.StatusLabel(record.status), risk = record.risk,
		riskLabel = P.RiskLabel(record.risk), cellID = record.cellID, charges = record.charges or {},
		evidence = record.evidence or {}, traits = record.traits or {}, needs = record.needs or {},
		morale = math.floor(record.morale or 0), compliance = math.floor(record.compliance or 0),
		health = math.floor(record.health or 0), escort = record.escortSteamID or "", transfer = record.transfer,
		contraband = record.contraband or {}, searched = record.searched == true,
		intakeComplete = record.intakeComplete == true, createdAt = record.createdAt,
		lastInterview = record.interviews and record.interviews[1] or nil,
	}
end

cellRuntime = function(id)
	P.State.cellState = P.State.cellState or {}
	local state = P.State.cellState[id]
	if not istable(state) then state = { cleanliness = 100, damage = 0, contraband = {} } P.State.cellState[id] = state end
	state.cleanliness = clamp(state.cleanliness or 100, 0, 100)
	state.damage = clamp(state.damage or 0, 0, 100)
	state.contraband = istable(state.contraband) and state.contraband or {}
	return state
end
P.CellRuntime = cellRuntime

local function cellSummary(id, cell)
	local occupants = cellOccupants(id)
	local runtime = cellRuntime(id)
	local names = {}; for _, record in ipairs(occupants) do names[#names + 1] = record.name end
	return { id = id, name = cell.name, capacity = cell.capacity, occupied = #occupants,
		occupants = names, security = cell.security, cleanliness = runtime.cleanliness,
		damage = runtime.damage, contraband = runtime.contraband, hasDoor = cell.markers.cell_door ~= nil,
		hasVolume = cell.markers.cell_corner_a ~= nil and cell.markers.cell_corner_b ~= nil }
end

function P.DatapadPayload(ply, selectedID, message)
	local prisoners, cells, transfers, destinations = {}, {}, {}, {}
	for _, record in ipairs(P.ActivePrisoners()) do prisoners[#prisoners + 1] = prisonerSummary(record) end
	for id, cell in pairs(P.Cells or {}) do cells[#cells + 1] = cellSummary(id, cell) end
	table.sort(cells, function(a,b) return a.id < b.id end)
	for id, transfer in pairs(P.State.transfers or {}) do
		if transfer.status ~= "completed" or unix() - (transfer.completedAt or 0) < 1800 then
			transfers[#transfers + 1] = table.Copy(transfer); transfers[#transfers].transport = nil
		end
	end
	for key, dest in pairs(cfg.AlliedPrisons or {}) do
		destinations[#destinations + 1] = { id = key, name = dest.name, planet = dest.planet,
			security = dest.security, capacity = dest.capacity, used = tonumber(P.State.destinationUsage[key]) or 0,
			acceptedRisk = dest.acceptedRisk or {} }
	end
	table.sort(destinations, function(a,b) return a.name < b.name end)
	local capacity = P.CapacitySnapshot()
	return {
		message = message, selectedID = selectedID or "", alert = P.State.alert,
		schedule = P.State.schedule, scheduleLabel = P.ScheduleLabels[P.State.schedule] or string.upper(P.State.schedule),
		scheduleEndsAt = P.State.scheduleEndsAt, manualSchedule = P.State.manualSchedule,
		capacity = capacity, facility = P.State.facility, prisoners = prisoners, cells = cells,
		incidents = tableCopy(P.State.incidents), transfers = transfers, destinations = destinations,
		canCommand = P.CanCommand(ply), canConfigure = P.CanConfigure(ply),
		carried = { meals = ply:GetNWInt("mb_prison_meals", 0), water = ply:GetNWInt("mb_prison_water", 0) },
	}
end

local function selectedRecord(data)
	return P.State.prisoners[tostring(data and (data.prisonerID or data.id) or "")]
end

local function interviewPrisoner(ply, record, topic)
	if not record or not IsValid(record.entity) then return false, "Prisoner unavailable" end
	if ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190) ^ 2 then return false, "Move closer to the prisoner" end
	topic = P.CleanID(topic, "case")
	local lowNeeds = needAverage(record) < 35
	local hostile = trait(record, "aggressive") or trait(record, "ideological")
	local cooperative = trait(record, "cooperative") or trait(record, "informant") or (record.compliance or 0) >= 70
	local responses = {
		case = cooperative and "I will answer what I can about the inspection case." or hostile and "You already decided what you think happened." or "I have given the Republic my account.",
		crew = trait(record, "loyal") and "I will not provide statements against my crew." or cooperative and "Some of the crew knew more than they admitted." or "Ask the others yourself.",
		cargo = record.trueFaction == "pirate" and "The cargo was not mine to question." or cooperative and "The captain controlled the manifest and sealed compartments." or "I only handled routine cargo.",
		contacts = trait(record, "informant") and "I can identify a contact if Republic protection is guaranteed." or hostile and "I have no names for you." or "I do not know who arranged the route.",
		cooperation = lowNeeds and "Deal with the conditions in here first, then we can talk." or cooperative and "Record that I am cooperating and I will continue." or "What does cooperation get me?",
		medical = (record.needs and (record.needs.medical or 100) < 60) and "I need a medic. This is not an act." or "I do not require treatment right now.",
		contraband = #((record.contraband) or {}) > 0 and "I have nothing to declare." or "Search me if you must; I have nothing prohibited.",
		takeover = trait(record, "takeover_planner")
			and "They are studying the ship's armory, engineering, communications and bridge."
			or "I have not heard a credible plan to seize the ship.",
	}
	local response = responses[topic] or "I have no statement on that subject."
	record.interviews = record.interviews or {}
	table.insert(record.interviews, 1, { time = unix(), topic = topic, questioner = playerName(ply), response = response })
	while #record.interviews > 20 do table.remove(record.interviews) end
	record.compliance = clamp((record.compliance or 50) + (cooperative and 1 or hostile and -1 or 0), 0, 100)
	P.AddIncident("interview", playerName(ply) .. " interviewed " .. record.name .. " about " .. topic .. ".", record, ply, 0)
	P.SaveState()
	return true, record.name .. ": " .. response
end

function P.HandleDatapadRequest(ply, action, data, sendData)
	if not P.CanUse(ply) then return end
	action, data = tostring(action or "get"), istable(data) and data or {}
	if not data.prisonerID or tostring(data.prisonerID) == "" then
		data.prisonerID = ply:GetNWString("mb_prisonSelected", "")
	end
	if data.prisonerID and tostring(data.prisonerID) ~= "" then ply:SetNWString("mb_prisonSelected", tostring(data.prisonerID)) end
	local message
	local record = selectedRecord(data)
	if action == "start_escort" and record then local ok; ok, message = P.StartEscort(ply, record); if not ok then message = message end
	elseif action == "process_intake" and record then local ok; ok, message = P.ProcessIntake(ply, record); if not ok then message = message end
	elseif action == "meal" and record then local ok; ok, message = carePrisoner(ply, record, "meal"); if not ok then message = message end
	elseif action == "water" and record then local ok; ok, message = carePrisoner(ply, record, "water"); if not ok then message = message end
	elseif action == "medical" and record then local ok; ok, message = carePrisoner(ply, record, "medical"); if not ok then message = message end
	elseif action == "interview" and record then local ok; ok, message = interviewPrisoner(ply, record, data.topic); if not ok then message = message end
	elseif action == "search" and record then
		if not IsValid(record.entity) or ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190)^2 then message = "Move closer to the prisoner"
		else
			record.searched = true
			local hadContraband = #record.contraband > 0
			local found = hadContraband and table.concat(record.contraband, ", ") or "nothing prohibited"
			record.contraband = {}; message = "Search recovered " .. found .. "."
			P.AddIncident("search", playerName(ply) .. " searched " .. record.name .. " and found " .. found .. ".", record, ply, hadContraband and 2 or 0); P.SaveState()
		end
	elseif action == "restrain" and record then
		if not IsValid(record.entity) or ply:GetPos():DistToSqr(record.entity:GetPos()) > (cfg.InteractionDistance or 190)^2 then message = "Move closer to the prisoner"
		else record.restrained = true; record.status = record.cellID ~= "" and "incarcerated" or "overflow"; record.compliance = clamp((record.compliance or 0)+15,0,100); updateNetwork(record); message = "Prisoner restrained and returned to custody."; P.AddIncident("restraint", playerName(ply).." restrained "..record.name..".",record,ply,2); P.SaveState() end
	elseif action == "release" and record and P.CanCommand(ply) then
		record.status = "released"; record.releasedAt = unix(); record.releaseOfficer = playerName(ply); removePrisonerEntity(record); message = record.name .. " released from custody."; P.AddIncident("release", message, record, ply, 2); P.SaveState()
	elseif action == "isolate" and record and P.CanCommand(ply) then
		local isolation = P.GetMarker("isolation")
		if not isolation then message = "No isolation marker configured" else record.status="isolation"; record.cellID=""; setTarget(record,isolation,"isolation"); message="Prisoner moved to isolation."; P.SaveState() end
	elseif action == "search_cell" and record then
		local cell = P.Cells[record.cellID or ""]
		local marker = cell and (cell.markers.cell_search or cell.markers.cell_origin)
		if not playerNearMarker(ply, marker, 260) then message = "Move to the selected prisoner's cell search point"
		else
			local runtime = cellRuntime(record.cellID)
			local found = #runtime.contraband > 0 and table.concat(runtime.contraband, ", ") or "no cell contraband"
			runtime.contraband = {}; message = "Cell search found " .. found .. "."
			P.AddIncident("cell_search", playerName(ply) .. " searched " .. record.cellID .. " and found " .. found .. ".", record, ply, found ~= "no cell contraband" and 2 or 0); P.SaveState()
		end
	elseif action == "clean_cell" and record then
		local cell = P.Cells[record.cellID or ""]
		local marker = cell and (cell.markers.cell_origin or cell.markers.cell_search)
		if not playerNearMarker(ply, marker, 260) then message = "Move to the selected prisoner's cell"
		else local runtime = cellRuntime(record.cellID); runtime.cleanliness = 100; message = "Cell cleaning completed."; P.AddIncident("maintenance", playerName(ply) .. " cleaned " .. record.cellID .. ".", record, ply, 0); P.SaveState() end
	elseif action == "repair_cell" and record then
		local cell = P.Cells[record.cellID or ""]
		local marker = cell and (cell.markers.cell_door or cell.markers.cell_origin)
		if not isEngineer(ply) then message = "Engineering certification is required"
		elseif not playerNearMarker(ply, marker, 280) then message = "Move to the damaged cell"
		else local runtime = cellRuntime(record.cellID); runtime.damage = math.max(0, runtime.damage - 45); message = "Cell structure and door controls repaired."; P.AddIncident("repair", playerName(ply) .. " repaired " .. record.cellID .. ".", record, ply, 1); P.SaveState() end
	elseif action == "collect_meals" then
		local store = P.GetMarker("food_store")
		if not playerNearMarker(ply, store, 240) then message = "Move to the marked prison food store"
		else
			local count = math.min(cfg.MaximumCarriedMeals or 12, ply:GetNWInt("mb_prison_meals", 0) + (cfg.MealsPerCollection or 6))
			local added = count - ply:GetNWInt("mb_prison_meals", 0)
			if added <= 0 then message = "You are already carrying the maximum number of meal trays"
			elseif not consumeNavalSupply(math.max(1, math.ceil(added * (cfg.FoodSupplyCost or 1))), "Prison meal trays collected", ply) then message = "Naval supplies are insufficient"
			else ply:SetNWInt("mb_prison_meals", count); message = "Collected " .. added .. " prison meal trays." end
		end
	elseif action == "collect_water" then
		local store = P.GetMarker("water_store")
		if not playerNearMarker(ply, store, 240) then message = "Move to the marked prison water store"
		else
			local count = math.min(cfg.MaximumCarriedWater or 20, ply:GetNWInt("mb_prison_water", 0) + (cfg.WaterUnitsPerCollection or 10))
			local added = count - ply:GetNWInt("mb_prison_water", 0)
			if added <= 0 then message = "You are already carrying the maximum water supply"
			else ply:SetNWInt("mb_prison_water", count); message = "Collected " .. added .. " prisoner water units." end
		end
	elseif action == "schedule" and P.CanCommand(ply) then
		P.ApplySchedule(data.schedule, ply, true, tonumber(data.duration) or 300); message = "Schedule changed."
	elseif action == "automatic_schedule" and P.CanCommand(ply) then
		P.State.manualSchedule = false; advanceSchedule(); message = "Automatic prison schedule resumed."
	elseif action == "request_transfer" and P.CanCommand(ply) then
		message = "Transfer requests must be transmitted from the ship communications console."
	elseif action == "begin_boarding" and P.CanCommand(ply) then
		local ok; ok, message = P.BeginTransferBoarding(ply, data.transferID)
	elseif action == "dispatch_transfer" and P.CanCommand(ply) then
		local ok; ok, message = P.DispatchTransfer(ply, data.transferID)
	elseif action == "lockdown" and P.CanCommand(ply) then P.ApplySchedule("riot_lockdown", ply, true, 600); message="Emergency lockdown ordered."
	elseif action == "negotiate" and P.CanCommand(ply) then
		for _, prisoner in ipairs(P.ActivePrisoners()) do if prisoner.status == "rioting" and math.Rand(0,1) < 0.55 then prisoner.status = prisoner.cellID ~= "" and "incarcerated" or "overflow"; prisoner.restrained=true; updateNetwork(prisoner) end end
		P.State.alert="restricted"; message="Negotiation reduced the disturbance."; P.AddIncident("riot","Guards negotiated with rioting prisoners.",nil,ply,2); P.SaveState()
	elseif action == "clean_facility" and P.CanCommand(ply) then P.State.facility.cleanliness=100; message="Facility cleaning completed."; P.SaveState()
	elseif action == "get" or action == "select" then
		-- No mutation.
	else message = message or "Unknown prison action." end
	if sendData then sendData(ply, "prison_ops", "state", P.DatapadPayload(ply, data.prisonerID or data.id, message)) end
end

function P.OpenDatapad(ply, prisonerID)
	if not P.CanUse(ply) then return end
	ply.mb_prisonSelected = tostring(prisonerID or "")
	ply:SetNWString("mb_prisonSelected", ply.mb_prisonSelected)
	if MilBase.DatapadOpen then MilBase.DatapadOpen(ply, "prison_ops") end
end

net.Receive(NET_LAYOUT_REQUEST, function(_, ply) P.BroadcastLayout(ply) end)

local function sendCommsData(ply, message)
	if not P.CanCommand(ply) then return end
	net.Start(NET_COMMS_DATA)
		net.WriteTable(P.DatapadPayload(ply, "", message))
	net.Send(ply)
end

net.Receive(NET_COMMS, function(_, ply)
	if not P.CanCommand(ply) then return end
	if not (G and G.CommsOperator == ply and G.CommsSessionValid and G.CommsSessionValid(ply, G.CommsTerminal)) then
		MilBase.Notify(ply, "Operate the ship communications console to contact an allied prison.", "warn") return
	end
	local action = net.ReadString()
	if action == "open" then sendCommsData(ply)
	elseif action == "request" then
		local data = net.ReadTable() or {}
		local ok, message = P.RequestTransfer(ply, data.destination, data.prisonerIDs or {})
		sendCommsData(ply, message)
	end
end)

hook.Add("PlayerDisconnected", "MilBase.Prison.ReleaseEscorts", function(ply)
	local id = ply:SteamID64()
	for _, record in pairs(P.State.prisoners or {}) do
		if record.escortSteamID == id then
			local transfer = P.State.transfers and P.State.transfers[tostring(record.transfer or "")]
			record.escortSteamID = ""
			record.status = transfer and (transfer.status == "pickup_landed"
				or transfer.status == "boarding") and "transfer_ready" or "awaiting_escort"
			updateNetwork(record)
		end
	end
	P.SaveState()
end)

hook.Add("PlayerInitialSpawn", "MilBase.Prison.LayoutToStaff", function(ply)
	timer.Simple(5, function() if IsValid(ply) then P.BroadcastLayout(ply) end end)
end)

local function loadLayout(done)
	MilBase.DB.Query("SELECT * FROM " .. LAYOUT_TABLE .. " WHERE map_key=" .. MilBase.SQLStr(mapKey) .. " ORDER BY id ASC", function(rows)
		P.Layout = {}
		for _, row in ipairs(rows or {}) do
			local id = tonumber(row.id)
			if id then
				P.Layout[id] = { id=id, kind=clean(row.kind_name,48), group=clean(row.group_id,48), name=clean(row.label,80),
					pos=recordVec(util.JSONToTable(row.pos_json or "") or {}), ang=recordAng(util.JSONToTable(row.ang_json or "") or {}),
					data=util.JSONToTable(row.data_json or "") or {}, mapID=tonumber(row.map_entity_id) or -1,
					class=clean(row.entity_class,80), model=clean(row.entity_model,260) }
			end
		end
		P._layoutLoaded=true; P.RebuildLayout(); P.BroadcastLayout(); if done then done() end
	end)
end

local function loadState()
	MilBase.DB.Query("SELECT state_json FROM " .. STATE_TABLE .. " WHERE map_key=" .. MilBase.SQLStr(mapKey) .. " LIMIT 1", function(rows)
		local state = rows and rows[1] and util.JSONToTable(rows[1].state_json or "") or nil
		P.State = normaliseState(state)
		P._loaded = true
		for _, record in pairs(P.State.prisoners) do
			record.needs = istable(record.needs) and record.needs or tableCopy(cfg.InitialNeeds)
			record.traits = istable(record.traits) and record.traits or {}
			record.bodygroups = istable(record.bodygroups) and record.bodygroups or {}
			record.charges = istable(record.charges) and record.charges or {}
			record.evidence = istable(record.evidence) and record.evidence or {}
			record.contraband = istable(record.contraband) and record.contraband or {}
			record.interviews = istable(record.interviews) and record.interviews or {}
			P.SpawnPrisonerEntity(record)
		end
		if unix() >= (P.State.scheduleEndsAt or 0) and not P.State.manualSchedule then advanceSchedule() end
		P.SaveState(true)
	end)
end

local function initialiseDatabase()
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. STATE_TABLE .. " (map_key VARCHAR(64) PRIMARY KEY, state_json LONGTEXT, updated_at INTEGER)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. LAYOUT_TABLE .. " (id " .. MilBase.DB.AutoIncPK()
		.. ", map_key VARCHAR(64), kind_name VARCHAR(48), group_id VARCHAR(48), label TEXT, pos_json TEXT, ang_json TEXT, data_json LONGTEXT, map_entity_id INTEGER, entity_class VARCHAR(80), entity_model TEXT)")
	timer.Simple(0.25, function() loadLayout(loadState) end)
end

hook.Add("InitPostEntity", "MilBase.Prison.Load", function()
	timer.Simple(1, initialiseDatabase)
end)
hook.Add("PostCleanupMap", "MilBase.Prison.Respawn", function()
	timer.Simple(1, function()
		loadLayout(function()
			for _, record in pairs(P.State.prisoners or {}) do P.SpawnPrisonerEntity(record) end
		end)
	end)
end)

MilBase.RegisterChatCommand("prisonstatus", {
	help = "Show shipboard prison status.",
	func = function(ply)
		if not P.CanUse(ply) then return end
		local c = P.CapacitySnapshot()
		MilBase.Notify(ply, string.format("Prison: %d active / %d proper beds, %s overcrowding, schedule %s.", c.active, c.capacity, string.upper(c.level), P.State.schedule), c.level == "normal" and "ok" or "warn")
	end,
})
MilBase.RegisterChatCommand("prisonreload", {
	help = "(Staff) Reload the persistent prison layout.",
	func = function(ply) if not P.CanConfigure(ply) then return end loadLayout(function() MilBase.Notify(ply,"Prison layout reloaded.","ok") end) end,
})
MilBase.RegisterChatCommand("prisondebug", {
	help = "(Staff) Show prison layout and persistence diagnostics.",
	func = function(ply)
		if not P.CanConfigure(ply) then return end
		local markerCount = 0; for _ in pairs(P.Layout or {}) do markerCount = markerCount + 1 end
		local c = P.CapacitySnapshot()
		MilBase.Notify(ply, string.format("Prison debug: loaded=%s, layout=%s, markers=%d, cells=%d, active=%d, beds=%d.", tostring(P._loaded), tostring(P._layoutLoaded), markerCount, table.Count(P.Cells or {}), c.active, c.capacity), "info")
	end,
})
MilBase.RegisterChatCommand("prisonclear", {
	help = "(Staff) /prisonclear test removes generated test prisoners.",
	func = function(ply, args)
		if not P.CanConfigure(ply) or P.CleanID(args[1], "") ~= "test" then return end
		local removed = 0
		for id, record in pairs(P.State.prisoners or {}) do
			if record.testCase == true or string.StartWith(tostring(id), "TEST-") then removePrisonerEntity(record); P.State.prisoners[id] = nil; removed = removed + 1 end
		end
		P.SaveState(true); MilBase.Notify(ply, "Removed " .. removed .. " test prisoner record(s).", "ok")
	end,
})

MilBase.RegisterChatCommand("prisonlockdown", {
	help = "Order an emergency prison lockdown.",
	func = function(ply) if P.CanCommand(ply) then P.ApplySchedule("riot_lockdown",ply,true,600) end end,
})
MilBase.RegisterChatCommand("prisontest", {
	help = "(Staff) /prisontest cooperative|aggressive|fill|riot|takeover|needs",
	func = function(ply,args)
		if not P.CanConfigure(ply) then return end
		local mode=P.CleanID(args[1],"cooperative")
		if mode=="riot" then for _,r in ipairs(P.ActivePrisoners()) do P.StartRiot(r,"staff test") end notifyGuards("Staff prison riot test started.","warn") return end
		if mode=="takeover" then
			for _,r in ipairs(P.ActivePrisoners()) do P.StartRiot(r,"staff takeover test") end
			if P.StartShipTakeover then
				local ok,message=P.StartShipTakeover("staff test",true)
				MilBase.Notify(ply,message,ok and "warn" or "error")
			end
			return
		end
		if mode=="needs" then for _,r in ipairs(P.ActivePrisoners()) do for k in pairs(r.needs or {}) do r.needs[k]=5 end end P.SaveState(); return end
		local count=mode=="fill" and math.max(1,P.CapacitySnapshot().capacity+2) or 1
		for index=1,count do
			P.State.nextPrisoner=(P.State.nextPrisoner or 0)+1
			local id=string.format("TEST-PR-%04d",P.State.nextPrisoner)
			local risk=mode=="aggressive" and "high" or "low"
			local r={id=id,name="Test Prisoner "..P.State.nextPrisoner,role="TEST DETAINEE",trueFaction="civilian",model="models/Humans/Group03/male_07.mdl",skin=0,bodygroups={},charges={"Staff test custody"},evidence={"Generated test record"},createdAt=unix(),status="awaiting_escort",risk=risk,traits=mode=="aggressive" and {"aggressive","takeover_planner"} or {"cooperative"},needs=tableCopy(cfg.InitialNeeds),morale=60,compliance=risk=="high" and 25 or 90,health=100,restrained=true,cellID="",escortSteamID="",incidents={},contraband={},intakeComplete=false,searched=false,interviews={},testCase=true}
			P.State.prisoners[id]=r; P.SpawnPrisonerEntity(r,(P.GetMarker("entrance") and P.GetMarker("entrance").pos+Vector(index*24,0,0)) or ply:GetPos()+ply:GetForward()*80,ply:EyeAngles())
		end
		P.SaveState(); MilBase.Notify(ply,"Prison test detainee(s) spawned.","ok")
	end,
})
