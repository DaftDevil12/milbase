-- Shared Event Character (EC) Persona System
MilBase.EventCharacter = MilBase.EventCharacter or {}
local EC = MilBase.EventCharacter

EC.Languages = EC.Languages or {
	{ id = "basic", name = "Galactic Basic", untranslated = "speech" },
	{ id = "shyriiwook", name = "Shyriiwook (Wookiee)", untranslated = "Grrrwaaaahff rrrgghh warrrgh!" },
	{ id = "huttese", name = "Huttese", untranslated = "Chuba ku nolla pawa!" },
	{ id = "binary", name = "Droid Binary", untranslated = "01000010 01101001 01101110" },
	{ id = "rodian", name = "Rodian", untranslated = "Heebie jeebie squawk!" },
	{ id = "dosh", name = "Trandoshan (Dosh)", untranslated = "Sssskrahhh sszh!" },
	{ id = "aurebesh", name = "Aurebesh Cipher", untranslated = "[Encrypted Comms Cipher]" },
}

local PLAYER = FindMetaTable("Player")

function PLAYER:MBIsEventCharacter()
	return self:GetNWBool("mb_ec_active", false)
end

function PLAYER:MBEventLanguage()
	return self:GetNWString("mb_ec_language", "")
end

function PLAYER:MBUseUnlimitedWeapons()
	return self:GetNWBool("mb_ec_unlimited_weapons", false)
end

-- Network string initialization
if SERVER then
	util.AddNetworkString("MilBase_EC_OpenMenu")
	util.AddNetworkString("MilBase_EC_ApplyProfile")
	util.AddNetworkString("MilBase_EC_RevertProfile")
end
