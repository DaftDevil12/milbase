--[[
	NPC dropship support.

	Event staff can call in a cinematic gunship from the toolgun. The ship
	flies to a hover point, drops a squad of NPCs through the existing event
	spawn backend, turns around, then departs and removes itself.
]]

MilBase.Dropship = MilBase.Dropship or {}

local cfg = MilBase.Config

cfg.DropshipWorkshopContent = cfg.DropshipWorkshopContent or {
	"2912816023", -- [LVS] - Framework
	"2919757295", -- [LVS] - Star Wars - Pack
	"2934104449", -- [LVS] HMP Droid Gunship
}

MilBase.Dropship.DefaultModel = "models/blu/laat.mdl"
MilBase.Dropship.FallbackModel = "models/combine_helicopter.mdl"

local function canCallDropship(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) then return true end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	return MilBase.CanRunEvents and MilBase.CanRunEvents(ply)
end

local function cleanString(value, fallback)
	value = string.Trim(tostring(value or ""))
	return value ~= "" and value or fallback
end

local function cleanTeam(value)
	value = string.lower(cleanString(value, "enemy"))
	return MilBase.NPCTeams and MilBase.NPCTeams[value] and value or "enemy"
end

local function cleanStance(value)
	value = string.lower(cleanString(value, "attack"))
	if value == "none" or value == "default" then return "" end
	if value == "hold" or value == "defend" or value == "patrol"
	or value == "careless" or value == "attack" or value == "aggressive" then
		return value
	end
	return "attack"
end

local modelFields = {
	"Model",
	"model",
	"MDL",
	"mdl",
	"VehicleModel",
	"vehicleModel",
	"WorldModel",
	"worldModel",
}

local aatClassCandidates = {
	"lvs_aat",
	"lvs_sw_aat",
	"lvs_ground_aat",
	"lvs_cis_aat",
	"lvs_aat_tank",
	"lvs_tank_aat",
	"lvs_wheeldrive_aat",
}

local function hasAATToken(text)
	text = string.lower(tostring(text or ""))
	if string.find(text, "armored assault tank", 1, true) then return true end

	local padded = " " .. string.gsub(text, "[^%w]+", " ") .. " "
	return string.find(padded, " aat ", 1, true) ~= nil
end

function MilBase.ResolveDropshipModel(requested)
	requested = cleanString(requested, "auto")

	if requested ~= "auto" and util.IsValidModel(requested) then
		return requested
	end

	for class, stored in pairs(scripted_ents.GetList()) do
		local t = stored.t or {}
		local haystack = string.lower(class .. " " .. tostring(t.PrintName or "")
			.. " " .. tostring(t.Category or ""))

		if string.find(haystack, "hmp", 1, true)
		and (string.find(haystack, "gunship", 1, true)
		or string.find(haystack, "droid", 1, true)) then
			for _, key in ipairs(modelFields) do
				local model = t[key]
				if isstring(model) and util.IsValidModel(model) then
					return model
				end
			end
		end
	end

	if util.IsValidModel(MilBase.Dropship.DefaultModel) then
		return MilBase.Dropship.DefaultModel
	end

	return MilBase.Dropship.FallbackModel
end

function MilBase.ResolveAATClass(requested)
	requested = cleanString(requested, "auto")

	if requested ~= "auto" and scripted_ents.GetStored(requested) then
		return requested
	end

	for _, class in ipairs(aatClassCandidates) do
		if scripted_ents.GetStored(class) then return class end
	end

	for class, stored in pairs(scripted_ents.GetList()) do
		local t = stored.t or {}
		local haystack = string.lower(class .. " " .. tostring(t.PrintName or "")
			.. " " .. tostring(t.Category or ""))

		if hasAATToken(haystack) then
			return class
		end
	end
end

function MilBase.ResolveVehicleDropModel(class, requested)
	requested = cleanString(requested, "auto")

	if requested ~= "auto" and util.IsValidModel(requested) then
		return requested
	end

	local stored = isstring(class) and scripted_ents.GetStored(class)
	local t = stored and stored.t or nil

	if t then
		for _, key in ipairs(modelFields) do
			local model = t[key]
			if isstring(model) and util.IsValidModel(model) then
				return model
			end
		end
	end

	return ""
end

if CLIENT then return end

for _, id in ipairs(cfg.DropshipWorkshopContent or {}) do
	resource.AddWorkshop(id)
end

local function notify(ply, text, kind)
	if IsValid(ply) and ply:IsPlayer() and MilBase.Notify then
		MilBase.Notify(ply, text, kind)
	end
end

local function groundPos(pos, filter)
	local tr = util.TraceLine({
		start = pos + Vector(0, 0, 128),
		endpos = pos - Vector(0, 0, 900),
		filter = filter,
		mask = MASK_SOLID_BRUSHONLY,
	})

	return tr.Hit and tr.HitPos or pos
end

local function dropSpawnPoint(center, index, count, radius, ship)
	if count <= 1 then return groundPos(center, ship) end

	local angle = (index - 1) / count * math.pi * 2
	local ring = radius + math.floor((index - 1) / 8) * math.max(radius * 0.55, 32)
	local pos = center + Vector(math.cos(angle) * ring, math.sin(angle) * ring, 0)
	return groundPos(pos, ship)
end

local function fallbackSpawnNPC(owner, class, weapon, pos, yaw, model)
	local npc = ents.Create(class)
	if not IsValid(npc) then return end

	npc:SetPos(pos + Vector(0, 0, 8))
	npc:SetAngles(Angle(0, yaw, 0))
	if IsValid(owner) then npc:SetCreator(owner) end
	if weapon ~= "" then npc:SetKeyValue("additionalequipment", weapon) end
	npc:Spawn()
	npc:Activate()

	if model and model ~= "" and util.IsValidModel(model) then
		npc:SetModel(model)
	end

	npc:AddRelationship("player D_HT 99")
	npc:SetNPCState(NPC_STATE_ALERT)
	npc.mb_eventSpawned = true
	npc.mb_eventOwner = owner
	npc:SetNWBool("mb_event", true)
	table.insert(MilBase.EventEntities, npc)

	return npc
end

function MilBase.SpawnDropshipNPCs(ship)
	if not IsValid(ship) then return 0 end

	local owner = ship:GetCreator()
	local count = math.Clamp(ship:GetNPCCount(), 1, 24)
	local rawClass = cleanString(ship:GetNPCClass(), "npc_combine_s")
	local weapon = cleanString(ship:GetNPCWeapon(), "")
	local model = cleanString(ship:GetNPCModel(), "")
	local vehicleModel = ship:GetVehicleModel()

	if model == "auto" or model == vehicleModel or (model ~= "" and not util.IsValidModel(model)) then
		model = ""
	end

	local class = rawClass
	local npcList = list.Get("NPC")
	if npcList and npcList[rawClass] then
		local npcData = npcList[rawClass]
		if npcData.Class then class = npcData.Class end
		if model == "" and npcData.Model and util.IsValidModel(npcData.Model) then
			model = npcData.Model
		end
		if weapon == "" and npcData.Weapons and istable(npcData.Weapons) and npcData.Weapons[1] then
			weapon = npcData.Weapons[1]
		end
	end

	local team = cleanTeam(ship:GetNPCTeam())
	local stance = cleanStance(ship:GetNPCStance())
	local healthMult = math.Clamp(ship:GetNPCHealthMult(), 0.25, 5)
	local radius = math.Clamp(ship:GetDropRadius(), 0, 420)
	local drop = ship:GetDropPos()
	local yaw = ship:GetDepartAngle().y
	local spawned = 0

	local def = {
		name = class,
		category = "Dropship",
		kind = "npc",
		class = class,
		weapon = weapon ~= "" and weapon or nil,
		model = (model ~= "" and model ~= vehicleModel) and model or nil,
	}
	local opts = {
		team = team,
		hp = healthMult,
		stance = stance ~= "" and stance or nil,
	}

	for i = 1, count do
		local pos = dropSpawnPoint(drop, i, count, radius, ship)
		local npc

		if MilBase.DoEventSpawn then
			npc = MilBase.DoEventSpawn(owner, def, pos, yaw, opts)
		else
			npc = fallbackSpawnNPC(owner, class, weapon, pos, yaw, def.model)
		end

		if IsValid(npc) then
			spawned = spawned + 1

			if npc:IsNPC() then
				local away = (pos - drop)
				away.z = 0
				if away:LengthSqr() < 4 then away = Angle(0, yaw, 0):Forward() end
				npc:SetLastPosition(pos + away:GetNormalized() * 220)
				npc:SetSchedule(SCHED_FORCED_GO_RUN)
			end
		end
	end

	return spawned
end

local function tagFallbackEventEntity(ent, ply, team)
	MilBase.EventEntities = MilBase.EventEntities or {}
	ent.mb_eventSpawned = true
	ent.mb_eventOwner = ply
	ent.mb_npcteam = team
	ent:SetNWBool("mb_event", true)
	ent:SetNWString("mb_team", team)
	table.insert(MilBase.EventEntities, ent)
end

function MilBase.SpawnDropshipVehicle(ship)
	if not IsValid(ship) then return end

	local owner = ship:GetCreator()
	local class = MilBase.ResolveAATClass(ship:GetVehicleClass())

	if not class then
		notify(owner, "No AAT vehicle class was found. Set the AAT class in the tool.", "danger")
		return
	end

	local team = cleanTeam(ship:GetVehicleTeam())
	local drop = groundPos(ship:GetDropPos(), ship)
	local yaw = ship:GetDepartAngle().y
	local ent

	local def = {
		name = class,
		category = "Dropship",
		kind = "lvs",
		class = class,
	}

	if MilBase.DoEventSpawn then
		ent = MilBase.DoEventSpawn(owner, def, drop, yaw, { team = team })
	else
		ent = ents.Create(class)
		if IsValid(ent) then
			ent:SetPos(drop + Vector(0, 0, 16))
			ent:SetAngles(Angle(0, yaw, 0))
			if IsValid(owner) then ent:SetCreator(owner) end
			ent:Spawn()
			ent:Activate()
			tagFallbackEventEntity(ent, owner, team)
		end
	end

	if not IsValid(ent) then return end

	if ent.SetAITEAM then
		ent:SetAITEAM(team == "friendly" and FRIENDLY_TEAM or ENEMY_TEAM)
	end
	if ent.SetAI then ent:SetAI(true) end

	notify(owner, "AAT deployed with AI enabled.", "ok")
	return ent
end

function MilBase.StartDropshipDrop(ply, dropPos, opts)
	if not canCallDropship(ply) then
		notify(ply, "You don't have permission to call a dropship.", "danger")
		return false
	end

	if not isvector(dropPos) or not util.IsInWorld(dropPos) then
		notify(ply, "Pick a valid drop zone.", "warn")
		return false
	end

	if IsValid(ply) and (ply.mb_nextDropship or 0) > CurTime() then
		notify(ply, "Dropship call-in is cooling down.", "warn")
		return false
	end

	opts = opts or {}

	local hoverHeight = math.Clamp(tonumber(opts.hoverHeight) or 155, 32, 600)
	local approachDistance = math.Clamp(tonumber(opts.approachDistance) or 2400, 400, 9000)
	local approachHeight = math.Clamp(tonumber(opts.approachHeight) or 900, 100, 5000)
	local approachTime = math.Clamp(tonumber(opts.approachTime) or 7, 1, 45)
	local holdTime = math.Clamp(tonumber(opts.holdTime) or 5, 1, 30)
	local departureTime = math.Clamp(tonumber(opts.departureTime) or 6, 1, 45)
	local dropDelay = math.Clamp(tonumber(opts.dropDelay) or math.min(1.2, holdTime * 0.35), 0, holdTime)

	local landPos = dropPos + Vector(0, 0, hoverHeight)
	local startPos = opts.startPos
	local forward

	if isvector(startPos) and util.IsInWorld(startPos) then
		local delta = landPos - startPos
		delta.z = 0
		forward = delta:LengthSqr() > 1 and delta:GetNormalized() or Angle(0, tonumber(opts.yaw) or 0, 0):Forward()
	else
		forward = Angle(0, tonumber(opts.yaw) or (IsValid(ply) and ply:EyeAngles().y or 0), 0):Forward()
		forward.z = 0
		forward:Normalize()
		startPos = landPos - forward * approachDistance + Vector(0, 0, approachHeight)
	end

	local departDistance = math.Clamp(tonumber(opts.departDistance) or approachDistance, 400, 9000)
	local departHeight = math.Clamp(tonumber(opts.departHeight) or approachHeight, 100, 5000)
	local departPos = opts.turnAround == false
		and (landPos + forward * departDistance + Vector(0, 0, departHeight))
		or (landPos - forward * departDistance + Vector(0, 0, departHeight))

	local approachAng = (landPos - startPos):Angle()
	approachAng.p = 0
	approachAng.r = 0

	local departAng = (departPos - landPos):Angle()
	departAng.p = 0
	departAng.r = 0

	local ship = ents.Create("mb_npc_dropship")
	if not IsValid(ship) then
		notify(ply, "Failed to create dropship entity.", "danger")
		return false
	end

	ship:SetVehicleModel(MilBase.ResolveDropshipModel(opts.model))
	ship:SetRouteStart(startPos)
	ship:SetRouteLand(landPos)
	ship:SetRouteDepart(departPos)
	ship:SetDropPos(dropPos)
	ship:SetRouteStartAngle(approachAng)
	ship:SetRouteLandAngle(approachAng)
	ship:SetDepartAngle(departAng)
	ship:SetSequenceStarted(CurTime())
	ship:SetApproachDuration(approachTime)
	ship:SetHoldDuration(holdTime)
	ship:SetDepartureDuration(departureTime)
	ship:SetDropDelay(dropDelay)
	ship:SetNPCClass(cleanString(opts.npcClass, "npc_combine_s"))
	ship:SetNPCModel(cleanString(opts.npcModel, ""))
	ship:SetNPCWeapon(cleanString(opts.npcWeapon, ""))
	ship:SetNPCCount(math.Clamp(math.floor(tonumber(opts.npcCount) or 6), 1, 24))
	ship:SetNPCTeam(cleanTeam(opts.team))
	ship:SetNPCStance(cleanStance(opts.stance))
	ship:SetNPCHealthMult(math.Clamp(tonumber(opts.healthMult) or 1, 0.25, 5))
	ship:SetDropRadius(math.Clamp(tonumber(opts.dropRadius) or 120, 0, 420))
	ship.mb_dropCallback = isfunction(opts.onDrop) and opts.onDrop or nil
	ship.mb_dropCancelledCallback = isfunction(opts.onCancel) and opts.onCancel or nil

	if IsValid(ply) then
		ship:SetCreator(ply)
	end

	ship:Spawn()
	ship:Activate()

	if IsValid(ply) then
		ply.mb_nextDropship = CurTime() + 1
	end

	notify(ply, "Dropship inbound.", "ok")
	return true, ship
end

local function routeForDrop(ply, dropPos, opts)
	local hoverHeight = math.Clamp(tonumber(opts.hoverHeight) or 185, 48, 800)
	local approachDistance = math.Clamp(tonumber(opts.approachDistance) or 2600, 400, 9000)
	local approachHeight = math.Clamp(tonumber(opts.approachHeight) or 950, 100, 5000)
	local landPos = dropPos + Vector(0, 0, hoverHeight)
	local startPos = opts.startPos
	local forward

	if isvector(startPos) and util.IsInWorld(startPos) then
		local delta = landPos - startPos
		delta.z = 0
		forward = delta:LengthSqr() > 1 and delta:GetNormalized() or Angle(0, tonumber(opts.yaw) or 0, 0):Forward()
	else
		forward = Angle(0, tonumber(opts.yaw) or (IsValid(ply) and ply:EyeAngles().y or 0), 0):Forward()
		forward.z = 0
		forward:Normalize()
		startPos = landPos - forward * approachDistance + Vector(0, 0, approachHeight)
	end

	local departDistance = math.Clamp(tonumber(opts.departDistance) or approachDistance, 400, 9000)
	local departHeight = math.Clamp(tonumber(opts.departHeight) or approachHeight, 100, 5000)
	local departPos = opts.turnAround == false
		and (landPos + forward * departDistance + Vector(0, 0, departHeight))
		or (landPos - forward * departDistance + Vector(0, 0, departHeight))

	local approachAng = (landPos - startPos):Angle()
	approachAng.p = 0
	approachAng.r = 0

	local departAng = (departPos - landPos):Angle()
	departAng.p = 0
	departAng.r = 0

	return startPos, landPos, departPos, approachAng, departAng
end

function MilBase.StartVehicleDropshipDrop(ply, dropPos, opts)
	if not canCallDropship(ply) then
		notify(ply, "You don't have permission to call a vehicle dropship.", "danger")
		return false
	end

	if not isvector(dropPos) or not util.IsInWorld(dropPos) then
		notify(ply, "Pick a valid vehicle drop zone.", "warn")
		return false
	end

	if IsValid(ply) and (ply.mb_nextDropship or 0) > CurTime() then
		notify(ply, "Dropship call-in is cooling down.", "warn")
		return false
	end

	opts = opts or {}

	local vehicleClass = MilBase.ResolveAATClass(opts.vehicleClass)
	if not vehicleClass then
		notify(ply, "No AAT vehicle class was found. Set the AAT class in the tool.", "danger")
		return false
	end

	local carrierModel = MilBase.ResolveDropshipModel(opts.carrierModel or opts.model)
	local carriedModel = MilBase.ResolveVehicleDropModel(vehicleClass, opts.vehicleModel)
	if carriedModel == "" then
		notify(ply, "The AAT model could not be detected. Set the carried model path in the tool.", "danger")
		return false
	end

	local startPos, landPos, departPos, approachAng, departAng = routeForDrop(ply, dropPos, opts)
	local holdTime = math.Clamp(tonumber(opts.holdTime) or 5, 1, 30)
	local ship = ents.Create("mb_vehicle_dropship")

	if not IsValid(ship) then
		notify(ply, "Failed to create vehicle dropship entity.", "danger")
		return false
	end

	ship:SetCarrierModel(carrierModel)
	ship:SetVehicleClass(vehicleClass)
	ship:SetCarriedModel(carriedModel)
	ship:SetVehicleTeam(cleanTeam(opts.team))
	ship:SetRouteStart(startPos)
	ship:SetRouteLand(landPos)
	ship:SetRouteDepart(departPos)
	ship:SetDropPos(dropPos)
	ship:SetRouteStartAngle(approachAng)
	ship:SetRouteLandAngle(approachAng)
	ship:SetDepartAngle(departAng)
	ship:SetSequenceStarted(CurTime())
	ship:SetApproachDuration(math.Clamp(tonumber(opts.approachTime) or 7, 1, 45))
	ship:SetHoldDuration(holdTime)
	ship:SetDepartureDuration(math.Clamp(tonumber(opts.departureTime) or 6, 1, 45))
	ship:SetDropDelay(math.Clamp(tonumber(opts.dropDelay) or math.min(1.1, holdTime * 0.35), 0, holdTime))
	ship:SetCarryOffset(Vector(
		math.Clamp(tonumber(opts.carryForward) or 0, -320, 320),
		math.Clamp(tonumber(opts.carryRight) or 0, -320, 320),
		math.Clamp(tonumber(opts.carryUp) or -95, -360, 64)
	))

	if IsValid(ply) then
		ship:SetCreator(ply)
		ply.mb_nextDropship = CurTime() + 1
	end

	ship:Spawn()
	ship:Activate()

	notify(ply, "AAT dropship inbound.", "ok")
	return true, ship
end

concommand.Add("mb_dropship_clear_start", function(ply)
	if not canCallDropship(ply) then return end
	ply.mb_dropship_start = nil
	notify(ply, "Dropship approach point cleared.", "warn")
end)

concommand.Add("mb_aat_dropship_clear_start", function(ply)
	if not canCallDropship(ply) then return end
	ply.mb_aat_dropship_start = nil
	notify(ply, "AAT approach point cleared.", "warn")
end)