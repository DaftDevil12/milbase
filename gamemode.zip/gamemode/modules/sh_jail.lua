--[[
	Jail / Arrest / Criminal Records system.

	Core loop:
	  * Staff place prison cells, arrest terminals, and records terminals with
	    Tools -> Star Wars RP -> Jail System.
	  * CG / police factions use an Arrest Terminal while a target is cuffed and
	    close to the terminal.
	  * The selected crimes define the charge text, jail time, and fine.
	  * Active jail state is persisted, so disconnecting does not clear a sentence.
	  * Criminal records are searchable from a records terminal or records datapad.
	  * Only Owner-level staff can see/edit the crime definitions tab.
]]

local cfg = MilBase.Config
MilBase.Jail = MilBase.Jail or {}
MilBase.Jail.Crimes = MilBase.Jail.Crimes or {}
MilBase.Jail.CrimeOrder = MilBase.Jail.CrimeOrder or {}
MilBase.Jail.Cells = MilBase.Jail.Cells or {}
MilBase.Jail.Terminals = MilBase.Jail.Terminals or {}

local NET_ARREST_OPEN = "MilBase_Jail_ArrestOpen"
local NET_ARREST_SUBMIT = "MilBase_Jail_ArrestSubmit"
local NET_RECORDS_OPEN = "MilBase_Jail_RecordsOpen"
local NET_RECORDS_SEARCH = "MilBase_Jail_RecordsSearch"
local NET_RECORDS_DATA = "MilBase_Jail_RecordsData"
local NET_CRIMES_ADMIN = "MilBase_Jail_CrimesAdmin"
local NET_CRIMES_DATA = "MilBase_Jail_CrimesData"

local function trim(s)
	return string.Trim(tostring(s or ""))
end

local function clampInt(value, min, max)
	value = math.floor(tonumber(value or 0) or 0)
	if min then value = math.max(min, value) end
	if max then value = math.min(max, value) end
	return value
end

local function now()
	return os.time()
end

local function defaultText(value, fallback)
	value = trim(value)
	return value ~= "" and value or fallback
end

local function isPoliceFaction(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
	local faction = ply:MBFaction()
	if faction and faction.police then return true end

	local allowed = cfg.JailPoliceFactions or {}
	return allowed[ply:MBFactionID()] == true
		or (faction and allowed[faction.name] == true)
end

function MilBase.JailCanArrest(ply)
	if cfg.JailEnabled == false then return false end
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if ply:GetNWBool("mb_cuffed", false) then return false end
	return isPoliceFaction(ply)
end

function MilBase.JailCanViewRecords(ply)
	if cfg.JailEnabled == false then return false end
	return isPoliceFaction(ply) or (IsValid(ply) and ply:MBStaffLevel() >= (cfg.JailSetupStaffLevel or 4))
end

function MilBase.JailCanConfigure(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	if ply:IsSuperAdmin() and ply:MBStaffLevel() <= 0 then return true end
	return ply:MBStaffLevel() >= (cfg.JailSetupStaffLevel or 4)
end

function MilBase.JailCanManageCrimes(ply)
	if game.SinglePlayer() then return true end
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	return ply:MBStaffLevel() >= (cfg.JailCrimeOwnerLevel or 7)
end

function MilBase.JailIsJailed(ply)
	return IsValid(ply) and ply:GetNWBool("mb_jailed", false) == true
end

local function serializeVec(v)
	return MilBase.SQLStr(util.TypeToString(isvector(v) and v or vector_origin))
end

local function serializeAng(a)
	return MilBase.SQLStr(util.TypeToString(isangle(a) and a or angle_zero))
end

local function rowVec(rowValue)
	local v = util.StringToType(rowValue or "", "Vector")
	return isvector(v) and v or vector_origin
end

local function rowAng(rowValue)
	local a = util.StringToType(rowValue or "", "Angle")
	return isangle(a) and a or angle_zero
end

local function crimeListForClient()
	local out = {}
	for _, id in ipairs(MilBase.Jail.CrimeOrder or {}) do
		local c = MilBase.Jail.Crimes[id]
		if c and tonumber(c.active or 1) == 1 then
			out[#out + 1] = {
				id = c.id,
				code = c.code,
				name = c.name,
				charge = c.charge,
				time = c.time,
				fine = c.fine,
				active = c.active,
			}
		end
	end
	return out
end

local function allCrimesForAdmin()
	local out = {}
	for _, id in ipairs(MilBase.Jail.CrimeOrder or {}) do
		local c = MilBase.Jail.Crimes[id]
		if c then
			out[#out + 1] = {
				id = c.id,
				code = c.code,
				name = c.name,
				charge = c.charge,
				time = c.time,
				fine = c.fine,
				active = c.active,
			}
		end
	end
	return out
end

if SERVER then
	util.AddNetworkString(NET_ARREST_OPEN)
	util.AddNetworkString(NET_ARREST_SUBMIT)
	util.AddNetworkString(NET_RECORDS_OPEN)
	util.AddNetworkString(NET_RECORDS_SEARCH)
	util.AddNetworkString(NET_RECORDS_DATA)
	util.AddNetworkString(NET_CRIMES_ADMIN)
	util.AddNetworkString(NET_CRIMES_DATA)

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_jail_crimes ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "code VARCHAR(32), name TEXT, charge TEXT, jail_time INTEGER, fine INTEGER, active INTEGER )")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_jail_cells ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "map VARCHAR(64), name TEXT, pos TEXT, ang TEXT )")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_jail_terminals ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "map VARCHAR(64), kind VARCHAR(24), name TEXT, pos TEXT, ang TEXT )")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_jail_records ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "steamid VARCHAR(32), rp_name TEXT, steam_name TEXT, "
		.. "officer_steamid VARCHAR(32), officer_name TEXT, "
		.. "crime_ids TEXT, crime_names TEXT, charge_text TEXT, notes TEXT, "
		.. "jail_seconds INTEGER, fine_amount INTEGER, fine_paid INTEGER, fine_owed INTEGER, "
		.. "created_at INTEGER, expires_at INTEGER, status VARCHAR(24) )")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_jail_active ("
		.. "steamid VARCHAR(32) PRIMARY KEY, record_id INTEGER, expires_at INTEGER, cell_id INTEGER, remaining_seconds INTEGER )")

	local function ensureActiveRemainingColumn()
		if MilBase.DB.IsMySQL and MilBase.DB.IsMySQL() then
			MilBase.DB.Query("SHOW COLUMNS FROM frontier_jail_active LIKE 'remaining_seconds'", function(rows)
				if not rows or #rows == 0 then
					MilBase.DB.Run("ALTER TABLE frontier_jail_active ADD COLUMN remaining_seconds INTEGER")
				end
			end)
		else
			MilBase.DB.Query("PRAGMA table_info(frontier_jail_active)", function(rows)
				local hasColumn = false
				for _, row in ipairs(rows or {}) do
					if row.name == "remaining_seconds" then hasColumn = true break end
				end
				if not hasColumn then
					MilBase.DB.Run("ALTER TABLE frontier_jail_active ADD COLUMN remaining_seconds INTEGER")
				end
			end)
		end
	end
	ensureActiveRemainingColumn()

	local function seedDefaultCrimesIfEmpty()
		MilBase.DB.Query("SELECT COUNT(*) AS n FROM frontier_jail_crimes", function(rows)
			local n = tonumber(rows and rows[1] and (rows[1].n or rows[1]["COUNT(*)"]) or 0) or 0
			if n > 0 then return end

			for _, c in ipairs(cfg.JailDefaultCrimes or {}) do
				MilBase.DB.Run(string.format(
					"INSERT INTO frontier_jail_crimes (code, name, charge, jail_time, fine, active) VALUES (%s, %s, %s, %d, %d, 1)",
					MilBase.SQLStr(defaultText(c.code, "CRIME")),
					MilBase.SQLStr(defaultText(c.name, "Crime")),
					MilBase.SQLStr(trim(c.charge)),
					clampInt(c.time or c.jail_time, 0, cfg.JailMaxSentence or 7200),
					clampInt(c.fine, 0, nil)
				))
			end

			timer.Simple(0.2, function()
				if MilBase.JailReloadCrimes then MilBase.JailReloadCrimes() end
			end)
		end)
	end

	function MilBase.JailReloadCrimes(onDone)
		MilBase.DB.Query("SELECT * FROM frontier_jail_crimes ORDER BY name ASC, id ASC", function(rows)
			MilBase.Jail.Crimes = {}
			MilBase.Jail.CrimeOrder = {}

			for _, row in ipairs(rows or {}) do
				local id = tonumber(row.id) or 0
				if id > 0 then
					MilBase.Jail.Crimes[id] = {
						id = id,
						code = row.code or "",
						name = row.name or "Crime",
						charge = row.charge or "",
						time = tonumber(row.jail_time or row.time or 0) or 0,
						fine = tonumber(row.fine or 0) or 0,
						active = tonumber(row.active or 1) or 0,
					}
					MilBase.Jail.CrimeOrder[#MilBase.Jail.CrimeOrder + 1] = id
				end
			end

			if onDone then onDone() end
		end)
	end

	local function sendCrimeAdmin(ply)
		if not MilBase.JailCanManageCrimes(ply) then return end
		net.Start(NET_CRIMES_DATA)
			net.WriteTable(allCrimesForAdmin())
		net.Send(ply)
	end

	local function sanitizeCrime(data)
		data = istable(data) and data or {}
		local name = defaultText(data.name, "New Crime")
		local code = string.upper(defaultText(data.code, string.sub(string.gsub(name, "%s+", "_"), 1, 24)))
		return {
			id = clampInt(data.id, 0, nil),
			code = string.sub(code, 1, 32),
			name = string.sub(name, 1, 80),
			charge = string.sub(trim(data.charge), 1, 512),
			time = clampInt(data.time or data.jail_time, 0, cfg.JailMaxSentence or 7200),
			fine = clampInt(data.fine, 0, nil),
			active = (data.active == false or tonumber(data.active) == 0) and 0 or 1,
		}
	end

	net.Receive(NET_CRIMES_ADMIN, function(_, ply)
		if not MilBase.JailCanManageCrimes(ply) then return end
		local action = net.ReadString()

		if action == "list" then
			sendCrimeAdmin(ply)
		elseif action == "save" then
			local data = sanitizeCrime(net.ReadTable())
			if data.id > 0 and MilBase.Jail.Crimes[data.id] then
				MilBase.DB.Run(string.format(
					"UPDATE frontier_jail_crimes SET code = %s, name = %s, charge = %s, jail_time = %d, fine = %d, active = %d WHERE id = %d",
					MilBase.SQLStr(data.code), MilBase.SQLStr(data.name), MilBase.SQLStr(data.charge),
					data.time, data.fine, data.active, data.id))
				MilBase.Notify(ply, "Crime updated: " .. data.name .. ".", "ok")
			else
				MilBase.DB.Run(string.format(
					"INSERT INTO frontier_jail_crimes (code, name, charge, jail_time, fine, active) VALUES (%s, %s, %s, %d, %d, %d)",
					MilBase.SQLStr(data.code), MilBase.SQLStr(data.name), MilBase.SQLStr(data.charge),
					data.time, data.fine, data.active))
				MilBase.Notify(ply, "Crime added: " .. data.name .. ".", "ok")
			end

			timer.Simple(0.15, function()
				MilBase.JailReloadCrimes(function()
					if IsValid(ply) then sendCrimeAdmin(ply) end
				end)
			end)
		elseif action == "delete" then
			local id = clampInt(net.ReadUInt(32), 0, nil)
			if id <= 0 then return end
			MilBase.DB.Run("DELETE FROM frontier_jail_crimes WHERE id = " .. id)
			MilBase.Notify(ply, "Crime deleted.", "warn")
			timer.Simple(0.15, function()
				MilBase.JailReloadCrimes(function()
					if IsValid(ply) then sendCrimeAdmin(ply) end
				end)
			end)
		end
	end)

	local function terminalClass(kind)
		if kind == "records" then return "mb_records_terminal" end
		return "mb_arrest_terminal"
	end

	local function spawnTerminal(row)
		local kind = row.kind == "records" and "records" or "arrest"
		local ent = ents.Create(terminalClass(kind))
		if not IsValid(ent) then return end
		ent:SetPos(row.pos)
		ent:SetAngles(row.ang)
		ent.MBJailPointID = row.id
		ent.MBJailPersistent = true
		ent.MBJailKind = kind
		ent.MBJailName = row.name or (kind == "records" and "Records Terminal" or "Arrest Terminal")
		ent:Spawn()
		ent:Activate()
		row.ent = ent
		return ent
	end

	local function removePersistentTerminals()
		for _, ent in ipairs(ents.FindByClass("mb_arrest_terminal")) do
			if ent.MBJailPersistent then ent:Remove() end
		end
		for _, ent in ipairs(ents.FindByClass("mb_records_terminal")) do
			if ent.MBJailPersistent then ent:Remove() end
		end
	end

	function MilBase.JailReloadMapPoints(onDone)
		MilBase.Jail.Cells = {}
		MilBase.Jail.Terminals = {}
		removePersistentTerminals()

		MilBase.DB.Query("SELECT * FROM frontier_jail_cells WHERE map = " .. MilBase.SQLStr(game.GetMap()), function(rows)
			for _, row in ipairs(rows or {}) do
				local id = tonumber(row.id) or 0
				if id > 0 then
					MilBase.Jail.Cells[id] = {
						id = id,
						name = row.name or ("Cell #" .. id),
						pos = rowVec(row.pos),
						ang = rowAng(row.ang),
					}
				end
			end

			MilBase.DB.Query("SELECT * FROM frontier_jail_terminals WHERE map = " .. MilBase.SQLStr(game.GetMap()), function(trows)
				for _, row in ipairs(trows or {}) do
					local id = tonumber(row.id) or 0
					if id > 0 then
						local terminal = {
							id = id,
							kind = row.kind == "records" and "records" or "arrest",
							name = row.name or "Terminal",
							pos = rowVec(row.pos),
							ang = rowAng(row.ang),
						}
						MilBase.Jail.Terminals[id] = terminal
						spawnTerminal(terminal)
					end
				end
				if onDone then onDone() end
			end)
		end)
	end

	local function nearestCell(pos, radius)
		local best, bestD
		local maxD = (radius or 260) ^ 2
		for _, cell in pairs(MilBase.Jail.Cells or {}) do
			local d = cell.pos and cell.pos:DistToSqr(pos) or math.huge
			if d <= maxD and (not bestD or d < bestD) then
				best, bestD = cell, d
			end
		end
		return best
	end

	local function nearestTerminal(pos, kind, radius)
		local best, bestD
		local maxD = (radius or 260) ^ 2
		for _, terminal in pairs(MilBase.Jail.Terminals or {}) do
			if terminal.kind == kind then
				local d = terminal.pos and terminal.pos:DistToSqr(pos) or math.huge
				if d <= maxD and (not bestD or d < bestD) then
					best, bestD = terminal, d
				end
			end
		end
		return best
	end

	local function notifySetup(ply, text, kind)
		if IsValid(ply) then MilBase.Notify(ply, text, kind) end
	end

	function MilBase.JailAddPoint(ply, kind, pos, ang, name)
		if not MilBase.JailCanConfigure(ply) then return false end
		if not isvector(pos) then return false end
		ang = isangle(ang) and ang or angle_zero
		kind = kind == "records" and "records" or (kind == "arrest" and "arrest" or "cell")
		name = defaultText(name, kind == "cell" and "Prison Cell" or (kind == "records" and "Records Terminal" or "Arrest Terminal"))

		if kind == "cell" then
			MilBase.DB.Insert(string.format(
				"INSERT INTO frontier_jail_cells (map, name, pos, ang) VALUES (%s, %s, %s, %s)",
				MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(name), serializeVec(pos), serializeAng(ang)), function(id)
				if not id then notifySetup(ply, "Prison cell could not be saved.", "danger") return end
				MilBase.Jail.Cells[tonumber(id)] = { id = tonumber(id), name = name, pos = pos, ang = ang }
				notifySetup(ply, "Prison cell added: " .. name .. ".", "ok")
			end)
			return true
		end

		MilBase.DB.Insert(string.format(
			"INSERT INTO frontier_jail_terminals (map, kind, name, pos, ang) VALUES (%s, %s, %s, %s, %s)",
			MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(kind), MilBase.SQLStr(name), serializeVec(pos), serializeAng(ang)), function(id)
			if not id then notifySetup(ply, "Jail terminal could not be saved.", "danger") return end
			local terminal = { id = tonumber(id), kind = kind, name = name, pos = pos, ang = ang }
			MilBase.Jail.Terminals[tonumber(id)] = terminal
			spawnTerminal(terminal)
			notifySetup(ply, (kind == "records" and "Records" or "Arrest") .. " terminal added: " .. name .. ".", "ok")
		end)
		return true
	end

	function MilBase.JailUpdateNearest(ply, kind, pos, ang, name)
		if not MilBase.JailCanConfigure(ply) or not isvector(pos) then return false end
		ang = isangle(ang) and ang or angle_zero
		kind = kind == "records" and "records" or (kind == "arrest" and "arrest" or "cell")
		name = defaultText(name, kind == "cell" and "Prison Cell" or (kind == "records" and "Records Terminal" or "Arrest Terminal"))

		if kind == "cell" then
			local cell = nearestCell(pos, 320)
			if not cell then notifySetup(ply, "No prison cell close enough to update.", "warn") return false end
			MilBase.DB.Run(string.format(
				"UPDATE frontier_jail_cells SET name = %s, pos = %s, ang = %s WHERE id = %d AND map = %s",
				MilBase.SQLStr(name), serializeVec(pos), serializeAng(ang), cell.id, MilBase.SQLStr(game.GetMap())))
			cell.name, cell.pos, cell.ang = name, pos, ang
			notifySetup(ply, "Prison cell updated: " .. name .. ".", "ok")
			return true
		end

		local terminal = nearestTerminal(pos, kind, 320)
		if not terminal then notifySetup(ply, "No " .. kind .. " terminal close enough to update.", "warn") return false end
		MilBase.DB.Run(string.format(
			"UPDATE frontier_jail_terminals SET name = %s, pos = %s, ang = %s WHERE id = %d AND map = %s",
			MilBase.SQLStr(name), serializeVec(pos), serializeAng(ang), terminal.id, MilBase.SQLStr(game.GetMap())))
		terminal.name, terminal.pos, terminal.ang = name, pos, ang
		if IsValid(terminal.ent) then
			terminal.ent:SetPos(pos)
			terminal.ent:SetAngles(ang)
			terminal.ent.MBJailName = name
		end
		notifySetup(ply, (kind == "records" and "Records" or "Arrest") .. " terminal updated: " .. name .. ".", "ok")
		return true
	end

	function MilBase.JailRemoveNearest(ply, kind, pos, radius)
		if not MilBase.JailCanConfigure(ply) then return false end
		kind = kind == "records" and "records" or (kind == "arrest" and "arrest" or "cell")

		if kind == "cell" then
			local cell = nearestCell(pos, radius or 320)
			if not cell then notifySetup(ply, "No prison cell close enough to remove.", "warn") return false end
			MilBase.DB.Run("DELETE FROM frontier_jail_cells WHERE id = " .. tonumber(cell.id) .. " AND map = " .. MilBase.SQLStr(game.GetMap()))
			MilBase.Jail.Cells[cell.id] = nil
			notifySetup(ply, "Prison cell removed: " .. (cell.name or cell.id) .. ".", "warn")
			return true
		end

		local terminal = nearestTerminal(pos, kind, radius or 320)
		if not terminal then notifySetup(ply, "No " .. kind .. " terminal close enough to remove.", "warn") return false end
		MilBase.DB.Run("DELETE FROM frontier_jail_terminals WHERE id = " .. tonumber(terminal.id) .. " AND map = " .. MilBase.SQLStr(game.GetMap()))
		if IsValid(terminal.ent) then terminal.ent:Remove() end
		MilBase.Jail.Terminals[terminal.id] = nil
		notifySetup(ply, (kind == "records" and "Records" or "Arrest") .. " terminal removed: " .. (terminal.name or terminal.id) .. ".", "warn")
		return true
	end

	local function pickCell()
		local cells = {}
		for _, cell in pairs(MilBase.Jail.Cells or {}) do
			if isvector(cell.pos) then cells[#cells + 1] = cell end
		end
		if #cells == 0 then return nil end
		return cells[math.random(1, #cells)]
	end

	local function getCell(id)
		id = tonumber(id or 0) or 0
		return (MilBase.Jail.Cells or {})[id] or pickCell()
	end

	local function setJailNW(ply, active, recordID, expiresAt, cellID)
		ply:SetNWBool("mb_jailed", active == true)
		ply:SetNWInt("mb_jail_record", tonumber(recordID or 0) or 0)
		ply:SetNWInt("mb_jail_end", tonumber(expiresAt or 0) or 0)
		ply:SetNWInt("mb_jail_cell", tonumber(cellID or 0) or 0)
		if active and MilBase.CloseCharacterSwitchMenu then
			MilBase.CloseCharacterSwitchMenu(ply)
		end
	end

	local function formatDuration(seconds)
		seconds = math.max(0, tonumber(seconds or 0) or 0)
		local mins = math.floor(seconds / 60)
		local secs = seconds % 60
		if mins > 0 then return mins .. "m " .. secs .. "s" end
		return secs .. "s"
	end

	function MilBase.JailRelease(ply, expired)
		if not IsValid(ply) then return end
		local sid = MilBase.SQLStr(ply:SteamID64())
		local recordID = tonumber(ply:GetNWInt("mb_jail_record", 0)) or 0
		MilBase.DB.Run("DELETE FROM frontier_jail_active WHERE steamid = " .. sid)
		if recordID > 0 then
			MilBase.DB.Run("UPDATE frontier_jail_records SET status = 'released' WHERE id = " .. recordID)
		end

		ply.mb_jailActive = nil
		setJailNW(ply, false, 0, 0, 0)
		if expired then MilBase.Notify(ply, "Your jail sentence has ended.", "ok") end
		if ply:Alive() then
			ply:SetNWBool("mb_cuffed", false)
			if MilBase.UpdateMoveSpeed then MilBase.UpdateMoveSpeed(ply) end
			ply:Spawn()
		end
	end

	function MilBase.JailApply(ply, reason)
		if not IsValid(ply) or not ply.mb_jailActive then return false end
		local data = ply.mb_jailActive
		if tonumber(data.expiresAt or 0) <= now() then
			MilBase.JailRelease(ply, true)
			return false
		end

		local cell = getCell(data.cellID)
		if not cell then return false end
		data.cellID = cell.id
		setJailNW(ply, true, data.recordID, data.expiresAt, cell.id)

		ply.mb_spawn_selecting = false
		ply:SetNWBool("mb_spawn_selecting", false)
		ply:SetNWString("mb_spawn_select_reason", "")

		if not ply:Alive() then return true end
		ply:UnSpectate()
		ply:SetNoDraw(false)
		ply:SetNotSolid(false)
		ply:Freeze(false)
		ply:GodDisable()
		ply:SetMoveType(MOVETYPE_WALK)
		ply:SetNWBool("mb_cuffed", false)
		ply:StripWeapons()
		ply:StripAmmo()
		if MilBase.UpdateMoveSpeed then MilBase.UpdateMoveSpeed(ply) end
		ply:SetPos(cell.pos + Vector(0, 0, 8))
		ply:SetEyeAngles(Angle(0, (cell.ang and cell.ang.y) or 0, 0))
		ply:SetLocalVelocity(vector_origin)

		if reason ~= "silent" then
			local left = math.max(0, (tonumber(data.expiresAt or 0) or 0) - now())
			MilBase.Notify(ply, "You are jailed for " .. formatDuration(left) .. ".", "warn")
		end
		return true
	end

	function MilBase.JailLoadActive(ply)
		if not IsValid(ply) then return end
		ply.mb_jailStateLoaded = false
		ply.mb_jailStateLoadFailed = nil
		MilBase.DB.Query("SELECT * FROM frontier_jail_active WHERE steamid = " .. MilBase.SQLStr(ply:SteamID64()), function(rows)
			if not IsValid(ply) then return end
			ply.mb_jailStateLoaded = true
			ply.mb_jailStateLoadFailed = nil
			local row = rows and rows[1]
			if not row then return end

			local remaining = tonumber(row.remaining_seconds or 0) or 0
			local expiresAt = tonumber(row.expires_at or 0) or 0
			local recordID = tonumber(row.record_id or 0) or 0
			if remaining > 0 then
				expiresAt = now() + remaining
				MilBase.DB.Run(string.format("UPDATE frontier_jail_active SET expires_at = %d, remaining_seconds = 0 WHERE steamid = %s", expiresAt, MilBase.SQLStr(ply:SteamID64())))
			end
			if expiresAt <= now() then
				MilBase.DB.Run("DELETE FROM frontier_jail_active WHERE steamid = " .. MilBase.SQLStr(ply:SteamID64()))
				if recordID > 0 then MilBase.DB.Run("UPDATE frontier_jail_records SET status = 'released' WHERE id = " .. recordID) end
				return
			end

			ply.mb_jailActive = {
				recordID = recordID,
				expiresAt = expiresAt,
				cellID = tonumber(row.cell_id or 0) or 0,
			}
			MilBase.JailApply(ply, "silent")
		end, function()
			-- Fail closed: without an authoritative account-wide custody result,
			-- character switching remains disabled instead of allowing a prisoner
			-- to escape through a temporary database failure.
			if not IsValid(ply) then return end
			ply.mb_jailStateLoaded = false
			ply.mb_jailStateLoadFailed = true
		end)
	end

	local function buildCuffedCandidates(terminal)
		local out = {}
		local maxD = (cfg.JailArrestTargetRange or 220) ^ 2
		local tpos = terminal:GetPos()
		for _, p in ipairs(player.GetAll()) do
			if p:Alive() and p:GetNWBool("mb_cuffed", false) and p:GetPos():DistToSqr(tpos) <= maxD then
				local faction = p:MBFaction()
				out[#out + 1] = {
					ent = p,
					name = p:MBName(),
					steam = p:Nick(),
					faction = faction and faction.name or "Unknown",
					rank = (p:MBRank() and p:MBRank().name) or "",
				}
			end
		end
		table.sort(out, function(a, b) return string.lower(a.name) < string.lower(b.name) end)
		return out
	end

	function MilBase.JailOpenArrestTerminal(ply, terminal)
		if not MilBase.JailCanArrest(ply) then
			MilBase.Notify(ply, "Only CG / police can use arrest terminals.", "warn")
			return
		end
		if not IsValid(terminal) or terminal:GetClass() ~= "mb_arrest_terminal" then return end
		if ply:GetPos():DistToSqr(terminal:GetPos()) > (cfg.JailTerminalUseRange or 170) ^ 2 then return end

		ply.mb_jail_terminal = terminal
		net.Start(NET_ARREST_OPEN)
			net.WriteEntity(terminal)
			net.WriteTable(buildCuffedCandidates(terminal))
			net.WriteTable(crimeListForClient())
		net.Send(ply)
	end

	local function collectSelectedCrimes(ids)
		local selected = {}
		local seen = {}
		local totalTime = 0
		local totalFine = 0
		local names = {}
		local charges = {}

		for _, id in ipairs(istable(ids) and ids or {}) do
			id = tonumber(id) or 0
			local c = MilBase.Jail.Crimes[id]
			if id > 0 and c and tonumber(c.active or 1) == 1 and not seen[id] then
				seen[id] = true
				selected[#selected + 1] = c
				totalTime = totalTime + (tonumber(c.time or 0) or 0)
				totalFine = totalFine + (tonumber(c.fine or 0) or 0)
				names[#names + 1] = c.name or "Crime"
				local line = (c.code ~= "" and ("[" .. c.code .. "] ") or "") .. (c.name or "Crime")
				if trim(c.charge) ~= "" then line = line .. ": " .. trim(c.charge) end
				charges[#charges + 1] = line
			end
		end

		totalTime = clampInt(totalTime, 0, cfg.JailMaxSentence or 7200)
		return selected, totalTime, totalFine, names, charges
	end

	function MilBase.JailArrest(officer, target, crimeIDs, notes)
		if not MilBase.JailCanArrest(officer) then return false end
		if not IsValid(target) or not target:IsPlayer() or not target:Alive() then
			MilBase.Notify(officer, "Target is not available.", "warn")
			return false
		end
		if target:GetNWBool("mb_cuffed", false) ~= true then
			MilBase.Notify(officer, "Target must be cuffed first.", "warn")
			return false
		end

		local cell = pickCell()
		if not cell then
			MilBase.Notify(officer, "No prison cells have been defined with the Jail System Toolgun.", "danger")
			return false
		end

		local selected, totalTime, totalFine, names, charges = collectSelectedCrimes(crimeIDs)
		if #selected == 0 then
			MilBase.Notify(officer, "Select at least one crime.", "warn")
			return false
		end

		local createdAt = now()
		local expiresAt = createdAt + totalTime
		local paid = math.min(target:MBMoney(), totalFine)
		local owed = math.max(0, totalFine - paid)
		if paid > 0 then target:MBAddMoney(-paid) end

		local crimeIDText = table.concat(crimeIDs or {}, ",")
		local crimeNameText = table.concat(names, ", ")
		local chargeText = table.concat(charges, "\n")
		notes = string.sub(trim(notes), 1, 512)

		local insertSQL = string.format(
			"INSERT INTO frontier_jail_records (steamid, rp_name, steam_name, officer_steamid, officer_name, crime_ids, crime_names, charge_text, notes, jail_seconds, fine_amount, fine_paid, fine_owed, created_at, expires_at, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %d, %d, %d, %d, %d, %s)",
			MilBase.SQLStr(target:SteamID64()),
			MilBase.SQLStr(target:MBName()),
			MilBase.SQLStr(target:Nick()),
			MilBase.SQLStr(officer:SteamID64()),
			MilBase.SQLStr(officer:MBName()),
			MilBase.SQLStr(crimeIDText),
			MilBase.SQLStr(crimeNameText),
			MilBase.SQLStr(chargeText),
			MilBase.SQLStr(notes),
			totalTime,
			totalFine,
			paid,
			owed,
			createdAt,
			expiresAt,
			MilBase.SQLStr(totalTime > 0 and "active" or "fine_only")
		)

		MilBase.DB.Insert(insertSQL, function(recordID)
			if not IsValid(target) then return end
			recordID = tonumber(recordID or 0) or 0
			if totalTime > 0 then
				MilBase.DB.Run(string.format(
					"REPLACE INTO frontier_jail_active (steamid, record_id, expires_at, cell_id, remaining_seconds) VALUES (%s, %d, %d, %d, 0)",
					MilBase.SQLStr(target:SteamID64()), recordID, expiresAt, cell.id))
				target.mb_jailActive = { recordID = recordID, expiresAt = expiresAt, cellID = cell.id }
				MilBase.JailApply(target)
			else
				if recordID > 0 then MilBase.DB.Run("UPDATE frontier_jail_records SET status = 'released' WHERE id = " .. recordID) end
			end
		end)
		if MilBase.RosterRecordArrest then
			MilBase.RosterRecordArrest(target, createdAt, officer)
		end

		MilBase.Notify(officer, "Arrest processed: " .. target:MBName() .. " — " .. formatDuration(totalTime) .. ", fine " .. (cfg.CurrencySymbol or "₡") .. totalFine .. ".", "ok")
		MilBase.Notify(target, "You were charged with: " .. crimeNameText .. ". Fine: " .. (cfg.CurrencySymbol or "₡") .. totalFine .. ".", "warn")
		if owed > 0 then MilBase.Notify(target, "Unpaid fine balance recorded: " .. (cfg.CurrencySymbol or "₡") .. owed .. ".", "warn") end
		MilBase.ChatMsg(nil, Color(70, 110, 180), "[CG] ", color_white,
			target:MBName() .. " was charged by " .. officer:MBName() .. " for " .. crimeNameText .. ".")
		if MilBase.Log then
			MilBase.Log("jail", MilBase.LogTag(officer) .. " charged " .. MilBase.LogTag(target) .. " with " .. crimeNameText, officer, target)
		end
		return true
	end

	net.Receive(NET_ARREST_SUBMIT, function(_, ply)
		local target = net.ReadEntity()
		local ids = net.ReadTable()
		local notes = net.ReadString()
		local terminal = ply.mb_jail_terminal

		if not IsValid(terminal) or terminal:GetClass() ~= "mb_arrest_terminal" then
			MilBase.Notify(ply, "Use an arrest terminal first.", "warn")
			return
		end
		if ply:GetPos():DistToSqr(terminal:GetPos()) > (cfg.JailTerminalUseRange or 170) ^ 2 then
			MilBase.Notify(ply, "You are too far from the arrest terminal.", "warn")
			return
		end
		if IsValid(target) and target:GetPos():DistToSqr(terminal:GetPos()) > (cfg.JailArrestTargetRange or 220) ^ 2 then
			MilBase.Notify(ply, "The target must be cuffed and near the arrest terminal.", "warn")
			return
		end
		MilBase.JailArrest(ply, target, ids, notes)
	end)

	function MilBase.JailOpenRecords(ply)
		if not MilBase.JailCanViewRecords(ply) then
			MilBase.Notify(ply, "Only CG / police can access criminal records.", "warn")
			return
		end
		net.Start(NET_RECORDS_OPEN)
		net.Send(ply)
	end

	local function sendRecordsData(ply, query, rows)
		local records = {}
		local totalFine, totalPaid, totalOwed, totalTime = 0, 0, 0, 0
		for _, row in ipairs(rows or {}) do
			local fine = tonumber(row.fine_amount or 0) or 0
			local paid = tonumber(row.fine_paid or 0) or 0
			local owed = tonumber(row.fine_owed or 0) or 0
			local seconds = tonumber(row.jail_seconds or 0) or 0
			totalFine = totalFine + fine
			totalPaid = totalPaid + paid
			totalOwed = totalOwed + owed
			totalTime = totalTime + seconds
			records[#records + 1] = {
				id = tonumber(row.id) or 0,
				steamid = row.steamid or "",
				rp_name = row.rp_name or "Unknown",
				steam_name = row.steam_name or "",
				officer_name = row.officer_name or "Unknown",
				crime_names = row.crime_names or "",
				charge_text = row.charge_text or "",
				notes = row.notes or "",
				jail_seconds = seconds,
				fine_amount = fine,
				fine_paid = paid,
				fine_owed = owed,
				created_at = tonumber(row.created_at or 0) or 0,
				expires_at = tonumber(row.expires_at or 0) or 0,
				status = row.status or "recorded",
			}
		end

		net.Start(NET_RECORDS_DATA)
			net.WriteString(query or "")
			net.WriteTable(records)
			net.WriteTable({
				count = #records,
				totalFine = totalFine,
				totalPaid = totalPaid,
				totalOwed = totalOwed,
				totalTime = totalTime,
			})
		net.Send(ply)
	end

	local function recordsWhere(query)
		query = trim(query)
		if query == "" then return "1=1" end
		local like = MilBase.SQLStr("%" .. query .. "%")
		return "(rp_name LIKE " .. like .. " OR steam_name LIKE " .. like .. " OR steamid LIKE " .. like
			.. " OR crime_names LIKE " .. like .. " OR officer_name LIKE " .. like .. ")"
	end

	function MilBase.JailSearchRecords(ply, query)
		if not MilBase.JailCanViewRecords(ply) then return end
		query = string.sub(trim(query), 1, 64)
		local limit = clampInt(cfg.JailRecordsSearchLimit or 60, 10, 200)
		local sqlText = "SELECT * FROM frontier_jail_records WHERE " .. recordsWhere(query)
			.. " ORDER BY created_at DESC, id DESC LIMIT " .. limit
		MilBase.DB.Query(sqlText, function(rows)
			if IsValid(ply) then sendRecordsData(ply, query, rows or {}) end
		end)
	end

	net.Receive(NET_RECORDS_SEARCH, function(_, ply)
		local query = net.ReadString()
		MilBase.JailSearchRecords(ply, query)
	end)

	hook.Add("InitPostEntity", "MilBase.Jail.Reload", function()
		seedDefaultCrimesIfEmpty()
		MilBase.JailReloadCrimes()
		MilBase.JailReloadMapPoints()
	end)

	hook.Add("PostCleanupMap", "MilBase.Jail.Reload", function()
		timer.Simple(0, function()
			if MilBase.JailReloadMapPoints then MilBase.JailReloadMapPoints() end
		end)
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.Jail.PendingState", function(ply)
		ply.mb_jailStateLoaded = false
		ply.mb_jailStateLoadFailed = nil
	end)

	hook.Add("MilBase.PlayerLoaded", "MilBase.Jail.LoadActive", function(ply)
		MilBase.JailLoadActive(ply)
	end)

	hook.Add("PlayerDisconnected", "MilBase.Jail.PauseOfflineSentence", function(ply)
		if not ply.mb_jailActive then return end
		local remaining = math.max(0, (tonumber(ply.mb_jailActive.expiresAt or 0) or 0) - now())
		MilBase.DB.Run(string.format(
			"UPDATE frontier_jail_active SET remaining_seconds = %d WHERE steamid = %s",
			remaining, MilBase.SQLStr(ply:SteamID64())))
	end)

	hook.Add("PlayerSpawn", "MilBase.Jail.ApplyOnSpawn", function(ply)
		if ply.mb_jailActive then
			timer.Simple(0, function()
				if IsValid(ply) then MilBase.JailApply(ply, "silent") end
			end)
		end
	end)

	hook.Add("PlayerDeathThink", "MilBase.Jail.DeathThink", function(ply)
		if ply.mb_jailActive then
			local deathTime = ply:GetNWFloat("mb_deathtime", 0)
			if CurTime() >= deathTime + (cfg.RespawnTime or 0) then ply:Spawn() end
			return true
		end
	end)

	local nextThink = 0
	hook.Add("Think", "MilBase.Jail.ActiveThink", function()
		if CurTime() < nextThink then return end
		nextThink = CurTime() + math.max(0.5, tonumber(cfg.JailThinkInterval or 1.5) or 1.5)

		for _, ply in ipairs(player.GetAll()) do
			if ply.mb_jailActive then
				if (tonumber(ply.mb_jailActive.expiresAt or 0) or 0) <= now() then
					MilBase.JailRelease(ply, true)
				elseif ply:Alive() then
					local cell = getCell(ply.mb_jailActive.cellID)
					if cell and ply:GetPos():DistToSqr(cell.pos) > (cfg.JailCellLeashRadius or 900) ^ 2 then
						ply:SetPos(cell.pos + Vector(0, 0, 8))
						ply:SetLocalVelocity(vector_origin)
						MilBase.Notify(ply, "You cannot leave prison until your sentence ends.", "warn")
					end
					if #ply:GetWeapons() > 0 then
						ply:StripWeapons()
						ply:StripAmmo()
					end
				end
			end
		end
	end)

	MilBase.RegisterChatCommand("jailrecords", {
		help = "Open criminal records if you are CG / police.",
		func = function(ply)
			MilBase.JailOpenRecords(ply)
		end,
	})

	MilBase.RegisterChatCommand("jailreload", {
		help = "Reload jail cells and terminals. (staff)",
		func = function(ply)
			if not MilBase.JailCanConfigure(ply) then MilBase.Notify(ply, "No permission.", "warn") return end
			MilBase.JailReloadMapPoints(function()
				if IsValid(ply) then MilBase.Notify(ply, "Jail cells and terminals reloaded.", "ok") end
			end)
		end,
	})
end

if CLIENT then
	local function ui()
		return MilBase.UI or {
			panel = Color(10, 10, 11, 220), raised = Color(255, 198, 60, 12), hover = Color(255, 198, 60, 25),
			outline = Color(255, 198, 60, 50), accent = Color(255, 198, 60), text = color_white,
			dim = Color(180, 180, 180), faint = Color(110, 110, 110), ok = Color(120, 205, 120),
			warn = Color(255, 198, 60), danger = Color(220, 80, 70),
		}
	end

	local function font(name, fallback)
		return (MilBase.UI and name) or (fallback or "DermaDefault")
	end

	local function drawPanel(x, y, w, h, opts)
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(x, y, w, h, opts or {})
		else
			surface.SetDrawColor((opts and opts.color) or Color(0, 0, 0, 220))
			surface.DrawRect(x, y, w, h)
			surface.SetDrawColor((opts and opts.outlineColor) or ui().outline)
			surface.DrawOutlinedRect(x, y, w, h)
		end
	end

	local function paintEntry(self, w, h)
		local u = ui()
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(self:HasFocus() and u.accent or u.outline)
		surface.DrawOutlinedRect(0, 0, w, h)
		self:DrawTextEntryText(u.text, u.accent, u.text)
	end

	local function button(parent, label, accent, onClick)
		local b = vgui.Create("DButton", parent)
		b:SetText("")
		b.Paint = function(self, w, h)
			local u = ui()
			local col = accent or u.accent
			drawPanel(0, 0, w, h, {
				cut = 7,
				color = self:IsHovered() and Color(col.r, col.g, col.b, 46) or u.raised,
				accent = col,
			})
			if self:IsHovered() and MilBase.DrawBrackets then MilBase.DrawBrackets(3, 3, w - 6, h - 6, col, 8) end
			draw.SimpleText(label, font("MB.Small", "DermaDefaultBold"), w / 2, h / 2, u.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		b.DoClick = onClick
		return b
	end

	local function dateText(ts)
		ts = tonumber(ts or 0) or 0
		if ts <= 0 then return "Unknown" end
		return os.date("%Y-%m-%d %H:%M", ts)
	end

	local function durationText(seconds)
		seconds = math.max(0, tonumber(seconds or 0) or 0)
		local mins = math.floor(seconds / 60)
		local secs = seconds % 60
		if mins >= 60 then
			local hrs = math.floor(mins / 60)
			return hrs .. "h " .. (mins % 60) .. "m"
		end
		if mins > 0 then return mins .. "m " .. secs .. "s" end
		return secs .. "s"
	end

	-- While an officer is dragging a cuffed player, mark the closest arrest
	-- console for the dragger. The cuffed player also sees the same marker.
	local nearestArrestCache = { nextCheck = 0, ent = NULL, dist = 0, source = NULL }

	local function arrestMarkerSource()
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:Alive() then return nil end

		local dragged = lp:GetNWEntity("mb_dragging")
		if IsValid(dragged) and dragged:IsPlayer() and dragged:Alive() and dragged:GetNWBool("mb_cuffed", false) then
			return dragged
		end

		local dragger = lp:GetNWEntity("mb_dragged_by")
		if lp:GetNWBool("mb_cuffed", false) and IsValid(dragger) and dragger:IsPlayer() and dragger:Alive() then
			return lp
		end
	end

	local function nearestMarkedArrestConsole()
		local source = arrestMarkerSource()
		if not IsValid(source) then
			nearestArrestCache.ent = NULL
			nearestArrestCache.source = NULL
			nearestArrestCache.dist = 0
			return nil, 0
		end

		if CurTime() < nearestArrestCache.nextCheck and nearestArrestCache.source == source and IsValid(nearestArrestCache.ent) then
			return nearestArrestCache.ent, nearestArrestCache.dist
		end

		nearestArrestCache.nextCheck = CurTime() + 0.2
		nearestArrestCache.source = source

		local best, bestD
		local spos = source:GetPos()
		for _, ent in ipairs(ents.FindByClass("mb_arrest_terminal")) do
			if IsValid(ent) then
				local d = ent:GetPos():DistToSqr(spos)
				if not bestD or d < bestD then
					best, bestD = ent, d
				end
			end
		end

		nearestArrestCache.ent = best or NULL
		nearestArrestCache.dist = bestD and math.sqrt(bestD) or 0
		return best, nearestArrestCache.dist
	end

	hook.Add("PreDrawHalos", "MilBase.Jail.MarkNearestArrestConsole", function()
		local ent = nearestMarkedArrestConsole()
		if not IsValid(ent) then return end
		halo.Add({ ent }, Color(255, 198, 60), 6, 6, 2, true, true)
	end)

	hook.Add("PostDrawTranslucentRenderables", "MilBase.Jail.MarkNearestArrestConsole3D", function()
		local ent, dist = nearestMarkedArrestConsole()
		if not IsValid(ent) then return end

		local col = Color(255, 198, 60, 220)
		render.SetColorMaterial()
		render.DrawWireframeBox(ent:GetPos(), ent:GetAngles(), ent:OBBMins(), ent:OBBMaxs(), col, true)

		local pos = ent:WorldSpaceCenter() + Vector(0, 0, 50)
		local ang = Angle(0, EyeAngles().y - 90, 90)
		cam.Start3D2D(pos, ang, 0.085)
			surface.SetDrawColor(0, 0, 0, 205)
			surface.DrawRect(-120, -26, 240, 52)
			surface.SetDrawColor(col.r, col.g, col.b, 210)
			surface.DrawOutlinedRect(-120, -26, 240, 52, 1)
			draw.SimpleText("CLOSEST ARREST CONSOLE", font("MB.Small", "DermaDefaultBold"), 0, -7, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(math.floor(dist) .. " units away", font("MB.Tiny", "DermaDefault"), 0, 12, Color(210, 210, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.End3D2D()
	end)

	hook.Add("HUDPaint", "MilBase.Jail.MarkNearestArrestConsoleHUD", function()
		local ent, dist = nearestMarkedArrestConsole()
		if not IsValid(ent) then return end

		local u = ui()
		local pos = (ent:WorldSpaceCenter() + Vector(0, 0, 34)):ToScreen()
		local label = "ARREST CONSOLE"
		local sub = math.floor(dist) .. "u"
		local x = math.Clamp(pos.x, 90, ScrW() - 90)
		local y = math.Clamp(pos.y, 86, ScrH() - 86)
		if not pos.visible then y = 92 end

		drawPanel(x - 82, y - 22, 164, 44, { cut = 8, color = Color(0, 0, 0, 185), accent = u.warn })
		draw.SimpleText(label, font("MB.Tiny", "DermaDefaultBold"), x, y - 6, u.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(sub, font("MB.Tiny", "DermaDefault"), x, y + 10, u.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)

	local arrestFrame
	local selectedTarget
	local selectedCrimes = {}

	local function openArrestUI(terminal, candidates, crimes)
		if IsValid(arrestFrame) then arrestFrame:Remove() end
		local u = ui()
		selectedTarget = nil
		selectedCrimes = {}

		arrestFrame = vgui.Create("DFrame")
		arrestFrame:SetSize(math.min(980, ScrW() - 100), math.min(680, ScrH() - 80))
		arrestFrame:Center()
		arrestFrame:SetTitle("")
		arrestFrame:ShowCloseButton(false)
		arrestFrame:SetDraggable(true)
		arrestFrame:MakePopup()
		arrestFrame.Paint = function(self, w, h)
			if MilBase.DrawBlur then MilBase.DrawBlur(self, 5) end
			drawPanel(0, 0, w, h, { cut = 12, color = Color(7, 7, 8, 238), accent = u.accent })
			draw.SimpleText("ARREST TERMINAL", font("MB.Huge", "DermaLarge"), 24, 12, u.text)
			draw.SimpleText("Target must be cuffed and near this terminal.", font("MB.Small", "DermaDefault"), 26, 76, u.dim)
		end

		local close = button(arrestFrame, "CLOSE", u.dim, function() arrestFrame:Close() end)
		close:SetPos(arrestFrame:GetWide() - 116, 20)
		close:SetSize(92, 34)

		local left = vgui.Create("DPanel", arrestFrame)
		left:SetPos(22, 112)
		left:SetSize(300, arrestFrame:GetTall() - 184)
		left.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 120), accent = u.warn })
			draw.SimpleText("CUFFED TARGETS", font("MB.Tab", "DermaDefaultBold"), 14, 8, u.text)
		end

		local targetScroll = vgui.Create("DScrollPanel", left)
		targetScroll:Dock(FILL)
		targetScroll:DockMargin(10, 42, 10, 10)

		for _, target in ipairs(candidates or {}) do
			local row = vgui.Create("DButton", targetScroll)
			row:Dock(TOP)
			row:SetTall(58)
			row:DockMargin(0, 0, 0, 6)
			row:SetText("")
			row.Paint = function(self, w, h)
				local on = selectedTarget == target.ent
				drawPanel(0, 0, w, h, { cut = 7, color = on and Color(u.accent.r, u.accent.g, u.accent.b, 36) or (self:IsHovered() and u.hover or Color(255,255,255,4)), accent = on and u.accent or nil })
				draw.SimpleText(target.name or "Unknown", font("MB.Small", "DermaDefaultBold"), 12, 9, u.text)
				draw.SimpleText((target.rank or "") .. "  •  " .. (target.faction or ""), font("MB.Tiny", "DermaDefault"), 12, 30, u.dim)
			end
			row.DoClick = function()
				selectedTarget = target.ent
				if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			end
		end

		if #(candidates or {}) == 0 then
			local empty = vgui.Create("DLabel", targetScroll)
			empty:Dock(TOP)
			empty:SetTall(60)
			empty:SetWrap(true)
			empty:SetFont(font("MB.Small", "DermaDefault"))
			empty:SetTextColor(u.dim)
			empty:SetText("No cuffed players are close enough to this terminal.")
		end

		local right = vgui.Create("DPanel", arrestFrame)
		right:SetPos(338, 112)
		right:SetSize(arrestFrame:GetWide() - 360, arrestFrame:GetTall() - 184)
		right.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 120), accent = u.accent })
			draw.SimpleText("CRIMES / CHARGES", font("MB.Tab", "DermaDefaultBold"), 14, 8, u.text)
		end

		local crimeScroll = vgui.Create("DScrollPanel", right)
		crimeScroll:Dock(FILL)
		crimeScroll:DockMargin(10, 42, 10, 82)

		local totalLabel = vgui.Create("DLabel", right)
		totalLabel:Dock(BOTTOM)
		totalLabel:SetTall(26)
		totalLabel:SetFont(font("MB.Small", "DermaDefaultBold"))
		totalLabel:SetTextColor(u.accent)
		totalLabel:SetText("No charges selected.")

		local notes = vgui.Create("DTextEntry", right)
		notes:Dock(BOTTOM)
		notes:SetTall(30)
		notes:DockMargin(10, 0, 10, 8)
		notes:SetFont(font("MB.Small", "DermaDefault"))
		notes:SetPaintBackground(false)
		notes:SetPlaceholderText("Officer notes / evidence summary (optional)")
		notes.Paint = paintEntry

		local function updateTotals()
			local t, f, n = 0, 0, 0
			for _, c in ipairs(crimes or {}) do
				if selectedCrimes[c.id] then
					n = n + 1
					t = t + (tonumber(c.time or 0) or 0)
					f = f + (tonumber(c.fine or 0) or 0)
				end
			end
			if n == 0 then
				totalLabel:SetText("No charges selected.")
			else
				totalLabel:SetText(n .. " charge(s)  •  Jail: " .. durationText(t) .. "  •  Fine: " .. (cfg.CurrencySymbol or "₡") .. f)
			end
		end

		for _, c in ipairs(crimes or {}) do
			local row = vgui.Create("DButton", crimeScroll)
			row:Dock(TOP)
			row:SetTall(72)
			row:DockMargin(0, 0, 0, 6)
			row:SetText("")
			row.Paint = function(self, w, h)
				local on = selectedCrimes[c.id] == true
				drawPanel(0, 0, w, h, { cut = 7, color = on and Color(u.accent.r, u.accent.g, u.accent.b, 35) or (self:IsHovered() and u.hover or Color(255,255,255,4)), accent = on and u.accent or nil })
				draw.SimpleText((c.code ~= "" and ("[" .. c.code .. "] ") or "") .. (c.name or "Crime"), font("MB.Small", "DermaDefaultBold"), 12, 8, u.text)
				draw.SimpleText(durationText(c.time) .. "  •  " .. (cfg.CurrencySymbol or "₡") .. tostring(c.fine or 0), font("MB.Tiny", "DermaDefault"), w - 12, 10, u.accent, TEXT_ALIGN_RIGHT)
				draw.SimpleText(c.charge or "", font("MB.Tiny", "DermaDefault"), 12, 34, u.dim)
				draw.SimpleText(on and "SELECTED" or "CLICK TO ADD", font("MB.Tiny", "DermaDefault"), 12, 52, on and u.ok or u.faint)
			end
			row.DoClick = function()
				selectedCrimes[c.id] = not selectedCrimes[c.id]
				updateTotals()
				if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			end
		end

		if #(crimes or {}) == 0 then
			local empty = vgui.Create("DLabel", crimeScroll)
			empty:Dock(TOP)
			empty:SetTall(60)
			empty:SetFont(font("MB.Small", "DermaDefault"))
			empty:SetTextColor(u.dim)
			empty:SetText("No active crimes have been defined yet. Owners can add them in the CRIMES staff tab.")
		end

		local submit = button(arrestFrame, "PROCESS ARREST", u.ok, function()
			if not IsValid(selectedTarget) then MilBase.Notify("Select a cuffed target first.") return end
			local ids = {}
			for id, on in pairs(selectedCrimes) do if on then ids[#ids + 1] = id end end
			if #ids == 0 then MilBase.Notify("Select at least one crime.") return end
			net.Start(NET_ARREST_SUBMIT)
				net.WriteEntity(selectedTarget)
				net.WriteTable(ids)
				net.WriteString(notes:GetValue() or "")
			net.SendToServer()
			arrestFrame:Close()
		end)
		submit:SetPos(arrestFrame:GetWide() - 218, arrestFrame:GetTall() - 56)
		submit:SetSize(196, 38)
	end

	net.Receive(NET_ARREST_OPEN, function()
		local terminal = net.ReadEntity()
		local candidates = net.ReadTable()
		local crimes = net.ReadTable()
		openArrestUI(terminal, candidates, crimes)
	end)

	local recordsFrame
	local recordsList
	local selectedRecord

	local function openRecordsUI()
		if IsValid(recordsFrame) then recordsFrame:Remove() end
		local u = ui()
		selectedRecord = nil

		recordsFrame = vgui.Create("DFrame")
		recordsFrame:SetSize(math.min(1040, ScrW() - 90), math.min(720, ScrH() - 70))
		recordsFrame:Center()
		recordsFrame:SetTitle("")
		recordsFrame:ShowCloseButton(false)
		recordsFrame:SetDraggable(true)
		recordsFrame:MakePopup()
		recordsFrame.Paint = function(self, w, h)
			if MilBase.DrawBlur then MilBase.DrawBlur(self, 5) end
			drawPanel(0, 0, w, h, { cut = 12, color = Color(7, 7, 8, 240), accent = u.accent })
			draw.SimpleText("CRIMINAL RECORDS", font("MB.Huge", "DermaLarge"), 24, 12, u.text)
			draw.SimpleText("Search by RP name, Steam name, SteamID, crime, or officer.", font("MB.Small", "DermaDefault"), 26, 76, u.dim)
		end

		local close = button(recordsFrame, "CLOSE", u.dim, function() recordsFrame:Close() end)
		close:SetPos(recordsFrame:GetWide() - 116, 20)
		close:SetSize(92, 34)

		local search = vgui.Create("DTextEntry", recordsFrame)
		search:SetPos(24, 112)
		search:SetSize(360, 34)
		search:SetFont(font("MB.Small", "DermaDefault"))
		search:SetPaintBackground(false)
		search:SetUpdateOnType(true)
		search:SetPlaceholderText("Search records…")
		search.Paint = paintEntry

		local doSearch = function()
			net.Start(NET_RECORDS_SEARCH)
				net.WriteString(search:GetValue() or "")
			net.SendToServer()
		end
		search.OnEnter = doSearch
		search.OnValueChange = function()
			recordsFrame.mb_nextSearch = CurTime() + 0.25
		end
		recordsFrame.Think = function()
			if recordsFrame.mb_nextSearch and CurTime() >= recordsFrame.mb_nextSearch then
				recordsFrame.mb_nextSearch = nil
				doSearch()
			end
		end

		local searchBtn = button(recordsFrame, "SEARCH", u.accent, doSearch)
		searchBtn:SetPos(396, 112)
		searchBtn:SetSize(110, 34)

		recordsList = vgui.Create("DScrollPanel", recordsFrame)
		recordsList:SetPos(24, 160)
		recordsList:SetSize(470, recordsFrame:GetTall() - 184)

		local detail = vgui.Create("DPanel", recordsFrame)
		detail:SetPos(512, 112)
		detail:SetSize(recordsFrame:GetWide() - 536, recordsFrame:GetTall() - 136)
		detail.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 9, color = Color(0, 0, 0, 125), accent = u.warn })
			if not selectedRecord then
				draw.SimpleText("SELECT A RECORD", font("MB.Big", "DermaLarge"), 18, 20, u.text)
				draw.SimpleText("Arrest details will appear here.", font("MB.Small", "DermaDefault"), 18, 58, u.dim)
				return
			end
			draw.SimpleText(string.upper(selectedRecord.rp_name or "Unknown"), font("MB.Big", "DermaLarge"), 18, 14, u.text)
			draw.SimpleText((selectedRecord.steam_name or "") .. "  •  " .. (selectedRecord.steamid or ""), font("MB.Tiny", "DermaDefault"), 19, 50, u.dim)
			draw.SimpleText("CRIMES", font("MB.Small", "DermaDefaultBold"), 18, 88, u.accent)
			draw.DrawText(selectedRecord.crime_names or "", font("MB.Small", "DermaDefault"), 18, 110, u.text, TEXT_ALIGN_LEFT)
			draw.SimpleText("CHARGES", font("MB.Small", "DermaDefaultBold"), 18, 158, u.accent)
			draw.DrawText(selectedRecord.charge_text or "", font("MB.Tiny", "DermaDefault"), 18, 180, u.dim, TEXT_ALIGN_LEFT)
			draw.SimpleText("OFFICER: " .. (selectedRecord.officer_name or "Unknown"), font("MB.Small", "DermaDefault"), 18, h - 144, u.text)
			draw.SimpleText("DATE: " .. dateText(selectedRecord.created_at), font("MB.Small", "DermaDefault"), 18, h - 118, u.text)
			draw.SimpleText("TIME: " .. durationText(selectedRecord.jail_seconds), font("MB.Small", "DermaDefault"), 18, h - 92, u.text)
			draw.SimpleText("FINE: " .. (cfg.CurrencySymbol or "₡") .. tostring(selectedRecord.fine_amount or 0) .. "  •  PAID: " .. (cfg.CurrencySymbol or "₡") .. tostring(selectedRecord.fine_paid or 0) .. "  •  OWED: " .. (cfg.CurrencySymbol or "₡") .. tostring(selectedRecord.fine_owed or 0), font("MB.Small", "DermaDefault"), 18, h - 66, (selectedRecord.fine_owed or 0) > 0 and u.warn or u.ok)
			draw.SimpleText("STATUS: " .. string.upper(selectedRecord.status or "recorded"), font("MB.Small", "DermaDefaultBold"), 18, h - 38, selectedRecord.status == "active" and u.danger or u.accent)
			if trim(selectedRecord.notes or "") ~= "" then
				draw.SimpleText("NOTES", font("MB.Small", "DermaDefaultBold"), w - 220, h - 118, u.accent)
				draw.DrawText(selectedRecord.notes, font("MB.Tiny", "DermaDefault"), w - 220, h - 96, u.dim, TEXT_ALIGN_LEFT)
			end
		end

		doSearch()
	end

	net.Receive(NET_RECORDS_OPEN, openRecordsUI)

	net.Receive(NET_RECORDS_DATA, function()
		local query = net.ReadString()
		local records = net.ReadTable()
		local summary = net.ReadTable()
		if not IsValid(recordsFrame) or not IsValid(recordsList) then return end
		local u = ui()
		recordsList:Clear()

		local summaryRow = vgui.Create("DPanel", recordsList)
		summaryRow:Dock(TOP)
		summaryRow:SetTall(78)
		summaryRow:DockMargin(0, 0, 0, 8)
		summaryRow.Paint = function(self, w, h)
			drawPanel(0, 0, w, h, { cut = 8, color = Color(u.accent.r, u.accent.g, u.accent.b, 22), accent = u.accent })
			draw.SimpleText((summary.count or 0) .. " RECORD(S)" .. (query ~= "" and (" FOR \"" .. query .. "\"") or ""), font("MB.Small", "DermaDefaultBold"), 12, 10, u.text)
			draw.SimpleText("Total fines: " .. (cfg.CurrencySymbol or "₡") .. tostring(summary.totalFine or 0) .. "  •  Paid: " .. (cfg.CurrencySymbol or "₡") .. tostring(summary.totalPaid or 0) .. "  •  Owed: " .. (cfg.CurrencySymbol or "₡") .. tostring(summary.totalOwed or 0), font("MB.Tiny", "DermaDefault"), 12, 34, (summary.totalOwed or 0) > 0 and u.warn or u.ok)
			draw.SimpleText("Total jail time recorded: " .. durationText(summary.totalTime or 0), font("MB.Tiny", "DermaDefault"), 12, 54, u.dim)
		end

		for _, rec in ipairs(records or {}) do
			local row = vgui.Create("DButton", recordsList)
			row:Dock(TOP)
			row:SetTall(78)
			row:DockMargin(0, 0, 0, 6)
			row:SetText("")
			row.Paint = function(self, w, h)
				local on = selectedRecord and selectedRecord.id == rec.id
				drawPanel(0, 0, w, h, { cut = 8, color = on and Color(u.accent.r, u.accent.g, u.accent.b, 35) or (self:IsHovered() and u.hover or Color(255,255,255,4)), accent = on and u.accent or nil })
				draw.SimpleText(rec.rp_name or "Unknown", font("MB.Small", "DermaDefaultBold"), 12, 8, u.text)
				draw.SimpleText(rec.crime_names or "", font("MB.Tiny", "DermaDefault"), 12, 30, u.dim)
				draw.SimpleText(dateText(rec.created_at), font("MB.Tiny", "DermaDefault"), 12, 52, u.faint)
				draw.SimpleText((cfg.CurrencySymbol or "₡") .. tostring(rec.fine_amount or 0), font("MB.Small", "DermaDefaultBold"), w - 12, 10, u.accent, TEXT_ALIGN_RIGHT)
				draw.SimpleText(string.upper(rec.status or "recorded"), font("MB.Tiny", "DermaDefault"), w - 12, 52, rec.status == "active" and u.danger or u.dim, TEXT_ALIGN_RIGHT)
			end
			row.DoClick = function()
				selectedRecord = rec
				if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			end
		end

		if #(records or {}) == 0 then
			local empty = vgui.Create("DLabel", recordsList)
			empty:Dock(TOP)
			empty:SetTall(42)
			empty:SetFont(font("MB.Small", "DermaDefault"))
			empty:SetTextColor(u.dim)
			empty:SetText("No records found.")
		end
	end)

	local crimes = {}
	local selectedCrime
	local refreshCrimeList

	local function requestCrimes()
		net.Start(NET_CRIMES_ADMIN)
			net.WriteString("list")
		net.SendToServer()
	end

	local function saveCrime(data)
		net.Start(NET_CRIMES_ADMIN)
			net.WriteString("save")
			net.WriteTable(data)
		net.SendToServer()
	end

	local function deleteCrime(id)
		net.Start(NET_CRIMES_ADMIN)
			net.WriteString("delete")
			net.WriteUInt(tonumber(id or 0) or 0, 32)
		net.SendToServer()
	end

	local function ownerCanSee(lp)
		return IsValid(lp) and lp:MBStaffLevel() >= (cfg.JailCrimeOwnerLevel or 7)
	end

	MilBase.AddMenuTab("CRIMES", 94, function(content)
		local u = ui()
		selectedCrime = nil

		local left = vgui.Create("DPanel", content)
		left:Dock(LEFT)
		left:SetWide(360)
		left:DockMargin(0, 0, 14, 0)
		left.Paint = function(self, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText("CRIME DEFINITIONS", font("MB.Tab", "DermaDefaultBold"), 14, 8, u.text)
			draw.SimpleText("Owner only", font("MB.Tiny", "DermaDefault"), 14, 32, u.warn)
		end

		local crimeScroll = vgui.Create("DScrollPanel", left)
		crimeScroll:Dock(FILL)
		crimeScroll:DockMargin(10, 56, 10, 10)

		local right = vgui.Create("DPanel", content)
		right:Dock(FILL)
		right.Paint = function(self, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText("EDIT CRIME / CHARGE", font("MB.Tab", "DermaDefaultBold"), 14, 8, u.text)
			draw.SimpleText("These entries drive arrest time and fines at arrest terminals.", font("MB.Tiny", "DermaDefault"), 14, 32, u.dim)
		end

		local form = vgui.Create("DPanel", right)
		form:Dock(TOP)
		form:DockMargin(12, 62, 12, 8)
		form:SetTall(270)
		form.Paint = nil

		local function label(text)
			local l = vgui.Create("DLabel", form)
			l:Dock(TOP)
			l:SetTall(18)
			l:SetFont(font("MB.Tiny", "DermaDefault"))
			l:SetTextColor(u.dim)
			l:SetText(text)
			return l
		end

		local code, name, charge, time, fine, active
		label("Code")
		code = vgui.Create("DTextEntry", form); code:Dock(TOP); code:SetTall(30); code:DockMargin(0,0,0,6); code:SetFont(font("MB.Small", "DermaDefault")); code:SetPaintBackground(false); code.Paint = paintEntry
		label("Crime name")
		name = vgui.Create("DTextEntry", form); name:Dock(TOP); name:SetTall(30); name:DockMargin(0,0,0,6); name:SetFont(font("MB.Small", "DermaDefault")); name:SetPaintBackground(false); name.Paint = paintEntry
		label("Charge / description")
		charge = vgui.Create("DTextEntry", form); charge:Dock(TOP); charge:SetTall(52); charge:DockMargin(0,0,0,6); charge:SetMultiline(true); charge:SetFont(font("MB.Small", "DermaDefault")); charge:SetPaintBackground(false); charge.Paint = paintEntry
		label("Jail time in seconds")
		time = vgui.Create("DTextEntry", form); time:Dock(TOP); time:SetTall(30); time:DockMargin(0,0,0,6); time:SetNumeric(true); time:SetFont(font("MB.Small", "DermaDefault")); time:SetPaintBackground(false); time.Paint = paintEntry
		label("Fine")
		fine = vgui.Create("DTextEntry", form); fine:Dock(TOP); fine:SetTall(30); fine:DockMargin(0,0,0,6); fine:SetNumeric(true); fine:SetFont(font("MB.Small", "DermaDefault")); fine:SetPaintBackground(false); fine.Paint = paintEntry
		active = vgui.Create("DCheckBoxLabel", form); active:Dock(TOP); active:SetTall(24); active:SetText("Active / selectable at arrest terminals"); active:SetTextColor(u.text); active:SetFont(font("MB.Small", "DermaDefault")); active:SetChecked(true)

		local function fill(c)
			selectedCrime = c
			code:SetText(c and c.code or "")
			name:SetText(c and c.name or "")
			charge:SetText(c and c.charge or "")
			time:SetText(c and tostring(c.time or 0) or "0")
			fine:SetText(c and tostring(c.fine or 0) or "0")
			active:SetChecked(not c or tonumber(c.active or 1) == 1)
		end

		local actions = vgui.Create("DPanel", right)
		actions:Dock(TOP)
		actions:DockMargin(12, 0, 12, 8)
		actions:SetTall(38)
		actions.Paint = nil

		local save = button(actions, "SAVE", u.ok, function()
			saveCrime({
				id = selectedCrime and selectedCrime.id or 0,
				code = code:GetValue(),
				name = name:GetValue(),
				charge = charge:GetValue(),
				time = tonumber(time:GetValue()) or 0,
				fine = tonumber(fine:GetValue()) or 0,
				active = active:GetChecked(),
			})
		end)
		save:Dock(LEFT); save:SetWide(100); save:DockMargin(0, 0, 8, 0)

		local newBtn = button(actions, "NEW", u.accent, function() fill(nil) end)
		newBtn:Dock(LEFT); newBtn:SetWide(100); newBtn:DockMargin(0, 0, 8, 0)

		local del = button(actions, "DELETE", u.danger, function()
			if selectedCrime and selectedCrime.id then deleteCrime(selectedCrime.id) fill(nil) end
		end)
		del:Dock(LEFT); del:SetWide(100)

		local function refreshList()
			if not IsValid(crimeScroll) then return end
			crimeScroll:Clear()
			for _, c in ipairs(crimes or {}) do
				local row = vgui.Create("DButton", crimeScroll)
				row:Dock(TOP)
				row:SetTall(62)
				row:DockMargin(0, 0, 0, 6)
				row:SetText("")
				row.Paint = function(self, w, h)
					local on = selectedCrime and selectedCrime.id == c.id
					drawPanel(0, 0, w, h, { cut = 7, color = on and Color(u.accent.r, u.accent.g, u.accent.b, 35) or (self:IsHovered() and u.hover or Color(255,255,255,4)), accent = on and u.accent or nil })
					draw.SimpleText("[" .. (c.code or "") .. "] " .. (c.name or "Crime"), font("MB.Small", "DermaDefaultBold"), 12, 8, u.text)
					draw.SimpleText(durationText(c.time) .. "  •  " .. (cfg.CurrencySymbol or "₡") .. tostring(c.fine or 0), font("MB.Tiny", "DermaDefault"), 12, 32, u.accent)
					draw.SimpleText(tonumber(c.active or 1) == 1 and "ACTIVE" or "INACTIVE", font("MB.Tiny", "DermaDefault"), w - 12, 32, tonumber(c.active or 1) == 1 and u.ok or u.faint, TEXT_ALIGN_RIGHT)
				end
				row.DoClick = function() fill(c) end
			end
		end

		refreshCrimeList = refreshList
		requestCrimes()
		fill(nil)
		timer.Simple(0, refreshList)
	end, ownerCanSee)

	net.Receive(NET_CRIMES_DATA, function()
		crimes = net.ReadTable() or {}
		if refreshCrimeList then refreshCrimeList() end
	end)
end
