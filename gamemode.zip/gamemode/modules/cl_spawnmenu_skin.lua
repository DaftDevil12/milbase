--[[
	Spawn-menu reskin (staff only see it now — see cl_menugate.lua). Keeps
	all of GMod's default sandbox content/tabs, just themes the chrome to the
	BF2 look: frame backdrop, tab strip, scrollbars and search boxes.

	Only the stable chrome is themed (created once). The dynamic spawn-icon
	grid keeps its default look. Everything is wrapped in pcall so a future
	engine/derma change can't break the menu — worst case it stays unthemed.
]]

if SERVER then return end

local ACCENT = Color(255, 198, 60)

-- Theme one DPropertySheet's tab buttons.
local function themeSheet(sheet)
	if not IsValid(sheet) or not sheet.Items then return end

	sheet.Paint = function() end

	for _, item in pairs(sheet.Items) do
		local tab = item.Tab
		if IsValid(tab) and not tab.mbThemed then
			tab.mbThemed = true
			tab.Paint = function(self, w, h)
				local active = IsValid(self:GetPropertySheet())
					and self:GetPropertySheet():GetActiveTab() == self

				surface.SetDrawColor(active and Color(255, 198, 60, 28) or Color(0, 0, 0, 120))
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 255, 255, 12)
				surface.DrawOutlinedRect(0, 0, w, h)

				if active then
					surface.SetDrawColor(ACCENT)
					surface.DrawRect(0, h - 2, w, 2)
				end
			end
		end
	end
end

-- Thin gold scrollbar.
local function themeScrollbar(bar)
	if not IsValid(bar) or bar.mbThemed then return end
	bar.mbThemed = true

	bar.Paint = function() end
	if IsValid(bar.btnUp) then bar.btnUp.Paint = function() end end
	if IsValid(bar.btnDown) then bar.btnDown.Paint = function() end end
	if IsValid(bar.btnGrip) then
		bar.btnGrip.Paint = function(_, w, h)
			surface.SetDrawColor(255, 198, 60, 60)
			surface.DrawRect(w / 2 - 1, 0, 2, h)
		end
	end
end

-- Recursively theme known chrome classes.
local function restyle(pnl, depth)
	if not IsValid(pnl) or depth > 10 then return end

	local class = pnl.GetClassName and pnl:GetClassName() or ""

	if class == "DPropertySheet" then
		themeSheet(pnl)
	elseif class == "DVScrollBar" then
		themeScrollbar(pnl)
	elseif class == "DTextEntry" then
		if not pnl.mbThemed then
			pnl.mbThemed = true
			pnl.Paint = function(self, w, h)
				if MilBase.DrawPanelBF2 then
					MilBase.DrawPanelBF2(0, 0, w, h, { cut = 4, color = Color(0, 0, 0, 160) })
				else
					surface.SetDrawColor(0, 0, 0, 160)
					surface.DrawRect(0, 0, w, h)
				end
				self:DrawTextEntryText(MilBase.UI.text, MilBase.UI.dim, MilBase.UI.text)
			end
		end
	end

	for _, child in ipairs(pnl:GetChildren()) do
		restyle(child, depth + 1)
	end
end

hook.Add("SpawnMenuCreated", "MilBase.SpawnMenuSkin", function()
	-- Defer a frame so the sheet/children exist, then theme defensively.
	timer.Simple(0, function()
		if not IsValid(g_SpawnMenu) then return end

		pcall(function()
			g_SpawnMenu.Paint = function(_, w, h)
				if MilBase.PaintBackdrop then
					MilBase.PaintBackdrop(g_SpawnMenu, w, h, nil, 235)
				else
					surface.SetDrawColor(8, 9, 11, 240)
					surface.DrawRect(0, 0, w, h)
				end
			end

			restyle(g_SpawnMenu, 0)
		end)
	end)

	-- Re-theme when a creation tab is switched (new sheets/scrollbars appear).
	timer.Simple(0.05, function()
		if IsValid(g_SpawnMenu) then pcall(restyle, g_SpawnMenu, 0) end
	end)
end)
