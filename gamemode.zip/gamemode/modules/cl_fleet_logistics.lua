if not CLIENT or MilBase.FleetLogisticsClientLoaded then return end
MilBase.FleetLogisticsClientLoaded = true

local N = MilBase.Naval
local NET_OPEN = "MilBase_Naval_FleetOpen"
local NET_ACTION = "MilBase_Naval_FleetAction"

surface.CreateFont("MB.FleetTitle", {
	font = "Roboto Condensed", size = 28, weight = 900, extended = true,
})
surface.CreateFont("MB.FleetHeading", {
	font = "Roboto Condensed", size = 19, weight = 800, extended = true,
})
surface.CreateFont("MB.FleetText", {
	font = "Roboto", size = 16, weight = 500, extended = true,
})
surface.CreateFont("MB.FleetTiny", {
	font = "Roboto Condensed", size = 14, weight = 700, extended = true,
})

local colours = {
	background = Color(5, 10, 17, 250),
	panel = Color(8, 17, 28, 245),
	panelAlt = Color(11, 24, 38, 245),
	line = Color(48, 145, 225),
	accent = Color(238, 183, 48),
	text = Color(232, 239, 246),
	dim = Color(150, 169, 187),
	ok = Color(100, 205, 130),
	danger = Color(235, 85, 75),
}

local activeFrame

local function readCompressed()
	local length = net.ReadUInt(32)
	if length <= 0 then return {} end
	local raw = net.ReadData(length)
	local json = raw and util.Decompress(raw)
	return json and util.JSONToTable(json) or {}
end

local function sendAction(action, primary, secondary)
	net.Start(NET_ACTION)
		net.WriteString(tostring(action or "refresh"))
		net.WriteString(tostring(primary or ""))
		net.WriteString(tostring(secondary or ""))
	net.SendToServer()
end

local function timeLabel(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	if seconds <= 0 then return "RETURNING NOW" end
	local hours = math.floor(seconds / 3600)
	local minutes = math.floor((seconds % 3600) / 60)
	local secs = seconds % 60
	if hours > 0 then return string.format("%02d:%02d:%02d", hours, minutes, secs) end
	return string.format("%02d:%02d", minutes, secs)
end

local function actionButton(parent, text, callback, colour)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.Paint = function(self, w, h)
		local enabled = self:IsEnabled()
		local accent = enabled and (colour or colours.accent) or Color(75, 84, 92)
		surface.SetDrawColor(5, 10, 17, 245)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(accent)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		if self:IsHovered() and enabled then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 35)
			surface.DrawRect(1, 1, w - 2, h - 2)
		end
		draw.SimpleText(text, "MB.FleetTiny", w / 2, h / 2,
			enabled and colours.text or colours.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = callback
	return button
end

local function addFormationOrders(scroll, snapshot)
	local selectedFormation = tostring(snapshot.formation or "close_escort")
	local selectedDescription = ""
	local panel = scroll:Add("DPanel")
	panel:Dock(TOP)
	panel:DockMargin(0, 0, 8, 12)
	panel:SetTall(148)
	panel.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(colours.accent)
		surface.DrawRect(0, 0, 4, h)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("FLEET FORMATION ORDERS", "MB.FleetHeading",
			18, 12, colours.text)
		draw.SimpleText("CURRENT: " .. string.upper(tostring(snapshot.formation or "close_escort"))
			.. "   /   RANGE " .. math.floor(tonumber(snapshot.formationRange) or 10)
			.. "% FROM FLAGSHIP", "MB.FleetTiny", 18, 42, colours.accent)
		draw.SimpleText(string.upper(selectedDescription), "MB.FleetTiny",
			18, 116, colours.dim)
	end

	local formation = vgui.Create("DComboBox", panel)
	formation:SetPos(18, 68)
	formation:SetSize(280, 34)
	formation:SetFont("MB.FleetTiny")
	for _, definition in ipairs(snapshot.formations or {}) do
		local selected = definition.id == selectedFormation
		formation:AddChoice(string.upper(definition.label or definition.id),
			definition.id, selected)
		if selected then selectedDescription = tostring(definition.description or "") end
	end
	formation.OnSelect = function(_, _, _, data)
		selectedFormation = tostring(data or selectedFormation)
		for _, definition in ipairs(snapshot.formations or {}) do
			if definition.id == selectedFormation then
				selectedDescription = tostring(definition.description or "")
				break
			end
		end
	end

	local range = vgui.Create("DNumSlider", panel)
	range:SetPos(315, 59)
	range:SetSize(390, 52)
	range:SetText("FORMATION RANGE")
	range:SetMinMax(tonumber(snapshot.formationMinimumRange) or 6,
		tonumber(snapshot.formationMaximumRange) or 72)
	range:SetDecimals(0)
	range:SetValue(tonumber(snapshot.formationRange) or 10)
	range:SetDark(false)
	if IsValid(range.Label) then range.Label:SetTextColor(colours.text) end
	if IsValid(range.TextArea) then range.TextArea:SetTextColor(colours.text) end

	local apply = actionButton(panel, "ISSUE ORDER", function()
		sendAction("formation", selectedFormation,
			tostring(math.Round(range:GetValue())))
	end, colours.accent)
	apply:SetPos(780, 68)
	apply:SetSize(176, 34)
	apply:SetEnabled(snapshot.canManage == true)
end

local function addAssetRow(scroll, snapshot, record)
	local row = scroll:Add("DPanel")
	row:Dock(TOP)
	row:DockMargin(0, 0, 8, 9)
	row:SetTall(158)
	row.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(colours.line)
		surface.DrawRect(0, 0, 4, h)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText(string.upper(record.name or "REPUBLIC VESSEL"),
			"MB.FleetHeading", 18, 12, colours.text)
		draw.SimpleText(string.upper(record.className or record.shipType or ""),
			"MB.FleetTiny", 18, 40, colours.line)
		local capability = {}
		if (tonumber(record.groundVehicleCapacity) or 0) > 0 then
			capability[#capability + 1] = "GROUND VEHICLE BERTHS +"
				.. math.floor(record.groundVehicleCapacity)
		end
		if (tonumber(record.fireSupportDamage) or 0) > 0 then
			capability[#capability + 1] = "FIRE-SUPPORT VOLLEY +"
				.. math.floor(record.fireSupportDamage)
		end
		if (tonumber(record.cargoCapacity) or 0) > 0 then
			capability[#capability + 1] = "CARGO +" .. math.floor(record.cargoCapacity)
		end
		capability[#capability + 1] = "SUPPLY RUNS " .. math.floor(tonumber(record.missions) or 0)
		capability[#capability + 1] = "RECOVERIES "
			.. math.floor(tonumber(record.salvageMissions) or 0)
		draw.SimpleText(table.concat(capability, "   /   "), "MB.FleetTiny",
			18, 123, colours.dim)
	end

	if record.status == "supply_mission" then
		local status = vgui.Create("DLabel", row)
		status:SetFont("MB.FleetText")
		status:SetTextColor(colours.accent)
		status:SetContentAlignment(6)
		status:SetPos(510, 34)
		status:SetSize(420, 70)
		status.Think = function(self)
			local remaining = (tonumber(record.missionEndsAt) or 0) - os.time()
			self:SetText("SUPPLY MISSION: " .. string.upper(record.destination or "REPUBLIC BASE")
				.. "\nESTIMATED RETURN " .. timeLabel(remaining))
		end
	elseif record.status == "salvage_mission" then
		local status = vgui.Create("DLabel", row)
		status:SetFont("MB.FleetText")
		status:SetTextColor(colours.accent)
		status:SetContentAlignment(6)
		status:SetPos(495, 30)
		status:SetSize(445, 82)
		status.Think = function(self)
			local endsAt = tonumber(record.missionEndsAt) or 0
			if endsAt > 0 then
				self:SetText("CUTTING WRECKAGE: "
					.. string.upper(record.salvageName or "UNKNOWN HULL")
					.. "\nRECOVERY COMPLETE IN "
					.. timeLabel(endsAt - os.time()))
			else
				self:SetText("SALVAGE ASSIGNMENT: "
					.. string.upper(record.salvageName or "UNKNOWN HULL")
					.. "\nMANOEUVRING TO RECOVERY POSITION")
			end
		end
	else
		local selectedDestination
		local destinations = vgui.Create("DComboBox", row)
		destinations:SetPos(510, 22)
		destinations:SetSize(270, 34)
		destinations:SetValue("SELECT REPUBLIC DESTINATION")
		destinations:SetFont("MB.FleetTiny")
		for _, destination in ipairs(snapshot.destinations or {}) do
			destinations:AddChoice(string.upper(destination.name), destination.key)
		end
		destinations.OnSelect = function(_, _, _, data) selectedDestination = data end

		local dispatch = actionButton(row, "SEND FOR SUPPLIES", function()
			if selectedDestination then
				sendAction("mission", record.id, selectedDestination)
			else
				notification.AddLegacy("Choose a Republic destination first.",
					NOTIFY_HINT, 4)
			end
		end, colours.line)
		dispatch:SetPos(792, 22)
		dispatch:SetSize(164, 34)
		dispatch:SetEnabled(snapshot.canManage == true)

		local selectedWreck
		local wrecks = vgui.Create("DComboBox", row)
		wrecks:SetPos(510, 66)
		wrecks:SetSize(270, 34)
		wrecks:SetValue(#(snapshot.wrecks or {}) > 0
			and "SELECT RECOVERABLE WRECK" or "NO WRECKAGE AVAILABLE")
		wrecks:SetFont("MB.FleetTiny")
		for _, wreck in ipairs(snapshot.wrecks or {}) do
			wrecks:AddChoice(string.upper(wreck.name)
				.. " / " .. string.Comma(wreck.scrap or 0) .. " SCRAP",
				wreck.entity)
		end
		wrecks.OnSelect = function(_, _, _, data) selectedWreck = data end

		local salvage = actionButton(row, "RECOVER WRECK", function()
			if selectedWreck then
				sendAction("salvage", record.id, tostring(selectedWreck))
			else
				notification.AddLegacy("Choose recoverable wreckage first.",
					NOTIFY_HINT, 4)
			end
		end, colours.accent)
		salvage:SetPos(792, 66)
		salvage:SetSize(164, 34)
		salvage:SetEnabled(snapshot.canManage == true
			and #(snapshot.wrecks or {}) > 0)
		local state = vgui.Create("DLabel", row)
		state:SetFont("MB.FleetTiny")
		state:SetTextColor(colours.ok)
		state:SetText("IN FORMATION / READY FOR ORDERS")
		state:SetPos(510, 108)
		state:SetSize(430, 18)
	end
end

local function addPurchaseRow(scroll, snapshot, definition)
	local row = scroll:Add("DPanel")
	row:Dock(TOP)
	row:DockMargin(0, 0, 8, 9)
	row:SetTall(125)
	row.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(colours.accent)
		surface.DrawRect(0, 0, 4, h)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText(string.upper(definition.label or definition.id),
			"MB.FleetHeading", 18, 12, colours.text)
		draw.SimpleText(string.upper(definition.description or ""),
			"MB.FleetTiny", 18, 44, colours.dim)
		local benefits = {}
		if (tonumber(definition.groundVehicleCapacity) or 0) > 0 then
			benefits[#benefits + 1] = "CARRIES " .. definition.groundVehicleCapacity
				.. " GROUND VEHICLES"
		end
		if (tonumber(definition.fireSupportDamage) or 0) > 0 then
			benefits[#benefits + 1] = "ADDS " .. definition.fireSupportDamage
				.. " DAMAGE TO LONG-RANGE VOLLEYS"
		end
		draw.SimpleText(table.concat(benefits, "   /   "), "MB.FleetTiny",
			18, 72, colours.line)
		draw.SimpleText(N.FormatCost(definition.cost or {}, true), "MB.FleetText",
			18, 98, colours.accent)
	end
	local buy = actionButton(row, "COMMISSION", function()
		sendAction("buy", definition.id, "")
	end, colours.accent)
	buy:SetPos(790, 76)
	buy:SetSize(166, 36)
	local atLimit = (tonumber(definition.owned) or 0)
		>= (tonumber(definition.maxOwned) or 99)
	buy:SetEnabled(snapshot.canManage == true and snapshot.canPurchaseHere == true and not atLimit)
	local availability = vgui.Create("DLabel", row)
	availability:SetFont("MB.FleetTiny")
	availability:SetTextColor(definition.modelAvailable and colours.ok or colours.accent)
	availability:SetContentAlignment(6)
	availability:SetPos(610, 20)
	availability:SetSize(346, 40)
	availability:SetText("OWNED " .. math.floor(tonumber(definition.owned) or 0)
		.. "/" .. math.floor(tonumber(definition.maxOwned) or 99)
		.. (definition.modelAvailable and "\nDEDICATED MODEL READY"
			or "\nREPUBLIC CAPITAL MODEL FALLBACK"))
end

local function addTierRow(scroll, snapshot, definition)
	local row = scroll:Add("DPanel")
	row:Dock(TOP)
	row:DockMargin(0, 0, 8, 8)
	row:SetTall(78)
	local unlocked = definition.enabled
		and (tonumber(definition.tier) or 1) <= (tonumber(snapshot.regimentalTier) or 1)
	local funding = tonumber(snapshot.resources and snapshot.resources.funding) or 0
	row.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(unlocked and colours.ok
			or definition.enabled and colours.accent or Color(90, 100, 110))
		surface.DrawRect(0, 0, 4, h)
		draw.SimpleText(definition.label or ("TIER " .. definition.tier),
			"MB.FleetHeading", 18, 13, colours.text)
		draw.SimpleText(definition.enabled
			and ("CAMPAIGN FUNDING REQUIRED: CR " .. string.Comma(definition.requiredFunding or 0))
			or "IN DEVELOPMENT / HIDDEN FROM PROGRESSION",
			"MB.FleetTiny", 18, 46, colours.dim)
		draw.SimpleText(unlocked and "UNLOCKED"
			or not definition.enabled and "NOT YET RELEASED"
			or ("CR " .. string.Comma(math.max(0,
				(tonumber(definition.requiredFunding) or 0) - funding)) .. " NEEDED"),
			"MB.FleetHeading", w - 20, h / 2,
			unlocked and colours.ok or colours.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end

local function addCargoSummary(scroll, snapshot)
	local market = snapshot.market or {}
	local panel = scroll:Add("DPanel")
	panel:Dock(TOP)
	panel:DockMargin(0, 0, 8, 12)
	panel:SetTall(102)
	panel.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(market.available and colours.line or colours.danger)
		surface.DrawRect(0, 0, 4, h)
		surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("FLAGSHIP CARGO HOLD", "MB.FleetHeading",
			18, 12, colours.text)
		draw.SimpleText(string.Comma(snapshot.cargoUsed or 0) .. " / "
			.. string.Comma(snapshot.cargoCapacity or 0) .. " CAPACITY USED",
			"MB.FleetText", 18, 44,
			(snapshot.cargoUsed or 0) >= (snapshot.cargoCapacity or 0)
				and colours.danger or colours.accent)
		draw.SimpleText(string.upper(market.name or "NO MARKET LINK"),
			"MB.FleetHeading", w - 20, 12,
			market.available and colours.line or colours.dim, TEXT_ALIGN_RIGHT)
		draw.SimpleText(string.upper(market.activity or ""),
			"MB.FleetTiny", w - 20, 46, colours.dim, TEXT_ALIGN_RIGHT)
		draw.SimpleText("PRICES RESPOND TO LOCAL SUPPLY / SALES ADD STOCK TO THIS MARKET",
			"MB.FleetTiny", 18, 76, colours.dim)
	end
end

local function addCommodityRow(scroll, snapshot, commodity)
	local market = snapshot.market or {}
	local row = scroll:Add("DPanel")
	row:Dock(TOP)
	row:DockMargin(0, 0, 8, 8)
	row:SetTall(94)
	row.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(colours.line)
		surface.DrawRect(0, 0, 4, h)
		draw.SimpleText(string.upper(commodity.label or commodity.key),
			"MB.FleetHeading", 18, 11, colours.text)
		draw.SimpleText(string.upper(commodity.manifest or ""),
			"MB.FleetTiny", 18, 39, colours.dim)
		draw.SimpleText("HOLD " .. string.Comma(commodity.held or 0)
			.. "   /   VOLUME " .. math.floor(tonumber(commodity.volume) or 1)
			.. " EACH   /   MARKET STOCK " .. string.Comma(commodity.stock or 0),
			"MB.FleetTiny", 18, 67, colours.line)
		draw.SimpleText(commodity.buyable == false and "SALVAGE ONLY"
			or ("BUY  CR " .. string.Comma(commodity.buyPrice or 0)),
			"MB.FleetTiny", 610, 15,
			commodity.buyable == false and colours.dim or colours.accent)
		draw.SimpleText("SELL  CR " .. string.Comma(commodity.sellPrice or 0),
			"MB.FleetTiny", 610, 43, colours.ok)
	end

	local quantity = vgui.Create("DNumberWang", row)
	quantity:SetPos(748, 16)
	quantity:SetSize(70, 30)
	quantity:SetMinMax(1, 100)
	quantity:SetDecimals(0)
	quantity:SetValue(1)
	quantity:SetFont("MB.FleetText")

	local buy = actionButton(row, "BUY", function()
		sendAction("trade_buy", commodity.key,
			tostring(math.max(1, math.Round(quantity:GetValue()))))
	end, colours.accent)
	buy:SetPos(830, 13)
	buy:SetSize(112, 34)
	buy:SetEnabled(snapshot.canManage == true and market.available == true
		and commodity.buyable ~= false and (tonumber(commodity.stock) or 0) > 0)

	local sell = actionButton(row, "SELL", function()
		sendAction("trade_sell", commodity.key,
			tostring(math.max(1, math.Round(quantity:GetValue()))))
	end, colours.ok)
	sell:SetPos(830, 52)
	sell:SetSize(112, 30)
	sell:SetEnabled(snapshot.canManage == true and market.available == true
		and (tonumber(commodity.held) or 0) > 0)
end

local function tabPanel(sheet, label)
	local panel = vgui.Create("DPanel", sheet)
	panel.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panel)
		surface.DrawRect(0, 0, w, h)
	end
	local sheetData = sheet:AddSheet(label, panel)
	local scroll = vgui.Create("DScrollPanel", panel)
	scroll:Dock(FILL)
	scroll:DockMargin(12, 12, 4, 12)
	return panel, scroll, sheetData
end

local function openFleet(snapshot)
	N.ClientFleetSnapshot = snapshot
	if IsValid(activeFrame) then activeFrame:Remove() end

	local width = math.min(1080, ScrW() - 50)
	local height = math.min(760, ScrH() - 50)
	local frame = vgui.Create("DFrame")
	activeFrame = frame
	frame:SetSize(width, height)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	frame.Paint = function(_, w, h)
		surface.SetDrawColor(colours.background)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(colours.accent)
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		surface.DrawRect(0, 0, w, 3)
		draw.SimpleText("REPUBLIC FLEET LOGISTICS", "MB.FleetTitle",
			22, 16, colours.text)
		draw.SimpleText("PERSISTENT SUPPORT FLEET / " .. string.upper(
			snapshot.currentPlanet or "DEEP SPACE"), "MB.FleetTiny",
			23, 52, colours.line)
	end

	local close = actionButton(frame, "X", function() frame:Remove() end, colours.danger)
	close:SetPos(width - 50, 14)
	close:SetSize(32, 30)
	local refresh = actionButton(frame, "REFRESH", function()
		sendAction("refresh", "", "")
	end, colours.line)
	refresh:SetPos(width - 150, 14)
	refresh:SetSize(92, 30)

	local resources = vgui.Create("DPanel", frame)
	resources:SetPos(20, 80)
	resources:SetSize(width - 40, 58)
	resources.Paint = function(_, w, h)
		surface.SetDrawColor(colours.panelAlt)
		surface.DrawRect(0, 0, w, h)
		local x = 16
		for _, key in ipairs(N.ResourceOrder or {}) do
			local value = math.floor(tonumber(snapshot.resources and snapshot.resources[key]) or 0)
			draw.SimpleText((N.ResourceLabels[key] or string.upper(key))
				.. "  " .. string.Comma(value), "MB.FleetTiny", x, 18,
				key == "funding" and colours.accent or colours.text)
			x = x + (key == "funding" and 175 or 142)
		end
		draw.SimpleText("VEHICLE BERTHS  " .. math.floor(
			tonumber(snapshot.groundVehicleCapacity) or 0), "MB.FleetTiny",
			w - 16, 39, colours.line, TEXT_ALIGN_RIGHT)
	end

	if snapshot.feedback and snapshot.feedback ~= "" then
		local feedback = vgui.Create("DLabel", frame)
		feedback:SetPos(22, 142)
		feedback:SetSize(width - 44, 30)
		feedback:SetFont("MB.FleetTiny")
		feedback:SetTextColor(snapshot.feedbackOK and colours.ok or colours.danger)
		feedback:SetText(string.upper(snapshot.feedback))
	end

	local sheet = vgui.Create("DPropertySheet", frame)
	sheet:SetPos(18, snapshot.feedback and 174 or 148)
	sheet:SetSize(width - 36, height - (snapshot.feedback and 192 or 166))

	local _, assets = tabPanel(sheet, "FLEET ASSETS")
	addFormationOrders(assets, snapshot)
	if #(snapshot.ships or {}) == 0 then
		local empty = assets:Add("DLabel")
		empty:Dock(TOP)
		empty:SetTall(90)
		empty:SetFont("MB.FleetHeading")
		empty:SetTextColor(colours.dim)
		empty:SetText("NO SUPPORT VESSELS COMMISSIONED\nTravel to a Republic shipyard and use the Commission Ships tab.")
	else
		for _, record in ipairs(snapshot.ships) do addAssetRow(assets, snapshot, record) end
	end

	local _, cargo, cargoSheet = tabPanel(sheet, "CARGO & TRADE")
	addCargoSummary(cargo, snapshot)
	for _, commodity in ipairs(snapshot.market and snapshot.market.commodities or {}) do
		addCommodityRow(cargo, snapshot, commodity)
	end

	local _, purchase = tabPanel(sheet, "COMMISSION SHIPS")
	local shipyardNotice = purchase:Add("DLabel")
	shipyardNotice:Dock(TOP)
	shipyardNotice:DockMargin(0, 0, 8, 10)
	shipyardNotice:SetTall(42)
	shipyardNotice:SetFont("MB.FleetText")
	shipyardNotice:SetTextColor(snapshot.canPurchaseHere and colours.ok or colours.accent)
	shipyardNotice:SetText(snapshot.canPurchaseHere
		and "SHIPYARD LINK ESTABLISHED — NEW VESSELS MAY BE COMMISSIONED HERE."
		or "NO SHIPYARD LINK — TRAVEL TO KUAT, CORUSCANT, KAMINO OR ANOTHER REPUBLIC SHIPYARD.")
	for _, definition in ipairs(snapshot.definitions or {}) do
		addPurchaseRow(purchase, snapshot, definition)
	end

	local _, tiers = tabPanel(sheet, "REGIMENTAL FUNDING")
	local tierIntro = tiers:Add("DLabel")
	tierIntro:Dock(TOP)
	tierIntro:DockMargin(0, 0, 8, 10)
	tierIntro:SetTall(58)
	tierIntro:SetFont("MB.FleetText")
	tierIntro:SetTextColor(colours.dim)
	tierIntro:SetWrap(true)
	tierIntro:SetText("Skill tiers unlock permanently when total campaign funding first reaches each target. Spending funds afterwards does not remove an unlocked tier, allowing future tiers to be prepared behind the scenes.")
	for _, definition in ipairs(snapshot.regimentalTiers or {}) do
		addTierRow(tiers, snapshot, definition)
	end
	if snapshot.selectedTab == "cargo" and cargoSheet and IsValid(cargoSheet.Tab) then
		sheet:SetActiveTab(cargoSheet.Tab)
	end
end

net.Receive(NET_OPEN, function()
	openFleet(readCompressed())
end)
