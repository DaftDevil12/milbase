--[[
	LVS vehicle hacking (slicing).

	A player carrying a Slicer Kit (item type "hack") can crouch + hold E
	on an ALLOWED, unoccupied LVS vehicle to open a slice minigame (the
	shared "type the code" game). On success the vehicle's AI is enabled
	and it's flipped to the slicer's team - a captured gunship that now
	fights for you.

	Configure which vehicles can be hacked in config/sh_config.lua
	(cfg.HackableVehicleClasses / cfg.HackAllVehicles). Requires lvs_base.
]]

local cfg = MilBase.Config

local function isHackable(veh)
	if not (IsValid(veh) and veh.LVS) then return false end
	if cfg.HackAllVehicles then return true end
	return cfg.HackableVehicleClasses and cfg.HackableVehicleClasses[veh:GetClass()] or false
end

function MilBase.InventoryHasSlicerKit(inv)
	if not inv then return false end
	local pools = { inv.items or {} }
	if inv.pack then pools[#pools + 1] = inv.pack.items or {} end
	for _, pool in ipairs(pools) do
		for _, it in ipairs(pool or {}) do
			local def = MilBase.Items[it.id]
			if def and def.type == "hack" then return true end
		end
	end
	return false
end

function MilBase.PlayerHasSlicerKit(ply)
	if not (IsValid(ply) and ply:IsPlayer()) then return false end
	return MilBase.InventoryHasSlicerKit(MilBase.GetInventory(ply))
end

local function hasHackTool_inv(inv)
	return MilBase.InventoryHasSlicerKit(inv)
end

--------------------------------------------------------------------------
-- The hold-G self-menu action (client opens the minigame on the aimed vehicle)
--------------------------------------------------------------------------

MilBase.RegisterSelfAction("veh_hack", {
	name = "Hack Vehicle",
	order = 43,
	visible = function(lp) -- CLIENT
		local veh = MilBase.ServiceableLVS and MilBase.ServiceableLVS(lp)
		if not IsValid(veh) or not isHackable(veh) then return false end
		if IsValid(veh.GetDriver and veh:GetDriver()) then return false end
		return MilBase.HasHackTool and MilBase.HasHackTool()
	end,
	client = function(lp)
		local veh = MilBase.ServiceableLVS and MilBase.ServiceableLVS(lp)
		if IsValid(veh) and MilBase.OpenHackGame then MilBase.OpenHackGame(veh) end
	end,
})

--------------------------------------------------------------------------
-- Client
--------------------------------------------------------------------------

if CLIENT then

	function MilBase.HasHackTool()
		return hasHackTool_inv(MilBase.LocalInv)
	end

	function MilBase.OpenHackGame(veh)
		if not IsValid(veh) then return end

		MilBase.OpenCodeMinigame({
			title = "SLICING — " .. string.upper(veh.PrintName or "VEHICLE"),
			subtitle = "Break the flight computer's encryption to seize control.",
			color = Color(120, 200, 140),
			lines = MilBase.GenCodeLines(6),
			valid = function()
				return IsValid(veh)
					and veh:GetPos():DistToSqr(LocalPlayer():GetPos()) < 240 * 240
			end,
			onSuccess = function()
				net.Start("MilBase_HackVehicle")
					net.WriteEntity(veh)
				net.SendToServer()
			end,
		})
	end

	return
end

--------------------------------------------------------------------------
-- Server: apply the hack
--------------------------------------------------------------------------

util.AddNetworkString("MilBase_HackVehicle")

net.Receive("MilBase_HackVehicle", function(_, ply)
	local veh = net.ReadEntity()
	if not ply:Alive() or not isHackable(veh) then return end
	if veh:NearestPoint(ply:GetPos()):DistToSqr(ply:GetPos()) > 240 * 240 then return end
	if IsValid(veh.GetDriver and veh:GetDriver()) then
		MilBase.Notify(ply, "You can't slice an occupied vehicle.")
		return
	end
	if not hasHackTool_inv(MilBase.GetInventory(ply)) then
		MilBase.Notify(ply, "You need a Slicer Kit.")
		return
	end
	if (ply.mb_nextHack or 0) > CurTime() then
		MilBase.Notify(ply, "Your slicer is still cooling down.")
		return
	end
	ply.mb_nextHack = CurTime() + (cfg.HackCooldown or 20)

	-- Flip it to the slicer's team and switch its AI on.
	local team = (ply.lvsGetAITeam and ply:lvsGetAITeam()) or 0
	if team == 0 then team = cfg.HackedVehicleTeam or 1 end

	if veh.SetAITEAM then veh:SetAITEAM(team) end
	if veh.SetAI then veh:SetAI(true) end
	veh.mb_hackedBy = ply

	veh:EmitSound("ambient/levels/labs/electric_explosion" .. math.random(1, 5) .. ".wav", 75)

	MilBase.ChatMsg(nil, Color(120, 200, 140), "[SLICER] ", color_white,
		ply:MBName() .. " has commandeered a " .. (veh.PrintName or "vehicle") .. "!")
	MilBase.Notify(ply, "Vehicle commandeered — it now fights for your side.")
end)
