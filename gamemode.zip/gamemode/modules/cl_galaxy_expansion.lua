-- Galaxy Director living-universe operation and ship-condition HUD.

if not CLIENT or MilBase._GalaxyExpansionClientLoaded then return end
MilBase._GalaxyExpansionClientLoaded = true
if (MilBase.Config.GalaxyDirector or {}).LivingUniverseExpansion == false then return end

local G = MilBase.Galaxy
local phenomenonMaterial = Material("sprites/light_glow02_add")

hook.Add("PostDrawTranslucentRenderables", "MilBase.GalaxyPhenomena", function()
	render.SetMaterial(phenomenonMaterial)
	local now = CurTime()
	for _, ent in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		local kind = ent:GetNWString("mb_galaxy_phenomenon", "")
		if kind ~= "" and IsValid(ent) then
			local pulse = 0.7 + math.sin(now * (kind == "beacon" and 3.4 or 2.1)
				+ ent:EntIndex()) * 0.3
			local color = kind == "beacon" and Color(80, 165, 255, 210)
				or kind == "anomaly" and Color(185, 90, 255, 195)
				or Color(235, 175, 70, 165)
			local size = kind == "beacon" and 105 or kind == "anomaly" and 150 or 80
			render.DrawSprite(ent:WorldSpaceCenter(), size * pulse, size * pulse,
				Color(color.r, color.g, color.b, color.a * pulse))
		end
	end
end)

local function panel(x, y, width, height, accent)
	MilBase.DrawPanelBF2(x, y, width, height, {
		cut = 8,
		color = Color(5, 11, 18, 226),
		accent = accent,
	})
end

hook.Add("HUDPaint", "MilBase.GalaxyExpansionHUD", function()
	if MilBase.Naval and MilBase.Naval.IsNavy
	and not MilBase.Naval.IsNavy(LocalPlayer()) then return end
	local state = G.ClientState or {}
	local operation = state.operation
	local systems = state.shipSystems or {}
	local ui = MilBase.UI
	if not ui then return end

	if operation then
		local width = math.min(510, ScrW() * 0.4)
		local height = 88
		local x = 22
		local y = 62
		local accent = operation.kind == "counter_board" and ui.danger
			or operation.kind == "blockade" and ui.warn or ui.accent
		panel(x, y, width, height, accent)
		draw.SimpleText(operation.title or "FLEET OPERATION", "MB.Med",
			x + 14, y + 9, ui.text)
		local remain = math.max(0, (tonumber(operation.endsAt) or CurTime()) - CurTime())
		draw.SimpleText(G.FormatDuration(remain), "MB.Tiny",
			x + width - 14, y + 16, accent, TEXT_ALIGN_RIGHT)
		draw.SimpleText(string.sub(tostring(operation.body or ""), 1, 105), "MB.Tiny",
			x + 14, y + 39, ui.dim)
		local goal = math.max(1, tonumber(operation.goal) or 1)
		local progress = math.Clamp(tonumber(operation.progress) or 0, 0, goal)
		surface.SetDrawColor(255, 255, 255, 18)
		surface.DrawRect(x + 14, y + height - 14, width - 28, 5)
		surface.SetDrawColor(accent)
		surface.DrawRect(x + 14, y + height - 14,
			(width - 28) * progress / goal, 5)
		if operation.mapSpace and tonumber(operation.targetEntity) and operation.targetEntity > 0 then
			local convoy = Entity(operation.targetEntity)
			if IsValid(convoy) then
				local screen = convoy:WorldSpaceCenter():ToScreen()
				if screen.visible then
					draw.SimpleText("ESCORT CONVOY", "MB.Tiny", screen.x, screen.y - 18,
						ui.accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
			end
		end
	end

	local damaged = {}
	for _, id in ipairs({
		"sensors", "communications", "weapons", "engines",
		"maneuver", "hyperdrive", "shields", "hangar",
	}) do
		local value = tonumber(systems[id])
		if value and value < 75 then damaged[#damaged + 1] = { id = id, value = value } end
	end
	if #damaged == 0 then return end

	local width = 270
	local rowHeight = 19
	local height = 35 + #damaged * rowHeight
	local x = 22
	local y = ScrH() - height - 150
	panel(x, y, width, height, ui.warn)
	draw.SimpleText("SHIP DAMAGE CONTROL", "MB.Small", x + 12, y + 9, ui.text)
	for index, system in ipairs(damaged) do
		local rowY = y + 31 + (index - 1) * rowHeight
		local color = system.value < 25 and ui.danger or ui.warn
		draw.SimpleText(string.upper(system.id), "MB.Tiny", x + 12, rowY, ui.dim)
		draw.SimpleText(math.floor(system.value) .. "%", "MB.Tiny",
			x + width - 12, rowY, color, TEXT_ALIGN_RIGHT)
		surface.SetDrawColor(255, 255, 255, 15)
		surface.DrawRect(x + 105, rowY + 4, width - 155, 4)
		surface.SetDrawColor(color)
		surface.DrawRect(x + 105, rowY + 4,
			(width - 155) * math.Clamp(system.value / 100, 0, 1), 4)
	end
end)
