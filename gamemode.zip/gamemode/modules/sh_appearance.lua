--[[
	Appearance: a bodygroup + skin editor in the F4 menu.

	Every player customises their current model in the APPEARANCE tab. Staff
	lock individual bodygroups behind a rank or equipment IN-GAME via the
	MODEL RULES tab (no config). Choices persist per player+model and are
	re-applied (unlock-checked) by MilBase.ApplyEquipment, which then lets
	equipped armor override its own bodygroups (armor wins its slots).
]]

local cfg = MilBase.Config

-- Unlock rules, keyed by lower-case model then bodygroup index.
--   { type = "open" | "rank" | "item", rank = N, slot = "backpack" }
MilBase.BGRules = MilBase.BGRules or {}

-- Gear slots a bodygroup can be tied to (matches cl_inventory GEAR_SLOTS).
local RULE_SLOTS = { "backpack", "head", "armor", "holster" }

-- Shared: may `ply` change bodygroup `idx` on `model`?
function MilBase.BodygroupUnlocked(ply, model, idx)
	model = string.lower(model)
	local r = MilBase.BGRules[model] and MilBase.BGRules[model][idx]
	if not r or r.type == "open" then return true end

	if r.type == "rank" then
		return ply:GetNWInt("mb_rank", 1) >= (r.rank or 1)
	elseif r.type == "item" then
		local inv = CLIENT and MilBase.LocalInv or (SERVER and MilBase.GetInventory(ply))
		return (inv and inv.equip and inv.equip[r.slot or "backpack"] ~= nil) or false
	end
	return true
end

-- Requirement label for a locked bodygroup (nil if open).
function MilBase.BGRuleText(model, idx)
	model = string.lower(model)
	local r = MilBase.BGRules[model] and MilBase.BGRules[model][idx]
	if not r or r.type == "open" then return nil end
	if r.type == "rank" then return "Requires Rank " .. (r.rank or 1) .. "+" end
	if r.type == "item" then return "Requires " .. string.upper(r.slot or "backpack") end
	return nil
end

--------------------------------------------------------------------------
-- Server: persistence, apply, net
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_BGRules")
	util.AddNetworkString("MilBase_SetBodygroup")
	util.AddNetworkString("MilBase_SetSkin")
	util.AddNetworkString("MilBase_SetBGRule")

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_appearance (
		steamid VARCHAR(32), model VARCHAR(160), skin INTEGER, bg TEXT,
		PRIMARY KEY (steamid, model)
	)]])
	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_bg_rules (
		model VARCHAR(160), idx INTEGER, rule TEXT,
		PRIMARY KEY (model, idx)
	)]])

	local function loadRules()
		MilBase.DB.Query("SELECT * FROM frontier_bg_rules", function(rows)
			MilBase.BGRules = {}
			for _, row in ipairs(rows) do
				local m = string.lower(row.model)
				MilBase.BGRules[m] = MilBase.BGRules[m] or {}
				MilBase.BGRules[m][tonumber(row.idx)] = util.JSONToTable(row.rule) or { type = "open" }
			end
		end)
	end
	MilBase.BGRules = MilBase.BGRules or {}
	loadRules()

	local function syncRules(target)
		net.Start("MilBase_BGRules")
			net.WriteString(util.TableToJSON(MilBase.BGRules))
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	function MilBase.LoadAppearance(ply)
		local key = ply:MBCharacterSteamIDKey()
		local token = ply:MBCharacterLoadToken()
		ply.mb_appearance = {}
		MilBase.DB.Query(string.format(
			"SELECT * FROM frontier_appearance WHERE steamid = %s",
			MilBase.SQLStr(key)), function(rows)
			if not IsValid(ply) or ply:MBCharacterSteamIDKey() ~= key or ply:MBCharacterLoadToken() ~= token then return end
			ply.mb_appearance = {}
			for _, row in ipairs(rows) do
				ply.mb_appearance[string.lower(row.model)] = {
					skin = tonumber(row.skin) or 0,
					bg = util.JSONToTable(row.bg) or {},
				}
			end
		end)
	end

	hook.Add("PlayerInitialSpawn", "MilBase.AppearanceLoad", function(ply)
		MilBase.LoadAppearance(ply)
		timer.Simple(3, function() if IsValid(ply) then syncRules(ply) end end)
	end)

	-- Applies stored bodygroups/skin for the player's current model. Called
	-- from ApplyEquipment after the bodygroup reset, before armor overrides.
	function MilBase.ApplyAppearance(ply)
		if cfg.AppearanceEnabled == false then return end
		local model = string.lower(ply:GetModel())
		local a = ply.mb_appearance and ply.mb_appearance[model]
		if not a then return end

		for i, v in pairs(a.bg or {}) do
			i = tonumber(i)
			if i and MilBase.BodygroupUnlocked(ply, model, i) then
				ply:SetBodygroup(i, tonumber(v) or 0)
			end
		end
		ply:SetSkin(a.skin or 0)
	end

	local function entry(ply, model)
		ply.mb_appearance = ply.mb_appearance or {}
		ply.mb_appearance[model] = ply.mb_appearance[model] or { skin = 0, bg = {} }
		return ply.mb_appearance[model]
	end

	local function saveAppearance(ply, model)
		local a = ply.mb_appearance and ply.mb_appearance[model]
		if not a then return end
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_appearance (steamid, model, skin, bg) VALUES (%s, %s, %d, %s)",
			MilBase.SQLStr(ply:MBCharacterSteamIDKey()), MilBase.SQLStr(model), a.skin or 0,
			MilBase.SQLStr(util.TableToJSON(a.bg or {}))))
	end

	net.Receive("MilBase_SetBodygroup", function(_, ply)
		if cfg.AppearanceEnabled == false or not ply:Alive() then return end
		local idx, val = net.ReadUInt(8), net.ReadUInt(8)
		if idx >= ply:GetNumBodyGroups() or val >= ply:GetBodygroupCount(idx) then return end

		local model = string.lower(ply:GetModel())
		if not MilBase.BodygroupUnlocked(ply, model, idx) then return end

		local a = entry(ply, model)
		a.bg[tostring(idx)] = val
		ply:SetBodygroup(idx, val)
		saveAppearance(ply, model)
	end)

	net.Receive("MilBase_SetSkin", function(_, ply)
		if cfg.AppearanceEnabled == false or not ply:Alive() then return end
		local val = net.ReadUInt(8)
		if val >= ply:SkinCount() then return end

		local model = string.lower(ply:GetModel())
		local a = entry(ply, model)
		a.skin = val
		ply:SetSkin(val)
		saveAppearance(ply, model)
	end)

	net.Receive("MilBase_SetBGRule", function(_, ply)
		if not (ply:IsAdmin() or ply:IsSuperAdmin()) then return end
		local model = string.lower(net.ReadString())
		local idx = net.ReadUInt(8)
		local raw = util.JSONToTable(net.ReadString()) or {}

		local t = raw.type
		local clean = { type = (t == "rank" or t == "item") and t or "open" }
		if clean.type == "rank" then clean.rank = math.Clamp(tonumber(raw.rank) or 2, 1, 50) end
		if clean.type == "item" then clean.slot = tostring(raw.slot or "backpack") end

		MilBase.BGRules[model] = MilBase.BGRules[model] or {}
		if clean.type == "open" then
			MilBase.BGRules[model][idx] = nil
			MilBase.DB.Run(string.format("DELETE FROM frontier_bg_rules WHERE model = %s AND idx = %d",
				MilBase.SQLStr(model), idx))
		else
			MilBase.BGRules[model][idx] = clean
			MilBase.DB.Run(string.format(
				"REPLACE INTO frontier_bg_rules (model, idx, rule) VALUES (%s, %d, %s)",
				MilBase.SQLStr(model), idx, MilBase.SQLStr(util.TableToJSON(clean))))
		end
		syncRules()
	end)

	return
end

--------------------------------------------------------------------------
-- Client: sync + the two F4 tabs
--------------------------------------------------------------------------

net.Receive("MilBase_BGRules", function()
	local raw = util.JSONToTable(net.ReadString()) or {}
	local out = {}
	for model, rules in pairs(raw) do
		out[model] = {}
		for k, v in pairs(rules) do out[model][tonumber(k) or k] = v end -- JSON keys -> numbers
	end
	MilBase.BGRules = out
end)

local function stepBtn(parent, label, onClick)
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(self, w, h)
		local ui = MilBase.UI
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 5,
			color = self:IsHovered() and ui.hover or ui.raised })
		draw.SimpleText(label, "MB.Med", w / 2, h / 2 - 1, ui.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

-- Character preview docked left, mirroring the local player's model.
local function previewModel(content)
	local lp = LocalPlayer()
	local mdl = vgui.Create("DModelPanel", content)
	mdl:Dock(LEFT)
	mdl:SetWide(320)
	mdl:DockMargin(0, 0, 14, 0)
	mdl:SetModel(lp:GetModel())
	mdl:SetFOV(40)
	mdl:SetCamPos(Vector(70, 0, 40))
	mdl:SetLookAt(Vector(0, 0, 38))
	function mdl:LayoutEntity(ent) ent:SetAngles(Angle(0, 0, 0)) end

	local ent = mdl.Entity
	if IsValid(ent) then
		ent:SetSkin(lp:GetSkin())
		for i = 0, ent:GetNumBodyGroups() - 1 do ent:SetBodygroup(i, lp:GetBodygroup(i)) end
	end
	return mdl, ent
end

--------------------------------------------------------------------------
-- APPEARANCE tab (all players)
--------------------------------------------------------------------------

MilBase.AddMenuTab("APPEARANCE", 15, function(content)
	if MilBase.Config.AppearanceEnabled == false then return end

	local ui = MilBase.UI
	local lp = LocalPlayer()
	local model = string.lower(lp:GetModel())
	local mdl, ent = previewModel(content)
	if not IsValid(ent) then return end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local hint = vgui.Create("DLabel", scroll)
	hint:Dock(TOP)
	hint:SetFont("MB.Tiny")
	hint:SetText("Customise your appearance. Locked parts need a rank or equipment.")
	hint:SetTextColor(ui.dim)
	hint:DockMargin(2, 0, 0, 8)
	hint:SizeToContents()

	local function valueRow(label, getMax, getVal, apply, unlocked, reqText)
		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(44)
		row:DockMargin(0, 0, 8, 6)
		row.Paint = function(self, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText(label, "MB.Small", 14, 9, unlocked and ui.text or ui.faint)
			if unlocked then
				draw.SimpleText(getVal() .. "  /  " .. math.max(getMax() - 1, 0), "MB.Tiny", 14, 27, ui.dim)
			else
				draw.SimpleText(reqText or "Locked", "MB.Tiny", 14, 27, ui.warn)
			end
		end

		if unlocked then
			local function change(d)
				local mx = getMax()
				if mx <= 1 then return end
				apply((getVal() + d) % mx)
			end
			local l = stepBtn(row, "<", function() change(-1) end)
			local r = stepBtn(row, ">", function() change(1) end)
			row.PerformLayout = function(self, w, h)
				r:SetSize(40, h - 12); r:SetPos(w - 48, 6)
				l:SetSize(40, h - 12); l:SetPos(w - 92, 6)
			end
		end
	end

	for i = 0, ent:GetNumBodyGroups() - 1 do
		if ent:GetBodygroupCount(i) > 1 then
			local idx = i
			local name = ent:GetBodygroupName(idx)
			valueRow(
				string.upper(name ~= "" and name or ("bodygroup " .. idx)),
				function() return ent:GetBodygroupCount(idx) end,
				function() return ent:GetBodygroup(idx) end,
				function(v)
					ent:SetBodygroup(idx, v)
					net.Start("MilBase_SetBodygroup")
						net.WriteUInt(idx, 8)
						net.WriteUInt(v, 8)
					net.SendToServer()
				end,
				MilBase.BodygroupUnlocked(lp, model, idx),
				MilBase.BGRuleText(model, idx))
		end
	end

	if ent:SkinCount() > 1 then
		valueRow("SKIN",
			function() return ent:SkinCount() end,
			function() return ent:GetSkin() end,
			function(v)
				ent:SetSkin(v)
				net.Start("MilBase_SetSkin")
					net.WriteUInt(v, 8)
				net.SendToServer()
			end,
			true, nil)
	end
end)

--------------------------------------------------------------------------
-- MODEL RULES tab (staff only)
--------------------------------------------------------------------------

MilBase.AddMenuTab("MODEL RULES", 92, function(content)
	local ui = MilBase.UI
	local lp = LocalPlayer()
	local model = string.lower(lp:GetModel())
	local mdl, ent = previewModel(content)
	if not IsValid(ent) then return end

	local scroll = vgui.Create("DScrollPanel", content)
	scroll:Dock(FILL)

	local hint = vgui.Create("DLabel", scroll)
	hint:Dock(TOP)
	hint:SetFont("MB.Tiny")
	hint:SetText("Lock bodygroups for THIS model. MODE cycles Open / Rank / Item; +/- sets the value.")
	hint:SetTextColor(ui.dim)
	hint:DockMargin(2, 0, 0, 8)
	hint:SizeToContents()

	local function ruleRow(name, idx)
		local base = MilBase.BGRules[model] and MilBase.BGRules[model][idx]
		local rule = base and table.Copy(base) or { type = "open" }

		local row = vgui.Create("DPanel", scroll)
		row:Dock(TOP)
		row:SetTall(48)
		row:DockMargin(0, 0, 8, 6)

		local function send()
			net.Start("MilBase_SetBGRule")
				net.WriteString(model)
				net.WriteUInt(idx, 8)
				net.WriteString(util.TableToJSON(rule))
			net.SendToServer()
		end

		row.Paint = function(self, w, h)
			MilBase.PaintPanel(w, h)
			draw.SimpleText(string.upper(name ~= "" and name or ("bodygroup " .. idx)),
				"MB.Small", 14, 8, ui.text)
			local txt = rule.type == "open" and "Anyone"
				or rule.type == "rank" and ("Rank " .. (rule.rank or 2) .. "+")
				or ("Needs " .. string.upper(rule.slot or "backpack"))
			draw.SimpleText(txt, "MB.Tiny", 14, 28, rule.type == "open" and ui.ok or ui.warn)
		end

		local mode = stepBtn(row, "MODE", function()
			rule.type = (rule.type == "open" and "rank")
				or (rule.type == "rank" and "item") or "open"
			if rule.type == "rank" then rule.rank = rule.rank or 2 end
			if rule.type == "item" then rule.slot = rule.slot or "backpack" end
			send()
		end)
		local dec = stepBtn(row, "-", function()
			if rule.type == "rank" then
				rule.rank = math.max(1, (rule.rank or 2) - 1); send()
			elseif rule.type == "item" then
				local k = (table.KeyFromValue(RULE_SLOTS, rule.slot) or 1) - 1
				if k < 1 then k = #RULE_SLOTS end
				rule.slot = RULE_SLOTS[k]; send()
			end
		end)
		local inc = stepBtn(row, "+", function()
			if rule.type == "rank" then
				rule.rank = math.min(50, (rule.rank or 2) + 1); send()
			elseif rule.type == "item" then
				rule.slot = RULE_SLOTS[(table.KeyFromValue(RULE_SLOTS, rule.slot) or 1) % #RULE_SLOTS + 1]
				send()
			end
		end)

		row.PerformLayout = function(self, w, h)
			mode:SetSize(70, h - 14); mode:SetPos(w - 78, 7)
			inc:SetSize(34, h - 14); inc:SetPos(w - 118, 7)
			dec:SetSize(34, h - 14); dec:SetPos(w - 156, 7)
		end
	end

	for i = 0, ent:GetNumBodyGroups() - 1 do
		if ent:GetBodygroupCount(i) > 1 then
			ruleRow(ent:GetBodygroupName(i), i)
		end
	end
end, function(lp) return lp:IsAdmin() or lp:IsSuperAdmin() end)
