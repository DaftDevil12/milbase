if MilBase.FleetLogisticsSharedLoaded then return end
MilBase.FleetLogisticsSharedLoaded = true

MilBase.Naval = MilBase.Naval or {}
local N = MilBase.Naval
local naval = MilBase.Config.NavalOperations or {}

function N.FleetDefinition(shipType)
	return (naval.FleetShipDefinitions or {})[N.CleanKey(shipType)]
end

function N.RegimentalTierDefinition(tier)
	return (naval.RegimentalSkillTiers or {})[math.max(1, math.floor(tonumber(tier) or 1))]
end

function N.RegimentalSkillTierRequirement(tier)
	local definition = N.RegimentalTierDefinition(tier)
	return definition and math.max(0, math.floor(tonumber(definition.requiredFunding) or 0)) or nil
end

function N.RegimentalUnlockedTier()
	if SERVER and N.FleetState then
		return math.max(1, math.floor(tonumber(N.FleetState.regimentalTier) or 1))
	end
	local snapshot = N.ClientFleetSnapshot or {}
	return math.max(1, math.floor(tonumber(snapshot.regimentalTier) or 1))
end

function N.IsRegimentalSkillTierAvailable(tier)
	tier = math.max(1, math.floor(tonumber(tier) or 1))
	local definition = N.RegimentalTierDefinition(tier)
	return definition ~= nil and definition.enabled ~= false
		and tier <= N.RegimentalUnlockedTier()
end

function MilBase.CanUseRegimentalSkillTier(subject, tier)
	if tier == nil then tier = subject end
	return N.IsRegimentalSkillTierAvailable(tier)
end

function N.FleetVehicleCapacity()
	if not SERVER or not N.FleetState then
		return math.max(0, math.floor(tonumber(
			N.ClientFleetSnapshot and N.ClientFleetSnapshot.groundVehicleCapacity) or 0))
	end
	local total = 0
	for _, record in pairs(N.FleetState.ships or {}) do
		if record.status == "following" then
			local definition = N.FleetDefinition(record.shipType)
			total = total + math.max(0,
				math.floor(tonumber(definition and definition.groundVehicleCapacity) or 0))
		end
	end
	return total
end

function N.TradeCommodity(key)
	return (naval.TradeCommodities or {})[N.CleanKey(key)]
end

function N.CargoUsed(cargo)
	cargo = cargo or (SERVER and N.FleetState and N.FleetState.cargoHold)
		or (N.ClientFleetSnapshot and N.ClientFleetSnapshot.cargoHold) or {}
	local used = 0
	for key, amount in pairs(cargo or {}) do
		local definition = N.TradeCommodity(key)
		used = used + math.max(0, math.floor(tonumber(amount) or 0))
			* math.max(1, math.floor(tonumber(definition and definition.volume) or 1))
	end
	return used
end

function N.FleetCargoCapacity()
	if not SERVER or not N.FleetState then
		return math.max(0, math.floor(tonumber(
			N.ClientFleetSnapshot and N.ClientFleetSnapshot.cargoCapacity) or 0))
	end
	local total = math.max(0, math.floor(
		tonumber(naval.FleetBaseCargoCapacity) or 420))
	for _, record in pairs(N.FleetState.ships or {}) do
		local definition = N.FleetDefinition(record.shipType)
		total = total + math.max(0,
			math.floor(tonumber(definition and definition.cargoCapacity) or 0))
	end
	return total
end
