if not SERVER or MilBase.FleetLogisticsServerLoaded then return end
MilBase.FleetLogisticsServerLoaded = true

local naval = MilBase.Config.NavalOperations or {}
if naval.Enabled == false or naval.FleetEnabled == false then return end

local N = MilBase.Naval
local G = MilBase.Galaxy
local TABLE_NAME = "frontier_naval_fleet"
local CAMPAIGN_KEY = "republic_support_fleet"
local NET_OPEN = "MilBase_Naval_FleetOpen"
local NET_ACTION = "MilBase_Naval_FleetAction"

util.AddNetworkString(NET_OPEN)
util.AddNetworkString(NET_ACTION)

N.FleetState = N.FleetState or {
	ships = {},
	nextID = 1,
	planetRequests = {},
	cargoHold = {},
	regimentalTier = 1,
	formationLayoutVersion = tonumber(naval.FleetFormationLayoutVersion) or 3,
	formation = naval.FleetDefaultFormation or "close_escort",
	formationRange = naval.FleetDefaultFormationRange or 24,
	revision = 1,
}
N.FleetEntities = N.FleetEntities or {}
N.FleetRegistryReady = false

local fleetLoaded = false
local dirtyAt

local function actorName(actor)
	if not IsValid(actor) then return isstring(actor) and actor or "SHIP COMPUTER" end
	return actor.MBName and actor:MBName() or actor:Nick()
end

local function configuredPlanet(set, key)
	key = G.PlanetKey(key)
	for configuredKey, value in pairs(set or {}) do
		if isstring(configuredKey) and value == true
		and G.PlanetKey(configuredKey) == key then return true end
		if isstring(value) and G.PlanetKey(value) == key then return true end
	end
	return false
end

local function formationDefinition(formation)
	return (naval.FleetFormations or {})[N.CleanKey(formation)]
end

local function cleanFormation(formation)
	formation = N.CleanKey(formation)
	if formationDefinition(formation) then return formation end
	local fallback = N.CleanKey(naval.FleetDefaultFormation or "close_escort")
	return formationDefinition(fallback) and fallback or "close_escort"
end

local function cleanFormationRange(value)
	local minimum = math.max(5, tonumber(naval.FleetFormationMinimumRange) or 18)
	local maximum = math.max(minimum,
		tonumber(naval.FleetFormationMaximumRange) or 72)
	return math.Clamp(math.floor(tonumber(value)
		or tonumber(naval.FleetDefaultFormationRange) or 24), minimum, maximum)
end

local function normalizeRecord(record, fallbackID)
	if not istable(record) then return nil end
	local shipType = N.CleanKey(record.shipType or record.type)
	if not N.FleetDefinition(shipType) then return nil end
	local id = N.CleanKey(record.id or fallbackID)
	if id == "" then return nil end
	local status = record.status == "supply_mission" and "supply_mission" or "following"
	return {
		id = id,
		shipType = shipType,
		name = string.sub(string.Trim(tostring(record.name or "")), 1, 96),
		status = status,
		destinationKey = status == "supply_mission"
			and G.PlanetKey(record.destinationKey or "") or "",
		missionStartedAt = status == "supply_mission"
			and math.max(0, math.floor(tonumber(record.missionStartedAt) or 0)) or 0,
		missionEndsAt = status == "supply_mission"
			and math.max(0, math.floor(tonumber(record.missionEndsAt) or 0)) or 0,
		missions = math.max(0, math.floor(tonumber(record.missions) or 0)),
		salvageMissions = math.max(0,
			math.floor(tonumber(record.salvageMissions) or 0)),
		purchasedAt = math.max(0, math.floor(tonumber(record.purchasedAt) or os.time())),
	}
end

local function normalizeState(state)
	state = istable(state) and state or {}
	local currentLayoutVersion = math.max(1,
		math.floor(tonumber(naval.FleetFormationLayoutVersion) or 3))
	local savedLayoutVersion = math.max(0,
		math.floor(tonumber(state.formationLayoutVersion) or 0))
	local formation = cleanFormation(state.formation)
	local formationRange = cleanFormationRange(state.formationRange)
	if savedLayoutVersion < currentLayoutVersion then
		formation = cleanFormation(naval.FleetDefaultFormation or "close_escort")
		formationRange = cleanFormationRange(naval.FleetDefaultFormationRange or 24)
	end
	local clean = {
		ships = {},
		nextID = math.max(1, math.floor(tonumber(state.nextID) or 1)),
		planetRequests = {},
		cargoHold = {},
		regimentalTier = math.max(1, math.floor(tonumber(state.regimentalTier) or 1)),
		formationLayoutVersion = currentLayoutVersion,
		formation = formation,
		formationRange = formationRange,
		revision = math.max(1, math.floor(tonumber(state.revision) or 1)),
	}
	for fallbackID, raw in pairs(state.ships or {}) do
		local record = normalizeRecord(raw, fallbackID)
		if record then clean.ships[record.id] = record end
	end
	for key, expiresAt in pairs(state.planetRequests or {}) do
		key = G.PlanetKey(key)
		if key ~= "" then clean.planetRequests[key] = math.max(0,
			math.floor(tonumber(expiresAt) or 0)) end
	end
	for key, amount in pairs(state.cargoHold or {}) do
		key = N.CleanKey(key)
		if N.TradeCommodity(key) then
			clean.cargoHold[key] = math.max(0,
				math.floor(tonumber(amount) or 0))
		end
	end
	return clean
end

local function touchFleet()
	N.FleetState.revision = (tonumber(N.FleetState.revision) or 0) + 1
	dirtyAt = CurTime() + math.max(0.2, tonumber(naval.StateSaveDelay) or 2)
end

function N.AddCargo(commodityKey, amount)
	commodityKey = N.CleanKey(commodityKey)
	local definition = N.TradeCommodity(commodityKey)
	if not fleetLoaded or not definition then return 0, 0 end
	amount = math.max(0, math.floor(tonumber(amount) or 0))
	local volume = math.max(1, math.floor(tonumber(definition.volume) or 1))
	local available = math.max(0, N.FleetCargoCapacity() - N.CargoUsed())
	local accepted = math.min(amount, math.floor(available / volume))
	if accepted > 0 then
		N.FleetState.cargoHold[commodityKey] = math.max(0,
			math.floor(tonumber(N.FleetState.cargoHold[commodityKey]) or 0))
			+ accepted
		touchFleet()
	end
	return accepted, available
end

function N.RemoveCargo(commodityKey, amount)
	commodityKey = N.CleanKey(commodityKey)
	if not fleetLoaded or not N.TradeCommodity(commodityKey) then return 0 end
	amount = math.max(0, math.floor(tonumber(amount) or 0))
	local held = math.max(0,
		math.floor(tonumber(N.FleetState.cargoHold[commodityKey]) or 0))
	local removed = math.min(held, amount)
	if removed > 0 then
		N.FleetState.cargoHold[commodityKey] = held - removed
		touchFleet()
	end
	return removed
end

function N.SaveFleetState()
	if not fleetLoaded or not MilBase.DB then return end
	dirtyAt = nil
	local json = util.TableToJSON(N.FleetState, false) or "{}"
	MilBase.DB.Run("REPLACE INTO " .. TABLE_NAME
		.. " (campaign_key,state_json,updated_at) VALUES ("
		.. MilBase.SQLStr(CAMPAIGN_KEY) .. ","
		.. MilBase.SQLStr(json) .. "," .. os.time() .. ")")
end

local function initFleetDatabase()
	if not MilBase.DB then return end
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS " .. TABLE_NAME .. " ("
		.. "campaign_key VARCHAR(64) PRIMARY KEY,"
		.. "state_json LONGTEXT NOT NULL, updated_at INTEGER NOT NULL DEFAULT 0)")
	MilBase.DB.Query("SELECT state_json FROM " .. TABLE_NAME
		.. " WHERE campaign_key=" .. MilBase.SQLStr(CAMPAIGN_KEY) .. " LIMIT 1",
		function(rows)
			local row = rows and rows[1]
			local decoded = row and util.JSONToTable(tostring(row.state_json or "")) or nil
			local savedLayoutVersion = istable(decoded)
				and tonumber(decoded.formationLayoutVersion) or 0
			local currentLayoutVersion = tonumber(naval.FleetFormationLayoutVersion) or 3
			N.FleetState = normalizeState(decoded)
			fleetLoaded = true
			N.FleetRegistryReady = true
			N.UpdateRegimentalFundingTier(true)
			if not row or savedLayoutVersion < currentLayoutVersion then touchFleet() end
		end)
end
hook.Add("Initialize", "MilBase.Naval.FleetDatabase", initFleetDatabase)

local function currentPlanet()
	if not G or not G.EnsurePlanet then return nil end
	return G.EnsurePlanet(G.State and G.State.currentPlanet or "")
end

local function noteContains(planet, token)
	return string.find(string.lower(tostring(planet and planet.note or "")),
		token, 1, true) ~= nil
end

function N.IsRepublicSupplyPlanet(planet)
	if not planet or planet.allegiance ~= "republic" then return false end
	if configuredPlanet(naval.RepublicSupplyWorlds, planet.key) then return true end
	if noteContains(planet, "base") or noteContains(planet, "shipyard")
	or noteContains(planet, "depot") then return true end
	return (tonumber(planet.republicOpinion) or 0)
		>= (tonumber(naval.PlanetSupplyOpinionMinimum) or 50)
end

function N.IsFleetPurchasePlanet(planet)
	if not planet or planet.allegiance ~= "republic" then return false end
	return configuredPlanet(naval.FleetPurchaseWorlds, planet.key)
		or noteContains(planet, "shipyard")
end

local function supplyDestinations()
	local destinations = {}
	for key, planet in pairs(G.Planets or {}) do
		if N.IsRepublicSupplyPlanet(planet) then
			destinations[#destinations + 1] = {
				key = key,
				name = planet.name,
				opinion = tonumber(planet.republicOpinion) or 0,
			}
		end
	end
	table.sort(destinations, function(a, b) return a.name < b.name end)
	return destinations
end

local function resolveFleetModel(definition)
	for _, model in ipairs(definition and definition.models or {}) do
		if util.IsValidModel(model)
		and (not G.IsBlockedShipModel or not G.IsBlockedShipModel(model)) then
			return model
		end
	end
	return nil
end

local function ownedTypeCount(shipType)
	local count = 0
	for _, record in pairs(N.FleetState.ships) do
		if record.shipType == shipType then count = count + 1 end
	end
	return count
end

local function chooseFleetName(definition, numericID)
	local pool = definition.names or {}
	local name = pool[((numericID - 1) % math.max(1, #pool)) + 1]
		or ("RNS " .. tostring(definition.shortLabel or definition.label or "Escort"))
	if numericID > #pool and #pool > 0 then name = name .. " " .. numericID end
	return string.sub(name, 1, 96)
end

function N.SpawnOwnedFleetVisual(record, index, arriving)
	if not fleetLoaded or not record
	or (record.status ~= "following" and record.status ~= "salvage_mission")
	or not G or not G.SpawnShip
	or (G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive()) then return nil end
	local existing = N.FleetEntities[record.id]
	if IsValid(existing) then return existing end
	local definition = N.FleetDefinition(record.shipType)
	if not definition then return nil end
	index = math.max(1, math.floor(tonumber(index) or 1))
	local side = 105 + ((index - 1) % 6) * 25
	local entrySlot = ((index - 1) % 3) - 1
	local entrySpacing = math.max(240,
		tonumber(naval.FleetFormationEntrySpacing) or 620)
	local entryHeight = math.max(0,
		tonumber(naval.FleetFormationEntryHeightStep) or 140)
	local ship = G.SpawnShip(definition.role or "republic", {
		name = record.name,
		model = resolveFleetModel(definition),
		faction = "republic",
		trueFaction = "republic",
		transponderFaction = "republic",
		capital = definition.role == "republic_flagship",
		hull = definition.hull,
		hold = true,
		persistentTraffic = true,
		invulnerable = true,
		state = record.status == "salvage_mission"
			and "recovering assigned wreckage" or "attached Republic fleet support",
		sideYaw = side,
		lane = entrySlot * entrySpacing,
		height = (index % 2 == 0 and 1 or -1)
			* math.abs(entrySlot) * entryHeight,
		routeStatus = "operating in formation with the Republic flagship",
		routeKind = "fleet_support",
	})
	if not IsValid(ship) then return nil end
	ship.mb_navalOwnedFleetID = record.id
	ship.mb_galaxyRepublicFleet = true
	ship.mb_galaxyFleetFollowing = true
	ship.mb_galaxyHoldForPlayerDeparture = true
	ship.mb_galaxyPlayerDeparting = false
	ship.mb_galaxyPersistentTraffic = true
	ship.mb_navalFormationReleaseAt = CurTime()
		+ math.max(0, tonumber(naval.FleetFormationArrivalStagger) or 0.45)
		* math.max(0, index - 1)
	ship:SetFlightVelocity(vector_origin)
	ship:SetDieAt(0)
	N.FleetEntities[record.id] = ship
	if G.BindShipToSWUUniverse then G.BindShipToSWUUniverse(ship) end
	if arriving and G.EmitHyperspaceBurst then
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), ship:GetForward(),
			Color(75, 150, 255), true)
	end
	return ship
end

local function removeFleetVisual(record, departing)
	local ship = record and N.FleetEntities[record.id]
	if not IsValid(ship) then
		if record then N.FleetEntities[record.id] = nil end
		return
	end
	if departing and G.EmitHyperspaceBurst then
		G.EmitHyperspaceBurst(ship:WorldSpaceCenter(), ship:GetForward(),
			Color(75, 150, 255), false)
	end
	ship.mb_navalFleetIntentionalRemoval = true
	N.FleetEntities[record.id] = nil
	ship:Remove()
end

function N.SyncFleetVisuals(arrivingID)
	if not fleetLoaded then return end
	if G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then
		for _, record in pairs(N.FleetState.ships) do
			removeFleetVisual(record, false)
		end
		return
	end
	local index = 0
	for _, record in pairs(N.FleetState.ships) do
		if record.status == "following" or record.status == "salvage_mission" then
			index = index + 1
			N.SpawnOwnedFleetVisual(record, index, record.id == arrivingID)
		else
			removeFleetVisual(record, false)
		end
	end
end

local formationTargetCache = {}

hook.Add("EntityRemoved", "MilBase.Naval.OwnedFleetVisualRemoved", function(ent)
	local id = ent.mb_navalOwnedFleetID
	if not id then return end
	if N.FleetEntities[id] == ent then N.FleetEntities[id] = nil end
	if formationTargetCache then formationTargetCache[id] = nil end
end)

local slotCache = {}
local slotCacheUntil = 0
local slotCacheTotal = 0

local function refreshFormationSlots()
	if CurTime() < slotCacheUntil then return end
	slotCache = {}
	local records = {}
	for _, record in pairs(N.FleetState.ships or {}) do
		if record.status == "following" then records[#records + 1] = record end
	end
	table.sort(records, function(a, b)
		return tostring(a.name) == tostring(b.name)
			and tostring(a.id) < tostring(b.id)
			or tostring(a.name) < tostring(b.name)
	end)
	for index, record in ipairs(records) do slotCache[record.id] = index end
	slotCacheTotal = #records
	slotCacheUntil = CurTime() + 0.35
end

local diamondSlots = {
	Vector(-0.52, -0.62, 0.04),
	Vector(-0.52, 0.62, -0.04),
	Vector(-1.02, 0, 0.12),
	Vector(-1.12, -0.92, -0.08),
	Vector(-1.12, 0.92, 0.08),
	Vector(-1.62, 0, -0.12),
}

local closeEscortSlots = {
	Vector(-0.10, -1.05, 0.02),
	Vector(-0.10, 1.05, -0.02),
	Vector(-2.10, -1.05, 0.08),
	Vector(-2.10, 1.05, -0.08),
	Vector(-4.10, -1.05, -0.06),
	Vector(-4.10, 1.05, 0.06),
}

local function formationOffset(formation, index, total)
	index = math.max(1, math.floor(tonumber(index) or 1))
	total = math.max(index, math.floor(tonumber(total) or index))
	if formation == "close_escort" then
		local point = closeEscortSlots[index] or Vector(-0.8,
			(index - 3.5) * 0.48, 0)
		return Vector(point.x, point.y, point.z)
	elseif formation == "line" then
		return Vector(-0.7, (index - (total + 1) * 0.5) * 0.82,
			(index % 2 == 0 and 0.05 or -0.05))
	elseif formation == "column" then
		return Vector(-0.55 - (index - 1) * 0.55, 0,
			(index % 2 == 0 and 0.1 or -0.1))
	elseif formation == "echelon_left" then
		return Vector(-0.55 - (index - 1) * 0.45,
			-0.3 - (index - 1) * 0.48, (index % 2 == 0 and 0.07 or -0.03))
	elseif formation == "echelon_right" then
		return Vector(-0.55 - (index - 1) * 0.45,
			0.3 + (index - 1) * 0.48, (index % 2 == 0 and 0.07 or -0.03))
	elseif formation == "diamond" then
		local point = diamondSlots[index] or Vector(-1.65,
			(index - 3.5) * 0.42, 0)
		return Vector(point.x, point.y, point.z)
	end
	local row = math.ceil(index / 2)
	local side = index % 2 == 1 and -1 or 1
	return Vector(-0.48 - (row - 1) * 0.5, side * row * 0.66,
		(index % 3 - 1) * 0.07)
end

local function formationAxes()
	-- These actors intentionally bypass the universe transform and live in
	-- flagship-local skybox space. Their formation heading must therefore be
	-- local too; adding the stored galactic yaw makes them turn broadside.
	local yaw = tonumber(naval.FleetFormationLocalHeadingYaw) or 0
	local facing = Angle(0, yaw, 0)
	return facing:Forward(), facing:Right(), Vector(0, 0, 1)
end

local function clampedFormationTarget(target, shipRadius)
	local _, radius, minimum, maximum = G.SkyboxFrame()
	local margin = math.Clamp(math.max(30, tonumber(shipRadius) or 30),
		30, math.max(30, radius * 0.25))
	local function clampPoint(point)
		return Vector(
			math.Clamp(point.x, minimum.x + margin, maximum.x - margin),
			math.Clamp(point.y, minimum.y + margin, maximum.y - margin),
			math.Clamp(point.z, minimum.z + margin * 0.45, maximum.z - margin * 0.45))
	end
	target = clampPoint(target)
	if not G.PlanetClearanceAt or G.PlanetClearanceAt(target, shipRadius) then return target end
	local forward, right, up = formationAxes()
	local shift = math.max(160, radius * 0.24)
	for _, offset in ipairs({
		up * shift, up * -shift, right * shift, right * -shift,
		(forward + up * 0.4) * shift, (forward * -1 + up * 0.4) * shift,
	}) do
		local candidate = clampPoint(target + offset)
		if G.PlanetClearanceAt(candidate, shipRadius) then return candidate end
	end
	return target
end

local function formationFlagshipStandOff(ent, skyboxRadius)
	local shipRadius = ent.GetCombatRadius and ent:GetCombatRadius() or 40
	return math.max(
		tonumber(naval.FleetFormationMinimumFlagshipDistance) or 360,
		math.max(600, tonumber(skyboxRadius) or 600)
			* math.Clamp(tonumber(naval.FleetFormationMinimumFlagshipDistanceFraction)
				or 0.24, 0.08, 0.6),
		math.max(20, tonumber(shipRadius) or 40)
			+ math.max(40, tonumber(naval.FleetFormationFlagshipHullClearance) or 180)
	)
end

function N.FleetFormationTarget(ent)
	if not IsValid(ent) or not ent.mb_navalOwnedFleetID then return nil end
	local cached = formationTargetCache[ent.mb_navalOwnedFleetID]
	if cached and CurTime() < cached.expiresAt then
		return cached.target, cached.forward
	end
	refreshFormationSlots()
	local index = slotCache[ent.mb_navalOwnedFleetID]
	if not index then return nil end
	local center, radius = G.SkyboxFrame()
	local formation = cleanFormation(N.FleetState.formation)
	local offset = formationOffset(formation, index, slotCacheTotal)
	local range = cleanFormationRange(N.FleetState.formationRange)
	local scale = radius * range / 100
	local shipRadius = ent.GetCombatRadius and ent:GetCombatRadius()
		or G.MaximumShipRadius and G.MaximumShipRadius(ent) or 40
	local standOff = formationFlagshipStandOff(ent, radius)
	scale = math.max(scale, standOff / math.max(0.35, offset:Length()))
	-- Every formation, not just close escort, must keep neighbouring hulls
	-- apart. Work in the formation's normalized coordinates so line/column
	-- layouts cannot collapse large capital models into the same slot.
	local widestRadius = math.max(20, tonumber(shipRadius) or 40)
	for _, fleetShip in pairs(N.FleetEntities) do
		if IsValid(fleetShip) then
			local fleetRadius = fleetShip.GetCombatRadius and fleetShip:GetCombatRadius()
				or G.MaximumShipRadius
					and G.MaximumShipRadius(fleetShip) or 40
			widestRadius = math.max(widestRadius, tonumber(fleetRadius) or 40)
		end
	end
	local minimumSlotDistance = math.huge
	for otherIndex = 1, slotCacheTotal do
		if otherIndex ~= index then
			minimumSlotDistance = math.min(minimumSlotDistance,
				offset:Distance(formationOffset(formation, otherIndex, slotCacheTotal)))
		end
	end
	if minimumSlotDistance < math.huge then
		local required = widestRadius * 2
			+ math.max(20, tonumber(naval.FleetFormationShipClearance) or 80)
		scale = math.max(scale, required / math.max(0.25, minimumSlotDistance))
	end
	local forward, right, up = formationAxes()
	local target = center + forward * offset.x * scale
		+ right * offset.y * scale + up * offset.z * scale
	target = clampedFormationTarget(target, shipRadius)
	local fromFlagship = target - center
	if fromFlagship:Length() < standOff then
		if fromFlagship:LengthSqr() <= 0.001 then
			fromFlagship = right * (offset.y < 0 and -1 or 1)
		end
		fromFlagship:Normalize()
		target = clampedFormationTarget(center + fromFlagship * standOff, shipRadius)
	end
	formationTargetCache[ent.mb_navalOwnedFleetID] = {
		target = target,
		forward = forward,
		expiresAt = CurTime() + 0.1,
	}
	return target, forward
end

local function formationActualVelocity(ent)
	if isvector(ent.mb_galaxyActualWorldVelocity) then
		return Vector(ent.mb_galaxyActualWorldVelocity)
	end
	if isvector(ent.mb_galaxyLocalVelocity) then
		return Vector(ent.mb_galaxyLocalVelocity)
	end
	return Vector(ent:GetFlightVelocity())
end

local function formationTravelDirection(ent, actualVelocity)
	if actualVelocity:LengthSqr() > 1 then return actualVelocity:GetNormalized() end
	local facing = ent:GetAngles()
	local galaxy = MilBase.Config.GalaxyDirector or {}
	local corrections = galaxy.ShipModelFacingYaw or {}
	local correction = tonumber(corrections[ent:GetRole()])
		or tonumber(corrections.default) or 0
	facing.y = facing.y - correction
	return facing:Forward()
end

local function formationMaximumSpeed(ent)
	local limits = naval.FleetFormationRoleSpeeds or {}
	local roleLimit = math.max(4, tonumber(limits[ent:GetRole()])
		or tonumber(limits.default) or 50)
	return math.min(roleLimit, math.max(4,
		tonumber(naval.FleetFormationManeuverSpeed) or 120))
end

local function formationArrivalRadius(ent)
	local configured = math.max(6,
		tonumber(naval.FleetFormationDeadband) or 10)
	local shipRadius = ent.GetCombatRadius and ent:GetCombatRadius() or 40
	local scaled = math.max(0, tonumber(shipRadius) or 40)
		* math.max(0, tonumber(naval.FleetFormationArrivalRadiusScale) or 0.08)
	local maximum = math.max(configured,
		tonumber(naval.FleetFormationMaximumArrivalRadius) or 32)
	return math.max(configured, math.min(scaled, maximum))
end

local function formationCollisionAvoidance(ent, desired)
	if not IsValid(ent) or not isvector(desired)
	or desired:LengthSqr() <= 0.001 then return desired end
	local position = ent:GetPos()
	local ownRadius = math.max(20, tonumber(ent:GetCombatRadius()) or 40)
	local adjusted = Vector(desired)
	local speedScale = 1
	for _, other in pairs(N.FleetEntities) do
		if IsValid(other) and other ~= ent then
			local away = position - other:GetPos()
			local distance = away:Length()
			local required = ownRadius
				+ math.max(20, tonumber(other:GetCombatRadius()) or 40)
				+ math.max(20, tonumber(naval.FleetFormationShipClearance) or 80)
			local avoidanceRange = required * math.max(1.1,
				tonumber(naval.FleetFormationAvoidanceRangeScale) or 1.8)
			if distance < avoidanceRange then
				if distance <= 0.01 then
					local sign = ent:EntIndex() < other:EntIndex() and -1 or 1
					away = ent:GetRight() * sign
				else
					away = away / distance
				end
				local urgency = math.Clamp(
					(avoidanceRange - distance) / math.max(1, avoidanceRange - required),
					0, 1)
				adjusted = adjusted + away
					* desired:Length() * (0.55 + urgency * 1.15)
				if distance < required then
					speedScale = math.min(speedScale,
						math.Clamp(distance / math.max(1, required), 0.18, 0.7))
				end
			end
		end
	end
	if adjusted:LengthSqr() <= 0.001 then return desired * speedScale end
	return adjusted:GetNormalized() * desired:Length() * speedScale
end

-- Formation slots are docking targets, not ordinary cruise waypoints. A pure
-- "point at target" controller lets a slow-turning capital ship arrive too
-- quickly, overshoot and orbit forever. This controller limits speed by both
-- stopping distance and current course alignment so ships brake before the
-- slot, make a controlled turn, then settle without circling.
local function formationDesiredVelocity(ent, delta, distance, arrivalRadius)
	if distance <= arrivalRadius or distance <= 0.001 then return vector_origin end
	local direction = delta / distance
	local remaining = math.max(0, distance - arrivalRadius)
	local profile = G.ShipFlightProfile and G.ShipFlightProfile(ent) or {}
	local brake = math.max(1, tonumber(profile.brake) or 24)
	local speed = math.min(
		formationMaximumSpeed(ent),
		remaining * math.max(0.05,
			tonumber(naval.FleetFormationPositionGain) or 0.38),
		math.sqrt(2 * brake * remaining)
			* math.Clamp(tonumber(naval.FleetFormationBrakeSafety) or 0.82, 0.35, 1)
	)

	local actualVelocity = formationActualVelocity(ent)
	local travelDirection = formationTravelDirection(ent, actualVelocity)
	local alignment = math.Clamp(travelDirection:Dot(direction), -1, 1)
	local turnFraction = math.Clamp((alignment + 1) * 0.5, 0, 1)
	local minimumThrottle = math.Clamp(
		tonumber(naval.FleetFormationTurnMinimumThrottle) or 0.12, 0.04, 0.5)
	local turnThrottle = minimumThrottle
		+ (1 - minimumThrottle) * turnFraction * turnFraction
	return direction * speed * turnThrottle
end

local function formationNavigationDelta(ent, target)
	local position = ent:GetPos()
	local direct = target - position
	if direct:LengthSqr() <= 0.001 then return direct end
	local center, radius = G.SkyboxFrame()
	local safeRadius = formationFlagshipStandOff(ent, radius) * 1.08
	local lengthSqr = direct:LengthSqr()
	local fraction = math.Clamp((center - position):Dot(direct) / lengthSqr, 0, 1)
	local closest = position + direct * fraction
	if closest:DistToSqr(center) >= safeRadius * safeRadius then return direct end

	local radial = position - center
	if radial:LengthSqr() <= 1 then radial = target - center end
	if radial:LengthSqr() <= 1 then radial = Vector(1, 0, 0) end
	radial:Normalize()
	if position:DistToSqr(center) < safeRadius * safeRadius then
		return center + radial * safeRadius - position
	end

	-- Route around the protected flagship sphere rather than cutting through
	-- it when a formation order moves a vessel from one side to the other.
	local targetRadial = target - center
	local cross = radial.x * targetRadial.y - radial.y * targetRadial.x
	local side = cross < 0 and -1 or 1
	local tangent = Vector(-radial.y * side, radial.x * side, 0)
	if tangent:LengthSqr() <= 0.001 then tangent = Vector(0, side, 0) end
	tangent:Normalize()
	local waypoint = center + radial * safeRadius + tangent * safeRadius * 0.72
	waypoint.z = Lerp(0.35, position.z, target.z)
	return waypoint - position
end

function N.UpdateOwnedFleetFormationMotion(ent)
	if not fleetLoaded or not IsValid(ent) then return false end
	local record = N.FleetState.ships[ent.mb_navalOwnedFleetID or ""]
	if not record then return false end
	if record.status == "salvage_mission" then
		local wreck = Entity(math.max(0,
			math.floor(tonumber(record.salvageTarget) or 0)))
		if not IsValid(wreck) or not wreck.mb_galaxySalvage
		or wreck.mb_navalSalvageReservedBy ~= record.id then
			return false
		end
		ent.mb_galaxyFlightRoute = nil
		ent.mb_galaxyFormationFlight = nil
		local delta = wreck:WorldSpaceCenter() - ent:WorldSpaceCenter()
		local distance = delta:Length()
		local shipRadius = math.max(15, tonumber(ent:GetCombatRadius()) or 35)
		local wreckRadius = math.max(15, tonumber(wreck:GetCombatRadius()) or 35)
		local standOff = shipRadius + wreckRadius + 24
		local desired = vector_origin
		if distance > standOff then
			desired = delta:GetNormalized() * math.min(
				math.max(18, tonumber(naval.FleetSalvageApproachSpeed) or 105),
				math.max(12, (distance - standOff) * 0.42))
			local state = "approaching wreckage"
			if ent:GetShipState() ~= state then ent:SetShipState(state) end
			if G.ShipTravelFacing then
				local facing = G.ShipTravelFacing(ent:GetRole(), desired)
				if isangle(facing) then
					ent:SetAngles(LerpAngle(math.Clamp(FrameTime() * 1.7, 0, 1),
						ent:GetAngles(), facing))
				end
			end
			ent.mb_galaxyRouteStatus = "closing on " .. tostring(record.salvageName)
		else
			if (tonumber(record.missionEndsAt) or 0) <= 0 then
				record.missionEndsAt = os.time() + math.max(8,
					math.floor(tonumber(naval.FleetSalvageWorkSeconds) or 38))
				touchFleet()
			end
			local state = "cutting wreckage"
			if ent:GetShipState() ~= state then ent:SetShipState(state) end
			ent.mb_galaxyRouteStatus = "recovering " .. tostring(record.salvageName)
		end
		if ent:GetFlightVelocity():DistToSqr(desired) > 0.2 then
			ent:SetFlightVelocity(desired)
		end
		return true
	end
	if record.status ~= "following" then return false end
	if CurTime() < (tonumber(ent.mb_navalFormationReleaseAt) or 0) then
		ent:SetFlightVelocity(vector_origin)
		ent.mb_galaxyLocalVelocity = vector_origin
		ent.mb_galaxyLongitudinalAcceleration = 0
		ent:SetShipState("holding hyperspace arrival lane")
		return true
	end
	ent.mb_navalFormationReleaseAt = nil
	local target, fleetForward = N.FleetFormationTarget(ent)
	if not isvector(target) then return false end
	ent.mb_galaxyFlightRoute = nil
	ent.mb_galaxyFormationFlight = nil
	local delta = target - ent:GetPos()
	local distance = delta:Length()
	local deadband = formationArrivalRadius(ent)
	local captured = distance <= deadband
	local navigationDelta = captured and delta or formationNavigationDelta(ent, target)
	local navigationDistance = navigationDelta:Length()
	local desired = captured and vector_origin
		or formationDesiredVelocity(ent, navigationDelta, navigationDistance, deadband)
	if not captured then desired = formationCollisionAvoidance(ent, desired) end
	if captured then
		-- Requested zero speed alone still leaves inertia in the shared flight
		-- model. Capture the assigned slot and clear every velocity layer so an
		-- escort cannot creep, orbit, or slowly drift back toward the flagship.
		ent:SetPos(target)
		ent.mb_galaxyLocalVelocity = vector_origin
		ent.mb_galaxyUniverseVelocity = vector_origin
		ent.mb_galaxyActualWorldVelocity = vector_origin
		ent.mb_galaxyDesiredWorldVelocity = vector_origin
		ent.mb_galaxyDesiredUniverseVelocity = vector_origin
		ent.mb_galaxyLongitudinalAcceleration = 0
	end
	if ent:GetFlightVelocity():DistToSqr(desired) > 0.2 then
		ent:SetFlightVelocity(desired)
	end
	local definition = formationDefinition(N.FleetState.formation) or {}
	local label = string.lower(definition.label or "fleet formation")
	local settled = captured
	if not settled then
		local state = "manoeuvring into " .. label
		if ent:GetShipState() ~= state then ent:SetShipState(state) end
		ent.mb_galaxyRouteStatus = state .. " with the Republic flagship"
	else
		local state = "holding " .. label
		if ent:GetShipState() ~= state then ent:SetShipState(state) end
		ent.mb_galaxyRouteStatus = state .. " with the Republic flagship"
		if CurTime() >= (ent.mb_navalNextFormationFacingAt or 0)
		and isvector(fleetForward) and G.ShipTravelFacing then
			ent.mb_navalNextFormationFacingAt = CurTime() + 0.1
			if G.UpdateShipTravelFacing then
				G.UpdateShipTravelFacing(ent, fleetForward, angle_zero, 0.1, false)
			else
				local facing = G.ShipTravelFacing(ent:GetRole(), fleetForward)
				if isangle(facing) then ent:SetAngles(facing) end
			end
		end
	end
	return true
end

function N.SetFleetFormation(ply, formation, range)
	if not fleetLoaded then return false, "Fleet registry is still loading." end
	formation = N.CleanKey(formation)
	if not formationDefinition(formation) then return false, "Unknown fleet formation." end
	range = cleanFormationRange(range)
	N.FleetState.formation = formation
	N.FleetState.formationRange = range
	slotCacheUntil = 0
	formationTargetCache = {}
	local definition = formationDefinition(formation)
	for _, ship in pairs(N.FleetEntities) do
		if IsValid(ship) then
			ship.mb_galaxyFlightRoute = nil
			ship.mb_navalFormationReleaseAt = CurTime()
				+ math.max(0, tonumber(naval.FleetFormationArrivalStagger) or 0.45)
				* math.max(0, (slotCache[ship.mb_navalOwnedFleetID] or 1) - 1)
			ship:SetShipState("acknowledging " .. string.lower(definition.label))
		end
	end
	touchFleet()
	N.AddLog("fleet", "Formation order: " .. definition.label,
		"Support fleet ordered to " .. range
			.. "% formation range from the Republic flagship.", ply)
	return true, "Fleet acknowledges " .. definition.label
		.. " at " .. range .. "% formation range."
end

local function totalFleetShips()
	return table.Count(N.FleetState.ships or {})
end

function N.PurchaseFleetShip(ply, shipType)
	if not fleetLoaded then return false, "Fleet registry is still loading." end
	local definition = N.FleetDefinition(shipType)
	if not definition then return false, "Unknown Republic fleet asset." end
	local planet = currentPlanet()
	if not N.IsFleetPurchasePlanet(planet) then
		return false, "Fleet vessels can only be commissioned at a Republic shipyard such as Kuat, Coruscant or Kamino."
	end
	if totalFleetShips() >= math.max(1, tonumber(naval.FleetMaximumShips) or 6) then
		return false, "The support fleet is at its campaign limit."
	end
	if ownedTypeCount(N.CleanKey(shipType))
	>= math.max(1, tonumber(definition.maxOwned) or 99) then
		return false, "The fleet already has the maximum number of this class."
	end
	local ok, message = N.Spend(definition.cost or {},
		"Fleet vessel commissioned: " .. tostring(definition.label), ply)
	if not ok then return false, message end
	local numericID = math.max(1, math.floor(tonumber(N.FleetState.nextID) or 1))
	N.FleetState.nextID = numericID + 1
	local id = "fleet_" .. numericID
	local record = {
		id = id,
		shipType = N.CleanKey(shipType),
		name = chooseFleetName(definition, numericID),
		status = "following",
		destinationKey = "",
		missionStartedAt = 0,
		missionEndsAt = 0,
		missions = 0,
		salvageMissions = 0,
		purchasedAt = os.time(),
	}
	N.FleetState.ships[id] = record
	touchFleet()
	N.SyncFleetVisuals(id)
	N.AddLog("fleet", record.name .. " commissioned",
		definition.label .. " joined the Republic support fleet at " .. planet.name .. ".", ply)
	return true, record.name .. " has joined formation with the fleet."
end

local function missionDuration(originKey, destinationKey)
	local minimum = math.max(60, tonumber(naval.FleetMissionMinimumSeconds) or 480)
	local maximum = math.max(minimum, tonumber(naval.FleetMissionMaximumSeconds) or 2400)
	local origin = G.UniversePositions and G.UniversePositions[originKey]
	local destination = G.UniversePositions and G.UniversePositions[destinationKey]
	if isvector(origin) and isvector(destination) then
		return math.floor(math.Clamp(origin:Distance(destination)
			* math.max(0.01, tonumber(naval.FleetMissionSecondsPerUniverseUnit) or 0.22)
			* 2, minimum, maximum))
	end
	return math.floor(math.Clamp((minimum + maximum) * 0.45, minimum, maximum))
end

local function acceptedStoreGrant(proposed)
	local accepted = {}
	for key, amount in pairs(proposed or {}) do
		if N.State.resources[key] ~= nil then
			local maximum = tonumber(naval.ResourceMaximums
				and naval.ResourceMaximums[key]) or 999999999
			accepted[key] = math.max(0, math.min(math.floor(tonumber(amount) or 0),
				math.floor(maximum - (tonumber(N.State.resources[key]) or 0))))
		end
	end
	return accepted
end

local function grantHasCargo(grant)
	for _, amount in pairs(grant or {}) do
		if (tonumber(amount) or 0) > 0 then return true end
	end
	return false
end

function N.DispatchFleetSupplyMission(ply, fleetID, destinationKey)
	if not fleetLoaded then return false, "Fleet registry is still loading." end
	local record = N.FleetState.ships[N.CleanKey(fleetID)]
	if not record then return false, "That fleet vessel is not registered." end
	if record.status ~= "following" then return false, record.name .. " is already away on assignment." end
	destinationKey = G.PlanetKey(destinationKey)
	local destination = G.Planets and G.Planets[destinationKey]
	if not N.IsRepublicSupplyPlanet(destination) then
		return false, "Supply missions require a Republic core world or recognised Republic base."
	end
	local origin = currentPlanet()
	local now = os.time()
	record.status = "supply_mission"
	record.destinationKey = destinationKey
	record.missionStartedAt = now
	record.missionEndsAt = now + missionDuration(origin and origin.key or "", destinationKey)
	removeFleetVisual(record, true)
	touchFleet()
	N.AddLog("fleet", record.name .. " dispatched",
		"Round-trip supply mission to " .. destination.name .. ". Estimated return in "
			.. math.ceil((record.missionEndsAt - now) / 60) .. " minutes.", ply)
	return true, record.name .. " has jumped to " .. destination.name
		.. " and will return with supplies."
end

local function salvageWrecks()
	local wrecks = {}
	for _, wreck in ipairs(G.Wreckage or {}) do
		if IsValid(wreck) and wreck.mb_galaxySalvage
		and not wreck.mb_navalSalvageReservedBy then
			local capitalMultiplier = wreck:GetCapital()
				and math.max(1,
					tonumber(naval.FleetSalvageCapitalMultiplier) or 1.8) or 1
			local estimatedFunding = ((tonumber(naval.FleetSalvageFundingMinimum)
				or 1800) + (tonumber(naval.FleetSalvageFundingMaximum) or 6200))
				* 0.5 * capitalMultiplier
			local estimatedScrap = ((tonumber(naval.FleetSalvageScrapMinimum)
				or 18) + (tonumber(naval.FleetSalvageScrapMaximum) or 65))
				* 0.5 * capitalMultiplier
			wrecks[#wrecks + 1] = {
				entity = wreck:EntIndex(),
				name = wreck:GetShipName(),
				funding = math.max(0,
					math.floor(tonumber(wreck.mb_navalSalvageFunding)
						or estimatedFunding)),
				scrap = math.max(0,
					math.floor(tonumber(wreck.mb_navalSalvageScrap)
						or estimatedScrap)),
			}
		end
	end
	table.sort(wrecks, function(a, b) return a.name < b.name end)
	return wrecks
end

function N.DispatchFleetSalvageMission(ply, fleetID, wreckIndex)
	if not fleetLoaded then return false, "Fleet registry is still loading." end
	local record = N.FleetState.ships[N.CleanKey(fleetID)]
	if not record then return false, "That fleet vessel is not registered." end
	if record.status ~= "following" then
		return false, record.name .. " is already away on assignment."
	end
	local wreck = Entity(math.max(0, math.floor(tonumber(wreckIndex) or 0)))
	if not IsValid(wreck) or not wreck.mb_galaxySalvage then
		return false, "That wreckage is no longer available."
	end
	if wreck.mb_navalSalvageReservedBy then
		return false, "Another support vessel is already recovering that wreck."
	end
	record.status = "salvage_mission"
	record.salvageTarget = wreck:EntIndex()
	record.salvageName = string.sub(tostring(wreck:GetShipName()), 1, 96)
	local capitalMultiplier = wreck:GetCapital()
		and math.max(1, tonumber(naval.FleetSalvageCapitalMultiplier) or 1.8) or 1
	local fundingMinimum = math.max(0,
		tonumber(naval.FleetSalvageFundingMinimum) or 1800)
	local fundingMaximum = math.max(fundingMinimum,
		tonumber(naval.FleetSalvageFundingMaximum) or 6200)
	local scrapMinimum = math.max(1,
		math.floor(tonumber(naval.FleetSalvageScrapMinimum) or 18))
	local scrapMaximum = math.max(scrapMinimum,
		math.floor(tonumber(naval.FleetSalvageScrapMaximum) or 65))
	record.salvageFunding = math.max(0, math.floor(tonumber(
		wreck.mb_navalSalvageFunding) or math.Rand(
			fundingMinimum, fundingMaximum) * capitalMultiplier))
	record.salvageScrap = math.max(0, math.floor(tonumber(
		wreck.mb_navalSalvageScrap) or math.random(
			scrapMinimum, scrapMaximum) * capitalMultiplier))
	record.missionStartedAt = os.time()
	record.missionEndsAt = 0
	wreck.mb_navalSalvageReservedBy = record.id
	wreck:SetDieAt(0)
	local ship = N.FleetEntities[record.id]
	if IsValid(ship) then
		ship:SetShipState("acknowledging salvage assignment")
		ship.mb_galaxyFlightRoute = nil
	end
	formationTargetCache[record.id] = nil
	slotCacheUntil = 0
	touchFleet()
	N.SyncFleetVisuals()
	N.AddLog("salvage", record.name .. " assigned to wreckage recovery",
		"Recovery ordered for " .. record.salvageName .. ".", ply)
	return true, record.name .. " is manoeuvring to " .. record.salvageName .. "."
end

local function clearSalvageRecord(record)
	record.status = "following"
	record.salvageTarget = nil
	record.salvageName = nil
	record.salvageFunding = nil
	record.salvageScrap = nil
	record.missionStartedAt = 0
	record.missionEndsAt = 0
	formationTargetCache[record.id] = nil
	slotCacheUntil = 0
end

local function cancelSalvageMission(record)
	local name = record.salvageName or "assigned wreckage"
	clearSalvageRecord(record)
	touchFleet()
	N.SyncFleetVisuals()
	N.AddLog("salvage", record.name .. " recovery cancelled",
		name .. " was lost before recovery could be completed.", "FLEET LOGISTICS")
end

local function completeSalvageMission(record)
	local wreck = Entity(math.max(0,
		math.floor(tonumber(record.salvageTarget) or 0)))
	local wreckName = record.salvageName or "recovered wreckage"
	local funding = math.max(0,
		math.floor(tonumber(record.salvageFunding) or 0))
	local scrap = math.max(0,
		math.floor(tonumber(record.salvageScrap) or 0))
	local fundingGrant = acceptedStoreGrant({ funding = funding })
	if IsValid(wreck) and wreck.mb_navalSalvageReservedBy == record.id then
		wreck.mb_navalSalvageReservedBy = nil
		wreck:Remove()
	end
	clearSalvageRecord(record)
	record.salvageMissions = math.max(0,
		math.floor(tonumber(record.salvageMissions) or 0)) + 1
	if (fundingGrant.funding or 0) > 0 then
		N.ChangeResources(fundingGrant,
			record.name .. " completed a salvage mission", "FLEET SALVAGE", true)
	end
	local acceptedScrap = N.AddCargo("scrap", scrap)
	touchFleet()
	N.SyncFleetVisuals()
	local result = "Recovered CR " .. string.Comma(fundingGrant.funding or 0)
		.. " and " .. string.Comma(acceptedScrap) .. " scrap"
	if acceptedScrap < scrap then
		result = result .. " (cargo hold full; "
			.. string.Comma(scrap - acceptedScrap) .. " scrap left behind)"
	end
	N.AddLog("salvage", record.name .. " recovered " .. wreckName,
		result .. " and returned to formation.", "FLEET SALVAGE")
	for _, ply in ipairs(player.GetHumans()) do
		if not N.IsNavy or N.IsNavy(ply) then
			MilBase.Notify(ply, record.name .. " completed recovery: "
				.. result .. ".", "ok")
		end
	end
end

local function completeMission(record)
	local definition = N.FleetDefinition(record.shipType)
	local destination = G.Planets and G.Planets[record.destinationKey]
	local destinationName = destination and destination.name or record.destinationKey
	local grant = acceptedStoreGrant(definition and definition.supplyYield or {})
	record.status = "following"
	record.destinationKey = ""
	record.missionStartedAt = 0
	record.missionEndsAt = 0
	record.missions = (tonumber(record.missions) or 0) + 1
	N.ChangeResources(grant, record.name .. " completed a supply mission",
		"FLEET LOGISTICS", true)
	N.AddLog("fleet", record.name .. " returned from " .. destinationName,
		(grantHasCargo(grant) and ("Recovered " .. N.FormatCost(grant))
			or "Fleet stores were already at capacity")
			.. " and rejoined formation.", "FLEET LOGISTICS")
	touchFleet()
	N.SyncFleetVisuals(record.id)
	for _, ply in ipairs(player.GetHumans()) do
		if not N.IsNavy or N.IsNavy(ply) then
			MilBase.Notify(ply, record.name .. " has returned from " .. destinationName
				.. (grantHasCargo(grant) and (" with " .. N.FormatCost(grant, true))
					or "; fleet stores were already full") .. ".", "ok")
		end
	end
end

function N.UpdateRegimentalFundingTier(silent)
	if not N.FleetState or not N.State or not N.State.resources then return end
	local current = math.max(1, math.floor(tonumber(N.FleetState.regimentalTier) or 1))
	local funding = math.max(0, math.floor(tonumber(N.State.resources.funding) or 0))
	local unlocked = current
	for tier = current + 1, 32 do
		local definition = N.RegimentalTierDefinition(tier)
		if not definition or definition.enabled == false then break end
		if funding < math.max(0, tonumber(definition.requiredFunding) or 0) then break end
		unlocked = tier
	end
	if unlocked <= current then return end
	N.FleetState.regimentalTier = unlocked
	touchFleet()
	local definition = N.RegimentalTierDefinition(unlocked)
	N.AddLog("funding", "Regimental development tier unlocked",
		tostring(definition and definition.label or ("Tier " .. unlocked))
			.. " is now available to the future regimental skill programme.",
		"REPUBLIC PROCUREMENT")
	hook.Run("MilBase.RegimentalFundingTierUnlocked", unlocked, funding)
	if not silent then
		for _, ply in ipairs(player.GetHumans()) do
			if not N.IsNavy or N.IsNavy(ply) then
				MilBase.Notify(ply, "Campaign funding unlocked "
					.. tostring(definition and definition.label or ("Tier " .. unlocked))
					.. " regimental development.", "ok")
			end
		end
	end
end

function G.PlanetContactSnapshot()
	local planet = currentPlanet()
	if not N.IsRepublicSupplyPlanet(planet) then return nil end
	local availableAt = tonumber(N.FleetState.planetRequests[planet.key]) or 0
	local remaining = math.max(0, availableAt - os.time())
	return {
		entity = 0,
		planetContact = true,
		name = string.upper(planet.name) .. " PLANETARY COMMAND",
		faction = "republic",
		factionName = "GALACTIC REPUBLIC",
		state = remaining > 0 and ("LOGISTICS COOLDOWN " .. math.ceil(remaining / 60) .. " MIN")
			or "PLANETARY LOGISTICS AVAILABLE",
		scanned = true,
		hostile = false,
		signal = 100,
		signalLabel = "SECURE",
		known = false,
		contactTypeName = "REPUBLIC SUPPLY AUTHORITY",
		routeStatus = "secure orbital logistics channel",
	}
end

function N.RequestPlanetSupplies(ply)
	if not fleetLoaded then return false, "Planetary logistics registry is still loading." end
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then
		return false, "Use the communications station to contact planetary logistics."
	end
	local planet = currentPlanet()
	if not N.IsRepublicSupplyPlanet(planet) then
		return false, "This world has no Republic logistics authority available to the fleet."
	end
	local now = os.time()
	local availableAt = tonumber(N.FleetState.planetRequests[planet.key]) or 0
	if availableAt > now then
		return false, planet.name .. " can prepare another shipment in "
			.. math.ceil((availableAt - now) / 60) .. " minutes."
	end
	local multiplier = math.Clamp(0.85
		+ math.max(0, tonumber(planet.republicOpinion) or 0) / 250, 0.85, 1.25)
	local proposed = {}
	for key, amount in pairs(naval.PlanetSupplyGrant or {}) do
		proposed[key] = math.max(0, math.floor((tonumber(amount) or 0) * multiplier))
	end
	local grant = acceptedStoreGrant(proposed)
	if not grantHasCargo(grant) then
		return false, "Fleet stores are already full; planetary command is holding the shipment."
	end
	N.FleetState.planetRequests[planet.key] = now
		+ math.max(60, tonumber(naval.PlanetSupplyCooldown) or 1800)
	N.ChangeResources(grant, "Planetary shipment received from " .. planet.name, ply, true)
	N.AddLog("logistics", "Planetary supply request approved",
		planet.name .. " transferred " .. N.FormatCost(grant) .. " to the fleet.", ply)
	touchFleet()
	return true, planet.name .. " approved the request: " .. N.FormatCost(grant, true) .. "."
end

local function commodityKeys()
	local keys, seen = {}, {}
	for _, key in ipairs(naval.TradeCommodityOrder or {}) do
		key = N.CleanKey(key)
		if key ~= "" and N.TradeCommodity(key) and not seen[key] then
			seen[key] = true
			keys[#keys + 1] = key
		end
	end
	for key in pairs(naval.TradeCommodities or {}) do
		key = N.CleanKey(key)
		if key ~= "" and not seen[key] then
			seen[key] = true
			keys[#keys + 1] = key
		end
	end
	return keys
end

local function createContactStock(ship)
	if istable(ship.mb_navalTradeStock) then return ship.mb_navalTradeStock end
	local stock = {}
	for _, key in ipairs(commodityKeys()) do
		local definition = N.TradeCommodity(key)
		stock[key] = definition and definition.buyable == false
			and math.random(4, 18) or math.random(24, 82)
	end
	local trafficRecord = ship.mb_galaxyUniverseTrafficID
		and G.UniverseTraffic
		and G.UniverseTraffic[ship.mb_galaxyUniverseTrafficID] or nil
	local cargoKey = N.CleanKey(trafficRecord and trafficRecord.cargoKey or "")
	if N.TradeCommodity(cargoKey) then
		stock[cargoKey] = math.random(70, 115)
	end
	ship.mb_navalTradeStock = stock
	return stock
end

function N.OpenContactTrade(ply, ship)
	if not fleetLoaded then return false, "The cargo registry is still loading." end
	if not IsValid(ply) or not IsValid(ship) or not ship.GetShipName then
		return false, "That trade contact is no longer available."
	end
	if ship:GetHostile() or ship:GetFaction() == "cis" then
		return false, "The contact refuses to establish a commercial link."
	end
	createContactStock(ship)
	N.ActiveTradeContact = ship
	N.ActiveTradeContactUntil = CurTime()
		+ math.max(30, tonumber(naval.TradeContactDuration) or 120)
	ply.mb_navalFleetTab = "cargo"
	return true, "Secure cargo manifest exchanged. The trade link has been routed "
		.. "to the Fleet Logistics console."
end

local function tradeMarket(ply)
	if IsValid(N.ActiveTradeContact)
	and CurTime() <= (tonumber(N.ActiveTradeContactUntil) or 0) then
		local ship = N.ActiveTradeContact
		return {
			kind = "contact",
			name = ship:GetShipName(),
			activity = ship:GetFaction() == "pirate"
				and "independent salvage and unregistered freight"
				or "direct ship-to-ship cargo exchange",
			stock = createContactStock(ship),
			markup = ship:GetFaction() == "pirate" and 1.12 or 1.04,
			entity = ship,
		}
	end
	local planet = currentPlanet()
	if not planet then return nil end
	local defaultPlanet = G.PlanetKey((MilBase.Config.GalaxyDirector or {}).DefaultPlanet
		or "Deep Space")
	if planet.key == defaultPlanet then return nil end
	local economy = G.GalaxyEconomyFor and G.GalaxyEconomyFor(planet.key)
	if not economy then return nil end
	economy.stock = economy.stock or {}
	for _, key in ipairs(commodityKeys()) do
		local definition = N.TradeCommodity(key)
		local economyKey = N.CleanKey(definition and definition.economyKey or key)
		if economy.stock[economyKey] == nil then
			economy.stock[economyKey] = math.random(32, 68)
		end
	end
	return {
		kind = "planet",
		name = planet.name .. " ORBITAL EXCHANGE",
		activity = economy.activity or "normal orbital trade",
		stock = economy.stock,
		markup = planet.allegiance == "republic" and 0.94
			or planet.allegiance == "cis" and 1.22 or 1,
		planetKey = planet.key,
	}
end

local function commodityMarketStock(market, commodityKey)
	local definition = N.TradeCommodity(commodityKey)
	local economyKey = N.CleanKey(definition and definition.economyKey or commodityKey)
	return math.max(0,
		math.floor(tonumber(market and market.stock[economyKey]) or 0)), economyKey
end

local function commodityPrices(market, commodityKey)
	local definition = N.TradeCommodity(commodityKey)
	if not definition or not market then return 0, 0 end
	local stock = commodityMarketStock(market, commodityKey)
	local scarcity = math.Clamp(1.25 - (stock - 50) * 0.012, 0.65, 1.55)
	local buyPrice = math.max(1, math.floor(
		(tonumber(definition.basePrice) or 1)
		* scarcity * (tonumber(market.markup) or 1)))
	local sellPrice = math.max(1, math.floor(buyPrice
		* math.Clamp(tonumber(naval.TradeSellReturnFraction) or 0.72, 0.1, 0.95)))
	return buyPrice, sellPrice
end

local function markMarketChanged(market)
	if market and market.kind == "planet" then G.GalaxySimulationDirty = true end
end

function N.TradeCargo(ply, direction, commodityKey, amount)
	if not fleetLoaded then return false, "The cargo registry is still loading." end
	direction = N.CleanKey(direction)
	commodityKey = N.CleanKey(commodityKey)
	local definition = N.TradeCommodity(commodityKey)
	if not definition then return false, "Unknown cargo commodity." end
	amount = math.Clamp(math.floor(tonumber(amount) or 0), 1,
		math.max(1, math.floor(tonumber(naval.TradeMaximumUnitsPerOrder) or 100)))
	local market = tradeMarket(ply)
	if not market then return false, "No local market or ship-to-ship trade link is available." end
	local stock, economyKey = commodityMarketStock(market, commodityKey)
	local buyPrice, sellPrice = commodityPrices(market, commodityKey)
	ply.mb_navalFleetTab = "cargo"
	if direction == "buy" then
		if definition.buyable == false then
			return false, definition.label .. " is recovered cargo and cannot be purchased here."
		end
		if stock < amount then
			return false, "The market only has " .. string.Comma(stock)
				.. " units available."
		end
		local volume = math.max(1, math.floor(tonumber(definition.volume) or 1))
		if N.CargoUsed() + amount * volume > N.FleetCargoCapacity() then
			return false, "The cargo hold lacks space for that order."
		end
		local total = buyPrice * amount
		local ok, message = N.Spend({ funding = total },
			"Purchased " .. amount .. " " .. definition.label, ply)
		if not ok then return false, message end
		local accepted = N.AddCargo(commodityKey, amount)
		if accepted ~= amount then
			N.ChangeResources({ funding = total },
				"Cargo purchase reversed", ply, true)
			if accepted > 0 then N.RemoveCargo(commodityKey, accepted) end
			return false, "The cargo order could not be loaded."
		end
		market.stock[economyKey] = stock - amount
		market.activity = "loading " .. tostring(definition.manifest or definition.label)
		if market.kind == "planet" then
			local economy = G.GalaxyEconomyFor(market.planetKey)
			if economy then economy.activity = market.activity end
		end
		markMarketChanged(market)
		N.AddLog("trade", "Cargo purchased at " .. market.name,
			amount .. " " .. definition.label .. " for CR " .. string.Comma(total), ply)
		return true, "Purchased " .. amount .. " " .. definition.label
			.. " for CR " .. string.Comma(total) .. "."
	elseif direction == "sell" then
		local held = math.max(0,
			math.floor(tonumber(N.FleetState.cargoHold[commodityKey]) or 0))
		if held < amount then
			return false, "The cargo hold only contains " .. string.Comma(held)
				.. " units."
		end
		local total = sellPrice * amount
		local maximum = tonumber(naval.ResourceMaximums
			and naval.ResourceMaximums.funding) or 999999999
		if (tonumber(N.State.resources.funding) or 0) + total > maximum then
			return false, "The fleet funding account cannot accept the full sale value."
		end
		N.RemoveCargo(commodityKey, amount)
		N.ChangeResources({ funding = total },
			"Sold " .. amount .. " " .. definition.label, ply, true)
		market.stock[economyKey] = math.min(200, stock + amount)
		market.activity = "receiving " .. tostring(definition.manifest or definition.label)
		if market.kind == "planet" then
			local economy = G.GalaxyEconomyFor(market.planetKey)
			if economy then economy.activity = market.activity end
		end
		markMarketChanged(market)
		N.AddLog("trade", "Cargo sold at " .. market.name,
			amount .. " " .. definition.label .. " for CR " .. string.Comma(total), ply)
		return true, "Sold " .. amount .. " " .. definition.label
			.. " for CR " .. string.Comma(total) .. "."
	end
	return false, "Unknown trade instruction."
end

local function commandAllowed(ply)
	if not IsValid(ply) then return true end
	if not N.CanUseConsole or not N.CanUseConsole(ply) then return false end
	if N.IsNavalOfficer and N.IsNavalOfficer(ply) then return true end
	for _, station in ipairs({ "command", "logistics", "flight_control" }) do
		local watch = N.State.watches[N.CleanKey(station)]
		if watch and watch.steamID == ply:SteamID64() then return true end
	end
	return false
end

local function fleetSnapshot(ply, feedback, feedbackOK)
	local ships = {}
	for _, record in pairs(N.FleetState.ships or {}) do
		local definition = N.FleetDefinition(record.shipType) or {}
		local destination = G.Planets and G.Planets[record.destinationKey]
		ships[#ships + 1] = {
			id = record.id,
			shipType = record.shipType,
			name = record.name,
			className = definition.label or record.shipType,
			status = record.status,
			destination = destination and destination.name or record.destinationKey,
			missionEndsAt = record.missionEndsAt,
			missions = record.missions,
			salvageMissions = record.salvageMissions,
			salvageName = record.salvageName,
			groundVehicleCapacity = tonumber(definition.groundVehicleCapacity) or 0,
			fireSupportDamage = tonumber(definition.fireSupportDamage) or 0,
			cargoCapacity = tonumber(definition.cargoCapacity) or 0,
		}
	end
	table.sort(ships, function(a, b) return a.name < b.name end)
	local definitions = {}
	for shipType, definition in pairs(naval.FleetShipDefinitions or {}) do
		definitions[#definitions + 1] = {
			id = shipType,
			label = definition.label,
			description = definition.description,
			cost = table.Copy(definition.cost or {}),
			maxOwned = tonumber(definition.maxOwned) or 99,
			owned = ownedTypeCount(shipType),
			groundVehicleCapacity = tonumber(definition.groundVehicleCapacity) or 0,
			fireSupportDamage = tonumber(definition.fireSupportDamage) or 0,
			cargoCapacity = tonumber(definition.cargoCapacity) or 0,
			modelAvailable = resolveFleetModel(definition) ~= nil,
		}
	end
	table.sort(definitions, function(a, b) return a.label < b.label end)
	local tiers = {}
	for tier, definition in pairs(naval.RegimentalSkillTiers or {}) do
		if definition.enabled ~= false then
			tiers[#tiers + 1] = {
				tier = tonumber(tier) or 1,
				label = definition.label,
				requiredFunding = tonumber(definition.requiredFunding) or 0,
				enabled = true,
			}
		end
	end
	table.sort(tiers, function(a, b) return a.tier < b.tier end)
	local formations = {}
	for _, formationID in ipairs(naval.FleetFormationOrder or {}) do
		local definition = formationDefinition(formationID)
		if definition then
			formations[#formations + 1] = {
				id = N.CleanKey(formationID),
				label = definition.label,
				description = definition.description,
			}
		end
	end
	local planet = currentPlanet()
	local market = tradeMarket(ply)
	local marketSnapshot = {
		available = market ~= nil,
		name = market and market.name or "NO MARKET LINK",
		activity = market and market.activity
			or "Hail a trader or enter an inhabited system to exchange cargo.",
		commodities = {},
	}
	for _, key in ipairs(commodityKeys()) do
		local definition = N.TradeCommodity(key)
		local stock = market and commodityMarketStock(market, key) or 0
		local buyPrice, sellPrice = commodityPrices(market, key)
		marketSnapshot.commodities[#marketSnapshot.commodities + 1] = {
			key = key,
			label = definition.label or key,
			manifest = definition.manifest or "",
			volume = math.max(1,
				math.floor(tonumber(definition.volume) or 1)),
			stock = stock,
			held = math.max(0, math.floor(tonumber(
				N.FleetState.cargoHold[key]) or 0)),
			buyPrice = buyPrice,
			sellPrice = sellPrice,
			buyable = definition.buyable ~= false,
		}
	end
	return {
		revision = N.FleetState.revision,
		serverTime = os.time(),
		resources = table.Copy(N.State.resources or {}),
		ships = ships,
		definitions = definitions,
		destinations = supplyDestinations(),
		maximumShips = tonumber(naval.FleetMaximumShips) or 6,
		currentPlanet = planet and planet.name or "Deep Space",
		canPurchaseHere = N.IsFleetPurchasePlanet(planet),
		canManage = commandAllowed(ply),
		groundVehicleCapacity = N.FleetVehicleCapacity(),
		cargoHold = table.Copy(N.FleetState.cargoHold or {}),
		cargoUsed = N.CargoUsed(),
		cargoCapacity = N.FleetCargoCapacity(),
		market = marketSnapshot,
		wrecks = salvageWrecks(),
		selectedTab = IsValid(ply) and ply.mb_navalFleetTab or "",
		regimentalTier = N.RegimentalUnlockedTier(),
		regimentalTiers = tiers,
		formation = cleanFormation(N.FleetState.formation),
		formationRange = cleanFormationRange(N.FleetState.formationRange),
		formationMinimumRange = tonumber(naval.FleetFormationMinimumRange) or 18,
		formationMaximumRange = tonumber(naval.FleetFormationMaximumRange) or 72,
		formations = formations,
		feedback = feedback,
		feedbackOK = feedbackOK == true,
	}
end

function N.FleetConsoleSessionValid(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if N.CanUseConsole and not N.CanUseConsole(ply) then return false end
	local terminal = ply.mb_navalFleetConsole
	if not IsValid(terminal)
	or terminal:GetClass() ~= "mb_fleet_logistics_console" then return false end
	local range = math.max(80, tonumber(naval.FleetConsoleUseRange) or 240)
	return ply:GetPos():DistToSqr(terminal:GetPos()) <= range * range
end

function N.UseFleetConsole(ply, terminal)
	if not IsValid(ply) or not IsValid(terminal)
	or terminal:GetClass() ~= "mb_fleet_logistics_console" then return false end
	if (terminal.mb_nextUse or 0) > CurTime() then return false end
	terminal.mb_nextUse = CurTime() + 0.35
	if not N.CanUseConsole or not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		terminal:EmitSound("buttons/button10.wav", 55, 92, 0.5)
		return false
	end
	local range = math.max(80, tonumber(naval.FleetConsoleUseRange) or 240)
	if ply:GetPos():DistToSqr(terminal:GetPos()) > range * range then return false end
	ply.mb_navalFleetConsole = terminal
	N.SendFleetPanel(ply)
	terminal:EmitSound("buttons/lightswitch2.wav", 55, 105, 0.45)
	return true
end

function N.SendFleetPanel(ply, feedback, feedbackOK)
	if not IsValid(ply) then return end
	if N.CanUseConsole and not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		return
	end
	if not N.FleetConsoleSessionValid(ply) then
		MilBase.Notify(ply,
			"Remain at the Fleet Logistics console to access fleet controls.", "warn")
		return
	end
	local json = util.TableToJSON(fleetSnapshot(ply, feedback, feedbackOK), false) or "{}"
	local compressed = util.Compress(json)
	if not compressed then return end
	net.Start(NET_OPEN)
		net.WriteUInt(#compressed, 32)
		net.WriteData(compressed, #compressed)
	net.Send(ply)
end

net.Receive(NET_ACTION, function(_, ply)
	if not IsValid(ply) or not ply:Alive() then return end
	if N.CanUseConsole and not N.CanUseConsole(ply) then
		MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
		return
	end
	if not N.FleetConsoleSessionValid(ply) then
		MilBase.Notify(ply,
			"Fleet controls disconnected: return to the Fleet Logistics console.", "warn")
		return
	end
	if (ply.mb_navalFleetActionAt or 0) > CurTime() then return end
	ply.mb_navalFleetActionAt = CurTime() + 0.35
	local action = N.CleanKey(net.ReadString())
	local primary = string.sub(net.ReadString(), 1, 96)
	local secondary = string.sub(net.ReadString(), 1, 96)
	if action == "refresh" then
		N.SendFleetPanel(ply)
		return
	end
	if not commandAllowed(ply) then
		N.SendFleetPanel(ply,
			"Fleet changes require Command, Logistics or Fleet Operations authority.", false)
		return
	end
	local ok, message
	if action == "buy" then
		ok, message = N.PurchaseFleetShip(ply, primary)
	elseif action == "mission" then
		ok, message = N.DispatchFleetSupplyMission(ply, primary, secondary)
	elseif action == "salvage" then
		ok, message = N.DispatchFleetSalvageMission(ply, primary, secondary)
	elseif action == "trade_buy" then
		ok, message = N.TradeCargo(ply, "buy", primary, secondary)
	elseif action == "trade_sell" then
		ok, message = N.TradeCargo(ply, "sell", primary, secondary)
	elseif action == "formation" then
		ok, message = N.SetFleetFormation(ply, primary, secondary)
	else
		ok, message = false, "Unknown fleet order."
	end
	N.SendFleetPanel(ply, message, ok)
end)

hook.Add("PlayerSay", "MilBase.Naval.FleetPanelCommand", function(ply, text)
	local lower = string.lower(string.Trim(text or ""))
	if lower == "/fleet" or lower == "!fleet" or lower == "/navalfleet" then
		MilBase.Notify(ply,
			"Fleet controls are available from the Fleet Logistics console.", "warn")
		return ""
	end
end)

if G and G.RequestSkyboxVolley and not G.mb_ownedFleetVolleyWrapped then
	G.mb_ownedFleetVolleyWrapped = true
	local baseVolley = G.RequestSkyboxVolley
	G.RequestSkyboxVolley = function(ply, target)
		local ok, message = baseVolley(ply, target)
		if not ok or not IsValid(target) then return ok, message end
		local delay = 0.55
		for id, record in pairs(N.FleetState.ships or {}) do
			local definition = N.FleetDefinition(record.shipType)
			local supportDamage = tonumber(definition and definition.fireSupportDamage) or 0
			local supportShip = N.FleetEntities[id]
			if record.status == "following" and supportDamage > 0 and IsValid(supportShip) then
				timer.Simple(delay, function()
					if not IsValid(target) or not IsValid(supportShip) then return end
					local impact = target:WorldSpaceCenter() + VectorRand()
						* math.max(8, tonumber(target:GetCombatRadius()) or 32) * 0.2
					G.EmitLaser(supportShip:WorldSpaceCenter(), impact,
						Color(75, 150, 255), 5)
					local info = DamageInfo()
					info:SetDamage(supportDamage * N.PowerFactor("weapons"))
					info:SetAttacker(IsValid(ply) and ply or supportShip)
					info:SetInflictor(supportShip)
					info:SetDamagePosition(impact)
					info:SetDamageType(DMG_ENERGYBEAM)
					target.mb_galaxyFleetVolleyDamage = true
					target:TakeDamageInfo(info)
					if IsValid(target) then target.mb_galaxyFleetVolleyDamage = nil end
				end)
				delay = delay + 0.18
			end
		end
		return ok, message
	end
end

timer.Create("MilBase.Naval.FleetSimulation", 5, 0, function()
	if not fleetLoaded then return end
	local now = os.time()
	for _, record in pairs(N.FleetState.ships) do
		if record.status == "supply_mission"
		and now >= (tonumber(record.missionEndsAt) or 0) then
			completeMission(record)
		elseif record.status == "salvage_mission" then
			local wreck = Entity(math.max(0,
				math.floor(tonumber(record.salvageTarget) or 0)))
			if not IsValid(wreck) or not wreck.mb_galaxySalvage
			or wreck.mb_navalSalvageReservedBy ~= record.id then
				cancelSalvageMission(record)
			elseif (tonumber(record.missionEndsAt) or 0) > 0
			and now >= (tonumber(record.missionEndsAt) or 0) then
				completeSalvageMission(record)
			end
		end
	end
	N.UpdateRegimentalFundingTier(false)
	N.SyncFleetVisuals()
	if dirtyAt and CurTime() >= dirtyAt then N.SaveFleetState() end
end)

hook.Add("PostCleanupMap", "MilBase.Naval.RestoreOwnedFleet", function()
	timer.Simple(2, function() if fleetLoaded then N.SyncFleetVisuals() end end)
end)
hook.Add("ShutDown", "MilBase.Naval.SaveFleet", function()
	if dirtyAt then N.SaveFleetState() end
end)
