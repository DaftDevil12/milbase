-- Immersion effects: injury desaturation, bleed pulse, no killfeed,
-- optional no crosshair. Painkillers suppress the pain effects.

local cfg = MilBase.Config

-- Milsim servers don't announce kills.
hook.Add("DrawDeathNotice", "MilBase.HideKillfeed", function()
	if cfg.HideKillfeed then return false end
end)

hook.Add("HUDShouldDraw", "MilBase.HideCrosshair", function(name)
	if cfg.HideCrosshair and name == "CHudCrosshair" then return false end
end)

local colorMod = {
	["$pp_colour_addr"] = 0,
	["$pp_colour_addg"] = 0,
	["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = 0,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 1,
	["$pp_colour_mulr"] = 0,
	["$pp_colour_mulg"] = 0,
	["$pp_colour_mulb"] = 0,
}

hook.Add("RenderScreenspaceEffects", "MilBase.InjuryEffects", function()
	local ply = LocalPlayer()
	if not IsValid(ply) or not ply:Alive() then return end

	local wounded = ply:GetNWBool("mb_wounded", false)
	local bleeding = ply:GetNWBool("mb_bleeding", false)
	local painkillers = ply:GetNWFloat("mb_painkillers", 0) > CurTime()
	local frac = math.Clamp(ply:Health() / math.max(ply:GetMaxHealth(), 1), 0, 1)

	local desat, brightness, red = 0, 0, 0

	if wounded then
		-- Face down in the dirt: the world drains almost completely.
		desat, brightness, red = 0.85, -0.05, 0.03
	elseif frac < 0.4 and not painkillers then
		local t = 1 - frac / 0.4
		desat = 0.55 * t
		brightness = -0.02 * t
		red = 0.03 * t
	end

	-- A slow red pulse while bleeding (painkillers don't stop blood loss).
	if bleeding and not wounded then
		red = math.max(red, 0.025 + 0.02 * math.sin(RealTime() * 4))
	end

	if desat <= 0 and red <= 0 then return end

	colorMod["$pp_colour_colour"] = 1 - desat
	colorMod["$pp_colour_brightness"] = brightness
	colorMod["$pp_colour_addr"] = red
	DrawColorModify(colorMod)
end)
