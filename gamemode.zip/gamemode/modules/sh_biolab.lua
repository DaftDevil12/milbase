--[[
	Bio-lab: the medic counter-play to the disease system (sh_disease.lua).

	Take a sample from an infected patient (C + right-click -> Take Bio Sample),
	analyze samples at an mb_analyzer (each analysis reveals a virus component);
	once every component of a virus is identified, synthesize a Cure Serum +
	Cure Canister at the analyzer. Administer the serum to a patient (C +
	right-click), or release the canister into the vents (self-menu) to cure
	everyone whose suit isn't sealed.
]]

local cfg = MilBase.Config

-- Unique effect ids that make up a virus (its "components" to identify).
function MilBase.VirusComponents(v)
	local out, seen = {}, {}
	for _, phase in pairs((v and v.phases) or {}) do
		for eid in pairs(phase.effects or {}) do
			if not seen[eid] then seen[eid] = true; out[#out + 1] = eid end
		end
	end
	return out
end

-- Inventory count that works in both realms.
local function countItem(ply, id)
	if SERVER then return MilBase.CountItem(ply, id) end
	local inv, n = MilBase.LocalInv, 0
	local pools = { inv.items }
	if inv.pack then pools[#pools + 1] = inv.pack.items end
	for _, pool in ipairs(pools) do
		for _, it in ipairs(pool or {}) do
			if it.id == id then n = n + (it.amount or 1) end
		end
	end
	return n
end

--------------------------------------------------------------------------
-- Take Bio Sample: hold [E] on an infected patient (quick interaction).
-- Administer Cure stays on the C + right-click player menu.
--------------------------------------------------------------------------

MilBase.RegisterQuickInteraction("bio_sample", {
	name = "Take Bio Sample",
	order = 40,
	visible = function(lp, target)
		return target:GetNWBool("mb_infected", false) and countItem(lp, "sample_kit") > 0
	end,
	run = function(ply, target)
		if MilBase.CountItem(ply, "sample_kit") <= 0 then return end
		local vid = target:GetNWString("mb_virus", "")
		if vid == "" then MilBase.Notify(ply, "That patient isn't infected."); return end

		ply.mb_samples = ply.mb_samples or {}
		if #ply.mb_samples >= 8 then MilBase.Notify(ply, "Your sample case is full."); return end
		table.insert(ply.mb_samples, vid)
		target:EmitSound("items/medshot4.wav", 60)
		MilBase.Notify(ply, "Sample taken (" .. #ply.mb_samples .. "). Analyze it at a Bio-Analyzer.")
	end,
})

MilBase.RegisterPlayerAction("bio_cure", {
	name = "Administer Cure",
	order = 41,
	visible = function(lp, target)
		return target:GetNWBool("mb_infected", false) and countItem(lp, "cure") > 0
	end,
	run = function(ply, target)
		if MilBase.CountItem(ply, "cure") <= 0 then return end
		if target:GetNWString("mb_virus", "") == "" then return end
		MilBase.TakeItem(ply, "cure", 1)
		MilBase.Cure(target)
		MilBase.Notify(target, "You've been cured.")
		MilBase.Notify(ply, "Cure administered to " .. target:MBName() .. ".")
	end,
})

--------------------------------------------------------------------------
-- Server: analyzer flow + vent flush
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_AnalyzeGame")
	util.AddNetworkString("MilBase_AnalyzeDone")

	MilBase.VirusResearch = MilBase.VirusResearch or {}

	-- Called by mb_analyzer:Use.
	function MilBase.AnalyzerUse(ply, ent)
		ply.mb_samples = ply.mb_samples or {}

		if #ply.mb_samples > 0 then
			local vid = table.remove(ply.mb_samples, 1)
			net.Start("MilBase_AnalyzeGame")
				net.WriteEntity(ent)
				net.WriteString(vid)
			net.Send(ply)
			return
		end

		-- No samples: synthesize a cure from any fully-analyzed virus.
		for vid, r in pairs(MilBase.VirusResearch) do
			if r.complete and MilBase.Viruses[vid] then
				MilBase.GiveItem(ply, "cure", 3)
				MilBase.GiveItem(ply, "cure_canister", 1)
				ent:EmitSound("items/suitchargeok1.wav", 72)
				MilBase.Notify(ply, "Synthesized a cure for " .. (MilBase.Viruses[vid].name or vid) .. ".")
				return
			end
		end

		MilBase.Notify(ply, "Take a sample from an infected patient first, or fully analyze a virus to synthesize a cure.")
	end

	net.Receive("MilBase_AnalyzeDone", function(_, ply)
		local ent = net.ReadEntity()
		local vid = net.ReadString()
		if not IsValid(ent) or ent:GetClass() ~= "mb_analyzer" then return end
		if ent:GetPos():DistToSqr(ply:GetPos()) > 150 * 150 then return end
		local v = MilBase.Viruses[vid]
		if not v then return end

		local comps = MilBase.VirusComponents(v)
		local r = MilBase.VirusResearch[vid] or { discovered = {}, count = 0 }
		MilBase.VirusResearch[vid] = r

		local undiscovered = {}
		for _, eid in ipairs(comps) do
			if not r.discovered[eid] then undiscovered[#undiscovered + 1] = eid end
		end
		for _ = 1, math.min(cfg.DiseaseComponentsPerAnalysis or 1, #undiscovered) do
			local eid = table.remove(undiscovered, math.random(#undiscovered))
			r.discovered[eid] = true
			r.count = r.count + 1
		end

		if #comps > 0 and r.count >= #comps then
			r.complete = true
			MilBase.ChatMsg(nil, Color(120, 200, 140), "[BIO-LAB] ", color_white,
				(v.name or vid) .. " fully analyzed — synthesize a cure at the analyzer (use it with no sample).")
		else
			MilBase.Notify(ply, "Component identified — " .. r.count .. " / " .. #comps
				.. " for " .. (v.name or vid) .. ".")
		end
	end)

	-- Vent flush: cure every unsealed player in range (self-menu).
	MilBase.RegisterSelfAction("ventcure", {
		name = "Release Cure Canister (vents)",
		order = 30,
		visible = function(lp) return countItem(lp, "cure_canister") > 0 end,
		run = function(ply)
			if MilBase.CountItem(ply, "cure_canister") <= 0 then return end
			MilBase.TakeItem(ply, "cure_canister", 1)

			local range = cfg.VentCureRange or 0
			local n = 0
			for _, other in ipairs(player.GetAll()) do
				if other:Alive() and not other:GetNWBool("mb_sealed", false)
				and other:GetNWString("mb_virus", "") ~= ""
				and (range <= 0 or other:GetPos():DistToSqr(ply:GetPos()) <= range * range) then
					MilBase.Cure(other)
					n = n + 1
				end
			end
			MilBase.ChatMsg(nil, Color(120, 200, 140), "[BIO-LAB] ", color_white,
				ply:MBName() .. " released a cure through the vents — " .. n
				.. " cured (sealed suits unaffected).")
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client: analysis minigame
--------------------------------------------------------------------------

net.Receive("MilBase_AnalyzeGame", function()
	local ent = net.ReadEntity()
	local vid = net.ReadString()
	if not IsValid(ent) then return end

	MilBase.OpenCodeMinigame({
		title = "SAMPLE ANALYSIS",
		subtitle = "Sequence the pathogen to identify a component.",
		color = Color(120, 200, 140),
		lines = MilBase.GenCodeLines(4),
		valid = function()
			return IsValid(ent) and ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 150 * 150
		end,
		onSuccess = function()
			net.Start("MilBase_AnalyzeDone")
				net.WriteEntity(ent)
				net.WriteString(vid)
			net.SendToServer()
		end,
	})
end)

-- Prompt when aiming at an analyzer.
hook.Add("HUDPaint", "MilBase.AnalyzerHUD", function()
	local lp = LocalPlayer()
	if not IsValid(lp) or not lp:Alive() then return end
	local ent = lp:GetEyeTrace().Entity
	if not IsValid(ent) or ent:GetClass() ~= "mb_analyzer" then return end
	if ent:GetPos():DistToSqr(lp:GetPos()) > 160 * 160 then return end

	local screen = (ent:GetPos() + Vector(0, 0, 30)):ToScreen()
	if not screen.visible then return end
	draw.SimpleTextOutlined("BIO-ANALYZER — [E] analyze sample / synthesize cure", "MB.Tiny",
		screen.x, screen.y, MilBase.UI.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
end)
