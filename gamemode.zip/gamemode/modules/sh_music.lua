--[[
	MUSIC F4 tab (staff only): play a YouTube link, or any direct audio URL
	(mp3 / ogg / aac / internet-radio stream) to everyone on the server.

	- YouTube links play through an offscreen DHTML panel using the YouTube
	  IFrame API (so we can set volume / stop / seek late joiners).
	- Anything that isn't a recognised YouTube link falls back to
	  sound.PlayURL - the "mp3 fallback" - which streams the raw audio.

	The staff-set master volume is broadcast; each player then scales it with
	their own personal volume + mute (client convars) so nobody is forced to
	listen at a fixed level. Playback state is authoritative on the server and
	re-synced to late joiners.

	All actions are re-validated server-side. Staff level gate:
	cfg.MusicStaffLevel (config/sh_config.lua).
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Shared: parse a YouTube video id out of a URL. Returns id or nil.
--------------------------------------------------------------------------

function MilBase.ParseYouTubeID(url)
	if not isstring(url) then return nil end
	url = string.Trim(url)

	-- youtu.be/<id>
	local id = string.match(url, "youtu%.be/([%w_%-]+)")
	if id then return id end
	-- youtube.com/watch?v=<id>  (or &v=)
	id = string.match(url, "[?&]v=([%w_%-]+)")
	if id then return id end
	-- youtube.com/embed/<id>  or  /shorts/<id>  or  /live/<id>
	id = string.match(url, "youtube%.com/embed/([%w_%-]+)")
		or string.match(url, "youtube%.com/shorts/([%w_%-]+)")
		or string.match(url, "youtube%.com/live/([%w_%-]+)")
	if id then return id end

	return nil
end

--------------------------------------------------------------------------
-- SERVER: authoritative "now playing" state + the action net
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_Music")

	-- kind: "" (nothing) | "youtube" | "stream"
	MilBase.MusicState = MilBase.MusicState or {
		playing   = false,
		kind      = "",
		ref       = "",   -- youtube video id, or the stream URL
		title     = "",
		master    = 60,   -- staff-set master volume 0-100
		startTime = 0,    -- CurTime() when it started (for late-join seek)
		seq       = 0,    -- bumped every change so clients can dedupe
	}

	local function level(ply) return ply:MBStaffLevel() end

	local function broadcast(target)
		local s = MilBase.MusicState
		net.Start("MilBase_Music")
			net.WriteUInt(s.seq, 32)
			net.WriteBool(s.playing)
			net.WriteString(s.kind)
			net.WriteString(s.ref)
			net.WriteString(s.title)
			net.WriteUInt(math.Clamp(s.master, 0, 100), 7)
			-- elapsed seconds, so a late joiner can seek a YouTube track
			net.WriteUInt(math.Clamp(math.floor(CurTime() - s.startTime), 0, 86400), 24)
		if target then net.Send(target) else net.Broadcast() end
	end
	MilBase.BroadcastMusic = broadcast

	net.Receive("MilBase_Music", function(_, ply)
		local action = net.ReadString()

		-- Anyone may ask for a resync (used by late joiners); everything
		-- else needs the staff level.
		if action == "request" then
			broadcast(ply)
			return
		end

		if level(ply) < (cfg.MusicStaffLevel or 1) then return end
		if (ply.mb_nextMusic or 0) > CurTime() then return end
		ply.mb_nextMusic = CurTime() + 0.25

		local s = MilBase.MusicState

		if action == "play" then
			local kind  = net.ReadString()
			local ref   = string.Trim(net.ReadString())
			local title = string.Trim(net.ReadString())
			local vol   = math.Clamp(net.ReadUInt(7), 0, 100)
			if ref == "" then return end
			if kind ~= "youtube" and kind ~= "stream" then return end

			s.playing, s.kind, s.ref = true, kind, ref
			s.title = title ~= "" and title or (kind == "youtube" and "YouTube track" or ref)
			s.master = vol
			s.startTime = CurTime()
			s.seq = s.seq + 1
			broadcast()

			MilBase.ChatMsg(nil, Color(150, 110, 220), "[MUSIC] ", color_white,
				ply:MBName() .. " is now playing: ", Color(200, 200, 255), s.title)
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(ply) .. " played music: " .. s.title
					.. " (" .. kind .. ")", ply)
			end

		elseif action == "stop" then
			if not s.playing then return end
			s.playing = false
			s.seq = s.seq + 1
			broadcast()
			MilBase.ChatMsg(nil, Color(150, 110, 220), "[MUSIC] ", color_white,
				"Music stopped by " .. ply:MBName() .. ".")
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(ply) .. " stopped the music", ply)
			end

		elseif action == "volume" then
			local vol = math.Clamp(net.ReadUInt(7), 0, 100)
			s.master = vol
			s.seq = s.seq + 1
			broadcast()
		end
	end)

	-- Late joiners get the current track once they're in.
	hook.Add("PlayerInitialSpawn", "MilBase.MusicSync", function(ply)
		timer.Simple(4, function()
			if IsValid(ply) and MilBase.MusicState.playing then broadcast(ply) end
		end)
	end)

	return
end

--------------------------------------------------------------------------
-- CLIENT: playback engine (independent of the F4 menu being open)
--------------------------------------------------------------------------

CreateClientConVar("mb_music_volume", "100", true, false, "Personal music volume (0-100)", 0, 100)
CreateClientConVar("mb_music_mute",   "0",   true, false, "Mute staff music", 0, 1)

MilBase.Music = MilBase.Music or {
	seq     = -1,
	kind    = "",
	channel = nil,   -- IGModAudioChannel for streams
	html    = nil,   -- DHTML for YouTube
	master  = 60,    -- last staff-set master volume
}

local M = MilBase.Music

-- Effective 0-1 gain: staff master * personal volume, or 0 if muted.
local function effFrac()
	if GetConVar("mb_music_mute"):GetBool() then return 0 end
	local personal = math.Clamp(GetConVar("mb_music_volume"):GetInt(), 0, 100) / 100
	return math.Clamp(M.master, 0, 100) / 100 * personal
end

local function applyVolume()
	if IsValid(M.channel) then
		M.channel:SetVolume(effFrac())
	end
	if IsValid(M.html) then
		-- The hosted wrapper page exposes a MediaPlayer JS object (0-100).
		local v = math.floor(effFrac() * 100)
		-- Stay silent while the pre-roll ad guard window is active.
		if M.html.mbUnmuteAt and CurTime() < M.html.mbUnmuteAt then v = 0 end
		M.html:RunJavascript("if(window.MediaPlayer)MediaPlayer.setVolume(" .. v .. ");")
	end
end
MilBase.ApplyMusicVolume = applyVolume

local function stopPlayback()
	if IsValid(M.channel) then M.channel:Stop() end
	M.channel = nil
	if IsValid(M.html) then M.html:Remove() end
	M.html = nil
	M.kind = ""
end
MilBase.StopMusicPlayback = stopPlayback

-- Direct audio URL (mp3 / ogg / aac / radio) via the game's audio streamer.
local function playStream(url)
	sound.PlayURL(url, "noblock", function(chan, errID, errName)
		if not IsValid(chan) then
			-- Only surface the error to staff so players aren't spammed.
			if LocalPlayer():MBStaffLevel() >= (cfg.MusicStaffLevel or 1) then
				MilBase.Notify(LocalPlayer(), "Music stream failed: " .. (errName or ("#" .. tostring(errID))), "danger")
			end
			return
		end
		-- A newer track may have started while this was loading.
		if M.kind ~= "stream" or M.channel ~= nil then chan:Stop() return end
		M.channel = chan
		chan:SetVolume(effFrac())
		chan:Play()
	end)
end

-- Base URL of a hosted YouTube wrapper page. YouTube refuses to play when the
-- embedding origin isn't a real http(s) site (a SetHTML / about:blank page is
-- rejected with error 150/153), so - exactly like the Media Player addon - we
-- OpenURL a wrapper hosted on a real origin. The wrapper autoplays the video
-- and exposes a MediaPlayer JS object (setVolume/play/pause/seek, 0-100).
--
-- Default is the public gm-mediaplayer page (stable for years). If the Media
-- Player addon is mounted we reuse its configured host; override with
-- cfg.MusicHTMLBaseURL to self-host.
local function ytBaseURL()
	if MediaPlayer and MediaPlayer.GetConfigValue then
		local b = MediaPlayer.GetConfigValue("html.base_url")
		if isstring(b) and b ~= "" then return b end
	end
	local b = cfg.MusicHTMLBaseURL
	if isstring(b) and b ~= "" then return b end
	return "http://samuelmaddock.github.io/gm-mediaplayer/"
end

-- YouTube via an offscreen DHTML panel pointed at the hosted wrapper page.
-- Parked offscreen (but :IsVisible() true) so nothing shows yet CEF keeps the
-- page active and audio running.
local function playYouTube(videoId, startSecs)
	local html = vgui.Create("DHTML")
	html:SetSize(320, 180)
	html:SetPos(-4000, -4000)
	html:SetMouseInputEnabled(false)
	html:SetKeyboardInputEnabled(false)
	M.html = html

	local base = ytBaseURL()
	if string.sub(base, -1) ~= "/" then base = base .. "/" end
	local u = base .. "youtube.html?v=" .. videoId .. "&timed=1"
	if (startSecs or 0) > 3 then u = u .. "&start=" .. math.floor(startSecs) end
	html:OpenURL(u)

	-- Optionally stay muted through a typical pre-roll ad, then come up to
	-- volume. YouTube embeds expose no ad signal, so this is a timed guard
	-- (cfg.MusicYouTubeAdMute seconds), not real ad detection.
	local guard = math.max(0, tonumber(cfg.MusicYouTubeAdMute) or 0)
	html.mbUnmuteAt = guard > 0 and (CurTime() + guard) or nil

	-- The page autoplays on load; nudge volume as the player initializes and
	-- again just after the guard window ends (applyVolume respects mbUnmuteAt).
	for _, t in ipairs({ 0.5, 1.5, 3, 5, guard + 0.2, guard + 1.5 }) do
		if t > 0 then timer.Simple(t, applyVolume) end
	end
end

-- Apply a freshly-received state.
local function applyState(playing, kind, ref, startSecs)
	stopPlayback()
	if not playing then return end
	M.kind = kind
	if kind == "youtube" then
		playYouTube(ref, startSecs)
	elseif kind == "stream" then
		playStream(ref)
	end
	applyVolume()
end

net.Receive("MilBase_Music", function()
	local seq     = net.ReadUInt(32)
	local playing = net.ReadBool()
	local kind    = net.ReadString()
	local ref     = net.ReadString()
	local title   = net.ReadString()
	local master  = net.ReadUInt(7)
	local elapsed = net.ReadUInt(24)

	M.title  = title
	M.master = master

	-- Same sequence = only a volume/meta refresh, don't restart playback.
	if seq == M.seq then
		applyVolume()
		return
	end
	M.seq = seq

	applyState(playing, kind, ref, elapsed)
	MilBase.MusicPlaying = playing
	hook.Run("MilBase.MusicChanged")
end)

-- Personal volume / mute react live.
cvars.AddChangeCallback("mb_music_volume", function() applyVolume() end, "MilBase.Music")
cvars.AddChangeCallback("mb_music_mute",   function() applyVolume() end, "MilBase.Music")

-- Ask the server for the current track on join / gamemode reload.
hook.Add("InitPostEntity", "MilBase.MusicRequest", function()
	timer.Simple(2, function()
		net.Start("MilBase_Music") net.WriteString("request") net.SendToServer()
	end)
end)

--------------------------------------------------------------------------
-- CLIENT: the MUSIC tab
--------------------------------------------------------------------------

local function send(action, writer)
	net.Start("MilBase_Music")
		net.WriteString(action)
		if writer then writer() end
	net.SendToServer()
end

-- A small BF2-styled action button (mirrors sh_stafftab.lua).
local function actionBtn(parent, label, accent, onClick)
	local ui = MilBase.UI
	local b = vgui.Create("DButton", parent)
	b:SetText("")
	b.Paint = function(s, w, h)
		local col = accent or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = s:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised,
			accent = col })
		if s:IsHovered() then MilBase.DrawBrackets(2, 2, w - 4, h - 4, col, 6) end
		draw.SimpleText(label, "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	b.DoClick = onClick
	return b
end

-- A minimal draggable 0-100 slider. onChange(value) fires while dragging.
local function makeSlider(parent, getValue, onChange)
	local ui = MilBase.UI
	local s = vgui.Create("DPanel", parent)
	local dragging = false

	local function setFromX(x)
		local frac = math.Clamp(x / s:GetWide(), 0, 1)
		onChange(math.Round(frac * 100))
	end

	s.OnMousePressed = function(self, key)
		if key ~= MOUSE_LEFT then return end
		dragging = true
		self:MouseCapture(true)
		setFromX(self:CursorPos())
	end
	s.OnMouseReleased = function(self) dragging = false self:MouseCapture(false) end
	s.OnCursorMoved   = function(self, x) if dragging then setFromX(x) end end

	s.Paint = function(self, w, h)
		local v = math.Clamp(getValue(), 0, 100) / 100
		local cy = h / 2
		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(0, cy - 2, w, 4)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 220)
		surface.DrawRect(0, cy - 2, w * v, 4)
		surface.SetDrawColor(ui.text.r, ui.text.g, ui.text.b, 255)
		surface.DrawRect(math.Clamp(w * v - 3, 0, w - 6), cy - 7, 6, 14)
	end
	return s
end

MilBase.AddMenuTab("MUSIC", 92, function(content)
	local ui = MilBase.UI
	local lp = LocalPlayer()
	local isStaff = lp:MBStaffLevel() >= (cfg.MusicStaffLevel or 1)

	local root = vgui.Create("DScrollPanel", content)
	root:Dock(FILL)

	local function section(text)
		local pnl = vgui.Create("DPanel", root)
		pnl:Dock(TOP); pnl:SetTall(24); pnl:DockMargin(0, 10, 8, 6)
		pnl.Paint = function(s, w, h)
			draw.SimpleText(text, "MB.Small", 2, h / 2, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			surface.SetFont("MB.Small")
			local tw = surface.GetTextSize(text)
			surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 45)
			surface.DrawRect(tw + 12, h / 2, math.max(0, w - tw - 14), 1)
		end
	end

	----------------------------------------------------------------
	-- NOW PLAYING
	----------------------------------------------------------------
	section("NOW PLAYING")

	local now = vgui.Create("DPanel", root)
	now:Dock(TOP); now:SetTall(52); now:DockMargin(0, 0, 8, 4)
	now.Paint = function(s, w, h)
		MilBase.PaintPanel(w, h)
		local playing = MilBase.MusicPlaying
		local title = playing and (MilBase.Music.title ~= "" and MilBase.Music.title or "Playing…") or "Nothing playing"
		draw.SimpleText(playing and "♪  " .. title or title, "MB.Small", 14, h / 2 - 9,
			playing and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local kind = MilBase.Music.kind
		local sub = playing and ("Source: " .. (kind == "youtube" and "YouTube" or "Direct stream")
			.. "   •   Master " .. math.Round(MilBase.Music.master) .. "%") or "Staff can start a track below."
		draw.SimpleText(sub, "MB.Tiny", 14, h / 2 + 9, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	----------------------------------------------------------------
	-- PERSONAL VOLUME (everyone)
	----------------------------------------------------------------
	section("YOUR VOLUME")

	local myRow = vgui.Create("DPanel", root)
	myRow:Dock(TOP); myRow:SetTall(30); myRow:DockMargin(0, 0, 8, 4); myRow.Paint = nil

	local slider = makeSlider(myRow, function() return GetConVar("mb_music_volume"):GetInt() end,
		function(v) RunConsoleCommand("mb_music_volume", tostring(v)) end)
	slider:Dock(FILL); slider:DockMargin(0, 0, 10, 0)

	local muteBtn = actionBtn(myRow, "MUTE", ui.warn, function()
		local m = not GetConVar("mb_music_mute"):GetBool()
		RunConsoleCommand("mb_music_mute", m and "1" or "0")
	end)
	muteBtn:Dock(RIGHT); muteBtn:SetWide(96)
	-- Label reflects the live mute state.
	muteBtn.Paint = function(s, w, h)
		local muted = GetConVar("mb_music_mute"):GetBool()
		local col = muted and ui.danger or ui.warn
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 6,
			color = s:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised, accent = col })
		draw.SimpleText(muted and "UNMUTE" or "MUTE", "MB.Small", w / 2, h / 2, ui.text,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	----------------------------------------------------------------
	-- STAFF CONTROLS
	----------------------------------------------------------------
	if not isStaff then return end

	section("STAFF — PLAY A TRACK")

	local hint = vgui.Create("DPanel", root)
	hint:Dock(TOP); hint:SetTall(20); hint:DockMargin(0, 0, 8, 2)
	hint.Paint = function(s, w, h)
		draw.SimpleText("Paste a YouTube link, or any direct audio URL (mp3 / ogg / aac / radio stream).",
			"MB.Tiny", 2, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local function styledEntry(placeholder)
		local e = vgui.Create("DTextEntry", root)
		e:Dock(TOP); e:SetTall(30); e:DockMargin(0, 0, 8, 4)
		e:SetFont("MB.Small"); e:SetPaintBackground(false)
		e:SetPlaceholderText(placeholder)
		e:SetUpdateOnType(true)
		e.Paint = function(self, w, h)
			surface.SetDrawColor(0, 0, 0, 150); surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
			surface.DrawOutlinedRect(0, 0, w, h)
			self:DrawTextEntryText(ui.text, ui.accent, ui.text)
		end
		return e
	end

	local urlEntry   = styledEntry("https://www.youtube.com/watch?v=…  or  https://…/track.mp3")
	local titleEntry = styledEntry("Title shown to players (optional)")

	-- Detected-source indicator.
	local detect = vgui.Create("DPanel", root)
	detect:Dock(TOP); detect:SetTall(18); detect:DockMargin(0, 0, 8, 4)
	detect.Paint = function(s, w, h)
		local url = string.Trim(urlEntry:GetValue())
		local txt, col
		if url == "" then
			txt, col = "", ui.dim
		elseif MilBase.ParseYouTubeID(url) then
			txt, col = "Detected: YouTube", ui.ok
		else
			txt, col = "Detected: direct audio stream (mp3 fallback)", ui.accent
		end
		draw.SimpleText(txt, "MB.Tiny", 2, h / 2, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- Master volume for the broadcast.
	local masterVal = math.Clamp(MilBase.Music.master or 60, 0, 100)
	local mRow = vgui.Create("DPanel", root)
	mRow:Dock(TOP); mRow:SetTall(30); mRow:DockMargin(0, 4, 8, 4); mRow.Paint = nil
	local mLabel = vgui.Create("DPanel", mRow)
	mLabel:Dock(LEFT); mLabel:SetWide(120)
	mLabel.Paint = function(s, w, h)
		draw.SimpleText("Master volume  " .. masterVal .. "%", "MB.Tiny", 2, h / 2, ui.text,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local mSlider = makeSlider(mRow, function() return masterVal end, function(v)
		masterVal = v
		if MilBase.MusicPlaying then send("volume", function() net.WriteUInt(v, 7) end) end
	end)
	mSlider:Dock(FILL)

	local btnRow = vgui.Create("DPanel", root)
	btnRow:Dock(TOP); btnRow:SetTall(38); btnRow:DockMargin(0, 4, 8, 4); btnRow.Paint = nil

	local playBtn = actionBtn(btnRow, "PLAY FOR EVERYONE", ui.ok, function()
		local url = string.Trim(urlEntry:GetValue())
		if url == "" then MilBase.Notify(lp, "Enter a URL first.", "warn") return end
		local vid = MilBase.ParseYouTubeID(url)
		local kind = vid and "youtube" or "stream"
		local ref  = vid or url
		local title = string.Trim(titleEntry:GetValue())
		send("play", function()
			net.WriteString(kind)
			net.WriteString(ref)
			net.WriteString(title)
			net.WriteUInt(masterVal, 7)
		end)
		MilBase.PlayUISound("select")
	end)
	playBtn:Dock(LEFT); playBtn:SetWide(200); playBtn:DockMargin(0, 0, 8, 0)

	local stopBtn = actionBtn(btnRow, "STOP", ui.danger, function()
		send("stop")
		MilBase.PlayUISound("select")
	end)
	stopBtn:Dock(LEFT); stopBtn:SetWide(110)

	----------------------------------------------------------------
	-- PRESETS (config-defined)
	----------------------------------------------------------------
	local presets = cfg.MusicPresets or {}
	if #presets > 0 then
		section("PRESETS")
		for _, p in ipairs(presets) do
			if not (istable(p) and p.url) then continue end
			local row = actionBtn(root, p.title or p.url, ui.accent, function()
				local vid = MilBase.ParseYouTubeID(p.url)
				send("play", function()
					net.WriteString(vid and "youtube" or "stream")
					net.WriteString(vid or p.url)
					net.WriteString(p.title or "")
					net.WriteUInt(masterVal, 7)
				end)
				MilBase.PlayUISound("select")
			end)
			row:Dock(TOP); row:SetTall(30); row:DockMargin(0, 0, 8, 4)
		end
	end
end, function(lp)
	-- Everyone sees the tab (for the personal volume control); staff also get
	-- the playback controls. If you'd rather hide it from non-staff entirely,
	-- change this to: return lp:MBStaffLevel() >= (MilBase.Config.MusicStaffLevel or 1)
	return true
end)
