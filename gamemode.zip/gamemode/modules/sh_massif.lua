--[[
	CG Massif Handler system.
	Server-authoritative deployment, AI commands, temporary possession,
	suspect scent vision, non-lethal apprehension, searches and logging.
]]

if MilBase.MassifLoaded then return end
MilBase.MassifLoaded = true

local function cfg()
	return (MilBase.Config and MilBase.Config.Massif) or {}
end

function MilBase.ResolveMassifModel()
	local c = cfg()
	for _, model in ipairs(c.Models or {}) do
		if isstring(model) and util.IsValidModel(model) then return model end
	end

	-- Model packs often register their player model under a slightly different
	-- path. Discover any mounted model whose name or path contains "massif".
	if player_manager and player_manager.AllValidModels then
		for name, model in pairs(player_manager.AllValidModels() or {}) do
			local haystack = string.lower(tostring(name) .. " " .. tostring(model))
			if string.find(haystack, "massif", 1, true) and util.IsValidModel(model) then
				return model
			end
		end
	end

	if isstring(c.FallbackModel) and util.IsValidModel(c.FallbackModel) then return c.FallbackModel end
	return "models/antlion.mdl"
end

function MilBase.PlayerCanHandleMassif(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	local c = cfg()
	if c.Enabled == false then return false end
	if ply.MBHasCert and not ply:MBHasCert(c.CertificationID or "massif_handler") then return false end
	local faction = ply.MBFaction and ply:MBFaction()
	local id = faction and string.lower(tostring(faction.id or "")) or ""
	local allowed = c.AllowedFactions or { cg = true }
	return allowed[id] == true or (faction and faction.police and allowed.police == true)
end

function MilBase.GetPlayerMassif(ply)
	if not IsValid(ply) then return NULL end
	local ent = ply:GetNWEntity("mb_massif")
	return IsValid(ent) and ent:GetClass() == "mb_massif" and ent or NULL
end

if SERVER then
	util.AddNetworkString("MilBase_MassifCommand")
	util.AddNetworkString("MilBase_MassifWheel")

	MilBase.DB.Run([[CREATE TABLE IF NOT EXISTS frontier_massif_names (
		steamid VARCHAR(32) PRIMARY KEY,
		name VARCHAR(24)
	)]])

	function MilBase.LoadMassifName(ply)
		if not IsValid(ply) then return end
		local key = ply:MBCharacterKey()
		local token = ply:MBCharacterLoadToken()
		MilBase.DB.Query(string.format(
			"SELECT name FROM frontier_massif_names WHERE steamid = %s",
			MilBase.SQLStr(key)), function(rows)
			if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			local name = rows[1] and string.Trim(tostring(rows[1].name or "")) or ""
			ply:SetNWString("mb_massif_name", string.sub(name, 1, 24))
		end, function()
			if MilBase.CharacterLoadStillCurrent(ply, key, token) then
				ply:SetNWString("mb_massif_name", "")
			end
		end)
	end

	function MilBase.LogMassif(handler, action, target)
		if cfg().LogActions == false then return end
		local handlerName = IsValid(handler) and (handler.MBName and handler:MBName() or handler:Nick()) or "unknown handler"
		local targetName = IsValid(target) and (target:IsPlayer() and (target.MBName and target:MBName() or target:Nick()) or target:GetClass()) or "none"
		ServerLog(string.format("[MASSIF] %s %s %s\n", handlerName, tostring(action), targetName))
	end

	local function activeCount()
		return #ents.FindByClass("mb_massif")
	end

	function MilBase.FindMassifSpawnPosition(ply)
		if not IsValid(ply) then return nil end
		local c = cfg()
		local mins = c.CollisionMins or Vector(-22, -18, 0)
		local maxs = c.CollisionMaxs or Vector(22, 18, 45)
		local choices = {
			ply:GetPos() - ply:GetForward() * 85 + ply:GetRight() * 55,
			ply:GetPos() - ply:GetForward() * 105 - ply:GetRight() * 55,
			ply:GetPos() + ply:GetForward() * 90 + ply:GetRight() * 55,
		}
		for _, pos in ipairs(choices) do
			local floor = util.TraceLine({ start = pos + Vector(0, 0, 48), endpos = pos - Vector(0, 0, 100), filter = ply, mask = MASK_PLAYERSOLID })
			if floor.Hit then pos = floor.HitPos end
			local blocked = util.TraceHull({ start = pos + Vector(0, 0, 2), endpos = pos + Vector(0, 0, 2), mins = mins, maxs = maxs, filter = ply, mask = MASK_PLAYERSOLID })
			if not blocked.Hit then return pos end
		end
		return nil
	end

	function MilBase.DeployMassif(ply)
		if not MilBase.PlayerCanHandleMassif(ply) then
			if MilBase.Notify then MilBase.Notify(ply, "You need the active CG Massif Handler certification.", "warn") end
			return nil
		end
		local existing = MilBase.GetPlayerMassif(ply)
		if IsValid(existing) then return existing end
		if CurTime() < (ply.mb_massifDeployAt or 0) then
			if MilBase.Notify then MilBase.Notify(ply, "Your Massif is still recovering for " .. math.ceil(ply.mb_massifDeployAt - CurTime()) .. " seconds.", "warn") end
			return nil
		end
		if activeCount() >= (cfg().MaxActiveMassifs or 12) then
			if MilBase.Notify then MilBase.Notify(ply, "The active Massif limit has been reached.", "warn") end
			return nil
		end
		local pos = MilBase.FindMassifSpawnPosition(ply)
		if not pos then
			if MilBase.Notify then MilBase.Notify(ply, "There is no clear space to deploy your Massif.", "warn") end
			return nil
		end

		local ent = ents.Create("mb_massif")
		if not IsValid(ent) then return nil end
		ent:SetPos(pos)
		ent:SetAngles(Angle(0, ply:EyeAngles().y, 0))
		ent:SetHandler(ply)
		ent:SetCreator(ply)
		ent:Spawn()
		ent:Activate()
		ply:SetNWEntity("mb_massif", ent)
		if ent:GetModel() == (cfg().FallbackModel or "models/antlion.mdl") and MilBase.Notify then
			MilBase.Notify(ply, "Massif model content is not mounted; using the configured fallback model.", "warn")
		end
		ply.mb_massifDeployAt = CurTime() + (cfg().DeployCooldown or 12)
		if MilBase.Notify then MilBase.Notify(ply, ent:GetMassifName() .. " deployed. Right-click the handler tool for commands.", "ok") end
		MilBase.LogMassif(ply, "deployed", ent)
		return ent
	end

	function MilBase.EndMassifControl(ply, reason)
		if not IsValid(ply) then return end
		local ent = ply:GetNWEntity("mb_massif_control")
		local wasControlling = IsValid(ent) and ent:GetControlled()
		if IsValid(ent) then
			ent:SetControlled(false)
			ent:SetPossessionEnds(0)
			if ent:GetCommandState() == "controlled" then ent:SetCommandState("follow") end
		end
		ply:SetNWEntity("mb_massif_control", NULL)
		ply:SetNWBool("mb_massif_controlling", false)
		ply.mb_massifInput = nil
		ply.mb_massifOldButtons = 0
		if wasControlling then
			ply.mb_massifPossessionAt = CurTime() + (cfg().PossessionCooldown or 35)
		end
		if wasControlling and reason and MilBase.Notify then MilBase.Notify(ply, reason, "warn") end
	end

	function MilBase.DismissMassif(ply, reason)
		local ent = MilBase.GetPlayerMassif(ply)
		MilBase.EndMassifControl(ply)
		if IsValid(ent) then
			MilBase.LogMassif(ply, "recalled", ent)
			ent:Remove()
		end
		if reason and MilBase.Notify then MilBase.Notify(ply, reason, "ok") end
	end

	function MilBase.StartMassifControl(ply)
		local ent = MilBase.GetPlayerMassif(ply)
		if not IsValid(ent) or ent:GetIncapacitated() then return false end
		if not IsValid(ent:GetMarkedTarget()) then
			if MilBase.Notify then MilBase.Notify(ply, "Mark a suspect before taking control.", "warn") end
			return false
		end
		if CurTime() < (ply.mb_massifPossessionAt or 0) then
			if MilBase.Notify then MilBase.Notify(ply, "Neural handler link cooling down for " .. math.ceil(ply.mb_massifPossessionAt - CurTime()) .. " seconds.", "warn") end
			return false
		end
		ent:SetControlled(true)
		ent:SetCommandState("controlled")
		ent:SetPossessionEnds(CurTime() + (cfg().PossessionDuration or 40))
		ply:SetNWEntity("mb_massif_control", ent)
		ply:SetNWBool("mb_massif_controlling", true)
		ply.mb_massifInput = { buttons = 0, forward = 0, side = 0, angles = ply:EyeAngles() }
		if MilBase.Notify then MilBase.Notify(ply, "Massif control linked. Your body remains exposed. Reload exits.", "ok") end
		MilBase.LogMassif(ply, "took control of", ent)
		return true
	end

	local function inventoryContraband(target)
		local found = {}
		local c = cfg()
		local inv = target.mb_inv
		if istable(inv) then
			local function scan(items)
				for _, item in ipairs(items or {}) do
					local category = c.ContrabandItems and c.ContrabandItems[item.id]
					if category then found[category] = true end
				end
			end
			scan(inv.items)
			scan(inv.pack and inv.pack.items)
			for _, item in pairs(inv.equip or {}) do
				local category = c.ContrabandItems and c.ContrabandItems[item.id]
				if category then found[category] = true end
			end
		end
		for _, weapon in ipairs(target:GetWeapons()) do
			local category = c.ContrabandWeapons and c.ContrabandWeapons[weapon:GetClass()]
			if category then found[category] = true end
		end
		local list = {}
		for category in pairs(found) do list[#list + 1] = category end
		table.sort(list)
		return list
	end

	function MilBase.MassifSearchPlayer(ply, ent, silentRangeWarning)
		if CurTime() < (ent.NextSearch or 0) then
			if not silentRangeWarning and MilBase.Notify then MilBase.Notify(ply, "Massif search is cooling down.", "warn") end
			return false
		end
		local target = ent:GetMarkedTarget()
		if not IsValid(target) or not target:IsPlayer() then
			if MilBase.Notify then MilBase.Notify(ply, "Mark a player before ordering a contraband search.", "warn") end
			return false
		end
		if ent:GetPos():Distance(target:GetPos()) > (cfg().SearchRange or 180) then
			if not silentRangeWarning and MilBase.Notify then MilBase.Notify(ply, "The Massif is moving into search range.", "warn") end
			return false
		end
		ent.NextSearch = CurTime() + (cfg().SearchCooldown or 8)
		ent:DoScentPulse()
		local found = inventoryContraband(target)
		local result = #found > 0 and ("Possible " .. table.concat(found, " and ") .. " detected.") or "No configured contraband scent detected."
		if MilBase.Notify then MilBase.Notify(ply, ent:GetMassifName() .. ": " .. result, #found > 0 and "warn" or "ok") end
		MilBase.LogMassif(ply, "searched", target)
		return true
	end

	function MilBase.MassifAreaSearch(ply, ent)
		if CurTime() < (ent.NextSearch or 0) then return end
		ent.NextSearch = CurTime() + (cfg().SearchCooldown or 8)
		ent:DoScentPulse()
		local players, hostiles, explosives = 0, 0, 0
		for _, found in ipairs(ents.FindInSphere(ent:GetPos(), cfg().AreaSearchRadius or 650)) do
			if found:IsPlayer() and found ~= ply and found:Alive() then players = players + 1 end
			if found:IsNPC() or found:IsNextBot() then hostiles = hostiles + 1 end
			local class = string.lower(found:GetClass())
			if string.find(class, "charge", 1, true) or string.find(class, "bomb", 1, true) or string.find(class, "mine", 1, true) then explosives = explosives + 1 end
		end
		if MilBase.Notify then
			MilBase.Notify(ply, string.format("Area scent: %d personnel, %d NPC signatures, %d explosive signatures.", players, hostiles, explosives), explosives > 0 and "warn" or "ok")
		end
		MilBase.LogMassif(ply, "performed area search near", ent)
	end

	function MilBase.SetMassifTarget(ply, target)
		local ent = MilBase.GetPlayerMassif(ply)
		if not IsValid(ent) then ent = MilBase.DeployMassif(ply) end
		if not IsValid(ent) then return false end
		if not ent:CanTarget(target) then
			if MilBase.Notify then MilBase.Notify(ply, "That target cannot be marked for the Massif.", "warn") end
			return false
		end
		if ent:GetPos():Distance(target:GetPos()) > (cfg().TrackingRange or 6000) then
			if MilBase.Notify then MilBase.Notify(ply, "The suspect is outside scent acquisition range.", "warn") end
			return false
		end
		ent:SetMarkedTarget(target)
		-- Selecting a new scent is never an attack command. Cancel any previous
		-- target-driven order so an old Apprehend cannot carry over to this target.
		local state = ent:GetCommandState()
		if state == "track" or state == "apprehend" or state == "search" then
			ent:SetCommandState("follow")
		end
		if MilBase.Notify then
			MilBase.Notify(ply, "Scent marked: " .. (target:IsPlayer() and (target.MBName and target:MBName() or target:Nick()) or target:GetClass()) .. ". Choose Track, Search, Apprehend, or Control.", "ok")
		end
		MilBase.LogMassif(ply, "marked", target)
		return true
	end

	function MilBase.RunMassifCommand(ply, command)
		if not MilBase.PlayerCanHandleMassif(ply) then return end
		command = string.lower(tostring(command or ""))
		if command == "deploy" then MilBase.DeployMassif(ply) return end
		local ent = MilBase.GetPlayerMassif(ply)
		if not IsValid(ent) then
			ent = MilBase.DeployMassif(ply)
			if not IsValid(ent) then return end
		end

		if command == "follow" then
			MilBase.EndMassifControl(ply)
			ent:SetCommandState("follow")
		elseif command == "stay" then
			MilBase.EndMassifControl(ply)
			ent:SetCommandState("stay")
		elseif command == "guard" then
			MilBase.EndMassifControl(ply)
			ent:SetGuardPosition(ent:GetPos())
			ent:SetCommandState("guard")
		elseif command == "track" or command == "apprehend" then
			if not IsValid(ent:GetMarkedTarget()) then
				if MilBase.Notify then MilBase.Notify(ply, "Mark a suspect first with left-click.", "warn") end
				return
			end
			MilBase.EndMassifControl(ply)
			ent:SetCommandState(command)
		elseif command == "search" then
			local target = ent:GetMarkedTarget()
			if not IsValid(target) or not target:IsPlayer() then
				if MilBase.Notify then MilBase.Notify(ply, "Mark a player first with left-click.", "warn") end
				return
			end
			MilBase.EndMassifControl(ply)
			ent:SetCommandState("search")
		elseif command == "area_search" then
			MilBase.MassifAreaSearch(ply, ent)
		elseif command == "control" then
			MilBase.StartMassifControl(ply)
		elseif command == "dismiss" then
			MilBase.DismissMassif(ply, ent:GetMassifName() .. " recalled.")
		elseif command == "clear_target" then
			ent:SetMarkedTarget(NULL)
			local state = ent:GetCommandState()
			if state == "track" or state == "apprehend" or state == "search" then
				ent:SetCommandState("follow")
			end
		end
		if command ~= "dismiss" and command ~= "area_search" and command ~= "control" and MilBase.Notify and IsValid(ent) then
			MilBase.Notify(ply, ent:GetMassifName() .. " command: " .. string.gsub(command, "_", " ") .. ".", "ok")
		end
	end

	concommand.Add("mb_massif_anim_debug", function(ply)
		if IsValid(ply) and not ply:IsAdmin() then return end
		local ent
		if IsValid(ply) then ent = MilBase.GetPlayerMassif(ply) end
		if not IsValid(ent) then ent = ents.FindByClass("mb_massif")[1] end
		if not IsValid(ent) then
			if IsValid(ply) then ply:ChatPrint("No active Massif found.") else print("[MASSIF] No active Massif found.") end
			return
		end

		local lines = {
			"[MASSIF ANIMATION DEBUG]",
			"Model: " .. tostring(ent:GetModel()),
			"Current: " .. tostring(ent.GetSequenceName and ent:GetSequenceName(ent:GetSequence()) or "unknown") .. " (#" .. tostring(ent:GetSequence()) .. ")",
			"State: " .. tostring(ent.MassifAnimationState) .. " via " .. tostring(ent.MassifAnimationActiveSource),
			"Playback: " .. tostring(ent:GetPlaybackRate()) .. " Cycle: " .. tostring(ent:GetCycle()),
			"Sequences: " .. table.concat(ent:GetSequenceList() or {}, ", "),
		}
		for _, line in ipairs(lines) do
			if IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, line) else print(line) end
		end
		if IsValid(ply) then ply:ChatPrint("Massif animation details printed to your console.") end
	end)

	net.Receive("MilBase_MassifCommand", function(_, ply)
		if not IsValid(ply) then return end
		if CurTime() < (ply.mb_massifNetAt or 0) then return end
		ply.mb_massifNetAt = CurTime() + 0.12
		MilBase.RunMassifCommand(ply, net.ReadString())
	end)

	hook.Add("StartCommand", "MilBase.MassifControlInput", function(ply, cmd)
		local ent = ply:GetNWEntity("mb_massif_control")
		if not IsValid(ent) or ent:GetHandler() ~= ply or not ent:GetControlled() then return end
		local buttons = cmd:GetButtons()
		local oldButtons = ply.mb_massifOldButtons or 0
		ply.mb_massifInput = {
			buttons = buttons,
			forward = math.Clamp(cmd:GetForwardMove() / 10000, -1, 1),
			side = math.Clamp(cmd:GetSideMove() / 10000, -1, 1),
			angles = cmd:GetViewAngles(),
		}
		if bit.band(buttons, IN_ATTACK) ~= 0 and bit.band(oldButtons, IN_ATTACK) == 0 then ent.ControlAttackRequested = true end
		if bit.band(buttons, IN_ATTACK2) ~= 0 and bit.band(oldButtons, IN_ATTACK2) == 0 then ent.ControlPulseRequested = true end
		if bit.band(buttons, IN_RELOAD) ~= 0 and bit.band(oldButtons, IN_RELOAD) == 0 then MilBase.EndMassifControl(ply, "Massif control released.") end
		ply.mb_massifOldButtons = buttons
		cmd:ClearMovement()
		cmd:RemoveKey(IN_ATTACK)
		cmd:RemoveKey(IN_ATTACK2)
		cmd:RemoveKey(IN_USE)
		cmd:RemoveKey(IN_JUMP)
		cmd:RemoveKey(IN_DUCK)
	end)

	hook.Add("SetupMove", "MilBase.MassifPin", function(ply, mv)
		if ply:GetNWFloat("mb_massif_pinned_until", 0) <= CurTime() then return end
		mv:SetForwardSpeed(0)
		mv:SetSideSpeed(0)
		mv:SetUpSpeed(0)
		mv:SetVelocity(vector_origin)
		mv:SetMaxClientSpeed(0)
	end)

	hook.Add("SetupPlayerVisibility", "MilBase.MassifPVS", function(ply)
		local ent = ply:GetNWEntity("mb_massif_control")
		if not IsValid(ent) then return end
		AddOriginToPVS(ent:GetPos())
		local target = ent:GetMarkedTarget()
		if IsValid(target) then AddOriginToPVS(target:GetPos()) end
	end)

	hook.Add("EntityTakeDamage", "MilBase.MassifProtectHandler", function(victim, dmg)
		if victim:IsPlayer() and victim:GetNWBool("mb_massif_controlling", false)
			and cfg().BodyVulnerableWhileControlling == false then
			return true
		end
		if cfg().ProtectHandler == false or not victim:IsPlayer() then return end
		local ent = MilBase.GetPlayerMassif(victim)
		local attacker = dmg:GetAttacker()
		if not IsValid(ent) or ent:GetControlled() or not ent:CanTarget(attacker) then return end
		if dmg:GetDamage() < 5 then return end
		ent:SetMarkedTarget(attacker)
		ent:SetCommandState("apprehend")
	end)

	local function cleanPlayer(ply)
		MilBase.DismissMassif(ply)
		ply:SetNWFloat("mb_massif_pinned_until", 0)
	end
	hook.Add("PlayerDeath", "MilBase.MassifDeathCleanup", cleanPlayer)
	hook.Add("PlayerDisconnected", "MilBase.MassifDisconnectCleanup", cleanPlayer)
	hook.Add("PlayerSpawn", "MilBase.MassifSpawnCleanup", function(ply)
		MilBase.EndMassifControl(ply)
		ply:SetNWFloat("mb_massif_pinned_until", 0)
	end)

	MilBase.RegisterChatCommand("massifname", {
		help = "Name your active Massif: /massifname <name>",
		func = function(ply, _, rawText)
			if not MilBase.PlayerCanHandleMassif(ply) then return end
			local name = string.Trim(tostring(rawText or ""))
			name = string.sub(name, 1, 24)
			if name == "" then
				if MilBase.Notify then MilBase.Notify(ply, "Usage: /massifname <name>", "warn") end
				return
			end
			ply:SetNWString("mb_massif_name", name)
			MilBase.DB.Run(string.format(
				"REPLACE INTO frontier_massif_names (steamid, name) VALUES (%s, %s)",
				MilBase.SQLStr(ply:MBCharacterKey()), MilBase.SQLStr(name)))
			local ent = MilBase.GetPlayerMassif(ply)
			if IsValid(ent) then ent:SetMassifName(name) end
			if MilBase.Notify then MilBase.Notify(ply, "Your Massif is now named " .. name .. ".", "ok") end
		end,
	})

	hook.Add("MilBase.PlayerLoaded", "MilBase.LoadMassifName", function(ply)
		MilBase.LoadMassifName(ply)
	end)

	timer.Create("MilBase.MassifCertificationWatch", 1, 0, function()
		for _, ply in ipairs(player.GetAll()) do
			local ent = MilBase.GetPlayerMassif(ply)
			if IsValid(ent) and not MilBase.PlayerCanHandleMassif(ply) then MilBase.DismissMassif(ply, "Massif recalled: handler authorization is no longer active.") end
		end
	end)
else
	local wheelCommands = {
		{ id = "follow", label = "HEEL", description = "Follow your handler" },
		{ id = "stay", label = "STAY", description = "Hold the current position" },
		{ id = "guard", label = "GUARD", description = "Protect this location" },
		{ id = "track", label = "TRACK", description = "Follow only — do not attack" },
		{ id = "apprehend", label = "APPREHEND", description = "Chase and non-lethally pin" },
		{ id = "search", label = "SEARCH", description = "Approach and inspect — no attack" },
		{ id = "area_search", label = "AREA SCAN", description = "Search the nearby area" },
		{ id = "control", label = "CONTROL", description = "Link directly with the Massif" },
		{ id = "clear_target", label = "CLEAR", description = "Forget the marked suspect" },
		{ id = "dismiss", label = "RECALL", description = "Return the Massif to its kennel", danger = true },
	}

	local function sendCommand(id)
		net.Start("MilBase_MassifCommand")
			net.WriteString(id)
		net.SendToServer()
	end

	local function drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, color)
		local points = {}
		local steps = 8
		for step = 0, steps do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * outerRadius, y = cy + math.sin(angle) * outerRadius }
		end
		for step = steps, 0, -1 do
			local angle = math.rad(startAngle + (endAngle - startAngle) * (step / steps))
			points[#points + 1] = { x = cx + math.cos(angle) * innerRadius, y = cy + math.sin(angle) * innerRadius }
		end
		draw.NoTexture()
		surface.SetDrawColor(color)
		surface.DrawPoly(points)
	end

	function MilBase.OpenMassifWheel()
		if IsValid(MilBase.MassifWheel) then MilBase.MassifWheel:Remove() end

		local frame = vgui.Create("DFrame")
		MilBase.MassifWheel = frame
		frame:SetSize(ScrW(), ScrH())
		frame:SetPos(0, 0)
		frame:SetTitle("")
		frame:ShowCloseButton(false)
		frame:SetDraggable(false)
		frame:MakePopup()
		frame:SetCursor("hand")
		frame.SelectedCommand = nil
		frame.PreviousCommand = nil

		local function metrics(w, h)
			local scale = math.Clamp(math.min(w / 1920, h / 1080), 0.72, 1.2)
			return w * 0.5, h * 0.52, 116 * scale, 315 * scale, scale
		end

		function frame:Think()
			local w, h = self:GetSize()
			local cx, cy, innerRadius, outerRadius = metrics(w, h)
			local mx, my = gui.MousePos()
			local dx, dy = mx - cx, my - cy
			local distance = math.sqrt(dx * dx + dy * dy)
			local selected
			if distance >= innerRadius and distance <= outerRadius then
				local angle = (math.deg(math.atan2(dy, dx)) + 450) % 360
				local segment = 360 / #wheelCommands
				selected = math.floor((angle + segment * 0.5) / segment) % #wheelCommands + 1
			end
			self.SelectedCommand = selected
			if selected ~= self.PreviousCommand then
				if selected and MilBase.PlayUISound then MilBase.PlayUISound("hover") end
				self.PreviousCommand = selected
			end
		end

		function frame:OnMousePressed(code)
			if code == MOUSE_RIGHT then self:Remove() return end
			if code ~= MOUSE_LEFT then return end
			local selected = self.SelectedCommand
			if not selected then self:Remove() return end
			local command = wheelCommands[selected]
			if not command then return end
			if MilBase.PlayUISound then MilBase.PlayUISound("select") end
			sendCommand(command.id)
			self:Remove()
		end

		function frame:OnKeyCodePressed(code)
			if code == KEY_ESCAPE then self:Remove() end
		end

		frame.Paint = function(self, w, h)
			local ui = MilBase.UI or {}
			local bg = ui.bg or Color(6, 6, 7, 240)
			local panel = ui.panel or Color(10, 10, 11, 230)
			local raised = ui.raised or Color(255, 198, 60, 10)
			local hover = ui.hover or Color(255, 198, 60, 25)
			local outline = ui.outline or Color(255, 198, 60, 55)
			local accent = ui.accent or Color(255, 198, 60)
			local text = ui.text or Color(240, 238, 230)
			local dim = ui.dim or Color(170, 162, 140)
			local danger = ui.danger or Color(220, 80, 70)

			if MilBase.DrawBlur then MilBase.DrawBlur(self, 3) end
			surface.SetDrawColor(Color(bg.r, bg.g, bg.b, 218))
			surface.DrawRect(0, 0, w, h)

			local cx, cy, innerRadius, outerRadius, scale = metrics(w, h)
			local segment = 360 / #wheelCommands
			local gap = 2.2

			draw.SimpleText("CG MASSIF COMMAND LINK", "MB.Big", cx, cy - outerRadius - 74 * scale, text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			surface.SetDrawColor(accent)
			surface.DrawRect(cx - 92 * scale, cy - outerRadius - 47 * scale, 184 * scale, 2)
			draw.SimpleText("SELECT AN ORDER", "MB.Tiny", cx, cy - outerRadius - 29 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			for index, command in ipairs(wheelCommands) do
				local middle = -90 + (index - 1) * segment
				local startAngle = middle - segment * 0.5 + gap
				local endAngle = middle + segment * 0.5 - gap
				local selected = self.SelectedCommand == index
				local baseColor = selected and hover or panel
				if command.danger and selected then baseColor = Color(danger.r, danger.g, danger.b, 34) end
				drawWheelSector(cx, cy, innerRadius, outerRadius, startAngle, endAngle, baseColor)
				drawWheelSector(cx, cy, outerRadius - 2, outerRadius, startAngle, endAngle, selected and (command.danger and danger or accent) or outline)

				local angle = math.rad(middle)
				local labelRadius = (innerRadius + outerRadius) * 0.5
				local lx = cx + math.cos(angle) * labelRadius
				local ly = cy + math.sin(angle) * labelRadius
				local labelColor = selected and (command.danger and danger or accent) or text
				draw.SimpleText(command.label, "MB.Small", lx, ly, labelColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				if selected and MilBase.DrawBrackets then
					MilBase.DrawBrackets(lx - 58 * scale, ly - 17 * scale, 116 * scale, 34 * scale, labelColor, 7 * scale)
				end
			end

			local centerX, centerY = cx - innerRadius + 8 * scale, cy - 60 * scale
			local centerW, centerH = innerRadius * 2 - 16 * scale, 120 * scale
			if MilBase.DrawPanelBF2 then
				MilBase.DrawPanelBF2(centerX, centerY, centerW, centerH, { color = panel, accent = accent, outlineColor = outline, cut = 9 * scale })
			else
				surface.SetDrawColor(panel)
				surface.DrawRect(centerX, centerY, centerW, centerH)
			end

			local command = self.SelectedCommand and wheelCommands[self.SelectedCommand] or nil
			draw.SimpleText(command and command.label or "COMMAND", "MB.Tab", cx, cy - 22 * scale, command and (command.danger and danger or accent) or text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(command and command.description or "MOVE THE CURSOR TO AN ORDER", "MB.Tiny", cx, cy + 13 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("LMB CONFIRM  •  RMB / ESC CANCEL", "MB.Tiny", cx, cy + 39 * scale, dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	hook.Add("CalcView", "MilBase.MassifControlView", function(ply, origin, angles, fov)
		local ent = ply:GetNWEntity("mb_massif_control")
		if not IsValid(ent) or not ent:GetControlled() then return end
		local c = cfg()
		local focus = ent:GetPos() + Vector(0, 0, 38)
		if c.ThirdPersonControlCamera == false then
			return { origin = focus + ent:GetForward() * 18, angles = angles, fov = fov, drawviewer = true }
		end
		local desired = focus - angles:Forward() * 125 + Vector(0, 0, 28)
		local tr = util.TraceHull({ start = focus, endpos = desired, mins = Vector(-6, -6, -6), maxs = Vector(6, 6, 6), filter = { ply, ent }, mask = MASK_SOLID })
		return { origin = tr.HitPos, angles = angles, fov = math.min(fov + 5, 100), drawviewer = true }
	end)

	hook.Add("PreDrawHalos", "MilBase.MassifScentVision", function()
		local ply = LocalPlayer()
		local ent = IsValid(ply) and ply:GetNWEntity("mb_massif_control") or NULL
		if not IsValid(ent) then return end
		local target = ent:GetMarkedTarget()
		if not IsValid(target) then return end
		if ent:GetPos():Distance(target:GetPos()) > (cfg().TrackingRange or 6000) then return end
		local pulsing = ent:GetScentPulseEnds() > CurTime()
		local glow = pulsing and math.abs(math.sin(CurTime() * 14)) or 0.45
		halo.Add({ target }, Color(255, 75 + 100 * glow, 35), pulsing and 8 or 4, pulsing and 8 or 4, 2, true, true)
	end)

	hook.Add("HUDPaint", "MilBase.MassifHUD", function()
		local ply = LocalPlayer()
		if not IsValid(ply) then return end
		local ent = ply:GetNWEntity("mb_massif_control")
		if not IsValid(ent) then return end

		local ui = MilBase.UI or {}
		local panel = ui.panel or Color(10, 10, 11, 225)
		local outline = ui.outline or Color(255, 198, 60, 55)
		local accent = ui.accent or Color(255, 198, 60)
		local text = ui.text or Color(240, 238, 230)
		local dim = ui.dim or Color(170, 162, 140)
		local danger = ui.danger or Color(220, 80, 70)

		local sw, sh = ScrW(), ScrH()
		local scale = math.Clamp(math.min(sw / 1920, sh / 1080), 0.75, 1.15)
		local w, h = 500 * scale, 132 * scale
		local x, y = sw * 0.5 - w * 0.5, sh - h - 48 * scale
		if MilBase.DrawPanelBF2 then
			MilBase.DrawPanelBF2(x, y, w, h, { color = panel, accent = accent, outlineColor = outline, cut = 10 * scale })
		else
			surface.SetDrawColor(panel)
			surface.DrawRect(x, y, w, h)
		end

		local hp, maxHP = ent:GetMassifHealth(), math.max(1, ent:GetMassifMaxHealth())
		local healthFraction = math.Clamp(hp / maxHP, 0, 1)
		draw.SimpleText(ent:GetMassifName(), "MB.Tab", x + 18 * scale, y + 13 * scale, text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("DIRECT CONTROL", "MB.Tiny", x + w - 18 * scale, y + 19 * scale, accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		local barX, barY, barW, barH = x + 18 * scale, y + 51 * scale, 210 * scale, 10 * scale
		if MilBase.DrawSkewBar then
			MilBase.DrawSkewBar(barX, barY, barW, barH, healthFraction, healthFraction < 0.3 and danger or accent, { back = Color(0, 0, 0, 175) })
		else
			surface.SetDrawColor(Color(0, 0, 0, 175))
			surface.DrawRect(barX, barY, barW, barH)
			surface.SetDrawColor(healthFraction < 0.3 and danger or accent)
			surface.DrawRect(barX, barY, barW * healthFraction, barH)
		end
		draw.SimpleText("HEALTH " .. hp .. "/" .. maxHP, "MB.Tiny", barX, barY + 15 * scale, dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("LINK " .. math.max(0, math.ceil(ent:GetPossessionEnds() - CurTime())) .. "s", "MB.Small", x + w - 18 * scale, y + 50 * scale, text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		local target = ent:GetMarkedTarget()
		local targetText = IsValid(target) and ((target:IsPlayer() and target:Nick() or target:GetClass()) .. "  •  " .. math.floor(ent:GetPos():Distance(target:GetPos())) .. "u") or "NO SCENT ACQUIRED"
		draw.SimpleText("SUSPECT  " .. targetText, "MB.Small", x + 18 * scale, y + 83 * scale, IsValid(target) and danger or dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("WASD MOVE  •  SHIFT SPRINT  •  CTRL CROUCH  •  LMB ATTACK  •  RMB SCENT  •  R EXIT", "MB.Tiny", x + 18 * scale, y + 108 * scale, dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end)

	hook.Add("HUDShouldDraw", "MilBase.MassifHideCrosshair", function(name)
		if name ~= "CHudCrosshair" then return end
		local ply = LocalPlayer()
		if IsValid(ply) and IsValid(ply:GetNWEntity("mb_massif_control")) then return false end
	end)
end
