--[[
	Galaxy Director server.

	Responsibilities:
	  * Observe real Star Wars Universe hyperspace arrivals.
	  * Maintain persistent planet allegiance/opinion/CIS pressure.
	  * Schedule ambient traffic and interactive encounters.
	  * Run safeguarded, staged CIS capital-ship boarding attacks.
	  * Expose audited staff/management controls and Discord notifications.

	The director deliberately treats distant ships as lightweight skybox
	actors. Full NPC AI only exists during a local boarding wave.
]]

if not SERVER or MilBase._GalaxyServerLoaded then return end
MilBase._GalaxyServerLoaded = true

local G = MilBase.Galaxy
local gd = MilBase.Config.GalaxyDirector or {}
local discord = MilBase.Config.GalaxyDiscord or {}

util.AddNetworkString("MilBase_GalaxyState")
util.AddNetworkString("MilBase_GalaxyEncounter")
util.AddNetworkString("MilBase_GalaxyRespond")
util.AddNetworkString("MilBase_GalaxyHailContacts")
util.AddNetworkString("MilBase_GalaxyHailRequest")
util.AddNetworkString("MilBase_GalaxyAdminRequest")
util.AddNetworkString("MilBase_GalaxyAdminAction")
util.AddNetworkString("MilBase_GalaxyAdminData")
util.AddNetworkString("MilBase_GalaxyLaser")
util.AddNetworkString("MilBase_GalaxyHyperspace")

for _, workshopID in ipairs(gd.WorkshopContent or {}) do
	resource.AddWorkshop(workshopID)
end

G.Runtime = G.Runtime or {}
for key, value in pairs(gd.RuntimeDefaults or {}) do
	if G.Runtime[key] == nil then G.Runtime[key] = value end
end

G.State = G.State or {
	ready = false,
	currentPlanet = gd.DefaultPlanet or "Deep Space",
	currentRisk = 0.38,
	nextEncounterAt = 0,
	nextAmbientAt = 0,
	nextSimulationAt = 0,
	lastMajorAttack = 0,
	lastEncounter = 0,
	intelUntil = 0,
	intelText = "",
}

G.Planets = G.Planets or {}
G.UniversePositions = G.UniversePositions or {}
G.Anchors = G.Anchors or {}
G.SavedCapitalMapPosition = G.SavedCapitalMapPosition or nil
G.Recommendations = G.Recommendations or {}
G.RecentEncounters = G.RecentEncounters or {}
G.AmbientShips = G.AmbientShips or {}
G.Active = G.Active or nil

function G.IsNavyRecipient(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	local naval = MilBase.Naval
	if naval and naval.IsNavy then return naval.IsNavy(ply) end
	local config = MilBase.Config.NavalOperations or {}
	local factionID = ply.MBFactionID and tostring(ply:MBFactionID()) or ""
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local factionName = faction and tostring(faction.name or "") or ""
	return (config.ConsoleFactionIDs or {})[factionID] == true
		or (config.ConsoleFactionIDs or {})[string.lower(factionID)] == true
		or (config.ConsoleFactionNames or {})[factionName] == true
end

function G.NavyRecipients()
	local recipients = {}
	for _, ply in ipairs(player.GetHumans()) do
		if G.IsNavyRecipient(ply) then recipients[#recipients + 1] = ply end
	end
	return recipients
end

function G.AnnounceNavy(text, color, prefix)
	local recipients = G.NavyRecipients()
	if #recipients == 0 then return end
	color = color or Color(100, 190, 245)
	if MilBase.Announce then
		net.Start("MilBase_Announce")
			net.WriteString(text)
			net.WriteColor(color)
		net.Send(recipients)
	end
	if MilBase.ChatMsg then
		MilBase.ChatMsg(recipients, color, prefix or "[GALAXY] ", color_white, text)
	end
end

local function nowUnix()
	return os.time()
end

local function actorName(actor)
	if not IsValid(actor) then return "server console" end
	if actor.MBName then return actor:MBName() end
	if actor:IsPlayer() then return actor:Nick() end
	if actor.GetShipName then
		local name = string.Trim(tostring(actor:GetShipName() or ""))
		if name ~= "" then return name end
	end
	return actor:GetClass() ~= "" and actor:GetClass() or "world entity"
end

local function actorID(actor)
	if not IsValid(actor) then return "console" end
	if actor:IsPlayer() then return actor:SteamID64() end
	return "entity:" .. actor:EntIndex()
end

local function log(text, color)
	MsgC(color or Color(100, 190, 245), "[Galaxy Director] ", color_white, text .. "\n")
end

function G.IsStaff(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	return ply:IsListenServerHost() or ply:IsSuperAdmin()
		or ply:MBStaffLevel() >= (gd.StaffLevel or 3)
end

function G.IsManagement(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	return ply:IsListenServerHost()
		or ply:MBStaffLevel() >= (gd.ManagementLevel or 6)
end

function G.Audit(actor, action, details)
	action = G.CleanText(action, 64)
	details = G.CleanText(details, 1000)
	MilBase.DB.Run(string.format(
		"INSERT INTO frontier_galaxy_audit "
			.. "(event_time, actor_sid, actor_name, action_name, details) "
			.. "VALUES (%d, %s, %s, %s, %s)",
		nowUnix(), MilBase.SQLStr(actorID(actor)), MilBase.SQLStr(actorName(actor)),
		MilBase.SQLStr(action), MilBase.SQLStr(details)))

	if MilBase.Log then
		MilBase.Log("staff", "[Galaxy] " .. actorName(actor) .. " " .. action
			.. (details ~= "" and (": " .. details) or ""), actor)
	end
end

function G.RecordHistory(kind, outcome, planet, details)
	MilBase.DB.Run(string.format(
		"INSERT INTO frontier_galaxy_history "
			.. "(started_at, ended_at, event_kind, outcome, planet_name, details) "
			.. "VALUES (%d, %d, %s, %s, %s, %s)",
		tonumber(G.Active and G.Active.startedUnix) or nowUnix(), nowUnix(),
		MilBase.SQLStr(kind or ""), MilBase.SQLStr(outcome or ""),
		MilBase.SQLStr(planet or G.State.currentPlanet or ""),
		MilBase.SQLStr(G.CleanText(details, 1000))))
end

local function runSchema(queries, index, onDone)
	index = index or 1
	if index > #queries then
		if onDone then onDone() end
		return
	end

	MilBase.DB.Query(queries[index], function()
		runSchema(queries, index + 1, onDone)
	end, function()
		-- Continue so one stale/partially migrated table cannot disable the
		-- complete director.
		runSchema(queries, index + 1, onDone)
	end)
end

function G.InitializeDatabase()
	if G._databaseInitializing then return end
	G._databaseInitializing = true

	local queries = {
		[[CREATE TABLE IF NOT EXISTS frontier_galaxy_planets (
			planet_key VARCHAR(96) PRIMARY KEY,
			display_name VARCHAR(128),
			allegiance VARCHAR(24),
			republic_opinion INTEGER,
			cis_opinion INTEGER,
			cis_pressure INTEGER,
			locked INTEGER,
			lock_faction VARCHAR(24),
			note TEXT,
			updated_at INTEGER,
			updated_by VARCHAR(64)
		)]],
		[[CREATE TABLE IF NOT EXISTS frontier_galaxy_settings (
			setting_key VARCHAR(64) PRIMARY KEY,
			setting_value TEXT
		)]],
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_history ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "started_at INTEGER, ended_at INTEGER, event_kind VARCHAR(32), "
			.. "outcome VARCHAR(32), planet_name VARCHAR(128), details TEXT)",
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_audit ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "event_time INTEGER, actor_sid VARCHAR(32), actor_name VARCHAR(128), "
			.. "action_name VARCHAR(64), details TEXT)",
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_recommendations ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "created_at INTEGER, planet_key VARCHAR(96), republic_delta INTEGER, "
			.. "cis_delta INTEGER, reason TEXT, source_name VARCHAR(128), "
			.. "status VARCHAR(24), decided_at INTEGER, decided_by VARCHAR(128))",
		"CREATE TABLE IF NOT EXISTS frontier_galaxy_anchors ("
			.. "id " .. MilBase.DB.AutoIncPK() .. ", "
			.. "map_name VARCHAR(128), anchor_kind VARCHAR(24), label VARCHAR(128), "
			.. "pos TEXT, ang TEXT)",
	}

	runSchema(queries, 1, function()
		G.LoadPersistentState()
	end)
end

local function decodeSetting(raw)
	local decoded = util.JSONToTable(tostring(raw or ""))
	if not istable(decoded) then return nil end
	return decoded.value
end

function G.SaveRuntime(key)
	local payload = util.TableToJSON({ value = G.Runtime[key] })
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_settings (setting_key, setting_value) VALUES (%s, %s)",
		MilBase.SQLStr(key), MilBase.SQLStr(payload)))
end

local function seedFor(name)
	local key = G.PlanetKey(name)
	for seedName, seed in pairs(gd.PlanetSeeds or {}) do
		if G.PlanetKey(seedName) == key then return seed end
	end
end

function G.DefaultPlanet(name)
	local seed = seedFor(name) or {}
	local allegiance = string.lower(tostring(seed.allegiance or "neutral"))
	if not G.ValidAllegiances[allegiance] then allegiance = "neutral" end

	return {
		key = G.PlanetKey(name),
		name = G.CleanText(name, 128),
		allegiance = allegiance,
		republicOpinion = math.Clamp(tonumber(seed.republicOpinion) or 0, -100, 100),
		cisOpinion = math.Clamp(tonumber(seed.cisOpinion) or 0, -100, 100),
		pressure = math.Clamp(tonumber(seed.pressure) or 0, 0, 100),
		locked = seed.locked == true,
		lockFaction = G.ValidAllegiances[seed.lockFaction] and seed.lockFaction or "",
		note = G.CleanText(seed.note, 500),
	}
end

function G.EnsurePlanet(name)
	name = G.CleanText(name, 128)
	local key = G.PlanetKey(name)
	if key == "" then return nil end
	if not G.Planets[key] then G.Planets[key] = G.DefaultPlanet(name) end
	return G.Planets[key]
end

function G.RefreshUniverse()
	local previous = G.UniversePositions or {}
	G.UniversePositions = {}

	if SWU and istable(SWU.Universe) then
		for _, chunk in pairs(SWU.Universe) do
			if istable(chunk) then
				for _, object in ipairs(chunk) do
					if istable(object) and object.type == "planet"
					and isstring(object.name) and isvector(object.pos) then
						local key = G.PlanetKey(object.name)
						G.UniversePositions[key] = object.pos
						G.EnsurePlanet(object.name)
					end
				end
			end
		end
	end

	for name in pairs(gd.PlanetSeeds or {}) do G.EnsurePlanet(name) end
	G.EnsurePlanet(gd.DefaultPlanet or "Deep Space")

	if table.Count(G.UniversePositions) == 0 then
		G.UniversePositions = previous
	end
end

local function rowToPlanet(row)
	local name = G.CleanText(row.display_name, 128)
	local key = G.PlanetKey(row.planet_key ~= "" and row.planet_key or name)
	if key == "" then return nil end
	local planet = G.EnsurePlanet(name ~= "" and name or key)
	local allegiance = string.lower(tostring(row.allegiance or planet.allegiance))

	planet.key = key
	planet.name = name ~= "" and name or planet.name
	planet.allegiance = G.ValidAllegiances[allegiance] and allegiance or "neutral"
	planet.republicOpinion = math.Clamp(tonumber(row.republic_opinion) or 0, -100, 100)
	planet.cisOpinion = math.Clamp(tonumber(row.cis_opinion) or 0, -100, 100)
	planet.pressure = math.Clamp(tonumber(row.cis_pressure) or 0, 0, 100)
	planet.locked = tonumber(row.locked) == 1
	planet.lockFaction = G.ValidAllegiances[row.lock_faction] and row.lock_faction or ""
	planet.note = G.CleanText(row.note, 500)
	G.Planets[key] = planet
	return planet
end

function G.SavePlanet(planet, actor)
	if not planet or not planet.key then return end
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_planets "
			.. "(planet_key, display_name, allegiance, republic_opinion, cis_opinion, "
			.. "cis_pressure, locked, lock_faction, note, updated_at, updated_by) "
			.. "VALUES (%s, %s, %s, %d, %d, %d, %d, %s, %s, %d, %s)",
		MilBase.SQLStr(planet.key), MilBase.SQLStr(planet.name),
		MilBase.SQLStr(planet.allegiance), planet.republicOpinion, planet.cisOpinion,
		planet.pressure, planet.locked and 1 or 0, MilBase.SQLStr(planet.lockFaction or ""),
		MilBase.SQLStr(planet.note or ""), nowUnix(), MilBase.SQLStr(actorName(actor))))
end

local function vectorFromJSON(raw)
	local data = util.JSONToTable(tostring(raw or ""))
	if not istable(data) then return nil end
	local x = tonumber(data.x or data[1])
	local y = tonumber(data.y or data[2])
	local z = tonumber(data.z or data[3])
	if not x or not y or not z then return nil end
	return Vector(x, y, z)
end

local function angleFromJSON(raw)
	local data = util.JSONToTable(tostring(raw or ""))
	if not istable(data) then return angle_zero end
	return Angle(tonumber(data.p or data[1]) or 0, tonumber(data.y or data[2]) or 0,
		tonumber(data.r or data[3]) or 0)
end

function G.LoadAnchors(onDone)
	G.Anchors = {}
	MilBase.DB.Query("SELECT * FROM frontier_galaxy_anchors WHERE map_name = "
		.. MilBase.SQLStr(game.GetMap()) .. " ORDER BY id ASC", function(rows)
		for _, row in ipairs(rows) do
			local pos = vectorFromJSON(row.pos)
			if pos then
				local kind = tostring(row.anchor_kind or "")
				if kind ~= "impact" and kind ~= "boarding"
				and kind ~= "boarding_drill"
				and kind ~= "boarding_dropship"
				and kind ~= "boarding_player"
				and kind ~= "breach_door"
				and kind ~= "capital" and kind ~= "space_battle" then
					kind = "boarding"
				end
				G.Anchors[#G.Anchors + 1] = {
					id = tonumber(row.id) or 0,
					kind = kind,
					label = G.CleanText(row.label, 128),
					pos = pos,
					ang = angleFromJSON(row.ang),
				}
			end
		end
		if onDone then onDone() end
	end)
end

function G.LoadRecommendations(onDone)
	G.Recommendations = {}
	MilBase.DB.Query("SELECT * FROM frontier_galaxy_recommendations "
		.. "WHERE status = 'pending' ORDER BY id DESC LIMIT 100", function(rows)
		for _, row in ipairs(rows) do
			G.Recommendations[#G.Recommendations + 1] = {
				id = tonumber(row.id) or 0,
				createdAt = tonumber(row.created_at) or 0,
				planetKey = G.PlanetKey(row.planet_key),
				republicDelta = tonumber(row.republic_delta) or 0,
				cisDelta = tonumber(row.cis_delta) or 0,
				reason = G.CleanText(row.reason, 500),
				source = G.CleanText(row.source_name, 128),
			}
		end
		if onDone then onDone() end
	end)
end

function G.LoadPersistentState()
	G.RefreshUniverse()

	MilBase.DB.Query("SELECT setting_key, setting_value FROM frontier_galaxy_settings", function(rows)
		for _, row in ipairs(rows) do
			local key = tostring(row.setting_key or "")
			local value = decodeSetting(row.setting_value)
			if gd.RuntimeDefaults and gd.RuntimeDefaults[key] ~= nil
			and type(value) == type(gd.RuntimeDefaults[key]) then
				G.Runtime[key] = value
			elseif key == "lastMajorAttack" then
				G.State.lastMajorAttack = tonumber(value) or 0
			elseif key == ("capitalMapPosition:" .. string.sub(game.GetMap(), 1, 43))
			and istable(value) then
				local x, y, z = tonumber(value.x), tonumber(value.y), tonumber(value.z)
				if x and y and z then
					G.SavedCapitalMapPosition = {
						pos = Vector(x, y, z),
						ang = Angle(tonumber(value.p) or 0,
							tonumber(value.yaw) or 0, tonumber(value.r) or 0),
					}
				end
			end
		end

		MilBase.DB.Query("SELECT * FROM frontier_galaxy_planets", function(planetRows)
			for _, row in ipairs(planetRows) do rowToPlanet(row) end

			G.LoadAnchors(function()
				G.LoadRecommendations(function()
					G.State.ready = true
					G.ScheduleNextEncounter("startup")
					G.ScheduleNextAmbient()
					G.State.nextSimulationAt = CurTime() + math.max(30,
						tonumber(G.Runtime.simulationInterval) or 1800)
					G.DetectCurrentPlanet()
					G.BroadcastState()
					log("Ready with " .. table.Count(G.Planets) .. " planet records and "
						.. #G.Anchors .. " map anchors.", Color(120, 225, 145))
				end)
			end)
		end)
	end)
end

function G.AddRecommendation(planetName, republicDelta, cisDelta, reason, source)
	local planet = G.EnsurePlanet(planetName or G.State.currentPlanet)
	if not planet then return end

	MilBase.DB.Insert(string.format(
		"INSERT INTO frontier_galaxy_recommendations "
			.. "(created_at, planet_key, republic_delta, cis_delta, reason, source_name, status, "
			.. "decided_at, decided_by) VALUES (%d, %s, %d, %d, %s, %s, 'pending', 0, '')",
		nowUnix(), MilBase.SQLStr(planet.key),
		math.Clamp(math.floor(tonumber(republicDelta) or 0), -100, 100),
		math.Clamp(math.floor(tonumber(cisDelta) or 0), -100, 100),
		MilBase.SQLStr(G.CleanText(reason, 500)),
		MilBase.SQLStr(G.CleanText(source, 128))), function()
			G.LoadRecommendations()
		end)
end

function G.PlanetDanger(planet)
	planet = planet or G.EnsurePlanet(G.State.currentPlanet)
	if not planet then return 0.4 end

	local base = (gd.DangerByAllegiance or {})[planet.allegiance] or 0.4
	base = base + (planet.pressure / 100) * 0.2
	base = base - (planet.republicOpinion / 100) * 0.05
	base = base + (planet.cisOpinion / 100) * 0.05
	return math.Clamp(base, 0.03, 0.97)
end

function G.SetCurrentPlanet(name, reason)
	local planet = G.EnsurePlanet(name)
	if not planet then return end

	G.State.currentPlanet = planet.name
	G.State.currentRisk = G.PlanetDanger(planet)
	G.State.currentReason = G.CleanText(reason, 64)
	G.BroadcastState()
end

function G.FindNearestPlanet(pos)
	if not isvector(pos) then return nil end
	local nearestKey, nearestDistance
	for key, planetPos in pairs(G.UniversePositions) do
		local distance = pos:DistToSqr(planetPos)
		if not nearestDistance or distance < nearestDistance then
			nearestKey, nearestDistance = key, distance
		end
	end
	return nearestKey and G.Planets[nearestKey] or nil
end

function G.DetectCurrentPlanet()
	G.RefreshUniverse()
	if SWU and IsValid(SWU.Controller) and SWU.Controller.GetShipPos then
		local nearest = G.FindNearestPlanet(SWU.Controller:GetShipPos())
		if nearest then
			G.SetCurrentPlanet(nearest.name, "nearest SWU location")
			return
		end
	end
	G.SetCurrentPlanet(G.State.currentPlanet or gd.DefaultPlanet, "configured location")
end

function G.RaidCapitals(active, excluded)
	active = active or G.Active
	if not active or active.kind ~= "cis_raid" then return {} end
	local result, seen = {}, {}
	local function include(ship)
		if not IsValid(ship) or ship == excluded or seen[ship]
		or ship.mb_destroyed or ship:GetHull() <= 0 then return end
		seen[ship] = true
		result[#result + 1] = ship
	end
	for _, ship in ipairs(active.capitals or {}) do include(ship) end
	include(active.capital)
	active.capitals = result
	active.capital = result[1]
	return result
end

function G.PrimaryRaidCapital(active)
	active = active or G.Active
	local capitals = G.RaidCapitals(active)
	if #capitals == 0 then return nil end
	local target = capitals[1]
	for index = 2, #capitals do
		local candidate = capitals[index]
		local targetFraction = target:GetHull() / math.max(1, target:GetMaxHull())
		local candidateFraction = candidate:GetHull() / math.max(1, candidate:GetMaxHull())
		if candidateFraction < targetFraction then target = candidate end
	end
	active.capital = target
	return target
end

local function publicActive()
	local active = G.Active
	if not active then return nil end
	local privateTransmission = active.choices and #active.choices > 0
	local capitals = active.kind == "cis_raid" and G.RaidCapitals(active) or {}
	if active.kind == "cis_raid" then
		local ready = {}
		for _, candidate in ipairs(capitals) do
			if not candidate.mb_galaxyCombatPrepared
			or candidate:GetCombatReady() and not candidate.mb_galaxyRetreating then
				ready[#ready + 1] = candidate
			end
		end
		capitals = ready
	end
	local capitalHull, capitalMaxHull = 0, 0
	for _, capital in ipairs(capitals) do
		capitalHull = capitalHull + math.max(0, capital:GetHull())
		capitalMaxHull = capitalMaxHull + math.max(1, capital:GetMaxHull())
	end
	return {
		id = active.id,
		kind = active.kind,
		title = privateTransmission and "INCOMING SHIP TRANSMISSION" or active.title,
		body = privateTransmission
			and "A private channel is waiting at a ship communications terminal."
			or active.body,
		phase = active.phase,
		phaseName = G.RaidPhaseNames[active.phase] or active.phase,
		endsAt = active.endsAt or 0,
		startedAt = active.startedAt or 0,
		integrity = active.integrity,
		maxIntegrity = active.maxIntegrity,
		wave = active.wave,
		maxWaves = active.maxWaves,
		hostiles = active.hostiles,
		republicSupport = active.republicSupport
			and #active.republicSupport or 0,
		outcome = active.outcome,
		capitalCount = #capitals > 0 and #capitals or nil,
		capitalHull = capitalMaxHull > 0 and capitalHull or nil,
		capitalMaxHull = capitalMaxHull > 0 and capitalMaxHull or nil,
		breachZones = active.breachZones and #active.breachZones or nil,
		volleyReadyAt = active.nextVolleyAt or 0,
	}
end

function G.PublicSnapshot()
	local planet = G.EnsurePlanet(G.State.currentPlanet)
	return {
		version = G.Version,
		ready = G.State.ready,
		runtime = {
			enabled = G.Runtime.enabled,
			encounters = G.Runtime.encounters,
			attacks = G.Runtime.attacks,
		},
		currentPlanet = G.State.currentPlanet,
		currentRisk = G.State.currentRisk,
		planet = planet and {
			name = planet.name,
			allegiance = planet.allegiance,
			republicOpinion = planet.republicOpinion,
			cisOpinion = planet.cisOpinion,
			pressure = planet.pressure,
			locked = planet.locked,
		} or nil,
		nextEncounterAt = G.State.nextEncounterAt,
		intelUntil = G.State.intelUntil,
		intelText = G.State.intelText,
		activePlayers = G.ActivePlayerCount and G.ActivePlayerCount() or 0,
		comms = {
			terminalCount = #ents.FindByClass("mb_galaxy_comms"),
			scannerCount = #ents.FindByClass("mb_galaxy_scanner"),
			gunnerCount = #ents.FindByClass("mb_galaxy_gunner"),
			ionCount = #ents.FindByClass("mb_galaxy_ion"),
			torpedoCount = #ents.FindByClass("mb_galaxy_torpedo"),
			incoming = G.Active and G.Active.choices and #G.Active.choices > 0 or false,
			operator = IsValid(G.CommsOperator)
				and (G.CommsOperator.MBName and G.CommsOperator:MBName()
					or G.CommsOperator:Nick()) or "",
			scannerOperator = IsValid(G.ScannerOperator)
				and (G.ScannerOperator.MBName and G.ScannerOperator:MBName()
					or G.ScannerOperator:Nick()) or "",
			gunnerOperator = IsValid(G.GunnerOperator)
				and (G.GunnerOperator.MBName and G.GunnerOperator:MBName()
					or G.GunnerOperator:Nick()) or "",
			ionOperator = IsValid(G.IonOperator)
				and (G.IonOperator.MBName and G.IonOperator:MBName()
					or G.IonOperator:Nick()) or "",
			torpedoOperator = IsValid(G.TorpedoOperator)
				and (G.TorpedoOperator.MBName and G.TorpedoOperator:MBName()
					or G.TorpedoOperator:Nick()) or "",
		},
		active = publicActive(),
	}
end

local function writeCompressedNet(name, data, target)
	local raw = util.TableToJSON(data or {})
	local compressed = util.Compress(raw)
	if istable(target) and #target == 0 then return #raw, #compressed end
	net.Start(name)
		net.WriteUInt(#compressed, 24)
		net.WriteData(compressed, #compressed)
	if IsValid(target) or istable(target) then net.Send(target) else net.Broadcast() end
	return #raw, #compressed
end

function G.UpdateCommsTerminals()
	local active = G.Active
	local waiting = active and active.choices and #active.choices > 0 or false
	local operator = IsValid(G.CommsOperator) and G.CommsOperator or NULL
	local scannerOperator = IsValid(G.ScannerOperator) and G.ScannerOperator or NULL
	local gunnerOperator = IsValid(G.GunnerOperator) and G.GunnerOperator or NULL
	local pendingHail = G.PendingHail
	local pendingScan = G.PendingScan
	if pendingHail and (not IsValid(pendingHail.operator)
	or not IsValid(pendingHail.ship)) then
		G.PendingHail = nil
		pendingHail = nil
	end
	if pendingScan and (not IsValid(pendingScan.operator)
		or not IsValid(pendingScan.ship)) then
		G.PendingScan = nil
		pendingScan = nil
	end
	local status = not G.Runtime.enabled and "DIRECTOR OFFLINE"
		or waiting and "INCOMING TRANSMISSION"
		or pendingHail and "OUTGOING HAIL"
		or active and "TACTICAL CHANNEL"
		or "MONITORING"
	local contact = waiting and G.CleanText(active.source, 96)
		or pendingHail and G.CleanText(pendingHail.ship:GetShipName(), 96)
		or active and G.CleanText(active.title, 96)
		or "NO ACTIVE CONTACT"

	for _, terminal in ipairs(ents.FindByClass("mb_galaxy_comms")) do
		if IsValid(terminal) then
			terminal:SetOperator(operator)
			terminal:SetSignalWaiting(waiting)
			terminal:SetChannelStatus(status)
			terminal:SetContactName(contact)
		end
	end

	for _, terminal in ipairs(ents.FindByClass("mb_galaxy_scanner")) do
		if IsValid(terminal) then
			terminal:SetOperator(scannerOperator)
			terminal:SetSignalWaiting(pendingScan ~= nil)
			terminal:SetChannelStatus(not G.Runtime.enabled and "DIRECTOR OFFLINE"
				or pendingScan and "ACTIVE SENSOR SCAN" or "SENSOR WATCH")
			terminal:SetContactName(pendingScan and IsValid(pendingScan.ship)
				and G.CleanText(pendingScan.ship:GetShipName(), 96)
				or "NO ACTIVE SCAN")
		end
	end

	local ordnanceDisplays = {
		{ type = "turbolaser", class = "mb_galaxy_gunner", operator = gunnerOperator,
			next = G.NextSkyboxVolleyAt, last = G.LastSkyboxVolleyTarget,
			recharging = "TURBOLASERS RECHARGING", ready = "TURBOLASERS READY" },
		{ type = "ion", class = "mb_galaxy_ion", operator = IsValid(G.IonOperator)
			and G.IonOperator or NULL, next = G.NextIonCannonAt, last = G.LastIonTarget,
			recharging = "ION BANKS RECHARGING", ready = "ION CANNON READY" },
		{ type = "torpedo", class = "mb_galaxy_torpedo", operator = IsValid(G.TorpedoOperator)
			and G.TorpedoOperator or NULL, next = G.NextTorpedoAt, last = G.LastTorpedoTarget,
			recharging = "TORPEDO TUBES RELOADING", ready = "TORPEDO LOCK READY" },
	}
	for _, display in ipairs(ordnanceDisplays) do
		local recharge = math.max(0, (display.next or 0) - CurTime())
		local lastTarget = IsValid(display.last) and display.last or nil
		for _, terminal in ipairs(ents.FindByClass(display.class)) do
			if IsValid(terminal) then
				terminal:SetOperator(display.operator)
				terminal:SetSignalWaiting(false)
				terminal:SetChannelStatus(not G.Runtime.enabled and "DIRECTOR OFFLINE"
					or recharge > 0 and (display.recharging .. " " .. G.FormatDuration(recharge))
					or display.ready)
				terminal:SetContactName(lastTarget and G.CleanText(lastTarget:GetShipName(), 96)
					or "AWAITING SCANNER LOCK")
			end
		end
	end
end

local function navalConsoleAllowed(ply)
	local naval = MilBase.Naval
	if not naval or not naval.CanUseConsole then return true end
	return naval.CanUseConsole(ply)
end

local function requireNavalConsoleAccess(ply, terminal)
	if navalConsoleAllowed(ply) then return true end
	MilBase.Notify(ply, "ACCESS DENIED — REPUBLIC NAVY CREDENTIALS REQUIRED.", "warn")
	if IsValid(terminal) then terminal:EmitSound("buttons/button10.wav", 55, 92, 0.5) end
	return false
end

function G.CommsSessionValid(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if not navalConsoleAllowed(ply) then return false end
	if not IsValid(terminal) or terminal:GetClass() ~= "mb_galaxy_comms" then return false end
	local distance = math.max(80, tonumber(gd.CommsUseDistance) or 220)
	return ply:GetPos():DistToSqr(terminal:GetPos()) <= distance * distance
end

function G.ScannerSessionValid(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if not navalConsoleAllowed(ply) then return false end
	if not IsValid(terminal) or terminal:GetClass() ~= "mb_galaxy_scanner" then return false end
	local distance = math.max(80, tonumber(gd.ScannerUseDistance) or gd.CommsUseDistance or 220)
	return ply:GetPos():DistToSqr(terminal:GetPos()) <= distance * distance
end

local ordnanceStations = {
	turbolaser = {
		class = "mb_galaxy_gunner", operator = "GunnerOperator", terminal = "GunnerTerminal",
		distance = "GunnerUseDistance", label = "Turbolaser fire control",
	},
	ion = {
		class = "mb_galaxy_ion", operator = "IonOperator", terminal = "IonTerminal",
		distance = "IonUseDistance", label = "Ion cannon control",
	},
	torpedo = {
		class = "mb_galaxy_torpedo", operator = "TorpedoOperator", terminal = "TorpedoTerminal",
		distance = "TorpedoUseDistance", label = "Torpedo control",
	},
}

function G.OrdnanceTypeForTerminal(terminal)
	if not IsValid(terminal) then return nil end
	for kind, definition in pairs(ordnanceStations) do
		if terminal:GetClass() == definition.class then return kind end
	end
	return nil
end

function G.OrdnanceDefinition(kind)
	return ordnanceStations[kind]
end

function G.OrdnanceSessionValid(ply, terminal, kind)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if not navalConsoleAllowed(ply) then return false end
	kind = kind or G.OrdnanceTypeForTerminal(terminal)
	local definition = ordnanceStations[kind]
	if not definition or not IsValid(terminal) or terminal:GetClass() ~= definition.class then
		return false
	end
	local distance = math.max(80, tonumber(gd[definition.distance])
		or gd.GunnerUseDistance or gd.CommsUseDistance or 220)
	return ply:GetPos():DistToSqr(terminal:GetPos()) <= distance * distance
end

function G.GunnerSessionValid(ply, terminal)
	return G.OrdnanceSessionValid(ply, terminal, "turbolaser")
end

local hailFactionNames = {
	republic = "GALACTIC REPUBLIC",
	civilian = "CIVILIAN",
	pirate = "PIRATE / UNALIGNED",
	cis = "CONFEDERACY OF INDEPENDENT SYSTEMS",
	neutral = "UNIDENTIFIED",
}

local function validHailTarget(ship)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return false end
	if ship:GetHull() <= 0 or ship:GetShipState() == "destroyed" then return false end
	if ship.mb_galaxyMapSpace then return util.IsInWorld(ship:GetPos()) end
	return not G.IsInsideSkybox or G.IsInsideSkybox(ship:GetPos())
end

local function hailContactSnapshot(ship)
	local maxHull = math.max(1, ship:GetMaxHull())
	local faction = string.lower(G.CleanText(ship:GetFaction(), 24))
	if hailFactionNames[faction] == nil then faction = "neutral" end
	return {
		entity = ship:EntIndex(),
		name = G.CleanText(ship:GetShipName(), 96),
		faction = faction,
		factionName = hailFactionNames[faction],
		role = G.CleanText(ship:GetRole(), 48),
		sizeClass = G.CleanText(ship.GetSizeClass and ship:GetSizeClass() or "light", 24),
		state = G.CleanText(ship:GetShipState(), 48),
		hostile = ship:GetHostile(),
		capital = ship:GetCapital(),
		hull = math.Clamp(ship:GetHull(), 0, maxHull),
		maxHull = maxHull,
		shield = ship.GetShield and ship:GetShield() or nil,
		maxShield = ship.GetMaxShield and ship:GetMaxShield() or nil,
	}
end

function G.HailableShips()
	local ships = {}
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if validHailTarget(ship) then ships[#ships + 1] = ship end
	end
	table.sort(ships, function(a, b)
		if a:GetHostile() ~= b:GetHostile() then return a:GetHostile() end
		local factionA = string.lower(a:GetFaction())
		local factionB = string.lower(b:GetFaction())
		if factionA ~= factionB then return factionA < factionB end
		return string.lower(a:GetShipName()) < string.lower(b:GetShipName())
	end)
	return ships
end

function G.SendHailContacts(ply)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
	local contacts = {}
	local maximum = math.max(1, math.floor(tonumber(gd.MaximumHailContacts) or 16))
	for _, ship in ipairs(G.HailableShips()) do
		contacts[#contacts + 1] = hailContactSnapshot(ship)
		if #contacts >= maximum then break end
	end
	writeCompressedNet("MilBase_GalaxyHailContacts", {
		mode = "contacts",
		station = "communications",
		title = "OUTGOING COMMUNICATIONS",
		body = "Select a local sensor contact and transmit a hail. A ship may answer, ignore the signal, or respond according to its faction and current situation.",
		contacts = contacts,
	}, ply)
end

local function hailReply(ship)
	local faction = string.lower(ship:GetFaction())
	local name = G.CleanText(ship:GetShipName(), 96)
	local state = string.lower(ship:GetShipState())
	local hullFraction = ship:GetHull() / math.max(1, ship:GetMaxHull())
	local planet = G.CleanText(G.State.currentPlanet or "this sector", 96)

	if faction == "republic" then
		if ship:GetCombat() or state == "attacking" then
			return "REPUBLIC CHANNEL ESTABLISHED",
				name .. " acknowledges. \"We are engaged with hostile forces near "
				.. planet .. ". Keep weapons ready and stand by for tactical traffic.\""
		elseif hullFraction < 0.55 then
			return "REPUBLIC CHANNEL ESTABLISHED",
				name .. " answers with a damaged signal. \"Republic vessel, we read you. "
				.. "Our systems have taken damage, but we are still operational.\""
		end
		return "REPUBLIC CHANNEL ESTABLISHED",
			name .. " answers on an authenticated Republic frequency. "
			.. "\"Your signal is clear. No immediate threat is showing on our scopes.\""
	elseif faction == "civilian" then
		if ship:GetCombat() or state == "attacking" then
			return "CIVILIAN CHANNEL ESTABLISHED",
				name .. " answers urgently. \"Republic vessel, we are under fire! "
				.. "Any assistance you can provide would be appreciated!\""
		elseif (G.State.currentRisk or 0) >= 0.6 then
			return "CIVILIAN CHANNEL ESTABLISHED",
				name .. " responds. \"Good to hear a Republic voice. We saw suspicious "
				.. "traffic on the routes around " .. planet .. ". Travel carefully.\""
		end
		return "CIVILIAN CHANNEL ESTABLISHED",
			name .. " responds on an open civilian band. "
			.. "\"We read you, Republic vessel. We're only passing through the sector.\""
	elseif faction == "pirate" then
		if ship:GetHostile() or ship:GetCombat() or state == "attacking" then
			return "PIRATE CHANNEL ESTABLISHED",
				name .. " answers with an unsecured transmission. "
				.. "\"You've got our attention, Republic. Choose your next words carefully.\""
		end
		return "PIRATE CHANNEL ESTABLISHED",
			name .. " answers after a pause. "
			.. "\"State your business. Passage, cargo, or trouble—which one are you offering?\""
	elseif faction == "cis" then
		if ship:GetCapital() then
			return "CIS CHANNEL ESTABLISHED",
				name .. " answers on a hardened command frequency. "
				.. "\"Republic warship identified. Withdraw immediately or be destroyed.\""
		end
		return "CIS CHANNEL ESTABLISHED",
			name .. " returns a clipped droid transmission. "
			.. "\"Republic vessel: your position has been logged. Surrender is advised.\""
	end

	return "CHANNEL ESTABLISHED",
		name .. " acknowledges the hail but transmits no recognised identification."
end

function G.HandleHailRequest(ply, ship)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then
		MilBase.Notify(ply, "Remain at the ship communications terminal to transmit a hail.", "warn")
		return
	end
	if G.Active and G.Active.choices and #G.Active.choices > 0 then
		MilBase.Notify(ply, "Answer the incoming transmission before opening another channel.", "warn")
		G.SendEncounter(ply)
		return
	end
	if G.PendingHail then
		MilBase.Notify(ply, "An outgoing hail is already in progress.", "warn")
		return
	end
	if (ply.mb_nextGalaxyHail or 0) > CurTime() then
		MilBase.Notify(ply, "The communications array is cycling. Try again shortly.", "warn")
		return
	end
	if not validHailTarget(ship) then
		MilBase.Notify(ply, "That contact is no longer inside local sensor range.", "warn")
		G.SendHailContacts(ply)
		return
	end

	G._hailSequence = (G._hailSequence or 0) + 1
	local token = G._hailSequence
	local contact = hailContactSnapshot(ship)
	G.PendingHail = {
		token = token,
		operator = ply,
		terminal = G.CommsTerminal,
		ship = ship,
	}
	ply.mb_nextGalaxyHail = CurTime()
		+ math.max(1, tonumber(gd.OutgoingHailCooldown) or 8)
	writeCompressedNet("MilBase_GalaxyHailContacts", {
		mode = "pending",
		title = "TRANSMITTING HAIL",
		contact = contact,
		body = "Broadcasting Republic identification and waiting for "
			.. contact.name .. " to answer...",
	}, ply)
	G.UpdateCommsTerminals()
	G.BroadcastState()

	local minimum = math.max(0.1, tonumber(gd.OutgoingHailResponseDelayMin) or 0.8)
	local maximum = math.max(minimum, tonumber(gd.OutgoingHailResponseDelayMax) or 2.2)
	timer.Simple(math.Rand(minimum, maximum), function()
		local pending = G.PendingHail
		if not pending or pending.token ~= token then return end
		G.PendingHail = nil

		if not G.CommsSessionValid(ply, pending.terminal) then
			G.ReleaseCommsOperator(nil, true)
			return
		end
		if not validHailTarget(ship) then
			writeCompressedNet("MilBase_GalaxyHailContacts", {
				mode = "result",
				answered = false,
				title = "CONTACT LOST",
				body = "The ship left local sensor range before a channel could be established.",
				contact = contact,
			}, ply)
			G.BroadcastState()
			return
		end

		local faction = string.lower(ship:GetFaction())
		local chances = gd.HailResponseChance or {}
		local chance = tonumber(chances[faction]) or tonumber(chances.neutral) or 0.7
		local state = string.lower(ship:GetShipState())
		if ship:GetHostile() then chance = chance - 0.08 end
		if ship:GetCombat() then chance = chance - 0.08 end
		if state == "departing" or state == "retreating" then chance = chance - 0.2 end
		local answered = math.Rand(0, 1) <= math.Clamp(chance, 0.05, 0.99)
		local title, body
		if answered then
			title, body = hailReply(ship)
			local sound = tostring(gd.CommsHailResponseSound or "buttons/button15.wav")
			if sound ~= "" and IsValid(pending.terminal) then
				pending.terminal:EmitSound(sound, 68, 100, 0.75, CHAN_AUTO)
			end
		else
			title = "NO RESPONSE"
			body = contact.name .. " received the hail but did not open a channel."
		end
		writeCompressedNet("MilBase_GalaxyHailContacts", {
			mode = "result",
			answered = answered,
			title = title,
			body = body,
			contact = hailContactSnapshot(ship),
		}, ply)
		G.BroadcastState()
	end)
end

function G.ReleaseCommsOperator(reason, silent)
	local oldOperator = G.CommsOperator
	G.PendingHail = nil
	G.CommsOperator = nil
	G.CommsTerminal = nil

	if IsValid(oldOperator) then
		writeCompressedNet("MilBase_GalaxyEncounter", { close = true }, oldOperator)
		writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, oldOperator)
		if not silent and reason and reason ~= "" then
			MilBase.Notify(oldOperator, reason, "warn")
		end
	end
	G.UpdateCommsTerminals()
	G.BroadcastState()
end

function G.ReleaseScannerOperator(reason, silent)
	local oldOperator = G.ScannerOperator
	if G.PendingScan and G.PendingScan.operator == oldOperator then G.PendingScan = nil end
	G.ScannerOperator = nil
	G.ScannerTerminal = nil
	if IsValid(oldOperator) then
		writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, oldOperator)
		if not silent and reason and reason ~= "" then MilBase.Notify(oldOperator, reason, "warn") end
	end
	G.UpdateCommsTerminals()
	G.BroadcastState()
end

function G.ReleaseGunnerOperator(reason, silent)
	local oldOperator = G.GunnerOperator
	G.GunnerOperator = nil
	G.GunnerTerminal = nil
	if IsValid(oldOperator) then
		writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, oldOperator)
		if not silent and reason and reason ~= "" then MilBase.Notify(oldOperator, reason, "warn") end
	end
	G.UpdateCommsTerminals()
	G.BroadcastState()
end

function G.UseCommsTerminal(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
	if not IsValid(terminal) or terminal:GetClass() ~= "mb_galaxy_comms" then return end
	if not requireNavalConsoleAccess(ply, terminal) then return end
	if (ply.mb_nextGalaxyCommsUse or 0) > CurTime() then return end
	ply.mb_nextGalaxyCommsUse = CurTime() + 0.75

	if IsValid(G.CommsOperator) and not G.CommsSessionValid(G.CommsOperator, G.CommsTerminal) then
		G.ReleaseCommsOperator(nil, true)
	end

	if IsValid(G.CommsOperator) and G.CommsOperator ~= ply then
		local name = G.CommsOperator.MBName and G.CommsOperator:MBName()
			or G.CommsOperator:Nick()
		MilBase.Notify(ply, "Ship communications is currently operated by " .. name .. ".", "warn")
		return
	end

	G.CommsOperator = ply
	G.CommsTerminal = terminal
	G.UpdateCommsTerminals()
	G.BroadcastState()

	if G.Active and G.Active.choices and #G.Active.choices > 0 then
		writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, ply)
		G.SendEncounter(ply)
		MilBase.Notify(ply, "Private ship channel connected.", "ok")
	elseif G.PendingHail and G.PendingHail.operator == ply
	and IsValid(G.PendingHail.ship) then
		writeCompressedNet("MilBase_GalaxyEncounter", { close = true }, ply)
		writeCompressedNet("MilBase_GalaxyHailContacts", {
			mode = "pending",
			title = "TRANSMITTING HAIL",
			contact = hailContactSnapshot(G.PendingHail.ship),
			body = "The communications array is waiting for the selected contact to answer...",
		}, ply)
	else
		writeCompressedNet("MilBase_GalaxyEncounter", { close = true }, ply)
		G.SendHailContacts(ply)
		MilBase.Notify(ply, "Communications station connected. Local contacts are ready to hail.", "ok")
	end
end

function G.UseScannerTerminal(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
	if not IsValid(terminal) or terminal:GetClass() ~= "mb_galaxy_scanner" then return end
	if not requireNavalConsoleAccess(ply, terminal) then return end
	if (ply.mb_nextGalaxyScannerUse or 0) > CurTime() then return end
	ply.mb_nextGalaxyScannerUse = CurTime() + 0.75
	if IsValid(G.ScannerOperator) and not G.ScannerSessionValid(G.ScannerOperator, G.ScannerTerminal) then
		G.ReleaseScannerOperator(nil, true)
	end
	if IsValid(G.ScannerOperator) and G.ScannerOperator ~= ply then
		local name = G.ScannerOperator.MBName and G.ScannerOperator:MBName()
			or G.ScannerOperator:Nick()
		MilBase.Notify(ply, "Tactical scanner is currently operated by " .. name .. ".", "warn")
		return
	end
	G.ScannerOperator = ply
	G.ScannerTerminal = terminal
	G.UpdateCommsTerminals()
	G.BroadcastState()
	if G.SendScannerContacts then
		G.SendScannerContacts(ply)
		MilBase.Notify(ply, "Tactical scanner connected. Resolve local contacts for the bridge.", "ok")
	else
		MilBase.Notify(ply, "Tactical scanner is loading. Try again in a moment.", "warn")
	end
end

function G.UseGunnerTerminal(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
	if not IsValid(terminal) or terminal:GetClass() ~= "mb_galaxy_gunner" then return end
	if not requireNavalConsoleAccess(ply, terminal) then return end
	if (ply.mb_nextGalaxyGunnerUse or 0) > CurTime() then return end
	ply.mb_nextGalaxyGunnerUse = CurTime() + 0.75
	if IsValid(G.GunnerOperator) and not G.GunnerSessionValid(G.GunnerOperator, G.GunnerTerminal) then
		G.ReleaseGunnerOperator(nil, true)
	end
	if IsValid(G.GunnerOperator) and G.GunnerOperator ~= ply then
		local name = G.GunnerOperator.MBName and G.GunnerOperator:MBName()
			or G.GunnerOperator:Nick()
		MilBase.Notify(ply, "Long-range fire control is currently operated by " .. name .. ".", "warn")
		return
	end
	G.GunnerOperator = ply
	G.GunnerTerminal = terminal
	G.UpdateCommsTerminals()
	G.BroadcastState()
	if G.SendGunnerContacts then
		G.SendGunnerContacts(ply)
		MilBase.Notify(ply, "Long-range fire control connected. Await scanner-locked hostiles.", "ok")
	else
		MilBase.Notify(ply, "Long-range fire control is loading. Try again in a moment.", "warn")
	end
end

function G.ReleaseOrdnanceOperator(kind, reason, silent)
	if kind == "turbolaser" then return G.ReleaseGunnerOperator(reason, silent) end
	local definition = ordnanceStations[kind]
	if not definition then return end
	local oldOperator = G[definition.operator]
	G[definition.operator] = nil
	G[definition.terminal] = nil
	if IsValid(oldOperator) then
		writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, oldOperator)
		if not silent and reason and reason ~= "" then MilBase.Notify(oldOperator, reason, "warn") end
	end
	G.UpdateCommsTerminals()
	G.BroadcastState()
end

function G.ReleaseOrdnanceOperatorForTerminal(terminal, reason)
	local kind = G.OrdnanceTypeForTerminal(terminal)
	local definition = kind and ordnanceStations[kind] or nil
	if definition and G[definition.terminal] == terminal then
		G.ReleaseOrdnanceOperator(kind, reason, true)
	end
end

function G.UseOrdnanceTerminal(ply, terminal)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
	if not requireNavalConsoleAccess(ply, terminal) then return end
	local kind = G.OrdnanceTypeForTerminal(terminal)
	if kind == "turbolaser" then return G.UseGunnerTerminal(ply, terminal) end
	local definition = kind and ordnanceStations[kind] or nil
	if not definition then return end
	local cooldownKey = "mb_nextGalaxy" .. string.upper(string.sub(kind, 1, 1))
		.. string.sub(kind, 2) .. "Use"
	if (ply[cooldownKey] or 0) > CurTime() then return end
	ply[cooldownKey] = CurTime() + 0.75
	local operator = G[definition.operator]
	local activeTerminal = G[definition.terminal]
	if IsValid(operator) and not G.OrdnanceSessionValid(operator, activeTerminal, kind) then
		G.ReleaseOrdnanceOperator(kind, nil, true)
		operator = nil
	end
	if IsValid(operator) and operator ~= ply then
		local name = operator.MBName and operator:MBName() or operator:Nick()
		MilBase.Notify(ply, definition.label .. " is currently operated by " .. name .. ".", "warn")
		return
	end
	G[definition.operator] = ply
	G[definition.terminal] = terminal
	G.UpdateCommsTerminals()
	G.BroadcastState()
	if G.SendOrdnanceContacts then
		G.SendOrdnanceContacts(ply, kind)
		MilBase.Notify(ply, definition.label .. " connected. Await scanner-locked hostiles.", "ok")
	else
		MilBase.Notify(ply, definition.label .. " is loading. Try again in a moment.", "warn")
	end
end

function G.BroadcastState(target)
	if IsValid(target) and not G.IsNavyRecipient(target) then return end
	if not IsValid(target) then
		local now = CurTime()
		local minimum = math.max(0.05,
			tonumber(gd.GalaxyStateBroadcastMinimumInterval) or 0.12)
		local elapsed = now - (G._lastStateBroadcastAt or 0)
		if elapsed < minimum then
			if not G._stateBroadcastPending then
				G._stateBroadcastPending = true
				timer.Simple(math.max(0.01, minimum - elapsed), function()
					G._stateBroadcastPending = nil
					if G and G.BroadcastState then G.BroadcastState() end
				end)
			end
			return
		end
		G._lastStateBroadcastAt = now
	end
	G.UpdateCommsTerminals()
	local recipients = IsValid(target) and target or G.NavyRecipients()
	local rawBytes, compressedBytes =
		writeCompressedNet("MilBase_GalaxyState", G.PublicSnapshot(), recipients)
	if MilBase.Performance and MilBase.Performance.RecordNetwork then
		MilBase.Performance.RecordNetwork("galaxy_state", rawBytes,
			compressedBytes, IsValid(target) and 1 or #recipients)
	end
end

function G.SendEncounter(target)
	local recipient = IsValid(target) and target or G.CommsOperator
	if not IsValid(recipient) or recipient ~= G.CommsOperator then return end
	local active = G.Active
	if not active or not active.choices or #active.choices == 0 then
		writeCompressedNet("MilBase_GalaxyEncounter", { close = true }, recipient)
		return
	end

	if G.PendingHail and G.PendingHail.operator == recipient then
		G.PendingHail = nil
		G.UpdateCommsTerminals()
	end
	writeCompressedNet("MilBase_GalaxyHailContacts", { mode = "close" }, recipient)
	writeCompressedNet("MilBase_GalaxyEncounter", {
		id = active.id,
		kind = active.kind,
		title = active.title,
		body = active.body,
		source = active.source,
		timeout = active.endsAt,
		choices = active.choices,
	}, recipient)
end

local function anchorSnapshot()
	local anchors = {}
	for _, anchor in ipairs(G.Anchors) do
		anchors[#anchors + 1] = {
			id = anchor.id,
			kind = anchor.kind,
			label = anchor.label,
			pos = { x = anchor.pos.x, y = anchor.pos.y, z = anchor.pos.z },
		}
	end
	return anchors
end

function G.AdminSnapshot()
	local planets = {}
	for _, planet in pairs(G.Planets) do
		planets[#planets + 1] = {
			key = planet.key,
			name = planet.name,
			allegiance = planet.allegiance,
			republicOpinion = planet.republicOpinion,
			cisOpinion = planet.cisOpinion,
			pressure = planet.pressure,
			locked = planet.locked,
			lockFaction = planet.lockFaction,
			note = planet.note,
		}
	end
	table.sort(planets, function(a, b) return string.lower(a.name) < string.lower(b.name) end)

	local recommendations = {}
	for _, recommendation in ipairs(G.Recommendations) do
		local planet = G.Planets[recommendation.planetKey]
		recommendations[#recommendations + 1] = {
			id = recommendation.id,
			createdAt = recommendation.createdAt,
			planet = planet and planet.name or recommendation.planetKey,
			republicDelta = recommendation.republicDelta,
			cisDelta = recommendation.cisDelta,
			reason = recommendation.reason,
			source = recommendation.source,
		}
	end

	return {
		public = G.PublicSnapshot(),
		runtime = table.Copy(G.Runtime),
		planets = planets,
		anchors = anchorSnapshot(),
		recommendations = recommendations,
		orbitalBlockades = table.Copy(G.OrbitalBlockades or {}),
		eventEnemySpawnCount = table.Count(MilBase.EventEnemySpawns or {}),
		swuAvailable = SWU ~= nil and IsValid(SWU.Controller),
		lastMajorAttack = G.State.lastMajorAttack,
	}
end

function G.SendAdminData(ply)
	if not G.IsStaff(ply) then return end
	writeCompressedNet("MilBase_GalaxyAdminData", G.AdminSnapshot(), ply)
end

local discordNextPost = 0
local ok, reqwestAvailable = pcall(require, "reqwest")

function G.DiscordPost(title, description, color, mention)
	if not discord.Enabled or G.CleanText(discord.WebhookURL, 1000) == "" then return end
	if CurTime() < discordNextPost then return end
	discordNextPost = CurTime() + math.max(5, tonumber(discord.MinimumSecondsBetweenPosts) or 20)

	local roleID = string.match(tostring(discord.RoleID or ""), "^(%d+)$")
	local content = mention and roleID and ("<@&" .. roleID .. ">") or ""
	local payload = {
		username = G.CleanText(discord.Username, 80) ~= "" and discord.Username
			or "Republic Strategic Command",
		avatar_url = G.CleanText(discord.AvatarURL, 1000),
		content = content,
		allowed_mentions = { parse = {}, roles = mention and roleID and { roleID } or {} },
		embeds = {
			{
				title = G.CleanText(title, 256),
				description = G.CleanText(description, 3500),
				color = tonumber(color) or 15158332,
				timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
				footer = { text = "MilBase Galaxy Director" },
			},
		},
	}

	local requestData = {
		url = discord.WebhookURL,
		method = "POST",
		type = "application/json",
		headers = {
			["Content-Type"] = "application/json",
			["User-Agent"] = "curl/8.4.0",
		},
		body = util.TableToJSON(payload),
		success = function(code)
			if code < 200 or code >= 300 then
				log("Discord rejected a message (HTTP " .. tostring(code) .. ").",
					Color(245, 160, 80))
			end
		end,
		failed = function(err)
			log("Discord delivery failed: " .. tostring(err), Color(245, 100, 90))
		end,
	}

	if ok and reqwest then
		reqwest(requestData)
	else
		HTTP(requestData)
	end
end
function G.ScheduleNextEncounter()
	local low = math.max(30, tonumber(G.Runtime.encounterMin) or 480)
	local high = math.max(low, tonumber(G.Runtime.encounterMax) or 900)
	G.State.nextEncounterAt = CurTime() + math.Rand(low, high)
end

function G.ScheduleNextAmbient()
	local low = math.max(20, tonumber(G.Runtime.ambientMin) or 180)
	local high = math.max(low, tonumber(G.Runtime.ambientMax) or 360)
	G.State.nextAmbientAt = CurTime() + math.Rand(low, high)
end

local function markActivity(ply)
	if IsValid(ply) and ply:IsPlayer() then ply.mb_galaxyLastActive = CurTime() end
end

hook.Add("PlayerInitialSpawn", "MilBase.GalaxyActivity", markActivity)
hook.Add("KeyPress", "MilBase.GalaxyActivity", markActivity)
hook.Add("PlayerSay", "MilBase.GalaxyActivity", function(ply) markActivity(ply) end)
hook.Add("SetupMove", "MilBase.GalaxyActivity", function(ply, mv)
	if not IsValid(ply) or ply:IsBot() then return end
	local now = CurTime()
	if now < (ply.mb_galaxyNextMoveCheck or 0) then return end
	ply.mb_galaxyNextMoveCheck = now + 2

	local position = mv:GetOrigin()
	local angle = mv:GetAngles()
	local moved = not isvector(ply.mb_galaxyLastPos)
		or position:DistToSqr(ply.mb_galaxyLastPos) > 16
	local looked = not isangle(ply.mb_galaxyLastAng)
		or math.abs(math.AngleDifference(angle.y, ply.mb_galaxyLastAng.y)) > 2
		or math.abs(math.AngleDifference(angle.p, ply.mb_galaxyLastAng.p)) > 2

	ply.mb_galaxyLastPos = position
	ply.mb_galaxyLastAng = angle
	if moved or looked or mv:GetButtons() ~= 0 then markActivity(ply) end
end)

function G.ActivePlayers()
	local result = {}
	local afkSeconds = math.max(60, tonumber(G.Runtime.afkSeconds) or 600)
	for _, ply in ipairs(player.GetHumans()) do
		if IsValid(ply) and (ply.mb_galaxyLastActive or CurTime()) >= CurTime() - afkSeconds then
			result[#result + 1] = ply
		end
	end
	return result
end

function G.ActivePlayerCount()
	return #G.ActivePlayers()
end

hook.Add("PlayerInitialSpawn", "MilBase.GalaxyInitialSync", function(ply)
	timer.Simple(4, function()
		if not IsValid(ply) then return end
		G.BroadcastState(ply)
	end)
end)

hook.Add("PlayerDeath", "MilBase.GalaxyReleaseCommsOnDeath", function(ply)
	if G.CommsOperator == ply then
		G.ReleaseCommsOperator("Ship communications disconnected.", true)
	end
	if G.ScannerOperator == ply then G.ReleaseScannerOperator("Tactical scanner disconnected.", true) end
	if G.GunnerOperator == ply then G.ReleaseGunnerOperator("Fire control disconnected.", true) end
	if G.IonOperator == ply then G.ReleaseOrdnanceOperator("ion", "Ion cannon disconnected.", true) end
	if G.TorpedoOperator == ply then G.ReleaseOrdnanceOperator("torpedo", "Torpedo control disconnected.", true) end
end)

hook.Add("PlayerDisconnected", "MilBase.GalaxyReleaseCommsOnLeave", function(ply)
	if G.CommsOperator == ply then G.ReleaseCommsOperator(nil, true) end
	if G.ScannerOperator == ply then G.ReleaseScannerOperator(nil, true) end
	if G.GunnerOperator == ply then G.ReleaseGunnerOperator(nil, true) end
	if G.IonOperator == ply then G.ReleaseOrdnanceOperator("ion", nil, true) end
	if G.TorpedoOperator == ply then G.ReleaseOrdnanceOperator("torpedo", nil, true) end
end)

hook.Add("SWU.MapLoaded", "MilBase.GalaxySWUMapLoaded", function()
	timer.Simple(1, function()
		if not G.State.ready then return end
		G.DetectCurrentPlanet()
	end)
end)

function G.IsHyperspaceTransitActive()
	return G.HyperspaceTransitActive == true
end

function G.SetHyperspaceTransitActive(active)
	active = active == true
	if G.HyperspaceTransitActive == active then return end
	G.HyperspaceTransitActive = active
	SetGlobalBool("MBGalaxyHyperspaceTransit", active)

	if active then
		-- Local ship entities are only visual representatives of the simulated
		-- universe. Remove every representative for a clean hyperspace tunnel;
		-- persistent traffic and owned-fleet records remain in their databases.
		for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
			if IsValid(ship) then
				ship.mb_galaxyHyperspaceRemoval = true
				if ship.mb_navalOwnedFleetID then
					ship.mb_navalFleetIntentionalRemoval = true
				end
				ship:Remove()
			end
		end
		return
	end

	-- Arrival changes the current system before this callback is scheduled.
	-- Rebuild only the destination's simulated traffic, blockades and owned
	-- support fleet rather than restoring stale entities from the old system.
	timer.Simple(0.35, function()
		if G.IsHyperspaceTransitActive() then return end
		if G.UpdateUniverseTraffic then G.UpdateUniverseTraffic(os.time(), true) end
		G.NextOrbitalBlockadeCheck = 0
		if MilBase.Naval and MilBase.Naval.SyncFleetVisuals then
			MilBase.Naval.SyncFleetVisuals()
		end
	end)
end

hook.Add("SWU.OnHyperspaceStateChange", "MilBase.GalaxySWUTravel", function(oldState, newState)
	oldState = tonumber(oldState) or 0
	newState = tonumber(newState) or 0

	if newState == 1 then
		if G.Active and G.Active.kind == "cis_raid" then
			if gd.AllowFleeDuringRaid ~= false then
				G.ResolveRaid("fled",
					"Emergency hyperspace jump successful. The Republic ship escaped the CIS assault.")
			elseif G.CancelActive then
				G.CancelActive("Hyperspace transit cleared the local CIS assault.")
			end
		elseif G.Active and G.Active.kind ~= "cis_raid" and G.CancelActive then
			G.CancelActive("The Republic ship left the local encounter behind in hyperspace.")
		end
		if G.Operation and G.CancelOperation then
			G.CancelOperation("The Republic ship entered hyperspace and left the operation area.")
		end
		G.SetHyperspaceTransitActive(true)
	end

	if oldState == 2 and newState == 1 then
		local nav = SWU and SWU.NavigationComputer
		local destination = IsValid(nav) and nav.GetTargetPlanet and nav:GetTargetPlanet() or ""
		if destination ~= "" then G.PendingDestination = destination end
	elseif oldState == 1 and newState == 0 and G.PendingDestination then
		local destination = G.PendingDestination
		G.PendingDestination = nil
		G.SetCurrentPlanet(destination, "hyperspace arrival")

		local delay = math.max(3, tonumber(G.Runtime.arrivalDelay) or 18)
		timer.Create("MilBase.GalaxyArrivalEncounter", delay, 1, function()
			if not G.Active and math.Rand(0, 1) <= (gd.ArrivalEncounterChance or 0.72) then
				G.TryStartRandomEncounter("arrival")
			end
		end)
	end
	if newState == 0 then G.SetHyperspaceTransitActive(false) end
end)

local shipNamePools = {
	republic = { "Resolute Patrol", "Open Circle Escort", "Republic Vanguard",
		"Judicial Support Vessel", "Republic Medical Detachment" },
	republic_fighter = { "Blue Flight", "Red Flight", "Gold Flight",
		"Republic Interceptor Patrol", "Open Circle Fighter Element" },
	republic_capital = { "Republic Venator-class Star Destroyer",
		"Open Circle Fleet Venator", "Republic Fleet Carrier",
		"Venator-class Blockade Vessel" },
	civilian = { "Wayfarer", "Silver Current", "Dawn Trader", "Sundari Star",
		"Corellian Venture", "Free Commerce Vessel" },
	civilian_shuttle = { "Local Shuttle", "Passenger Transfer", "Courier Flight",
		"Orbital Taxi", "Independent Transport" },
	pirate = { "Black Sun Raider", "Crimson Talon", "Outer Rim Corsair",
		"Broken Fang", "Kessel Marauder" },
	pirate_fighter = { "Black Sun Talon", "Corsair Flight", "Razor Wing",
		"Broken Fang Interceptor", "Kessel Attack Craft" },
	cis = { "CIS Recon Element", "Droid Control Frigate", "Separatist Patrol",
		"Confederate Strike Vessel" },
	cis_fighter = { "Vulture Droid Flight", "CIS Interceptor Screen",
		"Droid Fighter Element", "Separatist Pursuit Flight" },
	cis_capital = { "CIS Munificent-class Frigate", "Separatist Assault Frigate",
		"Confederate Blockade Vessel" },
}

function G.IsBlockedShipModel(model)
	local lower = string.lower(tostring(model or ""))
	for _, fragment in ipairs(gd.BlockedShipModelFragments or {}) do
		fragment = string.lower(string.Trim(tostring(fragment or "")))
		if fragment ~= "" and string.find(lower, fragment, 1, true) then return true end
	end
	return false
end

local function cleanShipSizeClass(value)
	value = string.lower(string.Trim(tostring(value or "")))
	if value == "" then return "" end
	return (gd.ShipSizeClasses or {})[value] and value or ""
end

function G.ShipSizeClass(role, model, requested)
	local sizeClass = cleanShipSizeClass(requested)
	if sizeClass ~= "" then return sizeClass end

	local modelClasses = gd.ShipModelSizeClass or {}
	sizeClass = cleanShipSizeClass(modelClasses[string.lower(
		string.Trim(tostring(model or "")))])
	if sizeClass ~= "" then return sizeClass end

	local defaults = gd.ShipRoleDefaultSizeClass or {}
	sizeClass = cleanShipSizeClass(defaults[string.lower(
		string.Trim(tostring(role or "")))])
	if sizeClass ~= "" then return sizeClass end
	return cleanShipSizeClass(defaults.default) ~= ""
		and cleanShipSizeClass(defaults.default) or "light"
end

function G.ShipSizeDefinition(sizeClass)
	sizeClass = cleanShipSizeClass(sizeClass)
	return (gd.ShipSizeClasses or {})[sizeClass]
		or (gd.ShipSizeClasses or {}).light or {}
end

function G.ResolveShipVariant(role, requestedSizeClass)
	local requested = cleanShipSizeClass(requestedSizeClass)
	local valid = {}
	local totalWeight = 0
	for _, variant in ipairs((gd.ShipVariantPools or {})[role] or {}) do
		local model = string.Trim(tostring(variant.model or ""))
		local sizeClass = G.ShipSizeClass(role, model, variant.sizeClass)
		if model ~= "" and not G.IsBlockedShipModel(model)
		and util.IsValidModel(model)
		and (requested == "" or sizeClass == requested) then
			local weight = math.max(0.01, tonumber(variant.weight) or 1)
			totalWeight = totalWeight + weight
			valid[#valid + 1] = {
				model = model,
				sizeClass = sizeClass,
				weight = weight,
			}
		end
	end
	if #valid == 0 then return nil end

	local roll = math.Rand(0, totalWeight)
	for _, variant in ipairs(valid) do
		roll = roll - variant.weight
		if roll <= 0 then return variant end
	end
	return valid[#valid]
end

function G.ShipFormationSpacing(sizeClass)
	local definition = G.ShipSizeDefinition(sizeClass)
	return math.max(24, tonumber(definition.formationSpacing)
		or tonumber(definition.targetRadius) * 2.4 or 100)
end

function G.ResolveShipModel(role)
	local valid = {}
	for _, model in ipairs((gd.ShipModels or {})[role] or {}) do
		if not G.IsBlockedShipModel(model) and util.IsValidModel(model) then
			valid[#valid + 1] = model
		end
	end
	if #valid > 0 then return valid[math.random(#valid)] end
	return "models/hunter/blocks/cube2x2x2.mdl"
end

function G.ClampShipModelScale(ent, role)
	if not IsValid(ent) then return end
	local maximumScale = math.max(0.005,
		tonumber(gd.SkyboxMaximumModelScale) or 1.25)
	local scale = math.Clamp(tonumber(ent:GetModelSize()) or 0.05, 0.005, maximumScale)
	local requestedSizeClass = ent.mb_galaxySizeClassLocked
		and ent.GetSizeClass and ent:GetSizeClass() or ""
	local sizeClass = G.ShipSizeClass(role, ent:GetModel(), requestedSizeClass)
	local definition = G.ShipSizeDefinition(sizeClass)
	if ent.SetSizeClass then ent:SetSizeClass(sizeClass) end

	local limits = gd.MaximumShipVisualRadius or {}
	local maximum = math.max(8, tonumber(definition.maximumRadius)
		or tonumber(limits[role]) or tonumber(limits.default) or 320)
	local targets = gd.ShipModelTargetRadius or {}
	local targetRadius = math.max(0, tonumber(definition.targetRadius)
		or tonumber(targets[role]) or 0)
	local mins, maxs
	if ent.GetModelRenderBounds then
		mins, maxs = ent:GetModelRenderBounds()
	elseif ent.GetModelBounds then
		mins, maxs = ent:GetModelBounds()
	end
	if isvector(mins) and isvector(maxs) then
		local nativeRadius = math.max(mins:Length(), maxs:Length())
		if nativeRadius > 0 then
			if targetRadius > 0 then
				scale = math.Clamp(targetRadius / nativeRadius, 0.005, maximumScale)
			end
			scale = math.min(scale, maximum / nativeRadius)
		end
		ent.mb_galaxyVisualRadius = nativeRadius * scale
	end
	ent.mb_galaxyVisualRadius = ent.mb_galaxyVisualRadius or maximum
	if ent.SetCombatRadius then
		ent:SetCombatRadius(math.max(6, ent.mb_galaxyVisualRadius))
	end
	ent:SetModelSize(scale)
	ent:SetModelScale(scale, 0.000001)
	if isvector(mins) and isvector(maxs) then
		ent:SetCollisionBounds(mins * scale, maxs * scale)
	end
	if ent.RefreshCombatCollision then
		ent:RefreshCombatCollision(ent:GetHostile()
			and (MilBase.Config.GalaxyDirector or {}).CISUseModelCollision ~= false)
	end
end

function G.ApplyMapSpaceShipScale(ent, role)
	if not IsValid(ent) then return end
	local requestedSizeClass = ent.mb_galaxySizeClassLocked
		and ent.GetSizeClass and ent:GetSizeClass() or ""
	local sizeClass = G.ShipSizeClass(role, ent:GetModel(), requestedSizeClass)
	if ent.SetSizeClass then ent:SetSizeClass(sizeClass) end
	local scales = gd.MapSpaceShipModelScale or {}
	local scale = math.max(0.005, tonumber(scales[role])
		or tonumber(scales.default) or 1)
	local mins, maxs = ent:GetModelRenderBounds()
	if isvector(mins) and isvector(maxs) then
		local radius = math.max(mins:Length(), maxs:Length()) * scale
		ent.mb_galaxyVisualRadius = radius
		ent:SetCombatRadius(math.max(6, radius))
		ent:SetCollisionBounds(mins * scale, maxs * scale)
	end
	ent:SetModelSize(scale)
	ent:SetModelScale(scale, 0.000001)
	if ent.RefreshCombatCollision then
		ent:RefreshCombatCollision(ent:GetHostile()
			and (MilBase.Config.GalaxyDirector or {}).CISUseModelCollision ~= false)
	end
end

function G.SkyboxFrame()
	local swuConfig = SWU and SWU.config
	local bounds = swuConfig and swuConfig.skyboxBoundaries
	local center = bounds and bounds.center
		or swuConfig and swuConfig.controllerPos
		or Vector(0, 0, 0)
	local rawMin = bounds and bounds.min
	local rawMax = bounds and bounds.max
	if not isvector(rawMin) or not isvector(rawMax)
	or math.abs(rawMax.x - rawMin.x) < 256
	or math.abs(rawMax.y - rawMin.y) < 256 then
		rawMin = center - Vector(2200, 2200, 700)
		rawMax = center + Vector(2200, 2200, 700)
	end
	local min = Vector(math.min(rawMin.x, rawMax.x), math.min(rawMin.y, rawMax.y),
		math.min(rawMin.z, rawMax.z))
	local max = Vector(math.max(rawMin.x, rawMax.x), math.max(rawMin.y, rawMax.y),
		math.max(rawMin.z, rawMax.z))
	center = Vector((min.x + max.x) * 0.5, (min.y + max.y) * 0.5,
		(min.z + max.z) * 0.5)
	local radius = math.max(600, math.min(math.abs(max.x - min.x), math.abs(max.y - min.y)) * 0.38)
	return center, radius, min, max
end

function G.SkyboxEntryPoint(sideYaw, lane, height)
	local center, radius, min, max = G.SkyboxFrame()
	local yaw = tonumber(sideYaw) or math.Rand(0, 360)
	local direction = Angle(0, yaw, 0):Forward()
	local requestedInset = math.max(32, tonumber(gd.SkyboxEntryInset) or 180)
	local inset = math.min(requestedInset,
		math.max(32, math.min(max.x - min.x, max.y - min.y) * 0.45))
	local heightInset = math.min(inset, math.max(16, (max.z - min.z) * 0.45))
	local distanceX = math.huge
	local distanceY = math.huge
	if math.abs(direction.x) > 0.0001 then
		distanceX = direction.x > 0 and (max.x - center.x) / direction.x
			or (min.x - center.x) / direction.x
	end
	if math.abs(direction.y) > 0.0001 then
		distanceY = direction.y > 0 and (max.y - center.y) / direction.y
			or (min.y - center.y) / direction.y
	end
	local edgeDistance = math.max(inset + 32, math.min(distanceX, distanceY))
	local side = direction * math.max(32, edgeDistance - inset)
	local across = Angle(0, yaw + 90, 0):Forward() * (tonumber(lane) or 0)
	local start = center + side + across
	start.x = math.Clamp(start.x, min.x + inset, max.x - inset)
	start.y = math.Clamp(start.y, min.y + inset, max.y - inset)
	start.z = math.Clamp(center.z + (tonumber(height)
		or math.Rand(-radius * 0.12, radius * 0.12)),
		min.z + heightInset, max.z - heightInset)
	return start, direction, yaw
end

function G.MaximumRoleShipRadius(role, sizeClass)
	local definition = G.ShipSizeDefinition(G.ShipSizeClass(role, "", sizeClass))
	local limits = gd.MaximumShipVisualRadius or {}
	return math.max(8, tonumber(definition.maximumRadius)
		or tonumber(limits[role]) or tonumber(limits.default) or 320)
end

function G.MaximumShipRadius(ent)
	if not IsValid(ent) then return G.MaximumRoleShipRadius("default") end
	return math.max(6, tonumber(ent.mb_galaxyVisualRadius)
		or G.MaximumRoleShipRadius(ent:GetRole(),
			ent.GetSizeClass and ent:GetSizeClass() or ""))
end

function G.GetPlanetObstacles()
	if gd.PlanetAvoidanceEnabled == false or not SWU then return {} end
	if G._planetObstacleCache and CurTime() < (G._planetObstacleCacheUntil or 0) then
		return G._planetObstacleCache
	end
	G._planetObstacleCache = ents.FindByClass("swu_so_planet")
	G._planetObstacleCacheUntil = CurTime() + 1
	return G._planetObstacleCache
end

function G.PlanetWorldPosition(planet)
	if not IsValid(planet) then return nil end
	if G.HasSWUUniverseFrame() and planet.GetUniversePos then
		local universePos = planet:GetUniversePos()
		if isvector(universePos) then
			local ok, worldPos = pcall(SWU.CalculateWorldPos, SWU, universePos)
			if ok and isvector(worldPos) then return worldPos end
		end
	end
	return planet:GetPos()
end

function G.PlanetObstacleRadius(planet)
	if not IsValid(planet) then return 0 end
	local radius = 0
	if planet.GetCollisionRange then
		local ok, value = pcall(planet.GetCollisionRange, planet)
		if ok then radius = math.max(radius, tonumber(value) or 0) end
	end
	if planet.GetModelRenderBounds then
		local mins, maxs = planet:GetModelRenderBounds()
		if isvector(mins) and isvector(maxs) then
			local baseScale = planet.GetBaseScale and tonumber(planet:GetBaseScale())
				or tonumber(planet:GetModelScale()) or 1
			local nativeRadius = math.max(math.abs(mins.x), math.abs(mins.y), math.abs(mins.z),
				math.abs(maxs.x), math.abs(maxs.y), math.abs(maxs.z))
			radius = math.max(radius, nativeRadius * math.max(0, baseScale or 1))
		end
	end
	return radius
end

function G.PlanetClearanceAt(pos, shipRadius)
	if gd.PlanetAvoidanceEnabled == false or not isvector(pos) then return true, math.huge end
	local margin = math.max(0, tonumber(gd.PlanetAvoidanceMargin) or 180)
	local bestClearance = math.huge
	for _, planet in ipairs(G.GetPlanetObstacles()) do
		local planetPos = G.PlanetWorldPosition(planet)
		local obstacleRadius = G.PlanetObstacleRadius(planet)
			+ math.max(0, tonumber(shipRadius) or 0) + margin
		if isvector(planetPos) and obstacleRadius > 0 then
			bestClearance = math.min(bestClearance, pos:Distance(planetPos) - obstacleRadius)
		end
	end
	return bestClearance >= 0, bestClearance
end

function G.FindClearSkyboxEntry(sideYaw, lane, height, role, sizeClass)
	local _, radius = G.SkyboxFrame()
	local baseYaw = tonumber(sideYaw) or math.Rand(0, 360)
	local baseLane = tonumber(lane) or 0
	local baseHeight = tonumber(height) or math.Rand(-radius * 0.12, radius * 0.12)
	local shipRadius = G.MaximumRoleShipRadius(role, sizeClass)
	local yawOffsets = { 0, 12, -12, 24, -24, 40, -40, 60, -60, 90, -90, 135, -135, 180 }
	local laneOffsets = { 0, 280, -280, 560, -560 }
	for yawIndex, yawOffset in ipairs(yawOffsets) do
		local heightOffset = ((yawIndex - 1) % 3 - 1) * 260
		for _, laneOffset in ipairs(laneOffsets) do
			local start, direction, yaw = G.SkyboxEntryPoint(baseYaw + yawOffset,
				baseLane + laneOffset, baseHeight + heightOffset)
			local clear = G.PlanetClearanceAt(start, shipRadius)
			if clear then return start, direction, yaw end
		end
	end
	return nil, nil, baseYaw
end

function G.IsInsideSkybox(pos)
	if not isvector(pos) then return false end
	local _, _, min, max = G.SkyboxFrame()
	return pos:WithinAABox(min, max)
end

function G.PlayerShipIsMoving()
	if not G.HasSWUUniverseFrame() or not SWU.Controller.GetCurrentShipAcceleration then
		return false
	end
	return math.abs(tonumber(SWU.Controller:GetCurrentShipAcceleration()) or 0)
		>= math.max(0, tonumber(gd.SkyboxMovementThreshold) or 0.5)
end

function G.HasSWUUniverseFrame()
	return gd.TrackShipsInSWUUniverse ~= false and SWU
		and IsValid(SWU.Controller)
		and isfunction(SWU.CalculateWorldPos)
		and SWU.Controller.GetShipPos
		and SWU.Controller.GetInternalShipAngles
end

function G.BindShipToSWUUniverse(ent)
	if not IsValid(ent) or not G.HasSWUUniverseFrame() then return false end
	local controller = SWU.Controller
	local scale = math.max(0.0001, math.abs(tonumber(SWU.config and SWU.config.scale) or 1))
	local shipAngles = controller:GetInternalShipAngles()
	local delta = WorldToLocal(ent:GetPos(), angle_zero, controller:GetPos(), shipAngles)

	ent.mb_galaxyUniversePos = controller:GetShipPos() + delta / scale
	ent.mb_galaxyUniverseAng = ent:GetAngles() - shipAngles
	ent.mb_galaxyUniverseVelocity = vector_origin
	ent.mb_galaxyLastFlightVelocity = nil
	ent.mb_galaxyLongitudinalAcceleration = 0
	return true
end

local function closestPointOnSegment(point, startPos, endPos)
	local segment = endPos - startPos
	local lengthSqr = segment:LengthSqr()
	if lengthSqr <= 0.0001 then return startPos, 0 end
	local fraction = math.Clamp((point - startPos):Dot(segment) / lengthSqr, 0, 1)
	return startPos + segment * fraction, fraction
end

function G.AdvanceShipAroundPlanets(ent, shipAngles, scale, dt)
	local currentPos = ent.mb_galaxyUniversePos
	local velocity = ent.mb_galaxyUniverseVelocity
	if gd.PlanetAvoidanceEnabled == false or not isvector(velocity)
	or velocity:LengthSqr() <= 0 then
		return currentPos + (isvector(velocity) and velocity or vector_origin) * dt
	end

	local ok, currentWorld = pcall(SWU.CalculateWorldPos, SWU, currentPos)
	if not ok or not isvector(currentWorld) then return currentPos + velocity * dt end
	local worldVelocity = Vector(velocity * scale)
	worldVelocity:Rotate(shipAngles)
	local speed = worldVelocity:Length()
	if speed <= 0.001 then return currentPos end

	local planets = G.GetPlanetObstacles()
	local shipRadius = math.max(0, tonumber(ent.mb_galaxyVisualRadius)
		or G.MaximumShipRadius(ent))
	local margin = math.max(0, tonumber(gd.PlanetAvoidanceMargin) or 180)
	local lookAhead = math.max(dt, tonumber(gd.PlanetAvoidanceLookAhead) or 5)
	local futureWorld = currentWorld + worldVelocity * lookAhead
	local threat, threatPos
	local bestRatio = math.huge

	for _, planet in ipairs(planets) do
		local planetPos = G.PlanetWorldPosition(planet)
		local clearance = G.PlanetObstacleRadius(planet) + shipRadius + margin
		if isvector(planetPos) and clearance > 0 then
			local closest = closestPointOnSegment(planetPos, currentWorld, futureWorld)
			local distanceSqr = closest:DistToSqr(planetPos)
			local ratio = distanceSqr / (clearance * clearance)
			if ratio < 1 and ratio < bestRatio then
				bestRatio = ratio
				threat = planet
				threatPos = planetPos
			end
		end
	end

	if IsValid(threat) then
		local radial = currentWorld - threatPos
		if radial:LengthSqr() <= 1 then radial = worldVelocity * -1 end
		radial:Normalize()
		local tangent = Vector(-radial.y, radial.x, 0)
		if tangent:LengthSqr() <= 0.001 then
			tangent = worldVelocity:Cross(Vector(0, 0, 1))
		end
		tangent:Normalize()
		if tangent:Dot(worldVelocity) < 0 then tangent:Mul(-1) end
		local desired = tangent * 0.9 + radial * 0.42
		desired:Normalize()
		desired:Mul(speed)
		local turn = math.Clamp(dt * math.max(0.1,
			tonumber(gd.PlanetAvoidanceTurnRate) or 2.5), 0, 1)
		worldVelocity = LerpVector(turn, worldVelocity, desired)
		worldVelocity:Normalize()
		worldVelocity:Mul(speed)
		local universeVelocity = WorldToLocal(worldVelocity, angle_zero,
			vector_origin, shipAngles) / scale
		ent.mb_galaxyUniverseVelocity = universeVelocity
		velocity = universeVelocity
	end

	local nextPos = currentPos + velocity * dt
	local nextOK, nextWorld = pcall(SWU.CalculateWorldPos, SWU, nextPos)
	if not nextOK or not isvector(nextWorld) then return nextPos end
	for _, planet in ipairs(planets) do
		local planetPos = G.PlanetWorldPosition(planet)
		local clearance = G.PlanetObstacleRadius(planet) + shipRadius + margin
		if isvector(planetPos) and clearance > 0 then
			local closest = closestPointOnSegment(planetPos, currentWorld, nextWorld)
			local crossesClearance = closest:DistToSqr(planetPos) < clearance * clearance
			local movingCloser = nextWorld:DistToSqr(planetPos)
				< currentWorld:DistToSqr(planetPos)
			if crossesClearance and movingCloser then
				return currentPos
			end
		end
	end
	return nextPos
end

function G.ShipFlightProfile(ent)
	if IsValid(ent) and istable(ent.mb_galaxyPilotProfile) then
		return ent.mb_galaxyPilotProfile
	end
	if IsValid(ent) then
		local definition = G.ShipSizeDefinition(ent.GetSizeClass
			and ent:GetSizeClass() or "")
		if istable(definition.flightProfile) then
			return definition.flightProfile
		end
	end
	local profiles = gd.ShipFlightProfiles or {}
	local role = IsValid(ent) and ent:GetRole() or "default"
	return profiles[role] or profiles.default or {
		accelerate = 14, brake = 24, jerk = 72, steering = 58,
		bank = 9, bankRate = 40, turnThrottle = 0.5,
	}
end

function G.SetShipFlightRoute(ent, waypoints, options)
	if not IsValid(ent) or not istable(waypoints) then return false end
	local route = { points = {}, index = 1, options = options or {} }
	for _, point in ipairs(waypoints) do
		if isvector(point) then route.points[#route.points + 1] = Vector(point) end
	end
	if #route.points == 0 then return false end
	ent.mb_galaxyFlightRoute = route
	ent.mb_galaxyAutonomousPatrol = route.options.autonomous == true
	ent.mb_galaxyRouteCompleteAt = nil
	return true
end

function G.ClearShipFlightRoute(ent)
	if IsValid(ent) then
		ent.mb_galaxyFlightRoute = nil
		ent.mb_galaxyAutonomousPatrol = nil
	end
end

local function autonomousFlightSpeed(ent)
	local speeds = gd.ShipAutonomousSpeeds or {}
	local definition = IsValid(ent) and G.ShipSizeDefinition(
		ent.GetSizeClass and ent:GetSizeClass() or "") or {}
	local range = istable(definition.speed) and definition.speed
		or speeds[IsValid(ent) and ent:GetRole() or "default"]
		or speeds.default or { 26, 40 }
	local minimum = math.max(3, tonumber(range[1]) or 26)
	local maximum = math.max(minimum, tonumber(range[2]) or 40)
	local speed = math.Rand(minimum, maximum)
	local state = IsValid(ent) and string.lower(ent:GetShipState() or "") or ""
	if string.find(state, "derelict", 1, true)
	or string.find(state, "disabled", 1, true)
	or string.find(state, "surrendered", 1, true)
	or string.find(state, "adrift", 1, true) then
		speed = math.max(2.5, speed * 0.16)
	elseif IsValid(ent) and ent:GetCombat() then
		speed = speed * 1.12
	end
	return speed
end

local function autonomousFlightPoint(ent, origin, heading)
	if not IsValid(ent) or not isvector(origin) then return nil end
	local _, _, min, max = G.SkyboxFrame()
	local shipRadius = G.MaximumShipRadius(ent)
	local minimum = math.max(180,
		tonumber(gd.ShipAutonomousRouteMinimum) or 420)
	local maximum = math.max(minimum,
		tonumber(gd.ShipAutonomousRouteMaximum) or 1050)
	local insetX = math.min(shipRadius + 110,
		math.max(32, (max.x - min.x) * 0.44))
	local insetY = math.min(shipRadius + 110,
		math.max(32, (max.y - min.y) * 0.44))
	local insetZ = math.min(shipRadius * 0.35 + 55,
		math.max(24, (max.z - min.z) * 0.42))
	for _ = 1, 14 do
		local yaw = heading + math.Rand(-24, 24)
		local pitch = math.Rand(-7, 7)
		local candidate = origin + Angle(pitch, yaw, 0):Forward()
			* math.Rand(minimum, maximum)
		candidate.z = candidate.z + math.Rand(-110, 110)
		candidate.x = math.Clamp(candidate.x, min.x + insetX, max.x - insetX)
		candidate.y = math.Clamp(candidate.y, min.y + insetY, max.y - insetY)
		candidate.z = math.Clamp(candidate.z, min.z + insetZ, max.z - insetZ)
		if candidate:DistToSqr(origin) >= (minimum * 0.42) ^ 2
		and G.IsInsideSkybox(candidate)
		and G.PlanetClearanceAt(candidate, shipRadius) then
			return candidate
		end
	end
	return nil
end

-- Every visible ship represents a vessel with somewhere to be. If a spawn
-- path leaves a non-blockade contact at zero velocity, give it a safe local
-- patrol instead of allowing it to hover indefinitely.
function G.AssignAutonomousShipMotion(ent, reason)
	if gd.ShipAutonomousMotionEnabled == false or not IsValid(ent)
	or ent:GetClass() ~= "mb_galaxy_ship" then return false end
	if ent.mb_galaxyOrbitalBlockade or ent.mb_galaxyMapSpace
	or ent.mb_galaxyFleetFollowing
	or ent.mb_galaxyCombatIngress or ent.mb_destroyed
	or ent.mb_galaxyPlanetLandedAt then return false end
	local state = string.lower(ent:GetShipState() or "")
	if state == "destroyed" then return false end

	local actualVelocity = ent.mb_galaxyActualWorldVelocity
	if ent.mb_galaxyFlightRoute or ent.mb_galaxyFormationFlight
	or ent:GetFlightVelocity():LengthSqr() > 1
	or isvector(actualVelocity) and actualVelocity:LengthSqr() > 1 then
		return false
	end

	local facingVelocity = isvector(actualVelocity)
		and actualVelocity:LengthSqr() > 0.001 and actualVelocity
		or ent:GetFlightVelocity():LengthSqr() > 0.001 and ent:GetFlightVelocity()
		or ent:GetForward()
	local baseYaw = facingVelocity:Angle().y
	local pointCount = math.max(2, math.floor(
		tonumber(gd.ShipAutonomousRoutePoints) or 3))
	local points = {}
	local origin = ent:GetPos()
	for index = 1, pointCount do
		local heading = baseYaw + index * (300 / pointCount)
			+ (index % 2 == 0 and 18 or -12)
		local point = autonomousFlightPoint(ent, origin, heading)
		if isvector(point) then
			points[#points + 1] = point
			origin = point
		end
	end
	if #points < 2 and G.FindClearSkyboxEntry then
		for index = 1, 4 do
			local point = select(1, G.FindClearSkyboxEntry(
				baseYaw + index * 95, math.Rand(-180, 180),
				math.Rand(-150, 150), ent:GetRole(),
				ent.GetSizeClass and ent:GetSizeClass() or ""))
			if isvector(point) and point:DistToSqr(ent:GetPos()) > 180 ^ 2 then
				points[#points + 1] = point
				if #points >= 2 then break end
			end
		end
	end
	if #points < 2 then return false end

	local speed = autonomousFlightSpeed(ent)
	local shipRadius = G.MaximumShipRadius(ent)
	if not G.SetShipFlightRoute(ent, points, {
		speed = speed,
		arrivalRadius = math.Clamp(shipRadius * 0.55, 20, 150),
		lookAhead = math.max(220, tonumber(gd.ShipRouteLookAhead) or 320),
		loop = true,
		autonomous = true,
	}) then return false end
	local firstDelta = points[1] - ent:GetPos()
	if firstDelta:LengthSqr() > 1 then
		ent:SetFlightVelocity(firstDelta:GetNormalized() * speed)
	end
	ent.mb_galaxyAutonomousReason = G.CleanText(reason or "local traffic route", 96)
	ent.mb_galaxyHoldForPlayerDeparture = false
	ent.mb_galaxyPlayerDeparting = true
	return true
end

function G.EnsureAutonomousShipMotion(ent, now)
	if not IsValid(ent) then return false end
	now = tonumber(now) or CurTime()
	if now < (ent.mb_galaxyNextAutonomousCheckAt or 0) then return false end
	ent.mb_galaxyNextAutonomousCheckAt = now + 1
	if not ent.mb_galaxyAutonomousReadyAt then
		ent.mb_galaxyAutonomousReadyAt = now
			+ math.max(0.2, tonumber(gd.ShipAutonomousIdleDelay) or 1.5)
		return false
	end
	if now < ent.mb_galaxyAutonomousReadyAt then return false end
	return G.AssignAutonomousShipMotion(ent, "automatic non-blockade movement")
end

function G.SetShipFormationFollower(ent, leader, offset, options)
	if not IsValid(ent) or not IsValid(leader) then return false end
	ent.mb_galaxyFormationFlight = {
		leader = leader,
		offset = isvector(offset) and Vector(offset) or vector_origin,
		options = options or {},
	}
	return true
end

-- Routes use a small number of visible waypoints.  They prevent background
-- traffic from aiming straight at a destination and give the flight smoother
-- curves without expensive pathfinding in the skybox.
function G.UpdateShipFlightRoute(ent)
	if not IsValid(ent) or ent.mb_galaxyMapSpace or ent.mb_galaxyCombatIngress then return end
	if ent.mb_navalOwnedFleetID and MilBase.Naval
	and MilBase.Naval.UpdateOwnedFleetFormationMotion
	and MilBase.Naval.UpdateOwnedFleetFormationMotion(ent) then return end
	local formation = ent.mb_galaxyFormationFlight
	if formation then
		local leader = formation.leader
		if not IsValid(leader) then
			ent.mb_galaxyFormationFlight = nil
		else
			local offset = formation.offset or vector_origin
			local target = leader:GetPos() + leader:GetForward() * offset.x
				+ leader:GetRight() * offset.y + leader:GetUp() * offset.z
			local delta = target - ent:GetPos()
			local distance = delta:Length()
			local options = formation.options or {}
			local leaderVelocity = isvector(leader.mb_galaxyActualWorldVelocity)
				and leader.mb_galaxyActualWorldVelocity or leader:GetFlightVelocity()
			local baseSpeed = math.max(4, tonumber(options.speed)
				or leaderVelocity:Length())
			local positionGain = math.max(0.02, tonumber(options.positionGain)
				or tonumber(gd.ShipFormationPositionGain) or 0.22)
			local maximumCorrection = baseSpeed * math.max(0.1,
				tonumber(options.maximumCatchup)
					or tonumber(gd.ShipFormationMaximumCatchup) or 0.55)
			local correction = delta * positionGain
			if correction:Length() > maximumCorrection then
				correction:Normalize()
				correction:Mul(maximumCorrection)
			end
			if distance <= math.max(8, tonumber(options.deadband) or 18) then
				correction = vector_origin
			end
			local desired = leaderVelocity + correction
			if ent:GetFlightVelocity():DistToSqr(desired) > 0.25 then
				ent:SetFlightVelocity(desired)
			end
			return
		end
	end
	local route = ent.mb_galaxyFlightRoute
	if not route or not istable(route.points) then return end
	local point = route.points[route.index or 1]
	if not isvector(point) then
		ent.mb_galaxyFlightRoute = nil
		return
	end
	local delta = point - ent:GetPos()
	local distance = delta:Length()
	local options = route.options or {}
	local arrivalRadius = math.max(35, tonumber(options.arrivalRadius) or 110)
	local nextPoint = route.points[(route.index or 1) + 1]
	local lookAhead = math.max(arrivalRadius * 1.4,
		tonumber(options.lookAhead)
			or tonumber(gd.ShipRouteLookAhead) or 320)
	local switchRadius = arrivalRadius
	if isvector(nextPoint) then
		switchRadius = math.max(arrivalRadius,
			math.min(lookAhead * 0.55, arrivalRadius * 1.75))
	end
	local requestedVelocity = ent:GetFlightVelocity()
	local passedWaypoint = isvector(nextPoint)
		and requestedVelocity:LengthSqr() > 0.001
		and delta:Dot(requestedVelocity) <= 0
	if distance <= switchRadius or passedWaypoint then
		route.index = (route.index or 1) + 1
		if route.index > #route.points then
			if options.loop == true then
				route.index = 1
			else
				ent.mb_galaxyFlightRoute = nil
				ent.mb_galaxyRouteCompleteAt = CurTime()
				if options.finalStop then ent:SetFlightVelocity(vector_origin) end
			end
		end
		return
	end
	local navigationPoint = point
	if isvector(nextPoint) then
		if distance < lookAhead then
			local blend = math.Clamp(1 - distance / lookAhead, 0, 0.82)
			navigationPoint = LerpVector(blend, point, nextPoint)
		end
	end
	local speed = math.max(4, tonumber(options.speed) or ent:GetFlightVelocity():Length())
	if options.finalStop and route.index >= #route.points then
		local profile = G.ShipFlightProfile(ent)
		local brake = math.max(1, tonumber(profile.brake) or 26)
		local remaining = math.max(0, distance - arrivalRadius)
		speed = math.min(speed, math.sqrt(2 * brake * remaining))
	end
	local navigationDelta = navigationPoint - ent:GetPos()
	if navigationDelta:LengthSqr() <= 0.001 then navigationDelta = delta end
	local desired = navigationDelta:GetNormalized() * speed
	if ent:GetFlightVelocity():DistToSqr(desired) > 1 then
		ent:SetFlightVelocity(desired)
	end
end

-- Keep a model's nose pointed down its true travel path.  Universe movement
-- can curve around a planet, so this deliberately turns at a capped rate
-- rather than snapping to the new velocity in a single frame.
function G.ShipTravelFacing(role, worldVelocity)
	if not isvector(worldVelocity) or worldVelocity:LengthSqr() <= 0.001 then
		return nil
	end
	local facing = worldVelocity:Angle()
	local corrections = gd.ShipModelFacingYaw or {}
	local correction = tonumber(corrections[role]) or tonumber(corrections.default) or 0
	facing.y = facing.y + correction
	facing.r = 0
	return facing
end

local function shipTravelDirection(ent)
	if not IsValid(ent) then return Vector(1, 0, 0) end
	local facing = ent:GetAngles()
	local corrections = gd.ShipModelFacingYaw or {}
	local correction = tonumber(corrections[ent:GetRole()])
		or tonumber(corrections.default) or 0
	facing.y = facing.y - correction
	return facing:Forward()
end

-- Convert route requests into inertial movement. Thrust changes are jerk
-- limited, course changes have a real angular rate, and ships reduce throttle
-- during a hard turn instead of sliding sideways at full cruise speed.
function G.SmoothShipWorldVelocity(ent, currentVelocity, desiredVelocity, dt)
	currentVelocity = isvector(currentVelocity) and Vector(currentVelocity)
		or vector_origin
	desiredVelocity = isvector(desiredVelocity) and Vector(desiredVelocity)
		or vector_origin
	dt = math.Clamp(tonumber(dt) or 0, 0, 0.2)
	if gd.ShipFlightSmoothingEnabled == false or dt <= 0 then
		if IsValid(ent) then ent.mb_galaxyLongitudinalAcceleration = 0 end
		return desiredVelocity
	end

	local profile = G.ShipFlightProfile(ent)
	local motionScale = IsValid(ent) and ent.mb_galaxyMapSpace
		and math.max(1, tonumber(gd.ShipMapSpaceMotionScale) or 8) or 1
	local accelerate = math.max(0.1,
		tonumber(profile.accelerate) or 14) * motionScale
	local brake = math.max(0.1,
		tonumber(profile.brake) or 24) * motionScale
	local jerk = math.max(accelerate,
		math.max(0.1, tonumber(profile.jerk) or 72) * motionScale)
	local steering = math.max(2, tonumber(profile.steering)
		or tonumber(gd.ShipTurnRate) or 58)

	local currentSpeed = currentVelocity:Length()
	local requestedSpeed = desiredVelocity:Length()
	local currentDirection = currentSpeed > 0.001
		and currentVelocity:GetNormalized() or shipTravelDirection(ent)
	local desiredDirection = requestedSpeed > 0.001
		and desiredVelocity:GetNormalized() or currentDirection
	local dot = math.Clamp(currentDirection:Dot(desiredDirection), -1, 1)

	local targetSpeed = requestedSpeed
	if requestedSpeed > 0.001 and gd.ShipTurnThrottleEnabled ~= false then
		local alignment = math.Clamp((dot + 1) * 0.5, 0, 1)
		local minimumThrottle = math.Clamp(
			tonumber(profile.turnThrottle) or 0.5, 0.1, 1)
		local throttle = minimumThrottle
			+ (1 - minimumThrottle) * alignment * alignment
		targetSpeed = requestedSpeed * throttle
	end

	local speedDifference = targetSpeed - currentSpeed
	local targetAcceleration = 0
	if speedDifference > 0.02 then
		targetAcceleration = accelerate
	elseif speedDifference < -0.02 then
		targetAcceleration = -brake
	end
	local acceleration = IsValid(ent)
		and tonumber(ent.mb_galaxyLongitudinalAcceleration) or 0
	acceleration = math.Approach(acceleration, targetAcceleration, jerk * dt)
	local nextSpeed = math.max(0, currentSpeed + acceleration * dt)
	if speedDifference > 0 and nextSpeed > targetSpeed
	or speedDifference < 0 and nextSpeed < targetSpeed then
		nextSpeed = targetSpeed
		acceleration = 0
	elseif math.abs(speedDifference) <= 0.02 then
		nextSpeed = targetSpeed
	end
	if IsValid(ent) then ent.mb_galaxyLongitudinalAcceleration = acceleration end
	if nextSpeed <= 0.001 then return vector_origin end

	if requestedSpeed > 0.001 then
		local currentAngle = currentDirection:Angle()
		local desiredAngle = desiredDirection:Angle()
		currentAngle.p = math.ApproachAngle(currentAngle.p, desiredAngle.p,
			steering * 0.68 * dt)
		currentAngle.y = math.ApproachAngle(currentAngle.y, desiredAngle.y,
			steering * dt)
		currentAngle.r = 0
		currentDirection = currentAngle:Forward()
		currentDirection:Normalize()
	end
	return currentDirection * nextSpeed
end

function G.UpdateShipTravelFacing(ent, worldVelocity, shipAngles, dt, snap)
	if not IsValid(ent) then return end
	local desired = G.ShipTravelFacing(ent:GetRole(), worldVelocity)
	if not isangle(desired) then return end
	shipAngles = isangle(shipAngles) and shipAngles or angle_zero
	local current = isangle(ent.mb_galaxyUniverseAng)
		and ent.mb_galaxyUniverseAng + shipAngles or ent:GetAngles()
	if snap then
		current = desired
	else
		local profile = G.ShipFlightProfile(ent)
		local turnRate = math.max(10, tonumber(profile.steering)
			or tonumber(gd.ShipTurnRate) or 58) * 1.18
		local turn = turnRate * math.max(0, tonumber(dt) or 0)
		current.p = math.ApproachAngle(current.p, desired.p, turn * 0.72)
		current.y = math.ApproachAngle(current.y, desired.y, turn)
		local rollTarget = 0
		if gd.ShipBankingEnabled ~= false then
			local targetVelocity = ent.mb_galaxyDesiredWorldVelocity
			local targetFacing = G.ShipTravelFacing(ent:GetRole(), targetVelocity)
			if isangle(targetFacing) then
				local yawDifference = math.AngleDifference(targetFacing.y, current.y)
				rollTarget = math.Clamp(-yawDifference * 0.22,
					-math.max(0, tonumber(profile.bank) or 10),
					math.max(0, tonumber(profile.bank) or 10))
			end
		end
		-- Remote skybox pilots can add manual roll on top of assisted banking, or
		-- take direct roll control in advanced mode. Autonomous ships never set
		-- these fields and retain the normal travel-facing behaviour above.
		local pilotRoll = tonumber(ent.mb_galaxyPilotRollTarget)
		if pilotRoll then
			local manualLimit = math.max(0, tonumber(profile.manualBank)
				or math.abs(pilotRoll) or tonumber(profile.bank) or 10)
			if ent.mb_galaxyPilotManualMode then
				rollTarget = math.Clamp(pilotRoll, -manualLimit, manualLimit)
			else
				rollTarget = math.Clamp(rollTarget + pilotRoll, -manualLimit, manualLimit)
			end
		end
		current.r = math.ApproachAngle(current.r, rollTarget,
			math.max(10, tonumber(profile.bankRate) or 54) * math.max(0, tonumber(dt) or 0))
	end
	ent.mb_galaxyUniverseAng = current - shipAngles
	if not G.HasSWUUniverseFrame() or ent.mb_galaxyMapSpace
	or ent.mb_galaxyFleetFollowing then
		ent:SetAngles(current)
	end
end

function G.UpdateShipSWUTransform(ent, velocity, dt)
	if not IsValid(ent) or ent.mb_galaxyMapSpace or not G.HasSWUUniverseFrame() then return false end
	-- Owned support ships manoeuvre against formation targets expressed in the
	-- current skybox frame. Rebinding them here every think reset their universe
	-- velocity before it could advance, making re-order commands look frozen.
	-- Returning false routes them through UpdateShipLocalTransform instead:
	-- they visibly cross the skybox while remaining alongside the player ship.
	if ent.mb_galaxyFleetFollowing then return false end
	if not isvector(ent.mb_galaxyUniversePos) and not G.BindShipToSWUUniverse(ent) then
		return false
	end

	local controller = SWU.Controller
	local shipAngles = controller:GetInternalShipAngles()
	local scale = math.max(0.0001, math.abs(tonumber(SWU.config and SWU.config.scale) or 1))
	velocity = isvector(velocity) and velocity or vector_origin
	if not isvector(ent.mb_galaxyLastFlightVelocity)
	or ent.mb_galaxyLastFlightVelocity:DistToSqr(velocity) > 0.0001 then
		local universeVelocity = WorldToLocal(velocity, angle_zero, vector_origin, shipAngles)
		ent.mb_galaxyDesiredUniverseVelocity = universeVelocity / scale
		ent.mb_galaxyLastFlightVelocity = Vector(velocity)
	end
	local desiredUniverseVelocity = ent.mb_galaxyDesiredUniverseVelocity or vector_origin
	local desiredWorldVelocity = Vector(desiredUniverseVelocity * scale)
	desiredWorldVelocity:Rotate(shipAngles)
	ent.mb_galaxyDesiredWorldVelocity = desiredWorldVelocity
	local actualUniverseVelocity = ent.mb_galaxyUniverseVelocity or vector_origin
	local actualWorldVelocity = Vector(actualUniverseVelocity * scale)
	actualWorldVelocity:Rotate(shipAngles)
	actualWorldVelocity = G.SmoothShipWorldVelocity(ent, actualWorldVelocity,
		desiredWorldVelocity, dt)
	actualUniverseVelocity = WorldToLocal(actualWorldVelocity, angle_zero,
		vector_origin, shipAngles) / scale
	ent.mb_galaxyUniverseVelocity = actualUniverseVelocity

	if isvector(ent.mb_galaxyUniverseVelocity)
	and ent.mb_galaxyUniverseVelocity:LengthSqr() > 0 then
		ent.mb_galaxyUniversePos = G.AdvanceShipAroundPlanets(ent, shipAngles, scale, dt)
		actualWorldVelocity = Vector(ent.mb_galaxyUniverseVelocity * scale)
		actualWorldVelocity:Rotate(shipAngles)
	end
	ent.mb_galaxyActualWorldVelocity = actualWorldVelocity
	local facingVelocity = actualWorldVelocity:LengthSqr() > 0.001
		and actualWorldVelocity or desiredWorldVelocity
	if facingVelocity:LengthSqr() > 0.001 then
		G.UpdateShipTravelFacing(ent, facingVelocity, shipAngles, dt)
	end
	if ent.mb_galaxyHoldForPlayerDeparture and G.PlayerShipIsMoving() then
		ent.mb_galaxyPlayerDeparting = true
	end

	local ok, worldPos = pcall(SWU.CalculateWorldPos, SWU, ent.mb_galaxyUniversePos)
	if not ok or not isvector(worldPos) then return false end
	if ent.mb_galaxySkyboxManaged and not G.IsInsideSkybox(worldPos) then
		if ent.mb_galaxyPersistentTraffic then
			-- Legacy local persistent actors remain supported for compatibility.
			-- The living-universe system itself uses independent galaxy records and
			-- does not mark their local visual entities as persistent here.
			if G.HandlePersistentShipSkyboxExit
			and G.HandlePersistentShipSkyboxExit(ent, worldPos) then
				return true
			end
			ent:SetPos(worldPos)
			ent:SetAngles((ent.mb_galaxyUniverseAng or angle_zero) + shipAngles)
			return true
		end
		if (not ent.mb_galaxyHoldForPlayerDeparture or ent.mb_galaxyPlayerDeparting)
		and not ent.mb_galaxySkyboxExitQueued then
			ent.mb_galaxySkyboxExitQueued = true
			timer.Simple(0, function()
				if not IsValid(ent) then return end
				if G.OnShipLeftSkybox then G.OnShipLeftSkybox(ent) end
				if IsValid(ent) then ent:Remove() end
			end)
		end
		return true
	end
	ent:SetPos(worldPos)
	ent:SetAngles((ent.mb_galaxyUniverseAng or angle_zero) + shipAngles)
	return true
end

-- Map-space contacts and fallback maps use the same inertia as SWU skybox
-- contacts. This also keeps combat ingress and retreats from using a separate,
-- less convincing instant-velocity movement path.
function G.UpdateShipLocalTransform(ent, velocity, dt)
	if not IsValid(ent) then return false end
	velocity = isvector(velocity) and velocity or vector_origin
	local actualVelocity = isvector(ent.mb_galaxyLocalVelocity)
		and ent.mb_galaxyLocalVelocity or vector_origin
	actualVelocity = G.SmoothShipWorldVelocity(ent, actualVelocity, velocity, dt)
	ent.mb_galaxyLocalVelocity = actualVelocity
	ent.mb_galaxyActualWorldVelocity = actualVelocity
	ent.mb_galaxyDesiredWorldVelocity = velocity
	if actualVelocity:LengthSqr() > 0.001 then
		ent:SetPos(ent:GetPos() + actualVelocity * math.max(0, tonumber(dt) or 0))
	end
	local facingVelocity = actualVelocity:LengthSqr() > 0.001
		and actualVelocity or velocity
	if facingVelocity:LengthSqr() > 0.001 then
		G.UpdateShipTravelFacing(ent, facingVelocity, angle_zero, dt)
	end
	return true
end

function G.ChooseShipName(faction, capital, sizeClass)
	faction = string.lower(string.Trim(tostring(faction or "civilian")))
	sizeClass = cleanShipSizeClass(sizeClass)
	local poolKey = faction
	if capital and faction == "republic" then
		poolKey = "republic_capital"
	elseif capital and faction == "cis" then
		poolKey = "cis_capital"
	elseif sizeClass == "fighter" then
		poolKey = faction .. "_fighter"
	elseif sizeClass == "shuttle" and faction == "civilian" then
		poolKey = "civilian_shuttle"
	end
	local pool = shipNamePools[poolKey] or shipNamePools[faction]
		or shipNamePools.civilian
	return pool[math.random(#pool)]
end

local factionNameConflicts = {
	republic = {
		"cis ", "cis-", "separatist", "confederate", "munificent",
		"droid control",
	},
	cis = {
		"republic", "venator", "open circle", "resolute", "judicial",
	},
}

function G.ShipNameContradictsFaction(name, faction)
	name = string.lower(string.Trim(tostring(name or "")))
	faction = string.lower(string.Trim(tostring(faction or "")))
	if name == "" then return true end
	for _, fragment in ipairs(factionNameConflicts[faction] or {}) do
		if string.find(name, fragment, 1, true) then return true end
	end
	return false
end

function G.RepairShipName(ship, faction)
	if not IsValid(ship) or ship.mb_galaxyAllowCrossFactionName then return false end
	faction = string.lower(string.Trim(tostring(faction
		or ship.mb_galaxyTrueFaction or ship:GetFaction() or "")))
	if not G.ShipNameContradictsFaction(ship:GetShipName(), faction) then return false end
	ship:SetShipName(G.ChooseShipName(faction, ship:GetCapital(),
		ship.GetSizeClass and ship:GetSizeClass() or ""))
	ship.mb_galaxyContactKey = nil
	return true
end

function G.SpawnShip(role, opts)
	if G.IsHyperspaceTransitActive and G.IsHyperspaceTransitActive() then return nil end
	opts = opts or {}
	local _, radius = G.SkyboxFrame()

	local faction = opts.faction or (role == "republic" and "republic"
		or role == "civilian" and "civilian"
		or role == "pirate" and "pirate" or "cis")
	local capital = opts.capital == true or role == "cis_capital"
		or role == "republic_flagship"

	local preferredSizeClass = opts.sizeClass
	if cleanShipSizeClass(preferredSizeClass) == ""
	and tonumber(opts.hull) and tonumber(opts.hull) >= 2400 then
		preferredSizeClass = G.ShipSizeClass(role)
	end
	local requestedModel = string.Trim(tostring(opts.model or ""))
	local variant
	if requestedModel == "" or G.IsBlockedShipModel(requestedModel)
	or not util.IsValidModel(requestedModel) then
		variant = G.ResolveShipVariant(role, preferredSizeClass)
		requestedModel = variant and variant.model or G.ResolveShipModel(role)
	end
	local sizeClass = G.ShipSizeClass(role, requestedModel,
		preferredSizeClass or variant and variant.sizeClass)
	if capital then sizeClass = "capital" end

	local start, direction, yaw = G.FindClearSkyboxEntry(opts.sideYaw,
		opts.lane, opts.height, role, sizeClass)
	if not isvector(start) or not isvector(direction) then return nil end

	local ent = ents.Create("mb_galaxy_ship")
	if not IsValid(ent) then return nil end
	ent:SetModel(requestedModel)
	ent:SetPos(start)
	ent:SetShipName(opts.name or G.ChooseShipName(faction, capital, sizeClass))
	ent:SetFaction(faction)
	ent:SetRole(role)
	ent:SetSizeClass(sizeClass)
	ent.mb_galaxySizeClassLocked = cleanShipSizeClass(opts.sizeClass) ~= ""
	ent:SetAngles(G.ShipTravelFacing(role, direction * -1) or angle_zero)
	ent:SetEncounterID(opts.encounterID or "")
	ent:SetShipState(opts.state or (opts.hold and "holding" or "cruising"))
	ent:SetHostile(opts.hostile == true)
	ent:SetCapital(capital)
	ent.mb_galaxyAllowCrossFactionName = opts.allowCrossFactionName == true
	G.RepairShipName(ent, faction)
	ent:SetInvulnerable(opts.invulnerable == true)
	ent:SetModelSize(tonumber(opts.scale) or (gd.ShipModelScale or {})[role] or 0.1)

	local definition = G.ShipSizeDefinition(sizeClass)
	local baseHull = capital and 12000 or opts.hostile and 2200 or 1800
	local hullMultiplier = math.max(0.05,
		tonumber(definition.hullMultiplier) or 1)
	local hull = math.max(50, math.floor(tonumber(opts.hull)
		or baseHull * hullMultiplier))
	ent:SetMaxHull(hull)
	ent:SetHull(hull)

	if opts.hold then
		ent:SetFlightVelocity(vector_origin)
	else
		local speedRange = istable(definition.speed) and definition.speed or { 22, 42 }
		local minimumSpeed = math.max(3, tonumber(speedRange[1]) or 22)
		local maximumSpeed = math.max(minimumSpeed, tonumber(speedRange[2]) or 42)
		local speed = tonumber(opts.speed) or math.Rand(minimumSpeed, maximumSpeed)
		ent:SetFlightVelocity(direction * -speed)
		ent:SetDieAt(CurTime() + (tonumber(opts.lifetime)
			or math.max(60, radius * 2 / math.max(speed, 1) + 30)))
	end
	if opts.persistentTraffic == true then ent:SetDieAt(0) end

	ent:Spawn()
	ent:Activate()
	G.ClampShipModelScale(ent, role)
	ent.mb_galaxySideYaw = yaw
	ent.mb_galaxySkyboxManaged = true
	ent.mb_galaxyHoldForPlayerDeparture = opts.hold == true
	ent.mb_galaxyPlayerDeparting = false
	ent.mb_galaxyPersistentTraffic = opts.persistentTraffic == true
	ent.mb_galaxySizeClass = sizeClass
	G.BindShipToSWUUniverse(ent)

	if G.Active and opts.encounterID == G.Active.id then
		G.Active.entities = G.Active.entities or {}
		G.Active.entities[#G.Active.entities + 1] = ent
	else
		G.AmbientShips[#G.AmbientShips + 1] = ent
	end
	return ent
end

function G.EmitLaser(startPos, endPos, color, width)
	if not isvector(startPos) or not isvector(endPos) then return end
	net.Start("MilBase_GalaxyLaser")
		net.WriteVector(startPos)
		net.WriteVector(endPos)
		net.WriteColor(color or Color(235, 65, 55))
		net.WriteFloat(tonumber(width) or 3)
	net.Broadcast()
end

-- The player ship has no exterior entity in the skybox, so its batteries use
-- two stable virtual hardpoints near the observer. Keeping every shot in the
-- same compact bank prevents a volley looking as though it came from random
-- positions all around space.
function G.RepublicBatteryOrigins(target, shotCount)
	local center, radius = G.SkyboxFrame()
	local targetPos = IsValid(target) and target:WorldSpaceCenter()
		or isvector(target) and target or center + Vector(1, 0, 0)
	local aim = targetPos - center
	if aim:LengthSqr() <= 1 then aim = Vector(1, 0, 0) end
	aim:Normalize()
	local up = Vector(0, 0, 1)
	local right = aim:Cross(up)
	if right:LengthSqr() <= 0.001 then right = Vector(0, 1, 0) end
	right:Normalize()
	local anchor = center
		- aim * radius * math.Clamp(tonumber(gd.SkyboxVolleyBatteryDistance) or 0.2,
			0.04, 0.42)
		- up * radius * math.Clamp(tonumber(gd.SkyboxVolleyBatteryDrop) or 0.08,
			-0.2, 0.2)
	local separation = radius * math.Clamp(
		tonumber(gd.SkyboxVolleyBatterySeparation) or 0.025, 0.005, 0.08)
	local origins = {}
	for index = 1, math.max(1, math.floor(tonumber(shotCount) or 1)) do
		local bank = index % 2 == 1 and -1 or 1
		local row = math.floor((index - 1) / 2)
		origins[index] = anchor + right * separation * bank
			+ up * separation * row * 0.22 + aim * separation * row * 0.16
	end
	return origins
end

function G.EmitHyperspaceBurst(pos, direction, color, arriving)
	if gd.HyperspaceTransitEffectsEnabled == false
	or not isvector(pos) or not isvector(direction)
	or direction:LengthSqr() <= 0 then return end
	net.Start("MilBase_GalaxyHyperspace")
		net.WriteVector(pos)
		net.WriteVector(direction:GetNormalized())
		net.WriteColor(color or Color(80, 155, 255))
		net.WriteBool(arriving == true)
	net.Broadcast()
end

function G.EmitImpact(pos)
	if not isvector(pos) then return end
	local fx = EffectData()
	fx:SetOrigin(pos)
	fx:SetScale(0.65)
	util.Effect("Explosion", fx, true, true)
	util.Effect("Sparks", fx, true, true)
end

function G.ShipFire(ship, target, damage)
	if not IsValid(ship) or not IsValid(target) then return end
	local startPos = ship:WorldSpaceCenter()
	local endPos = target:WorldSpaceCenter() + VectorRand() * 12
	local faction = ship.mb_galaxyTrueFaction or ship:GetFaction()
	local color = faction == "republic" and Color(70, 145, 255)
		or faction == "pirate" and Color(235, 170, 55)
		or Color(235, 65, 55)
	G.EmitLaser(startPos, endPos, color, ship:GetCapital() and 7 or 3)

	if damage > 0 and target:GetClass() == "mb_galaxy_ship" then
		local info = DamageInfo()
		info:SetDamage(damage)
		info:SetAttacker(ship)
		info:SetInflictor(ship)
		info:SetDamagePosition(endPos)
		info:SetDamageType(DMG_ENERGYBEAM)
		if ship.mb_galaxyRaidSupport then
			target.mb_galaxyFleetVolleyDamage = true
		end
		target:TakeDamageInfo(info)
		if IsValid(target) and ship.mb_galaxyRaidSupport then
			target.mb_galaxyFleetVolleyDamage = nil
		end
	end
end

function G.OnShipRemoved(ship)
	for i = #G.AmbientShips, 1, -1 do
		if G.AmbientShips[i] == ship or not IsValid(G.AmbientShips[i]) then
			table.remove(G.AmbientShips, i)
		end
	end
end

function G.PersistentUniverseShipCount()
	local count = 0
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if IsValid(ship) and ship.mb_galaxyPersistentTraffic then count = count + 1 end
	end
	return count
end

function G.OnShipLeftSkybox(ship)
	local active = G.Active
	if not active or not IsValid(ship) or ship:GetEncounterID() ~= active.id then return end
	if active.kind == "cis_raid" and ship.mb_galaxyRaidCapital then
		local remaining = G.RaidCapitals(active, ship)
		if #remaining == 0 then
			G.ResolveRaid("fled",
				"The Republic ship accelerated clear of the CIS assault and left the hostile force behind.")
		else
			announce(ship:GetShipName() .. " has fallen behind the attack group. "
				.. #remaining .. " Munificent" .. (#remaining == 1 and " remains." or "s remain."),
				Color(235, 175, 70))
			G.BroadcastState()
		end
	elseif active.contactShip == ship or active.civilianShip == ship then
		G.ResolveEncounter("neutral",
			"The Republic ship moved on and the contact disappeared beyond the edge of local space.")
	end
end

function G.OnShipDestroyed(ship, attacker)
	local active = G.Active
	if not active or ship:GetEncounterID() ~= active.id then return end

	if active.kind == "cis_raid" and ship.mb_galaxyRaidCapital then
		active.capitalsDestroyed = (active.capitalsDestroyed or 0) + 1
		local remaining = G.RaidCapitals(active, ship)
		if #remaining == 0 then
			G.ResolveRaid("republic",
				"The final Munificent in the CIS attack group was destroyed.", attacker)
		else
			announce(ship:GetShipName() .. " destroyed. " .. #remaining
				.. " hostile Munificent" .. (#remaining == 1 and " remains." or "s remain."),
				Color(95, 220, 135))
			G.BroadcastState()
		end
		return
	end
	if active.kind == "cis" and ship:GetHostile() then
		G.ResolveEncounter("success", "Republic pilots destroyed the attacking CIS vessel.")
		return
	end

	if active.kind == "distress" and ship:GetHostile() then
		timer.Simple(0, function()
			if G.Active ~= active then return end
			local hostiles = 0
			for _, ent in ipairs(active.entities or {}) do
				if IsValid(ent) and ent:GetClass() == "mb_galaxy_ship"
				and ent:GetHostile() and ent:GetHull() > 0 then
					hostiles = hostiles + 1
				end
			end
			if hostiles == 0 then
				G.ResolveEncounter("success", "The attackers were destroyed and the civilian vessel is safe.")
			end
		end)
	elseif active.kind == "distress" and ship == active.civilianShip then
		G.ResolveEncounter("failure", "The civilian vessel was lost before it could escape.")
	end
end

function G.DamageCapital(amount, attacker, reason, requestedTarget)
	local active = G.Active
	local capital = IsValid(requestedTarget) and requestedTarget
		or G.PrimaryRaidCapital(active)
	if not active or active.kind ~= "cis_raid" or not IsValid(capital) then
		return false, "No targetable CIS Munificent is present."
	end
	if active.phase ~= "arrival" and active.phase ~= "breach"
	and active.phase ~= "boarding" then
		return false, "The capital ship is not yet in weapons range."
	end

	local damage = DamageInfo()
	damage:SetDamage(math.max(1, tonumber(amount) or 1))
	damage:SetAttacker(IsValid(attacker) and attacker or game.GetWorld())
	damage:SetInflictor(IsValid(attacker) and attacker or game.GetWorld())
	damage:SetDamagePosition(capital:WorldSpaceCenter())
	damage:SetDamageType(DMG_ENERGYBEAM)
	capital:TakeDamageInfo(damage)
	hook.Run("MilBase.GalaxyCapitalDamaged", capital, damage, reason)
	G.BroadcastState()
	return true
end

local function canAuthorizeVolley(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if MilBase.Naval and MilBase.Naval.CanUseConsole
	and not MilBase.Naval.CanUseConsole(ply) then return false end
	if ply.MBHasCert and (ply:MBHasCert("fleet_operator")
		or ply:MBHasCert("high_command")) then return true end
	return MilBase.CommsIsHighCommand and MilBase.CommsIsHighCommand(ply) == true
end

function G.RequestCapitalVolley(ply, encounterID)
	local active = G.Active
	if not active or active.id ~= encounterID or active.kind ~= "cis_raid" then return end
	if not canAuthorizeVolley(ply) then
		MilBase.Notify(ply, "Fleet Fire Control or High Command authorization is required.", "warn")
		return
	end
	local capital = G.PrimaryRaidCapital(active)
	if not IsValid(capital) then
		MilBase.Notify(ply, "No CIS Munificent is targetable yet.", "warn")
		return
	end
	if active.phase ~= "arrival" and active.phase ~= "breach"
	and active.phase ~= "boarding" then
		MilBase.Notify(ply, "The target is not yet within firing range.", "warn")
		return
	end
	if CurTime() < (active.nextVolleyAt or 0) then
		MilBase.Notify(ply, "Capital batteries recharging: "
			.. G.FormatDuration(active.nextVolleyAt - CurTime()), "warn")
		return
	end

	active.nextVolleyAt = CurTime() + math.max(10, tonumber(gd.CapitalVolleyCooldown) or 45)
	local origins = G.RepublicBatteryOrigins(capital, 4)
	for i = 1, 4 do
		timer.Simple((i - 1) * math.max(0.12,
			tonumber(gd.SkyboxVolleyShotInterval) or 0.3), function()
			if G.Active ~= active or not IsValid(capital) then return end
			local startPos = origins[i]
			local endPos = capital:WorldSpaceCenter() + VectorRand() * 35
			G.EmitLaser(startPos, endPos, Color(75, 150, 255), 8)
			if i == 4 then
				G.DamageCapital(tonumber(gd.CapitalVolleyDamage) or 2600, ply,
					"Republic capital-battery volley", capital)
			end
		end)
	end
	G.AnnounceNavy(ply:MBName()
		.. " authorizes a coordinated volley on " .. capital:GetShipName() .. ".",
		Color(80, 155, 240), "[GALAXY] ")
	G.Audit(ply, "authorized capital-ship volley", active.id)
	G.BroadcastState()
end

function G.SpawnAmbientFlight()
	G.ScheduleNextAmbient()
	if not G.Runtime.enabled or not G.Runtime.encounters or G.Active then return end

	local danger = G.State.currentRisk or 0.4
	local roll = math.Rand(0, 1)
	local role
	if roll < danger * 0.35 then
		role = "cis_scout"
	elseif roll < danger * 0.35 + 0.18 then
		role = "pirate"
	elseif roll < danger * 0.35 + 0.52 then
		role = "civilian"
	else
		role = "republic"
	end

	local count = math.random(1, (role == "cis_scout" or role == "republic") and 3 or 2)
	local sideYaw = math.Rand(0, 360)
	local variants = {}
	local laneStep = 72
	for i = 1, count do
		variants[i] = G.ResolveShipVariant(role)
		local sizeClass = variants[i] and variants[i].sizeClass
			or G.ShipSizeClass(role)
		laneStep = math.max(laneStep, G.ShipFormationSpacing(sizeClass) * 1.15)
	end
	for i = 1, count do
		local variant = variants[i]
		G.SpawnShip(role, {
			sideYaw = sideYaw,
			lane = (i - (count + 1) / 2) * laneStep,
			model = variant and variant.model or nil,
			sizeClass = variant and variant.sizeClass or nil,
			faction = role == "cis_scout" and "cis" or role,
			lifetime = math.Rand(75, 130),
			invulnerable = true,
		})
	end
end

local function announce(text, color)
	G.AnnounceNavy(text, color or Color(100, 190, 245), "[GALAXY] ")
end

local function eventID(kind)
	return string.format("%s_%d_%04d", kind, nowUnix(), math.random(1, 9999))
end

local function rememberEncounter(kind)
	G.RecentEncounters[#G.RecentEncounters + 1] = kind
	while #G.RecentEncounters > (gd.RecentEncounterMemory or 4) do
		table.remove(G.RecentEncounters, 1)
	end
end

local function recentlyUsed(kind)
	local count = 0
	for _, previous in ipairs(G.RecentEncounters) do
		if previous == kind then count = count + 1 end
	end
	return count
end

function G.CanStartEncounter(forced)
	if not G.State.ready or G.Active then return false, "Another Galaxy event is active." end
	if not forced and (not G.Runtime.enabled or not G.Runtime.encounters) then
		return false, "Galaxy encounters are disabled."
	end
	if not forced and G.ActivePlayerCount() < math.max(0,
		tonumber(G.Runtime.minPlayersEncounter) or 2) then
		return false, "Not enough active players for an encounter."
	end
	return true
end

function G.PickEncounterKind()
	local danger = G.State.currentRisk or 0.4
	local weighted = {}
	local total = 0
	for kind, range in pairs(gd.EncounterWeights or {}) do
		-- Civilian, pirate and routine Republic ships are physical traffic that
		-- waits to be hailed. Only a hostile CIS encounter may interrupt the
		-- crew through the older encounter director; Republic assistance calls
		-- are generated from genuinely damaged or engaged Republic ships.
		if kind == "cis" then
			local cisBlocked = not G.Runtime.attacks
				or G.ActivePlayerCount() < math.max(1,
					tonumber(G.Runtime.minPlayersAttack) or 6)
			local weight = Lerp(danger, tonumber(range.safe) or 0,
				tonumber(range.hostile) or 0)
			weight = weight / (1 + recentlyUsed(kind) * 1.7)
			if weight > 0 and not cisBlocked then
				total = total + weight
				weighted[#weighted + 1] = { kind = kind, ceiling = total }
			end
		end
	end

	if total <= 0 then return nil end
	local roll = math.Rand(0, total)
	for _, entry in ipairs(weighted) do
		if roll <= entry.ceiling then return entry.kind end
	end
	return weighted[#weighted].kind
end

local encounterCopy = {
	civilian = {
		title = "CIVILIAN VESSEL ON SENSORS",
		body = "A civilian transport has opened a communications channel. They may have local intelligence, cargo to trade, or an interest in Republic protection.",
		source = "Civilian transport",
		timeout = 90,
	},
	pirate = {
		title = "UNIDENTIFIED ARMED VESSEL",
		body = "The contact identifies itself as an independent Outer Rim crew. Weapons are powered, but they are willing to negotiate.",
		source = "Unknown captain",
		timeout = 90,
	},
	republic = {
		title = "REPUBLIC PATROL CONTACT",
		body = "A Republic patrol offers a secure channel. They can exchange intelligence and may be able to assist with damaged ship systems.",
		source = "Republic patrol command",
		timeout = 90,
	},
	distress = {
		title = "PRIORITY DISTRESS SIGNAL",
		body = "A civilian vessel reports hostile ships closing on its position. The transmission is breaking up and requires an immediate response.",
		source = "Civilian emergency beacon",
		timeout = 75,
	},
	cis = {
		title = "CIS WARSHIP DETECTED",
		body = "A Separatist vessel has identified the Republic transponder and is moving to attack. Battle stations.",
		source = "Republic tactical sensors",
		timeout = 75,
	},
}

function G.StartEncounter(kind, forced, opts)
	opts = opts or {}
	local allowed, reason = G.CanStartEncounter(forced)
	if not allowed then return false, reason end
	if not encounterCopy[kind] then return false, "Unknown encounter type." end
	if not forced and kind ~= "cis" then
		return false, "Ordinary ships remain on local traffic routes until the Republic crew hails them."
	end
	if kind ~= "cis" and gd.RequireCommsTerminal ~= false
	and #ents.FindByClass("mb_galaxy_comms") == 0 then
		return false, "No ship communications terminal is present on the map."
	end
	if kind == "cis" and not forced then
		if not G.Runtime.attacks then return false, "CIS attacks are disabled." end
		if G.ActivePlayerCount() < math.max(1, tonumber(G.Runtime.minPlayersAttack) or 6) then
			return false, "Not enough active players for a CIS attack."
		end
	end

	local copy = encounterCopy[kind]
	local active = {
		id = eventID(kind),
		kind = kind,
		title = copy.title,
		body = copy.body,
		source = copy.source,
		phase = "contact",
		startedAt = CurTime(),
		startedUnix = nowUnix(),
		endsAt = CurTime() + copy.timeout,
		choices = G.CopyChoices(kind),
		entities = {},
		sideYaw = tonumber(opts.sideYaw) or math.Rand(0, 360),
		forced = forced == true,
	}
	G.Active = active
	G.State.lastEncounter = nowUnix()
	rememberEncounter(kind)

	if kind == "civilian" or kind == "pirate" or kind == "republic" then
		active.contactShip = G.SpawnShip(kind, {
			sideYaw = active.sideYaw,
			hold = true,
			encounterID = active.id,
			faction = kind,
			hostile = false,
			invulnerable = kind ~= "pirate",
		})
	elseif kind == "distress" then
		-- A distress call is never radio-only: the crew can look out and see
		-- the damaged transport holding at the reported coordinates before
		-- deciding whether to commit to the rescue.
		active.contactShip = G.SpawnShip("civilian", {
			sideYaw = active.sideYaw,
			hold = true,
			encounterID = active.id,
			faction = "civilian",
			name = "Civilian Distress Transport",
			hull = 2400,
			invulnerable = true,
			state = "broadcasting distress signal",
		})
	elseif kind == "cis" then
		active.choices = {}
		active.phase = "hostile_contact"
		active.contactShip = G.SpawnShip("cis_scout", {
			sideYaw = active.sideYaw,
			hold = true,
			encounterID = active.id,
			faction = "cis",
			hostile = true,
			hull = 3000,
		})
	end
	if not IsValid(active.contactShip) then
		G.Active = nil
		G.ScheduleNextEncounter("planet blocked approach")
		return false, "No planet-safe skybox approach lane is currently available."
	end

	if #active.choices > 0 then
		announce("Incoming ship transmission detected. Report to a ship communications terminal.",
			Color(235, 175, 70))
	else
		announce(active.title .. " — " .. active.body,
			kind == "cis" and Color(230, 75, 65) or G.AllegianceColor(kind))
	end
	G.BroadcastState()
	G.SendEncounter()

	if kind == "cis" then
		timer.Simple(14, function()
			if G.Active ~= active then return end
			local canRaid = G.CanStartRaid(false)
			if canRaid and math.Rand(0, 1) <= (gd.CISContactRaidChance or 0.8) then
				G.StartRaid(false, { fromContact = true, sideYaw = active.sideYaw })
			else
				G.StartCISSkirmish(active)
			end
		end)
	end
	return true, active
end

function G.TryStartRandomEncounter(reason)
	local allowed = G.CanStartEncounter(false)
	if not allowed then
		G.ScheduleNextEncounter(reason)
		return false
	end
	G.ScheduleNextEncounter(reason)
	local kind = G.PickEncounterKind()
	if not kind then return false end
	return G.StartEncounter(kind, false, { reason = reason })
end

local function releaseEncounterShips(active, delay)
	for _, ent in ipairs(active and active.entities or {}) do
		if IsValid(ent) and ent:GetClass() == "mb_galaxy_ship" then
			if ent.mb_destroyed then
				SafeRemoveEntityDelayed(ent, 1.4)
			elseif ent.mb_galaxyMapSpace and G.BeginCISRetreat then
				G.BeginCISRetreat(ent, ent:GetShipName() .. " is leaving local airspace.")
			else
				ent:ClearCombatTarget()
				ent:SetShipState("departing")
				ent.mb_galaxyHoldForPlayerDeparture = false
				ent.mb_galaxyPlayerDeparting = true
				local away = ent:GetPos() - select(1, G.SkyboxFrame())
				away.z = 0
				if away:LengthSqr() < 1 then away = ent:GetForward() * -1 end
				ent:SetFlightVelocity(away:GetNormalized() * math.Rand(45, 70))
				ent:SetDieAt(CurTime() + (delay or 18))
			end
		end
	end
end

function G.ResolveEncounter(outcome, details)
	local active = G.Active
	if not active or active.kind == "cis_raid" then return end
	local previousPhase = active.phase
	local recipient = IsValid(active.respondingPlayer) and active.respondingPlayer
		or G.CommsOperator
	active.outcome = outcome
	active.phase = "resolved"
	active.choices = {}

	local color = outcome == "success" and Color(100, 220, 135)
		or outcome == "failure" and Color(230, 75, 65)
		or Color(230, 175, 70)
	if previousPhase == "contact" and active.kind ~= "cis" then
		if IsValid(recipient) then
			MilBase.Notify(recipient, details or "The contact has ended.",
				outcome == "success" and "ok" or "warn")
		end
	else
		announce(details or "The contact has ended.", color)
	end
	G.RecordHistory(active.kind, outcome, G.State.currentPlanet, details)
	releaseEncounterShips(active)
	G.Active = nil
	G.SendEncounter()
	G.ScheduleNextEncounter("resolved")
	G.BroadcastState()
end

local function setEncounterText(active, title, body, phase, duration)
	active.title = title or active.title
	active.body = body or active.body
	active.phase = phase or active.phase
	active.endsAt = CurTime() + (duration or 60)
	active.choices = {}
	G.SendEncounter()
	G.BroadcastState()
end

local function repairFromRepublic()
	local repaired = 0
	for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
		if node:GetBroken() and node.Fix then
			node:Fix()
			repaired = repaired + 1
			if repaired >= (gd.RepublicRepairNodes or 2) then break end
		end
	end
	hook.Run("MilBase.GalaxyRepublicRepairs", repaired)
	return repaired
end

function G.StartPirateAttack(active, reason)
	if G.Active ~= active then return end
	setEncounterText(active, "PIRATES OPEN FIRE",
		reason or "Negotiations have failed. The pirate vessel is attacking and may attempt to retreat if damaged.",
		"combat", 95)
	active.kind = "pirate"

	if IsValid(active.contactShip) then
		active.contactShip:SetHostile(true)
		active.contactShip:SetInvulnerable(false)
		active.contactShip:SetShipState("attacking")
	end

	if math.random(2) == 1 then
		G.SpawnShip("pirate", {
			sideYaw = active.sideYaw,
			lane = 170,
			hold = true,
			encounterID = active.id,
			faction = "pirate",
			hostile = true,
			hull = 1500,
		})
	end
	announce("Pirate weapons fire detected. Defensive action authorized.", Color(230, 145, 55))
end

function G.StartDistressBattle(active)
	if G.Active ~= active then return end
	active.kind = "distress"
	active.phase = "rescue"
	active.title = "CIVILIAN RESCUE IN PROGRESS"
	active.body = "Protect the civilian vessel until the attackers are destroyed or forced to withdraw."
	active.choices = {}
	active.endsAt = CurTime() + 135

	local attackerFaction = math.Rand(0, 1) < (G.State.currentRisk or 0.4) and "cis" or "pirate"
	active.distressAttacker = attackerFaction
	active.civilianShip = IsValid(active.contactShip) and active.contactShip
		or G.SpawnShip("civilian", {
			sideYaw = active.sideYaw,
			lane = -120,
			hold = true,
			encounterID = active.id,
			faction = "civilian",
			hull = 2400,
		})
	if not IsValid(active.civilianShip) then
		G.ResolveEncounter("neutral",
			"The distress contact cannot safely enter local space around the nearby planet.")
		return
	end
	active.contactShip = active.civilianShip
	active.civilianShip:SetInvulnerable(false)
	active.civilianShip:SetShipState("under attack")

	local hostileCount = G.ActivePlayerCount() >= 8 and 2 or 1
	for i = 1, hostileCount do
		local role = attackerFaction == "cis" and "cis_scout" or "pirate"
		local hostile = G.SpawnShip(role, {
			sideYaw = active.sideYaw,
			lane = 100 + i * 130,
			hold = true,
			encounterID = active.id,
			faction = attackerFaction,
			hostile = true,
			hull = attackerFaction == "cis" and 2300 or 1700,
		})
		if IsValid(hostile) and IsValid(active.civilianShip) then
			hostile:SetCombatTarget(active.civilianShip, hostileCount == 1 and 55 or 42, 4.2)
		end
	end

	announce("Distress coordinates reached. "
		.. (attackerFaction == "cis" and "CIS ships" or "Pirates")
		.. " are attacking the civilian transport.", Color(235, 165, 65))
	G.BroadcastState()
end

function G.HandleEncounterResponse(ply, encounterID, response)
	local active = G.Active
	if not active or active.id ~= encounterID then return end
	if response == "capital_volley" then
		G.RequestCapitalVolley(ply, encounterID)
		return
	end
	if G.CommsOperator ~= ply or not G.CommsSessionValid(ply, G.CommsTerminal) then
		MilBase.Notify(ply,
			"Use the ship communications terminal before answering this transmission.", "warn")
		return
	end
	if active.responded then return end
	if not ply:Alive() then return end

	local validChoice = false
	for _, choice in ipairs(active.choices or {}) do
		if choice.id == response then
			validChoice = true
			break
		end
	end
	if not validChoice then return end

	active.responded = true
	active.responder = ply:MBName()
	active.respondingPlayer = ply
	active.choices = {}
	G.SendEncounter()
	G.Audit(ply, "answered " .. active.kind .. " encounter", response)

	local planet = G.EnsurePlanet(G.State.currentPlanet)
	if active.kind == "civilian" then
		if response == "intel" then
			local hostile = math.Rand(0, 1) < (G.State.currentRisk or 0.4)
			G.State.intelUntil = CurTime() + 900
			G.State.intelText = hostile
				and "Civilian reports indicate CIS or pirate activity on the next major route."
				or "Civilian traffic reports no organised hostile fleet in the immediate area."
			G.ResolveEncounter("success", G.State.intelText)
		elseif response == "trade" then
			G.AddRecommendation(planet.name, 2, -1,
				"Republic personnel conducted fair trade with a civilian vessel.", ply:MBName())
			G.ResolveEncounter("success",
				"Trade completed. The civilian captain has filed a favourable report; management may review the reputation recommendation.")
		elseif response == "persuade" then
			local chance = math.Clamp(0.45 + planet.republicOpinion / 250
				- planet.cisOpinion / 400, 0.15, 0.9)
			if math.Rand(0, 1) <= chance then
				G.AddRecommendation(planet.name, 6, -2,
					"A civilian captain was persuaded to publicly support the Republic.", ply:MBName())
				G.ResolveEncounter("success",
					"The captain is receptive to Republic membership. A reputation recommendation has been sent to management.")
			else
				G.ResolveEncounter("neutral",
					"The captain remains unconvinced but agrees to keep Republic channels open.")
			end
		else
			G.ResolveEncounter("neutral", "The civilian vessel continues on its route.")
		end

	elseif active.kind == "pirate" then
		if response == "negotiate" then
			local success = math.Rand(0, 1) < math.Clamp(0.58 - (G.State.currentRisk or 0.4) * 0.2, 0.25, 0.7)
			if success then
				G.ResolveEncounter("success",
					"The pirates accept the terms and clear the Republic ship to pass.")
			else
				active.responded = false
				G.StartPirateAttack(active, "The pirate captain rejects the terms and orders an attack.")
			end
		elseif response == "surrender" then
			local strength = G.ActivePlayerCount() / math.max(1, tonumber(G.Runtime.minPlayersAttack) or 6)
			if math.Rand(0, 1) < math.Clamp(0.25 + strength * 0.3, 0.25, 0.85) then
				G.ResolveEncounter("success",
					"The pirate crew powers down its weapons and submits to Republic authority.")
			else
				active.responded = false
				G.StartPirateAttack(active, "The pirates refuse to surrender and open fire.")
			end
		elseif response == "attack" then
			active.responded = false
			G.StartPirateAttack(active, "Republic forces initiate combat with the pirate vessel.")
		else
			G.ResolveEncounter("neutral", "Contact is broken without further escalation.")
		end

	elseif active.kind == "republic" then
		if response == "intel" then
			G.State.intelUntil = CurTime() + 1200
			G.State.intelText = (G.State.currentRisk or 0.4) > 0.55
				and "Republic patrols confirm a strong Separatist presence in nearby systems."
				or "Republic patrols report the local route as comparatively secure."
			G.ResolveEncounter("success", G.State.intelText)
		elseif response == "repairs" then
			local repaired = repairFromRepublic()
			G.ResolveEncounter("success", repaired > 0
				and ("Republic engineers restored " .. repaired .. " damaged ship-system console(s).")
				or "The patrol completes a diagnostic pass; no repairable console damage was found.")
		elseif response == "offer_repairs" then
			G.AddRecommendation(planet.name, 3, -1,
				"Republic personnel offered supplies and repairs to an allied patrol.", ply:MBName())
			G.ResolveEncounter("success",
				"The patrol accepts assistance and forwards a commendation to sector command.")
		else
			G.ResolveEncounter("neutral", "The Republic patrol resumes its assigned route.")
		end

	elseif active.kind == "distress" then
		if response == "accept" then
			G.StartDistressBattle(active)
		else
			G.ResolveEncounter("neutral",
				"The distress coordinates are logged for the nearest available Republic patrol.")
		end
	end
end

net.Receive("MilBase_GalaxyRespond", function(_, ply)
	if (ply.mb_nextGalaxyResponse or 0) > CurTime() then return end
	ply.mb_nextGalaxyResponse = CurTime() + 1
	G.HandleEncounterResponse(ply, net.ReadString(), net.ReadString())
end)

net.Receive("MilBase_GalaxyHailRequest", function(_, ply)
	if (ply.mb_nextGalaxyHailRequest or 0) > CurTime() then return end
	ply.mb_nextGalaxyHailRequest = CurTime() + 0.35
	local entityIndex = net.ReadUInt(16)
	if entityIndex == 0 then
		if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return end
		if G.Active and G.Active.choices and #G.Active.choices > 0 then
			G.SendEncounter(ply)
		elseif not G.PendingHail then
			G.SendHailContacts(ply)
		end
		return
	end
	G.HandleHailRequest(ply, Entity(entityIndex))
end)

function G.CanStartRaid(forced)
	if not G.State.ready then return false, "Galaxy Director is not ready." end
	if G.Active and G.Active.kind ~= "cis" then return false, "Another Galaxy event is active." end
	if not forced and (not G.Runtime.enabled or not G.Runtime.attacks) then
		return false, "CIS attacks are disabled."
	end
	if not forced and G.ActivePlayerCount() < math.max(1,
		tonumber(G.Runtime.minPlayersAttack) or 6) then
		return false, "Not enough active players for a CIS attack."
	end
	local remaining = (tonumber(G.Runtime.majorCooldown) or 5400)
		- (nowUnix() - (G.State.lastMajorAttack or 0))
	if not forced and remaining > 0 then
		return false, "Major attack cooldown has " .. G.FormatDuration(remaining) .. " remaining."
	end
	return true
end

function G.StartCISSkirmish(active)
	if G.Active ~= active then return end
	setEncounterText(active, "CIS SKIRMISH",
		"The CIS contact opens fire but lacks the strength for a boarding assault. Hold defensive stations until it withdraws.",
		"skirmish", 75)
	active.nextBombardment = CurTime() + 2
	if IsValid(active.contactShip) then active.contactShip:SetShipState("attacking") end
	announce("CIS weapons fire incoming. Major boarding protocols remain locked by player-count and cooldown safeguards.",
		Color(230, 75, 65))
end

function G.LockHyperspace(locked)
	if not gd.LockHyperspaceDuringRaid or not SWU or not IsValid(SWU.Controller)
	or not SWU.Controller.SetCanJumpIntoHyperspace then return end
	if locked and gd.AllowFleeDuringRaid ~= false then return end
	if locked then
		if G._oldCanHyperspace == nil then
			G._oldCanHyperspace = SWU.Controller:GetCanJumpIntoHyperspace()
		end
		SWU.Controller:SetCanJumpIntoHyperspace(false)
	else
		if G._oldCanHyperspace ~= nil then
			SWU.Controller:SetCanJumpIntoHyperspace(G._oldCanHyperspace)
		end
		G._oldCanHyperspace = nil
	end
end

local function cleanActiveForRaid(oldActive)
	if not oldActive then return {} end
	oldActive.choices = {}
	G.SendEncounter()
	local retained = {}
	for _, ent in ipairs(oldActive.entities or {}) do
		if IsValid(ent) and ent:GetClass() == "mb_galaxy_ship"
		and (ent.mb_galaxyTrueFaction == "cis" or ent:GetFaction() == "cis") then
			ent:Remove()
		elseif IsValid(ent) then
			retained[#retained + 1] = ent
		end
	end
	return retained
end

function G.RaidMunificentCount()
	local minimum = math.max(2,
		math.floor(tonumber(gd.RaidMunificentMinimum) or 2))
	local maximum = math.max(minimum,
		math.floor(tonumber(gd.RaidMunificentMaximum) or 4))
	local playersPerExtra = math.max(1,
		math.floor(tonumber(gd.RaidMunificentPlayersPerExtra) or 8))
	return math.Clamp(minimum
		+ math.floor(math.max(0, G.ActivePlayerCount() - 1) / playersPerExtra),
		minimum, maximum)
end

function G.ResolveRaidMunificentModel()
	local valid = {}
	for _, model in ipairs(gd.RaidMunificentModels or {}) do
		if util.IsValidModel(model) and not G.IsBlockedShipModel(model) then
			valid[#valid + 1] = model
		end
	end
	return #valid > 0 and valid[math.random(#valid)] or nil
end

function G.SetRaidPhase(active, phase, duration)
	if G.Active ~= active then return end
	active.phase = phase
	active.endsAt = CurTime() + math.max(1, tonumber(duration) or 1)
	active.title = G.RaidPhaseNames[phase] or "CIS CAPITAL ASSAULT"
	local capitalCount = #G.RaidCapitals(active)
	if capitalCount == 0 then capitalCount = active.requestedCapitalCount or 2 end
	local zoneCount = active.breachZones and #active.breachZones
		or math.max(2, tonumber(gd.RaidBreachZoneMinimum) or 2)

	if phase == "warning" then
		active.body = "A Separatist attack group of " .. capitalCount
			.. " Munificent-class frigates is converging on the ship. Prepare defensive stations, internal response teams, or an emergency hyperspace escape."
	elseif phase == "arrival" then
		active.body = capitalCount .. " Munificent-class frigates are entering local airspace in attack formation. Capital batteries and nearby Republic ships can destroy them before the boarding action is complete."
	elseif phase == "breach" then
		active.body = "CIS fire is opening " .. zoneCount
			.. " breach fronts across the base. Response teams must divide between the marked boarding areas."
	elseif phase == "boarding" then
		active.body = "Mixed CGI B1 and B2 forces are attacking through "
			.. zoneCount .. " breach fronts. Repel every wave and preserve ship integrity while the Munificent group remains overhead."
	elseif phase == "retreat" then
		active.body = "The Separatist force is breaking contact."
	end

	G.BroadcastState()
end

function G.StartRaid(forced, opts)
	opts = opts or {}
	local allowed, reason = G.CanStartRaid(forced)
	if not allowed then
		if opts.fromContact and G.Active and G.Active.kind == "cis" then
			G.StartCISSkirmish(G.Active)
		end
		return false, reason
	end

	local old = opts.fromContact and G.Active or nil
	local active = {
		id = eventID("cis_raid"),
		kind = "cis_raid",
		title = G.RaidPhaseNames.warning,
		body = "",
		source = "Republic strategic sensors",
		phase = "warning",
		startedAt = CurTime(),
		startedUnix = nowUnix(),
		endsAt = 0,
		choices = {},
		entities = cleanActiveForRaid(old),
		sideYaw = tonumber(opts.sideYaw) or old and old.sideYaw or math.Rand(0, 360),
		integrity = math.max(1, math.floor(tonumber(G.Runtime.baseIntegrity) or 100)),
		maxIntegrity = math.max(1, math.floor(tonumber(G.Runtime.baseIntegrity) or 100)),
		wave = 0,
		maxWaves = math.max(1, math.floor(tonumber(G.Runtime.maxWaves) or 6)),
		kills = 0,
		nextBombardment = 0,
		nextWave = 0,
		nextPressure = 0,
		requestedCapitalCount = G.RaidMunificentCount(),
		capitalsDestroyed = 0,
		vulturesDestroyed = 0,
		capitals = {},
		breachedDoors = {},
		breachZones = {},
		forced = forced == true,
	}
	for _, ent in ipairs(active.entities) do
		if IsValid(ent) then ent:SetEncounterID(active.id) end
	end

	G.Active = active
	if G.PrepareRaidBreachZones then G.PrepareRaidBreachZones(active) end
	G.State.lastMajorAttack = nowUnix()
	G.Runtime.lastMajorAttack = G.State.lastMajorAttack
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_settings (setting_key, setting_value) VALUES (%s, %s)",
		MilBase.SQLStr("lastMajorAttack"),
		MilBase.SQLStr(util.TableToJSON({ value = G.State.lastMajorAttack }))))
	G.LockHyperspace(true)
	G.SetRaidPhase(active, "warning", tonumber(G.Runtime.warningDuration) or 90)
	announce("RED ALERT — major CIS attack inbound at " .. G.State.currentPlanet
		.. ". Prepare all defensive stations.", Color(235, 55, 50))
	G.DiscordPost("CIS attack inbound",
		"**Location:** " .. G.State.currentPlanet
			.. "\n**Threat:** " .. active.requestedCapitalCount
			.. " Munificent-class frigates"
			.. "\n**Projected breach fronts:** " .. math.max(1, #active.breachZones)
			.. "\n**Preparation:** " .. G.FormatDuration(G.Runtime.warningDuration)
			.. "\n**Active personnel:** " .. G.ActivePlayerCount(),
		15158332, discord.MentionOnAttack ~= false)
	G.Audit(nil, forced and "started forced CIS raid" or "started automatic CIS raid",
		G.State.currentPlanet)
	return true, active
end

local function configAnchorPositions(kind)
	local result = {}
	local configured = (gd.MapAnchors or {})[game.GetMap()] or {}
	for _, pos in ipairs(configured[kind] or {}) do
		if isvector(pos) and util.IsInWorld(pos) then result[#result + 1] = pos end
	end
	for _, anchor in ipairs(G.Anchors) do
		if anchor.kind == kind and isvector(anchor.pos) and util.IsInWorld(anchor.pos) then
			result[#result + 1] = anchor.pos
		end
	end
	return result
end

function G.ImpactPositions()
	local result = configAnchorPositions("impact")
	if #result > 0 then return result end

	for _, class in ipairs({ "mb_breach", "mb_shipnode", "mb_terminal", "mb_shippart" }) do
		for _, ent in ipairs(ents.FindByClass(class)) do
			result[#result + 1] = ent:WorldSpaceCenter()
		end
	end
	return result
end

local function automaticNavAnchor()
	if not navmesh or not navmesh.GetAllNavAreas then return nil end
	local areas = navmesh.GetAllNavAreas()
	if not areas or #areas == 0 then return nil end
	local players = G.ActivePlayers()
	local minimum = tonumber(gd.AutoNavAnchorMinDistance) or 700
	local maximum = tonumber(gd.AutoNavAnchorMaxDistance) or 6500
	local candidates = {}

	for _, area in ipairs(areas) do
		local pos = area:GetCenter()
		if util.IsInWorld(pos) then
			local nearest
			for _, ply in ipairs(players) do
				local distance = pos:Distance(ply:GetPos())
				nearest = not nearest and distance or math.min(nearest, distance)
			end
			if not nearest or (nearest >= minimum and nearest <= maximum) then
				candidates[#candidates + 1] = pos
			end
		end
	end
	return #candidates > 0 and candidates[math.random(#candidates)] or nil
end

function G.BoardingPositions()
	local result = configAnchorPositions("boarding")
	for _, spawn in pairs(MilBase.EventEnemySpawns or {}) do
		if spawn.enabled ~= false and spawn.status ~= "destroyed"
		and isvector(spawn.pos) and util.IsInWorld(spawn.pos) then
			result[#result + 1] = spawn.pos
		end
	end
	if #result == 0 then
		for i = 1, 3 do
			local pos = automaticNavAnchor()
			if pos then result[#result + 1] = pos end
		end
	end
	return result
end

local raidZoneNames = { "AUREK", "BESH", "CRESH", "DORN" }

local function raidBreachZoneCount()
	local minimum = math.max(2,
		math.floor(tonumber(gd.RaidBreachZoneMinimum) or 2))
	local maximum = math.max(minimum,
		math.floor(tonumber(gd.RaidBreachZoneMaximum) or 4))
	local playersPerExtra = math.max(1,
		math.floor(tonumber(gd.RaidBreachZonePlayersPerExtra) or 8))
	return math.Clamp(minimum
		+ math.floor(math.max(0, G.ActivePlayerCount() - 1) / playersPerExtra),
		minimum, maximum)
end

local function derivedRaidAnchor(base, index)
	local angle = math.rad((index - 1) * 137.5)
	for _, radius in ipairs({ 360, 520, 720 }) do
		local guess = base + Vector(math.cos(angle) * radius,
			math.sin(angle) * radius, 96)
		local floor = util.TraceHull({
			start = guess,
			endpos = guess - Vector(0, 0, 260),
			mins = Vector(-18, -18, 0),
			maxs = Vector(18, 18, 76),
			mask = MASK_PLAYERSOLID,
		})
		local pos = floor.Hit and floor.HitPos + Vector(0, 0, 4)
			or guess - Vector(0, 0, 88)
		local blocked = util.TraceHull({
			start = pos,
			endpos = pos + Vector(0, 0, 1),
			mins = Vector(-18, -18, 0),
			maxs = Vector(18, 18, 76),
			mask = MASK_PLAYERSOLID,
		})
		if util.IsInWorld(pos) and not blocked.Hit then return pos end
	end
end

local raidDeploymentKinds = {
	boarding_drill = "drill",
	boarding_dropship = "dropship",
}

local function raidDeploymentAnchors()
	local result = {}
	local configured = (gd.MapAnchors or {})[game.GetMap()] or {}
	for kind, deployment in pairs(raidDeploymentKinds) do
		for _, pos in ipairs(configured[kind] or {}) do
			if isvector(pos) and util.IsInWorld(pos) then
				result[#result + 1] = {
					pos = Vector(pos),
					deployment = deployment,
				}
			end
		end
		for _, anchor in ipairs(G.Anchors) do
			if anchor.kind == kind and isvector(anchor.pos)
			and util.IsInWorld(anchor.pos) then
				result[#result + 1] = {
					pos = Vector(anchor.pos),
					deployment = deployment,
					label = tostring(anchor.label or ""),
				}
			end
		end
	end
	for _, spawn in pairs(MilBase.EventEnemySpawns or {}) do
		if spawn.type == "drill" and spawn.enabled ~= false
		and spawn.status ~= "destroyed" and isvector(spawn.pos)
		and util.IsInWorld(spawn.pos) then
			result[#result + 1] = {
				pos = Vector(spawn.pos),
				deployment = "drill",
				label = tostring(spawn.name or ""),
				sourcePod = spawn.ent,
			}
		end
	end
	return result
end

local function raidDeploymentForIndex(index)
	local pattern = istable(gd.RaidDeploymentPattern)
		and gd.RaidDeploymentPattern or { "drill", "dropship" }
	local deployment = tostring(pattern[((index - 1) % math.max(1, #pattern)) + 1]
		or "drill")
	return deployment == "dropship" and "dropship" or "drill"
end

function G.PrepareRaidBreachZones(active)
	if not active or active.kind ~= "cis_raid" then return {} end
	local desired = raidBreachZoneCount()
	local separation = math.max(128,
		tonumber(gd.RaidBreachZoneMinimumSeparation) or 650)
	local candidates = raidDeploymentAnchors()
	local typedCount = #candidates
	local positions = G.BoardingPositions()
	if #positions == 0 then positions = G.ImpactPositions() end
	for _, pos in ipairs(positions) do
		candidates[#candidates + 1] = { pos = Vector(pos) }
	end
	if #candidates == 0 then
		for _, pos in ipairs(G.ImpactPositions()) do
			candidates[#candidates + 1] = { pos = Vector(pos) }
		end
	end
	for index = typedCount, 2, -1 do
		local swap = math.random(index)
		candidates[index], candidates[swap] = candidates[swap], candidates[index]
	end
	for index = #candidates, typedCount + 2, -1 do
		local swap = math.random(index)
		swap = math.max(typedCount + 1, swap)
		candidates[index], candidates[swap] = candidates[swap], candidates[index]
	end

	local selected = {}
	local function canUse(candidate, ignoreSeparation)
		local pos = candidate and candidate.pos
		if not isvector(pos) or not util.IsInWorld(pos) then return false end
		for _, existing in ipairs(selected) do
			local distance = existing.pos:DistToSqr(pos)
			if distance <= 48 * 48
			or not ignoreSeparation and distance < separation * separation then
				return false
			end
		end
		return true
	end
	for _, candidate in ipairs(candidates) do
		if #selected >= desired then break end
		if canUse(candidate, false) then selected[#selected + 1] = candidate end
	end
	for _, candidate in ipairs(candidates) do
		if #selected >= desired then break end
		if canUse(candidate, true) then selected[#selected + 1] = candidate end
	end
	local base = selected[1] and selected[1].pos or automaticNavAnchor()
	if isvector(base) and #selected == 0 then selected[1] = { pos = Vector(base) } end
	local attempts = 0
	while #selected < desired and isvector(base) and attempts < desired * 4 do
		attempts = attempts + 1
		local candidate = automaticNavAnchor()
			or derivedRaidAnchor(base, attempts + 1)
		candidate = isvector(candidate) and { pos = Vector(candidate) } or nil
		if canUse(candidate, #selected + 1 >= desired) then
			selected[#selected + 1] = candidate
		end
	end

	active.breachZones = {}
	for index, candidate in ipairs(selected) do
		active.breachZones[index] = {
			id = "breach_" .. index,
			label = candidate.label ~= "" and candidate.label
				or "BREACH " .. (raidZoneNames[index] or tostring(index)),
			pos = candidate.pos,
			deployment = candidate.deployment or raidDeploymentForIndex(index),
			pod = IsValid(candidate.sourcePod) and candidate.sourcePod or nil,
			drillReady = IsValid(candidate.sourcePod),
		}
	end
	return active.breachZones
end

function G.RaidBoardingPositions(active)
	active = active or G.Active
	if active and active.kind == "cis_raid" then
		if not active.breachZones or #active.breachZones == 0 then
			G.PrepareRaidBreachZones(active)
		end
		local result = {}
		for _, zone in ipairs(active.breachZones or {}) do
			if isvector(zone.pos) and util.IsInWorld(zone.pos) then
				result[#result + 1] = zone.pos
			end
		end
		if #result > 0 then return result end
	end
	return G.BoardingPositions()
end

local breachDoorClasses = {
	"func_door",
	"func_door_rotating",
	"prop_door_rotating",
	"func_movelinear",
}

function G.IsBreachDoor(ent)
	if not IsValid(ent) then return false end
	local class = ent:GetClass()
	for _, allowed in ipairs(breachDoorClasses) do
		if class == allowed then return true end
	end
	return false
end

function G.FindBreachDoors(active, limit)
	local markers = configAnchorPositions("breach_door")
	local explicit = #markers > 0
	if not explicit then markers = G.RaidBoardingPositions(active) end
	if #markers == 0 then return {} end

	local radius = explicit and (tonumber(gd.BreachDoorSearchRadius) or 260)
		or (tonumber(gd.BreachDoorFallbackRadius) or 750)
	local maximum = math.max(64, radius) ^ 2
	local doors = {}
	for _, class in ipairs(breachDoorClasses) do
		for _, door in ipairs(ents.FindByClass(class)) do doors[#doors + 1] = door end
	end
	local result, used = {}, {}
	limit = math.max(1, math.floor(tonumber(limit) or #markers))
	for _, marker in ipairs(markers) do
		if #result >= limit then break end
		local best, bestDistance
		for _, door in ipairs(doors) do
			if not used[door] and IsValid(door) then
				local distance = door:WorldSpaceCenter():DistToSqr(marker)
				if distance <= maximum and (not bestDistance or distance < bestDistance) then
					best = door
					bestDistance = distance
				end
			end
		end
		if IsValid(best) then
			used[best] = true
			result[#result + 1] = best
		end
	end
	return result
end

function G.FindBreachDoor(active)
	return G.FindBreachDoors(active, 1)[1]
end

function G.HoldBreachDoorOpen(door)
	if not G.IsBreachDoor(door) then return end
	door:Fire("Unlock", "", 0)
	door:Fire("Open", "", 0.05)
end

function G.BlowBreachDoor(active, door, index)
	if G.Active ~= active then return false end
	door = IsValid(door) and door or G.FindBreachDoor(active)
	if not IsValid(door) then return false end
	local pos = door:WorldSpaceCenter()
	local capitals = G.RaidCapitals(active)
	local attacker = capitals[((math.max(1, tonumber(index) or 1) - 1)
		% math.max(1, #capitals)) + 1] or game.GetWorld()
	active.breachedDoors = active.breachedDoors or {}
	active.breachedDoors[#active.breachedDoors + 1] = door
	active.breachedDoor = active.breachedDoor or door
	active.nextDoorHoldOpen = CurTime()

	if IsValid(attacker) then
		G.EmitLaser(attacker:WorldSpaceCenter(), pos, Color(235, 55, 45), 10)
	end
	timer.Simple(0.18, function()
		if G.Active ~= active or not IsValid(door) then return end
		local source = IsValid(attacker) and attacker or game.GetWorld()
		G.EmitImpact(pos)
		util.ScreenShake(pos, 12, 90, 1.2, 900)
		util.BlastDamage(source, source, pos, 180,
			math.max(0, tonumber(gd.BreachDoorDamage) or 35))
		G.HoldBreachDoorOpen(door)
		hook.Run("MilBase.GalaxyDoorBreached", active.id, door)
	end)
	return true
end

function G.BlowBreachDoors(active)
	if G.Active ~= active then return 0 end
	local desired = #(active.breachZones or {})
	if desired <= 0 then return 0 end
	local doors = G.FindBreachDoors(active, desired)
	local breached = 0
	for index, door in ipairs(doors) do
		if G.BlowBreachDoor(active, door, index) then breached = breached + 1 end
	end

	-- A map does not need a physical door at every configured front. Any
	-- remaining zones still receive a visible hull strike and become live
	-- boarding positions for pods and NPC waves.
	local capitals = G.RaidCapitals(active)
	for index = breached + 1, desired do
		local zone = active.breachZones and active.breachZones[index]
		local attacker = capitals[((index - 1) % math.max(1, #capitals)) + 1]
		if zone and isvector(zone.pos) and IsValid(attacker) then
			local impactPos = Vector(zone.pos)
			G.EmitLaser(attacker:WorldSpaceCenter(), impactPos, Color(235, 55, 45), 8)
			timer.Simple(0.18 + (index - breached - 1) * 0.12, function()
				if G.Active ~= active then return end
				local source = IsValid(attacker) and attacker or game.GetWorld()
				G.EmitImpact(impactPos)
				util.ScreenShake(impactPos, 8, 75, 0.9, 700)
				util.BlastDamage(source, source, impactPos, 140,
					math.max(0, tonumber(gd.RaidBreachZoneBlastDamage) or 18))
			end)
		end
	end
	return math.max(breached, desired)
end

function G.BombardMainShip(active, heavy)
	if G.Active ~= active then return end
	local impacts = G.ImpactPositions()
	local target = #impacts > 0 and impacts[math.random(#impacts)] or nil
	if not target then return end

	local capitals = active.kind == "cis_raid" and G.RaidCapitals(active) or {}
	local capital
	if active.kind == "cis_raid" then
		capital = #capitals > 0 and capitals[math.random(#capitals)] or nil
	else
		capital = IsValid(active.capital) and active.capital
			or IsValid(active.contactShip) and active.contactShip
	end
	if not IsValid(capital) then return end
	G.EmitLaser(capital:WorldSpaceCenter(), target, Color(235, 55, 45), heavy and 9 or 5)
	timer.Simple(0.18, function()
		if G.Active ~= active then return end
		G.EmitImpact(target)
		if heavy then
			local source = IsValid(capital) and capital or game.GetWorld()
			util.BlastDamage(source, source, target, 150, 18)
		end
	end)
end

function G.BreachMainShip(active)
	local breachedFronts = G.BlowBreachDoors(active)
	local frontCount = math.max(1, #(active.breachZones or {}))
	local brokenBreaches = 0
	for _, breach in RandomPairs(ents.FindByClass("mb_breach")) do
		if not breach:GetBreached() and breach.Break then
			breach:Break()
			brokenBreaches = brokenBreaches + 1
			if brokenBreaches >= math.min(frontCount,
				math.max(1, tonumber(gd.RaidBreachesToDamage) or 4)) then break end
		end
	end

	local nodes = {}
	for _, node in ipairs(ents.FindByClass("mb_shipnode")) do
		if not node:GetBroken() then nodes[#nodes + 1] = node end
	end
	local damagedSystems = math.min(#nodes, math.max(1,
		math.min(frontCount, tonumber(gd.RaidSystemsToDamage) or 2)))
	for _ = 1, damagedSystems do
		local index = math.random(#nodes)
		local node = table.remove(nodes, index)
		if node.Break then
			node:Break(G.PrimaryRaidCapital(active) or game.GetWorld())
		end
	end
	hook.Run("MilBase.GalaxyHangarBreached", active.id)
	return breachedFronts
end

function G.ResolveDroidNPC(npcType)
	local npcList = list.Get("NPC") or {}
	npcType = string.lower(string.Trim(tostring(npcType or "b1")))
	local candidates = {}
	for _, class in ipairs((gd.DroidNPCCandidatesByType or {})[npcType] or {}) do
		candidates[#candidates + 1] = class
	end
	if npcType == "b1" or #candidates == 0 then
		for _, class in ipairs(gd.DroidNPCCandidates or {}) do
			candidates[#candidates + 1] = class
		end
	end
	for _, class in ipairs(candidates) do
		if npcList[class] or scripted_ents.GetStored(class) then
			local data = npcList[class] or {}
			return class, data.Weapons and data.Weapons[1]
		end
	end

	local needles = npcType == "b2"
		and { "b2", "super battle droid", "heavy battle droid" }
		or { "b1", "battle droid", "cis droid" }
	for class, data in pairs(npcList) do
		local haystack = string.lower(class .. " " .. tostring(data.Name or "")
			.. " " .. tostring(data.Category or ""))
		for _, needle in ipairs(needles) do
			if string.find(haystack, needle, 1, true) then
				return class, istable(data.Weapons) and data.Weapons[1] or nil
			end
		end
	end
	if npcType ~= "b1" then return G.ResolveDroidNPC("b1") end
	return "npc_combine_s", gd.DroidWeapon or "weapon_ar2"
end

function G.ResolveDroidWeapon(preferred, fallback)
	preferred = string.Trim(tostring(preferred or ""))
	fallback = string.Trim(tostring(fallback or ""))
	if preferred ~= "" and weapons.GetStored(preferred) then return preferred end
	if fallback ~= "" and weapons.GetStored(fallback) then return fallback end
	local configured = string.Trim(tostring(gd.DroidWeapon or "weapon_ar2"))
	if configured ~= "" and weapons.GetStored(configured) then return configured end
	return "weapon_ar2"
end

function G.ChooseRaidBoardingUnit(active, index, count)
	local eligible = {}
	for _, definition in ipairs(gd.RaidBoardingUnits or {}) do
		if istable(definition) and tostring(definition.id or "") ~= "" then
			eligible[#eligible + 1] = definition
		end
	end
	if #eligible == 0 then
		return {
			id = "b1_rifleman",
			label = "B1 BATTLE DROID",
			npcType = "b1",
			weapon = "arccw_cgi_k_e5",
			health = 1,
			minimumHealth = 120,
		}
	end

	local function byID(id)
		for _, definition in ipairs(eligible) do
			if definition.id == id then return definition end
		end
	end
	if count >= 3 and index == count then
		return byID("b2_heavy") or eligible[#eligible]
	end
	if count >= 4 and index == 2 then
		return byID("b1_support") or eligible[1]
	end

	local total = 0
	for _, definition in ipairs(eligible) do
		local weight = math.max(0, tonumber(definition.weight) or 0)
		if G._boardingWaveVariant == "heavy"
		and definition.npcType == "b2" then weight = weight * 1.8 end
		total = total + weight
	end
	if total <= 0 then return eligible[math.random(#eligible)] end
	local roll = math.Rand(0, total)
	for _, definition in ipairs(eligible) do
		local weight = math.max(0, tonumber(definition.weight) or 0)
		if G._boardingWaveVariant == "heavy"
		and definition.npcType == "b2" then weight = weight * 1.8 end
		roll = roll - weight
		if roll <= 0 then return definition end
	end
	return eligible[#eligible]
end

local function galaxyNPCCount(active)
	local count = 0
	for _, ent in ipairs(active and active.npcs or {}) do
		if IsValid(ent) and ent:Health() > 0 then count = count + 1 end
	end
	return count
end

function G.RaidPlayerEnemyCount(active)
	local count = 0
	if not active or active.kind ~= "cis_raid" then return count end
	for _, ply in ipairs(player.GetAll()) do
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)
		and ply.mb_galaxyRaidEventEnemy == active.id
		and ply:GetNWInt("mb_enemylives", 0) > 0 then
			count = count + 1
		end
	end
	return count
end

local function raidHostileCount(active)
	return galaxyNPCCount(active)
		+ G.RaidPlayerEnemyCount(active)
		+ math.max(0, math.floor(tonumber(active and active.pendingDeployments) or 0))
end

local function scheduleRaidBoardingVictoryCheck(active)
	timer.Simple(0, function()
		if G.Active ~= active or active.phase ~= "boarding" then return end
		active.hostiles = raidHostileCount(active)
		if active.wave >= active.maxWaves and active.hostiles <= 0 then
			G.ResolveRaid("republic", "All CIS boarding waves were destroyed.")
		else
			G.BroadcastState()
		end
	end)
end

local function safeWavePosition(base, index)
	local angle = (index * 137.5) % 360
	local radius = 35 + math.floor((index - 1) / 8) * 45
	local guess = base + Angle(0, angle, 0):Forward() * radius
	local tr = util.TraceHull({
		start = guess + Vector(0, 0, 96),
		endpos = guess - Vector(0, 0, 180),
		mins = Vector(-16, -16, 0),
		maxs = Vector(16, 16, 72),
		mask = MASK_PLAYERSOLID,
	})
	return tr.Hit and tr.HitPos + Vector(0, 0, 4) or base + Vector(0, 0, 8)
end

function G.SpawnRaidBoardingUnit(active, pos, zoneIndex, unit, variant)
	if G.Active ~= active or active.phase ~= "boarding" or not isvector(pos) then return end
	unit = unit or G.ChooseRaidBoardingUnit(active, 1, 1)
	local class, defaultWeapon = G.ResolveDroidNPC(unit.npcType)
	local weapon = G.ResolveDroidWeapon(unit.weapon, defaultWeapon)
	local def = {
		name = tostring(unit.label or "Galaxy Director Battle Droid"),
		category = "Galaxy Director",
		kind = "npc",
		class = class,
		weapon = weapon,
	}
	local npc
	if MilBase.DoEventSpawn then
		npc = MilBase.DoEventSpawn(nil, def, pos, math.Rand(0, 360), {
			team = "enemy",
			hp = math.max(0.1, tonumber(gd.DroidHealthMultiplier) or 1)
				* math.max(0.25, tonumber(unit.health) or 1),
			stance = "attack",
		})
	else
		npc = ents.Create(class)
		if IsValid(npc) then
			npc:SetPos(pos)
			npc:SetAngles(Angle(0, math.Rand(0, 360), 0))
			if weapon then npc:SetKeyValue("additionalequipment", weapon) end
			npc:Spawn()
			npc:Activate()
			npc:AddRelationship("player D_HT 99")
		end
	end
	if not IsValid(npc) then return end

	local raidModel = string.Trim(tostring(unit.model or ""))
	if raidModel ~= "" and util.IsValidModel(raidModel) then
		npc:SetModel(raidModel)
	end
	local minimumHealth = math.max(1,
		math.floor(tonumber(unit.minimumHealth) or 1))
	if npc:GetMaxHealth() < minimumHealth then
		npc:SetMaxHealth(minimumHealth)
		npc:SetHealth(minimumHealth)
	end
	if weapon and weapons.GetStored(weapon) and npc.Give then
		local equipped = npc:GetActiveWeapon()
		if not IsValid(equipped) or equipped:GetClass() ~= weapon then npc:Give(weapon) end
	end
	if npc.SetCurrentWeaponProficiency and tonumber(unit.proficiency) then
		npc:SetCurrentWeaponProficiency(tonumber(unit.proficiency))
	end
	npc.mb_galaxyEncounter = active.id
	npc.mb_galaxyBoardingUnit = tostring(unit.id or "b1_rifleman")
	npc.mb_galaxyBoardingUnitName = tostring(unit.label or "BATTLE DROID")
	npc.mb_galaxyBoardingNPCType = tostring(unit.npcType or "b1")
	npc.mb_galaxyBreachZone = zoneIndex
	npc.mb_galaxyBoardingHealthApplied = true
	variant = variant or G._boardingWaveVariant
	npc.mb_galaxyBoardingVariant = variant
	if variant == "commando" and npc.SetCurrentWeaponProficiency then
		npc:SetCurrentWeaponProficiency(WEAPON_PROFICIENCY_VERY_GOOD)
	elseif variant == "saboteur" or variant == "demolition" then
		npc.mb_galaxySaboteur = true
	end
	npc:SetNWBool("mb_galaxy_npc", true)
	npc:SetNWString("mb_galaxy_unit", npc.mb_galaxyBoardingUnitName)
	npc:SetNWInt("mb_galaxy_breach_zone", zoneIndex)
	active.npcs = active.npcs or {}
	active.entities = active.entities or {}
	active.waveComposition = active.waveComposition or {}
	active.npcs[#active.npcs + 1] = npc
	active.entities[#active.entities + 1] = npc
	active.waveComposition[npc.mb_galaxyBoardingUnit]
		= (active.waveComposition[npc.mb_galaxyBoardingUnit] or 0) + 1
	return npc
end

local function deployDropshipGroup(active, zone, zoneIndex, entries)
	active.pendingDeployments = (active.pendingDeployments or 0) + #entries
	local settled = false
	local function finishDeployment()
		if settled then return 0 end
		settled = true
		active.pendingDeployments = math.max(0,
			(active.pendingDeployments or 0) - #entries)
		if G.Active ~= active or active.phase ~= "boarding" then return 0 end
		local spawned = 0
		for sequence, entry in ipairs(entries) do
			local pos = safeWavePosition(zone.pos, entry.sequence or sequence)
			if IsValid(G.SpawnRaidBoardingUnit(active, pos, zoneIndex,
				entry.unit, entry.variant)) then
				spawned = spawned + 1
			end
		end
		active.hostiles = raidHostileCount(active)
		scheduleRaidBoardingVictoryCheck(active)
		return spawned
	end

	local ok, ship
	if MilBase.StartDropshipDrop then
		ok, ship = MilBase.StartDropshipDrop(nil, zone.pos, {
			model = gd.RaidDropshipModel,
			npcCount = #entries,
			team = "enemy",
			stance = "attack",
			yaw = tonumber(active.sideYaw) or 0,
			approachTime = gd.RaidDropshipApproachTime,
			holdTime = gd.RaidDropshipHoldTime,
			departureTime = gd.RaidDropshipDepartureTime,
			approachDistance = gd.RaidDropshipApproachDistance,
			approachHeight = gd.RaidDropshipApproachHeight,
			hoverHeight = gd.RaidDropshipHoverHeight,
			dropRadius = gd.RaidDropshipDropRadius,
			turnAround = false,
			onDrop = finishDeployment,
			onCancel = finishDeployment,
		})
	end
	if ok and IsValid(ship) then
		ship.mb_galaxyTemporary = true
		ship.mb_galaxyEncounter = active.id
		active.dropships = active.dropships or {}
		active.entities = active.entities or {}
		active.dropships[#active.dropships + 1] = ship
		active.entities[#active.entities + 1] = ship
		return true
	end
	finishDeployment()
	return false
end

local function finishDrillPodQueue(active, zone, zoneIndex, deploy)
	local entries = zone.pendingRaidUnits or {}
	zone.pendingRaidUnits = {}
	if #entries == 0 then return 0 end
	active.pendingDeployments = math.max(0,
		(active.pendingDeployments or 0) - #entries)
	if not deploy or G.Active ~= active or active.phase ~= "boarding" then
		active.hostiles = raidHostileCount(active)
		if G.Active == active and active.phase == "boarding" then
			scheduleRaidBoardingVictoryCheck(active)
		end
		return 0
	end
	local spawned = 0
	for sequence, entry in ipairs(entries) do
		local pos = safeWavePosition(zone.pos, entry.sequence or sequence)
		if IsValid(G.SpawnRaidBoardingUnit(active, pos, zoneIndex,
			entry.unit, entry.variant)) then
			spawned = spawned + 1
		end
	end
	active.hostiles = raidHostileCount(active)
	scheduleRaidBoardingVictoryCheck(active)
	return spawned
end

function G.SpawnBoardingWave(active)
	if G.Active ~= active or active.phase ~= "boarding" then return 0 end
	if active.wave >= active.maxWaves then return 0 end

	local zones = active.breachZones or {}
	if #zones == 0 then
		G.PrepareRaidBreachZones(active)
		zones = active.breachZones or {}
	end
	if #zones == 0 then
		announce("Boarding wave delayed: no safe boarding anchors or navigation areas were found.",
			Color(235, 170, 65))
		active.nextWave = CurTime() + 30
		return 0
	end

	local cap = math.max(1, math.floor(tonumber(G.Runtime.maxNPCs) or 36))
	local available = cap - galaxyNPCCount(active)
		- G.RaidPlayerEnemyCount(active)
		- math.max(0, math.floor(tonumber(active.pendingDeployments) or 0))
	if available <= 0 then return 0 end
	local breachBonus = math.max(0, #zones - 1)
		* math.max(0, tonumber(gd.RaidDroidsPerAdditionalBreach) or 2)
	local count = math.min(available, math.max(#zones, math.floor(
		(tonumber(G.Runtime.waveSize) or 5) + breachBonus
			+ math.max(0, G.ActivePlayerCount() - 4) * 0.45)))
	local spawned = 0
	active.npcs = active.npcs or {}
	active.wave = active.wave + 1
	active.waveComposition = {}
	local dropshipGroups = {}

	for i = 1, count do
		local zoneIndex = ((i - 1) % #zones) + 1
		local zone = zones[zoneIndex]
		local unit = G.ChooseRaidBoardingUnit(active, i, count)
		if zone.deployment == "dropship" and MilBase.StartDropshipDrop then
			dropshipGroups[zoneIndex] = dropshipGroups[zoneIndex] or {}
			dropshipGroups[zoneIndex][#dropshipGroups[zoneIndex] + 1] = {
				sequence = i,
				unit = unit,
				variant = G._boardingWaveVariant,
			}
		elseif zone.deployment == "drill" and IsValid(zone.pod)
		and not zone.drillReady then
			zone.pendingRaidUnits = zone.pendingRaidUnits or {}
			zone.pendingRaidUnits[#zone.pendingRaidUnits + 1] = {
				sequence = i,
				unit = unit,
				variant = G._boardingWaveVariant,
			}
			active.pendingDeployments = (active.pendingDeployments or 0) + 1
			spawned = spawned + 1
		else
			local pos = safeWavePosition(zone.pos, i)
			if IsValid(G.SpawnRaidBoardingUnit(active, pos, zoneIndex, unit)) then
				spawned = spawned + 1
			end
		end
	end
	for zoneIndex, entries in pairs(dropshipGroups) do
		deployDropshipGroup(active, zones[zoneIndex], zoneIndex, entries)
		spawned = spawned + #entries
	end

	active.hostiles = raidHostileCount(active)
	active.nextWave = CurTime() + math.max(10, tonumber(G.Runtime.waveInterval) or 48)
	announce("CIS boarding wave " .. active.wave .. "/" .. active.maxWaves
		.. " deployed across " .. #zones .. " fronts — " .. spawned
		.. " mixed B1/B2 droids detected.", Color(230, 75, 65))
	G.BroadcastState()
	return spawned
end

function G.DeployBoardingPods(active)
	local zones = active and active.breachZones or {}
	if #zones == 0 or not MilBase.CreateEventEnemyDrillPod then return end
	active.pods = active.pods or {}
	local count = 0
	for i, zone in ipairs(zones) do
		if count >= math.max(0, tonumber(gd.BoardingPodsPerRaid) or 4) then break end
		if zone.deployment ~= "drill" then continue end
		if IsValid(zone.pod) and zone.drillReady then continue end
		count = count + 1
		local deploymentIndex = i
		local deploymentZone = zone
		local id = "galaxy_" .. active.id .. "_" .. i
		local pod = MilBase.CreateEventEnemyDrillPod(nil, zone.pos, {
			id = id,
			name = tostring(zone.label or "CIS Boarding Pod"),
			model = gd.RaidDrillPodModel,
			dropHeight = 1400,
			dropTime = 4,
			drillTime = 3,
			enabled = false,
			maxActive = 0,
			onActive = function()
				if G.Active ~= active or active.phase ~= "boarding" then return end
				deploymentZone.drillReady = true
				finishDrillPodQueue(active, deploymentZone, deploymentIndex, true)
			end,
			onCancel = function()
				deploymentZone.drillDestroyed = true
				deploymentZone.deployment = "dropship"
				finishDrillPodQueue(active, deploymentZone, deploymentIndex, false)
			end,
		})
		if IsValid(pod) then
			zone.pod = pod
			pod.mb_galaxyTemporary = true
			active.pods[#active.pods + 1] = pod
			active.entities[#active.entities + 1] = pod
		else
			zone.deployment = "dropship"
		end
	end
end

local function raidPlayableClassIDs()
	local classes = {}
	if not MilBase.EventEnemyClassEnabled then return classes end
	for _, classID in ipairs(gd.RaidPlayableEnemyClasses or {}) do
		if MilBase.EventEnemyClassEnabled(classID)
		and not table.HasValue(classes, classID) then
			classes[#classes + 1] = classID
		end
	end
	if #classes == 0 then
		for _, classID in ipairs(MilBase.EventEnemyOrder or {}) do
			if MilBase.EventEnemyClassEnabled(classID)
			and string.lower(classID) ~= "boss" then
				classes[#classes + 1] = classID
			end
		end
	end
	return classes
end

function G.PrepareRaidPlayerEnemySpawns(active)
	if not active or active.kind ~= "cis_raid"
	or active.raidPlayerSpawnsPrepared then return active and active.raidPlayerSpawnIDs or {} end
	active.raidPlayerSpawnsPrepared = true
	active.raidPlayerSpawnIDs = {}
	if not MilBase.CreateInvisibleEventEnemySpawn then return active.raidPlayerSpawnIDs end

	local positions = configAnchorPositions("boarding_player")
	if #positions == 0 then
		for _, zone in ipairs(active.breachZones or {}) do
			if isvector(zone.pos) and util.IsInWorld(zone.pos) then
				positions[#positions + 1] = zone.pos
			end
		end
	end
	local classes = raidPlayableClassIDs()
	for index, pos in ipairs(positions) do
		local id = "galaxy_raid_" .. tostring(active.id) .. "_player_" .. index
		local spawn = MilBase.CreateInvisibleEventEnemySpawn(nil, pos, {
			id = id,
			name = "CIS PLAYER DEPLOYMENT " .. (raidZoneNames[index] or tostring(index)),
			enabled = true,
			radius = 110,
			maxActive = 0,
			classes = classes,
		})
		if spawn then active.raidPlayerSpawnIDs[#active.raidPlayerSpawnIDs + 1] = id end
	end
	return active.raidPlayerSpawnIDs
end

local function raidPlayableClassOverrides(classIDs)
	local overrides = {}
	for index, classID in ipairs(classIDs) do
		local lower = string.lower(tostring(classID))
		local heavy = string.find(lower, "b2", 1, true)
			or string.find(lower, "super", 1, true)
			or string.find(lower, "heavy", 1, true)
		local weapon = heavy
			and G.ResolveDroidWeapon("arccw_k_b2hand", "weapon_ar2")
			or G.ResolveDroidWeapon(index % 2 == 0 and "arccw_cgi_k_e5c"
				or "arccw_cgi_k_e5", "weapon_ar2")
		overrides[classID] = {
			health = heavy and 650 or 180,
			lives = math.max(1,
				math.floor(tonumber(gd.RaidPlayableEnemyLives) or 3)),
			weapons = { weapon },
			model = heavy
				and "models/aussiwozzi/cgi/b1droids/b2_battledroid_rocket.mdl"
				or "models/aussiwozzi/cgi/b1droids/b1_battledroid.mdl",
		}
	end
	return overrides
end

function G.OfferRaidEventEnemies(active)
	if not active or G.Active ~= active or active.kind ~= "cis_raid"
	or active.phase ~= "boarding" or gd.RaidPlayableEnemiesEnabled == false
	or active.raidPlayerOffersSent or not MilBase.OfferEventEnemy then return 0 end
	active.raidPlayerOffersSent = true
	local population = G.ActivePlayerCount()
	local minimum = math.max(1,
		math.floor(tonumber(gd.RaidPlayableEnemiesMinimumPlayers) or 12))
	if population < minimum then return 0 end

	local reserve = math.max(1,
		math.floor(tonumber(gd.RaidPlayableEnemiesDefenderReserve) or 8))
	local maximum = math.min(
		math.max(0, math.floor(tonumber(gd.RaidPlayableEnemiesMaximum) or 4)),
		math.max(0, population - reserve))
	if maximum <= 0 then return 0 end
	local classIDs = raidPlayableClassIDs()
	local spawnIDs = G.PrepareRaidPlayerEnemySpawns(active)
	if #classIDs == 0 or #spawnIDs == 0 then return 0 end

	local candidates = {}
	for _, ply in ipairs(G.ActivePlayers()) do
		if not ply:IsBot()
		and not MilBase.IsEventEnemy(ply)
		and not ply:GetNWBool("mb_eventmode", false) then
			candidates[#candidates + 1] = ply
		end
	end
	for index = #candidates, 2, -1 do
		local swap = math.random(index)
		candidates[index], candidates[swap] = candidates[swap], candidates[index]
	end
	maximum = math.min(maximum, math.max(0, #candidates - reserve))
	if maximum <= 0 then return 0 end

	local offerCount = math.min(#candidates, maximum * math.max(1,
		math.floor(tonumber(gd.RaidPlayableEnemyOfferMultiplier) or 2)))
	local context = {
		raidID = active.id,
		maximum = maximum,
		spawnIDs = table.Copy(spawnIDs),
		lives = math.max(1,
			math.floor(tonumber(gd.RaidPlayableEnemyLives) or 3)),
		classOverrides = raidPlayableClassOverrides(classIDs),
	}
	local sent = 0
	for index = 1, offerCount do
		if MilBase.OfferEventEnemy(nil, candidates[index], classIDs, {
			sourceName = "CIS BOARDING COMMAND",
			spawnIDs = spawnIDs,
			context = context,
		}) then
			sent = sent + 1
		end
	end
	if sent > 0 then
		announce("CIS command is recruiting up to " .. maximum
			.. " volunteer player-controlled boarders. Check the event-enemy offer.",
			Color(210, 85, 75))
	end
	return sent
end

function G.CleanupRaidPlayerEnemies(active)
	if not active then return end
	for _, ply in ipairs(player.GetAll()) do
		if ply.mb_enemyOffer and ply.mb_enemyOffer.context
		and ply.mb_enemyOffer.context.raidID == active.id then
			ply.mb_enemyOffer = nil
		end
		if ply.mb_galaxyRaidEventEnemy == active.id
		and MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply)
		and MilBase.RevertEventEnemy then
			MilBase.RevertEventEnemy(ply, true)
			MilBase.Notify(ply, "The CIS boarding role has ended. You have returned to your unit.")
		end
	end
	for _, id in ipairs(active.raidPlayerSpawnIDs or {}) do
		if MilBase.RemoveEventEnemySpawn then MilBase.RemoveEventEnemySpawn(id) end
	end
	active.raidPlayerSpawnIDs = {}
end

local function refreshRaidPlayerEnemyState(context)
	local active = G.Active
	if not active or active.kind ~= "cis_raid" or active.phase ~= "boarding"
	or not context or context.raidID ~= active.id then return end
	timer.Simple(0, function()
		if G.Active ~= active or active.phase ~= "boarding" then return end
		active.hostiles = raidHostileCount(active)
		if active.wave >= active.maxWaves and active.hostiles <= 0 then
			G.ResolveRaid("republic", "All CIS boarding waves were destroyed.")
		else
			G.BroadcastState()
		end
	end)
end

hook.Add("MilBase.EventEnemyActivated", "MilBase.GalaxyRaidPlayerEnemyJoined",
	function(_, _, context)
		refreshRaidPlayerEnemyState(context)
	end)

hook.Add("MilBase.EventEnemyReverted", "MilBase.GalaxyRaidPlayerEnemyLeft",
	function(_, context)
		refreshRaidPlayerEnemyState(context)
	end)

function G.AdvanceRaid(active)
	if G.Active ~= active or active.kind ~= "cis_raid" then return end
	if active.phase == "warning" then
		local model = G.ResolveRaidMunificentModel()
		if not model then
			G.CancelActive("The CIS assault was cancelled because no Munificent model is mounted.")
			announce("CIS force diverted: the configured Munificent model is unavailable.",
				Color(235, 175, 70))
			return
		end
		active.capitals = {}
		local desired = math.max(2, tonumber(active.requestedCapitalCount)
			or G.RaidMunificentCount())
		local spread = math.max(5, tonumber(gd.RaidMunificentBearingSpread) or 14)
		local hull = math.max(1000,
			(tonumber(gd.RaidMunificentHullBase) or 7600)
				+ G.ActivePlayerCount()
				* (tonumber(gd.RaidMunificentHullPerPlayer) or 320))
		local formationNames = { "Aurek", "Besh", "Cresh", "Dorn" }
		for index = 1, desired do
			local slot = index - (desired + 1) * 0.5
			local bearingOffset = slot * spread
			local entrySpacing = math.max(360,
				tonumber(gd.RaidMunificentSkyboxEntrySpacing) or 900)
			local heightStep = math.max(0,
				tonumber(gd.RaidMunificentSkyboxEntryHeightStep) or 150)
			local capital = G.SpawnShip("cis_capital", {
				name = "CIS Munificent " .. (formationNames[index] or tostring(index)),
				model = model,
				sideYaw = active.sideYaw + bearingOffset,
				lane = slot * entrySpacing,
				height = ((index - 1) % 2 == 0 and -1 or 1)
					* math.abs(slot) * heightStep,
				hold = true,
				encounterID = active.id,
				faction = "cis",
				hostile = true,
				capital = true,
				hull = hull,
			})
			if IsValid(capital) then
				capital.mb_galaxyRaidCapital = true
				capital.mb_galaxyRaidCapitalIndex = index
				capital:SetNW2Bool("MBGalaxyRaidCapital", true)
				active.capitals[#active.capitals + 1] = capital
			end
		end
		if #active.capitals < 2 then
			for _, capital in ipairs(active.capitals) do
				if IsValid(capital) then capital:Remove() end
			end
			G.CancelActive("The CIS assault was unable to place a complete Munificent attack group.")
			announce("CIS force diverted: fewer than two planet-safe capital approach vectors were available.",
				Color(235, 175, 70))
			return
		end
		active.capital = active.capitals[1]
		if G.SpawnRaidVultureForces then G.SpawnRaidVultureForces(active) end
		if G.SpawnRaidLVSVultures then G.SpawnRaidLVSVultures(active) end
		G.SetRaidPhase(active, "arrival", tonumber(G.Runtime.assaultDuration) or 90)
		active.nextBombardment = CurTime() + 2
		announce(#active.capitals .. " Munificent-class frigates emerging around the "
			.. math.floor(active.sideYaw)
			.. " degree bearing. Coordinated capital weapons fire incoming.",
			Color(235, 55, 50))
	elseif active.phase == "arrival" then
		G.SetRaidPhase(active, "breach", tonumber(G.Runtime.breachDuration) or 25)
		local breachedFronts = G.BreachMainShip(active)
		announce(breachedFronts > 0
			and breachedFronts .. " CIS breach fronts are opening across the base. Divide response teams."
			or "Multiple internal breach alerts detected. All available units repel boarders.",
			Color(245, 70, 55))
	elseif active.phase == "breach" then
		G.SetRaidPhase(active, "boarding", tonumber(G.Runtime.boardingDuration) or 360)
		G.DeployBoardingPods(active)
		G.PrepareRaidPlayerEnemySpawns(active)
		G.OfferRaidEventEnemies(active)
		active.nextWave = CurTime()
		active.nextPressure = CurTime() + 15
	elseif active.phase == "boarding" then
		G.ResolveRaid("republic", "Republic forces held the ship until the CIS withdrew.")
	end
end

local function cleanupRaidEntities(active)
	G.CleanupRaidPlayerEnemies(active)
	for _, ent in ipairs(active.entities or {}) do
		if not IsValid(ent) then
			-- Nothing to clean.
		elseif ent:GetClass() == "mb_galaxy_ship" then
			if ent.mb_destroyed then
				SafeRemoveEntityDelayed(ent, 1.4)
			elseif G.BeginCISRetreat and ent.mb_galaxyCombatPrepared then
				G.BeginCISRetreat(ent, ent:GetShipName() .. " is withdrawing from the battle.")
			else
				ent:ClearCombatTarget()
				ent:SetShipState("retreating")
				ent.mb_galaxyHoldForPlayerDeparture = false
				ent.mb_galaxyPlayerDeparting = true
				local away = ent:GetPos() - select(1, G.SkyboxFrame())
				away.z = 0
				if away:LengthSqr() < 1 then away = ent:GetForward() * -1 end
				ent:SetFlightVelocity(away:GetNormalized() * 85)
				ent:SetDieAt(CurTime() + 18)
			end
		else
			if ent:GetClass() == "mb_enemy_drillpod" then
				ent.mb_skipSpawnUnregister = false
			end
			SafeRemoveEntityDelayed(ent, 8)
		end
	end
end

function G.ResolveRaid(outcome, details, actor)
	local active = G.Active
	if not active or active.kind ~= "cis_raid" then return end
	active.outcome = outcome
	active.phase = "retreat"
	active.endsAt = CurTime() + 18
	G.LockHyperspace(false)
	if G.ReleaseNearbyRepublicRaidSupport then
		G.ReleaseNearbyRepublicRaidSupport(active, "CIS assault resolved")
	end

	local republicWon = outcome == "republic"
	local fled = outcome == "fled"
	announce(details or (republicWon and "The CIS force is withdrawing."
		or fled and "The Republic ship escaped into hyperspace."
		or "The CIS boarding action has overwhelmed ship defences."),
		republicWon and Color(95, 220, 135)
			or fled and Color(235, 175, 70) or Color(235, 65, 55))

	if republicWon then
		G.AddRecommendation(G.State.currentPlanet, 5, -3,
			"Republic forces successfully defended the system from a CIS capital assault.",
			IsValid(actor) and actorName(actor) or "Republic defenders")
	else
		local planet = G.EnsurePlanet(G.State.currentPlanet)
		if planet and not planet.locked then
			planet.pressure = math.Clamp(planet.pressure
				+ (fled and (tonumber(gd.FleePressureIncrease) or 7) or 12), 0, 100)
			G.SavePlanet(planet, actor)
		end
	end

	G.RecordHistory("cis_raid", outcome, G.State.currentPlanet, details)
	G.DiscordPost(republicWon and "CIS assault repelled"
		or fled and "Republic ship withdrew from CIS assault"
		or "CIS assault successful",
		"**Location:** " .. G.State.currentPlanet
			.. "\n**Outcome:** " .. G.CleanText(details, 1000)
			.. "\n**Munificents destroyed:** " .. (active.capitalsDestroyed or 0)
			.. "\n**Vulture Droids destroyed:** " .. (active.vulturesDestroyed or 0)
			.. "\n**Boarding droids destroyed:** " .. (active.kills or 0),
		republicWon and 3066993 or fled and 15105570 or 15158332, false)
	cleanupRaidEntities(active)
	G.Active = nil
	G.ScheduleNextEncounter("raid resolved")
	G.SendEncounter()
	G.BroadcastState()
end

hook.Add("OnNPCKilled", "MilBase.GalaxyBoardingKills", function(npc)
	local active = G.Active
	if not active or active.kind ~= "cis_raid" or npc.mb_galaxyEncounter ~= active.id then return end
	active.kills = (active.kills or 0) + 1
	timer.Simple(0, function()
		if G.Active ~= active then return end
		active.hostiles = raidHostileCount(active)
		if active.phase == "boarding" and active.wave >= active.maxWaves
		and active.hostiles <= 0 then
			G.ResolveRaid("republic", "All CIS boarding waves were destroyed.")
		else
			G.BroadcastState()
		end
	end)
end)

function G.RunSimulationTick(forced)
	G.State.nextSimulationAt = CurTime() + math.max(300,
		tonumber(G.Runtime.simulationInterval) or 1800)
	if not forced and (not G.Runtime.enabled or not G.Runtime.simulation) then return false end
	if not forced and not gd.SimulateWhileEmpty and G.ActivePlayerCount() <= 0 then return false end

	local cisWorlds = {}
	local candidates = {}
	for key, planet in pairs(G.Planets) do
		local pos = G.UniversePositions[key]
		if planet.allegiance == "cis" and pos then
			cisWorlds[#cisWorlds + 1] = { planet = planet, pos = pos }
		elseif planet.allegiance ~= "cis" and not planet.locked then
			candidates[#candidates + 1] = { planet = planet, pos = pos }
		end
	end
	if #candidates == 0 then return false end

	if #cisWorlds > 0 then
		for _, candidate in ipairs(candidates) do
			local nearest
			if candidate.pos then
				for _, cisWorld in ipairs(cisWorlds) do
					local distance = candidate.pos:DistToSqr(cisWorld.pos)
					nearest = not nearest and distance or math.min(nearest, distance)
				end
			end
			local allegianceBias = candidate.planet.allegiance == "contested" and 0.55
				or candidate.planet.allegiance == "neutral" and 0.8 or 1.2
			candidate.score = (nearest or math.huge) * allegianceBias
		end
		table.sort(candidates, function(a, b) return a.score < b.score end)
	end

	local selectionLimit = math.min(#candidates, 10)
	local target = candidates[math.random(selectionLimit)].planet
	local low = math.max(1, math.floor(tonumber(G.Runtime.cisPressureMin) or 6))
	local high = math.max(low, math.floor(tonumber(G.Runtime.cisPressureMax) or 14))
	local increase = math.random(low, high)
	if target.allegiance == "republic" then increase = math.max(1, math.floor(increase * 0.7)) end
	target.pressure = math.Clamp(target.pressure + increase, 0, 100)

	if target.pressure >= 100 then
		target.allegiance = "cis"
		target.pressure = 35
		G.SavePlanet(target)
		if G.SetPlanetaryBlockade then
			G.SetPlanetaryBlockade(target.name, "cis", true, nil,
				"automatic CIS occupation")
		end
		announce(target.name .. " has fallen under automatic CIS occupation.",
			Color(235, 65, 55))
		G.DiscordPost("Planet occupied by the CIS",
			"**Planet:** " .. target.name
				.. "\nThe strategic simulation reached maximum CIS pressure. "
				.. "Management can review or override the result in the Galaxy Director tab.",
			15158332, discord.MentionOnPlanetFall ~= false)
		G.Audit(nil, "CIS automatically occupied planet", target.name)
	else
		if target.allegiance == "neutral" and target.pressure >= 65 then
			target.allegiance = "contested"
		end
		G.SavePlanet(target)
	end

	if G.PlanetKey(G.State.currentPlanet) == target.key then
		G.State.currentRisk = G.PlanetDanger(target)
	end
	G.BroadcastState()
	return true, target
end

function G.CancelActive(reason, actor)
	local active = G.Active
	if not active then return false end
	reason = G.CleanText(reason ~= "" and reason or "Cancelled by staff.", 500)

	if active.kind == "cis_raid" then
		G.LockHyperspace(false)
		if G.ReleaseNearbyRepublicRaidSupport then
			G.ReleaseNearbyRepublicRaidSupport(active, "raid cancelled")
		end
		cleanupRaidEntities(active)
	else
		releaseEncounterShips(active, 8)
	end
	G.RecordHistory(active.kind, "cancelled", G.State.currentPlanet, reason)
	G.Active = nil
	G.SendEncounter()
	G.ScheduleNextEncounter("cancelled")
	G.BroadcastState()
	if actor then G.Audit(actor, "cancelled Galaxy event", reason) end
	return true
end

local function tickActiveEncounter(active, now)
	if active.kind == "cis_raid" then
		if now >= (active.nextDoorHoldOpen or 0) then
			active.nextDoorHoldOpen = now + 3
			for _, door in ipairs(active.breachedDoors or {}) do
				if IsValid(door) then G.HoldBreachDoorOpen(door) end
			end
			if #(active.breachedDoors or {}) == 0 and IsValid(active.breachedDoor) then
				G.HoldBreachDoorOpen(active.breachedDoor)
			end
		end
		if active.phase == "warning" and not active.forced
		and G.ActivePlayerCount() < math.max(1, tonumber(G.Runtime.minPlayersAttack) or 6) then
			G.CancelActive("CIS attack stood down because the active player count fell below the minimum.")
			announce("CIS attack postponed: insufficient active personnel.", Color(235, 175, 70))
			return
		end
		if active.phase ~= "warning" and active.phase ~= "retreat"
		and #G.RaidCapitals(active) == 0 then
			G.ResolveRaid("republic",
				"The Republic destroyed every Munificent in the CIS attack group.")
			return
		end

		if (active.phase == "arrival" or active.phase == "breach")
		and now >= (active.nextBombardment or 0) then
			active.nextBombardment = now + math.Rand(5, active.phase == "breach" and 8 or 11)
			G.BombardMainShip(active, active.phase == "breach")
		end

		if active.phase == "boarding" then
			active.hostiles = raidHostileCount(active)
			if now >= (active.nextWave or 0) and active.wave < active.maxWaves then
				G.SpawnBoardingWave(active)
			end
			if now >= (active.nextPressure or 0) then
				active.nextPressure = now + 15
				local pressure = math.max(0, active.hostiles or 0) * 0.38
				if pressure > 0 then
					active.integrity = math.max(0, active.integrity - pressure)
					if active.integrity <= 0 then
						G.ResolveRaid("cis",
							"CIS boarding teams overwhelmed the ship's defensive integrity.")
						return
					end
				end
				G.BroadcastState()
			end
		end

		if now >= (active.endsAt or math.huge) then G.AdvanceRaid(active) end
		return
	end

	if active.kind == "cis" and active.phase == "skirmish" then
		if now >= (active.nextBombardment or 0) then
			active.nextBombardment = now + math.Rand(6, 10)
			G.BombardMainShip(active, false)
		end
		if now >= active.endsAt then
			G.ResolveEncounter("success", "The CIS vessel breaks contact and withdraws.")
		end
		return
	end

	if active.kind == "distress" and active.phase == "rescue" then
		if now >= active.endsAt then
			if IsValid(active.civilianShip) then
				G.AddRecommendation(G.State.currentPlanet, 4, -2,
					"Republic forces answered a civilian distress call.", active.responder or "Republic crew")
				G.ResolveEncounter("success",
					"The civilian vessel reaches a safe jump vector and escapes the attackers.")
			else
				G.ResolveEncounter("failure", "The civilian vessel was destroyed.")
			end
		end
		return
	end

	if active.kind == "pirate" and active.phase == "combat" and now >= active.endsAt then
		G.ResolveEncounter("success",
			"The pirate vessels abandon the engagement and retreat into hyperspace.")
		return
	end

	if now >= (active.endsAt or math.huge) then
		G.ResolveEncounter("neutral", "The contact closes its channel and leaves the area.")
	end
end

timer.Create("MilBase.GalaxyDirectorThink", 1, 0, function()
	if IsValid(G.CommsOperator) and not G.CommsSessionValid(G.CommsOperator, G.CommsTerminal) then
		G.ReleaseCommsOperator("Ship communications disconnected: remain near the terminal.")
	end
	if IsValid(G.ScannerOperator) and not G.ScannerSessionValid(G.ScannerOperator, G.ScannerTerminal) then
		G.ReleaseScannerOperator("Tactical scanner disconnected: remain near the terminal.")
	end
	if IsValid(G.GunnerOperator) and not G.GunnerSessionValid(G.GunnerOperator, G.GunnerTerminal) then
		G.ReleaseGunnerOperator("Fire control disconnected: remain near the terminal.")
	end
	if IsValid(G.IonOperator) and not G.OrdnanceSessionValid(G.IonOperator, G.IonTerminal, "ion") then
		G.ReleaseOrdnanceOperator("ion", "Ion cannon disconnected: remain near the terminal.")
	end
	if IsValid(G.TorpedoOperator)
	and not G.OrdnanceSessionValid(G.TorpedoOperator, G.TorpedoTerminal, "torpedo") then
		G.ReleaseOrdnanceOperator("torpedo", "Torpedo control disconnected: remain near the terminal.")
	end
	if not G.State.ready then return end
	local now = CurTime()

	if G.Active then
		tickActiveEncounter(G.Active, now)
		return
	end

	if now >= (G.State.nextAmbientAt or 0) then G.SpawnAmbientFlight() end
	if now >= (G.State.nextSimulationAt or 0) then G.RunSimulationTick(false) end
	if now >= (G.State.nextEncounterAt or 0) then G.TryStartRandomEncounter("timer") end
end)

function G.BroadcastAdminData()
	for _, ply in ipairs(player.GetAll()) do
		if G.IsStaff(ply) then G.SendAdminData(ply) end
	end
end

net.Receive("MilBase_GalaxyAdminRequest", function(_, ply)
	if not G.IsStaff(ply) then return end
	if (ply.mb_nextGalaxyAdminRequest or 0) > CurTime() then return end
	ply.mb_nextGalaxyAdminRequest = CurTime() + 0.75
	G.SendAdminData(ply)
end)

local function setRuntimeValue(actor, key, value)
	if gd.RuntimeDefaults[key] == nil then return false, "Unknown setting." end
	local default = gd.RuntimeDefaults[key]

	if type(default) == "boolean" then
		if key == "simulation" and not G.IsManagement(actor) then
			return false, "Only management can control the strategic simulation."
		end
		if key ~= "enabled" and key ~= "encounters" and key ~= "attacks"
		and key ~= "simulation" then
			return false, "That switch cannot be changed here."
		end
		value = value == true
	else
		if not G.IsManagement(actor) then return false, "Only management can tune configuration." end
		local field = G.GetRuntimeField(key)
		if not field then return false, "That setting is not live-tunable." end
		value = math.Clamp(tonumber(value) or default, field.min, field.max)
		if (field.decimals or 0) <= 0 then value = math.floor(value + 0.5) end
	end

	G.Runtime[key] = value
	local pairedKey
	if key == "encounterMin" or key == "encounterMax" then
		G.Runtime.encounterMax = math.max(G.Runtime.encounterMin, G.Runtime.encounterMax)
		if key == "encounterMin" then pairedKey = "encounterMax" end
	end
	if key == "cisPressureMin" or key == "cisPressureMax" then
		G.Runtime.cisPressureMax = math.max(G.Runtime.cisPressureMin, G.Runtime.cisPressureMax)
		if key == "cisPressureMin" then pairedKey = "cisPressureMax" end
	end
	G.SaveRuntime(key)
	if pairedKey then G.SaveRuntime(pairedKey) end

	if key == "enabled" and value == false and G.Active then
		G.CancelActive("Galaxy Director master switch was turned off.", actor)
	elseif key == "attacks" and value == false and G.Active
	and (G.Active.kind == "cis" or G.Active.kind == "cis_raid") then
		G.CancelActive("CIS attacks were turned off by staff.", actor)
	elseif key == "encounters" and value == false and G.Active and G.Active.kind ~= "cis_raid" then
		G.CancelActive("Ambient encounters were turned off by staff.", actor)
	end

	G.Audit(actor, "changed Galaxy setting", key .. " = " .. tostring(value))
	G.BroadcastState()
	return true
end

local function savePlanetFromAdmin(actor, data)
	if not G.IsManagement(actor) then return false, "Only management can edit planets." end
	local planet = G.EnsurePlanet(data.name or data.key)
	if not planet then return false, "Planet not found." end
	local allegiance = string.lower(tostring(data.allegiance or "neutral"))
	if not G.ValidAllegiances[allegiance] then return false, "Invalid allegiance." end
	local lockFaction = string.lower(tostring(data.lockFaction or ""))
	if lockFaction ~= "" and not G.ValidAllegiances[lockFaction] then
		return false, "Invalid lore-lock faction."
	end

	local before = planet.allegiance .. "/" .. planet.republicOpinion .. "/"
		.. planet.cisOpinion .. "/" .. planet.pressure
	planet.allegiance = allegiance
	planet.republicOpinion = math.Clamp(math.floor(tonumber(data.republicOpinion) or 0), -100, 100)
	planet.cisOpinion = math.Clamp(math.floor(tonumber(data.cisOpinion) or 0), -100, 100)
	planet.pressure = math.Clamp(math.floor(tonumber(data.pressure) or 0), 0, 100)
	planet.locked = data.locked == true
	planet.lockFaction = planet.locked and lockFaction or ""
	planet.note = G.CleanText(data.note, 500)
	G.SavePlanet(planet, actor)

	if G.PlanetKey(G.State.currentPlanet) == planet.key then
		G.State.currentPlanet = planet.name
		G.State.currentRisk = G.PlanetDanger(planet)
	end
	G.Audit(actor, "edited planet " .. planet.name,
		before .. " -> " .. planet.allegiance .. "/" .. planet.republicOpinion .. "/"
			.. planet.cisOpinion .. "/" .. planet.pressure
			.. (planet.locked and (" locked:" .. planet.lockFaction) or " unlocked"))
	G.BroadcastState()
	return true
end

local function decideRecommendation(actor, id, decision)
	if not G.IsManagement(actor) then return false, "Only management can decide recommendations." end
	id = math.max(0, math.floor(tonumber(id) or 0))
	local selected
	for _, recommendation in ipairs(G.Recommendations) do
		if recommendation.id == id then selected = recommendation break end
	end
	if not selected then return false, "Recommendation no longer exists." end
	if decision ~= "approve" and decision ~= "reject" then return false, "Invalid decision." end

	if decision == "approve" then
		local planet = G.Planets[selected.planetKey]
		if planet then
			planet.republicOpinion = math.Clamp(
				planet.republicOpinion + selected.republicDelta, -100, 100)
			planet.cisOpinion = math.Clamp(planet.cisOpinion + selected.cisDelta, -100, 100)
			G.SavePlanet(planet, actor)
			if G.PlanetKey(G.State.currentPlanet) == planet.key then
				G.State.currentRisk = G.PlanetDanger(planet)
			end
		end
	end

	MilBase.DB.Run(string.format(
		"UPDATE frontier_galaxy_recommendations SET status = %s, decided_at = %d, "
			.. "decided_by = %s WHERE id = %d AND status = 'pending'",
		MilBase.SQLStr(decision == "approve" and "approved" or "rejected"),
		nowUnix(), MilBase.SQLStr(actorName(actor)), id))
	G.Audit(actor, decision .. "d reputation recommendation",
		tostring(id) .. " — " .. selected.reason)
	G.LoadRecommendations(function() G.BroadcastAdminData() end)
	G.BroadcastState()
	return true
end

local function addAnchor(actor, data)
	local kind = data.kind == "impact" and "impact"
		or data.kind == "breach_door" and "breach_door"
		or data.kind == "capital" and "capital" or "boarding"
	if data.kind == "boarding_drill" then kind = "boarding_drill" end
	if data.kind == "boarding_dropship" then kind = "boarding_dropship" end
	if data.kind == "boarding_player" then kind = "boarding_player" end
	if data.kind == "space_battle" then kind = "space_battle" end
	local mode = data.mode == "self" and "self" or "aim"
	local pos
	local trace = actor:GetEyeTrace()
	if kind == "breach_door" then
		local door = trace and trace.Entity
		if not G.IsBreachDoor(door) then
			return false, "Aim directly at a supported map door."
		end
		pos = door:WorldSpaceCenter()
	elseif mode == "self" then
		pos = actor:GetPos()
	elseif kind == "capital" then
		local inset = G.MaximumRoleShipRadius and G.MaximumRoleShipRadius("cis_capital") or 520
		pos = trace and trace.Hit and (trace.HitPos + trace.HitNormal * (inset + 48)) or nil
	elseif kind == "space_battle" then
		local inset = G.MaximumRoleShipRadius and G.MaximumRoleShipRadius("civilian") or 320
		pos = trace and trace.Hit and (trace.HitPos + trace.HitNormal * (inset + 96)) or nil
	else
		pos = trace and trace.Hit and trace.HitPos or nil
	end
	if not isvector(pos) or not util.IsInWorld(pos) then return false, "Aim at a valid world position." end
	local ang = kind == "capital" and (actor:GetPos() - pos):Angle()
		or actor:EyeAngles()
	local label = G.CleanText(data.label, 128)
	if label == "" then
		label = kind == "impact" and "Ship impact point"
			or kind == "breach_door" and "CIS breach door"
			or kind == "capital" and "Munificent sky position"
			or kind == "space_battle" and "LVS space battle position"
			or kind == "boarding_drill" and "CIS drill-pod zone"
			or kind == "boarding_dropship" and "CIS dropship zone"
			or kind == "boarding_player" and "Playable CIS deployment zone"
			or "CIS boarding point"
	end

	MilBase.DB.Insert(string.format(
		"INSERT INTO frontier_galaxy_anchors (map_name, anchor_kind, label, pos, ang) "
			.. "VALUES (%s, %s, %s, %s, %s)",
		MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(kind), MilBase.SQLStr(label),
		MilBase.SQLStr(util.TableToJSON({ x = pos.x, y = pos.y, z = pos.z })),
		MilBase.SQLStr(util.TableToJSON({ p = ang.p, y = ang.y, r = ang.r }))), function()
			G.LoadAnchors(function() G.BroadcastAdminData() end)
		end)
	G.Audit(actor, "added Galaxy " .. kind .. " anchor", label)
	return true
end

local function deleteAnchor(actor, id)
	id = math.max(0, math.floor(tonumber(id) or 0))
	local found
	for _, anchor in ipairs(G.Anchors) do
		if anchor.id == id then found = anchor break end
	end
	if not found then return false, "Anchor not found." end
	MilBase.DB.Run("DELETE FROM frontier_galaxy_anchors WHERE id = " .. id
		.. " AND map_name = " .. MilBase.SQLStr(game.GetMap()))
	G.Audit(actor, "deleted Galaxy anchor", found.label)
	G.LoadAnchors(function() G.BroadcastAdminData() end)
	return true
end

local function forceEvent(actor, kind)
	if G.Active then return false, "Cancel the active event first." end
	if kind == "random" then kind = G.PickEncounterKind() or "cis" end
	if kind == "raid" or kind == "cis_raid" then
		return G.StartRaid(true)
	end
	if not encounterCopy[kind] then return false, "Unknown encounter type." end
	local ok, result = G.StartEncounter(kind, true)
	if ok then G.Audit(actor, "forced Galaxy event", kind) end
	return ok, result
end

net.Receive("MilBase_GalaxyAdminAction", function(_, ply)
	if not G.IsStaff(ply) then return end
	if (ply.mb_nextGalaxyAdminAction or 0) > CurTime() then return end
	ply.mb_nextGalaxyAdminAction = CurTime() + 0.25

	local action = net.ReadString()
	local raw = net.ReadString()
	if #raw > 60000 then return end
	local data = util.JSONToTable(raw) or {}
	local ok, err

	if action == "runtime" then
		ok, err = setRuntimeValue(ply, G.CleanText(data.key, 64), data.value)
	elseif action == "force" then
		ok, err = forceEvent(ply, G.CleanText(data.kind, 32))
	elseif action == "cancel" then
		ok = G.CancelActive(data.reason or "Cancelled from the staff panel.", ply)
		if not ok then err = "No Galaxy event is active." end
	elseif action == "advance" then
		if G.Active and G.Active.kind == "cis_raid" then
			G.AdvanceRaid(G.Active)
			G.Audit(ply, "advanced CIS raid phase", G.Active and G.Active.phase or "resolved")
			ok = true
		else
			err = "No CIS raid is active."
		end
	elseif action == "resolve" then
		if G.Active and G.Active.kind == "cis_raid" then
			local outcome = data.outcome == "cis" and "cis" or "republic"
			G.ResolveRaid(outcome, outcome == "cis"
				and "Staff resolved the assault as a CIS victory."
				or "Staff resolved the assault as a Republic victory.", ply)
			G.Audit(ply, "resolved CIS raid", outcome)
			ok = true
		else
			err = "No CIS raid is active."
		end
	elseif action == "planet" then
		ok, err = savePlanetFromAdmin(ply, data)
	elseif action == "blockade" then
		if not G.IsManagement(ply) then
			err = "Only management can change an orbital blockade."
		elseif not G.SetPlanetaryBlockade or not G.ClearPlanetaryBlockade then
			err = "The living-universe blockade layer is unavailable."
		else
			local planet = G.CleanText(data.planet, 96)
			local faction = string.lower(G.CleanText(data.faction, 16))
			if faction == "clear" then
				ok, err = G.ClearPlanetaryBlockade(planet, ply)
			else
				ok, err = G.SetPlanetaryBlockade(planet, faction, true, ply,
					"management orbital blockade order")
			end
		end
	elseif action == "recommendation" then
		ok, err = decideRecommendation(ply, data.id, data.decision)
	elseif action == "anchor_add" then
		ok, err = addAnchor(ply, data)
	elseif action == "anchor_delete" then
		ok, err = deleteAnchor(ply, data.id)
	elseif action == "set_location" then
		if not G.IsManagement(ply) then
			err = "Only management can override the current location."
		else
			local planet = G.EnsurePlanet(data.name)
			if planet then
				G.SetCurrentPlanet(planet.name, "management override")
				G.Audit(ply, "set current Galaxy location", planet.name)
				ok = true
			else
				err = "Planet not found."
			end
		end
	elseif action == "simulation_tick" then
		if not G.IsManagement(ply) then
			err = "Only management can run a strategy tick."
		else
			ok = G.RunSimulationTick(true)
			if ok then G.Audit(ply, "forced CIS strategy tick", G.State.currentPlanet) end
			if not ok then err = "No eligible planet could be pressured." end
		end
	elseif action == "discord_test" then
		if not G.IsManagement(ply) then
			err = "Only management can test Discord."
		elseif not discord.Enabled or G.CleanText(discord.WebhookURL, 1000) == "" then
			err = "Discord is disabled or its server-only webhook is blank."
		else
			G.DiscordPost("Galaxy Director test",
				"Discord integration test requested by **" .. actorName(ply) .. "**.", 3447003, false)
			G.Audit(ply, "tested Galaxy Discord integration", "")
			ok = true
		end
	else
		err = "Unknown Galaxy Director action."
	end

	if not ok and err then MilBase.Notify(ply, tostring(err), "warn") end
	if ok then
		MilBase.Notify(ply, "Galaxy Director updated.", "ok")
		timer.Simple(0.15, function()
			if IsValid(ply) then G.SendAdminData(ply) end
		end)
	end
end)

local function canConsoleOperate(ply)
	return not IsValid(ply) or G.IsManagement(ply)
end

concommand.Add("mb_galaxy_force", function(ply, _, args)
	if not canConsoleOperate(ply) then return end
	local kind = string.lower(args[1] or "random")
	local ok, err = forceEvent(IsValid(ply) and ply or nil, kind)
	local text = ok and ("Forced Galaxy event: " .. kind) or tostring(err)
	if IsValid(ply) then MilBase.Notify(ply, text, ok and "ok" or "warn")
	else MsgN("[Galaxy Director] " .. text) end
end)

concommand.Add("mb_galaxy_status", function(ply)
	if IsValid(ply) and not G.IsStaff(ply) then return end
	local active = G.Active and (G.Active.kind .. "/" .. G.Active.phase) or "none"
	local comms = IsValid(G.CommsOperator)
		and (G.CommsOperator.MBName and G.CommsOperator:MBName()
			or G.CommsOperator:Nick()) or "unoccupied"
	local text = "location=" .. tostring(G.State.currentPlanet)
		.. " risk=" .. string.format("%.2f", G.State.currentRisk or 0)
		.. " active=" .. active
		.. " players=" .. G.ActivePlayerCount()
		.. " comms=" .. comms
		.. " terminals=" .. #ents.FindByClass("mb_galaxy_comms")
		.. " enabled=" .. tostring(G.Runtime.enabled)
	local target = G.Active and G.Active.kind == "cis_raid"
		and G.PrimaryRaidCapital(G.Active)
		or G.Active and (IsValid(G.Active.capital) and G.Active.capital
			or IsValid(G.Active.contactShip) and G.Active.contactShip)
	if IsValid(target) and target.mb_galaxyCombatPrepared then
		text = text
			.. " target=" .. target:GetShipName()
			.. " shield=" .. target:GetShield() .. "/" .. target:GetMaxShield()
			.. " hull=" .. target:GetHull() .. "/" .. target:GetMaxHull()
			.. " collision=" .. (target:GetNW2Bool("MBGalaxyModelCollision", false)
				and "model" or "fallback")
			.. " space=" .. (target.mb_galaxyMapSpace and "map" or "skybox")
	end
	if IsValid(ply) then MilBase.Notify(ply, text) else MsgN("[Galaxy Director] " .. text) end
end)

concommand.Add("mb_galaxy_wake_traffic", function(ply)
	if IsValid(ply) and not G.IsStaff(ply) then return end
	local moving, awakened, blockades, stalled = 0, 0, 0, 0
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
		if ship.mb_galaxyOrbitalBlockade then
			blockades = blockades + 1
		elseif ship.mb_galaxyFlightRoute or ship.mb_galaxyFormationFlight
		or ship:GetFlightVelocity():LengthSqr() > 1 then
			moving = moving + 1
		elseif G.AssignAutonomousShipMotion(ship, "manual traffic wake check") then
			awakened = awakened + 1
		else
			stalled = stalled + 1
		end
	end
	local text = "Traffic check: " .. moving .. " already moving, "
		.. awakened .. " awakened, " .. blockades
		.. " blockade ships holding, " .. stalled .. " unable to route."
	if IsValid(ply) then MilBase.Notify(ply, text, stalled > 0 and "warn" or "ok")
	else MsgN("[Galaxy Director] " .. text) end
end)

hook.Add("PostCleanupMap", "MilBase.GalaxyMapCleanup", function()
	if G.Active then G.CancelActive("Map cleanup interrupted the active Galaxy event.") end
	for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do ship:Remove() end
	timer.Simple(1, function()
		if not G.State.ready then return end
		G.LoadAnchors()
		G.DetectCurrentPlanet()
		G.ScheduleNextEncounter("map cleanup")
		G.ScheduleNextAmbient()
	end)
end)

hook.Add("ShutDown", "MilBase.GalaxyShutdown", function()
	G.LockHyperspace(false)
end)

hook.Add("MilBase.DBReady", "MilBase.GalaxyDatabase", function()
	G.InitializeDatabase()
end)

timer.Simple(0, function()
	G.InitializeDatabase()
end)
