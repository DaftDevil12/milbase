if not SERVER then return end
if not MilBase or not MilBase.Galaxy or not MilBase.Naval then return end
if MilBase.Galaxy.RaidFighterScreenLoaded then return end
MilBase.Galaxy.RaidFighterScreenLoaded = true

local G = MilBase.Galaxy
local N = MilBase.Naval
local gd = MilBase.Config.GalaxyDirector or {}
local naval = MilBase.Config.NavalOperations or {}

local function announce(text, colour)
	if G.AnnounceNavy then
		G.AnnounceNavy(text, colour)
	else
		for _, ply in ipairs(player.GetHumans()) do
			if IsValid(ply) and MilBase.Notify then MilBase.Notify(ply, text, "warn") end
		end
	end
end

local function targetRadiusScale(ent, targetRadius)
	if not IsValid(ent) then return 1 end
	local mins, maxs = ent:GetModelRenderBounds()
	if (not isvector(mins) or not isvector(maxs)) and util.GetModelBounds then
		mins, maxs = util.GetModelBounds(ent:GetModel())
	end
	local native = isvector(mins) and isvector(maxs)
		and math.max(mins:Length(), maxs:Length()) or 0
	local scale = native > 0 and math.Clamp(math.max(1, targetRadius) / native,
		0.001, 2) or 0.012
	if ent.SetModelSize then ent:SetModelSize(scale) end
	ent:SetModelScale(scale, 0.000001)
	if isvector(mins) and isvector(maxs) then
		ent:SetCollisionBounds(mins * scale, maxs * scale)
		if ent.SetCombatRadius then ent:SetCombatRadius(math.max(4, native * scale)) end
	end
	return scale
end

local function resolveVultureModel()
	for _, model in ipairs(gd.RaidVultureSkyboxModels or {}) do
		model = string.Trim(tostring(model or ""))
		if model ~= "" and util.IsValidModel(model) then return model end
	end
	return nil
end

local function clampSkyboxPoint(pos, margin)
	local _, _, mins, maxs = G.SkyboxFrame()
	margin = math.max(24, tonumber(margin) or 90)
	return Vector(
		math.Clamp(pos.x, mins.x + margin, maxs.x - margin),
		math.Clamp(pos.y, mins.y + margin, maxs.y - margin),
		math.Clamp(pos.z, mins.z + margin, maxs.z - margin)
	)
end

local function raidVultureCount(active)
	local minimum = math.max(1, math.floor(tonumber(gd.RaidVultureSkyboxMinimum) or 4))
	local maximum = math.max(minimum,
		math.floor(tonumber(gd.RaidVultureSkyboxMaximum) or 12))
	local perCapital = math.max(1,
		math.floor(tonumber(gd.RaidVulturePerMunificent) or 2))
	local perPlayer = math.max(1,
		math.floor(tonumber(gd.RaidVulturePlayersPerExtra) or 2))
	local capitalCount = math.max(1, #(active.capitals or {}))
	local requested = capitalCount * perCapital
		+ math.floor(math.max(0, G.ActivePlayerCount() - 1) / perPlayer)
	return math.Clamp(requested, minimum, maximum)
end

local function validRepublicVisuals()
	local result = {}
	for id, squadron in pairs(N.State and N.State.squadrons or {}) do
		for _, ship in ipairs(squadron.visuals or {}) do
			if IsValid(ship) and ship:GetClass() == "mb_galaxy_ship"
			and not ship.mb_destroyed then
				result[#result + 1] = {
					ship = ship,
					squadron = squadron,
					id = id,
				}
			end
		end
	end
	return result
end

local function nearestVisual(pos, visuals)
	local best, bestDistance
	for _, data in ipairs(visuals or {}) do
		local ship = data.ship
		if IsValid(ship) then
			local distance = pos:DistToSqr(ship:GetPos())
			if not bestDistance or distance < bestDistance then
				best, bestDistance = data, distance
			end
		end
	end
	return best
end

local function setVultureRoute(ship, parent, target)
	if not IsValid(ship) or not G.SetShipFlightRoute then return end
	local origin = ship:GetPos()
	local parentPos = IsValid(parent) and parent:GetPos() or origin
	local targetPos = IsValid(target) and target:GetPos()
		or select(1, G.SkyboxFrame())
	local radius = math.max(12, ship:GetCombatRadius())
	local right = IsValid(parent) and parent:GetRight() or ship:GetRight()
	local up = IsValid(parent) and parent:GetUp() or Vector(0, 0, 1)
	local points = {
		clampSkyboxPoint(origin + ship:GetForward() * 260
			+ right * math.Rand(-160, 160) + up * math.Rand(-80, 80), radius + 70),
		clampSkyboxPoint(targetPos + VectorRand() * 260, radius + 70),
		clampSkyboxPoint(parentPos + right * math.Rand(-420, 420)
			+ up * math.Rand(-180, 180), radius + 70),
	}
	G.SetShipFlightRoute(ship, points, {
		speed = math.max(40, tonumber(gd.RaidVultureSpeed) or 112),
		arrivalRadius = math.Clamp(radius * 1.6, 35, 90),
		lookAhead = math.max(110, radius * 5),
		loop = true,
		autonomous = true,
	})
end

function G.SpawnRaidVultureForces(active)
	if gd.RaidVultureSkyboxEnabled == false
	or G.Active ~= active or not active or active.kind ~= "cis_raid" then return 0 end
	local model = resolveVultureModel()
	if not model then
		announce("Munificent fighter bays report unavailable Vulture Droid model; "
			.. "the raid will continue without a skybox fighter screen.",
			Color(235, 175, 70))
		return 0
	end

	active.vultures = active.vultures or {}
	local count = raidVultureCount(active)
	local visuals = validRepublicVisuals()
	local stagger = math.max(0, tonumber(gd.RaidVultureLaunchStagger) or 0.2)

	for index = 1, count do
		local craftIndex = index
		timer.Simple((craftIndex - 1) * stagger, function()
			if G.Active ~= active or active.kind ~= "cis_raid"
			or active.phase == "retreat" then return end
			local capitals = active.capitals or {}
			local parent = capitals[((craftIndex - 1) % math.max(1, #capitals)) + 1]
			if not IsValid(parent) then return end

			local slot = math.floor((craftIndex - 1) / math.max(1, #capitals))
			local side = craftIndex % 2 == 0 and 1 or -1
			local offset = parent:GetRight() * side * (85 + slot * 42)
				+ parent:GetUp() * (((craftIndex - 1) % 3) - 1) * 48
				- parent:GetForward() * (45 + slot * 28)
			local targetData = visuals[((craftIndex - 1) % math.max(1, #visuals)) + 1]
			local target = targetData and targetData.ship or nil
			local ship = G.SpawnShip("cis_fighter", {
				name = "Vulture Droid " .. tostring(craftIndex),
				model = model,
				sizeClass = "fighter",
				faction = "cis",
				hostile = true,
				capital = false,
				hold = true,
				hull = math.max(50, tonumber(gd.RaidVultureHull) or 280),
				encounterID = active.id,
				sideYaw = active.sideYaw,
			})
			if not IsValid(ship) then return end

			ship:SetPos(clampSkyboxPoint(parent:GetPos() + offset, 80))
			ship:SetAngles(parent:GetAngles())
			ship:SetDieAt(0)
			ship:SetShipState("launching from Munificent fighter bay")
			ship.mb_galaxyRaidVulture = true
			ship.mb_galaxyVultureParent = parent
			ship:SetNW2Bool("MBGalaxyRaidVulture", true)
			targetRadiusScale(ship, tonumber(gd.RaidVultureTargetRadius) or 13)
			if G.BindShipToSWUUniverse then G.BindShipToSWUUniverse(ship) end

			local launch = parent:GetForward()
				+ parent:GetRight() * side * 0.24
				+ parent:GetUp() * math.Rand(-0.12, 0.12)
			launch:Normalize()
			ship:SetFlightVelocity(launch
				* math.max(40, tonumber(gd.RaidVultureSpeed) or 112))
			if IsValid(target) and ship.SetCombatTarget then
				ship:SetCombatTarget(target,
					math.max(1, tonumber(gd.RaidVultureDamage) or 18),
					math.max(0.5, tonumber(gd.RaidVultureFireInterval) or 0.9))
			end
			setVultureRoute(ship, parent, target)
			active.vultures[#active.vultures + 1] = ship
			active.entities = active.entities or {}
			active.entities[#active.entities + 1] = ship
		end)
	end

	announce(count .. " Vulture Droids launching from the Munificent group. "
		.. "Republic squadrons are cleared to engage the fighter screen.",
		Color(235, 80, 65))
	return count
end

local function vectorFromRecord(value)
	if isvector(value) then return Vector(value) end
	if istable(value) then
		if isvector(value.pos) then return Vector(value.pos) end
		local x = tonumber(value.x or value[1])
		local y = tonumber(value.y or value[2])
		local z = tonumber(value.z or value[3])
		if x and y and z then return Vector(x, y, z) end
	end
	return nil
end

local function angleFromRecord(value)
	if isangle(value) then return Angle(value) end
	if istable(value) then
		if isangle(value.ang) then return Angle(value.ang) end
		local p = tonumber(value.p or value.pitch or value[1])
		local y = tonumber(value.y or value.yaw or value[2])
		local r = tonumber(value.r or value.roll or value[3])
		if p and y then return Angle(p, y, r or 0) end
	end
	return nil
end

local function averagePlayerPosition()
	local total, count = vector_origin, 0
	for _, ply in ipairs(player.GetHumans()) do
		if IsValid(ply) and ply:Alive() then
			total = total + ply:GetPos()
			count = count + 1
		end
	end
	return count > 0 and total / count or nil
end

local function raidLVSBase(active)
	local record = (gd.RaidLVSFighterAnchors or {})[game.GetMap()]
	if istable(record) then
		local pos = vectorFromRecord(record.pos or record)
		local ang = angleFromRecord(record.ang)
		if isvector(pos) then
			return pos, ang or Angle(0, tonumber(active.sideYaw) or 0, 0)
		end
	end

	local group = naval.SquadronDefaultHangarGroup or "main"
	local path = N.HangarPath and N.HangarPath(group, "launch") or {}
	if #path >= 2 then
		local direction = path[#path] - path[#path - 1]
		if direction:LengthSqr() > 1 then
			direction:Normalize()
			local base = path[#path]
				+ direction * math.max(1000,
					tonumber(gd.RaidLVSVultureSpawnDistance) or 3400)
				+ Vector(0, 0,
					math.max(250, tonumber(gd.RaidLVSVultureSpawnAltitude) or 850))
			return base, (-direction):Angle()
		end
	end

	local playerCenter = averagePlayerPosition()
	if not isvector(playerCenter) then return nil, nil end
	local outward = Angle(0, tonumber(active.sideYaw) or math.Rand(0, 360), 0):Forward()
	local base = playerCenter
		+ outward * math.max(1000, tonumber(gd.RaidLVSVultureSpawnDistance) or 3400)
		+ Vector(0, 0,
			math.max(250, tonumber(gd.RaidLVSVultureSpawnAltitude) or 850))
	return base, (-outward):Angle()
end

local function clearLVSPosition(base, ang, index)
	local spacing = math.max(180, tonumber(gd.RaidLVSVultureSpawnSpacing) or 520)
	local attempts = math.max(3, math.floor(tonumber(gd.RaidLVSVultureSpawnAttempts) or 12))
	local right = ang:Right()
	local forward = ang:Forward()
	for attempt = 1, attempts do
		local column = math.ceil(index * 0.5)
		local side = index % 2 == 0 and 1 or -1
		local candidate = base + right * side * column * spacing
			+ Vector(0, 0, ((index - 1) % 3) * 150)
			- forward * (attempt - 1) * 180
			+ right * math.Rand(-90, 90)
		if util.IsInWorld(candidate) then
			local trace = util.TraceHull({
				start = candidate,
				endpos = candidate,
				mins = Vector(-130, -130, -60),
				maxs = Vector(130, 130, 90),
				mask = MASK_SOLID,
			})
			if not trace.StartSolid and not trace.Hit then return candidate end
		end
	end
	return nil
end

local function raidLVSVultureCount()
	local minimum = math.max(1, math.floor(tonumber(gd.RaidLVSVultureMinimum) or 2))
	local maximum = math.max(minimum,
		math.floor(tonumber(gd.RaidLVSVultureMaximum) or 8))
	local perExtra = math.max(1,
		math.floor(tonumber(gd.RaidLVSVulturePlayersPerExtra) or 4))
	return math.Clamp(minimum
		+ math.floor(math.max(0, G.ActivePlayerCount() - 1) / perExtra),
		minimum, maximum)
end

function G.SpawnRaidLVSVultures(active)
	if gd.RaidLVSVultureEnabled == false
	or G.Active ~= active or not active or active.kind ~= "cis_raid" then return 0 end
	local class = string.Trim(tostring(gd.RaidLVSVultureClass
		or "lvs_starfighter_vulturedroid"))
	if class == "" or not scripted_ents.GetStored(class) then
		if not active.mb_lvsVultureMissingWarned then
			active.mb_lvsVultureMissingWarned = true
			announce("Playable-map Vulture wave skipped because LVS class "
				.. string.upper(class ~= "" and class or "UNKNOWN") .. " is not mounted.",
				Color(235, 175, 70))
		end
		return 0
	end

	local base, ang = raidLVSBase(active)
	if not isvector(base) or not isangle(ang) then
		announce("Playable-map Vulture wave could not find a safe raid airspace anchor. "
			.. "Record a MAIN hangar launch route or configure RaidLVSFighterAnchors.",
			Color(235, 175, 70))
		return 0
	end

	active.lvsVultures = active.lvsVultures or {}
	local count = raidLVSVultureCount()
	local stagger = math.max(0, tonumber(gd.RaidLVSVultureSpawnStagger) or 0.55)
	local scheduled = 0

	for index = 1, count do
		local pos = clearLVSPosition(base, ang, index)
		if isvector(pos) then
			local spawnPos = Vector(pos)
			scheduled = scheduled + 1
			local spawnIndex = scheduled
			timer.Simple((spawnIndex - 1) * stagger, function()
				if G.Active ~= active or active.kind ~= "cis_raid"
				or active.phase == "retreat" then return end
				local ent = ents.Create(class)
				if not IsValid(ent) then return end
				ent:SetPos(spawnPos)
				ent:SetAngles(ang)
				ent:Spawn()
				ent:Activate()
				ent.mb_galaxyRaidLVS = active.id
				ent.mb_npcteam = "enemy"
				ent:SetNWString("mb_team", "enemy")
				ent:SetNW2Bool("MBGalaxyRaidLVSVulture", true)
				if ent.SetAITEAM then ent:SetAITEAM(3) end
				if ent.SetAI then ent:SetAI(true) end
				if ent.SetEngineActive then ent:SetEngineActive(true) end
				local physics = ent:GetPhysicsObject()
				if IsValid(physics) then physics:Wake() end
				active.entities = active.entities or {}
				active.entities[#active.entities + 1] = ent
				active.lvsVultures[#active.lvsVultures + 1] = ent
			end)
		end
	end

	if scheduled > 0 then
		announce(scheduled .. " LVS Vulture Droid"
			.. (scheduled == 1 and " is" or "s are")
			.. " entering playable airspace. Republic pilots scramble to intercept.",
			Color(235, 80, 65))
	end
	return scheduled
end

local automaticDogfightOrders = {
	cap = true,
	patrol = true,
	close_escort = true,
	escort = true,
	defend = true,
	screen = true,
	intercept = true,
	boarding_cover = true,
}

local function activeVultures(active)
	local result = {}
	for _, ship in ipairs(active and active.vultures or {}) do
		if IsValid(ship) and not ship.mb_destroyed and ship:GetHull() > 0 then
			result[#result + 1] = ship
		end
	end
	return result
end

timer.Create("MilBase.Galaxy.RaidVultureDogfights", 1, 0, function()
	local active = G.Active
	if not active or active.kind ~= "cis_raid"
	or active.phase == "retreat" then return end
	local vultures = activeVultures(active)
	if #vultures == 0 then return end
	local republic = validRepublicVisuals()
	if #republic == 0 then return end

	for index, vulture in ipairs(vultures) do
		local target = republic[((index - 1) % #republic) + 1].ship
		if IsValid(target) and vulture.SetCombatTarget then
			vulture:SetCombatTarget(target,
				math.max(1, tonumber(gd.RaidVultureDamage) or 18),
				math.max(0.5, tonumber(gd.RaidVultureFireInterval) or 0.9))
			vulture:SetShipState("dogfighting Republic squadrons")
		end
	end

	local vultureVisuals = {}
	for _, vulture in ipairs(vultures) do
		vultureVisuals[#vultureVisuals + 1] = { ship = vulture }
	end

	for _, data in ipairs(republic) do
		local ship, squadron = data.ship, data.squadron
		local order = string.lower(tostring(squadron.order or "standby"))
		local roe = string.lower(tostring(squadron.roe or "confirmed_hostiles"))
		local current = ship.mb_combatTarget
		local shouldEngage = automaticDogfightOrders[order]
			and roe ~= "weapons_hold"
			and not ship.mb_galaxyPilotControlled
			and (not IsValid(current) or current.mb_galaxyRaidVulture
				or current:GetCapital())
		if shouldEngage then
			local target = nearestVisual(ship:GetPos(), vultureVisuals)
			target = target and target.ship or nil
			if IsValid(target) and ship.SetCombatTarget then
				ship:SetCombatTarget(target, 24, 0.72)
				ship:SetShipState("dogfighting Vulture Droids")
			end
		end
	end
end)

if G.OnShipDestroyed and not G.mb_raidVultureDestroyedWrapped then
	G.mb_raidVultureDestroyedWrapped = true
	local baseOnShipDestroyed = G.OnShipDestroyed
	G.OnShipDestroyed = function(ship, attacker)
		local active = G.Active
		if active and active.kind == "cis_raid"
		and IsValid(ship) and ship.mb_galaxyRaidVulture then
			active.vulturesDestroyed = (tonumber(active.vulturesDestroyed) or 0) + 1
			if G.BroadcastState then G.BroadcastState() end
		end
		return baseOnShipDestroyed(ship, attacker)
	end
end
