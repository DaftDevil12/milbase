--[[
	Persistent faction creator/editor for the F2 staff menu.

	Config factions remain the file-backed defaults. Saving one from this menu
	creates a database override; RESET TO FILE removes that override. New faction
	ids are stored entirely in the database and can be deleted only while no
	characters are assigned to them.
]]

local cfg = MilBase.Config
local EDIT_LEVEL = tonumber(cfg.FactionEditorLevel) or 4
local NET_REQUEST = "MilBase_FactionEditorRequest"
local NET_SYNC = "MilBase_FactionEditorSync"
local NET_ACTION = "MilBase_FactionEditorAction"
local MAX_WIRE_BYTES = 60 * 1024 -- GMod net messages cap out at roughly 64 KiB
local MAX_RAW_BYTES = 512 * 1024

local function trim(value)
	return string.Trim(tostring(value or ""))
end

local function copyColor(value)
	value = value or {}
	return {
		r = math.Clamp(math.floor(tonumber(value.r or value[1]) or 255), 0, 255),
		g = math.Clamp(math.floor(tonumber(value.g or value[2]) or 255), 0, 255),
		b = math.Clamp(math.floor(tonumber(value.b or value[3]) or 255), 0, 255),
		a = math.Clamp(math.floor(tonumber(value.a or value[4]) or 255), 0, 255),
	}
end

local function copyStringList(source)
	local out = {}
	if not istable(source) then return out end
	for _, value in ipairs(source) do
		value = trim(value)
		if value ~= "" then out[#out + 1] = value end
	end
	return out
end

local function copyIssue(source)
	local out = {}
	if not istable(source) then return out end
	for id, amount in pairs(source) do
		-- Some old configs accidentally used an array of item ids. Preserve the
		-- intent by treating each string value as one unit of that item.
		if isnumber(id) and isstring(amount) then
			id, amount = amount, 1
		end
		id = trim(id)
		amount = math.floor(tonumber(amount) or 0)
		if id ~= "" and amount > 0 then out[id] = amount end
	end
	return out
end

local function editableRank(rank)
	rank = rank or {}
	local out = {
		name = trim(rank.name),
		salary = math.floor(tonumber(rank.salary) or 0),
		canPromote = rank.canPromote == true,
		medic = rank.medic == true,
		highCommand = rank.highCommand == true,
		pilot = rank.pilot == true,
		loadout = copyStringList(rank.loadout),
		models = copyStringList(rank.models),
		issue = copyIssue(rank.issue),
		attachments = MilBase.CopyCountMap(rank.attachments, 1000),
	}

	for _, key in ipairs({ "abbrev", "short", "quartermasterGroup", "spawnGroup", "vehicleReqGroup" }) do
		local value = trim(rank[key])
		if value ~= "" then out[key] = value end
	end
	for _, key in ipairs({ "jediLevel", "level" }) do
		local value = tonumber(rank[key])
		if value then out[key] = math.floor(value) end
	end
	if rank.color then out.color = copyColor(rank.color) end
	return out
end

function MilBase.FactionToEditable(faction)
	if not istable(faction) then return nil end
	local out = {
		id = trim(faction.id),
		name = trim(faction.name),
		description = tostring(faction.description or ""),
		logo = trim(faction.logo),
		color = copyColor(faction.color),
		models = copyStringList(faction.models),
		loadout = copyStringList(faction.loadout),
		issue = copyIssue(faction.issue),
		attachments = MilBase.CopyCountMap(faction.attachments, 1000),
		medic = faction.medic == true,
		police = faction.police == true,
		jedi = faction.jedi == true,
		forceSensitive = faction.forceSensitive == true,
		ranks = {},
	}
	for _, rank in ipairs(faction.ranks or {}) do
		out.ranks[#out.ranks + 1] = editableRank(rank)
	end
	return out
end

-- Capture file-backed definitions before database overrides are loaded.
MilBase.FactionFileDefaults = MilBase.FactionFileDefaults or {}
if not MilBase._FactionFileDefaultsCaptured then
	for _, id in ipairs(MilBase.FactionOrder or {}) do
		local faction = MilBase.GetFaction(id)
		if faction then
			local fileDefinition = table.Copy(faction)
			fileDefinition.id = nil
			fileDefinition.teamIndex = nil
			MilBase.FactionFileDefaults[id] = fileDefinition
		end
	end
	MilBase._FactionFileDefaultsCaptured = true
end

local function cleanText(value, field, minLength, maxLength)
	value = trim(value)
	value = string.gsub(value, "[%z\1-\8\11\12\14-\31]", "")
	if #value < (minLength or 0) then return nil, field .. " is required." end
	if #value > maxLength then return nil, field .. " is too long (max " .. maxLength .. ")." end
	return value
end

local function validateStringList(source, field, maxItems, maxLength, requireOne)
	if not istable(source) then return nil, field .. " must be a list." end
	local out = {}
	for _, value in ipairs(source) do
		local cleaned, err = cleanText(value, field .. " entry", 1, maxLength)
		if not cleaned then return nil, err end
		out[#out + 1] = cleaned
		if #out > maxItems then return nil, field .. " has too many entries (max " .. maxItems .. ")." end
	end
	if requireOne and #out < 1 then return nil, field .. " needs at least one entry." end
	return out
end

local function validateIssue(source, field)
	if not istable(source) then return nil, field .. " must be an item/count table." end
	local out, count = {}, 0
	for id, amount in pairs(source) do
		local cleaned, err = cleanText(id, field .. " item id", 1, 96)
		if not cleaned then return nil, err end
		amount = math.floor(tonumber(amount) or 0)
		if amount < 1 or amount > 1000 then
			return nil, field .. " amount for " .. cleaned .. " must be between 1 and 1000."
		end
		out[cleaned] = amount
		count = count + 1
		if count > 64 then return nil, field .. " has too many entries (max 64)." end
	end
	return out
end

local function optionalText(value, field, maxLength)
	value = trim(value)
	if value == "" then return nil end
	return cleanText(value, field, 1, maxLength)
end

local function validateFaction(source)
	if not istable(source) then return nil, "Malformed faction data." end
	local out = { ranks = {} }

	local id, err = cleanText(source.id, "Faction id", 1, 32)
	if not id then return nil, err end
	if not string.match(id, "^[%w_%-]+$") then
		return nil, "Faction id may contain only letters, numbers, underscores and hyphens."
	end
	out.id = id

	out.name, err = cleanText(source.name, "Faction name", 1, 64)
	if not out.name then return nil, err end
	out.description, err = cleanText(source.description or "", "Description", 0, 1000)
	if not out.description then return nil, err end
	out.logo, err = optionalText(source.logo, "Logo path", 192)
	if err then return nil, err end
	out.color = copyColor(source.color)
	out.models, err = validateStringList(source.models or {}, "Faction models", 32, 192, true)
	if not out.models then return nil, err end
	out.loadout, err = validateStringList(source.loadout or {}, "Faction loadout", 64, 96, false)
	if not out.loadout then return nil, err end
	out.issue, err = validateIssue(source.issue or {}, "Faction issue")
	if not out.issue then return nil, err end
	out.attachments, err = validateIssue(source.attachments or {}, "Faction ArcCW attachments")
	if not out.attachments then return nil, err end
	out.medic = source.medic == true
	out.police = source.police == true
	out.jedi = source.jedi == true
	out.forceSensitive = source.forceSensitive == true

	if not istable(source.ranks) or #source.ranks < 1 then
		return nil, "A faction needs at least one rank."
	end
	if #source.ranks > 64 then return nil, "A faction can have at most 64 ranks." end

	local rankNames = {}
	for index, rank in ipairs(source.ranks) do
		if not istable(rank) then return nil, "Rank " .. index .. " is malformed." end
		local clean = {}
		clean.name, err = cleanText(rank.name, "Rank " .. index .. " name", 1, 64)
		if not clean.name then return nil, err end
		local rankKey = string.lower(clean.name)
		if rankNames[rankKey] then return nil, "Rank names must be unique." end
		rankNames[rankKey] = true
		clean.salary = math.Clamp(math.floor(tonumber(rank.salary) or 0), 0, 10000000)
		clean.canPromote = rank.canPromote == true
		clean.medic = rank.medic == true
		clean.highCommand = rank.highCommand == true
		clean.pilot = rank.pilot == true

		clean.models, err = validateStringList(rank.models or {}, "Rank " .. index .. " models", 32, 192, false)
		if not clean.models then return nil, err end
		if #clean.models < 1 then clean.models = nil end
		clean.loadout, err = validateStringList(rank.loadout or {}, "Rank " .. index .. " loadout", 64, 96, false)
		if not clean.loadout then return nil, err end
		if #clean.loadout < 1 then clean.loadout = nil end
		clean.issue, err = validateIssue(rank.issue or {}, "Rank " .. index .. " issue")
		if not clean.issue then return nil, err end
		if table.Count(clean.issue) < 1 then clean.issue = nil end
		clean.attachments, err = validateIssue(rank.attachments or {}, "Rank " .. index .. " ArcCW attachments")
		if not clean.attachments then return nil, err end
		if table.Count(clean.attachments) < 1 then clean.attachments = nil end

		for _, key in ipairs({ "abbrev", "short", "quartermasterGroup", "spawnGroup", "vehicleReqGroup" }) do
			local value, textErr = optionalText(rank[key], "Rank " .. index .. " " .. key, 64)
			if textErr then return nil, textErr end
			if value then clean[key] = value end
		end
		if rank.jediLevel ~= nil and trim(rank.jediLevel) ~= "" then
			clean.jediLevel = math.Clamp(math.floor(tonumber(rank.jediLevel) or 1), 1, 5)
		end
		if rank.level ~= nil and trim(rank.level) ~= "" then
			clean.level = math.Clamp(math.floor(tonumber(rank.level) or 0), 0, 100000)
		end
		if rank.color then clean.color = copyColor(rank.color) end
		out.ranks[#out.ranks + 1] = clean
	end

	return out
end

local function encodePayload(payload)
	local raw = util.TableToJSON(payload, false)
	if not raw then return nil end
	return util.Compress(raw)
end

local function decodePayload(blob)
	if not blob or #blob < 1 or #blob > MAX_WIRE_BYTES then return nil end
	local raw = util.Decompress(blob)
	if not raw or #raw > MAX_RAW_BYTES then return nil end
	return util.JSONToTable(raw)
end

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_SYNC)
	util.AddNetworkString(NET_ACTION)

	MilBase.FactionEditorOverrides = {}

	local FACTION_TABLE_SQL = [[CREATE TABLE IF NOT EXISTS frontier_factions (
		id VARCHAR(64) PRIMARY KEY,
		data TEXT NOT NULL,
		updated_by VARCHAR(32),
		updated_at INTEGER
	)]]

	local function canEdit(ply)
		return IsValid(ply) and (ply:IsListenServerHost() or ply:MBStaffLevel() >= EDIT_LEVEL)
	end

	local function snapshotPayload()
		local payload = { factions = {}, meta = {} }
		for _, id in ipairs(MilBase.FactionOrder or {}) do
			local faction = MilBase.GetFaction(id)
			if faction then
				payload.factions[#payload.factions + 1] = {
					id = id,
					teamIndex = faction.teamIndex,
					data = MilBase.FactionToEditable(faction),
				}
				payload.meta[id] = {
					custom = MilBase.FactionFileDefaults[id] == nil,
					overridden = MilBase.FactionEditorOverrides[id] == true,
				}
			end
		end
		return payload
	end

	function MilBase.SendFactionDefinitions(target)
		local blob = encodePayload(snapshotPayload())
		if not blob or #blob > MAX_WIRE_BYTES then
			MsgC(Color(255, 100, 90), "[MilBase Factions] Faction snapshot is too large to network.\n")
			return
		end
		net.Start(NET_SYNC)
			net.WriteUInt(#blob, 32)
			net.WriteData(blob, #blob)
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end

	local function buildRankMigration(previous, nextData)
		if not previous or not istable(previous.ranks) then return nil end
		local byName = {}
		for newIndex, rank in ipairs(nextData.ranks or {}) do
			local key = string.lower(trim(rank.name))
			if key ~= "" and not byName[key] then byName[key] = newIndex end
		end

		local migration = {}
		for oldIndex, rank in ipairs(previous.ranks) do
			local key = string.lower(trim(rank.name))
			migration[oldIndex] = byName[key]
				or math.Clamp(oldIndex, 1, math.max(1, #nextData.ranks))
		end
		return migration
	end

	local function migrateSavedRanks(id, migration, rankCount)
		if not migration then return end
		local cases = {}
		for oldIndex = 1, table.Count(migration) do
			if migration[oldIndex] then
				cases[#cases + 1] = "WHEN " .. oldIndex .. " THEN " .. migration[oldIndex]
			end
		end
		if #cases < 1 then return end
		rankCount = math.max(1, math.floor(tonumber(rankCount) or 1))
		local online = {}
		for _, ply in ipairs(player.GetAll()) do
			if ply:MBFactionID() == id then online[#online + 1] = MilBase.SQLStr(ply:MBCharacterKey()) end
		end
		local where = " WHERE faction = " .. MilBase.SQLStr(id)
		if #online > 0 then where = where .. " AND steamid NOT IN (" .. table.concat(online, ",") .. ")" end

		MilBase.DB.Run("UPDATE frontier_players SET `rank` = CASE `rank` "
			.. table.concat(cases, " ")
			.. " ELSE CASE WHEN `rank` < 1 THEN 1 WHEN `rank` > " .. rankCount
			.. " THEN " .. rankCount .. " ELSE `rank` END END" .. where)
	end

	local function refreshAssignedPlayers(id, faction, migration)
		for _, ply in ipairs(player.GetAll()) do
			if ply:MBFactionID() == id then
				local oldRank = ply:MBRankIndex()
				local rank = migration and migration[oldRank]
					or math.Clamp(oldRank, 1, #faction.ranks)
				ply:SetNWInt("mb_rank", rank)
				ply:SetTeam(faction.teamIndex)
				if MilBase.SavePlayer then MilBase.SavePlayer(ply) end

				if MilBase.QuartermasterReconcileGear and cfg.QuartermasterCleanupOnRoleChange ~= false
				and ply.mb_inv then
					MilBase.QuartermasterReconcileGear(ply, false)
				end
				if MilBase.QuartermasterUpdateArmorObjective then
					MilBase.QuartermasterUpdateArmorObjective(ply, "faction_editor")
				end
				if MilBase.SpawnSelectorValidateChoice then
					MilBase.SpawnSelectorValidateChoice(ply, false)
				end
				if MilBase.LSCS and isfunction(MilBase.LSCS.ScheduleBootstrap) then
					MilBase.LSCS.ScheduleBootstrap(ply, true)
				end
				if MilBase.RefreshArcCWEntitlements then MilBase.RefreshArcCWEntitlements(ply) end

				MilBase.Notify(ply, faction.name .. " was updated. Model and loadout changes apply on your next spawn.", "warn")
			end
		end
	end

	local function persistFaction(data, actor)
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_factions (id, data, updated_by, updated_at) VALUES (%s, %s, %s, %d)",
			MilBase.SQLStr(data.id),
			MilBase.SQLStr(util.TableToJSON(data, false) or "{}"),
			MilBase.SQLStr(IsValid(actor) and actor:SteamID64() or "console"),
			os.time()
		))
	end

	local function applySavedFaction(data, actor, loading)
		local previous = MilBase.GetFaction(data.id)
		local migration = buildRankMigration(previous, data)
		local faction = MilBase.ApplyFaction(data.id, data)
		MilBase.FactionEditorOverrides[data.id] = true
		if not loading then
			persistFaction(data, actor)
			migrateSavedRanks(data.id, migration, #faction.ranks)
			refreshAssignedPlayers(data.id, faction, migration)
			MilBase.SendFactionDefinitions()
			MilBase.Notify(actor, "Saved faction " .. faction.name .. " (" .. data.id .. ").", "ok")
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(actor) .. " saved faction " .. data.id, actor)
			end
		end
		return faction
	end

	local function resetStaticFaction(id, actor)
		local base = MilBase.FactionFileDefaults[id]
		if not base then return false, "That faction has no file-backed default." end
		MilBase.DB.Run("DELETE FROM frontier_factions WHERE id = " .. MilBase.SQLStr(id))
		MilBase.FactionEditorOverrides[id] = nil
		local previous = MilBase.GetFaction(id)
		local migration = buildRankMigration(previous, base)
		local faction = MilBase.ApplyFaction(id, table.Copy(base))
		migrateSavedRanks(id, migration, #faction.ranks)
		refreshAssignedPlayers(id, faction, migration)
		MilBase.SendFactionDefinitions()
		MilBase.Notify(actor, "Reset " .. faction.name .. " to config/sh_factions.lua.", "ok")
		if MilBase.Log then
			MilBase.Log("staff", MilBase.LogTag(actor) .. " reset faction " .. id .. " to file defaults", actor)
		end
		return true
	end

	local function deleteCustomFaction(id, actor)
		if MilBase.FactionFileDefaults[id] then return resetStaticFaction(id, actor) end
		if id == cfg.DefaultFaction then return false, "The default faction cannot be deleted." end
		if not MilBase.GetFaction(id) then return false, "Unknown faction." end
		for certID, cert in pairs(MilBase.Certs or {}) do
			if istable(cert.factions) and cert.factions[id] then
				return false, "Cannot delete this faction while certification " .. certID .. " is locked to it."
			end
		end
		for _, target in ipairs(player.GetAll()) do
			if target:MBFactionID() == id then
				return false, "Cannot delete this faction while an online player is assigned to it."
			end
		end

		MilBase.DB.Query("SELECT steamid FROM frontier_players WHERE faction = "
			.. MilBase.SQLStr(id) .. " LIMIT 1", function(rows)
			if not IsValid(actor) then return end
			if rows and rows[1] then
				MilBase.Notify(actor, "Cannot delete this faction while characters are assigned to it.", "danger")
				return
			end
			MilBase.DB.Run("DELETE FROM frontier_factions WHERE id = " .. MilBase.SQLStr(id))
			MilBase.FactionEditorOverrides[id] = nil
			MilBase.RemoveFaction(id)
			MilBase.SendFactionDefinitions()
			MilBase.Notify(actor, "Deleted custom faction " .. id .. ".", "ok")
			if MilBase.Log then
				MilBase.Log("staff", MilBase.LogTag(actor) .. " deleted faction " .. id, actor)
			end
		end)
		return true
	end

	local function loadOverrides()
		MilBase.DB.Query("SELECT id, data FROM frontier_factions", function(rows)
			table.sort(rows, function(a, b) return tostring(a.id) < tostring(b.id) end)
			for _, row in ipairs(rows) do
				local decoded = util.JSONToTable(row.data or "")
				if istable(decoded) then decoded.id = row.id end
				local data, err = validateFaction(decoded)
				if data then
					applySavedFaction(data, nil, true)
				else
					MsgC(Color(255, 100, 90), "[MilBase Factions] Ignoring invalid saved faction ",
						color_white, tostring(row.id), ": ", tostring(err), "\n")
				end
			end
			MilBase.FactionEditorReady = true
			MilBase.SendFactionDefinitions()
		end)
	end
	MilBase.DB.Query(FACTION_TABLE_SQL, loadOverrides, function(err)
		MsgC(Color(255, 100, 90), "[MilBase Factions] Could not create faction table: ",
			color_white, tostring(err), "\n")
	end)

	net.Receive(NET_REQUEST, function(_, ply)
		if (ply.mb_nextFactionRequest or 0) > CurTime() then return end
		ply.mb_nextFactionRequest = CurTime() + 1
		MilBase.SendFactionDefinitions(ply)
	end)

	net.Receive(NET_ACTION, function(_, ply)
		if not canEdit(ply) then return end
		if (ply.mb_nextFactionEdit or 0) > CurTime() then return end
		ply.mb_nextFactionEdit = CurTime() + 0.5

		local size = net.ReadUInt(32)
		if size < 1 or size > MAX_WIRE_BYTES then return end
		local payload = decodePayload(net.ReadData(size))
		if not istable(payload) then return end

		local action = trim(payload.action)
		if action == "save" then
			local originalID = trim(payload.original_id)
			local data, err = validateFaction(payload.faction)
			if not data then MilBase.Notify(ply, err or "Invalid faction.", "danger") return end
			if originalID ~= "" and originalID ~= data.id then
				MilBase.Notify(ply, "Faction ids cannot be renamed. Create a new faction instead.", "danger")
				return
			end
			if originalID == "" and MilBase.GetFaction(data.id) then
				MilBase.Notify(ply, "That faction id already exists.", "danger")
				return
			end
			applySavedFaction(data, ply, false)
		elseif action == "delete" then
			local id = trim(payload.id)
			local ok, err = deleteCustomFaction(id, ply)
			if ok == false then MilBase.Notify(ply, err or "Could not delete faction.", "danger") end
		end
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.SyncFactionDefinitions", function(ply)
		timer.Simple(2, function()
			if IsValid(ply) then MilBase.SendFactionDefinitions(ply) end
		end)
	end)

	return
end

--------------------------------------------------------------------------
-- Client synchronization
--------------------------------------------------------------------------

MilBase.FactionEditorMeta = MilBase.FactionEditorMeta or {}
MilBase.ServerSyncedFactionIDs = MilBase.ServerSyncedFactionIDs or {}

function MilBase.RequestFactionDefinitions()
	if not IsValid(LocalPlayer()) then return end
	net.Start(NET_REQUEST)
	net.SendToServer()
end

net.Receive(NET_SYNC, function()
	local size = net.ReadUInt(32)
	if size < 1 or size > MAX_WIRE_BYTES then return end
	local payload = decodePayload(net.ReadData(size))
	if not istable(payload) or not istable(payload.factions) then return end

	local incoming = {}
	for _, row in ipairs(payload.factions) do
		if istable(row) and isstring(row.id) and istable(row.data) then incoming[row.id] = true end
	end
	for id in pairs(MilBase.ServerSyncedFactionIDs) do
		if not incoming[id] and not MilBase.FactionFileDefaults[id] then MilBase.RemoveFaction(id) end
	end

	MilBase.FactionOrder = {}
	for _, row in ipairs(payload.factions) do
		if istable(row) and isstring(row.id) and istable(row.data) then
			MilBase.ApplyFaction(row.id, row.data, tonumber(row.teamIndex))
		end
	end
	MilBase.ServerSyncedFactionIDs = incoming
	MilBase.FactionEditorMeta = istable(payload.meta) and payload.meta or {}
	hook.Run("MilBaseFactionDefinitionsUpdated")
end)

hook.Add("InitPostEntity", "MilBase.RequestFactionDefinitions", function()
	timer.Simple(1, MilBase.RequestFactionDefinitions)
end)

hook.Add("OnReloaded", "MilBase.RequestFactionDefinitionsReload", function()
	timer.Simple(0.5, MilBase.RequestFactionDefinitions)
end)

--------------------------------------------------------------------------
-- Client staff menu
--------------------------------------------------------------------------

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["FACTIONS"] = true

local function sendAction(payload)
	local blob = encodePayload(payload)
	if not blob then return end
	if #blob > MAX_WIRE_BYTES then
		MilBase.Notify(LocalPlayer(), "That faction definition is too large to send.", "danger")
		return
	end
	net.Start(NET_ACTION)
		net.WriteUInt(#blob, 32)
		net.WriteData(blob, #blob)
	net.SendToServer()
end

local function listToText(list)
	return table.concat(copyStringList(list), "\n")
end

local function textToList(text)
	local out, seen = {}, {}
	text = string.gsub(tostring(text or ""), ",", "\n")
	for line in string.gmatch(text .. "\n", "([^\n]*)\n") do
		line = trim(line)
		if line ~= "" and not seen[line] then
			seen[line] = true
			out[#out + 1] = line
		end
	end
	return out
end

local function issueToText(issue)
	local rows = {}
	for id, amount in SortedPairs(copyIssue(issue)) do rows[#rows + 1] = id .. "=" .. amount end
	return table.concat(rows, "\n")
end

local function textToIssue(text)
	local out = {}
	text = string.gsub(tostring(text or ""), ",", "\n")
	for line in string.gmatch(text .. "\n", "([^\n]*)\n") do
		line = trim(line)
		if line ~= "" then
			local id, amount = string.match(line, "^([^=:%s]+)%s*[=:]%s*(%d+)$")
			if not id then id, amount = line, 1 end
			id = trim(id)
			if id ~= "" then out[id] = math.Clamp(math.floor(tonumber(amount) or 1), 1, 1000) end
		end
	end
	return out
end

local function paintEntry(self, w, h)
	local ui = MilBase.UI
	surface.SetDrawColor(0, 0, 0, 155)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(self:HasFocus() and ui.accent or ui.outline)
	surface.DrawOutlinedRect(0, 0, w, h)
	self:DrawTextEntryText(ui.text, ui.accent, ui.text)
end

local function actionButton(parent, label, accent, callback)
	local button = vgui.Create("DButton", parent)
	button:SetText("")
	button.mbLabel = label
	button.Paint = function(self, w, h)
		local ui = MilBase.UI
		local col = accent or ui.accent
		MilBase.DrawPanelBF2(0, 0, w, h, {
			cut = 6,
			color = self:IsEnabled() and (self:IsHovered() and Color(col.r, col.g, col.b, 55) or ui.raised)
				or Color(255, 255, 255, 3),
			accent = self:IsEnabled() and col or nil,
		})
		draw.SimpleText(self.mbLabel, "MB.Small", w / 2, h / 2,
			self:IsEnabled() and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = callback
	return button
end

local function labeledEntry(parent, label, value, multiline, height)
	local ui = MilBase.UI
	local wrap = vgui.Create("DPanel", parent)
	wrap:Dock(TOP)
	wrap:SetTall((height or 30) + 22)
	wrap:DockMargin(0, 0, 8, 7)
	wrap.Paint = function(_, w)
		draw.SimpleText(label, "MB.Tiny", 2, 8, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local entry = vgui.Create("DTextEntry", wrap)
	entry:Dock(FILL)
	entry:DockMargin(0, 20, 0, 0)
	entry:SetFont("MB.Small")
	entry:SetPaintBackground(false)
	entry:SetText(tostring(value or ""))
	entry:SetMultiline(multiline == true)
	entry.Paint = paintEntry
	return entry
end

local function checkbox(parent, label, checked)
	local box = vgui.Create("DCheckBoxLabel", parent)
	box:Dock(TOP)
	box:SetTall(24)
	box:DockMargin(2, 0, 8, 2)
	box:SetFont("MB.Small")
	box:SetTextColor(MilBase.UI.text)
	box:SetText(label)
	box:SetChecked(checked == true)
	return box
end

local function blankFaction(id)
	return {
		id = id,
		name = id,
		description = "",
		logo = "",
		color = { r = 120, g = 180, b = 240, a = 255 },
		models = { "models/player/group01/male_02.mdl" },
		loadout = {}, issue = {}, attachments = {}, medic = false, police = false,
		jedi = false, forceSensitive = false,
		ranks = { { name = "Recruit", salary = 0, loadout = {}, models = {}, issue = {}, attachments = {} } },
	}
end

MilBase.AddMenuTab("FACTIONS", 92.5, function(content)
	local ui = MilBase.UI
	local selectedID, originalID, draft, selectedRank = nil, nil, nil, 1
	local generalControls, rankControls = {}, {}
	local listScroll, generalScroll, rankList, rankEditor, deleteButton, saveButton
	local alive = true

	content.OnRemove = function() alive = false end

	local left = vgui.Create("DPanel", content)
	left:Dock(LEFT)
	left:SetWide(265)
	left:DockMargin(0, 0, 14, 0)
	left.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("FACTIONS", "MB.Tab", 14, 8, ui.text)
		draw.SimpleText("Database-backed definitions", "MB.Tiny", 14, 29, ui.dim)
	end

	local leftActions = vgui.Create("DPanel", left)
	leftActions:Dock(BOTTOM)
	leftActions:SetTall(44)
	leftActions:DockMargin(10, 4, 10, 10)
	leftActions.Paint = nil

	listScroll = vgui.Create("DScrollPanel", left)
	listScroll:Dock(FILL)
	listScroll:DockMargin(10, 48, 10, 4)

	local body = vgui.Create("DPanel", content)
	body:Dock(FILL)
	body.Paint = nil

	local toolbar = vgui.Create("DPanel", body)
	toolbar:Dock(TOP)
	toolbar:SetTall(42)
	toolbar:DockMargin(0, 0, 0, 10)
	toolbar.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 7, color = Color(0, 0, 0, 130), accent = ui.accent })
		draw.SimpleText(draft and (draft.name ~= "" and draft.name or draft.id) or "SELECT A FACTION",
			"MB.Med", 14, h / 2, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	saveButton = actionButton(toolbar, "SAVE", ui.ok, function() end)
	saveButton:Dock(RIGHT)
	saveButton:SetWide(105)
	saveButton:DockMargin(6, 6, 8, 6)

	deleteButton = actionButton(toolbar, "FILE DEFAULT", ui.danger, function() end)
	deleteButton:Dock(RIGHT)
	deleteButton:SetWide(145)
	deleteButton:DockMargin(6, 6, 0, 6)

	local generalPanel = vgui.Create("DPanel", body)
	generalPanel:Dock(LEFT)
	generalPanel:SetWide(math.Clamp(math.floor((ScrW() - 265) * 0.43), 360, 560))
	generalPanel:DockMargin(0, 0, 14, 0)
	generalPanel.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("FACTION DETAILS", "MB.Tab", 14, 8, ui.text)
	end

	generalScroll = vgui.Create("DScrollPanel", generalPanel)
	generalScroll:Dock(FILL)
	generalScroll:DockMargin(12, 42, 4, 10)

	local ranksPanel = vgui.Create("DPanel", body)
	ranksPanel:Dock(FILL)
	ranksPanel.Paint = function(_, w, h)
		MilBase.PaintPanel(w, h)
		draw.SimpleText("RANK STRUCTURE", "MB.Tab", 14, 8, ui.text)
	end

	local rankButtons = vgui.Create("DPanel", ranksPanel)
	rankButtons:Dock(TOP)
	rankButtons:SetTall(34)
	rankButtons:DockMargin(12, 40, 12, 5)
	rankButtons.Paint = nil

	rankList = vgui.Create("DScrollPanel", ranksPanel)
	rankList:Dock(TOP)
	rankList:SetTall(190)
	rankList:DockMargin(12, 0, 6, 8)

	rankEditor = vgui.Create("DScrollPanel", ranksPanel)
	rankEditor:Dock(FILL)
	rankEditor:DockMargin(12, 0, 6, 10)

	local function commitGeneral()
		if not draft or not generalControls.name then return end
		draft.name = trim(generalControls.name:GetValue())
		draft.description = generalControls.description:GetValue()
		draft.logo = trim(generalControls.logo:GetValue())
		local c = generalControls.color:GetColor()
		draft.color = copyColor(c)
		draft.models = textToList(generalControls.models:GetValue())
		draft.loadout = textToList(generalControls.loadout:GetValue())
		draft.issue = textToIssue(generalControls.issue:GetValue())
		draft.attachments = textToIssue(generalControls.attachments:GetValue())
		draft.medic = generalControls.medic:GetChecked()
		draft.police = generalControls.police:GetChecked()
		draft.jedi = generalControls.jedi:GetChecked()
		draft.forceSensitive = generalControls.forceSensitive:GetChecked()
	end

	local function commitRank()
		if not draft or not rankControls.name or not draft.ranks[selectedRank] then return end
		local rank = draft.ranks[selectedRank]
		rank.name = trim(rankControls.name:GetValue())
		rank.salary = math.floor(tonumber(rankControls.salary:GetValue()) or 0)
		rank.abbrev = trim(rankControls.abbrev:GetValue())
		rank.short = trim(rankControls.short:GetValue())
		rank.quartermasterGroup = trim(rankControls.quartermasterGroup:GetValue())
		rank.spawnGroup = trim(rankControls.spawnGroup:GetValue())
		rank.vehicleReqGroup = trim(rankControls.vehicleReqGroup:GetValue())
		local jediLevel = trim(rankControls.jediLevel:GetValue())
		rank.jediLevel = jediLevel ~= "" and tonumber(jediLevel) or nil
		rank.canPromote = rankControls.canPromote:GetChecked()
		rank.medic = rankControls.medic:GetChecked()
		rank.highCommand = rankControls.highCommand:GetChecked()
		rank.pilot = rankControls.pilot:GetChecked()
		rank.models = textToList(rankControls.models:GetValue())
		rank.loadout = textToList(rankControls.loadout:GetValue())
		rank.issue = textToIssue(rankControls.issue:GetValue())
		rank.attachments = textToIssue(rankControls.attachments:GetValue())
	end

	local rebuildRankList, rebuildRankEditor, rebuildGeneral, rebuildFactionList

	rebuildRankEditor = function()
		rankEditor:Clear()
		rankControls = {}
		if not draft or not draft.ranks[selectedRank] then return end
		local rank = draft.ranks[selectedRank]
		rankControls.name = labeledEntry(rankEditor, "RANK NAME", rank.name, false, 30)
		rankControls.salary = labeledEntry(rankEditor, "SALARY", rank.salary or 0, false, 30)
		rankControls.abbrev = labeledEntry(rankEditor, "ABBREVIATION (optional)", rank.abbrev or "", false, 30)
		rankControls.short = labeledEntry(rankEditor, "SHORT NAME (optional)", rank.short or "", false, 30)
		rankControls.quartermasterGroup = labeledEntry(rankEditor, "QUARTERMASTER GROUP (optional)", rank.quartermasterGroup or "", false, 30)
		rankControls.spawnGroup = labeledEntry(rankEditor, "SPAWN GROUP (optional)", rank.spawnGroup or "", false, 30)
		rankControls.vehicleReqGroup = labeledEntry(rankEditor, "VEHICLE REQUISITION GROUP (optional)", rank.vehicleReqGroup or "", false, 30)
		rankControls.jediLevel = labeledEntry(rankEditor, "JEDI LEVEL 1-5 (optional)", rank.jediLevel or "", false, 30)
		rankControls.canPromote = checkbox(rankEditor, "Can promote / assign", rank.canPromote)
		rankControls.medic = checkbox(rankEditor, "Medic capability", rank.medic)
		rankControls.highCommand = checkbox(rankEditor, "High Command", rank.highCommand)
		rankControls.pilot = checkbox(rankEditor, "Pilot", rank.pilot)
		rankControls.models = labeledEntry(rankEditor, "RANK MODEL OVERRIDES — one per line", listToText(rank.models), true, 76)
		rankControls.loadout = labeledEntry(rankEditor, "EXTRA WEAPON CLASSES — one per line", listToText(rank.loadout), true, 76)
		rankControls.issue = labeledEntry(rankEditor, "EXTRA ISSUE — item_id=amount", issueToText(rank.issue), true, 76)
		rankControls.attachments = labeledEntry(rankEditor, "ARCCW ATTACHMENTS — attachment_id=amount", issueToText(rank.attachments), true, 76)
	end

	rebuildRankList = function()
		rankList:Clear()
		if not draft then return end
		for i, rank in ipairs(draft.ranks) do
			local index = i
			local row = vgui.Create("DButton", rankList)
			row:Dock(TOP)
			row:SetTall(30)
			row:DockMargin(0, 0, 6, 4)
			row:SetText("")
			row.Paint = function(self, w, h)
				local active = selectedRank == index
				MilBase.DrawPanelBF2(0, 0, w, h, {
					cut = 5,
					color = active and Color(ui.accent.r, ui.accent.g, ui.accent.b, 36)
						or (self:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
					accent = active and ui.accent or nil,
				})
				draw.SimpleText(index, "MB.Tiny", 9, h / 2, ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(rank.name ~= "" and rank.name or "Unnamed rank", "MB.Small", 32, h / 2,
					ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText((rank.canPromote and "★ " or "") .. (rank.salary or 0), "MB.Tiny", w - 10, h / 2,
					ui.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			row.DoClick = function()
				commitRank()
				selectedRank = index
				rebuildRankList()
				rebuildRankEditor()
			end
		end
	end

	rebuildGeneral = function()
		generalScroll:Clear()
		generalControls = {}
		if not draft then return end

		generalControls.id = labeledEntry(generalScroll, "FACTION ID — immutable after creation", draft.id, false, 30)
		generalControls.id:SetEditable(false)
		generalControls.name = labeledEntry(generalScroll, "DISPLAY NAME", draft.name, false, 30)
		generalControls.description = labeledEntry(generalScroll, "DESCRIPTION", draft.description, true, 84)
		generalControls.logo = labeledEntry(generalScroll, "LOGO MATERIAL PATH (optional)", draft.logo, false, 30)

		local colorWrap = vgui.Create("DPanel", generalScroll)
		colorWrap:Dock(TOP)
		colorWrap:SetTall(150)
		colorWrap:DockMargin(0, 0, 8, 7)
		colorWrap.Paint = function(_, w)
			draw.SimpleText("FACTION COLOR", "MB.Tiny", 2, 8, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		generalControls.color = vgui.Create("DColorMixer", colorWrap)
		generalControls.color:Dock(FILL)
		generalControls.color:DockMargin(0, 20, 0, 0)
		generalControls.color:SetPalette(false)
		generalControls.color:SetAlphaBar(false)
		generalControls.color:SetWangs(true)
		generalControls.color:SetColor(Color(draft.color.r, draft.color.g, draft.color.b))

		generalControls.medic = checkbox(generalScroll, "All faction members are medics", draft.medic)
		generalControls.police = checkbox(generalScroll, "Police / security capability", draft.police)
		generalControls.jedi = checkbox(generalScroll, "Jedi faction — enables LSCS access", draft.jedi)
		generalControls.forceSensitive = checkbox(generalScroll, "Force-sensitive faction", draft.forceSensitive)
		generalControls.models = labeledEntry(generalScroll, "PLAYER MODELS — one per line", listToText(draft.models), true, 92)
		generalControls.loadout = labeledEntry(generalScroll, "WEAPON CLASSES — one per line", listToText(draft.loadout), true, 92)
		generalControls.issue = labeledEntry(generalScroll, "STANDARD ISSUE — item_id=amount", issueToText(draft.issue), true, 92)
		generalControls.attachments = labeledEntry(generalScroll, "ARCCW ATTACHMENTS — attachment_id=amount", issueToText(draft.attachments), true, 92)
	end

	local function updateDeleteButton()
		local meta = selectedID and MilBase.FactionEditorMeta[selectedID] or nil
		if not selectedID or not meta then
			deleteButton.mbLabel = "FILE DEFAULT"
			deleteButton:SetEnabled(false)
		elseif meta.custom then
			deleteButton.mbLabel = "DELETE"
			deleteButton:SetEnabled(true)
		elseif meta.overridden then
			deleteButton.mbLabel = "RESET TO FILE"
			deleteButton:SetEnabled(true)
		else
			deleteButton.mbLabel = "FILE DEFAULT"
			deleteButton:SetEnabled(false)
		end
	end

	local function selectFaction(id)
		commitGeneral()
		commitRank()
		local faction = MilBase.GetFaction(id)
		if not faction then return end
		selectedID, originalID = id, id
		draft = MilBase.FactionToEditable(faction)
		selectedRank = 1
		rebuildGeneral()
		rebuildRankList()
		rebuildRankEditor()
		rebuildFactionList()
		updateDeleteButton()
	end

	rebuildFactionList = function()
		listScroll:Clear()
		for _, id in ipairs(MilBase.FactionOrder or {}) do
			local faction = MilBase.GetFaction(id)
			if faction then
				local factionID = id
				local row = vgui.Create("DButton", listScroll)
				row:Dock(TOP)
				row:SetTall(52)
				row:DockMargin(0, 0, 4, 5)
				row:SetText("")
				row.Paint = function(self, w, h)
					local active = selectedID == factionID
					MilBase.DrawPanelBF2(0, 0, w, h, {
						cut = 6,
						color = active and Color(faction.color.r, faction.color.g, faction.color.b, 35)
							or (self:IsHovered() and ui.hover or Color(255, 255, 255, 4)),
						accent = faction.color,
					})
					draw.SimpleText(faction.name, "MB.Small", 12, 8, ui.text)
					local meta = MilBase.FactionEditorMeta[factionID] or {}
					local state = meta.custom and "CUSTOM" or (meta.overridden and "OVERRIDE" or "FILE")
					draw.SimpleText(factionID .. "  •  " .. #faction.ranks .. " ranks  •  " .. state,
						"MB.Tiny", 12, 29, ui.dim)
				end
				row.DoClick = function() selectFaction(factionID) end
			end
		end
	end

	local addRank = actionButton(rankButtons, "+ RANK", ui.ok, function()
		if not draft then return end
		commitRank()
		draft.ranks[#draft.ranks + 1] = { name = "New Rank", salary = 0, models = {}, loadout = {}, issue = {}, attachments = {} }
		selectedRank = #draft.ranks
		rebuildRankList()
		rebuildRankEditor()
	end)
	addRank:Dock(LEFT); addRank:SetWide(85); addRank:DockMargin(0, 0, 6, 0)

	local removeRank = actionButton(rankButtons, "REMOVE", ui.danger, function()
		if not draft or #draft.ranks <= 1 then
			MilBase.Notify(LocalPlayer(), "A faction needs at least one rank.", "danger")
			return
		end
		commitRank()
		table.remove(draft.ranks, selectedRank)
		selectedRank = math.Clamp(selectedRank, 1, #draft.ranks)
		rebuildRankList(); rebuildRankEditor()
	end)
	removeRank:Dock(LEFT); removeRank:SetWide(90); removeRank:DockMargin(0, 0, 6, 0)

	local upRank = actionButton(rankButtons, "▲", ui.accent, function()
		if not draft or selectedRank <= 1 then return end
		commitRank()
		draft.ranks[selectedRank], draft.ranks[selectedRank - 1] = draft.ranks[selectedRank - 1], draft.ranks[selectedRank]
		selectedRank = selectedRank - 1
		rebuildRankList(); rebuildRankEditor()
	end)
	upRank:Dock(LEFT); upRank:SetWide(42); upRank:DockMargin(0, 0, 6, 0)

	local downRank = actionButton(rankButtons, "▼", ui.accent, function()
		if not draft or selectedRank >= #draft.ranks then return end
		commitRank()
		draft.ranks[selectedRank], draft.ranks[selectedRank + 1] = draft.ranks[selectedRank + 1], draft.ranks[selectedRank]
		selectedRank = selectedRank + 1
		rebuildRankList(); rebuildRankEditor()
	end)
	downRank:Dock(LEFT); downRank:SetWide(42)

	local newButton = actionButton(leftActions, "+ NEW FACTION", ui.ok, function()
		Derma_StringRequest("Create faction", "Enter a permanent faction id (letters, numbers, _ or -):", "new_faction",
			function(value)
				value = trim(value)
				if not string.match(value, "^[%w_%-]+$") or #value > 32 then
					MilBase.Notify(LocalPlayer(), "Invalid faction id.", "danger")
					return
				end
				if MilBase.GetFaction(value) then
					MilBase.Notify(LocalPlayer(), "That faction id already exists.", "danger")
					return
				end
				commitGeneral(); commitRank()
				selectedID, originalID = value, ""
				draft = blankFaction(value)
				selectedRank = 1
				rebuildGeneral(); rebuildRankList(); rebuildRankEditor(); rebuildFactionList(); updateDeleteButton()
			end)
	end)
	newButton:Dock(FILL)

	saveButton.DoClick = function()
		if not draft then return end
		commitGeneral(); commitRank()
		sendAction({ action = "save", original_id = originalID or "", faction = draft })
	end

	deleteButton.DoClick = function()
		if not selectedID then return end
		local meta = MilBase.FactionEditorMeta[selectedID] or {}
		local verb = meta.custom and "delete" or "reset"
		Derma_Query("Are you sure you want to " .. verb .. " faction '" .. selectedID .. "'?",
			"Confirm faction change", "CONFIRM", function()
				sendAction({ action = "delete", id = selectedID })
			end, "CANCEL")
	end

	local hookID = "MilBase.FactionEditorRefresh." .. tostring(content)
	hook.Add("MilBaseFactionDefinitionsUpdated", hookID, function()
		if not alive or not IsValid(content) then hook.Remove("MilBaseFactionDefinitionsUpdated", hookID) return end
		local keep = selectedID
		rebuildFactionList()
		if keep and MilBase.GetFaction(keep) then selectFaction(keep)
		elseif MilBase.FactionOrder[1] then selectFaction(MilBase.FactionOrder[1]) end
	end)
	content.OnRemove = function()
		alive = false
		hook.Remove("MilBaseFactionDefinitionsUpdated", hookID)
	end

	rebuildFactionList()
	if MilBase.FactionOrder[1] then selectFaction(MilBase.FactionOrder[1]) end
	updateDeleteButton()
	MilBase.RequestFactionDefinitions()
end, function(lp)
	return lp:IsListenServerHost() or lp:MBStaffLevel() >= EDIT_LEVEL
end)
