-- Shared definitions for Republic customs inspections and false-IFF cases.
if MilBase._SmugglingInspectionsSharedLoaded then return end
MilBase._SmugglingInspectionsSharedLoaded = true

MilBase.Inspections = MilBase.Inspections or {}
local I = MilBase.Inspections

I.StatusLabels = {
	monitoring = "MONITORING",
	held = "HELD FOR QUESTIONING",
	landing = "APPROACHING INSPECTION BAY",
	landed = "PHYSICAL INSPECTION",
	fleeing = "EVADING INSPECTION",
	disabled = "ENGINES DISABLED",
	cleared = "CLEARED",
	detained = "DETAINED",
	impounded = "IMPOUNDED",
	closed = "CASE CLOSED",
}

I.IFFQualityLabels = {
	poor = "POOR FORGERY",
	basic = "BASIC FORGERY",
	professional = "PROFESSIONAL FORGERY",
	military = "MILITARY-GRADE SPOOF",
	stolen = "STOLEN AUTHENTIC TRANSPONDER",
	cloned = "CLONED ACTIVE IDENTITY",
	legitimate = "LEGITIMATE",
}

I.CheckLabels = {
	registry = "REGISTRY QUERY",
	manifest = "CARGO MANIFEST",
	crew = "CREW MANIFEST",
	engine = "ENGINE SIGNATURE",
	mass = "CARGO MASS",
	flightplan = "FLIGHT PLAN",
	hull = "HULL / MODEL MATCH",
}

I.CrimeLabels = {
	false_iff = "False identification",
	stolen_ship = "Operating a stolen vessel",
	smuggling = "Smuggling restricted or illegal goods",
	piracy = "Piracy",
	evasion = "Evading Republic inspection",
	bribery = "Attempted bribery",
	espionage = "Espionage",
	sabotage = "Sabotage",
	assault = "Assault on Republic personnel",
	weapons = "Possession of unregistered weapons",
}

function I.Clean(value, maximum)
	value = string.Trim(tostring(value or ""))
	value = string.gsub(value, "[%c]", " ")
	return string.sub(value, 1, maximum or 256)
end
