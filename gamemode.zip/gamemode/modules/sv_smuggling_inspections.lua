-- Republic customs, false-IFF, forced landing and physical cargo inspections.
if not SERVER or MilBase._SmugglingInspectionsServerLoaded then return end
MilBase._SmugglingInspectionsServerLoaded = true

local I = MilBase.Inspections
local G = MilBase.Galaxy
local N = MilBase.Naval
local cfg = MilBase.Config.SmugglingInspections or {}
if cfg.Enabled == false or not G then return end

util.AddNetworkString("MilBase_InspectionOpen")
util.AddNetworkString("MilBase_InspectionAction")

I.Cases = I.Cases or {}
I.ByShip = I.ByShip or setmetatable({}, { __mode = "k" })
I.Anchors = I.Anchors or { crew = {}, cargo = {}, approach = {} }
I.WantedCaptains = I.WantedCaptains or {}
I._sequence = I._sequence or 0
I.TestCases = I.TestCases or {}
I._testSequence = I._testSequence or 0

local legitimateCargo = {
	{ key = "food", label = "food and relief packages", mass = 18, legal = true },
	{ key = "medical", label = "medical supplies and bacta", mass = 14, legal = true },
	{ key = "parts", label = "replacement starship components", mass = 26, legal = true },
	{ key = "fuel", label = "licensed refined fuel cells", mass = 31, legal = true },
	{ key = "agriculture", label = "agricultural machinery", mass = 38, legal = true },
	{ key = "textiles", label = "civilian textiles and uniforms", mass = 12, legal = true },
	{ key = "droids", label = "licensed utility droid parts", mass = 20, legal = true },
	{ key = "passengers", label = "passenger luggage and personal effects", mass = 10, legal = true },
}

local illegalCargo = {
	{ key = "weapons", label = "unregistered blaster weapons", mass = 24, legal = false, crime = "weapons" },
	{ key = "munitions", label = "stolen Republic munitions", mass = 36, legal = false, crime = "smuggling" },
	{ key = "spice", label = "spice concealed in medical packaging", mass = 12, legal = false, crime = "smuggling" },
	{ key = "cis", label = "encrypted CIS datacores and tracking beacons", mass = 9, legal = false, crime = "espionage" },
	{ key = "droid", label = "restricted battle-droid components", mass = 28, legal = false, crime = "smuggling" },
	{ key = "armour", label = "stolen clone armour and Republic access codes", mass = 17, legal = false, crime = "smuggling" },
	{ key = "explosives", label = "military-grade sabotage charges", mass = 22, legal = false, crime = "sabotage" },
	{ key = "prisoners", label = "concealed kidnapped civilians", mass = 15, legal = false, crime = "piracy" },
}

local captainFirst = {
	"Arden", "Bela", "Caro", "Davan", "Eris", "Fenn", "Garris", "Hale",
	"Ilya", "Joran", "Kessa", "Lio", "Mara", "Niko", "Oran", "Pella",
	"Quill", "Ressa", "Sorin", "Tala", "Venn", "Wes", "Yara", "Zev",
}
local captainLast = {
	"Aven", "Bex", "Cordan", "Drell", "Eran", "Faro", "Gant", "Hesk",
	"Iven", "Jast", "Korr", "Lenn", "Merek", "Nall", "Ordo", "Pryce",
	"Rann", "Sorn", "Tallis", "Vane", "Wren", "Yorr", "Zann",
}
local civilianShipNames = {
	"Azure Wayfarer", "Corellian Promise", "Dawn Courier", "Frontier Mercy",
	"Golden Meridian", "Horizon Trader", "Independent Venture", "Jade Runner",
	"Luminous Path", "New Concord", "Outer Rim Star", "Quiet Resolve",
	"Relief Star", "Silver Current", "Trade Wind", "Vigilant Merchant",
}
local crewRoles = { "Captain", "Pilot", "Engineer", "Cargo Master", "Navigator", "Medic" }
local crewPersonalities = { "professional", "guarded", "nervous", "talkative", "defiant", "weary" }
local failureProfiles = {
	{ label = "main-engine failure", system = "engines", minimum = 0.16, maximum = 0.34 },
	{ label = "partial engine loss", system = "engines", minimum = 0.34, maximum = 0.58 },
	{ label = "hyperdrive fault", system = "hyperdrive", minimum = 0.12, maximum = 0.38 },
	{ label = "fuel leak", system = "engines", minimum = 0.28, maximum = 0.52 },
	{ label = "reactor instability", system = "shields", minimum = 0.22, maximum = 0.48 },
	{ label = "communications failure", system = "communications", minimum = 0.08, maximum = 0.35 },
	{ label = "navigation failure", system = "controls", minimum = 0.18, maximum = 0.42 },
	{ label = "landing-gear malfunction", system = "controls", minimum = 0.35, maximum = 0.62 },
	{ label = "life-support fault", system = "life_support", minimum = 0.18, maximum = 0.46 },
	{ label = "electrical fire", system = "weapons", minimum = 0.15, maximum = 0.4 },
}

local function unix()
	return os.time()
end

local function randomChoice(list)
	return list[math.random(1, #list)]
end

local function copy(value)
	return istable(value) and table.Copy(value) or value
end

local function writeCompressed(target, data)
	if not IsValid(target) then return end
	local raw = util.TableToJSON(data or {}) or "{}"
	local compressed = util.Compress(raw)
	net.Start("MilBase_InspectionOpen")
		net.WriteUInt(#compressed, 24)
		net.WriteData(compressed, #compressed)
	net.Send(target)
end

local function writeGalaxyDialogue(target, data)
	if not IsValid(target) then return end
	local raw = util.TableToJSON(data or {}) or "{}"
	local compressed = util.Compress(raw)
	net.Start("MilBase_GalaxyHailContacts")
		net.WriteUInt(#compressed, 24)
		net.WriteData(compressed, #compressed)
	net.Send(target)
end

local function playerName(ply)
	if not IsValid(ply) then return "Republic personnel" end
	return ply.MBName and ply:MBName() or ply:Nick()
end

local function notify(ply, text, kind)
	if MilBase.Notify then MilBase.Notify(ply, text, kind or "info") end
end

local function canConfigure(ply)
	if not IsValid(ply) then return false end
	if ply:IsListenServerHost() or ply:IsSuperAdmin() then return true end
	return ply.MBStaffLevel and ply:MBStaffLevel() >= (tonumber(cfg.AnchorStaffLevel) or 6)
end

local function canUseTestHarness(ply)
	if cfg.EnableTestHarness == false or not IsValid(ply) then return false end
	if ply:IsListenServerHost() or ply:IsSuperAdmin() then return true end
	return ply.MBStaffLevel and ply:MBStaffLevel() >= (tonumber(cfg.TestStaffLevel) or tonumber(cfg.AnchorStaffLevel) or 6)
end

local function canInspect(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
	if ply:IsAdmin() then return true end
	if G.IsNavyRecipient and G.IsNavyRecipient(ply) then return true end
	if MilBase.JailCanArrest and MilBase.JailCanArrest(ply) then return true end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local name = string.lower(tostring(faction and faction.name or ""))
	return string.find(name, "clone", 1, true) ~= nil
		or string.find(name, "guard", 1, true) ~= nil
		or string.find(name, "nav", 1, true) ~= nil
end
I.CanInspect = canInspect

local function isEngineer(ply)
	if not IsValid(ply) then return false end
	local faction = ply.MBFaction and ply:MBFaction() or nil
	local name = string.lower(tostring(faction and faction.name or ""))
	local title = string.lower(tostring(ply.MBFullTitle and ply:MBFullTitle() or ""))
	return string.find(name, "engineer", 1, true) ~= nil
		or string.find(title, "engineer", 1, true) ~= nil
end

local function vecString(value)
	return MilBase.SQLStr(util.TypeToString(isvector(value) and value or vector_origin))
end

local function angString(value)
	return MilBase.SQLStr(util.TypeToString(isangle(value) and value or angle_zero))
end

local function rowVector(value)
	local result = util.StringToType(tostring(value or ""), "Vector")
	return isvector(result) and result or nil
end

local function rowAngle(value)
	local result = util.StringToType(tostring(value or ""), "Angle")
	return isangle(result) and result or angle_zero
end

local function evidenceCount(case)
	local total = 0
	for _, evidence in pairs(case.evidence or {}) do
		total = total + math.max(1, tonumber(evidence.weight) or 1)
	end
	return total
end
I.EvidenceCount = evidenceCount

local function evidenceList(case)
	local result = {}
	for _, evidence in pairs(case.evidence or {}) do
		result[#result + 1] = evidence.label
	end
	table.sort(result)
	return result
end

local function suspectedCharges(case)
	local charges, seen = {}, {}
	local function add(key)
		local label = I.CrimeLabels[key]
		if label and not seen[key] then
			seen[key] = true
			charges[#charges + 1] = label
		end
	end
	for key in pairs(case.evidence or {}) do
		if string.find(key, "iff", 1, true) or key == "stolen_registry" then add("false_iff") end
		if string.find(key, "contraband", 1, true) or key == "hidden_compartment" then add("smuggling") end
		if string.find(key, "weapon", 1, true) then add("weapons") end
		if key == "evasion" or key == "disabled_after_evasion" then add("evasion") end
		if key == "assault" or key == "hostile_action" or key == "inspection_violence" then add("assault") end
		if key == "bribery" then add("bribery") end
	end
	for _, cargo in ipairs(case.cargo or {}) do
		if cargo.searched and cargo.legal == false then add(cargo.crime or "smuggling") end
	end
	if case.stolenShip and (case.identityConfirmed or case.evidence.stolen_registry) then add("stolen_ship") end
	table.sort(charges)
	return charges
end

function I.AddEvidence(case, key, label, weight, actor)
	if not case or not key or case.evidence[key] then return false end
	case.evidence[key] = {
		key = key,
		label = I.Clean(label, 180),
		weight = math.max(1, math.floor(tonumber(weight) or 1)),
		at = unix(),
		by = playerName(actor),
	}
	case.suspicion = math.Clamp((case.suspicion or 0) + 12
		* math.max(1, tonumber(weight) or 1), 0, 100)
	I.MaybeConfirmIdentity(case)
	I.SaveCase(case)
	return true
end

function I.MaybeConfirmIdentity(case)
	if not case or case.identityConfirmed then return end
	if case.ship and IsValid(case.ship) and case.ship:GetHostile() then
		case.identityConfirmed = true
	elseif evidenceCount(case) >= 3 and case.trueFaction ~= "civilian"
	and case.trueFaction ~= "republic" then
		case.identityConfirmed = true
	elseif case.evidence.stolen_registry and case.trueFaction == "pirate" then
		case.identityConfirmed = true
	end
	if case.identityConfirmed and IsValid(case.ship) then
		case.ship:SetFaction(case.trueFaction)
		case.ship.mb_galaxyTransponderFaction = case.claimedFaction
		case.ship:SetShipState(case.trueFaction == "pirate" and "pirate identity exposed"
			or case.trueFaction == "cis" and "CIS infiltration exposed"
			or case.ship:GetShipState())
	end
end

function I.PublicFaction(ship, scanned)
	local case = I.ByShip[ship]
	if not case then return nil end
	if case.identityConfirmed or ship:GetHostile() then return case.trueFaction end
	return case.claimedFaction or "civilian"
end

function I.PublicContactType(ship)
	local case = I.ByShip[ship]
	if not case or case.identityConfirmed then return nil end
	return case.publicType or ""
end

function I.PublicRole(ship)
	local case = I.ByShip[ship]
	if not case or case.identityConfirmed then return nil end
	return case.claimedFaction == "republic" and "republic courier" or "civilian traffic"
end

function I.IdentityNameKnown(ship)
	local case = I.ByShip[ship]
	return not case or case.identityConfirmed or case.checks.registry == "verified"
end

local function declaredCargoLabel(case)
	local labels = {}
	for _, item in ipairs(case.cargo or {}) do
		labels[#labels + 1] = item.declared
	end
	return table.concat(labels, ", ")
end

local function actualCargoMass(case)
	local total = 0
	for _, item in ipairs(case.cargo or {}) do total = total + (tonumber(item.mass) or 0) end
	if case.hiddenCompartment then total = total + (case.hiddenMass or 12) end
	return math.floor(total)
end

local function caseLegal(case)
	if not case then return true end
	if case.trueFaction == "pirate" or case.trueFaction == "cis" then return false end
	for _, item in ipairs(case.cargo or {}) do
		if item.legal == false then return false end
	end
	return not case.stolenShip and not case.criminalCaptain
end
I.CaseLegal = caseLegal

local function nextCaseID()
	I._sequence = I._sequence + 1
	return string.format("INSP-%d-%03d", unix(), I._sequence % 1000)
end

local function nextTestCaseID()
	I._sequence = I._sequence + 1
	return string.format("TEST-%d-%03d", unix(), I._sequence % 1000)
end

local function chooseIFFQuality(trueFaction, criminal)
	if not criminal then
		return math.Rand(0, 1) < 0.08 and "basic" or "legitimate"
	end
	local roll = math.Rand(0, 1)
	if trueFaction == "cis" then
		if roll < 0.3 then return "military" end
		if roll < 0.55 then return "stolen" end
		if roll < 0.78 then return "cloned" end
		return "professional"
	end
	if roll < 0.14 then return "poor" end
	if roll < 0.36 then return "basic" end
	if roll < 0.64 then return "professional" end
	if roll < 0.83 then return "stolen" end
	return "cloned"
end

local function makeCargo(criminal, count)
	local cargo = {}
	local illegalIndex = criminal and math.random(1, count) or 0
	for index = 1, count do
		local actual = index == illegalIndex and copy(randomChoice(illegalCargo))
			or copy(randomChoice(legitimateCargo))
		local declared = actual.label
		if actual.legal == false then declared = randomChoice(legitimateCargo).label end
		cargo[#cargo + 1] = {
			id = index,
			declared = declared,
			actual = actual.label,
			key = actual.key,
			mass = actual.mass + math.random(-2, 4),
			legal = actual.legal,
			crime = actual.crime,
			sealed = math.Rand(0, 1) < 0.65,
			searched = false,
			seized = false,
		}
	end
	return cargo
end

local function makeCrew(case, count)
	local crew = {}
	local originalCaptain = case.captainName
	for index = 1, count do
		local role = crewRoles[math.min(index, #crewRoles)]
		local profile = MilBase.ChooseSpeciesProfile
			and MilBase.ChooseSpeciesProfile("crew", cfg.CrewSpeciesWeights) or nil
		local species = profile and profile.species
			or (MilBase.GetSpecies and MilBase.GetSpecies("human"))
		local speciesID = species and species.id or "human"
		local name = MilBase.RandomSpeciesName and MilBase.RandomSpeciesName(speciesID)
			or (randomChoice(captainFirst) .. " " .. randomChoice(captainLast))
		if index == 1 then
			case.captainName = name
			if not case.registryCaptain or case.registryCaptain == originalCaptain then
				case.registryCaptain = name
			end
		end
		crew[index] = {
			id = index,
			name = name,
			role = role,
			speciesID = speciesID,
			speciesName = species and species.name or "Human",
			languageID = species and species.nativeLanguage or "basic",
			model = profile and profile.model or cfg.CrewModel,
			modelAlias = profile and profile.alias or "",
			personality = randomChoice(crewPersonalities),
			truthful = not case.criminal or index > 1 and math.Rand(0, 1) < 0.45,
			loyalty = math.random(25, 95),
			morale = math.random(30, 95),
			armed = case.criminal and math.Rand(0, 1) < 0.4,
			searched = false,
			arrested = false,
			questioned = {},
			statements = {},
			statementRecords = {},
			relationships = {},
		}
	end
	return crew
end

-- Deterministic staff scenarios used by /inspectiontest. Every contact still
-- presents itself as civilian until its evidence or hostile behaviour exposes it.
local testScenarioOrder = {
	"legitimate", "paperwork", "smuggler", "pirate", "cis", "stolen",
	"real_failure", "fake_failure", "bribery", "evasion", "resistance",
}
local testScenarioLabels = {
	legitimate = "innocent civilian with valid records and legal cargo",
	paperwork = "innocent civilian with paperwork and mass discrepancies",
	smuggler = "civilian smuggler carrying concealed contraband",
	pirate = "pirate crew using a cloned civilian identity",
	cis = "CIS intelligence team using a military-grade civilian spoof",
	stolen = "pirates operating a stolen vessel and authentic transponder",
	real_failure = "innocent civilian with a genuine main-engine failure",
	fake_failure = "smuggler faking an engine failure to delay inspection",
	bribery = "smuggler whose captain will offer a bribe",
	evasion = "pirate contact guaranteed to refuse the landing order",
	resistance = "pirate crew guaranteed to resist after enforcement",
}
local testScenarioAliases = {
	legit = "legitimate", innocent = "legitimate", papers = "paperwork",
	smuggle = "smuggler", failure = "real_failure", real = "real_failure",
	fake = "fake_failure", bribe = "bribery", flee = "evasion",
	violent = "resistance", hostile = "resistance", separatist = "cis",
}
I.TestScenarioOrder = testScenarioOrder
I.TestScenarioLabels = testScenarioLabels

local function normaliseTestScenario(value)
	value = string.lower(string.Trim(tostring(value or "random")))
	value = string.gsub(value, "[%s%-]+", "_")
	value = testScenarioAliases[value] or value
	if value == "random" or value == "next" then return value end
	return testScenarioLabels[value] and value or nil
end

local function cargoTemplateByKey(key)
	key = string.lower(tostring(key or ""))
	for _, item in ipairs(illegalCargo) do
		if item.key == key then return item end
	end
	return randomChoice(illegalCargo)
end

local function buildTestCargo(case, profile)
	local count = math.random(3, 4)
	case.cargo = makeCargo(false, count)
	if profile.criminal then
		local index = math.random(1, count)
		local actual = copy(cargoTemplateByKey(profile.cargoKey))
		case.cargo[index] = {
			id = index,
			declared = randomChoice(legitimateCargo).label,
			actual = actual.label,
			key = actual.key,
			mass = actual.mass + math.random(-1, 4),
			legal = false,
			crime = actual.crime,
			sealed = true,
			searched = false,
			seized = false,
		}
	end
end

local function clearTestFailure(case)
	case.emergency = nil
	case.emergencySystem = nil
	case.emergencyCondition = nil
	case.emergencyFake = false
	case.failureDiagnosed = false
	case.failureRepaired = false
	if IsValid(case.ship) then
		case.ship.mb_inspectionSystemConditions = {}
		case.ship.mb_skyboxSystems = case.ship.mb_skyboxSystems or {}
		for _, key in ipairs({ "engines", "controls", "weapons", "shields" }) do
			case.ship.mb_skyboxSystems[key] = 1
		end
	end
end

local function applyTestFailure(case, fake)
	clearTestFailure(case)
	local failure = copy(failureProfiles[1]) -- main-engine failure is easiest to verify and repair.
	case.emergency = failure.label
	case.emergencySystem = failure.system
	case.emergencyCondition = math.Rand(failure.minimum, failure.maximum)
	case.emergencyFake = fake == true
	if IsValid(case.ship) and not case.emergencyFake then
		case.ship.mb_skyboxSystems = case.ship.mb_skyboxSystems or {
			engines = 1, controls = 1, weapons = 1, shields = 1,
		}
		case.ship.mb_skyboxSystems[case.emergencySystem] = case.emergencyCondition
		case.ship.mb_inspectionSystemConditions = case.ship.mb_inspectionSystemConditions or {}
		case.ship.mb_inspectionSystemConditions[case.emergencySystem] = case.emergencyCondition
	end
end

function I.ConfigureTestCase(case, scenario, owner)
	if not case or not IsValid(case.ship) then return nil end
	scenario = normaliseTestScenario(scenario) or "random"
	if scenario == "random" then scenario = randomChoice(testScenarioOrder) end
	if scenario == "next" then
		I._testSequence = (I._testSequence % #testScenarioOrder) + 1
		scenario = testScenarioOrder[I._testSequence]
	end

	local profiles = {
		legitimate = { trueFaction = "civilian", criminal = false, iff = "legitimate", compliance = "comply" },
		paperwork = { trueFaction = "civilian", criminal = false, iff = "legitimate", compliance = "comply", paperwork = true },
		smuggler = { trueFaction = "civilian", criminal = true, iff = "professional", compliance = "comply", hidden = true },
		pirate = { trueFaction = "pirate", criminal = true, iff = "cloned", compliance = "comply", hidden = true, armed = true },
		cis = { trueFaction = "cis", criminal = true, iff = "military", compliance = "comply", hidden = true, armed = true, cargoKey = "cis" },
		stolen = { trueFaction = "pirate", criminal = true, iff = "stolen", compliance = "comply", hidden = true, armed = true, stolen = true },
		real_failure = { trueFaction = "civilian", criminal = false, iff = "legitimate", compliance = "comply", emergency = "real" },
		fake_failure = { trueFaction = "civilian", criminal = true, iff = "basic", compliance = "comply", hidden = true, emergency = "fake" },
		bribery = { trueFaction = "civilian", criminal = true, iff = "professional", compliance = "comply", hidden = true, forceBribe = true },
		evasion = { trueFaction = "pirate", criminal = true, iff = "cloned", compliance = "refuse", hidden = true, armed = true },
		resistance = { trueFaction = "pirate", criminal = true, iff = "professional", compliance = "comply", hidden = true, armed = true, forceResistance = true },
	}
	local profile = profiles[scenario] or profiles.legitimate

	case.testCase = true
	case.testScenario = scenario
	case.testDescription = testScenarioLabels[scenario]
	case.testOwnerSteamID = IsValid(owner) and owner:SteamID64() or ""
	case.testCompliance = profile.compliance
	case.testForceBribe = profile.forceBribe == true
	case.testForceResistance = profile.forceResistance == true
	case.testForceHidden = profile.hidden == true
	case.testForceScannerAnomaly = profile.iff ~= "legitimate"
	case.trueFaction = profile.trueFaction
	case.claimedFaction = "civilian"
	case.criminal = profile.criminal == true
	case.criminalCaptain = case.criminal
	case.stolenShip = profile.stolen == true
	case.iffQuality = profile.iff
	case.iffStatus = "UNVERIFIED"
	case.identityConfirmed = false
	case.publicType = ""
	case.suspicion = 0
	case.evidence = {}
	case.checks = {}
	case.hiddenCompartment = profile.hidden == true
	case.hiddenFound = false
	case.hiddenMass = case.hiddenCompartment and math.random(12, 24) or 0
	case.resistanceTriggered = false
	case.disableAuthorized = false
	case.landingOrdered = false
	case.bribeOffered = false
	case.wrongfulActions = 0
	case.resolved = false
	case.outcome = nil

	buildTestCargo(case, profile)
	case.declaredMass = actualCargoMass(case)
	case.flightPlanValid = true
	case.crewManifestValid = true
	case.modelRegistryMatch = true
	case.duplicateIFF = profile.iff == "cloned"
	case.registryStolen = profile.iff == "stolen" or case.stolenShip
	if profile.paperwork then
		case.flightPlanValid = false
		case.crewManifestValid = false
		case.modelRegistryMatch = false
		case.declaredMass = case.declaredMass + math.random(6, 12)
	elseif case.criminal then
		case.flightPlanValid = false
		case.crewManifestValid = math.Rand(0, 1) < 0.25
		case.modelRegistryMatch = profile.iff == "stolen"
		case.declaredMass = math.max(4, case.declaredMass - math.random(8, 20))
	end

	case.crew = makeCrew(case, math.random(3, 5))
	for index, member in ipairs(case.crew) do
		if not case.criminal then
			member.truthful = true
			member.armed = false
		else
			member.truthful = index > 2 and math.Rand(0, 1) < 0.35
			member.armed = profile.armed == true and index <= 2
		end
	end

	clearTestFailure(case)
	if profile.emergency == "real" then applyTestFailure(case, false)
	elseif profile.emergency == "fake" then applyTestFailure(case, true) end

	local ship = case.ship
	ship.mb_galaxyTrueFaction = case.trueFaction
	ship.mb_galaxyTransponderFaction = "civilian"
	ship.mb_galaxyInspectionCase = case
	ship.mb_inspectionCaseID = case.id
	ship.mb_galaxyAllowCrossFactionName = true
	ship.mb_inspectionTestContact = true
	ship:SetFaction("civilian")
	ship:SetHostile(false)
	ship:SetInvulnerable(false)
	ship:SetShipName(case.displayedName)
	ship:SetDieAt(0)
	ship:SetFlightVelocity(vector_origin)
	ship:SetShipState(case.emergency and (case.emergencyFake and "reports technical emergency" or case.emergency)
		or "awaiting routine customs clearance")
	case.testExpiresAt = CurTime() + math.max(300, tonumber(cfg.TestContactLifetime) or 1800)
	I.TestCases[case.id] = true
	return scenario
end

function I.EnsureCaseForShip(ship, opts)
	if not IsValid(ship) or ship:GetClass() ~= "mb_galaxy_ship" then return nil end
	opts = istable(opts) and opts or {}
	if I.ByShip[ship] then
		local existing = I.ByShip[ship]
		if opts.testCase == true and not existing.testCase then
			I.ConfigureTestCase(existing, opts.testScenario, opts.testOwner)
		end
		return existing
	end
	if ship.mb_galaxySalvage or ship.mb_galaxyNavigationBeacon
	or ship.mb_galaxySensorAnomaly or ship.mb_galaxyBackgroundBattle
	or ship:GetCapital() then return nil end
	if opts.inspectable ~= true and (ship:GetHostile()
	or string.Trim(tostring(ship:GetEncounterID() or "")) ~= "") then return nil end
	local sizeClass = string.lower(tostring(ship.GetSizeClass and ship:GetSizeClass() or "light"))
	if sizeClass == "fighter" and cfg.AllowFighterInspections ~= true then return nil end
	local trueFaction = string.lower(tostring(ship.mb_galaxyTrueFaction or ship:GetFaction() or "neutral"))
	local chance = tonumber((cfg.CaseChance or {})[trueFaction]) or 0
	if opts.forceInspectionCase ~= true and math.Rand(0, 1) > chance then return nil end
	if opts.testCase == true then
		local activeTests = 0
		for id in pairs(I.TestCases or {}) do
			if I.Cases[id] then activeTests = activeTests + 1 end
		end
		if activeTests >= math.max(1, tonumber(cfg.TestMaximumContacts) or 6) then return nil end
	else
		local activeLive = 0
		for _, openCase in pairs(I.Cases or {}) do
			if openCase.testCase ~= true then activeLive = activeLive + 1 end
		end
		if activeLive >= math.max(1, tonumber(cfg.MaximumOpenCases) or 12) then return nil end
	end

	local criminal = trueFaction == "pirate" or trueFaction == "cis"
		or ship.mb_galaxyManifestLegal == false
	if trueFaction == "civilian" and not criminal then criminal = math.Rand(0, 1) < 0.22 end
	local claimedFaction = trueFaction == "republic" and "republic" or "civilian"
	local displayedName = randomChoice(civilianShipNames)
	local captainName = randomChoice(captainFirst) .. " " .. randomChoice(captainLast)
	local count = math.random(2, 4)
	local case = {
		id = opts.testCase == true and nextTestCaseID() or nextCaseID(),
		ship = ship,
		createdAt = unix(),
		updatedAt = unix(),
		status = "monitoring",
		trueFaction = trueFaction,
		claimedFaction = claimedFaction,
		trueName = ship:GetShipName(),
		displayedName = displayedName,
		captainName = captainName,
		registryCaptain = captainName,
		registryModel = ship:GetModel(),
		iffQuality = chooseIFFQuality(trueFaction, criminal),
		iffStatus = "UNVERIFIED",
		criminal = criminal,
		criminalCaptain = criminal and math.Rand(0, 1) < 0.78,
		stolenShip = criminal and math.Rand(0, 1) < 0.22,
		publicType = "",
		suspicion = 0,
		evidence = {},
		checks = {},
		cargo = makeCargo(criminal, count),
		declaredMass = 0,
		hiddenCompartment = criminal and math.Rand(0, 1)
			< math.Clamp(tonumber(cfg.HiddenCompartmentBaseChance) or 0.3, 0, 1),
		hiddenFound = false,
		hiddenMass = criminal and math.random(8, 26) or 0,
		crew = {},
		physicalEntities = {},
		resistanceTriggered = false,
		disableAuthorized = false,
		landingOrdered = false,
		bribeOffered = false,
		wrongfulActions = 0,
	}
	case.crew = makeCrew(case, math.random(2, 5))
	case.declaredMass = actualCargoMass(case)
	if criminal then case.declaredMass = math.max(4, case.declaredMass - math.random(7, 24)) end
	case.flightPlanValid = not criminal or math.Rand(0, 1) < 0.28
	case.crewManifestValid = not criminal or math.Rand(0, 1) < 0.35
	case.modelRegistryMatch = case.iffQuality == "legitimate" or math.Rand(0, 1) < 0.35
	case.duplicateIFF = case.iffQuality == "cloned"
	case.registryStolen = case.iffQuality == "stolen" or case.stolenShip
	case.emergency = nil
	if cfg.EnableNaturalFailures ~= false and math.Rand(0, 1)
	< math.Clamp(tonumber(cfg.EngineFailureChance) or 0.2, 0, 1) then
		local failure = copy(randomChoice(failureProfiles))
		case.emergency = failure.label
		case.emergencySystem = failure.system
		case.emergencyCondition = math.Rand(failure.minimum, failure.maximum)
		case.emergencyFake = criminal and math.Rand(0, 1)
			< math.Clamp(tonumber(cfg.FakeEmergencyChance) or 0.3, 0, 1)
	end

	I.Cases[case.id] = case
	I.ByShip[ship] = case
	ship.mb_inspectionCaseID = case.id
	ship.mb_galaxyInspectionCase = case
	ship.mb_galaxyTrueName = case.trueName
	ship.mb_galaxyTransponderFaction = claimedFaction
	ship.mb_galaxyAllowCrossFactionName = true
	ship:SetFaction(claimedFaction)
	ship:SetShipName(displayedName)
	ship:SetHostile(false)
	if case.emergency then
		ship:SetShipState(case.emergencyFake and "reports technical emergency"
			or case.emergency)
		if not case.emergencyFake then
			ship.mb_skyboxSystems = ship.mb_skyboxSystems or {
				engines = 1, controls = 1, weapons = 1, shields = 1,
			}
			if ship.mb_skyboxSystems[case.emergencySystem] ~= nil then
				ship.mb_skyboxSystems[case.emergencySystem] = case.emergencyCondition
			end
			ship.mb_inspectionSystemConditions = ship.mb_inspectionSystemConditions or {}
			ship.mb_inspectionSystemConditions[case.emergencySystem] = case.emergencyCondition
		end
	end
	if opts.testCase == true then
		I.ConfigureTestCase(case, opts.testScenario, opts.testOwner)
	end
	I.SaveCase(case)
	return case
end

local baseSpawnShip = G.SpawnShip
function G.SpawnShip(role, opts)
	opts = istable(opts) and table.Copy(opts) or {}
	local hiddenPirate = role == "pirate" and opts.hostile ~= true
		and not opts.encounterID and not opts.combat
	if hiddenPirate then
		opts.trueFaction = "pirate"
		opts.faction = "civilian"
		opts.transponderFaction = "civilian"
		opts.hostile = false
		if G.ResolveShipModel then opts.model = opts.model or G.ResolveShipModel("civilian") end
	end
	local ship = baseSpawnShip(role, opts)
	if IsValid(ship) then I.EnsureCaseForShip(ship, opts) end
	return ship
end

local baseIdentity = G.InitializeShipIdentity
function G.InitializeShipIdentity(ship, opts)
	baseIdentity(ship, opts)
	I.EnsureCaseForShip(ship, opts)
end

function I.OnScannerResolved(ply, ship)
	local case = I.EnsureCaseForShip(ship)
	if not case then return end
	case.checks.hull = "completed"
	local qualityDifficulty = {
		legitimate = 0.05, poor = 0.95, basic = 0.78, professional = 0.48,
		military = 0.24, stolen = 0.42, cloned = 0.6,
	}
	local sensorCondition = G.ShipSystemSnapshot and G.ShipSystemSnapshot().sensors or 100
	local chance = math.Clamp((qualityDifficulty[case.iffQuality] or 0.4)
		* (0.55 + sensorCondition / 220), 0.04, 0.98)
	if case.testForceScannerAnomaly then chance = 1 end
	if case.iffQuality ~= "legitimate" and math.Rand(0, 1) <= chance then
		case.iffStatus = case.iffQuality == "poor" and "FALSE IFF SUSPECTED"
			or "PARTIAL AUTHENTICATION MISMATCH"
		I.AddEvidence(case, "scanner_anomaly", "Sensor profile contains an IFF authentication anomaly.", 1, ply)
	else
		case.iffStatus = case.iffQuality == "legitimate" and "PROVISIONALLY VERIFIED"
			or "INCONCLUSIVE"
	end
	if not case.modelRegistryMatch and math.Rand(0, 1) < 0.55 then
		I.AddEvidence(case, "hull_mismatch", "Observed hull profile does not match the transmitted registry.", 1, ply)
	end
	I.SaveCase(case)
end

function I.ScannerProfile(ship)
	local case = I.ByShip[ship]
	if not case then return nil end
	local maxHull = math.max(1, ship:GetMaxHull())
	local hull = math.floor(ship:GetHull() / maxHull * 100)
	local systems = ship.mb_skyboxSystems or {}
	local inspectionSystems = ship.mb_inspectionSystemConditions or {}
	local engine = math.floor(math.Clamp(tonumber(systems.engines) or 1, 0, 1) * 100)
	local emergencyCondition = case.emergencySystem and math.floor(math.Clamp(
		tonumber(inspectionSystems[case.emergencySystem]) or tonumber(systems[case.emergencySystem]) or 1,
		0, 1) * 100) or nil
	local cargoText = case.checks.mass and ("DECLARED " .. case.declaredMass
		.. " / DETECTED " .. actualCargoMass(case) .. " MASS UNITS")
		or "MASS PROFILE NOT YET COMPARED"
	return "TRANSMITTED IDENTITY: " .. case.displayedName
		.. "\nAPPARENT AFFILIATION: " .. string.upper(case.claimedFaction)
		.. "\nIFF AUTHENTICATION: " .. case.iffStatus
		.. "\nHULL INTEGRITY: " .. hull .. "%"
		.. "\nENGINE OUTPUT: " .. engine .. "%"
		.. (emergencyCondition and ("\nDECLARED-FAULT SYSTEM: "
			.. string.upper(tostring(case.emergencySystem)) .. " / " .. emergencyCondition .. "%") or "")
		.. "\nCARGO PROFILE: " .. cargoText
		.. "\nROUTE: " .. I.Clean(ship.mb_galaxyOrigin, 80) .. " → "
		.. I.Clean(ship.mb_galaxyDestination, 100)
		.. (case.emergency and ("\nDECLARED EMERGENCY: " .. string.upper(case.emergency)) or "")
		.. "\n\nThe scanner reports only observable evidence. True allegiance remains unknown until identity records and crew statements are checked."
end

local function caseTitle(case)
	return "CUSTOMS CASE " .. case.id
end

local function caseBody(case, prefix)
	local checks = {}
	for key, label in pairs(I.CheckLabels) do
		if case.checks[key] then checks[#checks + 1] = label .. ": " .. string.upper(tostring(case.checks[key])) end
	end
	table.sort(checks)
	local evidence = evidenceList(case)
	local charges = suspectedCharges(case)
	return (prefix and (prefix .. "\n\n") or "")
		.. "CONTACT: " .. case.displayedName
		.. "\nCAPTAIN: " .. case.captainName
		.. "\nSTATUS: " .. (I.StatusLabels[case.status] or string.upper(case.status))
		.. "\nIFF: " .. case.iffStatus
		.. "\nSUSPICION: " .. math.floor(case.suspicion or 0) .. "%"
		.. "\nEVIDENCE: " .. evidenceCount(case)
		.. (#evidence > 0 and ("\n- " .. table.concat(evidence, "\n- ")) or "\n- No confirmed evidence")
		.. (#charges > 0 and ("\n\nPOTENTIAL CHARGES\n- " .. table.concat(charges, "\n- ")) or "")
		.. (#checks > 0 and ("\n\nCHECKS\n" .. table.concat(checks, "\n")) or "")
end

local function commsChoices(case)
	local choices = {
		{ id = "inspection_talk", label = "OPEN CINEMATIC CAPTAIN CHANNEL", group = "CAPTAIN INTERVIEW" },
		{ id = "inspection_registry", label = "QUERY SHIP REGISTRY", group = "IDENTITY & DOCUMENTS" },
		{ id = "inspection_manifest", label = "REQUEST CARGO MANIFEST", group = "IDENTITY & DOCUMENTS" },
		{ id = "inspection_crew", label = "REQUEST CREW IDENTITIES", group = "IDENTITY & DOCUMENTS" },
		{ id = "inspection_flightplan", label = "VERIFY FLIGHT PLAN", group = "IDENTITY & DOCUMENTS" },
	}
	if G.ScannedShips and G.ScannedShips[case.ship] then
		choices[#choices + 1] = { id = "inspection_engine", label = "COMPARE SYSTEM TELEMETRY", group = "SENSOR CHECKS" }
		choices[#choices + 1] = { id = "inspection_mass", label = "COMPARE CARGO MASS", group = "SENSOR CHECKS" }
	end
	choices[#choices + 1] = { id = "inspection_mark", label = "MARK CONTACT SUSPICIOUS", group = "FLIGHT CONTROL" }
	choices[#choices + 1] = { id = "inspection_disable", label = "AUTHORISE DISABLING FIRE", group = "FLIGHT CONTROL", danger = true }
	choices[#choices + 1] = { id = "inspection_clear_space", label = "CLEAR TO PROCEED", group = "DISPOSITION" }
	choices[#choices + 1] = { id = "inspection_leave", label = "ORDER LEAVE LOCAL SPACE", group = "DISPOSITION" }
	choices[#choices + 1] = { id = "close", label = "CLOSE CHANNEL", group = "DISPOSITION" }
	return choices
end

local function commsCaseSnapshot(case, message)
	local checks = {}
	for key, label in pairs(I.CheckLabels) do
		local value = case.checks and case.checks[key]
		if value then
			checks[#checks + 1] = { label = label, value = string.upper(tostring(value)) }
		end
	end
	table.sort(checks, function(a, b) return a.label < b.label end)
	return {
		id = case.id,
		contact = case.displayedName,
		captain = case.captainName,
		captainSpecies = case.crew and case.crew[1] and case.crew[1].speciesName or "Human",
		captainLanguage = case.crew and case.crew[1] and case.crew[1].languageID or "basic",
		status = I.StatusLabels[case.status] or string.upper(tostring(case.status or "UNKNOWN")),
		iff = case.iffStatus,
		suspicion = math.floor(case.suspicion or 0),
		evidenceCount = evidenceCount(case),
		evidence = evidenceList(case),
		charges = suspectedCharges(case),
		checks = checks,
		message = tostring(message or "Select the next verification or flight-control step."),
		landingOrdered = case.landingOrdered == true,
		landed = case.status == "landed",
	}
end

function I.SendCommsCase(ply, case, message, title)
	if not IsValid(ply) or not case then return end
	writeGalaxyDialogue(ply, {
		mode = "result",
		layout = "customs",
		station = "communications",
		answered = true,
		title = title or caseTitle(case),
		body = tostring(message or "Select the next verification or flight-control step."),
		customs = commsCaseSnapshot(case, message),
		contact = IsValid(case.ship) and G.ExpandedContactSnapshot(case.ship) or {
			entity = 0, name = case.displayedName, faction = case.claimedFaction,
			factionName = string.upper(case.claimedFaction), state = case.status,
		},
		choices = commsChoices(case),
	})
end

local function validCommsCase(ply, ship)
	if ply ~= G.CommsOperator or not G.CommsSessionValid(ply, G.CommsTerminal) then return nil end
	if not IsValid(ship) then return nil end
	local conversation = G.HailConversation
	if not conversation or conversation.operator ~= ply or conversation.ship ~= ship
	or CurTime() >= (conversation.expiresAt or 0) then return nil end
	return I.ByShip[ship] or I.EnsureCaseForShip(ship)
end

local function setHeld(case, held)
	if not IsValid(case.ship) then return end
	if held then
		case.ship:SetFlightVelocity(vector_origin)
		case.ship:SetShipState("holding for Republic inspection")
		case.ship:SetDieAt(0)
		case.status = "held"
	else
		case.ship:SetShipState("cleared to proceed")
		case.status = "monitoring"
		if G.AssignAutonomousShipMotion then G.AssignAutonomousShipMotion(case.ship, "inspection cleared") end
	end
end

local function shipComplies(case, purpose)
	if not case then return false end
	if case.testCompliance == "comply" then return true end
	if case.testCompliance == "refuse" then return false end
	local chance = case.trueFaction == "republic" and 0.98
		or case.trueFaction == "civilian" and 0.88
		or case.trueFaction == "pirate" and 0.42
		or case.trueFaction == "cis" and 0.18 or 0.65
	chance = chance - (case.suspicion or 0) / 260
	if purpose == "hold" then chance = chance + 0.08 end
	if case.emergency and not case.emergencyFake then chance = chance + 0.12 end
	return math.Rand(0, 1) <= math.Clamp(chance, 0.05, 0.99)
end

local function anchorReady()
	return I.Anchors and I.Anchors.ship and isvector(I.Anchors.ship.pos)
end

local function anchorAt(kind, index, fallbackPos, fallbackAng)
	local source = I.Anchors and I.Anchors[kind]
	if kind == "ship" or kind == "exit" then
		if source and isvector(source.pos) then return source.pos, source.ang or angle_zero end
	else
		local entry = istable(source) and source[index] or nil
		if entry and isvector(entry.pos) then return entry.pos, entry.ang or angle_zero end
	end
	return fallbackPos, fallbackAng or angle_zero
end

local function moveCrewToCustody(case, member, index, actor)
	if not case or not member then return nil end
	-- Persistent prison custody replaces the old instant teleport to a generic
	-- exit marker. The detainee keeps their inspection appearance and remains a
	-- physical character who must be escorted through intake and assigned a cell.
	if MilBase.Prison and MilBase.Prison.CreateDetaineeFromInspection then
		local record = MilBase.Prison.CreateDetaineeFromInspection(case, member, index, actor)
		if record then return record end
	end
	-- Compatibility fallback when the prison module is disabled or still loading.
	if not IsValid(member.entity) then return nil end
	local exit = I.Anchors and I.Anchors.exit
	if not exit or not isvector(exit.pos) then return nil end
	local ang = exit.ang or angle_zero
	local row = math.floor((math.max(1, index) - 1) / 3)
	local column = (math.max(1, index) - 1) % 3 - 1
	member.entity:SetPos(exit.pos + ang:Forward() * (row * 38) + ang:Right() * (column * 34))
	member.entity:SetAngles(Angle(0, ang.y, 0))
	return nil
end

local function removePhysical(case)
	if not case then return end
	case.removingPhysical = true
	for _, ent in ipairs(case.physicalEntities or {}) do
		if IsValid(ent) then ent:Remove() end
	end
	case.physicalEntities = {}
	case.landedShip = nil
	case.removingPhysical = nil
end

local function inspectionShipScale(case)
	if not case or not IsValid(case.ship) then return 0.62 end
	return math.max(0.05, tonumber((cfg.InspectionShipScale or {})[case.ship:GetSizeClass()]) or 0.62)
end

local function inspectionShipModelBounds(case)
	local ship = case and case.ship or nil
	local mins, maxs

	-- GetModelRenderBounds is available on entities across older GMod builds and
	-- returns the model's native local-space bounds before our landing scale.
	if IsValid(ship) and ship.GetModelRenderBounds then
		mins, maxs = ship:GetModelRenderBounds()
	end

	-- Some entity bases expose GetModelBounds instead. Keep this guarded because
	-- it is not present on every server branch/base entity.
	if (not isvector(mins) or not isvector(maxs))
		and IsValid(ship) and ship.GetModelBounds then
		mins, maxs = ship:GetModelBounds()
	end

	-- Newer branches may provide the util helper, but older servers do not.
	if (not isvector(mins) or not isvector(maxs)) and util.GetModelBounds then
		mins, maxs = util.GetModelBounds(IsValid(ship) and ship:GetModel() or "")
	end

	if not isvector(mins) or not isvector(maxs) then
		return Vector(-32, -32, -16), Vector(32, 32, 16)
	end
	return mins, maxs
end

local function inspectionShipLandingOrigin(case, floorPos, floorAng)
	local scale = inspectionShipScale(case)
	local mins = inspectionShipModelBounds(case)
	local clearance = math.max(0, tonumber(cfg.InspectionShipFloorClearance) or 6)
	local vertical = math.max(0, -mins.z * scale) + clearance
	return floorPos + Vector(0, 0, vertical), floorAng or angle_zero, scale
end

local function inspectionApproachPath(finalPos, finalAng)
	local points = {}
	local configured = I.Anchors and I.Anchors.approach or {}
	local slots = {}
	for slot, entry in pairs(configured or {}) do
		if entry and isvector(entry.pos) then slots[#slots + 1] = tonumber(slot) or 1 end
	end
	table.sort(slots)
	for _, slot in ipairs(slots) do
		local entry = configured[slot]
		points[#points + 1] = { pos = entry.pos, ang = entry.ang or finalAng }
	end
	if #points == 0 then
		local distance = math.max(400, tonumber(cfg.InspectionApproachDefaultDistance) or 1500)
		local height = math.max(80, tonumber(cfg.InspectionApproachDefaultHeight) or 360)
		local forward = finalAng:Forward()
		points = {
			{ pos = finalPos - forward * distance + Vector(0, 0, height), ang = finalAng },
			{ pos = finalPos - forward * (distance * 0.48) + Vector(0, 0, height * 0.52), ang = finalAng },
			{ pos = finalPos - forward * 260 + Vector(0, 0, 92), ang = finalAng },
		}
	end
	if #points == 0 or points[#points].pos:DistToSqr(finalPos) > 4 then
		points[#points + 1] = { pos = finalPos, ang = finalAng }
	else
		points[#points].pos = finalPos
		points[#points].ang = finalAng
	end
	for index = 1, #points - 1 do
		local delta = points[index + 1].pos - points[index].pos
		if delta:LengthSqr() > 1 then
			local travel = delta:Angle()
			travel.r = 0
			points[index].ang = travel
		end
	end
	points[#points].ang = finalAng
	return points
end

local function inspectionHangarGroup()
	local key = tostring(cfg.InspectionHangarGroup or "main")
	if N and N.CleanKey then key = N.CleanKey(key) end
	return key ~= "" and key or "main"
end

local function appendLandingPoint(points, pos, ang, joinDistance)
	if not isvector(pos) then return end
	local previous = points[#points]
	if previous and previous.pos:DistToSqr(pos) <= joinDistance * joinDistance then
		previous.pos = pos
		previous.ang = isangle(ang) and ang or previous.ang
		return
	end
	points[#points + 1] = {
		pos = pos,
		ang = isangle(ang) and ang or angle_zero,
	}
end

-- A 3D-skybox contact cannot literally cross into normal map coordinates.
-- Match squadron recovery by replacing it with a full-scale map entity at the
-- first recorded recovery node, then flying that entity through the same door
-- corridor and into the customs landing position.
local function inspectionPhysicalPath(finalPos, finalAng)
	local localPath = inspectionApproachPath(finalPos, finalAng)
	if cfg.InspectionUseNavalRecoveryRoute == false
	or not N or not N.HangarPath then return localPath, false end

	local recovery = N.HangarPath(inspectionHangarGroup(), "return") or {}
	if #recovery < 2 then return localPath, false end

	local joinDistance = math.max(8,
		tonumber(cfg.InspectionRecoveryRouteJoinDistance) or 96)
	local points = {}
	for _, pos in ipairs(recovery) do
		appendLandingPoint(points, pos, nil, joinDistance)
	end

	-- Join the customs-only route at the waypoint nearest the final naval
	-- recovery node. This supports curved final approaches while avoiding a
	-- turn back toward old customs nodes that were recorded outside the door.
	local joinIndex, joinDistanceSqr
	local recoveryEnd = points[#points] and points[#points].pos or finalPos
	for index = 1, math.max(0, #localPath - 1) do
		local distance = recoveryEnd:DistToSqr(localPath[index].pos)
		if not joinDistanceSqr or distance < joinDistanceSqr then
			joinIndex, joinDistanceSqr = index, distance
		end
	end
	for index = joinIndex or #localPath, math.max(0, #localPath - 1) do
		local point = localPath[index]
		if point then appendLandingPoint(points, point.pos, point.ang, joinDistance) end
	end
	appendLandingPoint(points, finalPos, finalAng, joinDistance)

	for index = 1, #points - 1 do
		local delta = points[index + 1].pos - points[index].pos
		if delta:LengthSqr() > 1 then
			local travel = delta:Angle()
			travel.r = 0
			points[index].ang = travel
		end
	end
	points[#points].ang = finalAng
	return points, true
end

local function inspectionPathDuration(path)
	if not istable(path) or #path < 2 then return 0 end
	local speed = math.max(80, tonumber(cfg.InspectionApproachSpeed) or 520)
	local minimum = math.max(0.3,
		tonumber(cfg.InspectionApproachMinimumDuration) or 1.2)
	local maximum = math.max(minimum,
		tonumber(cfg.InspectionApproachMaximumDuration) or 8)
	local total = math.max(0,
		tonumber(cfg.InspectionApproachSettleTime) or 0.8)
	for index = 1, #path - 1 do
		local distance = path[index].pos:Distance(path[index + 1].pos)
		total = total + math.Clamp(distance / speed, minimum, maximum)
	end
	return total
end

local function finishInspectionHangar(case, reason, closeDoors)
	if not case or not case.hangarOperationActive then return end
	case.hangarOperationActive = false
	local group = case.inspectionHangarGroup or inspectionHangarGroup()
	if closeDoors ~= false and cfg.InspectionCloseLinkedHangarDoors ~= false
	and N and N.CloseHangar then
		N.CloseHangar(group, reason or "Customs vessel secured; sealing inspection bay")
	elseif N and N.ReleaseExternalHangarOperation then
		N.ReleaseExternalHangarOperation(group)
	end
end

local function spawnInspectionCrewAndCargo(case, shipFloorPos, shipAng)
	for index, member in ipairs(case.crew or {}) do
		local fallback = shipFloorPos + shipAng:Forward() * (90 + index * 34)
			+ shipAng:Right() * ((index % 2 == 0 and 1 or -1) * 48)
		local pos, ang = anchorAt("crew", index, fallback, shipAng)
		local ent = ents.Create("mb_inspection_crew")
		if IsValid(ent) then
			local models = cfg.CrewModels or {}
			local model = member.model or models[((index - 1) % math.max(1, #models)) + 1] or cfg.CrewModel
			if not util.IsValidModel(model or "") then
				local humanModel, humanAlias = cfg.CrewModel, ""
				if MilBase.ResolveSpeciesModel then
					humanModel, humanAlias = MilBase.ResolveSpeciesModel("human", "crew")
				end
				model = util.IsValidModel(humanModel or "") and humanModel or cfg.CrewModel
				member.speciesID = "human"
				member.speciesName = "Human"
				member.languageID = "basic"
				member.modelAlias = humanAlias or ""
			end
			if util.IsValidModel(model or "") then ent:SetModel(model) member.model = model end
			if member.skin then ent:SetSkin(math.max(0, tonumber(member.skin) or 0)) end
			for bodygroup, value in pairs(member.bodygroups or {}) do ent:SetBodygroup(tonumber(bodygroup) or 0, tonumber(value) or 0) end
			ent:SetPos(pos)
			ent:SetAngles(Angle(0, ang.y, 0))
			ent:SetCaseID(case.id)
			ent:SetCrewIndex(index)
			ent:SetCrewName(member.name)
			ent:SetCrewRole(member.role)
			if ent.SetSpeciesName then ent:SetSpeciesName(member.speciesName or "Human") end
			local language = MilBase.GetLanguage
				and MilBase.GetLanguage(member.languageID or "basic") or {}
			if ent.SetLanguageName then
				ent:SetLanguageName(tostring(language.name or member.languageID or "Galactic Basic"))
			end
			ent:SetArrested(member.arrested == true)
			ent:Spawn()
			ent:Activate()
			member.model = ent:GetModel()
			member.skin = ent:GetSkin()
			member.bodygroups = member.bodygroups or {}
			for bodygroup = 0, math.max(0, ent:GetNumBodyGroups() - 1) do
				member.bodygroups[tostring(bodygroup)] = ent:GetBodygroup(bodygroup)
			end
			ent.mb_inspectionCaseID = case.id
			member.entity = ent
			case.physicalEntities[#case.physicalEntities + 1] = ent
		end
	end

	for index, cargo in ipairs(case.cargo or {}) do
		local fallback = shipFloorPos + shipAng:Forward() * (20 + math.floor((index - 1) / 3) * 54)
			+ shipAng:Right() * ((index - 2) * 62)
		local pos, ang = anchorAt("cargo", index, fallback, shipAng)
		local ent = ents.Create("mb_inspection_cargo")
		if IsValid(ent) then
			if util.IsValidModel(cfg.CargoModel or "") then ent:SetModel(cfg.CargoModel) end
			ent:SetPos(pos)
			ent:SetAngles(ang)
			ent:SetCaseID(case.id)
			ent:SetCargoIndex(index)
			ent:SetCargoLabel("CONTAINER " .. string.format("%02d", index))
			ent:SetSearched(cargo.searched == true)
			ent:SetSeized(cargo.seized == true)
			ent:Spawn()
			ent:Activate()
			ent.mb_inspectionCaseID = case.id
			cargo.entity = ent
			case.physicalEntities[#case.physicalEntities + 1] = ent
		end
	end
end

function I.CompletePhysicalLanding(caseID, landed)
	local case = I.Cases[tostring(caseID or "")]
	if not case or not IsValid(landed) or landed ~= case.landedShip then return false end
	if case.status == "landed" then return true end
	landed:SetInspectionStatus("USE DATAPAD: CUSTOMS CASES")
	landed:SetSolid(SOLID_NONE)
	landed:SetMoveType(MOVETYPE_NONE)
	local floorPos, floorAng = anchorAt("ship", 1, landed:GetPos(), landed:GetAngles())
	spawnInspectionCrewAndCargo(case, floorPos, floorAng)
	case.status = "landed"
	case.physicalStartedAt = unix()
	case.landingCompletedAt = unix()
	I.SaveCase(case)
	timer.Simple(math.max(0, tonumber(cfg.InspectionDoorCloseDelay) or 1.2), function()
		if I.Cases[case.id] ~= case then return end
		finishInspectionHangar(case,
			case.displayedName .. " landed; securing inspection bay", true)
	end)
	if G.AnnounceNavy then
		G.AnnounceNavy(case.displayedName .. " has completed its landing in the inspection bay. Open CUSTOMS CASES on a datapad to coordinate the search.",
			Color(90, 180, 245), "[CUSTOMS] ")
	end
	return true
end

function I.SpawnPhysicalInspection(case, animateApproach)
	if not case or not IsValid(case.ship) or not anchorReady() then return false end
	removePhysical(case)
	case.physicalEntities = case.physicalEntities or {}
	local floorPos, floorAng = anchorAt("ship", 1)
	local finalPos, finalAng, scale = inspectionShipLandingOrigin(case, floorPos, floorAng)
	local path, usedRecoveryRoute
	if animateApproach then
		path, usedRecoveryRoute = inspectionPhysicalPath(finalPos, finalAng)
	else
		path, usedRecoveryRoute = { { pos = finalPos, ang = finalAng } }, false
	end
	if animateApproach and cfg.InspectionRequireRecoveryRoute == true
	and not usedRecoveryRoute then
		return false, "No naval recovery route is configured for "
			.. string.upper(inspectionHangarGroup()) .. "."
	end
	case.landingDeadline = CurTime() + math.max(
		math.max(5, tonumber(cfg.LandingTimeout) or 45),
		inspectionPathDuration(path) + 15)
	local start = path[1]
	local landed = ents.Create("mb_inspection_ship")
	if not IsValid(landed) then return false end
	landed:SetModel(case.ship:GetModel())
	landed:SetPos(start.pos)
	landed:SetAngles(start.ang or finalAng)
	landed:SetCaseID(case.id)
	landed:SetDisplayName(case.displayedName)
	landed:SetInspectionStatus(animateApproach and "AUTOMATED LANDING IN PROGRESS" or "USE DATAPAD: CUSTOMS CASES")
	landed:Spawn()
	landed:Activate()
	landed:SetModelScale(scale, 0)
	landed:SetSolid(SOLID_NONE)
	landed:SetMoveType(MOVETYPE_NONE)
	landed.mb_inspectionCaseID = case.id
	case.landedShip = landed
	case.physicalEntities[#case.physicalEntities + 1] = landed
	case.inspectionFloorPos = floorPos
	case.inspectionFloorAng = floorAng
	case.usedNavalRecoveryRoute = usedRecoveryRoute == true

	if G.EmitHyperspaceBurst then
		G.EmitHyperspaceBurst(case.ship:GetPos(), case.ship:GetForward(),
			Color(90, 180, 245), false)
	end
	case.ship:SetNoDraw(true)
	case.ship:SetInvulnerable(true)
	case.ship:SetFlightVelocity(vector_origin)
	case.ship:SetShipState(animateApproach and "transferred to physical inspection approach" or "landed for physical inspection")
	case.status = "landing"
	I.SaveCase(case)
	if G.EmitHyperspaceBurst then
		timer.Simple(0.05, function()
			if IsValid(landed) then
				G.EmitHyperspaceBurst(landed:GetPos(), landed:GetForward(),
					Color(90, 180, 245), false)
			end
		end)
	end

	if animateApproach and #path > 1 and landed.BeginInspectionLanding then
		landed:BeginInspectionLanding(path,
			math.max(80, tonumber(cfg.InspectionApproachSpeed) or 520),
			math.max(0.3, tonumber(cfg.InspectionApproachMinimumDuration) or 1.2),
			math.max(1, tonumber(cfg.InspectionApproachMaximumDuration) or 8),
			math.max(0, tonumber(cfg.InspectionApproachSettleTime) or 0.8))
		if G.AnnounceNavy then
			G.AnnounceNavy(case.displayedName .. (usedRecoveryRoute
				and " has transferred from local-space tracking into the map recovery corridor."
				or " is entering the configured inspection-bay approach corridor."),
				Color(90, 180, 245), "[CUSTOMS] ")
		end
	else
		landed:SetPos(finalPos)
		landed:SetAngles(finalAng)
		I.CompletePhysicalLanding(case.id, landed)
	end
	return true
end

function I.BeginLanding(case, ply)
	if not case or not IsValid(case.ship) then return false, "Contact is no longer available." end
	if not anchorReady() then return false, "No inspection-bay ship anchor is configured for this map." end
	if case.status == "landing" or case.status == "landed" then return true, "Landing sequence is already active." end
	case.status = "landing"
	case.landingOrdered = true
	case.ship:SetFlightVelocity(vector_origin)
	case.ship:SetShipState("awaiting Republic inspection-bay clearance")
	case.ship:SetDieAt(0)
	case.landingDeadline = CurTime() + math.max(5, tonumber(cfg.LandingTimeout) or 45)
	case.inspectionHangarGroup = inspectionHangarGroup()
	I.SaveCase(case)

	local function abortLanding(message)
		if I.Cases[case.id] ~= case then return end
		case.status = "held"
		if IsValid(case.ship) then
			case.ship:SetNoDraw(false)
			case.ship:SetInvulnerable(false)
			case.ship:SetShipState("landing corridor unavailable")
		end
		finishInspectionHangar(case, message or "Customs landing aborted", true)
		I.SaveCase(case)
		if G.AnnounceNavy then
			G.AnnounceNavy(message or (case.displayedName
				.. " could not enter the inspection-bay corridor."),
				Color(235, 175, 70), "[CUSTOMS] ")
		end
	end

	local function transferIntoMap()
		if I.Cases[case.id] ~= case or case.status ~= "landing" then
			finishInspectionHangar(case, "Customs landing cancelled", true)
			return
		end
		if not IsValid(case.ship) then
			finishInspectionHangar(case, "Customs contact lost", true)
			return
		end
		local ok, err = I.SpawnPhysicalInspection(case, true)
		if not ok then abortLanding(err) end
	end

	local function openDoorsAndTransfer()
		-- Reaching this callback means the shared naval flight deck has assigned
		-- this case its operation slot, including when it was queued earlier.
		case.hangarOperationActive = true
		if I.Cases[case.id] ~= case or case.status ~= "landing" then
			finishInspectionHangar(case, "Customs landing cancelled", true)
			return
		end
		if not IsValid(case.ship) then
			finishInspectionHangar(case, "Customs contact lost", true)
			return
		end
		case.landingDeadline = CurTime()
			+ math.max(5, tonumber(cfg.LandingTimeout) or 45)
		case.ship:SetShipState("waiting for inspection-bay doors")
		if cfg.InspectionOpenLinkedHangarDoors ~= false and N and N.OpenHangar then
			N.OpenHangar(case.inspectionHangarGroup,
				case.displayedName .. " customs recovery requested", function(_, doorCount)
					if I.Cases[case.id] ~= case or case.status ~= "landing" then
						finishInspectionHangar(case, "Customs landing cancelled", true)
						return
					end
					if not IsValid(case.ship) then
						finishInspectionHangar(case, "Customs contact lost", true)
						return
					end
					case.ship:SetShipState("cleared into map recovery corridor")
					timer.Simple(math.max(0, tonumber(cfg.InspectionMapTransitionDelay) or 0.35),
						transferIntoMap)
					if doorCount <= 0 and G.AnnounceNavy then
						G.AnnounceNavy("No linked doors were found for "
							.. string.upper(case.inspectionHangarGroup)
							.. "; customs recovery is continuing through the recorded route.",
							Color(235, 175, 70), "[CUSTOMS] ")
					end
				end)
		else
			timer.Simple(math.max(0, tonumber(cfg.InspectionMapTransitionDelay) or 0.35),
				transferIntoMap)
		end
	end

	local function requestDeck()
		if N and N.RequestExternalHangarOperation then
			local _, position, state = N.RequestExternalHangarOperation(
				case.inspectionHangarGroup,
				case.displayedName .. " customs landing",
				openDoorsAndTransfer)
			if state == "queued" then
				case.ship:SetShipState("queued for inspection-bay recovery")
				if G.AnnounceNavy then
					G.AnnounceNavy(case.displayedName .. " is queued behind another flight-deck operation"
						.. (tonumber(position) and (" (position " .. position .. ").") or "."),
						Color(90, 180, 245), "[CUSTOMS] ")
				end
			end
		else
			openDoorsAndTransfer()
		end
	end

	timer.Simple(math.max(0.5, tonumber(cfg.LandingDelay) or 2.5), function()
		if I.Cases[case.id] ~= case or case.status ~= "landing" then return end
		requestDeck()
	end)
	return true, "Landing clearance transmitted. The vessel will wait for the linked hangar doors, transfer into the map at the naval recovery route, and then land at the customs anchor."
end

local function fleeInspection(case, reason)
	if not case or not IsValid(case.ship) then return end
	case.status = "fleeing"
	case.ship:SetShipState("evading Republic inspection")
	case.ship:SetHostile(false)
	case.ship:SetInvulnerable(false)
	case.ship:SetFlightVelocity(case.ship:GetForward() * 75)
	I.AddEvidence(case, "evasion", "The vessel refused a lawful inspection order and attempted to flee.", 1)
	if G.AssignAutonomousShipMotion then G.AssignAutonomousShipMotion(case.ship, reason or "inspection evasion") end
end

local function startHostility(case, reason)
	if not case or not IsValid(case.ship) then return end
	case.identityConfirmed = true
	case.ship:SetNoDraw(false)
	case.ship:SetFaction(case.trueFaction)
	case.ship:SetHostile(true)
	case.ship:SetShipState(reason or "weapons activated during inspection")
	I.AddEvidence(case, "hostile_action", "The vessel activated weapons against Republic forces.", 2)
	if G.StartContactEngagement and IsValid(G.CommsOperator) then
		G.StartContactEngagement(G.CommsOperator, case.ship)
	end
end

local baseDialogueChoices = G.DialogueChoicesForShip
function G.DialogueChoicesForShip(ship)
	local choices = baseDialogueChoices(ship)
	local case = I.ByShip[ship] or I.EnsureCaseForShip(ship)
	if not case then return choices end
	for _, choice in ipairs(choices) do
		if choice.id == "inspection_menu" then return choices end
	end
	table.insert(choices, math.max(1, #choices), {
		id = "inspection_menu",
		label = "OPEN CUSTOMS / INSPECTION CASE",
	})
	return choices
end

local inspectionActions = {
	inspection_menu = true, inspection_talk = true, inspection_registry = true, inspection_manifest = true,
	inspection_crew = true, inspection_engine = true, inspection_mass = true,
	inspection_flightplan = true, inspection_hold = true, inspection_land = true,
	inspection_mark = true, inspection_disable = true,
	inspection_clear_space = true, inspection_leave = true,
}

local baseDialogueAction = G.HandleDialogueAction
function G.HandleDialogueAction(ply, ship, action)
	if not inspectionActions[action] then return baseDialogueAction(ply, ship, action) end
	local case = validCommsCase(ply, ship)
	if not case then
		notify(ply, "The customs channel is no longer active.", "warn")
		return
	end
	if action == "inspection_talk" or action == "inspection_hold" or action == "inspection_land" then
		if I.OpenRemoteCaptainConversation then
			I.OpenRemoteCaptainConversation(ply, case)
		else
			notify(ply, "The captain channel is still initialising.", "warn")
		end
		return
	end
	local message = "Customs case opened. Scanner results are evidence, not automatic proof of allegiance."
	if action == "inspection_registry" then
		case.checks.registry = "queried"
		if case.iffQuality == "legitimate" then
			case.iffStatus = "REGISTRY VERIFIED"
			case.checks.registry = "verified"
			message = "Republic registry confirms the transmitted identity and captain licence."
		elseif case.iffQuality == "poor" or case.iffQuality == "basic" then
			case.iffStatus = "FALSE IFF CONFIRMED"
			case.checks.registry = "false checksum"
			I.AddEvidence(case, "false_iff", "Registry checksum does not match the transmitted vessel identity.", 1, ply)
			message = "Registry authentication fails. The identity packet contains an invalid checksum."
		elseif case.iffQuality == "stolen" then
			case.iffStatus = "STOLEN IDENTITY CONFIRMED"
			case.checks.registry = "stolen"
			I.AddEvidence(case, "stolen_registry", "The transmitted identity belongs to a stolen or destroyed vessel.", 2, ply)
			message = "The IFF code is authentic, but Republic records list its registered vessel as stolen or destroyed."
		elseif case.iffQuality == "cloned" then
			case.iffStatus = "DUPLICATE IFF CONFIRMED"
			case.checks.registry = "duplicate active code"
			I.AddEvidence(case, "duplicate_iff", "The same IFF identity is active on another registered vessel.", 2, ply)
			message = "The identity is simultaneously active elsewhere. This contact is transmitting a cloned IFF."
		else
			case.iffStatus = "PARTIAL REGISTRY MATCH"
			case.checks.registry = "partial match"
			message = "The registry accepts the encryption but cannot match the current hull and ownership history."
			I.AddEvidence(case, "partial_registry", "Registry ownership and hull records are inconsistent.", 1, ply)
		end
	elseif action == "inspection_manifest" then
		case.checks.manifest = "received"
		message = "The captain transmits a manifest declaring: " .. declaredCargoLabel(case)
			.. ". Declared mass: " .. case.declaredMass .. " units."
	elseif action == "inspection_crew" then
		case.checks.crew = case.crewManifestValid and "received" or "incomplete"
		local names = {}
		for index, member in ipairs(case.crew) do
			if case.crewManifestValid or index < #case.crew then
				names[#names + 1] = member.role .. " " .. member.name
			end
		end
		message = "Crew manifest: " .. table.concat(names, "; ") .. "."
		if not case.crewManifestValid then
			I.AddEvidence(case, "crew_mismatch", "Life signs exceed the submitted crew manifest.", 1, ply)
			message = message .. " Sensor life signs indicate at least one undeclared person aboard."
		end
	elseif action == "inspection_engine" then
		if not G.ScannedShips[ship] then
			message = "Tactical Scanner must resolve the contact before system telemetry can be compared."
		else
			case.checks.engine = "compared"
			if case.emergency then
				if case.emergencyFake then
					I.AddEvidence(case, "fake_emergency",
						"System telemetry contradicts the captain's declared emergency.", 1, ply)
					message = "Telemetry is normal. The declared " .. case.emergency
						.. " is not supported by sensor readings."
				else
					message = "Telemetry confirms a genuine " .. case.emergency
						.. " affecting " .. string.upper(tostring(case.emergencySystem or "ship systems"))
						.. ". Engineering assistance is recommended."
				end
			elseif not case.modelRegistryMatch then
				I.AddEvidence(case, "engine_mismatch", "Drive signature does not match the registered ship class.", 1, ply)
				message = "The drive signature belongs to a different ship class than the transmitted registry."
			else
				message = "System and drive signatures are consistent with the submitted registry."
			end
		end
	elseif action == "inspection_mass" then
		if not G.ScannedShips[ship] then
			message = "Tactical Scanner must resolve the contact before cargo mass can be compared."
		else
			case.checks.mass = "compared"
			local actual = actualCargoMass(case)
			local difference = math.abs(actual - case.declaredMass)
			message = "Declared cargo mass: " .. case.declaredMass
				.. ". Detected mass: " .. actual .. "."
			if difference >= 6 then
				I.AddEvidence(case, "mass_mismatch", "Detected cargo mass does not match the submitted manifest.", 1, ply)
				message = message .. " The difference exceeds civilian freight tolerance."
			else
				message = message .. " The values are within normal tolerance."
			end
		end
	elseif action == "inspection_flightplan" then
		case.checks.flightplan = case.flightPlanValid and "verified" or "conflict"
		if case.flightPlanValid then
			message = "The filed origin, destination and hyperspace route are consistent with local traffic records."
		else
			I.AddEvidence(case, "route_conflict", "The contact's course conflicts with its submitted flight plan.", 1, ply)
			message = "The filed destination does not match the contact's actual approach vector or recent route history."
		end
	elseif action == "inspection_hold" then
		if shipComplies(case, "hold") then
			setHeld(case, true)
			message = "The captain acknowledges and holds position for Republic checks."
		else
			fleeInspection(case, "refused hold order")
			message = "The contact refuses the hold order and begins evasive manoeuvres."
		end
	elseif action == "inspection_land" then
		case.landingOrdered = true
		if not anchorReady() then
			message = "No physical inspection-bay anchor is configured. Staff must use /inspectionanchor ship first."
		elseif shipComplies(case, "land") or case.status == "disabled" then
			local _, result = I.BeginLanding(case, ply)
			message = result
		else
			fleeInspection(case, "refused landing order")
			message = "The captain refuses to land and attempts to leave the inspection corridor."
			if case.trueFaction == "cis" and math.Rand(0, 1) < 0.45 then startHostility(case, "CIS weapons activated") end
		end
	elseif action == "inspection_casefile" then
		message = "Current evidence and verification history follow."
	elseif action == "inspection_mark" then
		case.suspicion = math.max(case.suspicion or 0, 45)
		case.markedSuspicious = true
		message = "The contact is marked amber for continued observation. This is not proof of a crime."
	elseif action == "inspection_disable" then
		case.disableAuthorized = true
		message = "Disabling fire authorised. Pilots should target engines or manoeuvring systems and avoid destroying the vessel."
		if G.AnnounceNavy then
			G.AnnounceNavy("Disabling fire authorised against " .. case.displayedName .. ". Target engines only.",
				Color(235, 175, 70), "[CUSTOMS] ")
		end
	elseif action == "inspection_clear_space" then
		local legal = caseLegal(case)
		if legal then
			message = "The contact is cleared to continue its filed route."
		else
			message = "The contact is cleared despite unresolved criminal indicators. The decision has been recorded for review."
			case.wrongfulActions = (case.wrongfulActions or 0) + 1
		end
		I.ResolveCase(case, "cleared", ply, legal)
	elseif action == "inspection_leave" then
		message = "The contact is denied local access and ordered to leave Republic-controlled space."
		I.ResolveCase(case, "denied", ply, true)
	end
	I.SaveCase(case)
	if G.AddCommsHistory and IsValid(case.ship) then
		G.AddCommsHistory("customs", case.ship, message, ply)
	end
	if I.Cases[case.id] == case and IsValid(case.ship) then
		I.SendCommsCase(ply, case, message)
	else
		writeGalaxyDialogue(ply, {
			mode = "result", station = "communications", answered = true,
			title = "CUSTOMS CASE CLOSED", body = message,
			contact = { entity = 0, name = case.displayedName, faction = "neutral", factionName = "CASE CLOSED", state = case.status },
			choices = { { id = "contacts", label = "RETURN TO CONTACTS" } },
		})
	end
end

local function physicalActions(case, kind, index)
	local actions = {}
	if kind == "ship" then
		actions = {
			{ id = "casefile", label = "REVIEW CASE FILE" },
			{ id = "diagnose_failure", label = "DIAGNOSE REPORTED FAILURE" },
			{ id = "repair_failure", label = "REPAIR CONFIRMED FAILURE" },
			{ id = "search_hidden", label = "SEARCH FOR HIDDEN COMPARTMENTS" },
			{ id = "attach_tracker", label = "ATTACH TRACKING BEACON" },
			{ id = "confiscate", label = "CONFISCATE ILLEGAL CARGO" },
			{ id = "fine", label = "ISSUE FINE AND RELEASE" },
			{ id = "arrest_all", label = "DETAIN ALL CREW" },
			{ id = "impound", label = "IMPOUND VESSEL" },
			{ id = "clear", label = "CLEAR AND RELEASE" },
		}
	elseif kind == "crew" then
		actions = {
			{ id = "talk", label = "BEGIN CINEMATIC INTERVIEW" },
			{ id = "search_crew", label = "SEARCH CREW MEMBER" },
			{ id = "arrest_crew", label = "DETAIN CREW MEMBER" },
		}
	elseif kind == "cargo" then
		actions = {
			{ id = "inspect_seal", label = "INSPECT CONTAINER SEAL" },
			{ id = "scan_container", label = "SCAN CONTAINER" },
			{ id = "open_container", label = "OPEN AND SEARCH" },
			{ id = "seize_container", label = "SEIZE CONTAINER" },
		}
	end
	return actions
end

local function physicalBody(case, kind, index, message)
	local body = caseBody(case, message)
	if kind == "crew" then
		local member = case.crew[index]
		if member then
			local language = MilBase.GetLanguage
				and MilBase.GetLanguage(member.languageID or "basic") or {}
			body = body .. "\n\nCREW MEMBER\n" .. member.name .. " — " .. member.role
				.. "\nSPECIES: " .. string.upper(tostring(member.speciesName or "Human"))
				.. "\nNATIVE LANGUAGE: " .. string.upper(tostring(
					language.name or member.languageID or "Galactic Basic"))
				.. "\nSEARCHED: " .. (member.searched and "YES" or "NO")
				.. "\nDETAINED: " .. (member.arrested and "YES" or "NO")
			if #member.statements > 0 then body = body .. "\nSTATEMENTS:\n- " .. table.concat(member.statements, "\n- ") end
		end
	elseif kind == "cargo" then
		local cargo = case.cargo[index]
		if cargo then
			body = body .. "\n\nCONTAINER " .. string.format("%02d", index)
				.. "\nDECLARED: " .. cargo.declared
				.. "\nSEAL: " .. (cargo.sealed and "INTACT" or "BROKEN / REPLACED")
				.. "\nCONTENTS: " .. (cargo.searched and cargo.actual or "NOT YET CONFIRMED")
				.. "\nSEIZED: " .. (cargo.seized and "YES" or "NO")
		end
	end
	return body
end

local function physicalTarget(case, kind, index)
	if not case then return nil end
	if kind == "ship" then return case.landedShip end
	if kind == "crew" then
		local member = case.crew and case.crew[index]
		return member and member.entity or nil
	end
	if kind == "cargo" then
		local cargo = case.cargo and case.cargo[index]
		return cargo and cargo.entity or nil
	end
	return nil
end

local function physicalTargetInRange(ply, target, kind)
	if not IsValid(ply) or not IsValid(target) then return false end
	local allowance = math.max(64, tonumber(cfg.InteractionDistance) or 180)
	if kind == "ship" then
		allowance = allowance + math.min(420, math.max(0, target:BoundingRadius() * 0.45))
	end
	return ply:EyePos():DistToSqr(target:NearestPoint(ply:EyePos())) <= allowance * allowance
end

local handlePhysicalAction

function I.OpenPhysicalUI(ply, caseID, kind, index, message)
	-- Legacy entity interaction entry-point. Physical inspection is now managed
	-- through the Customs Cases datapad app instead of a separate ship window.
	return I.OpenDatapad(ply, caseID, kind, index, message)
end

local function datapadCaseRows()
	local rows = {}
	for _, case in pairs(I.Cases or {}) do
		if case and not case.resolved and case.status ~= "closed" then
			rows[#rows + 1] = {
				id = case.id,
				name = case.displayedName,
				status = case.status,
				statusLabel = I.StatusLabels[case.status] or string.upper(tostring(case.status or "UNKNOWN")),
				evidence = evidenceCount(case),
				suspicion = math.floor(case.suspicion or 0),
				createdAt = tonumber(case.createdAt) or 0,
			}
		end
	end
	table.sort(rows, function(a, b)
		local aLanded = a.status == "landed" and 1 or 0
		local bLanded = b.status == "landed" and 1 or 0
		if aLanded ~= bLanded then return aLanded > bLanded end
		return a.createdAt > b.createdAt
	end)
	return rows
end

local function datapadSubjects(case)
	local subjects = {
		{ kind = "ship", index = 0, label = "VESSEL / CASE FILE", state = case.status == "landed" and "LANDED" or string.upper(tostring(case.status or "ACTIVE")) },
	}
	if case.status ~= "landed" then return subjects end
	for index, member in ipairs(case.crew or {}) do
		subjects[#subjects + 1] = {
			kind = "crew", index = index,
			label = member.name .. " / " .. tostring(member.speciesName or "Human")
				.. " / " .. member.role,
			state = member.arrested and "DETAINED" or member.searched and "SEARCHED" or "AWAITING INTERVIEW",
		}
	end
	for index, cargo in ipairs(case.cargo or {}) do
		subjects[#subjects + 1] = {
			kind = "cargo", index = index,
			label = "CONTAINER " .. string.format("%02d", index),
			state = cargo.seized and "SEIZED" or cargo.searched and "SEARCHED" or "UNSEARCHED",
		}
	end
	return subjects
end

local function datapadActionRows(case, kind, index)
	local rows = {}
	if case.status ~= "landed" then return rows end
	for _, action in ipairs(physicalActions(case, kind, index)) do
		local id = tostring(action.id or "")
		rows[#rows + 1] = {
			id = id,
			label = action.label,
			danger = id == "arrest_crew" or id == "arrest_all" or id == "impound"
				or id == "fine" or id == "confiscate" or id == "seize_container",
		}
	end
	return rows
end

local function normaliseDatapadSelection(ply, requested)
	requested = istable(requested) and requested or {}
	local stored = IsValid(ply) and ply.mb_customsDatapadSelection or {}
	local caseID = I.Clean(requested.caseID or stored.caseID, 48)
	local case = I.Cases[caseID]
	if not case or case.resolved then
		local rows = datapadCaseRows()
		caseID = rows[1] and rows[1].id or ""
		case = I.Cases[caseID]
	end
	local kind = I.Clean(requested.kind or stored.kind or "ship", 16)
	if kind ~= "ship" and kind ~= "crew" and kind ~= "cargo" then kind = "ship" end
	local index = math.max(0, math.floor(tonumber(requested.index ~= nil and requested.index or stored.index) or 0))
	if kind == "ship" then index = 0 end
	if kind == "crew" and not (case and case.crew and case.crew[index]) then kind, index = "ship", 0 end
	if kind == "cargo" and not (case and case.cargo and case.cargo[index]) then kind, index = "ship", 0 end
	local selection = { caseID = caseID, kind = kind, index = index }
	if IsValid(ply) then ply.mb_customsDatapadSelection = selection end
	return case, selection
end

local function datapadPayload(ply, requested, message)
	local case, selection = normaliseDatapadSelection(ply, requested)
	local payload = {
		cases = datapadCaseRows(),
		selection = selection,
	}
	if not case then return payload end
	local kind, index = selection.kind, selection.index
	local target = physicalTarget(case, kind, index)
	local nearby = case.status == "landed" and physicalTargetInRange(ply, target, kind)
	local title = kind == "crew" and "CREW INTERVIEW"
		or kind == "cargo" and "CARGO SEARCH" or "VESSEL / CASE FILE"
	payload.selected = {
		id = case.id,
		name = case.displayedName,
		title = caseTitle(case),
		subjectTitle = title,
		status = case.status,
		statusLabel = I.StatusLabels[case.status] or string.upper(tostring(case.status or "UNKNOWN")),
		suspicion = math.floor(case.suspicion or 0),
		evidence = evidenceCount(case),
		nearby = nearby,
		body = case.status == "landed" and physicalBody(case, kind, index, message)
			or caseBody(case, message or "The vessel has not completed its physical landing sequence."),
		actions = datapadActionRows(case, kind, index),
		subjects = datapadSubjects(case),
	}
	return payload
end

function I.OpenDatapad(ply, caseID, kind, index, message)
	if cfg.EnableDatapadInspection == false then
		notify(ply, "Datapad inspection workflow is disabled.", "warn")
		return false
	end
	if not canInspect(ply) then
		notify(ply, "Republic inspection credentials are required.", "warn")
		return false
	end
	local datapadClass = tostring((MilBase.Config and MilBase.Config.DatapadWeaponClass) or "mb_datapad")
	if not ply:IsAdmin() and datapadClass ~= "" and not ply:HasWeapon(datapadClass) then
		notify(ply, "Equip an RP Datapad to manage this inspection.", "warn")
		return false
	end
	ply.mb_customsDatapadSelection = {
		caseID = I.Clean(caseID, 48),
		kind = I.Clean(kind or "ship", 16),
		index = math.max(0, math.floor(tonumber(index) or 0)),
	}
	ply.mb_customsDatapadMessage = I.Clean(message, 300)
	if MilBase.DatapadOpen then
		MilBase.DatapadOpen(ply, "customs_cases")
		return true
	end
	notify(ply, "The RP Datapad service is unavailable.", "warn")
	return false
end

function I.HandleDatapadRequest(ply, action, data, sendData)
	if cfg.EnableDatapadInspection == false or not canInspect(ply) then return end
	data = istable(data) and data or {}
	action = tostring(action or "get")
	local message = ply.mb_customsDatapadMessage
	ply.mb_customsDatapadMessage = nil
	local case, selection = normaliseDatapadSelection(ply, data)
	if action == "action" then
		if not case or case.status ~= "landed" then
			message = "The selected case is not ready for physical inspection."
		else
			local target = physicalTarget(case, selection.kind, selection.index)
			if not physicalTargetInRange(ply, target, selection.kind) then
				message = "Move closer to the selected inspection subject before performing that action."
			else
				local actionID = I.Clean(data.action, 40)
				local allowed = false
				for _, row in ipairs(physicalActions(case, selection.kind, selection.index)) do
					if row.id == actionID then allowed = true break end
				end
				if allowed and actionID == "talk" and selection.kind == "crew"
				and I.OpenCrewConversation then
					I.OpenCrewConversation(ply, case.id, selection.index)
					message = "Cinematic interview opened."
				elseif allowed then
					message = handlePhysicalAction(ply, case, selection.kind, selection.index, actionID)
				else
					message = "That action is not available for the selected subject."
				end
			end
		end
	elseif action == "select" or action == "get" then
		-- Selection was already normalised and stored above.
	else
		message = "Unknown customs-datapad request."
	end
	if sendData then
		sendData(ply, "customs_cases", "state", datapadPayload(ply, ply.mb_customsDatapadSelection, message))
	end
end

local function addStatement(case, member, text, evidenceKey, evidenceLabel, ply)
	member.statements[#member.statements + 1] = text
	member.statementRecords = member.statementRecords or {}
	local translator
	if MilBase.ResolveLanguageForListener and IsValid(ply) then
		local position = IsValid(member.entity) and member.entity:GetPos() or ply:GetPos()
		local _, resolvedTranslator = MilBase.ResolveLanguageForListener(
			ply, member.languageID or "basic", position, cfg.LanguageTranslatorRadius or 340)
		translator = resolvedTranslator
	end
	member.statementRecords[#member.statementRecords + 1] = {
		time = unix(),
		text = text,
		languageID = member.languageID or "basic",
		interviewer = playerName(ply),
		translator = IsValid(translator) and playerName(translator) or "",
		translatorSteamID = IsValid(translator) and translator:SteamID64() or "",
	}
	if evidenceKey then I.AddEvidence(case, evidenceKey, evidenceLabel, 1, ply) end
end

local function hostileCrewCount(case)
	local count = 0
	for _, member in ipairs(case.crew) do if not member.arrested then count = count + 1 end end
	return count
end

function I.TriggerResistance(case, ply, reason)
	if not case or case.resistanceTriggered or cfg.EnableViolentResistance == false then return false end
	if not case.criminal or hostileCrewCount(case) <= 0 then return false end
	if case.testForceResistance ~= true
	and math.Rand(0, 1) > math.Clamp(tonumber(cfg.ResistanceChance) or 0.32, 0, 1) then return false end
	case.resistanceTriggered = true
	I.AddEvidence(case, "assault", "The crew resisted inspection with violence.", 2, ply)
	for _, member in ipairs(case.crew) do
		if not member.arrested and IsValid(member.entity) then
			local source = member.entity
			local pos, ang = source:GetPos(), source:GetAngles()
			local model, skin = source:GetModel(), source:GetSkin()
			local bodygroups = {}
			for bodygroup = 0, math.max(0, source:GetNumBodyGroups() - 1) do
				bodygroups[bodygroup] = source:GetBodygroup(bodygroup)
			end
			member.model, member.skin, member.bodygroups = model, skin, bodygroups
			source:Remove()
			member.entity = nil
			-- Use a human NPC brain but preserve the original pilot/crew model,
			-- skin and bodygroups. Hostility must never reveal a Combine model.
			local npcClass = tostring(cfg.HostileCrewNPC or "npc_citizen")
			if npcClass == "npc_combine_s" then npcClass = "npc_citizen" end
			local npc = ents.Create(npcClass)
			if IsValid(npc) then
				if util.IsValidModel(model or "") then npc:SetModel(model) end
				npc:SetSkin(math.max(0, tonumber(skin) or 0))
				for bodygroup, value in pairs(bodygroups) do npc:SetBodygroup(bodygroup, value) end
				npc:SetPos(pos)
				npc:SetAngles(ang)
				if npcClass == "npc_citizen" then npc:SetKeyValue("citizentype", "4") end
				if cfg.HostileCrewWeapon and cfg.HostileCrewWeapon ~= "" then
					npc:SetKeyValue("additionalequipment", tostring(cfg.HostileCrewWeapon))
				end
				npc:Spawn()
				npc:Activate()
				if util.IsValidModel(model or "") then npc:SetModel(model) end
				npc:SetSkin(math.max(0, tonumber(skin) or 0))
				for bodygroup, value in pairs(bodygroups) do npc:SetBodygroup(bodygroup, value) end
				for _, player in ipairs(player.GetAll()) do npc:AddEntityRelationship(player, D_HT, 99) end
				npc.mb_inspectionCaseID = case.id
				npc.mb_inspectionCrewName = member.name
				member.hostileEntity = npc
				case.physicalEntities[#case.physicalEntities + 1] = npc
			end
		end
	end
	if IsValid(case.landedShip) then case.landedShip:SetInspectionStatus("CREW RESISTING — SECURITY REQUIRED") end
	if G.AnnounceNavy then
		G.AnnounceNavy("Weapons drawn in the inspection bay: " .. case.displayedName
			.. " crew are resisting detention.", Color(235, 75, 65), "[CUSTOMS] ")
	end
	return true
end

local function applyOutcomeResources(case, outcome, actor)
	if case and case.testCase == true then return end
	local naval = MilBase.Naval
	if not naval or not naval.ChangeResources then return end
	if outcome == "fine" then
		naval.ChangeResources({ funding = math.random(
			math.max(0, tonumber(cfg.FineFundingMinimum) or 350),
			math.max(0, tonumber(cfg.FineFundingMaximum) or 1400)) },
			"Customs fine collected", actor, true)
	elseif outcome == "confiscated" or outcome == "impounded" then
		naval.ChangeResources({
			funding = math.random(math.max(0, tonumber(cfg.ConfiscationFundingMinimum) or 700),
				math.max(0, tonumber(cfg.ConfiscationFundingMaximum) or 2800)),
			supplies = math.random(math.max(0, tonumber(cfg.ConfiscationSuppliesMinimum) or 8),
				math.max(0, tonumber(cfg.ConfiscationSuppliesMaximum) or 35)),
		}, "Contraband confiscated", actor, true)
	end
end

local function campaignOutcome(case, correct, actor, outcome)
	if case and case.testCase == true then return end
	if G.AddRecommendation then
		if correct then
			G.AddRecommendation(G.State.currentPlanet,
				math.max(1, tonumber(cfg.SuccessReputationGain) or 3), -1,
				"Republic customs completed a lawful ship inspection (" .. outcome .. ").",
				playerName(actor))
		else
			G.AddRecommendation(G.State.currentPlanet,
				-math.max(1, tonumber(cfg.WrongfulActionReputationPenalty) or 5), 1,
				"Republic customs took an incorrect or unsupported enforcement action.",
				playerName(actor))
		end
	end
end

function I.ResolveCase(case, outcome, actor, correct)
	if not case or case.resolved then return false end
	case.resolved = true
	case.outcome = outcome
	case.status = outcome == "impounded" and "impounded"
		or ((outcome == "cleared" or outcome == "denied" or outcome == "fine"
			or outcome == "expired") and "cleared" or "detained")
	case.closedAt = unix()
	correct = correct ~= false
	if case.testCase == true then
		finishInspectionHangar(case, "Customs test case ended; securing inspection bay", true)
		removePhysical(case)
		local testShip = case.ship
		if IsValid(testShip) then
			I.ByShip[testShip] = nil
			testShip.mb_galaxyInspectionCase = nil
			testShip.mb_inspectionCaseID = nil
			testShip:Remove()
		end
		I.TestCases[case.id] = nil
		I.Cases[case.id] = nil
		if G.AnnounceNavy then
			G.AnnounceNavy(case.displayedName .. " test case resolved: " .. string.upper(outcome)
				.. ". No campaign resources or reputation were changed.",
				correct and Color(90, 205, 130) or Color(235, 175, 70), "[CUSTOMS TEST] ")
		end
		return true
	end
	campaignOutcome(case, correct, actor, outcome)
	applyOutcomeResources(case, outcome, actor)
	local wantedKey = string.lower(case.captainName)
	if case.criminalCaptain and (outcome == "impounded" or outcome == "detained") then
		I.WantedCaptains[wantedKey] = nil
		I.SaveWantedCaptain(wantedKey, nil)
	elseif case.criminal and outcome == "cleared" then
		I.WantedCaptains[wantedKey] = {
			name = case.captainName, reason = "Released after unresolved customs case",
			lastSeen = unix(), ship = case.displayedName,
		}
		I.SaveWantedCaptain(wantedKey, I.WantedCaptains[wantedKey])
	end
	I.SaveCase(case)
	finishInspectionHangar(case, "Customs case resolved; securing inspection bay", true)
	removePhysical(case)
	local ship = case.ship
	if IsValid(ship) then
		ship:SetNoDraw(false)
		ship:SetInvulnerable(false)
		ship.mb_galaxyInspectionCase = nil
		ship.mb_inspectionCaseID = nil
		if outcome == "impounded" or outcome == "detained" then
			ship:Remove()
		else
			ship:SetShipState(outcome == "denied" and "departing under Republic order" or "cleared to depart")
			local pos = G.SkyboxEntryPoint and G.SkyboxEntryPoint(math.Rand(0, 360), 0, 0)
			if isvector(pos) then ship:SetPos(pos) end
			ship:SetFlightVelocity(ship:GetForward() * 55)
			ship:SetDieAt(CurTime() + 75)
			if G.AssignAutonomousShipMotion then G.AssignAutonomousShipMotion(ship, "customs case resolved") end
		end
	end
	if IsValid(ship) then I.ByShip[ship] = nil end
	I.Cases[case.id] = nil
	if G.AnnounceNavy then
		G.AnnounceNavy(case.displayedName .. " customs case resolved: " .. string.upper(outcome) .. ".",
			correct and Color(90, 205, 130) or Color(235, 175, 70), "[CUSTOMS] ")
	end
	return true
end

handlePhysicalAction = function(ply, case, kind, index, action)
	local message = "No action taken."
	if kind == "crew" then
		local member = case.crew[index]
		if not member then return "Crew record unavailable." end
		if action == "ask_identity" or action == "ask_story" or action == "ask_cargo" then
			local position = IsValid(member.entity) and member.entity:GetPos() or ply:GetPos()
			local understood = MilBase.ResolveLanguageForListener
				and MilBase.ResolveLanguageForListener(ply, member.languageID or "basic",
					position, cfg.LanguageTranslatorRadius or 340)
				or (member.languageID == nil or member.languageID == "basic")
			if not understood then
				local language = MilBase.GetLanguage
					and MilBase.GetLanguage(member.languageID or "basic") or {}
				return member.name .. " answered in " .. tostring(language.name or member.languageID)
					.. ". A certified nearby translator is required."
			end
		end
		if action == "ask_identity" then
			member.questioned.identity = true
			local text = member.truthful
				and ("I am " .. member.name .. ", registered " .. member.role .. ".")
				or ("My papers are in the ship records. I don't remember the registry number.")
			addStatement(case, member, text,
				member.truthful and nil or "evasive_identity_" .. index,
				"A crew member gave an evasive or unverifiable identity.", ply)
			message = text
		elseif action == "ask_story" then
			member.questioned.story = true
			local bribe = index == 1 and case.criminal and not case.bribeOffered
				and (case.testForceBribe == true or math.Rand(0, 1) < 0.22)
			if bribe then
				case.bribeOffered = true
				local text = "Captain " .. member.name
					.. " quietly offers Republic personnel credits to overlook the inspection."
				addStatement(case, member, text, "bribery",
					"The captain attempted to bribe Republic inspection personnel.", ply)
				message = text
			else
				local text = member.truthful
					and ("We departed " .. I.Clean(case.ship.mb_galaxyOrigin, 80)
						.. " for " .. I.Clean(case.ship.mb_galaxyDestination, 100) .. ".")
					or ("We came from a refuelling stop. The captain handled the route.")
				addStatement(case, member, text,
					(not member.truthful and not case.flightPlanValid) and "testimony_route_" .. index or nil,
					"Crew testimony conflicts with the submitted flight plan.", ply)
				message = text
			end
		elseif action == "ask_cargo" then
			member.questioned.cargo = true
			local text = member.truthful and ("The hold contains " .. declaredCargoLabel(case) .. ".")
				or "I never entered the cargo bay. The containers were sealed before I joined."
			addStatement(case, member, text,
				(not member.truthful and case.criminal) and "testimony_cargo_" .. index or nil,
				"Crew testimony about the cargo is inconsistent.", ply)
			message = text
		elseif action == "search_crew" then
			member.searched = true
			if member.armed then
				I.AddEvidence(case, "hidden_weapon_" .. index,
					member.name .. " carried an undeclared concealed weapon.", 1, ply)
				message = "Search recovered an undeclared concealed weapon."
			else
				message = "No weapon or contraband was found on this crew member."
			end
		elseif action == "arrest_crew" then
			member.arrested = true
			if IsValid(member.entity) then member.entity:SetArrested(true) end
			moveCrewToCustody(case, member, index, ply)
			if evidenceCount(case) < math.max(1, tonumber(cfg.EvidenceForLawfulArrest) or 3) then
				case.wrongfulActions = (case.wrongfulActions or 0) + 1
				message = "Crew member detained, but the case currently lacks the configured evidence threshold."
			else
				message = "Crew member detained pending formal charges."
			end
			I.TriggerResistance(case, ply, "crew arrest")
		end
	elseif kind == "cargo" then
		local cargo = case.cargo[index]
		if not cargo then return "Cargo record unavailable." end
		if action == "inspect_seal" then
			if cargo.legal == false and cargo.sealed and math.Rand(0, 1) < 0.55 then
				cargo.sealed = false
				I.AddEvidence(case, "seal_" .. index,
					"Container " .. index .. " has a replaced or falsified customs seal.", 1, ply)
				message = "The seal has been replaced and does not match the manifest authority."
			else
				message = cargo.sealed and "The external seal appears intact."
					or "The seal is broken or has been replaced."
			end
		elseif action == "scan_container" then
			local accurate = isEngineer(ply) or math.Rand(0, 1) < 0.72
			if accurate and cargo.legal == false then
				I.AddEvidence(case, "container_scan_" .. index,
					"Container " .. index .. " scan is inconsistent with its declared contents.", 1, ply)
				message = "Density and energy signatures do not match the declared cargo."
			else
				message = "The scan is " .. (accurate and "consistent with the declared cargo." or "inconclusive through the shielding.")
			end
		elseif action == "open_container" then
			cargo.searched = true
			if IsValid(cargo.entity) then cargo.entity:SetSearched(true) end
			message = "Container opened: " .. cargo.actual .. "."
			if cargo.legal == false then
				I.AddEvidence(case, "contraband_" .. index,
					"Container " .. index .. " contains " .. cargo.actual .. ".", 2, ply)
				I.TriggerResistance(case, ply, "contraband discovered")
			end
		elseif action == "seize_container" then
			cargo.seized = true
			if IsValid(cargo.entity) then cargo.entity:SetSeized(true) end
			message = "Container tagged for Republic seizure."
			if cargo.legal then case.wrongfulActions = (case.wrongfulActions or 0) + 1 end
		end
	elseif kind == "ship" then
		if action == "casefile" then
			message = "Case file refreshed."
		elseif action == "diagnose_failure" then
			if not case.emergency then
				message = "The crew has not reported an active technical failure."
			elseif case.emergencyFake then
				I.AddEvidence(case, "physical_fake_emergency",
					"Physical engineering checks disproved the declared " .. case.emergency .. ".", 1, ply)
				message = "Engineering inspection finds no fault matching the declared " .. case.emergency .. "."
			else
				case.failureDiagnosed = true
				message = "Engineering confirms " .. case.emergency .. " in the "
					.. string.upper(tostring(case.emergencySystem or "affected")) .. " system."
			end
		elseif action == "repair_failure" then
			if not case.emergency or case.emergencyFake then
				message = "There is no confirmed genuine fault to repair."
			elseif not isEngineer(ply) then
				message = "A qualified engineer is required to perform this repair."
			elseif not case.failureDiagnosed then
				message = "Diagnose the reported failure before attempting repairs."
			elseif case.failureRepaired then
				message = "The reported failure has already been repaired."
			else
				case.failureRepaired = true
				if IsValid(case.ship) then
					case.ship.mb_skyboxSystems = case.ship.mb_skyboxSystems or {}
					if case.ship.mb_skyboxSystems[case.emergencySystem] ~= nil then
						case.ship.mb_skyboxSystems[case.emergencySystem] = 1
					end
					case.ship.mb_inspectionSystemConditions = case.ship.mb_inspectionSystemConditions or {}
					case.ship.mb_inspectionSystemConditions[case.emergencySystem] = 1
				end
				message = "Engineering repairs complete. The " .. case.emergency .. " has been cleared."
			end
		elseif action == "search_hidden" then
			if case.hiddenFound then
				message = "The hidden compartment has already been documented."
			else
				local chance = math.Clamp((tonumber(cfg.HiddenCompartmentBaseChance) or 0.3)
					+ evidenceCount(case) * 0.09 + (isEngineer(ply) and 0.28 or 0), 0.08, 0.96)
				if case.hiddenCompartment
				and (case.testForceHidden == true or math.Rand(0, 1) <= chance) then
					case.hiddenFound = true
					I.AddEvidence(case, "hidden_compartment",
						"A shielded hidden compartment was found behind the cargo bay bulkhead.", 2, ply)
					message = "Engineering inspection reveals a shielded hidden compartment."
				else
					message = "No hidden compartment was found during this search pass."
				end
			end
		elseif action == "attach_tracker" then
			case.trackerAttached = true
			message = "A covert Republic route tracker has been attached to the vessel."
		elseif action == "confiscate" then
			local seized = 0
			for _, cargo in ipairs(case.cargo) do
				if cargo.legal == false then cargo.seized = true seized = seized + 1 end
				if IsValid(cargo.entity) and cargo.seized then cargo.entity:SetSeized(true) end
			end
			if seized > 0 then
				applyOutcomeResources(case, "confiscated", ply)
				message = seized .. " illegal cargo container(s) seized."
			else
				case.wrongfulActions = (case.wrongfulActions or 0) + 1
				message = "No confirmed illegal cargo was available to confiscate."
			end
		elseif action == "fine" then
			local correct = case.criminal and evidenceCount(case) >= 1
			I.ResolveCase(case, "fine", ply, correct)
			return "Fine issued and vessel released."
		elseif action == "arrest_all" then
			for crewIndex, member in ipairs(case.crew) do
				member.arrested = true
				if IsValid(member.entity) then member.entity:SetArrested(true) end
				moveCrewToCustody(case, member, crewIndex, ply)
			end
			if evidenceCount(case) < math.max(1, tonumber(cfg.EvidenceForLawfulArrest) or 3) then
				case.wrongfulActions = (case.wrongfulActions or 0) + 1
				message = "All crew detained, but the current evidence threshold is not met."
			else
				message = "All crew detained pending formal processing."
			end
			I.TriggerResistance(case, ply, "mass detention")
		elseif action == "impound" then
			local threshold = math.max(1, tonumber(cfg.EvidenceForImpound) or 4)
			local correct = not caseLegal(case) and evidenceCount(case) >= threshold
			I.ResolveCase(case, "impounded", ply, correct)
			return correct and "Vessel impounded under Republic authority."
				or "Vessel impounded without the configured evidentiary threshold; review logged."
		elseif action == "clear" then
			local correct = caseLegal(case)
			I.ResolveCase(case, "cleared", ply, correct)
			return correct and "Inspection complete. Vessel cleared and released."
				or "Vessel released despite unresolved criminal evidence; review logged."
		end
	end
	I.SaveCase(case)
	return message
end

local function crewConversationChoices(member)
	local rows = {
		{ id = "ask_identity", label = member.questioned.identity
			and "ASK THEM TO CONFIRM THEIR IDENTITY AGAIN" or "ASK FOR THEIR IDENTITY AND ROLE" },
		{ id = "ask_story", label = member.questioned.story
			and "CHALLENGE THEIR ROUTE ACCOUNT AGAIN" or "ASK ABOUT THEIR ROUTE AND PURPOSE" },
		{ id = "ask_cargo", label = member.questioned.cargo
			and "PRESS THEM ON THE CARGO AGAIN" or "ASK WHAT THEY KNOW ABOUT THE CARGO" },
	}
	return rows
end

local function crewGreeting(member, remote)
	local prefix = remote and "Republic control, " or ""
	local lines = {
		professional = prefix .. "I am ready to answer your questions.",
		guarded = prefix .. "Our documents are in order. What else do you need?",
		nervous = prefix .. "I will cooperate. Please, just tell me what you need.",
		talkative = prefix .. "Ask what you need. I would like this inspection resolved.",
		defiant = prefix .. "You are delaying a lawful civilian crew.",
		weary = prefix .. "We have been travelling for days. Let us finish this.",
	}
	return lines[member.personality] or (prefix .. "I am listening.")
end

function I.OpenCrewConversation(ply, caseID, index)
	if cfg.CinematicConversations == false or not canInspect(ply)
	or not MilBase.CinematicDialogue then return false end
	local case = I.Cases[tostring(caseID or "")]
	index = math.max(1, math.floor(tonumber(index) or 1))
	local member = case and case.crew and case.crew[index]
	if not case or case.status ~= "landed" or not member or not IsValid(member.entity) then
		notify(ply, "That crew member is not available for interview.", "warn")
		return false
	end
	if not physicalTargetInRange(ply, member.entity, "crew") then
		notify(ply, "Move closer to the crew member.", "warn")
		return false
	end
	return MilBase.CinematicDialogue.Open(ply, {
		mode = "physical",
		speaker = member.entity,
		speakerName = member.name,
		speciesName = member.speciesName or "Human",
		languageID = member.languageID or "basic",
		model = member.model,
		title = "REPUBLIC CUSTOMS INTERVIEW",
		subtitle = case.displayedName .. " / " .. member.role,
		line = crewGreeting(member, false),
		choices = crewConversationChoices(member),
		maxDistance = cfg.CinematicConversationDistance or 230,
		translatorRadius = cfg.LanguageTranslatorRadius or 340,
	}, function(actor, action)
		if I.Cases[case.id] ~= case or case.status ~= "landed"
		or not IsValid(member.entity)
		or not physicalTargetInRange(actor, member.entity, "crew") then return false end
		local message = handlePhysicalAction(actor, case, "crew", index, action)
		member.relationships = member.relationships or {}
		local key = actor:SteamID64()
		member.relationships[key] = math.Clamp(
			(tonumber(member.relationships[key]) or 0) + (member.truthful and 1 or 0), -100, 100)
		I.SaveCase(case)
		return {
			line = message,
			choices = crewConversationChoices(member),
		}
	end)
end

local function remoteCaptainChoices(case)
	local choices = {
		{ id = "captain_identity", label = "IDENTIFY YOURSELF AND YOUR CREW" },
		{ id = "captain_route", label = "STATE YOUR ORIGIN, DESTINATION AND PURPOSE" },
		{ id = "captain_cargo", label = "DECLARE YOUR CARGO" },
		{ id = "captain_emergency", label = "EXPLAIN ANY REPORTED EMERGENCY" },
		{ id = "captain_hold", label = "ORDER THE VESSEL TO HOLD POSITION" },
	}
	if not case.landingOrdered then
		choices[#choices + 1] = {
			id = "captain_land",
			label = "ORDER A PHYSICAL CUSTOMS LANDING",
			danger = true,
		}
	end
	choices[#choices + 1] = { id = "return_case", label = "RETURN TO CUSTOMS CASE FILE" }
	return choices
end

function I.OpenRemoteCaptainConversation(ply, case)
	if cfg.CinematicConversations == false or not case
	or not MilBase.CinematicDialogue then return false end
	if not validCommsCase(ply, case.ship) then
		notify(ply, "The captain channel is no longer active.", "warn")
		return false
	end
	local captain = case.crew and case.crew[1]
	if not captain then return false end
	return MilBase.CinematicDialogue.Open(ply, {
		mode = "remote",
		anchorPosition = ply:GetPos(),
		speakerName = captain.name,
		speciesName = captain.speciesName or "Human",
		languageID = captain.languageID or "basic",
		model = captain.model,
		title = "LIVE CUSTOMS CHANNEL",
		subtitle = case.displayedName .. " / CAPTAIN",
		line = crewGreeting(captain, true),
		choices = remoteCaptainChoices(case),
		translatorRadius = cfg.LanguageTranslatorRadius or 340,
	}, function(actor, action)
		if validCommsCase(actor, case.ship) ~= case then return false end
		local message
		if action == "return_case" then
			I.SendCommsCase(actor, case, "Captain channel placed on standby.")
			return false
		elseif action == "captain_identity" then
			captain.questioned.identity = true
			message = captain.truthful
				and ("I am Captain " .. captain.name .. ". The submitted crew manifest is current.")
				or "My identity and crew authorisations are in the transmitted records."
			addStatement(case, captain, message,
				captain.truthful and nil or "remote_evasive_identity",
				"The captain avoided confirming their transmitted identity.", actor)
		elseif action == "captain_route" then
			captain.questioned.story = true
			message = captain.truthful
				and ("We departed " .. I.Clean(case.ship.mb_galaxyOrigin, 80) .. " for "
					.. I.Clean(case.ship.mb_galaxyDestination, 100) .. " on our filed route.")
				or "We made an unscheduled refuelling stop. The route changed after departure."
			addStatement(case, captain, message,
				(not captain.truthful and not case.flightPlanValid) and "remote_route_conflict" or nil,
				"The captain's spoken route conflicts with the filed flight plan.", actor)
		elseif action == "captain_cargo" then
			captain.questioned.cargo = true
			message = "Our declared cargo is " .. declaredCargoLabel(case)
				.. ", with a submitted mass of " .. tostring(case.declaredMass) .. " units."
			addStatement(case, captain, message, nil, nil, actor)
		elseif action == "captain_emergency" then
			message = case.emergency
				and ("We are reporting " .. case.emergency .. ". The affected system is "
					.. string.upper(tostring(case.emergencySystem or "unknown")) .. ".")
				or "We are not reporting an emergency."
			addStatement(case, captain, message, nil, nil, actor)
		elseif action == "captain_hold" then
			if shipComplies(case, "hold") then
				setHeld(case, true)
				message = "Understood, Republic control. Holding position for inspection."
			else
				fleeInspection(case, "refused hold order")
				message = "Negative. We are leaving the inspection corridor."
			end
		elseif action == "captain_land" then
			case.landingOrdered = true
			if not anchorReady() then
				message = "We cannot receive landing coordinates. Your inspection bay is not configured."
			elseif shipComplies(case, "land") or case.status == "disabled" then
				local _, result = I.BeginLanding(case, actor)
				message = result or "Landing approach acknowledged."
			else
				fleeInspection(case, "refused landing order")
				message = "We will not submit to a physical search."
				if case.trueFaction == "cis" and math.Rand(0, 1) < 0.45 then
					startHostility(case, "CIS weapons activated")
				end
			end
		end
		I.SaveCase(case)
		if G.AddCommsHistory and IsValid(case.ship) then
			G.AddCommsHistory("customs", case.ship, message, actor)
		end
		if I.Cases[case.id] ~= case or not IsValid(case.ship) then return false end
		return {
			line = message or "No response.",
			choices = remoteCaptainChoices(case),
		}
	end)
end

net.Receive("MilBase_InspectionAction", function(_, ply)
	if (ply.mb_nextInspectionAction or 0) > CurTime() then return end
	ply.mb_nextInspectionAction = CurTime() + 0.25
	local caseID = I.Clean(net.ReadString(), 48)
	local kind = I.Clean(net.ReadString(), 16)
	local index = net.ReadUInt(8)
	local action = I.Clean(net.ReadString(), 40)
	local case = I.Cases[caseID]
	if not case or case.status ~= "landed" or not canInspect(ply) then return end
	local target = physicalTarget(case, kind, index)
	if not physicalTargetInRange(ply, target, kind) then
		notify(ply, "Move closer to the inspection subject.", "warn")
		return
	end
	local allowed = false
	for _, row in ipairs(physicalActions(case, kind, index)) do
		if row.id == action then allowed = true break end
	end
	if not allowed then return end
	if kind == "crew" and action == "talk" then
		I.OpenCrewConversation(ply, caseID, index)
		return
	end
	local message = handlePhysicalAction(ply, case, kind, index, action)
	if I.Cases[caseID] == case and case.status == "landed" then
		I.OpenPhysicalUI(ply, caseID, kind, index, message)
	else
		notify(ply, message, "info")
	end
end)

function I.OnCrewAttacked(ent, dmg)
	local case = I.Cases[ent:GetCaseID()]
	if not case then return end
	local attacker = dmg:GetAttacker()
	I.AddEvidence(case, "inspection_violence", "Violence occurred during the physical inspection.", 1, attacker)
	I.TriggerResistance(case, IsValid(attacker) and attacker:IsPlayer() and attacker or nil, "crew attacked")
end

function I.OnPhysicalEntityRemoved(ent)
	if not ent then return end
	local case = I.Cases[ent.mb_inspectionCaseID or (ent.GetCaseID and ent:GetCaseID())]
	if not case or case.removingPhysical then return end
	if ent == case.landedShip and case.status == "landing" then
		case.landedShip = nil
		case.status = "held"
		finishInspectionHangar(case,
			case.displayedName .. " landing aborted; securing inspection bay", true)
		if IsValid(case.ship) then
			case.ship:SetNoDraw(false)
			case.ship:SetInvulnerable(false)
			case.ship:SetShipState("inspection landing aborted")
		end
		I.SaveCase(case)
		if G.AnnounceNavy then
			G.AnnounceNavy(case.displayedName .. " could not complete the inspection-bay landing sequence.",
				Color(235, 175, 70), "[CUSTOMS] ")
		end
	elseif ent == case.landedShip and case.status == "landed" then
		I.ResolveCase(case, "impounded", nil, not caseLegal(case))
	end
end

local function serializableCrew(case)
	local rows = {}
	for index, member in ipairs(case.crew or {}) do
		rows[index] = {
			id = member.id,
			name = member.name,
			role = member.role,
			speciesID = member.speciesID,
			speciesName = member.speciesName,
			languageID = member.languageID,
			modelAlias = member.modelAlias,
			personality = member.personality,
			truthful = member.truthful == true,
			loyalty = member.loyalty,
			morale = member.morale,
			armed = member.armed == true,
			searched = member.searched == true,
			arrested = member.arrested == true,
			model = member.model,
			skin = member.skin,
			bodygroups = member.bodygroups or {},
			prisonerID = member.prisonerID,
			questioned = member.questioned or {},
			statements = member.statements or {},
			statementRecords = member.statementRecords or {},
			relationships = member.relationships or {},
		}
	end
	return rows
end

local function serializableCargo(case)
	local rows = {}
	for index, cargo in ipairs(case.cargo or {}) do
		rows[index] = {
			id = cargo.id,
			declared = cargo.declared,
			actual = cargo.actual,
			key = cargo.key,
			mass = cargo.mass,
			legal = cargo.legal ~= false,
			crime = cargo.crime,
			sealed = cargo.sealed == true,
			searched = cargo.searched == true,
			seized = cargo.seized == true,
		}
	end
	return rows
end

function I.SaveWantedCaptain(key, record)
	if not I._databaseReady or cfg.EnablePersistence == false or not MilBase.DB then return end
	key = string.lower(I.Clean(key, 128))
	if key == "" then return end
	if not record then
		MilBase.DB.Run("DELETE FROM frontier_galaxy_wanted_captains WHERE captain_key="
			.. MilBase.SQLStr(key))
		return
	end
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_wanted_captains "
			.. "(captain_key,captain_name,reason,ship_name,last_seen) VALUES (%s,%s,%s,%s,%d)",
		MilBase.SQLStr(key), MilBase.SQLStr(record.name or key),
		MilBase.SQLStr(record.reason or "Customs interest"),
		MilBase.SQLStr(record.ship or ""), tonumber(record.lastSeen) or unix()))
end

function I.SaveCase(case)
	if not case or case.testCase == true or not I._databaseReady
	or cfg.EnablePersistence == false or not MilBase.DB then return end
	case.updatedAt = unix()
	local payload = {
		checks = table.Copy(case.checks or {}),
		evidence = table.Copy(case.evidence or {}),
		cargo = serializableCargo(case),
		crew = serializableCrew(case),
		iffQuality = case.iffQuality,
		iffStatus = case.iffStatus,
		claimedFaction = case.claimedFaction,
		trueFaction = case.trueFaction,
		identityConfirmed = case.identityConfirmed == true,
		hiddenCompartment = case.hiddenCompartment == true,
		hiddenFound = case.hiddenFound == true,
		trackerAttached = case.trackerAttached == true,
		bribeOffered = case.bribeOffered == true,
		emergency = case.emergency,
		emergencySystem = case.emergencySystem,
		emergencyFake = case.emergencyFake == true,
		failureDiagnosed = case.failureDiagnosed == true,
		failureRepaired = case.failureRepaired == true,
		outcome = case.outcome,
		wrongfulActions = case.wrongfulActions,
	}
	MilBase.DB.Run(string.format(
		"REPLACE INTO frontier_galaxy_inspection_cases "
			.. "(case_id,created_at,updated_at,ship_name,captain_name,status,suspicion,evidence_count,outcome,case_json) "
			.. "VALUES (%s,%d,%d,%s,%s,%s,%d,%d,%s,%s)",
		MilBase.SQLStr(case.id), tonumber(case.createdAt) or unix(), case.updatedAt,
		MilBase.SQLStr(case.displayedName), MilBase.SQLStr(case.captainName),
		MilBase.SQLStr(case.status), math.floor(case.suspicion or 0), evidenceCount(case),
		MilBase.SQLStr(case.outcome or ""), MilBase.SQLStr(util.TableToJSON(payload) or "{}")))
end

function I.LoadAnchors()
	I.Anchors = { crew = {}, cargo = {}, approach = {} }
	MilBase.DB.Query("SELECT * FROM frontier_galaxy_inspection_anchors WHERE map_name="
		.. MilBase.SQLStr(game.GetMap()) .. " ORDER BY anchor_kind ASC, slot_index ASC", function(rows)
		for _, row in ipairs(rows or {}) do
			local kind = tostring(row.anchor_kind or "")
			local slot = math.max(1, tonumber(row.slot_index) or 1)
			local entry = { pos = rowVector(row.pos), ang = rowAngle(row.ang), label = row.label or "" }
			if entry.pos then
				if kind == "ship" or kind == "exit" then I.Anchors[kind] = entry
				elseif kind == "crew" or kind == "cargo" or kind == "approach" then
					I.Anchors[kind][slot] = entry
				end
			end
		end
	end)
end

function I.InitializeDatabase()
	if I._databaseReady then return end
	I._databaseReady = true
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_galaxy_inspection_anchors ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", map_name VARCHAR(128), anchor_kind VARCHAR(24), "
		.. "slot_index INTEGER, label VARCHAR(96), pos TEXT, ang TEXT)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_galaxy_inspection_cases ("
		.. "case_id VARCHAR(48) PRIMARY KEY, created_at INTEGER, updated_at INTEGER, "
		.. "ship_name VARCHAR(128), captain_name VARCHAR(128), status VARCHAR(32), "
		.. "suspicion INTEGER, evidence_count INTEGER, outcome VARCHAR(32), case_json TEXT)")
	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_galaxy_wanted_captains ("
		.. "captain_key VARCHAR(128) PRIMARY KEY, captain_name VARCHAR(128), reason TEXT, "
		.. "ship_name VARCHAR(128), last_seen INTEGER)")
	timer.Simple(0.3, function()
		I.LoadAnchors()
		MilBase.DB.Query("SELECT * FROM frontier_galaxy_wanted_captains", function(rows)
			I.WantedCaptains = {}
			for _, row in ipairs(rows or {}) do
				local key = string.lower(I.Clean(row.captain_key or row.captain_name, 128))
				if key ~= "" then
					I.WantedCaptains[key] = {
						name = I.Clean(row.captain_name, 128),
						reason = I.Clean(row.reason, 180),
						ship = I.Clean(row.ship_name, 128),
						lastSeen = tonumber(row.last_seen) or 0,
					}
				end
			end
		end)
		for _, openCase in pairs(I.Cases or {}) do I.SaveCase(openCase) end
	end)
end

hook.Add("MilBase.DBReady", "MilBase.SmugglingInspectionsDatabase", function()
	timer.Simple(0, I.InitializeDatabase)
end)
hook.Add("Initialize", "MilBase.SmugglingInspectionsDatabaseFallback", function()
	timer.Simple(1, function()
		if MilBase.DB then I.InitializeDatabase() end
	end)
end)

local function testCaseSummary(case)
	if not case then return "No active test case." end
	local illegal = {}
	for _, cargo in ipairs(case.cargo or {}) do
		if cargo.legal == false then illegal[#illegal + 1] = cargo.actual end
	end
	local failure = "none"
	if case.emergency then
		failure = case.emergency .. (case.emergencyFake and " (FAKE)" or " (GENUINE)")
	end
	return case.id .. " / " .. string.upper(tostring(case.testScenario or "unknown"))
		.. "\nPublic identity: " .. case.displayedName .. " / CIVILIAN"
		.. "\nHidden truth: " .. string.upper(tostring(case.trueFaction))
		.. (case.criminal and " / CRIMINAL" or " / INNOCENT")
		.. "\nIFF: " .. string.upper(tostring(case.iffQuality))
		.. "\nContraband: " .. (#illegal > 0 and table.concat(illegal, ", ") or "none")
		.. "\nHidden compartment: " .. (case.hiddenCompartment and "YES" or "NO")
		.. "\nEmergency: " .. failure
		.. "\nLanding behaviour: " .. string.upper(tostring(case.testCompliance or "random"))
		.. "\nForced bribe: " .. (case.testForceBribe and "YES" or "NO")
		.. " / forced resistance: " .. (case.testForceResistance and "YES" or "NO")
end

local function printTestSummary(ply, case)
	if not IsValid(ply) then return end
	for line in string.gmatch(testCaseSummary(case), "[^\n]+") do
		ply:ChatPrint("[CUSTOMS TEST] " .. line)
	end
end

local function latestTestCase(ply, requestedID)
	requestedID = string.Trim(tostring(requestedID or ""))
	if requestedID ~= "" then
		local direct = I.Cases[requestedID]
		if direct and direct.testCase then return direct end
	end
	local owner = IsValid(ply) and ply:SteamID64() or ""
	local newestOwner, newestAny
	for id in pairs(I.TestCases or {}) do
		local case = I.Cases[id]
		if case and not case.resolved then
			if not newestAny or (case.createdAt or 0) > (newestAny.createdAt or 0) then newestAny = case end
			if case.testOwnerSteamID == owner
			and (not newestOwner or (case.createdAt or 0) > (newestOwner.createdAt or 0)) then
				newestOwner = case
			end
		end
	end
	return newestOwner or newestAny
end

function I.RemoveTestCase(case, reason)
	if not case or case.testCase ~= true then return false end
	case.resolved = true
	case.outcome = reason or "test cleanup"
	finishInspectionHangar(case, "Customs test removed; securing inspection bay", true)
	removePhysical(case)
	local ship = case.ship
	if IsValid(ship) then
		I.ByShip[ship] = nil
		ship.mb_galaxyInspectionCase = nil
		ship.mb_inspectionCaseID = nil
		ship:Remove()
	end
	I.TestCases[case.id] = nil
	I.Cases[case.id] = nil
	return true
end

function I.CleanupTestCases()
	local removed = 0
	local ids = {}
	for id in pairs(I.TestCases or {}) do ids[#ids + 1] = id end
	for _, id in ipairs(ids) do
		if I.RemoveTestCase(I.Cases[id], "staff cleanup") then removed = removed + 1
		else I.TestCases[id] = nil end
	end
	return removed
end

function I.SpawnTestContact(ply, requestedScenario)
	if not canUseTestHarness(ply) then return nil, "Management permissions are required." end
	local scenario = normaliseTestScenario(requestedScenario or "random")
	if not scenario then return nil, "Unknown scenario. Use /inspectiontest list." end
	local ship = G.SpawnShip("civilian", {
		hold = true,
		persistentTraffic = true,
		inspectable = true,
		forceInspectionCase = true,
		testCase = true,
		testScenario = scenario,
		testOwner = ply,
		faction = "civilian",
		trueFaction = "civilian",
		transponderFaction = "civilian",
		hostile = false,
		invulnerable = false,
		sizeClass = math.Rand(0, 1) < 0.35 and "shuttle" or "light",
		state = "awaiting routine customs clearance",
		hull = 1500,
		sideYaw = math.Rand(0, 360),
		lane = math.Rand(-160, 160),
		height = math.Rand(-90, 90),
	})
	if not IsValid(ship) then return nil, "The Galaxy system could not find a clear skybox spawn point." end
	local case = I.ByShip[ship]
	if not case or case.testCase ~= true then
		if IsValid(ship) then ship:Remove() end
		return nil, "The inspection case could not be created. The test-contact limit may have been reached."
	end
	case.testOwnerSteamID = ply:SteamID64()
	ship:SetDieAt(0)
	ship:SetFlightVelocity(vector_origin)
	ship:SetShipState(case.emergency and (case.emergencyFake and "reports technical emergency" or case.emergency)
		or "awaiting routine customs clearance")
	if G.BroadcastState then G.BroadcastState() end
	if G.AnnounceNavy then
		G.AnnounceNavy("A civilian contact identified as " .. case.displayedName
			.. " has entered local space for customs-system testing. Treat its identity as unverified.",
			Color(100, 190, 235), "[CUSTOMS TEST] ")
	end
	return case
end

local function inspectionTestCommand(ply, args)
	if not canUseTestHarness(ply) then
		notify(ply, "Management permissions are required.", "warn")
		return
	end
	local action = string.lower(string.Trim(tostring(args[1] or "random")))
	if action == "list" or action == "help" then
		notify(ply, "Scenarios: " .. table.concat(testScenarioOrder, ", ")
			.. ". Utilities: random, next, reveal, land, cleanup.", "info")
		return
	elseif action == "cleanup" or action == "clear" then
		local removed = I.CleanupTestCases()
		notify(ply, "Removed " .. removed .. " active customs test contact(s).", "ok")
		return
	elseif action == "reveal" or action == "status" then
		local case = latestTestCase(ply, args[2])
		if not case then notify(ply, "No active customs test contact was found.", "warn") return end
		printTestSummary(ply, case)
		return
	elseif action == "land" then
		local case = latestTestCase(ply, args[2])
		if not case then notify(ply, "No active customs test contact was found.", "warn") return end
		local ok, message = I.BeginLanding(case, ply)
		notify(ply, message, ok and "ok" or "warn")
		return
	end

	local case, err = I.SpawnTestContact(ply, action)
	if not case then notify(ply, err or "Unable to create the test contact.", "warn") return end
	notify(ply, "Spawned " .. case.displayedName .. " as test scenario "
		.. string.upper(case.testScenario) .. ". Use the communications console normally.", "ok")
	printTestSummary(ply, case)
end

MilBase.RegisterChatCommand("inspectiontest", {
	help = "(Management) Spawn or manage a customs test contact: /inspectiontest <random|next|scenario|list|reveal|land|cleanup>",
	func = inspectionTestCommand,
})
MilBase.RegisterChatCommand("customstest", {
	help = "Alias for /inspectiontest.",
	func = inspectionTestCommand,
})
concommand.Add("mb_inspection_test", function(ply, _, args)
	if not IsValid(ply) then return end
	inspectionTestCommand(ply, args or {})
end)

MilBase.RegisterChatCommand("inspectionanchor", {
	help = "(Management) Save an inspection bay anchor: /inspectionanchor <ship|approach|crew|cargo|exit> [slot]",
	func = function(ply, args)
		if not canConfigure(ply) then notify(ply, "Management permissions are required.", "warn") return end
		local kind = string.lower(tostring(args[1] or ""))
		if kind ~= "ship" and kind ~= "approach" and kind ~= "crew" and kind ~= "cargo" and kind ~= "exit" then
			notify(ply, "Use /inspectionanchor <ship|approach|crew|cargo|exit> [slot].", "warn")
			return
		end
		local slotted = kind == "crew" or kind == "cargo" or kind == "approach"
		local slot = slotted and math.max(1, math.floor(tonumber(args[2]) or 1)) or 1
		local savePos = kind == "approach" and ply:EyePos() or ply:GetPos()
		local eyeAng = ply:EyeAngles()
		local saveAng = kind == "approach" and Angle(eyeAng.p, eyeAng.y, 0) or Angle(0, eyeAng.y, 0)
		MilBase.DB.Query("DELETE FROM frontier_galaxy_inspection_anchors WHERE map_name="
			.. MilBase.SQLStr(game.GetMap()) .. " AND anchor_kind=" .. MilBase.SQLStr(kind)
			.. " AND slot_index=" .. slot, function()
			MilBase.DB.Query(string.format(
				"INSERT INTO frontier_galaxy_inspection_anchors (map_name,anchor_kind,slot_index,label,pos,ang) "
					.. "VALUES (%s,%s,%d,%s,%s,%s)",
				MilBase.SQLStr(game.GetMap()), MilBase.SQLStr(kind), slot,
				MilBase.SQLStr(string.upper(kind) .. " " .. slot), vecString(savePos), angString(saveAng)),
				function()
					I.LoadAnchors()
					notify(ply, "Saved inspection " .. kind .. " anchor " .. slot
						.. (kind == "approach" and " at your eye position." or "."), "ok")
				end)
		end)
	end,
})

MilBase.RegisterChatCommand("inspectionanchors", {
	help = "List inspection-bay anchor status for this map.",
	func = function(ply)
		if not canConfigure(ply) then return end
		local crew, cargo, approach = 0, 0, 0
		for _ in pairs(I.Anchors.crew or {}) do crew = crew + 1 end
		for _ in pairs(I.Anchors.cargo or {}) do cargo = cargo + 1 end
		for _ in pairs(I.Anchors.approach or {}) do approach = approach + 1 end
		notify(ply, "Inspection anchors: ship " .. (I.Anchors.ship and "YES" or "NO")
			.. ", approach " .. approach .. ", exit " .. (I.Anchors.exit and "YES" or "NO")
			.. ", crew " .. crew .. ", cargo " .. cargo .. ".", "info")
	end,
})

MilBase.RegisterChatCommand("inspectionclearanchors", {
	help = "(Management) Delete all inspection-bay anchors for this map.",
	func = function(ply)
		if not canConfigure(ply) then return end
		MilBase.DB.Query("DELETE FROM frontier_galaxy_inspection_anchors WHERE map_name="
			.. MilBase.SQLStr(game.GetMap()), function()
			I.LoadAnchors()
			notify(ply, "Inspection anchors cleared for this map.", "ok")
		end)
	end,
})

hook.Add("EntityTakeDamage", "MilBase.SmugglingInspectionShipDamage", function(ent, dmg)
	if not IsValid(ent) or ent:GetClass() ~= "mb_galaxy_ship" then return end
	local case = I.ByShip[ent]
	if not case then return end
	if ent:GetHostile() then I.MaybeConfirmIdentity(case) end
	local systems = ent.mb_skyboxSystems or {}
	if tonumber(systems.engines) and systems.engines <= 0.12 and case.status == "fleeing" then
		case.status = "disabled"
		ent:SetShipState("engines disabled by Republic fire")
		ent:SetFlightVelocity(vector_origin)
		I.AddEvidence(case, "disabled_after_evasion", "The fleeing contact was disabled after refusing inspection.", 1, dmg:GetAttacker())
		if case.landingOrdered and anchorReady() then I.BeginLanding(case, dmg:GetAttacker()) end
	end
end)

hook.Add("EntityRemoved", "MilBase.SmugglingInspectionShipRemoved", function(ent)
	local case = I.ByShip[ent]
	if not case then return end
	I.ByShip[ent] = nil
	if case.testCase then I.TestCases[case.id] = nil end
	if not case.resolved then
		case.status = "closed"
		case.outcome = "contact lost"
		I.SaveCase(case)
		removePhysical(case)
		I.Cases[case.id] = nil
	end
end)

hook.Add("Think", "MilBase.SmugglingInspectionThink", function()
	if (I._nextThink or 0) > CurTime() then return end
	I._nextThink = CurTime() + 0.5
	local now = unix()
	for id, case in pairs(I.Cases) do
		local ship = case.ship
		if case.testCase == true and case.testExpiresAt
		and CurTime() >= case.testExpiresAt then
			I.RemoveTestCase(case, "test timeout")
		elseif not IsValid(ship) then
			finishInspectionHangar(case, "Customs contact lost; securing inspection bay", true)
			removePhysical(case)
			I.Cases[id] = nil
		else
			if ship:GetHostile() and not case.identityConfirmed then I.MaybeConfirmIdentity(case) end
			if case.emergency and not case.emergencyFake and not case.failureRepaired
			and case.emergencySystem == "engines" then
				local systems = ship.mb_skyboxSystems or {}
				local engine = math.Clamp(tonumber(systems.engines) or case.emergencyCondition or 0.45, 0, 1)
				if case.status ~= "landed" and case.status ~= "landing" then
					local velocity = ship:GetFlightVelocity()
					local maximum = 18 + engine * 36
					if velocity:Length() > maximum then ship:SetFlightVelocity(velocity:GetNormalized() * maximum) end
				end
			end
			if case.status == "landing" and case.landingDeadline and CurTime() > case.landingDeadline then
				removePhysical(case)
				case.status = "held"
				ship:SetNoDraw(false)
				ship:SetInvulnerable(false)
				ship:SetShipState("landing corridor timed out")
				finishInspectionHangar(case,
					case.displayedName .. " landing timed out; securing inspection bay", true)
				I.SaveCase(case)
			end
			if case.status == "landed" and case.physicalStartedAt
			and now - case.physicalStartedAt > math.max(120, tonumber(cfg.PhysicalEncounterLifetime) or 1200) then
				I.ResolveCase(case, "cleared", nil, caseLegal(case))
			elseif case.testCase ~= true
			and now - (case.createdAt or now) > math.max(300, tonumber(cfg.CaseLifetime) or 1800)
			and case.status ~= "landed" then
				I.ResolveCase(case, "expired", nil, true)
			end
		end
	end
end)

for _, ship in ipairs(ents.FindByClass("mb_galaxy_ship")) do
	timer.Simple(0, function() if IsValid(ship) then I.EnsureCaseForShip(ship) end end)
end
