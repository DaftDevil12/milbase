--[[
	Squads module: session fireteams.

	/squad create <name>   - form a squad (you become leader)
	/squad invite <player> - invite someone (leader only)
	/squad accept          - accept a pending invite
	/squad leave           - leave (leadership passes on)
	/squad kick <player>   - remove a member (leader only)
	/squad disband         - dissolve the squad (leader only)
	/s <message>           - squad radio

	Members see a fireteam list on the left of the HUD (name, health,
	distance) and green markers over squadmates' heads.
]]

local cfg = MilBase.Config
local COL_SQD = Color(255, 198, 60) -- golden yellow

if SERVER then

	MilBase.Squads = MilBase.Squads or {}

	local function getSquad(ply)
		local name = ply:GetNWString("mb_squad", "")
		return name ~= "" and MilBase.Squads[name] or nil
	end

	local function members(squad)
		for i = #squad.members, 1, -1 do
			if not IsValid(squad.members[i]) then table.remove(squad.members, i) end
		end
		return squad.members
	end

	local function joinSquad(ply, squad)
		table.insert(squad.members, ply)
		ply:SetNWString("mb_squad", squad.name)
		ply:SetNWBool("mb_squadleader", squad.leader == ply)

		for _, m in ipairs(members(squad)) do
			MilBase.Notify(m, ply:MBName() .. " joined squad " .. squad.name .. ".")
		end
	end

	local function leaveSquad(ply, silent)
		local squad = getSquad(ply)
		if not squad then return end

		table.RemoveByValue(squad.members, ply)
		ply:SetNWString("mb_squad", "")
		ply:SetNWBool("mb_squadleader", false)

		if not silent then
			MilBase.Notify(ply, "You left squad " .. squad.name .. ".")
			for _, m in ipairs(members(squad)) do
				MilBase.Notify(m, ply:MBName() .. " left squad " .. squad.name .. ".")
			end
		end

		if squad.leader == ply then
			local heir = members(squad)[1]
			if IsValid(heir) then
				squad.leader = heir
				heir:SetNWBool("mb_squadleader", true)
				MilBase.Notify(heir, "You are now the leader of squad " .. squad.name .. ".")
			else
				MilBase.Squads[squad.name] = nil
			end
		end
	end

	hook.Add("PlayerDisconnected", "MilBase.SquadLeave", function(ply)
		leaveSquad(ply, true)
	end)

	MilBase.RegisterChatCommand("squad", {
		help = "Squad management: /squad create|invite|accept|leave|kick|disband",
		func = function(ply, args)
			if not cfg.SquadsEnabled then
				MilBase.Notify(ply, "Squads are disabled.")
				return
			end

			local sub = string.lower(args[1] or "")

			if sub == "create" then
				local name = string.Trim(table.concat(args, " ", 2))
				if getSquad(ply) then
					MilBase.Notify(ply, "Leave your current squad first (/squad leave).")
				elseif #name < 2 or #name > 20 then
					MilBase.Notify(ply, "Squad names must be 2-20 characters.")
				elseif MilBase.Squads[name] then
					MilBase.Notify(ply, "That squad already exists.")
				else
					local squad = { name = name, leader = ply, members = {} }
					MilBase.Squads[name] = squad
					joinSquad(ply, squad)
				end

			elseif sub == "invite" then
				local squad = getSquad(ply)
				local target = MilBase.FindPlayer(args[2])
				if not squad or squad.leader ~= ply then
					MilBase.Notify(ply, "Only squad leaders can invite.")
				elseif not IsValid(target) or target == ply then
					MilBase.Notify(ply, "Player not found.")
				elseif target:GetNWString("mb_squad", "") ~= "" then
					MilBase.Notify(ply, target:MBName() .. " is already in a squad.")
				elseif #members(squad) >= cfg.SquadMaxMembers then
					MilBase.Notify(ply, "Your squad is full (" .. cfg.SquadMaxMembers .. ").")
				else
					target.mb_squadInvite = { name = squad.name, expires = CurTime() + 60 }
					MilBase.Notify(ply, "Invited " .. target:MBName() .. ".")
					MilBase.Notify(target, ply:MBName() .. " invited you to squad "
						.. squad.name .. ". Type /squad accept within 60s.")
				end

			elseif sub == "accept" then
				local invite = ply.mb_squadInvite
				local squad = invite and MilBase.Squads[invite.name]
				if not invite or CurTime() > invite.expires or not squad then
					MilBase.Notify(ply, "No pending squad invite.")
				elseif getSquad(ply) then
					MilBase.Notify(ply, "Leave your current squad first.")
				elseif #members(squad) >= cfg.SquadMaxMembers then
					MilBase.Notify(ply, "That squad is now full.")
				else
					ply.mb_squadInvite = nil
					joinSquad(ply, squad)
				end

			elseif sub == "leave" then
				if getSquad(ply) then leaveSquad(ply)
				else MilBase.Notify(ply, "You are not in a squad.") end

			elseif sub == "kick" then
				local squad = getSquad(ply)
				local target = MilBase.FindPlayer(args[2])
				if not squad or squad.leader ~= ply then
					MilBase.Notify(ply, "Only squad leaders can kick.")
				elseif not IsValid(target) or target == ply or getSquad(target) ~= squad then
					MilBase.Notify(ply, "That player is not in your squad.")
				else
					leaveSquad(target)
					MilBase.Notify(target, "You were removed from squad " .. squad.name .. ".")
				end

			elseif sub == "disband" then
				local squad = getSquad(ply)
				if not squad or squad.leader ~= ply then
					MilBase.Notify(ply, "Only squad leaders can disband.")
				else
					for _, m in ipairs(members(squad)) do
						m:SetNWString("mb_squad", "")
						m:SetNWBool("mb_squadleader", false)
						MilBase.Notify(m, "Squad " .. squad.name .. " was disbanded.")
					end
					MilBase.Squads[squad.name] = nil
				end

			else
				MilBase.Notify(ply, "Usage: /squad create|invite|accept|leave|kick|disband")
			end
		end,
	})

	MilBase.RegisterChatCommand("s", {
		help = "Squad radio: /s moving to the north ridge",
		func = function(ply, args, rawText)
			if rawText == "" then return end

			local squad = getSquad(ply)
			if not squad then
				MilBase.Notify(ply, "You are not in a squad.")
				return
			end
			if not ply:Alive() then
				MilBase.Notify(ply, "You can't use the radio while dead.")
				return
			end

			-- Route through the Squad comm channel so channel muting and jamming
			-- apply. Falls back to a direct send if comms are disabled.
			if not (MilBase.SendCommsChat and MilBase.SendCommsChat(ply, rawText, "squad")) then
				MilBase.ChatMsg(members(squad),
					COL_SQD, "[SQD] ", color_white, ply:MBFullTitle(),
					Color(220, 220, 220), ": " .. rawText)
			end
		end,
	})

else -- CLIENT

	hook.Add("HUDPaint", "MilBase.SquadHUD", function()
		if MilBase.InEventView() then return end
		local ply = LocalPlayer()
		if not IsValid(ply) then return end

		local squadName = ply:GetNWString("mb_squad", "")
		if squadName == "" then return end

		local ui = MilBase.UI

		local squadmates = {}
		for _, p in ipairs(player.GetAll()) do
			if p:GetNWString("mb_squad", "") == squadName then
				table.insert(squadmates, p)
			end
		end

		-- Fireteam list, left side
		local x, y = 20, math.floor(ScrH() * 0.28)
		draw.SimpleTextOutlined("SQUAD  " .. string.upper(squadName), "MB.Small",
			x, y, COL_SQD, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)
		y = y + 22
		if cfg.SquadPingsEnabled ~= false then
			draw.SimpleTextOutlined("MMB PING  /  HOLD FOR ORDERS", "MB.Tiny",
				x, y, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)
			y = y + 16
		end

		for _, m in ipairs(squadmates) do
			local nameCol = m:Alive() and ui.text or ui.danger
			if m:GetNWBool("mb_wounded", false) then nameCol = ui.warn end

			local label = (m:GetNWBool("mb_squadleader", false) and "★ " or "") .. m:MBName()
			draw.SimpleTextOutlined(label, "MB.Tiny", x, y, nameCol,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)

			local frac = m:Alive()
				and math.Clamp(m:Health() / math.max(m:GetMaxHealth(), 1), 0, 1) or 0
			MilBase.DrawBar(x + 135, y + 3, 60, 8, frac, COL_SQD)

			if m ~= ply then
				local dist = math.Round(m:GetPos():Distance(ply:GetPos()) / 52.5)
				draw.SimpleTextOutlined(dist .. "m", "MB.Tiny", x + 202, y,
					ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, color_black)
			end

			y = y + 17
		end

		-- Diamond markers over squadmates
		for _, m in ipairs(squadmates) do
			if m == ply or not m:Alive() then continue end

			local screen = (m:GetPos() + Vector(0, 0, m:OBBMaxs().z + 18)):ToScreen()
			if screen.visible then
				local wounded = m:GetNWBool("mb_wounded", false)
				MilBase.DrawDiamond(screen.x, screen.y, 6,
					wounded and ui.warn or COL_SQD, not wounded)
			end
		end
	end)

end
