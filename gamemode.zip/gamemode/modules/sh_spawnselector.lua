--[[
	Spawn Selector module.

	Staff place persistent player spawn points with the Toolgun:
	  Tools -> Star Wars RP -> Spawn Selector

	Each spawn can be restricted by faction/job, rank index, rank group and
	certification/spec. Players can open /spawns to choose any spawn they are
	currently eligible for. Spawns can also be configured as square zones so
	deployments spread players out instead of stacking everyone on one point.
	The server re-checks access on every selection and spawn, so losing a
	cert/rank/faction also removes access to that spawn.
]]

local cfg = MilBase.Config
MilBase.SpawnSelector = MilBase.SpawnSelector or {}

local NET_OPEN = "MilBase_SpawnSelector_Open"
local NET_SELECT = "MilBase_SpawnSelector_Select"

local function trim(s)
	return string.Trim(tostring(s or ""))
end

local function splitList(value)
	local out = {}
	value = trim(value)
	if value == "" then return out end

	for part in string.gmatch(value, "([^,;|]+)") do
		part = trim(part)
		if part ~= "" then out[#out + 1] = part end
	end
	return out
end

local function lower(s)
	return string.lower(trim(s))
end

local function listHas(listText, candidates)
	local list = splitList(listText)
	if #list == 0 then return true end

	local wanted = {}
	for _, c in ipairs(candidates or {}) do
		if trim(c) ~= "" then wanted[lower(c)] = true end
	end

	for _, item in ipairs(list) do
		local l = lower(item)
		if l == "*" or l == "all" or wanted[l] then return true end
	end
	return false
end

local function displayList(value, emptyText)
	local list = splitList(value)
	if #list == 0 then return emptyText or "Any" end
	return table.concat(list, ", ")
end

local function cleanZoneSize(value)
	local defaultSize = tonumber(cfg.SpawnSelectorDefaultZoneSize or 192) or 192
	local maxSize = tonumber(cfg.SpawnSelectorMaxZoneSize or 1024) or 1024
	local size = math.floor(tonumber(value or defaultSize) or defaultSize)
	return math.Clamp(size, 0, math.max(0, maxSize))
end

local function certTokenMatchesPlayer(ply, token)
	token = lower(token)
	if token == "" then return false end

	for _, certID in ipairs(ply:MBCertList()) do
		local cert = MilBase.Certs and MilBase.Certs[certID]
		if lower(certID) == token or (cert and lower(cert.name) == token) then
			return true
		end
	end
	return false
end

local function certRequirementPasses(ply, certText, requireAll)
	local certs = splitList(certText)
	if #certs == 0 then return true end

	local matched = 0
	for _, token in ipairs(certs) do
		local l = lower(token)
		if l == "*" or l == "all" or certTokenMatchesPlayer(ply, token) then
			matched = matched + 1
		elseif requireAll then
			return false
		end
	end

	return requireAll and matched == #certs or matched > 0
end

function MilBase.SpawnSelectorRankGroup(ply)
	if MilBase.QuartermasterRankGroup then return MilBase.QuartermasterRankGroup(ply) end

	local rank = ply:MBRank()
	if not rank then return "trooper" end
	if isstring(rank.spawnGroup) and rank.spawnGroup ~= "" then return lower(rank.spawnGroup) end
	if isstring(rank.quartermasterGroup) and rank.quartermasterGroup ~= "" then return lower(rank.quartermasterGroup) end

	local name = lower(rank.name)
	local groups = cfg.QuartermasterRankGroups or {}
	for _, group in ipairs({ "commander", "officer", "nco" }) do
		for _, token in ipairs(groups[group] or {}) do
			if token ~= "" and string.find(name, lower(token), 1, true) then
				return group
			end
		end
	end

	return "trooper"
end

local function spawnRankNames(ply)
	local rank = ply:MBRank()
	local group = MilBase.SpawnSelectorRankGroup(ply)
	local names = { group, rank and rank.name or "" }
	if group == "trp" or group == "trooper" then
		names[#names + 1] = "trooper"
		names[#names + 1] = "trp"
		names[#names + 1] = "enlisted"
	end
	return names
end

function MilBase.SpawnSelectorAccessText(spawn)
	local parts = {}
	parts[#parts + 1] = "Faction/Job: " .. displayList(spawn.factions, "Any")

	local minRank = tonumber(spawn.minRank or 0) or 0
	local maxRank = tonumber(spawn.maxRank or 0) or 0
	if minRank > 0 or maxRank > 0 then
		if minRank > 0 and maxRank > 0 then
			parts[#parts + 1] = "Ranks: " .. minRank .. "-" .. maxRank
		elseif minRank > 0 then
			parts[#parts + 1] = "Rank: " .. minRank .. "+"
		else
			parts[#parts + 1] = "Rank: up to " .. maxRank
		end
	end

	if trim(spawn.rankGroups) ~= "" then
		parts[#parts + 1] = "Rank Groups: " .. displayList(spawn.rankGroups, "Any")
	end

	if trim(spawn.certs) ~= "" then
		parts[#parts + 1] = "Specs/Certs: " .. displayList(spawn.certs, "Any")
		if tonumber(spawn.requireAll or 0) == 1 then
			parts[#parts + 1] = "Requires all specs"
		else
			parts[#parts + 1] = "Requires any spec"
		end
	end

	local zoneSize = cleanZoneSize(spawn.zoneSize or spawn.zone_size)
	if zoneSize > 0 then
		parts[#parts + 1] = "Zone: " .. zoneSize .. "u square"
	end

	return table.concat(parts, "  •  ")
end

function MilBase.SpawnSelectorCanUse(ply, spawn)
	if cfg.SpawnSelectorEnabled == false then return false, "Spawn selector disabled" end
	if not IsValid(ply) or not ply:IsPlayer() then return false, "Invalid player" end
	if not spawn then return false, "Invalid spawn" end
	if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return false, "Event enemy" end

	local faction = ply:MBFaction()
	local factionID = ply:MBFactionID()
	if not listHas(spawn.factions or "", { factionID, faction and faction.name or "" }) then
		return false, "Wrong faction/job"
	end

	local rankIndex = ply:MBRankIndex()
	local minRank = tonumber(spawn.minRank or 0) or 0
	local maxRank = tonumber(spawn.maxRank or 0) or 0
	if minRank > 0 and rankIndex < minRank then return false, "Rank too low" end
	if maxRank > 0 and rankIndex > maxRank then return false, "Rank too high" end

	if not listHas(spawn.rankGroups or "", spawnRankNames(ply)) then
		return false, "Wrong rank group"
	end

	if not certRequirementPasses(ply, spawn.certs or "", tonumber(spawn.requireAll or 0) == 1) then
		return false, "Missing spec/cert"
	end

	return true
end

function MilBase.SpawnSelectorGetSpawn(id)
	id = tonumber(id or 0) or 0
	return (MilBase.SpawnSelector.Spawns or {})[id]
end

function MilBase.SpawnSelectorBuildList(ply)
	local list = {}
	for id, spawn in pairs(MilBase.SpawnSelector.Spawns or {}) do
		local allowed, reason = MilBase.SpawnSelectorCanUse(ply, spawn)
		if allowed or cfg.SpawnSelectorShowLocked == true then
			local entry = {
				id = id,
				name = spawn.name or ("Spawn #" .. id),
				allowed = allowed,
				reason = allowed and "Available" or reason,
				access = MilBase.SpawnSelectorAccessText(spawn),
				zoneSize = cleanZoneSize(spawn.zoneSize or spawn.zone_size),
				selected = tonumber(ply:GetNWInt("mb_spawn_choice", 0)) == id,
			}

			-- Only send preview coordinates for spawns the player is allowed to use.
			-- Locked spawn positions stay server-side.
			if allowed and cfg.SpawnSelectorPreviewEnabled ~= false then
				entry.pos = spawn.pos
				entry.ang = spawn.ang
			end

			list[#list + 1] = entry
		end
	end

	table.sort(list, function(a, b)
		if a.allowed ~= b.allowed then return a.allowed end
		return string.lower(a.name or "") < string.lower(b.name or "")
	end)
	return list
end

if SERVER then
	util.AddNetworkString(NET_OPEN)
	util.AddNetworkString(NET_SELECT)

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_spawn_points ("
		.. "id " .. MilBase.DB.AutoIncPK() .. ", "
		.. "map VARCHAR(64), name TEXT, pos TEXT, ang TEXT, "
		.. "factions TEXT, certs TEXT, require_all INTEGER, "
		.. "min_rank INTEGER, max_rank INTEGER, rank_groups TEXT, "
		.. "zone_size INTEGER )")

	MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_spawn_choices ("
		.. "steamid VARCHAR(32) PRIMARY KEY, spawn_id INTEGER )")

	local function ensureSpawnZoneColumn()
		if MilBase.DB.IsMySQL and MilBase.DB.IsMySQL() then
			MilBase.DB.Query("SHOW COLUMNS FROM frontier_spawn_points LIKE 'zone_size'", function(rows)
				if not rows or #rows == 0 then
					MilBase.DB.Run("ALTER TABLE frontier_spawn_points ADD COLUMN zone_size INTEGER")
				end
			end)
		else
			MilBase.DB.Query("PRAGMA table_info(frontier_spawn_points)", function(rows)
				local hasColumn = false
				for _, row in ipairs(rows or {}) do
					if row.name == "zone_size" then hasColumn = true break end
				end
				if not hasColumn then
					MilBase.DB.Run("ALTER TABLE frontier_spawn_points ADD COLUMN zone_size INTEGER")
				end
			end)
		end
	end
	ensureSpawnZoneColumn()

	local function canConfigure(ply)
		if game.SinglePlayer() then return true end
		if not IsValid(ply) then return false end
		if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
		return ply:MBStaffLevel() >= (cfg.SpawnSelectorStaffLevel or 3)
	end
	MilBase.SpawnSelectorCanConfigure = canConfigure

	local function sanitizeData(data)
		data = data or {}
		return {
			name = trim(data.name) ~= "" and trim(data.name) or "Spawn Point",
			factions = trim(data.factions),
			certs = trim(data.certs),
			requireAll = data.requireAll and 1 or 0,
			minRank = math.max(0, math.floor(tonumber(data.minRank or 0) or 0)),
			maxRank = math.max(0, math.floor(tonumber(data.maxRank or 0) or 0)),
			rankGroups = trim(data.rankGroups),
			zoneSize = cleanZoneSize(data.zoneSize),
		}
	end

	local function rowToSpawn(row)
		local pos = util.StringToType(row.pos or "", "Vector")
		local ang = util.StringToType(row.ang or "", "Angle")
		if not isvector(pos) then pos = vector_origin end
		if not isangle(ang) then ang = angle_zero end

		return {
			id = tonumber(row.id) or 0,
			name = row.name or "Spawn Point",
			pos = pos,
			ang = ang,
			factions = row.factions or "",
			certs = row.certs or "",
			requireAll = tonumber(row.require_all or row.requireAll or 0) or 0,
			minRank = tonumber(row.min_rank or row.minRank or 0) or 0,
			maxRank = tonumber(row.max_rank or row.maxRank or 0) or 0,
			rankGroups = row.rank_groups or row.rankGroups or "",
			zoneSize = cleanZoneSize(row.zone_size or row.zoneSize),
		}
	end

	function MilBase.SpawnSelectorReload()
		MilBase.SpawnSelector.Spawns = {}
		MilBase.SpawnSelector.Loaded = false
		MilBase.DB.Query("SELECT * FROM frontier_spawn_points WHERE map = " .. MilBase.SQLStr(game.GetMap()), function(rows)
			MilBase.SpawnSelector.Spawns = {}
			for _, row in ipairs(rows or {}) do
				local spawn = rowToSpawn(row)
				if spawn.id > 0 then MilBase.SpawnSelector.Spawns[spawn.id] = spawn end
			end
			MilBase.SpawnSelector.Loaded = true
			for _, ply in ipairs(player.GetAll()) do
				MilBase.SpawnSelectorValidateChoice(ply, true)
			end
		end)
	end

	local function notifyStaff(text, kind)
		for _, ply in ipairs(player.GetAll()) do
			if canConfigure(ply) then MilBase.Notify(ply, text, kind) end
		end
	end

	function MilBase.SpawnSelectorAddSpawn(ply, pos, ang, data)
		if not canConfigure(ply) then return false end
		if not isvector(pos) then return false end
		ang = isangle(ang) and ang or angle_zero
		data = sanitizeData(data)

		local sqlText = string.format(
			"INSERT INTO frontier_spawn_points (map, name, pos, ang, factions, certs, require_all, min_rank, max_rank, rank_groups, zone_size) VALUES (%s, %s, %s, %s, %s, %s, %d, %d, %d, %s, %d)",
			MilBase.SQLStr(game.GetMap()),
			MilBase.SQLStr(data.name),
			MilBase.SQLStr(util.TypeToString(pos)),
			MilBase.SQLStr(util.TypeToString(ang)),
			MilBase.SQLStr(data.factions),
			MilBase.SQLStr(data.certs),
			data.requireAll,
			data.minRank,
			data.maxRank,
			MilBase.SQLStr(data.rankGroups),
			data.zoneSize
		)

		MilBase.DB.Insert(sqlText, function(id)
			if not id then
				if IsValid(ply) then MilBase.Notify(ply, "Spawn point could not be saved.", "danger") end
				return
			end
			MilBase.SpawnSelector.Spawns[tonumber(id)] = {
				id = tonumber(id), name = data.name, pos = pos, ang = ang,
				factions = data.factions, certs = data.certs, requireAll = data.requireAll,
				minRank = data.minRank, maxRank = data.maxRank, rankGroups = data.rankGroups,
				zoneSize = data.zoneSize,
			}
			if IsValid(ply) then MilBase.Notify(ply, "Spawn point added: " .. data.name .. ".", "ok") end
			if MilBase.Log and IsValid(ply) then
				MilBase.Log("staff", MilBase.LogTag(ply) .. " added spawn point " .. data.name .. ".", ply)
			end
		end)
		return true
	end

	function MilBase.SpawnSelectorNearest(pos, radius)
		local best, bestD
		local maxD = (radius or 220) ^ 2
		for id, spawn in pairs(MilBase.SpawnSelector.Spawns or {}) do
			local d = spawn.pos and spawn.pos:DistToSqr(pos) or math.huge
			if d <= maxD and (not bestD or d < bestD) then
				best, bestD = spawn, d
			end
		end
		return best
	end

	function MilBase.SpawnSelectorUpdateNearest(ply, pos, ang, data)
		if not canConfigure(ply) or not isvector(pos) then return false end
		local spawn = MilBase.SpawnSelectorNearest(pos, 260)
		if not spawn then
			MilBase.Notify(ply, "No spawn point close enough to update.", "warn")
			return false
		end

		ang = isangle(ang) and ang or spawn.ang or angle_zero
		data = sanitizeData(data)
		MilBase.DB.Run(string.format(
			"UPDATE frontier_spawn_points SET name = %s, pos = %s, ang = %s, factions = %s, certs = %s, require_all = %d, min_rank = %d, max_rank = %d, rank_groups = %s, zone_size = %d WHERE id = %d AND map = %s",
			MilBase.SQLStr(data.name),
			MilBase.SQLStr(util.TypeToString(pos)),
			MilBase.SQLStr(util.TypeToString(ang)),
			MilBase.SQLStr(data.factions),
			MilBase.SQLStr(data.certs),
			data.requireAll,
			data.minRank,
			data.maxRank,
			MilBase.SQLStr(data.rankGroups),
			data.zoneSize,
			spawn.id,
			MilBase.SQLStr(game.GetMap())
		))

		spawn.name = data.name
		spawn.pos = pos
		spawn.ang = ang
		spawn.factions = data.factions
		spawn.certs = data.certs
		spawn.requireAll = data.requireAll
		spawn.minRank = data.minRank
		spawn.maxRank = data.maxRank
		spawn.rankGroups = data.rankGroups
		spawn.zoneSize = data.zoneSize
		MilBase.Notify(ply, "Spawn point updated: " .. data.name .. ".", "ok")
		return true
	end

	function MilBase.SpawnSelectorRemoveNearest(ply, pos, radius)
		if not canConfigure(ply) then return false end
		local spawn = MilBase.SpawnSelectorNearest(pos, radius or 260)
		if not spawn then
			MilBase.Notify(ply, "No spawn point close enough to remove.", "warn")
			return false
		end

		MilBase.DB.Run("DELETE FROM frontier_spawn_points WHERE id = " .. tonumber(spawn.id) .. " AND map = " .. MilBase.SQLStr(game.GetMap()))
		MilBase.SpawnSelector.Spawns[spawn.id] = nil
		MilBase.DB.Run("DELETE FROM frontier_spawn_choices WHERE spawn_id = " .. tonumber(spawn.id))
		notifyStaff("Spawn point removed: " .. (spawn.name or spawn.id) .. ".", "warn")
		return true
	end

	function MilBase.SpawnSelectorHasAvailableSpawns(ply)
		if not IsValid(ply) or cfg.SpawnSelectorEnabled == false then return false end
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return false end

		for _, spawn in pairs(MilBase.SpawnSelector.Spawns or {}) do
			if MilBase.SpawnSelectorCanUse(ply, spawn) then return true end
		end
		return false
	end

	local function shouldUseDeploymentMenu(ply)
		if cfg.SpawnSelectorEnabled == false then return false end
		if cfg.SpawnSelectorRequireChoiceBeforeSpawn == false then return false end
		if not IsValid(ply) or not ply:IsPlayer() then return false end
		if ply:GetNWBool("mb_jailed", false) or (MilBase.JailIsJailed and MilBase.JailIsJailed(ply)) then return false end
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return false end

		-- Do not soft-lock players on maps with no configured/eligible spawns.
		-- If the DB is still loading, keep them in selection until the list is ready.
		if MilBase.SpawnSelector.Loaded ~= false and not MilBase.SpawnSelectorHasAvailableSpawns(ply) then
			return false
		end

		return true
	end

	local function characterSelectionGateActive(ply)
		return IsValid(ply) and (ply.mb_characterSelectionRequired == true or ply.mb_characterSwitching == true)
	end

	function MilBase.SpawnSelectorBeginSelection(ply, reason)
		local characterGate = characterSelectionGateActive(ply)
		if not characterGate and not shouldUseDeploymentMenu(ply) then
			if IsValid(ply) then
				ply.mb_spawn_selecting = false
				ply:SetNWBool("mb_spawn_selecting", false)
				ply:SetNWString("mb_spawn_select_reason", "")
			end
			return false
		end

		ply.mb_spawn_selecting = true
		ply:SetNWBool("mb_spawn_selecting", true)
		ply:SetNWString("mb_spawn_select_reason", tostring(reason or "spawn"))

		-- If the engine has already created a body, hide and freeze it so the
		-- player is truly waiting for deployment instead of standing at default spawn.
		if ply:Alive() then
			ply:StripWeapons()
			ply:StripAmmo()
			ply:GodEnable()
			ply:SetNoDraw(true)
			ply:SetNotSolid(true)
			ply:Freeze(true)
			ply:SetMoveType(MOVETYPE_OBSERVER)
			ply:Spectate(OBS_MODE_ROAMING)
		end

		-- Joining and character switches are a strict two-step flow. Keep the
		-- player in the deployment hold, but do not open the spawn selector until
		-- the character selector has been completed and all character data is ready.
		if characterGate then return true end

		timer.Simple(0.1, function()
			if IsValid(ply) and ply.mb_spawn_selecting and not characterSelectionGateActive(ply) then
				MilBase.SpawnSelectorOpen(ply, true)
			end
		end)
		return true
	end

	function MilBase.SpawnSelectorShouldHoldSpawn(ply)
		if ply.mb_spawn_allow_next_spawn then
			ply.mb_spawn_allow_next_spawn = nil
			return false
		end

		-- Character selection is the first deployment gate even before faction
		-- data and eligible spawn points have finished loading.
		if characterSelectionGateActive(ply) then
			ply.mb_spawn_selecting = true
			ply:SetNWBool("mb_spawn_selecting", true)
			ply:SetNWString("mb_spawn_select_reason", "character")
			return true
		end

		if not ply.mb_spawn_selecting then return false end
		if not shouldUseDeploymentMenu(ply) then
			ply.mb_spawn_selecting = false
			ply:SetNWBool("mb_spawn_selecting", false)
			return false
		end

		return true
	end

	function MilBase.SpawnSelectorHoldSpawn(ply)
		if not IsValid(ply) then return end
		MilBase.SpawnSelectorBeginSelection(ply, "spawn")
	end

	local function spawnZoneCandidate(spawn, firstAttempt)
		local base = spawn.pos or vector_origin
		local size = cleanZoneSize(spawn.zoneSize or spawn.zone_size)
		if firstAttempt or size <= 0 then return base + Vector(0, 0, 8) end

		local half = size * 0.5
		local ang = spawn.ang or angle_zero
		local yaw = Angle(0, ang.y or 0, 0)
		local candidate = base + yaw:Forward() * math.Rand(-half, half) + yaw:Right() * math.Rand(-half, half)
		local tr = util.TraceLine({
			start = candidate + Vector(0, 0, 96),
			endpos = candidate - Vector(0, 0, 256),
			mask = MASK_PLAYERSOLID_BRUSHONLY,
		})
		if tr.Hit then candidate = tr.HitPos end
		return candidate + Vector(0, 0, 8)
	end

	local function spawnSpotClear(ply, pos)
		local mins, maxs = ply:GetHull()
		if not isvector(mins) or not isvector(maxs) then
			mins, maxs = Vector(-16, -16, 0), Vector(16, 16, 72)
		end

		local tr = util.TraceHull({
			start = pos,
			endpos = pos,
			mins = mins,
			maxs = maxs,
			filter = ply,
			mask = MASK_PLAYERSOLID,
		})
		if tr.Hit then return false end

		local pad = tonumber(cfg.SpawnSelectorSpawnPadding or 32) or 32
		for _, ent in ipairs(ents.FindInBox(pos + mins - Vector(pad, pad, 0), pos + maxs + Vector(pad, pad, 8))) do
			if IsValid(ent) and ent ~= ply and ent:IsPlayer() and ent:Alive() and not ent:GetNoDraw() then
				return false
			end
		end

		return true
	end

	function MilBase.SpawnSelectorFindDeployPosition(ply, spawn)
		if not spawn or not isvector(spawn.pos) then return vector_origin end
		local attempts = math.max(1, math.floor(tonumber(cfg.SpawnSelectorSpawnAttempts or 24) or 24))
		local fallback = spawnZoneCandidate(spawn, true)

		for i = 1, attempts do
			local candidate = spawnZoneCandidate(spawn, i == 1)
			if spawnSpotClear(ply, candidate) then
				return candidate, true
			end
		end

		return fallback, false
	end

	local function finishDeployment(ply)
		ply.mb_spawn_selecting = false
		ply.mb_spawn_allow_next_spawn = true
		ply:SetNWBool("mb_spawn_selecting", false)
		ply:SetNWString("mb_spawn_select_reason", "")

		if ply:Alive() then
			ply:UnSpectate()
			ply:SetNoDraw(false)
			ply:SetNotSolid(false)
			ply:Freeze(false)
			ply:GodDisable()
		end
	end

	function MilBase.SpawnSelectorDeploy(ply)
		if not IsValid(ply) then return false end
		local ok, spawn = MilBase.SpawnSelectorValidateChoice(ply, false)
		if not ok or not spawn then
			MilBase.SpawnSelectorBeginSelection(ply, "spawn")
			return false
		end

		finishDeployment(ply)

		local deathTime = ply:GetNWFloat("mb_deathtime", 0)
		local wait = (deathTime + (cfg.RespawnTime or 0)) - CurTime()
		if not ply:Alive() and wait > 0 then
			timer.Simple(wait, function()
				if IsValid(ply) and not ply:Alive() and not ply.mb_spawn_selecting then
					ply.mb_spawn_allow_next_spawn = true
					ply:Spawn()
				end
			end)
			MilBase.Notify(ply, "Deploying in " .. math.ceil(wait) .. " seconds...", "warn")
		else
			ply:Spawn()
		end

		return true
	end

	function MilBase.SpawnSelectorDeathThink(ply)
		if not shouldUseDeploymentMenu(ply) then return false end

		local deathTime = ply:GetNWFloat("mb_deathtime", 0)
		if CurTime() < deathTime + (cfg.RespawnTime or 0) then return false end

		if not ply.mb_spawn_selecting then
			MilBase.SpawnSelectorBeginSelection(ply, "death")
		end

		-- Block the normal click/jump respawn until a spawn is chosen.
		return true
	end

	function MilBase.SpawnSelectorValidateChoice(ply, silent)
		if not IsValid(ply) then return false end
		local choice = tonumber(ply:GetNWInt("mb_spawn_choice", 0)) or 0
		if choice <= 0 then return false end

		local spawn = MilBase.SpawnSelectorGetSpawn(choice)
		if not spawn and MilBase.SpawnSelector.Loaded == false then
			return true, nil
		end

		local allowed = spawn and MilBase.SpawnSelectorCanUse(ply, spawn)
		if allowed then return true, spawn end

		ply:SetNWInt("mb_spawn_choice", 0)
		MilBase.DB.Run("DELETE FROM frontier_spawn_choices WHERE steamid = " .. MilBase.SQLStr(ply:MBCharacterKey()))
		if shouldUseDeploymentMenu(ply) then
			ply.mb_spawn_selecting = true
			ply:SetNWBool("mb_spawn_selecting", true)
		end
		if not silent then MilBase.Notify(ply, "Your selected spawn is no longer available for your current faction/rank/spec.", "warn") end
		return false
	end

	function MilBase.SpawnSelectorSetChoice(ply, id)
		id = tonumber(id or 0) or 0
		local spawn = MilBase.SpawnSelectorGetSpawn(id)
		local allowed, reason = MilBase.SpawnSelectorCanUse(ply, spawn)
		if not allowed then
			MilBase.Notify(ply, "You cannot use that spawn: " .. tostring(reason or "restricted") .. ".", "warn")
			MilBase.SpawnSelectorOpen(ply)
			return false
		end

		ply:SetNWInt("mb_spawn_choice", id)
		MilBase.DB.Run(string.format("REPLACE INTO frontier_spawn_choices (steamid, spawn_id) VALUES (%s, %d)",
			MilBase.SQLStr(ply:MBCharacterKey()), id))

		if cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false and (ply.mb_spawn_selecting or not ply:Alive()) then
			MilBase.Notify(ply, "Deploying to " .. (spawn.name or ("#" .. id)) .. ".", "ok")
			return MilBase.SpawnSelectorDeploy(ply)
		end

		MilBase.Notify(ply, "Spawn selected: " .. (spawn.name or ("#" .. id)) .. ". You will deploy there next respawn.", "ok")
		return true
	end

	function MilBase.SpawnSelectorOpen(ply, forced)
		if not IsValid(ply) or cfg.SpawnSelectorEnabled == false then return end
		if characterSelectionGateActive(ply) then
			if ply.mb_characterSelectionRequired and MilBase.SendCharacterMenu then
				MilBase.SendCharacterMenu(ply, true)
			end
			return
		end
		MilBase.SpawnSelectorValidateChoice(ply, true)
		forced = forced or ply.mb_spawn_selecting or false

		net.Start(NET_OPEN)
			net.WriteTable(MilBase.SpawnSelectorBuildList(ply))
			net.WriteUInt(math.max(0, tonumber(ply:GetNWInt("mb_spawn_choice", 0)) or 0), 32)
			net.WriteBool(forced == true)
		net.Send(ply)
	end

	function MilBase.SpawnSelectorMaybeOpen(ply)
		if not IsValid(ply) or cfg.SpawnSelectorEnabled == false then return end
		if cfg.SpawnSelectorAutoOpenIfNoChoice == false and not ply.mb_spawn_selecting then return end
		if tonumber(ply:GetNWInt("mb_spawn_choice", 0)) > 0 and not ply.mb_spawn_selecting then return end
		timer.Simple(1, function()
			if IsValid(ply) then MilBase.SpawnSelectorOpen(ply, ply.mb_spawn_selecting) end
		end)
	end

	net.Receive(NET_SELECT, function(_, ply)
		local id = net.ReadUInt(32)
		MilBase.SpawnSelectorSetChoice(ply, id)
	end)

	hook.Add("InitPostEntity", "MilBase.SpawnSelector.Reload", function()
		MilBase.SpawnSelectorReload()
	end)

	hook.Add("PostCleanupMap", "MilBase.SpawnSelector.Reload", function()
		timer.Simple(0, function()
			if MilBase.SpawnSelectorReload then MilBase.SpawnSelectorReload() end
		end)
	end)

	hook.Add("PlayerInitialSpawn", "MilBase.SpawnSelector.MarkPending", function(ply)
		if cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false and cfg.SpawnSelectorOpenOnJoin ~= false then
			ply.mb_spawn_selecting = true
			ply:SetNWBool("mb_spawn_selecting", true)
			ply:SetNWString("mb_spawn_select_reason", "join")
		end
	end)

	hook.Add("MilBase.PlayerLoaded", "MilBase.SpawnSelector.LoadChoice", function(ply)
		local key = ply:MBCharacterKey()
		local token = ply:MBCharacterLoadToken()
		local function finishChoice(rows)
			if not MilBase.CharacterLoadStillCurrent(ply, key, token) then return end
			rows = rows or {}
			local id = rows[1] and tonumber(rows[1].spawn_id) or 0
			ply:SetNWInt("mb_spawn_choice", id or 0)
			MilBase.SpawnSelectorValidateChoice(ply, true)

			if cfg.SpawnSelectorOpenOnJoin ~= false then
				if cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false then
					MilBase.SpawnSelectorBeginSelection(ply,
						ply.mb_characterSelectionRequired and "character" or "join")
				elseif not characterSelectionGateActive(ply) then
					MilBase.SpawnSelectorMaybeOpen(ply)
				end
			end
			ply.mb_characterSpawnChoiceLoadedToken = token
			hook.Run("MilBase.SpawnChoiceLoaded", ply, id or 0, token)
		end
		MilBase.DB.Query("SELECT spawn_id FROM frontier_spawn_choices WHERE steamid = "
			.. MilBase.SQLStr(key), finishChoice, function() finishChoice({}) end)
	end)

	hook.Add("PlayerSpawn", "MilBase.SpawnSelector.Apply", function(ply)
		if cfg.SpawnSelectorEnabled == false then return end
		if ply.mb_spawn_selecting then return end
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ply) then return end

		local ok, spawn = MilBase.SpawnSelectorValidateChoice(ply, true)
		if not ok or not spawn then
			if cfg.SpawnSelectorOpenOnSpawnNoChoice then MilBase.SpawnSelectorMaybeOpen(ply) end
			return
		end

		timer.Simple(0, function()
			if not IsValid(ply) or not ply:Alive() then return end
			local _, currentSpawn = MilBase.SpawnSelectorValidateChoice(ply, true)
			if not currentSpawn then return end
			local deployPos = MilBase.SpawnSelectorFindDeployPosition(ply, currentSpawn)
			ply:SetPos(deployPos)
			local ang = currentSpawn.ang or angle_zero
			ply:SetEyeAngles(Angle(0, ang.y or 0, 0))
			ply:SetLocalVelocity(vector_origin)
		end)
	end)

	hook.Add("PlayerDeath", "MilBase.SpawnSelector.DeathMenu", function(ply)
		if cfg.SpawnSelectorOpenOnDeath == false then return end
		if cfg.SpawnSelectorRequireChoiceBeforeSpawn ~= false and shouldUseDeploymentMenu(ply) then
			ply.mb_spawn_selecting = true
			ply:SetNWBool("mb_spawn_selecting", true)
			ply:SetNWString("mb_spawn_select_reason", "death")
		else
			ply.mb_spawn_selecting = false
			ply:SetNWBool("mb_spawn_selecting", false)
			ply:SetNWString("mb_spawn_select_reason", "")
		end

		timer.Simple(math.max(0.5, cfg.RespawnTime or 8), function()
			if IsValid(ply) and not ply:Alive() then MilBase.SpawnSelectorOpen(ply, ply.mb_spawn_selecting and shouldUseDeploymentMenu(ply)) end
		end)
	end)

	MilBase.RegisterChatCommand("spawns", {
		help = "Open the spawn selector.",
		func = function(ply)
			MilBase.SpawnSelectorOpen(ply)
		end,
	})
	MilBase.RegisterChatCommand("spawnselector", {
		help = "Open the spawn selector.",
		func = function(ply)
			MilBase.SpawnSelectorOpen(ply)
		end,
	})

	return
end

--------------------------------------------------------------------------
-- Client UI
--------------------------------------------------------------------------

local fallbackUI = {
	bg = Color(6, 6, 7, 240),
	panel = Color(10, 10, 11, 218),
	raised = Color(255, 198, 60, 10),
	hover = Color(255, 198, 60, 25),
	outline = Color(255, 198, 60, 50),
	accent = Color(255, 198, 60),
	text = Color(240, 238, 230),
	dim = Color(170, 162, 140),
	faint = Color(112, 106, 92),
	ok = Color(150, 205, 125),
	danger = Color(220, 80, 70),
	warn = Color(255, 215, 135),
}

local function hasMilBaseUI()
	return MilBase and MilBase.UI and MilBase.DrawPanelBF2 and MilBase.DrawBrackets and MilBase.DrawIcon
end

local function spawnUI()
	return (MilBase and MilBase.UI) or fallbackUI
end

local function uiColor(color, alpha)
	if not color then return Color(255, 255, 255, alpha or 255) end
	return Color(color.r or 255, color.g or 255, color.b or 255, alpha or color.a or 255)
end

local function uiFont(milbaseFont, fallbackFont)
	if hasMilBaseUI() and milbaseFont and milbaseFont ~= "" then return milbaseFont end
	return fallbackFont or "DermaDefault"
end

local function playUISound(id)
	if MilBase and MilBase.PlayUISound then
		MilBase.PlayUISound(id)
	elseif id == "select" then
		surface.PlaySound("ui/buttonclickrelease.wav")
	elseif id == "hover" then
		surface.PlaySound("ui/buttonrollover.wav")
	end
end

local function drawDeploymentPanel(x, y, w, h, opts)
	opts = opts or {}
	if hasMilBaseUI() then
		MilBase.DrawPanelBF2(x, y, w, h, opts)
		return
	end

	surface.SetDrawColor(opts.color or fallbackUI.panel)
	surface.DrawRect(x, y, w, h)
	if opts.outline ~= false then
		surface.SetDrawColor(opts.outlineColor or fallbackUI.outline)
		surface.DrawOutlinedRect(x, y, w, h)
	end
	if opts.accent then
		surface.SetDrawColor(opts.accent)
		surface.DrawRect(x, y, 3, h)
	end
end

local function paintDeploymentButton(self, w, h, label, accent, font)
	local ui = spawnUI()
	local hovered = self:IsHovered()
	local enabled = self:IsEnabled()
	local fill = enabled and ui.raised or Color(255, 255, 255, 4)
	if hovered and enabled then fill = uiColor(accent or ui.accent, 46) end

	drawDeploymentPanel(0, 0, w, h, {
		cut = 8,
		color = fill,
		accent = enabled and (accent or ui.accent) or nil,
	})

	if hovered and enabled and hasMilBaseUI() then
		MilBase.DrawBrackets(3, 3, w - 6, h - 6, accent or ui.accent, 9)
	end

	draw.SimpleText(label, font or uiFont("MB.Tab", "DermaDefaultBold"), w / 2, h / 2 - 1,
		enabled and ui.text or ui.faint, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local frame
local previewTarget
local activeSpawn

local function clearPreview()
	previewTarget = nil
	activeSpawn = nil
end

local function setPreview(spawn)
	if not spawn or not spawn.allowed or not isvector(spawn.pos) then return end
	local ang = isangle(spawn.ang) and spawn.ang or angle_zero
	local lookAt = spawn.pos + Vector(0, 0, 46)
	local origin = spawn.pos - ang:Forward() * 720 + ang:Right() * 320 + Vector(0, 0, 280)
	previewTarget = {
		id = tonumber(spawn.id) or 0,
		origin = origin,
		angles = (lookAt - origin):Angle(),
	}
	activeSpawn = spawn
end

hook.Add("CalcView", "MilBase.SpawnSelector.Preview", function(ply, pos, angles, fov)
	if not previewTarget or not IsValid(frame) then return end
	return {
		origin = previewTarget.origin,
		angles = previewTarget.angles,
		fov = math.Clamp((fov or 75) + 8, 75, 95),
		drawviewer = false,
	}
end)

local function firstAllowed(spawns, selectedID)
	local fallback
	for _, spawn in ipairs(spawns or {}) do
		if spawn.allowed and isvector(spawn.pos) then
			fallback = fallback or spawn
			if tonumber(spawn.id) == selectedID then return spawn end
		end
	end
	return fallback
end

function MilBase.OpenSpawnSelector(spawns, selectedID, forced)
	if MilBase.CloseCharacterSelector then MilBase.CloseCharacterSelector() end
	if MilBase.CloseMenu then MilBase.CloseMenu() end
	spawns = spawns or {}
	selectedID = tonumber(selectedID or 0) or 0
	forced = forced == true

	if IsValid(frame) then frame:Remove() end
	clearPreview()

	local ui = spawnUI()
	local margin = math.floor(ScrW() * 0.055)
	local sidebarW = math.min(500, math.max(410, math.floor(ScrW() * 0.35)))
	local bottomH = 44

	frame = vgui.Create("DFrame")
	frame:SetSize(ScrW(), ScrH())
	frame:SetPos(0, 0)
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(false)
	frame:MakePopup()
	frame.OnRemove = function() clearPreview() end
	frame.Think = function()
		if forced and gui.IsGameUIVisible() then gui.HideGameUI() end
	end
	frame.Paint = function(self, w, h)
		if hasMilBaseUI() then
			if not (MilBase.DrawIcon(ui.art and ui.art.scoreboard, 0, 0, w, h)) and MilBase.DrawBlur then
				MilBase.DrawBlur(self, 6)
			end
		else
			surface.SetDrawColor(0, 0, 0, 230)
			surface.DrawRect(0, 0, w, h)
		end

		surface.SetDrawColor(0, 0, 0, 168)
		surface.DrawRect(0, 0, w, h)

		drawDeploymentPanel(margin, 24, sidebarW, h - 24 - bottomH - 14, {
			cut = 10,
			color = Color(8, 8, 9, 224),
			accent = ui.accent,
		})

		if hasMilBaseUI() and ui.art and ui.art.bf2 then
			MilBase.DrawIcon(ui.art.bf2.hex, margin + 18, 46, 15, 15, ui.accent)
			MilBase.DrawIcon(ui.art.bf2.underline, margin + 18, 98, sidebarW - 36, 16)
		end

		draw.SimpleText("DEPLOYMENT", uiFont("MB.Huge", "DermaLarge"),
			margin + 42, 33, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText("SELECT SPAWN POINT", uiFont("MB.Small", "DermaDefaultBold"),
			margin + 22, 94, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local help = forced and "Preview an available spawn, then deploy." or "Set your preferred deployment point."
		draw.SimpleText(help, uiFont("MB.Tiny", "DermaDefault"),
			margin + 22, 116, forced and ui.warn or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		-- Mirror the character selector's two-step header so the transition feels
		-- like one continuous PERSONNEL -> DEPLOYMENT workflow.
		if w >= 960 then
			local stepX = w - margin - 310
			draw.SimpleText("01", uiFont("MB.NumSmall", "DermaLarge"), stepX, 27, ui.ok)
			draw.SimpleText("CHARACTER", uiFont("MB.Small", "DermaDefaultBold"), stepX + 42, 38, ui.dim)
			surface.SetDrawColor(uiColor(ui.accent, 120))
			surface.DrawRect(stepX + 134, 45, 54, 1)
			draw.SimpleText("02", uiFont("MB.NumSmall", "DermaLarge"), stepX + 205, 27, ui.accent)
			draw.SimpleText("DEPLOY", uiFont("MB.Small", "DermaDefaultBold"), stepX + 247, 38, ui.text)
		end

		local cardW = math.min(560, math.floor(w * 0.38))
		local cardH = 120
		local cardX = w - margin - cardW
		local cardY = h - bottomH - cardH - 26
		drawDeploymentPanel(cardX, cardY, cardW, cardH, {
			cut = 10,
			color = Color(6, 6, 7, 178),
			accent = ui.accent,
		})

		if activeSpawn then
			draw.SimpleText("ACTIVE CAMERA", uiFont("MB.Tiny", "DermaDefault"),
				cardX + 18, cardY + 15, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(string.upper(activeSpawn.name or ("SPAWN #" .. tostring(activeSpawn.id))), uiFont("MB.Big", "DermaLarge"),
				cardX + 18, cardY + 34, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText(activeSpawn.access or "Available", uiFont("MB.Small", "DermaDefault"),
				cardX + 18, cardY + 76, ui.accent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		else
			draw.SimpleText("NO SPAWN SELECTED", uiFont("MB.Big", "DermaLarge"),
				cardX + 18, cardY + 42, ui.danger, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			draw.SimpleText("Select an available spawn from the left panel.", uiFont("MB.Small", "DermaDefault"),
				cardX + 18, cardY + 78, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		end

		surface.SetDrawColor(0, 0, 0, 178)
		surface.DrawRect(0, h - bottomH, w, bottomH)
		surface.SetDrawColor(uiColor(ui.accent, 70))
		surface.DrawRect(0, h - bottomH, w, 1)
		draw.SimpleText(forced and "SELECT A SPAWN TO ENTER THE SERVER" or "SPAWN SELECTOR",
			uiFont("MB.Tiny", "DermaDefault"), margin + 18, h - bottomH / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local list = vgui.Create("DScrollPanel", frame)
	list:SetPos(margin + 20, 148)
	list:SetSize(sidebarW - 40, ScrH() - 286)

	if #spawns == 0 then
		local empty = vgui.Create("DLabel", list)
		empty:SetText("No spawn points are available for your current faction/rank/spec.")
		empty:SetTextColor(ui.text)
		empty:SetFont(uiFont("MB.Med", "DermaDefaultBold"))
		empty:SetPos(8, 8)
		empty:SizeToContents()
	else
		for _, spawn in ipairs(spawns) do
			local button = list:Add("DButton")
			button:SetTall(78)
			button:Dock(TOP)
			button:DockMargin(0, 0, 0, 8)
			button:SetText("")
			button:SetEnabled(spawn.allowed == true)
			button.Paint = function(self, w, h)
				local allowed = spawn.allowed == true
				local selected = activeSpawn and tonumber(activeSpawn.id) == tonumber(spawn.id)
				local hovered = self:IsHovered() and allowed
				local fill = selected and uiColor(ui.accent, 32) or Color(0, 0, 0, hovered and 126 or 92)
				if not allowed then fill = Color(0, 0, 0, 70) end

				drawDeploymentPanel(0, 0, w, h, {
					cut = 8,
					color = fill,
					accent = selected and ui.accent or (allowed and uiColor(ui.accent, 42) or uiColor(ui.faint, 50)),
				})

				if (selected or hovered) and hasMilBaseUI() then
					MilBase.DrawBrackets(3, 3, w - 6, h - 6, selected and ui.accent or ui.dim, 9)
				end

				local name = string.upper(spawn.name or ("SPAWN #" .. tostring(spawn.id)))
				local status = allowed and (selected and "PREVIEWING" or (selectedID == tonumber(spawn.id) and "CURRENT" or "AVAILABLE")) or string.upper(spawn.reason or "LOCKED")
				draw.SimpleText(name, uiFont("MB.Med", "DermaDefaultBold"),
					16, 10, allowed and ui.text or ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(status, uiFont("MB.Tiny", "DermaDefault"),
					17, 34, allowed and ui.accent or ui.danger, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
				draw.SimpleText(spawn.access or "", uiFont("MB.Tiny", "DermaDefault"),
					17, 54, allowed and ui.dim or ui.faint, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
			button.DoClick = function()
				if not spawn.allowed then return end
				playUISound("select")
				setPreview(spawn)
			end
		end
	end

	local deploy = vgui.Create("DButton", frame)
	deploy:SetPos(margin + 20, ScrH() - bottomH - 82)
	deploy:SetSize(math.floor((sidebarW - 48) * (forced and 1 or 0.58)), 48)
	deploy:SetText("")
	deploy.Paint = function(self, w, h)
		local label = forced and "DEPLOY HERE" or "SET SPAWN"
		paintDeploymentButton(self, w, h, label, ui.ok, uiFont("MB.Tab", "DermaDefaultBold"))
	end
	deploy.Think = function(self)
		self:SetEnabled(activeSpawn ~= nil)
	end
	deploy.DoClick = function()
		if not activeSpawn then return end
		playUISound("select")
		net.Start(NET_SELECT)
			net.WriteUInt(tonumber(activeSpawn.id) or 0, 32)
		net.SendToServer()
		if IsValid(frame) then frame:Close() end
	end

	if not forced then
		local close = vgui.Create("DButton", frame)
		close:SetPos(margin + 28 + deploy:GetWide(), ScrH() - bottomH - 82)
		close:SetSize(sidebarW - 48 - deploy:GetWide(), 48)
		close:SetText("")
		close.Paint = function(self, w, h)
			paintDeploymentButton(self, w, h, "CLOSE", ui.dim, uiFont("MB.Small", "DermaDefaultBold"))
		end
		close.DoClick = function()
			playUISound("select")
			if IsValid(frame) then frame:Close() end
		end
	end

	local initial = firstAllowed(spawns, selectedID)
	if initial then setPreview(initial) end
end

net.Receive(NET_OPEN, function()
	local spawns = net.ReadTable()
	local selectedID = net.ReadUInt(32)
	local forced = net.ReadBool()
	MilBase.OpenSpawnSelector(spawns, selectedID, forced)
end)
