--[[
	Event triggers & linked actions (Zeus automation).

	A trigger = a CONDITION that, when met, runs one or more ACTIONS. This is
	what turns hacking/objectives into real events: "players enter the hangar
	-> lock the blast doors, spawn a droid wave, create an objective", or
	"slice this console -> open the doors and announce the next objective".

	The game master builds triggers live from the event context menu
	(right-click -> New Trigger Here, or right-click an entity -> Link Trigger).
	Triggers are cleared with /eventclear, on map change and round restart.
]]

-- Conditions (what fires the trigger).
MilBase.TriggerConditions = {
	enter        = "Players Enter Area",
	leave        = "Players Leave Area",
	timer        = "Timer Ends",
	alldead      = "All Enemies Defeated",
	srcfixed     = "Linked Entity Hacked / Repaired",
	srcdestroyed = "Linked Entity Destroyed",
}
MilBase.TriggerConditionOrder = { "enter", "leave", "timer", "alldead", "srcfixed", "srcdestroyed" }

-- Actions (what the trigger does). str/str2/num carry the parameters.
MilBase.TriggerActions = {
	announce  = "Announce",
	spawn     = "Spawn Wave",
	objective = "Create Objective",
	complete  = "Complete Objective",
	doors     = "Toggle Doors In Area",
	explosion = "Explosion",
	alarm     = "Alarm",
}
MilBase.TriggerActionOrder = { "announce", "spawn", "objective", "complete", "doors", "explosion", "alarm" }

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

if SERVER then

	util.AddNetworkString("MilBase_TriggerCreate")
	util.AddNetworkString("MilBase_TriggerDelete")
	util.AddNetworkString("MilBase_TriggerSync")

	MilBase.Triggers = MilBase.Triggers or {}
	local nextID = 0

	-- Push a lightweight summary of every trigger to game masters so their
	-- HUD can draw the zones. `to` = a player, or nil for all event staff.
	function MilBase.SyncTriggers(to)
		local recips = to
		if not recips then
			recips = {}
			for _, p in ipairs(player.GetAll()) do
				if p:GetNWBool("mb_eventmode", false) then recips[#recips + 1] = p end
			end
			if #recips == 0 then return end -- nobody watching
		end

		local list = {}
		for _, t in pairs(MilBase.Triggers) do
			list[#list + 1] = { id = t.id, pos = t.pos, radius = t.radius,
				condition = t.condition, na = #t.actions }
		end

		net.Start("MilBase_TriggerSync")
			net.WriteUInt(#list, 8)
			for _, s in ipairs(list) do
				net.WriteUInt(s.id, 16)
				net.WriteVector(s.pos)
				net.WriteFloat(s.radius)
				net.WriteString(s.condition)
				net.WriteUInt(s.na, 5)
			end
		net.Send(recips)
	end

	function MilBase.ClearTriggers()
		MilBase.Triggers = {}
		MilBase.SyncTriggers()
	end

	hook.Add("PostCleanupMap", "MilBase.TriggerClear", function()
		MilBase.Triggers = {}
	end)

	--------------------------------------------------------------------
	-- Door / world control
	--------------------------------------------------------------------

	local DOOR_CLASSES = {
		func_door = true, func_door_rotating = true,
		prop_door_rotating = true, func_movelinear = true,
	}

	local function fireDoors(pos, radius, mode)
		for _, e in ipairs(ents.FindInSphere(pos, radius)) do
			if not DOOR_CLASSES[e:GetClass()] then continue end
			if mode == "open" then
				e:Fire("Unlock") e:Fire("Open")
			elseif mode == "close" then
				e:Fire("Close")
			elseif mode == "lock" then
				e:Fire("Lock")
			elseif mode == "unlock" then
				e:Fire("Unlock")
			end
		end
	end

	--------------------------------------------------------------------
	-- Action execution
	--------------------------------------------------------------------

	local function runAction(trig, act)
		local owner = trig.owner

		if act.kind == "announce" then
			MilBase.Announce("all", act.str ~= "" and act.str or "Objective update.")

		elseif act.kind == "spawn" then
			local def = MilBase.EventSpawns[act.str]
			if def then
				for _ = 1, math.Clamp(act.num or 1, 1, 24) do
					local off = VectorRand() * (trig.radius * 0.35)
					off.z = 0
					MilBase.DoEventSpawn(owner, def, trig.pos + off, math.random(0, 360))
				end
			end

		elseif act.kind == "objective" then
			MilBase.AddObjective(owner, { pos = trig.pos, otype = act.str, name = act.str2 })

		elseif act.kind == "complete" then
			-- Tick the nearest objective to the zone complete.
			if MilBase.NearestObjective then
				local id = MilBase.NearestObjective(trig.pos, math.max(trig.radius, 1500))
				if id then MilBase.CompleteObjective(id) end
			end

		elseif act.kind == "doors" then
			fireDoors(trig.pos, math.max(trig.radius, 128), act.str)

		elseif act.kind == "explosion" then
			local attacker = (IsValid(owner) and owner) or game.GetWorld()
			local fx = EffectData()
			fx:SetOrigin(trig.pos)
			fx:SetScale(1)
			util.Effect("HelicopterMegaBomb", fx)
			util.Effect("Explosion", fx)
			util.BlastDamage(attacker, attacker, trig.pos, 320, 160)

		elseif act.kind == "alarm" then
			sound.Play("ambient/alarms/klaxon1.wav", trig.pos, 105, 100, 1)
		end
	end

	local function fireTrigger(trig)
		for _, act in ipairs(trig.actions) do runAction(trig, act) end
		if trig.once then trig.fired = true end
		trig.cooldown = CurTime() + 0.5 -- avoid double-fire within a tick window
	end

	--------------------------------------------------------------------
	-- Create / delete
	--------------------------------------------------------------------

	local function brokenState(e)
		if not IsValid(e) then return false end
		if e.GetBroken then return e:GetBroken() end
		if e.GetBreached then return e:GetBreached() end
		return false
	end

	net.Receive("MilBase_TriggerCreate", function(_, ply)
		if not MilBase.CanRunEvents(ply) or not ply:GetNWBool("mb_eventmode", false) then return end

		local condition = net.ReadString()
		local pos = net.ReadVector()
		local radius = math.Clamp(net.ReadFloat(), 64, 8192)
		local delay = math.Clamp(net.ReadFloat(), 0, 3600)
		local once = net.ReadBool()
		local faction = net.ReadString()

		local src = NULL
		if net.ReadBool() then src = net.ReadEntity() end

		local n = net.ReadUInt(5)
		local actions = {}
		for i = 1, n do
			actions[i] = {
				kind = net.ReadString(),
				str  = net.ReadString(),
				str2 = net.ReadString(),
				num  = net.ReadUInt(8),
			}
		end

		if not MilBase.TriggerConditions[condition] then return end
		if not isvector(pos) then return end
		if #actions == 0 then
			MilBase.Notify(ply, "Add at least one action to the trigger.")
			return
		end
		if (condition == "srcfixed" or condition == "srcdestroyed") and not IsValid(src) then
			MilBase.Notify(ply, "That trigger needs a linked entity.")
			return
		end

		nextID = nextID + 1
		MilBase.Triggers[nextID] = {
			id = nextID,
			owner = ply,
			condition = condition,
			pos = pos,
			radius = radius,
			delay = delay,
			once = once,
			faction = faction or "",
			src = src,
			actions = actions,
			born = CurTime(),
			fired = false,
			inside = {},
			sawEnemies = false,
			srcWasBroken = brokenState(src),
		}

		MilBase.Notify(ply, "Trigger created: " .. MilBase.TriggerConditions[condition]
			.. " -> " .. #actions .. " action(s).")
		MilBase.SyncTriggers()
	end)

	net.Receive("MilBase_TriggerDelete", function(_, ply)
		if not MilBase.CanRunEvents(ply) then return end
		local id = net.ReadUInt(16)
		if MilBase.Triggers[id] then
			MilBase.Triggers[id] = nil
			MilBase.Notify(ply, "Trigger removed.")
			MilBase.SyncTriggers()
		end
	end)

	--------------------------------------------------------------------
	-- Evaluation loop
	--------------------------------------------------------------------

	local nextEval = 0
	hook.Add("Think", "MilBase.TriggerThink", function()
		if CurTime() < nextEval then return end
		nextEval = CurTime() + 0.3

		for id, trig in pairs(MilBase.Triggers) do
			if trig.fired then continue end
			if (trig.cooldown or 0) > CurTime() then continue end
			local c = trig.condition

			if c == "enter" or c == "leave" then
				local r2 = trig.radius * trig.radius
				for _, p in ipairs(player.GetAll()) do
					if not p:Alive() or p:GetNWBool("mb_eventmode", false) then continue end
					if trig.faction ~= "" and p:MBFactionID() ~= trig.faction then continue end

					local inside = p:GetPos():DistToSqr(trig.pos) <= r2
					local was = trig.inside[p]
					trig.inside[p] = inside

					if c == "enter" and inside and not was then fireTrigger(trig) break
					elseif c == "leave" and was and not inside then fireTrigger(trig) break end
				end

			elseif c == "timer" then
				if CurTime() >= trig.born + trig.delay then
					fireTrigger(trig)
					trig.born = CurTime() -- restart countdown (repeats unless once)
				end

			elseif c == "alldead" then
				local live = 0
				for _, e in ipairs(MilBase.EventEntities) do
					if IsValid(e) and (e.LVS or (e:IsNPC() and e:Health() > 0)) then
						live = live + 1
					end
				end
				if live > 0 then trig.sawEnemies = true end
				if trig.sawEnemies and live == 0 then
					fireTrigger(trig)
					trig.sawEnemies = false -- re-arm only after new enemies appear
				end

			elseif c == "srcfixed" then
				if not IsValid(trig.src) then trig.fired = true continue end
				local broken = brokenState(trig.src)
				if broken then trig.srcWasBroken = true
				elseif trig.srcWasBroken then
					fireTrigger(trig)
					trig.srcWasBroken = false -- must break again to re-fire
				end

			elseif c == "srcdestroyed" then
				-- Can't un-destroy: fire once and retire regardless of `once`.
				if not IsValid(trig.src) then fireTrigger(trig) trig.fired = true end
			end
		end
	end)

	return
end

--------------------------------------------------------------------------
-- Client: zone visualization + trigger builder
--------------------------------------------------------------------------

MilBase.TriggerSummaries = MilBase.TriggerSummaries or {}

net.Receive("MilBase_TriggerSync", function()
	local list = {}
	local n = net.ReadUInt(8)
	for i = 1, n do
		list[i] = {
			id = net.ReadUInt(16),
			pos = net.ReadVector(),
			radius = net.ReadFloat(),
			condition = net.ReadString(),
			na = net.ReadUInt(5),
		}
	end
	MilBase.TriggerSummaries = list
end)

-- Translucent trigger zones, drawn only in the game-master view.
hook.Add("PostDrawTranslucentRenderables", "MilBase.TriggerZones", function(_, sky)
	if sky or not MilBase.InEventView() then return end
	render.SetColorMaterial()
	for _, t in ipairs(MilBase.TriggerSummaries) do
		render.DrawSphere(t.pos, t.radius, 22, 22, Color(255, 120, 60, 16))
		render.DrawSphere(t.pos, -t.radius, 22, 22, Color(255, 120, 60, 16))
	end
end)

hook.Add("HUDPaint", "MilBase.TriggerLabels", function()
	if not MilBase.InEventView() then return end
	for _, t in ipairs(MilBase.TriggerSummaries) do
		local scr = (t.pos + Vector(0, 0, 12)):ToScreen()
		if scr.visible then
			local name = MilBase.TriggerConditions[t.condition] or t.condition
			draw.SimpleTextOutlined("TRIGGER  " .. name .. "  (" .. t.na .. ")",
				"MB.Tiny", scr.x, scr.y, Color(255, 180, 90), TEXT_ALIGN_CENTER,
				TEXT_ALIGN_CENTER, 1, color_black)
		end
	end
end)

--------------------------------------------------------------------------
-- Builder UI
--------------------------------------------------------------------------

local function actionDetail(a)
	if a.kind == "announce" then return '"' .. a.str .. '"'
	elseif a.kind == "spawn" then return a.str2 .. "  x" .. a.num
	elseif a.kind == "objective" then
		local ot = MilBase.ObjectiveTypes[a.str]
		return (ot and ot.name or a.str) .. ": " .. a.str2
	elseif a.kind == "complete" then return "nearest objective in zone"
	elseif a.kind == "doors" then return string.upper(a.str) .. " doors in area"
	elseif a.kind == "explosion" then return "detonate at zone"
	elseif a.kind == "alarm" then return "sound klaxon"
	end
	return ""
end

function MilBase.OpenTriggerBuilder(worldPos, srcEnt)
	local ui = MilBase.UI
	local actions = {}

	MilBase.EventModal = true

	if IsValid(MilBase.TriggerBuilderFrame) then MilBase.TriggerBuilderFrame:Remove() end

	local frame = vgui.Create("DFrame")
	MilBase.TriggerBuilderFrame = frame
	frame:SetSize(440, 520)
	frame:Center()
	frame:SetTitle("")
	frame:MakePopup()
	frame:ShowCloseButton(false)
	frame.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 12 })
		draw.SimpleText("TRIGGER BUILDER", "MB.Tab", 16, 16, ui.accent, TEXT_ALIGN_LEFT)
		draw.SimpleText("actions fire at the zone centre", "MB.Tiny", 16, 40, ui.dim, TEXT_ALIGN_LEFT)
	end
	frame.OnRemove = function() MilBase.EventModal = false end

	local close = vgui.Create("DButton", frame)
	close:SetText("X")
	close:SetFont("MB.Small")
	close:SetSize(24, 24)
	close:SetPos(440 - 32, 12)
	close.Paint = function(self, w, h)
		draw.SimpleText("X", "MB.Small", w / 2, h / 2,
			self:IsHovered() and ui.accent or ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function() frame:Remove() end

	local y = 60

	-- Condition
	local condLbl = vgui.Create("DLabel", frame)
	condLbl:SetPos(16, y) condLbl:SetFont("MB.Tiny")
	condLbl:SetText("CONDITION") condLbl:SetTextColor(ui.dim) condLbl:SizeToContents()

	local cond = vgui.Create("DComboBox", frame)
	cond:SetPos(16, y + 16) cond:SetSize(408, 26)
	cond:SetFont("MB.Small")
	local defaultCond = IsValid(srcEnt) and "srcfixed" or "enter"
	for _, id in ipairs(MilBase.TriggerConditionOrder) do
		if (id == "srcfixed" or id == "srcdestroyed") and not IsValid(srcEnt) then continue end
		cond:AddChoice(MilBase.TriggerConditions[id], id, id == defaultCond)
	end
	cond.mbData = defaultCond
	cond.OnSelect = function(_, _, _, data) cond.mbData = data end

	y = y + 52

	-- Radius
	local rad = vgui.Create("DNumSlider", frame)
	rad:SetPos(4, y) rad:SetSize(432, 26)
	rad:SetText("Radius") rad:SetMin(128) rad:SetMax(4096)
	rad:SetDecimals(0) rad:SetValue(512)
	rad.Label:SetTextColor(ui.text)

	y = y + 30

	-- Timer delay
	local delay = vgui.Create("DNumSlider", frame)
	delay:SetPos(4, y) delay:SetSize(432, 26)
	delay:SetText("Timer (s)") delay:SetMin(0) delay:SetMax(300)
	delay:SetDecimals(0) delay:SetValue(15)
	delay.Label:SetTextColor(ui.text)

	y = y + 30

	local once = vgui.Create("DCheckBoxLabel", frame)
	once:SetPos(16, y) once:SetText("Fire once, then disable")
	once:SetValue(true) once:SetTextColor(ui.text)
	once:SizeToContents()

	y = y + 28

	-- Actions list
	local actLbl = vgui.Create("DLabel", frame)
	actLbl:SetPos(16, y) actLbl:SetFont("MB.Tiny")
	actLbl:SetText("ACTIONS") actLbl:SetTextColor(ui.dim) actLbl:SizeToContents()

	local list = vgui.Create("DListView", frame)
	list:SetPos(16, y + 16) list:SetSize(408, 150)
	list:SetMultiSelect(false)
	list:AddColumn("Type"):SetFixedWidth(120)
	list:AddColumn("Detail")

	local function refresh()
		list:Clear()
		for _, a in ipairs(actions) do
			list:AddLine(MilBase.TriggerActions[a.kind] or a.kind, actionDetail(a))
		end
	end

	-- double-click a row to remove it
	list.DoDoubleClick = function(_, rowIndex)
		table.remove(actions, rowIndex)
		refresh()
	end

	y = y + 174

	local addBtn = vgui.Create("DButton", frame)
	addBtn:SetPos(16, y) addBtn:SetSize(200, 28) addBtn:SetText("")
	addBtn.Paint = function(self, w, h)
		surface.SetDrawColor(self:IsHovered() and Color(ui.accent.r, ui.accent.g, ui.accent.b, 55) or Color(0, 0, 0, 120))
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(255, 198, 60, 50) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("+ ADD ACTION", "MB.Small", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	addBtn.DoClick = function()
		local m = DermaMenu()

		m:AddOption("Announce…", function()
			Derma_StringRequest("Announce", "Message:", "", function(text)
				actions[#actions + 1] = { kind = "announce", str = text, str2 = "", num = 0 }
				refresh()
			end)
		end)

		local spawn = m:AddSubMenu("Spawn Wave")
		local cats = {}
		for _, id in ipairs(MilBase.EventSpawnOrder) do
			local def = MilBase.EventSpawns[id]
			if def.kind == "effect" then continue end
			cats[def.category] = cats[def.category] or {}
			table.insert(cats[def.category], def)
		end
		for cat, defs in SortedPairs(cats) do
			local sub = spawn:AddSubMenu(cat)
			for _, def in ipairs(defs) do
				sub:AddOption(def.name, function()
					Derma_StringRequest("Spawn " .. def.name, "How many? (1-12)", "4", function(txt)
						local cnt = math.Clamp(tonumber(txt) or 1, 1, 12)
						actions[#actions + 1] = { kind = "spawn", str = def.id, str2 = def.name, num = cnt }
						refresh()
					end)
				end)
			end
		end

		local obj = m:AddSubMenu("Create Objective")
		for _, ot in ipairs(MilBase.ObjectiveOrder) do
			local t = MilBase.ObjectiveTypes[ot]
			obj:AddOption(t.name, function()
				Derma_StringRequest("Objective", "Label:", t.name, function(name)
					actions[#actions + 1] = { kind = "objective", str = ot, str2 = name, num = 0 }
					refresh()
				end)
			end)
		end

		m:AddOption("Complete Objective", function()
			actions[#actions + 1] = { kind = "complete", str = "", str2 = "", num = 0 }
			refresh()
		end)

		local doors = m:AddSubMenu("Toggle Doors In Area")
		for _, mode in ipairs({ "open", "close", "lock", "unlock" }) do
			doors:AddOption(string.upper(mode), function()
				actions[#actions + 1] = { kind = "doors", str = mode, str2 = "", num = 0 }
				refresh()
			end)
		end

		m:AddOption("Explosion", function()
			actions[#actions + 1] = { kind = "explosion", str = "", str2 = "", num = 0 }
			refresh()
		end)
		m:AddOption("Alarm", function()
			actions[#actions + 1] = { kind = "alarm", str = "", str2 = "", num = 0 }
			refresh()
		end)

		m:Open()
	end

	local hint = vgui.Create("DLabel", frame)
	hint:SetPos(224, y) hint:SetSize(200, 28) hint:SetFont("MB.Tiny")
	hint:SetText("double-click a row to remove") hint:SetTextColor(ui.dim)
	hint:SetContentAlignment(6)

	y = y + 40

	local create = vgui.Create("DButton", frame)
	create:SetPos(16, y) create:SetSize(408, 34) create:SetText("")
	create.Paint = function(self, w, h)
		surface.SetDrawColor(self:IsHovered() and Color(ui.accent.r, ui.accent.g, ui.accent.b, 90) or Color(ui.accent.r, ui.accent.g, ui.accent.b, 45))
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ui.accent) surface.DrawOutlinedRect(0, 0, w, h)
		draw.SimpleText("CREATE TRIGGER", "MB.Tab", w / 2, h / 2, ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	create.DoClick = function()
		if #actions == 0 then
			MilBase.Notify("Add at least one action first.")
			surface.PlaySound("buttons/button10.wav")
			return
		end
		local condID = cond.mbData or "enter"
		local hasSrc = (condID == "srcfixed" or condID == "srcdestroyed") and IsValid(srcEnt)

		net.Start("MilBase_TriggerCreate")
			net.WriteString(condID)
			net.WriteVector(worldPos)
			net.WriteFloat(rad:GetValue())
			net.WriteFloat(delay:GetValue())
			net.WriteBool(once:GetChecked())
			net.WriteString("") -- faction filter (all, for now)
			net.WriteBool(hasSrc)
			if hasSrc then net.WriteEntity(srcEnt) end
			net.WriteUInt(#actions, 5)
			for _, a in ipairs(actions) do
				net.WriteString(a.kind)
				net.WriteString(a.str or "")
				net.WriteString(a.str2 or "")
				net.WriteUInt(a.num or 0, 8)
			end
		net.SendToServer()

		surface.PlaySound("ui/buttonclickrelease.wav")
		frame:Remove()
	end
end
