--[[
	MilBase zero-gravity rescue tether.

	Controls:
	  Primary fire       Attach to a drifting player; hold to reel them in.
	  Secondary fire     Attach a stabilising world anchor; hold in zero-G to reel yourself in.
	  Reload             Release both cables.

	No certification or inventory item is registered here. Administrators can
	issue the SWEP with /givetether while the final role/cert integration is tested.
]]

if MilBase.RescueTetherLoaded then return end
MilBase.RescueTetherLoaded = true

local function cfg()
	return (MilBase.Config and MilBase.Config.RescueTether) or {}
end

local function weaponClass()
	return cfg().WeaponClass or "weapon_mb_rescue_tether"
end

local function notify(ply, text, kind)
	if SERVER and IsValid(ply) and MilBase.Notify then MilBase.Notify(ply, text, kind) end
end

local function displayName(ply)
	if not IsValid(ply) then return "unknown" end
	return ply.MBName and ply:MBName() or ply:Nick()
end

local function logAction(ply, text)
	if not SERVER or cfg().LogActions == false then return end
	local line = "[RESCUE TETHER] " .. displayName(ply) .. " " .. text
	print(line)
	if MilBase.Log then MilBase.Log("rescue_tether", line, ply) end
end

local function isStaticAnchorTrace(tr)
	if not tr or not tr.Hit then return false end
	if tr.HitWorld then return true end
	local ent = tr.Entity
	return IsValid(ent) and ent:GetMoveType() == MOVETYPE_NONE and not ent:IsPlayer() and not ent:IsNPC()
end

local function canTetherTarget(owner, target)
	local c = cfg()
	if not IsValid(owner) or not owner:IsPlayer() or not owner:Alive() then return false, "Invalid operator." end
	if not IsValid(target) or not target:IsPlayer() or not target:Alive() or target == owner then
		return false, "Aim at a drifting player."
	end
	if c.AllowVehicleTargets == false and target:InVehicle() then return false, "Vehicle occupants cannot be tethered." end
	if c.RequireTargetZeroG ~= false and not target:GetNWBool("mb_zerog", false) then
		return false, "The rescue tether only locks onto players drifting in zero gravity."
	end
	if c.AllowJuggernautTargets == false and MilBase.IsJuggernaut and MilBase.IsJuggernaut(target) then
		return false, "The Juggernaut suit is too heavy for this tether."
	end
	if target:GetNWBool("mb_staffmode", false) then return false, "That target cannot be tethered." end
	if c.AllowMultipleTethers == false then
		local existing = target:GetNWEntity("mb_tether_weapon")
		if IsValid(existing) then return false, "That player is already attached to a rescue tether." end
	end
	local allowed, reason = hook.Run("MilBaseCanRescueTether", owner, target)
	if allowed == false then return false, reason or "The tether cannot attach to that target." end
	return true
end

local SWEP = {}
SWEP.Base = "weapon_base"
SWEP.Category = "MilBase"
SWEP.Spawnable = false
SWEP.AdminOnly = false
SWEP.UseHands = true
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.Slot = 4
SWEP.SlotPos = 2
SWEP.Primary = { ClipSize = -1, DefaultClip = -1, Automatic = true, Ammo = "none" }
SWEP.Secondary = { ClipSize = -1, DefaultClip = -1, Automatic = false, Ammo = "none" }

function SWEP:SetupDataTables()
	self:NetworkVar("Entity", 0, "TetherTarget")
	self:NetworkVar("Bool", 0, "HasWorldAnchor")
	self:NetworkVar("Vector", 0, "WorldAnchor")
	self:NetworkVar("Float", 0, "ReelLength")
	self:NetworkVar("Float", 1, "AnchorLength")
	self:NetworkVar("Float", 2, "Tension")
end

function SWEP:Initialize()
	local c = cfg()
	self:SetHoldType(c.HoldType or "pistol")
	if SERVER then
		self:SetTetherTarget(NULL)
		self:SetHasWorldAnchor(false)
		self:SetWorldAnchor(vector_origin)
		self:SetReelLength(0)
		self:SetAnchorLength(0)
		self:SetTension(0)
	end
end

function SWEP:Deploy()
	self:SetHoldType(cfg().HoldType or "pistol")
	return true
end

function SWEP:GetCableStart()
	local owner = self:GetOwner()
	if not IsValid(owner) then return self:GetPos() end
	local attachment = owner:LookupAttachment("anim_attachment_RH")
	if attachment and attachment > 0 then
		local data = owner:GetAttachment(attachment)
		if data and data.Pos then return data.Pos end
	end
	return owner:GetShootPos() + owner:GetAimVector() * 8
end

function SWEP:ReleaseTarget(reason, silent)
	if not SERVER then return end
	local owner = self:GetOwner()
	local target = self:GetTetherTarget()
	if IsValid(target) then
		if target:GetNWEntity("mb_tether_weapon") == self then
			target:SetNWEntity("mb_tether_weapon", NULL)
			target:SetNWEntity("mb_tethered_by", NULL)
			target:SetNWBool("mb_tethered", false)
			target:SetNWFloat("mb_tether_escape", 0)
			target:SetNWFloat("mb_tether_safe_until", CurTime() + (cfg().SafeFallWindow or 1.4))
		end
		if not silent and reason then notify(target, reason, "warn") end
	end
	self:SetTetherTarget(NULL)
	self:SetReelLength(0)
	self:SetTension(0)
	self.mb_tetherBlockedAt = nil
	self.mb_tetherSecured = nil
	if IsValid(owner) and not silent and reason then notify(owner, reason, "warn") end
end

function SWEP:ReleaseAnchor(reason, silent)
	if not SERVER then return end
	local owner = self:GetOwner()
	if self:GetHasWorldAnchor() and IsValid(owner) and reason and not silent then notify(owner, reason, "warn") end
	self:SetHasWorldAnchor(false)
	self:SetWorldAnchor(vector_origin)
	self:SetAnchorLength(0)
	self:SetTension(0)
end

function SWEP:ReleaseAll(reason, silent)
	self:ReleaseTarget(reason, silent)
	self:ReleaseAnchor(nil, true)
end

function SWEP:AttachTarget(target)
	if not SERVER then return false end
	local owner = self:GetOwner()
	local allowed, reason = canTetherTarget(owner, target)
	if not allowed then notify(owner, reason, "warn") return false end
	local distance = owner:WorldSpaceCenter():Distance(target:WorldSpaceCenter())
	if distance > (cfg().MaximumCableLength or 2200) then
		notify(owner, "Target is beyond the cable's safe length.", "warn")
		return false
	end
	self:SetTetherTarget(target)
	self:SetReelLength(math.max(cfg().MinimumReelLength or 72, distance))
	self:SetTension(0)
	target:SetNWEntity("mb_tether_weapon", self)
	target:SetNWEntity("mb_tethered_by", owner)
	target:SetNWBool("mb_tethered", true)
	target:SetNWFloat("mb_tether_escape", 0)
	target:SetNWFloat("mb_tether_safe_until", CurTime() + (cfg().SafeFallWindow or 1.4))
	self.mb_tetherBlockedAt = nil
	self.mb_tetherSecured = false
	owner:EmitSound("weapons/physcannon/physcannon_claws_open.wav", 66, 118)
	target:EmitSound("buttons/button17.wav", 58, 112)
	notify(owner, "Rescue tether attached to " .. displayName(target) .. ". Hold primary fire to reel them in.", "ok")
	notify(target, "Rescue tether attached by " .. displayName(owner) .. ". Hold Reload to detach.", "ok")
	logAction(owner, "attached a line to " .. displayName(target))
	return true
end

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire(CurTime() + (cfg().FireCooldown or 0.35))
	if CLIENT then return end
	local owner = self:GetOwner()
	if not IsValid(owner) or not owner:Alive() or IsValid(self:GetTetherTarget()) then return end
	owner:LagCompensation(true)
	local startPos = owner:GetShootPos()
	local tr = util.TraceHull({
		start = startPos,
		endpos = startPos + owner:GetAimVector() * (cfg().AcquireRange or 1800),
		mins = Vector(-1, -1, -1) * (cfg().AcquireHull or 12),
		maxs = Vector(1, 1, 1) * (cfg().AcquireHull or 12),
		filter = { owner, self },
		mask = MASK_SHOT,
	})
	owner:LagCompensation(false)
	if not IsValid(tr.Entity) or not tr.Entity:IsPlayer() then
		notify(owner, "No drifting player acquired.", "warn")
		owner:EmitSound("buttons/button10.wav", 55, 90)
		return
	end
	if self:AttachTarget(tr.Entity) then
		self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
		owner:SetAnimation(PLAYER_ATTACK1)
	end
end

function SWEP:SecondaryAttack()
	self:SetNextSecondaryFire(CurTime() + (cfg().FireCooldown or 0.35))
	if CLIENT then return end
	local owner = self:GetOwner()
	if not IsValid(owner) or not owner:Alive() then return end
	if cfg().AllowWorldAnchor == false then notify(owner, "World anchoring is disabled.", "warn") return end
	if self:GetHasWorldAnchor() then
		if owner:GetNWBool("mb_zerog", false) and cfg().AllowSelfReel ~= false then
			notify(owner, "Hold secondary fire to reel yourself toward the anchor. Reload releases the line.", "ok")
		else
			notify(owner, "Self-reeling is locked outside zero gravity. Reload releases the anchor.", "warn")
		end
		return
	end
	owner:LagCompensation(true)
	local startPos = owner:GetShootPos()
	local tr = util.TraceLine({
		start = startPos,
		endpos = startPos + owner:GetAimVector() * (cfg().AnchorRange or 1500),
		filter = { owner, self, self:GetTetherTarget() },
		mask = MASK_SOLID,
	})
	owner:LagCompensation(false)
	if not isStaticAnchorTrace(tr) then
		notify(owner, "Aim at a fixed surface to establish an anchor.", "warn")
		owner:EmitSound("buttons/button10.wav", 55, 90)
		return
	end
	local distance = owner:WorldSpaceCenter():Distance(tr.HitPos)
	self:SetWorldAnchor(tr.HitPos + tr.HitNormal * 2)
	self:SetAnchorLength(math.min(cfg().AnchorBreakDistance or 2300, distance + (cfg().AnchorSlack or 260)))
	self:SetHasWorldAnchor(true)
	owner:EmitSound("weapons/crossbow/hit1.wav", 64, 130)
	notify(owner, owner:GetNWBool("mb_zerog", false) and "Rescue line anchored. Hold secondary fire to reel yourself in, or reel a casualty with primary fire." or "Rescue line anchored for casualty recovery. Self-reeling is locked outside zero gravity.", "ok")
	logAction(owner, "established a world anchor")
end

function SWEP:Reload()
	if CLIENT then return end
	if self.mb_tetherReloadAt and self.mb_tetherReloadAt > CurTime() then return end
	self.mb_tetherReloadAt = CurTime() + 0.45
	if IsValid(self:GetTetherTarget()) or self:GetHasWorldAnchor() then
		self:ReleaseAll("Rescue tether released.")
		local owner = self:GetOwner()
		if IsValid(owner) then owner:EmitSound("weapons/physcannon/physcannon_claws_close.wav", 62, 95) end
	end
end

local function addVelocityToward(ply, direction, desiredSpeed, maximumChange)
	if not IsValid(ply) or direction:LengthSqr() <= 0 then return 0 end
	direction = direction:GetNormalized()
	local radialSpeed = ply:GetVelocity():Dot(direction)
	local change = math.Clamp(desiredSpeed - radialSpeed, 0, maximumChange)
	if change > 0 then ply:SetVelocity(direction * change) end
	return change
end

function SWEP:Think()
	if CLIENT then return end
	local owner = self:GetOwner()
	if not IsValid(owner) or not owner:IsPlayer() or not owner:Alive() then self:ReleaseAll(nil, true) return end
	if cfg().ReleaseWhenHolstered ~= false and owner:GetActiveWeapon() ~= self then self:ReleaseAll(nil, true) return end
	local now = CurTime()
	if (self.mb_tetherNextThink or 0) > now then return end
	local dt = cfg().ThinkInterval or 0.05
	self.mb_tetherNextThink = now + dt

	local target = self:GetTetherTarget()
	local targetTension, anchorTension = 0, 0
	if IsValid(target) then
		if not target:IsPlayer() or not target:Alive() or target:InVehicle()
		or target:GetNWEntity("mb_tether_weapon") ~= self then
			self:ReleaseTarget("Rescue tether disconnected.")
			target = NULL
		else
			local ownerPos = owner:WorldSpaceCenter()
			local targetPos = target:WorldSpaceCenter()
			local separation = ownerPos:Distance(targetPos)
			if separation > (cfg().BreakDistance or 2600) then
				self:ReleaseTarget("Rescue tether snapped: maximum distance exceeded.")
				target = NULL
			else
				local obstruction = util.TraceLine({ start = ownerPos, endpos = targetPos, filter = { owner, target, self }, mask = MASK_SOLID })
				if obstruction.Hit then
					self.mb_tetherBlockedAt = self.mb_tetherBlockedAt or now
					if now - self.mb_tetherBlockedAt >= (cfg().BlockedBreakDelay or 1.5) then
						self:ReleaseTarget("Rescue tether severed by an obstruction.")
						target = NULL
					end
				else
					self.mb_tetherBlockedAt = nil
				end
			end
		end
	end

	if IsValid(target) then
		target:SetNWFloat("mb_tether_safe_until", now + (cfg().SafeFallWindow or 1.4))
		local ownerPos = owner:WorldSpaceCenter()
		local targetPos = target:WorldSpaceCenter()
		local delta = ownerPos - targetPos
		local separation = delta:Length()
		if owner:KeyDown(IN_ATTACK) then
			self:SetReelLength(math.max(cfg().MinimumReelLength or 72,
				self:GetReelLength() - (cfg().ReelSpeed or 285) * dt))
		end
		local cableLength = math.max(cfg().MinimumReelLength or 72, self:GetReelLength())
		local stretch = math.max(0, separation - cableLength)
		targetTension = math.Clamp(stretch / 220, 0, 1)
		if stretch > 0.5 and delta:LengthSqr() > 0 then
			local direction = delta:GetNormalized()
			local desired = math.min(cfg().MaximumPullSpeed or 610,
				60 + stretch * (cfg().StretchSpeedScale or 2.25))
			local maxChange = (cfg().PullAcceleration or 920) * dt
			addVelocityToward(target, direction, desired, maxChange)
			local operatorStable = self:GetHasWorldAnchor() or owner:OnGround()
				or owner:GetNWBool("mb_magboots_on", false) or not owner:GetNWBool("mb_zerog", false)
			if not operatorStable then
				addVelocityToward(owner, -direction, desired * (cfg().UnanchoredOperatorReaction or 0.62),
					maxChange * (cfg().UnanchoredOperatorReaction or 0.62))
			end
		end

		if separation <= (cfg().SecureDistance or 92) and owner:KeyDown(IN_ATTACK) then
			local damp = math.Clamp(cfg().CloseRangeDamping or 0.32, 0, 0.9)
			target:SetVelocity(-target:GetVelocity() * damp)
			target:SetNWFloat("mb_tether_safe_until", now + (cfg().SafeFallWindow or 1.4))
			if not self.mb_tetherSecured then
				self.mb_tetherSecured = true
				notify(owner, displayName(target) .. " is within recovery distance.", "ok")
				notify(target, "You have been pulled within recovery distance.", "ok")
			end
		else
			self.mb_tetherSecured = false
		end

		-- A tethered player can always opt out by holding Reload briefly.
		if target:KeyDown(IN_RELOAD) then
			target.mb_tetherEscapeStarted = target.mb_tetherEscapeStarted or now
			local fraction = math.Clamp((now - target.mb_tetherEscapeStarted) / math.max(0.25, cfg().TargetEscapeHoldTime or 1.1), 0, 1)
			target:SetNWFloat("mb_tether_escape", fraction)
			if fraction >= 1 then
				local targetName = displayName(target)
				self:ReleaseTarget(targetName .. " released the rescue tether.", true)
				notify(target, "You released the rescue tether.", "warn")
				notify(owner, targetName .. " released the rescue tether.", "warn")
				logAction(target, "released a tether from " .. displayName(owner))
				target.mb_tetherEscapeStarted = nil
			end
		else
			target.mb_tetherEscapeStarted = nil
			target:SetNWFloat("mb_tether_escape", 0)
		end
	end

	if self:GetHasWorldAnchor() then
		local anchor = self:GetWorldAnchor()
		local delta = anchor - owner:WorldSpaceCenter()
		local distance = delta:Length()
		if distance > (cfg().AnchorBreakDistance or 2300) then
			self:ReleaseAnchor("World anchor snapped: maximum distance exceeded.")
		else
			local operatorInZeroG = owner:GetNWBool("mb_zerog", false)
			local mayPullOperator = cfg().RequireOperatorZeroGForAnchorPull == false or operatorInZeroG

			-- Holding secondary shortens the line, but only inside an actual zero-G
			-- volume. This is the hard anti-grapple gate; normal gravity can never
			-- receive anchor velocity from this weapon.
			if operatorInZeroG and cfg().AllowSelfReel ~= false and owner:KeyDown(IN_ATTACK2) then
				self:SetAnchorLength(math.max(cfg().MinimumSelfReelLength or 64,
					self:GetAnchorLength() - (cfg().SelfReelSpeed or 360) * dt))
			elseif not mayPullOperator then
				-- If the user leaves zero-G, add enough slack to ensure the stored
				-- line cannot jerk them when they later enter another zero-G volume.
				self:SetAnchorLength(math.max(self:GetAnchorLength(), distance))
			end

			if distance > self:GetAnchorLength() then
				local stretch = distance - self:GetAnchorLength()
				anchorTension = math.Clamp(stretch / 180, 0, 1)
				if mayPullOperator and delta:LengthSqr() > 0 then
					local desired = math.min(cfg().AnchorMaximumPullSpeed or 520,
						45 + stretch * (cfg().StretchSpeedScale or 2.25))
					addVelocityToward(owner, delta:GetNormalized(), desired, (cfg().AnchorPullAcceleration or 1100) * dt)
				end
			end
		end
	end

	self:SetTension(math.max(targetTension, anchorTension))
end

function SWEP:Holster()
	if SERVER and cfg().ReleaseWhenHolstered ~= false then self:ReleaseAll(nil, true) end
	return true
end

function SWEP:OnDrop()
	if SERVER then self:ReleaseAll(nil, true) end
end

function SWEP:OnRemove()
	if SERVER then self:ReleaseAll(nil, true) end
end

local c = cfg()
SWEP.PrintName = c.WeaponName or "Zero-G Rescue Tether"
SWEP.ViewModel = c.ViewModel or "models/kraken/cgi/v_cgi_dc17revolver.mdl"
SWEP.WorldModel = c.WorldModel or "models/kraken/cgi/world/w_cgi_dc17revolver.mdl"
weapons.Register(SWEP, weaponClass())

if SERVER then
	local function giveTether(target)
		if not IsValid(target) or not target:IsPlayer() then return false end
		local class = weaponClass()
		if not target:HasWeapon(class) then target:Give(class) end
		target:SelectWeapon(class)
		notify(target, "Zero-G Rescue Tether issued. Primary rescues casualties; Secondary anchors and self-reels only in zero-G; Reload releases.", "ok")
		return true
	end

	MilBase.RegisterChatCommand("givetether", {
		help = "(Admin test) Give the zero-G rescue tether: /givetether [player]",
		adminOnly = true,
		func = function(ply, _, rawText)
			local target = string.Trim(rawText or "") ~= "" and MilBase.FindPlayer(string.Trim(rawText)) or ply
			if not IsValid(target) then notify(ply, "Player not found.", "warn") return end
			giveTether(target)
			if target ~= ply then notify(ply, "Rescue tether issued to " .. displayName(target) .. ".", "ok") end
		end,
	})

	concommand.Add("mb_givetether", function(ply, _, args)
		if IsValid(ply) and not ply:IsAdmin() then return end
		local target = IsValid(ply) and (args[1] and MilBase.FindPlayer(table.concat(args, " ")) or ply) or nil
		if IsValid(target) then giveTether(target) end
	end)

	hook.Add("GetFallDamage", "MilBase.RescueTetherSafeRecovery", function(ply)
		if ply:GetNWFloat("mb_tether_safe_until", 0) > CurTime() then return 0 end
	end)

	hook.Add("EntityTakeDamage", "MilBase.RescueTetherFallDamageGuard", function(ent, dmg)
		if IsValid(ent) and ent:IsPlayer() and dmg:IsDamageType(DMG_FALL)
		and ent:GetNWFloat("mb_tether_safe_until", 0) > CurTime() then
			dmg:SetDamage(0)
			dmg:SetDamageForce(vector_origin)
			return true
		end
	end)

	local function cleanPlayerTethers(ply)
		for _, operator in ipairs(player.GetAll()) do
			local wep = operator:GetWeapon(weaponClass())
			if IsValid(wep) and (operator == ply or wep:GetTetherTarget() == ply) then
				wep:ReleaseAll(nil, true)
			end
		end
		ply:SetNWEntity("mb_tether_weapon", NULL)
		ply:SetNWEntity("mb_tethered_by", NULL)
		ply:SetNWBool("mb_tethered", false)
		ply:SetNWFloat("mb_tether_escape", 0)
	end

	hook.Add("PlayerDeath", "MilBase.RescueTetherDeathCleanup", cleanPlayerTethers)
	hook.Add("PlayerDisconnected", "MilBase.RescueTetherDisconnectCleanup", cleanPlayerTethers)
	hook.Add("PlayerSpawn", "MilBase.RescueTetherSpawnCleanup", function(ply)
		ply:SetNWEntity("mb_tether_weapon", NULL)
		ply:SetNWEntity("mb_tethered_by", NULL)
		ply:SetNWBool("mb_tethered", false)
		ply:SetNWFloat("mb_tether_escape", 0)
	end)
else
	local cableMaterial = Material("cable/cable2")
	local glowMaterial = Material("sprites/light_glow02_add")

	local function cableStart(owner, wep)
		if IsValid(wep) and wep.GetCableStart then return wep:GetCableStart() end
		return IsValid(owner) and owner:WorldSpaceCenter() or vector_origin
	end

	hook.Add("PostDrawTranslucentRenderables", "MilBase.RescueTetherCables", function()
		for _, owner in ipairs(player.GetAll()) do
			local wep = owner:GetWeapon(weaponClass())
			if IsValid(wep) then
				local target = wep:GetTetherTarget()
				local anchored = wep:GetHasWorldAnchor()
				if IsValid(target) or anchored then
					local startPos = cableStart(owner, wep)
					local tension = math.Clamp(wep:GetTension(), 0, 1)
					local cableColor = Color(120 + 120 * tension, 205 - 85 * tension, 255 - 155 * tension, 235)
					render.SetMaterial(cableMaterial)
					if IsValid(target) then
						local targetPos = target:WorldSpaceCenter()
						render.DrawBeam(startPos, targetPos, 2.6 + tension * 1.8, 0, startPos:Distance(targetPos) / 64, cableColor)
						render.SetMaterial(glowMaterial)
						render.DrawSprite(targetPos, 10, 10, cableColor)
					end
					if anchored then
						local anchor = wep:GetWorldAnchor()
						render.SetMaterial(cableMaterial)
						render.DrawBeam(startPos, anchor, 2.4 + tension, 0, startPos:Distance(anchor) / 64, Color(255, 198, 60, 225))
						render.SetMaterial(glowMaterial)
						render.DrawSprite(anchor, 11, 11, Color(255, 198, 60, 235))
					end
				end
			end
		end
	end)

	hook.Add("PreDrawHalos", "MilBase.RescueTetherTargetHalo", function()
		if cfg().HighlightAttachedTarget == false then return end
		local ply = LocalPlayer()
		local wep = IsValid(ply) and ply:GetActiveWeapon() or NULL
		if not IsValid(wep) or wep:GetClass() ~= weaponClass() then return end
		local target = wep:GetTetherTarget()
		if IsValid(target) then halo.Add({ target }, Color(95, 185, 255), 2, 2, 1, true, true) end
	end)

	local function drawStatusPanel(ply, wep)
		local ui = MilBase.UI
		if not ui or not MilBase.DrawPanelBF2 then return end
		local scale = math.Clamp(ScrH() / 1080, 0.75, 1.15)
		local w, h = 390 * scale, 142 * scale
		local x, y = ScrW() - w - 28 * scale, 92 * scale
		MilBase.DrawPanelBF2(x, y, w, h, { color = ui.panel, accent = ui.accent, outlineColor = ui.outline, cut = 10 * scale })
		draw.SimpleText("ZERO-G RESCUE TETHER", "MB.Tab", x + 18 * scale, y + 12 * scale, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		local target = wep:GetTetherTarget()
		local state = IsValid(target) and "TARGET LOCKED" or "STANDBY"
		if wep:GetHasWorldAnchor() then
			if ply:GetNWBool("mb_zerog", false) and ply:KeyDown(IN_ATTACK2) then
				state = IsValid(target) and "ANCHORED + SELF-REEL" or "SELF-REEL ACTIVE"
			else
				state = IsValid(target) and "ANCHORED RECOVERY" or "WORLD ANCHORED"
			end
		end
		draw.SimpleText(state, "MB.Small", x + w - 18 * scale, y + 18 * scale, IsValid(target) and ui.ok or ui.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		local targetName = IsValid(target) and displayName(target) or "NO TARGET"
		local distance = IsValid(target) and math.Round(ply:WorldSpaceCenter():Distance(target:WorldSpaceCenter())) or 0
		draw.SimpleText("CASUALTY", "MB.Tiny", x + 18 * scale, y + 53 * scale, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(targetName, "MB.Med", x + 18 * scale, y + 70 * scale, ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(IsValid(target) and (distance .. "u") or "—", "MB.NumSmall", x + w - 18 * scale, y + 60 * scale, ui.accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
		MilBase.DrawBar(x + 18 * scale, y + 98 * scale, w - 36 * scale, 6 * scale, math.Clamp(wep:GetTension(), 0, 1), wep:GetTension() > 0.75 and ui.danger or ui.accent)
		local controls = ply:GetNWBool("mb_zerog", false)
			and "LMB RESCUE / REEL   •   HOLD RMB SELF-REEL   •   R RELEASE"
			or "LMB RESCUE / REEL   •   RMB ANCHOR   •   SELF-REEL LOCKED"
		draw.SimpleText(controls, "MB.Tiny", x + 18 * scale, y + h - 18 * scale, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	hook.Add("HUDPaint", "MilBase.RescueTetherHUD", function()
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() or MilBase.InEventView() then return end
		local wep = ply:GetActiveWeapon()
		if IsValid(wep) and wep:GetClass() == weaponClass() then
			drawStatusPanel(ply, wep)
			local tr = ply:GetEyeTrace()
			local valid = IsValid(tr.Entity) and tr.Entity:IsPlayer() and tr.Entity:GetNWBool("mb_zerog", false)
			local color = valid and (MilBase.UI and MilBase.UI.ok or Color(150, 205, 125)) or (MilBase.UI and MilBase.UI.accent or Color(255, 198, 60))
			local cx, cy = ScrW() * 0.5, ScrH() * 0.5
			surface.SetDrawColor(color)
			surface.DrawOutlinedRect(cx - 8, cy - 8, 16, 16, 1)
			surface.DrawLine(cx - 15, cy, cx - 5, cy)
			surface.DrawLine(cx + 5, cy, cx + 15, cy)
		end

		if ply:GetNWBool("mb_tethered", false) then
			local ui = MilBase.UI or {}
			local operator = ply:GetNWEntity("mb_tethered_by")
			local text = "RESCUE TETHER ATTACHED"
			if IsValid(operator) then text = text .. " — " .. displayName(operator) end
			draw.SimpleText(text, "MB.Big", ScrW() * 0.5, ScrH() * 0.28, ui.accent or Color(255, 198, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("HOLD RELOAD TO DETACH", "MB.Small", ScrW() * 0.5, ScrH() * 0.315, ui.text or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			local escape = ply:GetNWFloat("mb_tether_escape", 0)
			if escape > 0 and MilBase.DrawBar then
				MilBase.DrawBar(ScrW() * 0.5 - 120, ScrH() * 0.335, 240, 6, escape, ui.warn or Color(255, 198, 60))
			end
		end
	end)
end
