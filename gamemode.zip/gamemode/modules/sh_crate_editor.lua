-- Persistent crate creator/editor for the staff menu.

local cfg = MilBase.Config
local EDIT_LEVEL = tonumber(cfg.CrateEditorLevel) or 4
local NET_REQUEST = "MilBase_CrateEditorRequest"
local NET_SYNC = "MilBase_CrateEditorSync"
local NET_ACTION = "MilBase_CrateEditorAction"
local MAX_RAW = 512 * 1024

local function trim(value) return string.Trim(tostring(value or "")) end

local function stringList(source)
	local out, seen = {}, {}
	for _, value in ipairs(istable(source) and source or {}) do
		value = string.lower(trim(value))
		if value ~= "" and not seen[value] then out[#out + 1], seen[value] = value, true end
	end
	return out
end

local function editableLoot(source)
	local out = {}
	for _, raw in ipairs(istable(source) and source or {}) do
		if istable(raw) then
			local entry = table.Copy(raw)
			entry.type = string.lower(trim(entry.type))
			entry.id = trim(entry.id)
			entry.weight = tonumber(entry.weight) or 1
			if entry.pool then entry.pool = stringList(entry.pool) end
			out[#out + 1] = entry
		end
	end
	return out
end

function MilBase.CrateToEditable(crate)
	if not istable(crate) then return nil end
	return {
		id = trim(crate.id), name = trim(crate.name), tier = tonumber(crate.tier) or 1,
		cost = tonumber(crate.cost) or 0, item = trim(crate.item),
		rewards = tonumber(crate.rewards) or 1, loot = editableLoot(crate.loot),
	}
end

MilBase.CrateFileDefaults = MilBase.CrateFileDefaults or {}
if not MilBase._CrateFileDefaultsCaptured then
	for _, id in ipairs(MilBase.CrateOrder or {}) do
		local crate = MilBase.GetCrate(id)
		if crate then local copy = table.Copy(crate); copy.id = nil; MilBase.CrateFileDefaults[id] = copy end
	end
	MilBase._CrateFileDefaultsCaptured = true
end

local function cleanText(value, label, minLength, maxLength)
	value = trim(value)
	value = string.gsub(value, "[%z\1-\8\11\12\14-\31]", "")
	if #value < (minLength or 0) then return nil, label .. " is required." end
	if #value > maxLength then return nil, label .. " is too long." end
	return value
end

local function validateLoot(source)
	if not istable(source) then return nil, "Loot must be a list." end
	if #source < 1 then return nil, "A crate needs at least one loot entry." end
	if #source > 128 then return nil, "A crate can have at most 128 loot entries." end
	local out = {}
	for index, raw in ipairs(source) do
		if not istable(raw) then return nil, "Loot entry " .. index .. " is malformed." end
		local entry = { type = string.lower(trim(raw.type)) }
		entry.weight = math.Clamp(tonumber(raw.weight) or 1, 0.001, 1000000)
		if entry.type == "card" then
			entry.pool = stringList(raw.pool)
			if #entry.pool < 1 then entry.pool = nil end
			entry.fallback = math.Clamp(math.floor(tonumber(raw.fallback) or 100), 0, 10000000)
		elseif entry.type == "item" or entry.type == "attachment" then
			entry.id = cleanText(raw.id, "Loot entry " .. index .. " id", 1, 128)
			if not entry.id then return nil, "Loot entry " .. index .. " needs an id." end
			entry.amount = math.Clamp(math.floor(tonumber(raw.amount) or 1), 1, 1000)
		elseif entry.type == "weapon" then
			entry.id = cleanText(raw.id, "Loot entry " .. index .. " weapon", 1, 128)
			if not entry.id then return nil, "Loot entry " .. index .. " needs a weapon class." end
			entry.fallback = math.Clamp(math.floor(tonumber(raw.fallback) or 250), 0, 10000000)
		elseif entry.type == "credits" then
			entry.min = math.Clamp(math.floor(tonumber(raw.min) or 0), 0, 10000000)
			entry.max = math.Clamp(math.floor(tonumber(raw.max) or entry.min), entry.min, 10000000)
		elseif entry.type == "booster" then
			entry.mult = math.Clamp(tonumber(raw.mult) or 1.5, 1, 10)
			entry.duration = math.Clamp(math.floor(tonumber(raw.duration) or 3600), 60, 604800)
		else
			return nil, "Unknown loot type in entry " .. index .. ": " .. entry.type
		end
		out[#out + 1] = entry
	end
	return out
end

local function validateCrate(source)
	if not istable(source) then return nil, "Malformed crate data." end
	local out, err = {}
	out.id, err = cleanText(source.id, "Crate id", 1, 48)
	if not out.id then return nil, err end
	out.id = string.lower(out.id)
	if not string.match(out.id, "^[%w_%-]+$") then return nil, "Crate id may contain only letters, numbers, underscores and hyphens." end
	out.name, err = cleanText(source.name, "Name", 1, 80)
	if not out.name then return nil, err end
	out.tier = math.Clamp(math.floor(tonumber(source.tier) or 1), 1, 4)
	out.cost = math.Clamp(math.floor(tonumber(source.cost) or 0), 0, 10000000)
	out.rewards = math.Clamp(math.floor(tonumber(source.rewards) or 1), 1, 16)
	out.item, err = cleanText(source.item or "", "Required item", 0, 96)
	if not out.item then return nil, err end
	if out.item == "" then out.item = nil end
	out.loot, err = validateLoot(source.loot)
	if not out.loot then return nil, err end
	return out
end

if SERVER then
	util.AddNetworkString(NET_REQUEST)
	util.AddNetworkString(NET_SYNC)
	util.AddNetworkString(NET_ACTION)
	local CRATE_TABLE_SQL = [[CREATE TABLE IF NOT EXISTS frontier_crate_definitions (
		id VARCHAR(64) PRIMARY KEY, data TEXT, source VARCHAR(16),
		updated_by VARCHAR(32), updated_at INTEGER
	)]]
	MilBase.CrateEditorOverrides = MilBase.CrateEditorOverrides or {}

	local function canEdit(ply)
		return IsValid(ply) and (ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL)
	end

	local function payload()
		local definitions, meta = {}, {}
		for _, id in ipairs(MilBase.CrateOrder or {}) do
			local crate = MilBase.GetCrate(id)
			if crate then
				definitions[#definitions + 1] = MilBase.CrateToEditable(crate)
				meta[id] = { file = MilBase.CrateFileDefaults[id] ~= nil,
					overridden = MilBase.CrateEditorOverrides[id] == true }
			end
		end
		return { definitions = definitions, meta = meta }
	end

	local function sendSync(target)
		local compressed = util.Compress(util.TableToJSON(payload()) or "{}")
		if not compressed then return end
		net.Start(NET_SYNC)
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		if IsValid(target) then net.Send(target) else net.Broadcast() end
	end
	MilBase.SyncCrateDefinitions = sendSync

	local function saveCrate(actor, source)
		local clean, err = validateCrate(source)
		if not clean then return false, err end
		local existed = MilBase.GetCrate(clean.id) ~= nil
		if not existed and #MilBase.CrateOrder >= 256 then return false, "Crate limit reached." end
		MilBase.RegisterCrate(clean.id, clean)
		MilBase.CrateEditorOverrides[clean.id] = true
		MilBase.DB.Run(string.format(
			"REPLACE INTO frontier_crate_definitions (id, data, source, updated_by, updated_at) VALUES (%s, %s, %s, %s, %d)",
			MilBase.SQLStr(clean.id), MilBase.SQLStr(util.TableToJSON(clean)),
			MilBase.SQLStr(MilBase.CrateFileDefaults[clean.id] and "override" or "custom"),
			MilBase.SQLStr(actor:SteamID64()), os.time()))
		sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. (existed and " updated crate " or " created crate ") .. clean.id, actor) end
		return true, existed and "Crate updated." or "Crate created."
	end

	local function resetCrate(actor, id)
		local default = MilBase.CrateFileDefaults[id]
		if not default then return false, "That crate has no file default." end
		MilBase.RegisterCrate(id, table.Copy(default))
		MilBase.CrateEditorOverrides[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_crate_definitions WHERE id = " .. MilBase.SQLStr(id))
		sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " reset crate " .. id, actor) end
		return true, "Crate reset to its file definition."
	end

	local function deleteCrate(actor, id)
		if MilBase.CrateFileDefaults[id] then return false, "File crates must be reset, not deleted." end
		if not MilBase.RemoveCrate(id) then return false, "Unknown crate." end
		MilBase.CrateEditorOverrides[id] = nil
		MilBase.DB.Run("DELETE FROM frontier_crate_definitions WHERE id = " .. MilBase.SQLStr(id))
		sendSync()
		if MilBase.Log then MilBase.Log("staff", MilBase.LogTag(actor) .. " deleted crate " .. id, actor) end
		return true, "Custom crate deleted."
	end

	net.Receive(NET_REQUEST, function(_, ply)
		if (ply.mb_nextCrateDefinitionRequest or 0) > CurTime() then return end
		ply.mb_nextCrateDefinitionRequest = CurTime() + 1
		sendSync(ply)
	end)
	net.Receive(NET_ACTION, function(_, ply)
		if not canEdit(ply) or (ply.mb_nextCrateEditorAction or 0) > CurTime() then return end
		ply.mb_nextCrateEditorAction = CurTime() + 0.2
		local action = net.ReadString()
		if action == "save" then
			local length = net.ReadUInt(20)
			if length <= 0 or length > MAX_RAW then return end
			local raw = util.Decompress(net.ReadData(length) or "")
			if not raw or #raw > MAX_RAW then return end
			local ok, message = saveCrate(ply, util.JSONToTable(raw))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "reset" then
			local ok, message = resetCrate(ply, string.lower(trim(net.ReadString())))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		elseif action == "delete" then
			local ok, message = deleteCrate(ply, string.lower(trim(net.ReadString())))
			MilBase.Notify(ply, message, ok and "ok" or "warn")
		end
	end)

	local function loadOverrides()
		MilBase.DB.Query("SELECT id, data FROM frontier_crate_definitions", function(rows)
			rows = rows or {}
			table.sort(rows, function(a, b) return tostring(a.id or "") < tostring(b.id or "") end)
			for _, row in ipairs(rows) do
				local clean = validateCrate(util.JSONToTable(row.data or ""))
				if clean and clean.id == tostring(row.id or "") then
					MilBase.RegisterCrate(clean.id, clean)
					MilBase.CrateEditorOverrides[clean.id] = true
				end
			end
			sendSync()
		end)
	end
	MilBase.DB.Query(CRATE_TABLE_SQL, loadOverrides, function(err)
		MsgC(Color(255, 100, 90), "[MilBase Crates] Could not create crate editor table: ",
			color_white, tostring(err), "\n")
	end)
	hook.Add("PlayerInitialSpawn", "MilBase.CrateEditorSync", function(ply)
		timer.Simple(2, function() if IsValid(ply) then sendSync(ply) end end)
	end)
	return
end

-- Client -----------------------------------------------------------------

MilBase.CrateEditorMeta = MilBase.CrateEditorMeta or {}
net.Receive(NET_SYNC, function()
	local length = net.ReadUInt(20)
	local raw = util.Decompress(net.ReadData(length) or "")
	local data = raw and util.JSONToTable(raw) or {}
	MilBase.Crates, MilBase.CrateOrder = {}, {}
	for _, crate in ipairs(data.definitions or {}) do MilBase.RegisterCrate(crate.id, crate) end
	MilBase.CrateEditorMeta = istable(data.meta) and data.meta or {}
	hook.Run("MilBase.CrateEditorUpdated")
end)

local function sendAction(action, value)
	net.Start(NET_ACTION)
		net.WriteString(action)
		if action == "save" then
			local compressed = util.Compress(util.TableToJSON(value) or "{}") or ""
			net.WriteUInt(#compressed, 20)
			net.WriteData(compressed, #compressed)
		else net.WriteString(tostring(value or "")) end
	net.SendToServer()
end

local function lootToText(loot)
	local rows = {}
	for _, entry in ipairs(loot or {}) do
		if entry.type == "card" then
			rows[#rows + 1] = table.concat({ "card", table.concat(entry.pool or {}, ","), entry.fallback or 100, entry.weight or 1 }, " | ")
		elseif entry.type == "item" or entry.type == "attachment" then
			rows[#rows + 1] = table.concat({ entry.type, entry.id or "", entry.amount or 1, entry.weight or 1 }, " | ")
		elseif entry.type == "weapon" then
			rows[#rows + 1] = table.concat({ "weapon", entry.id or "", entry.fallback or 250, entry.weight or 1 }, " | ")
		elseif entry.type == "credits" then
			rows[#rows + 1] = table.concat({ "credits", entry.min or 0, entry.max or 0, entry.weight or 1 }, " | ")
		elseif entry.type == "booster" then
			rows[#rows + 1] = table.concat({ "booster", entry.mult or 1.5, entry.duration or 3600, entry.weight or 1 }, " | ")
		end
	end
	return table.concat(rows, "\n")
end

local function parseLoot(text)
	local out = {}
	for line in string.gmatch(tostring(text or "") .. "\n", "([^\n]*)\n") do
		line = trim(line)
		if line ~= "" then
			local parts = string.Explode("|", line)
			for index, value in ipairs(parts) do parts[index] = trim(value) end
			local kind = string.lower(parts[1] or "")
			if kind == "card" then
				out[#out + 1] = { type = kind, pool = string.Explode(",", parts[2] or ""), fallback = tonumber(parts[3]), weight = tonumber(parts[4]) }
			elseif kind == "item" or kind == "attachment" then
				out[#out + 1] = { type = kind, id = parts[2], amount = tonumber(parts[3]), weight = tonumber(parts[4]) }
			elseif kind == "weapon" then
				out[#out + 1] = { type = kind, id = parts[2], fallback = tonumber(parts[3]), weight = tonumber(parts[4]) }
			elseif kind == "credits" then
				out[#out + 1] = { type = kind, min = tonumber(parts[2]), max = tonumber(parts[3]), weight = tonumber(parts[4]) }
			elseif kind == "booster" then
				out[#out + 1] = { type = kind, mult = tonumber(parts[2]), duration = tonumber(parts[3]), weight = tonumber(parts[4]) }
			else
				out[#out + 1] = { type = kind, weight = tonumber(parts[4]) }
			end
		end
	end
	return out
end

MilBase.StaffMenuTabs = MilBase.StaffMenuTabs or {}
MilBase.StaffMenuTabs["CRATE EDITOR"] = true
MilBase.AddMenuTab("CRATE EDITOR", 94, function(content)
	local selectedID, fields
	local left = vgui.Create("DPanel", content); left:Dock(LEFT); left:SetWide(270); left:DockMargin(0, 0, 12, 0)
	left.Paint = function(_, w, h) MilBase.PaintPanel(w, h) end
	local newButton = vgui.Create("DButton", left); newButton:Dock(TOP); newButton:SetTall(38); newButton:SetText("NEW CRATE")
	local list = vgui.Create("DScrollPanel", left); list:Dock(FILL); list:DockMargin(8, 8, 8, 8)
	local form = vgui.Create("DScrollPanel", content); form:Dock(FILL)

	local function label(text)
		local value = vgui.Create("DLabel", form); value:Dock(TOP); value:SetTall(20); value:SetFont("MB.Tiny")
		value:SetText(text); value:SetTextColor(MilBase.UI.dim); value:DockMargin(0, 5, 0, 2)
	end
	local function entry(key, title, tall, multiline)
		label(title); local value = vgui.Create("DTextEntry", form); value:Dock(TOP); value:SetTall(tall or 30)
		value:SetMultiline(multiline == true); fields[key] = value; return value
	end
	fields = {}
	entry("id", "ID (immutable after creation)")
	entry("name", "DISPLAY NAME")
	entry("tier", "TIER (1-4)")
	entry("cost", "CREDIT COST")
	entry("item", "OPTIONAL REQUIRED INVENTORY ITEM")
	entry("rewards", "REWARD PULLS PER OPEN")
	label("LOOT: type | value A | value B | weight")
	local help = vgui.Create("DLabel", form); help:Dock(TOP); help:SetTall(76); help:SetFont("MB.Tiny"); help:SetTextColor(MilBase.UI.dim)
	help:SetText("attachment | optic_id | amount | weight\nweapon | weapon_class | duplicate-credit fallback | weight\nitem | item_id | amount | weight\ncard | card_a,card_b (blank = any) | fallback credits | weight\ncredits | minimum | maximum | weight     booster | multiplier | seconds | weight")
	entry("loot", "", 240, true)
	local actions = vgui.Create("DPanel", form); actions:Dock(TOP); actions:SetTall(46); actions.Paint = nil; actions:DockMargin(0, 10, 0, 0)
	local save = vgui.Create("DButton", actions); save:SetText("SAVE"); save:SetSize(120, 36); save:SetPos(0, 5)
	local reset = vgui.Create("DButton", actions); reset:SetText("RESET TO FILE"); reset:SetSize(140, 36); reset:SetPos(128, 5)
	local delete = vgui.Create("DButton", actions); delete:SetText("DELETE CUSTOM"); delete:SetSize(140, 36); delete:SetPos(276, 5)

	local function load(crate)
		crate = crate or { id = "", name = "", tier = 1, cost = 0, item = "", rewards = 1, loot = {} }
		fields.id:SetText(crate.id or ""); fields.id:SetEditable(selectedID == nil)
		fields.name:SetText(crate.name or ""); fields.tier:SetText(tostring(crate.tier or 1)); fields.cost:SetText(tostring(crate.cost or 0))
		fields.item:SetText(crate.item or ""); fields.rewards:SetText(tostring(crate.rewards or 1)); fields.loot:SetText(lootToText(crate.loot))
		local meta = selectedID and MilBase.CrateEditorMeta[selectedID] or {}
		reset:SetEnabled(meta.file == true and meta.overridden == true); delete:SetEnabled(selectedID ~= nil and meta.file ~= true)
	end
	local function selectCrate(id) selectedID = id; load(MilBase.CrateToEditable(MilBase.GetCrate(id))) end
	local function rebuild()
		list:Clear()
		for _, id in ipairs(MilBase.CrateOrder or {}) do
			local crate = MilBase.GetCrate(id); local button = list:Add("DButton"); button:Dock(TOP); button:SetTall(38); button:DockMargin(0,0,0,4)
			button:SetText((crate and crate.name or id) .. "  [" .. id .. "]"); button.DoClick = function() selectCrate(id) end
		end
		if selectedID and MilBase.GetCrate(selectedID) then selectCrate(selectedID) else load(nil) end
	end
	newButton.DoClick = function() selectedID = nil; load(nil) end
	save.DoClick = function()
		sendAction("save", { id = selectedID or fields.id:GetValue(), name = fields.name:GetValue(), tier = tonumber(fields.tier:GetValue()),
			cost = tonumber(fields.cost:GetValue()), item = fields.item:GetValue(), rewards = tonumber(fields.rewards:GetValue()), loot = parseLoot(fields.loot:GetValue()) })
	end
	reset.DoClick = function() if selectedID then Derma_Query("Restore this crate's Lua definition?", "Reset Crate", "RESET", function() sendAction("reset", selectedID) end, "CANCEL") end end
	delete.DoClick = function() if selectedID then Derma_Query("Permanently delete this custom crate?", "Delete Crate", "DELETE", function() sendAction("delete", selectedID); selectedID = nil end, "CANCEL") end end
	local hookID = "MilBase.CrateEditorPanel." .. tostring(content)
	hook.Add("MilBase.CrateEditorUpdated", hookID, rebuild); content.OnRemove = function() hook.Remove("MilBase.CrateEditorUpdated", hookID) end
	net.Start(NET_REQUEST); net.SendToServer(); rebuild()
end, function(ply) return ply:IsAdmin() or ply:MBStaffLevel() >= EDIT_LEVEL end)

hook.Add("InitPostEntity", "MilBase.RequestCrateDefinitions", function()
	timer.Simple(1, function() net.Start(NET_REQUEST); net.SendToServer() end)
end)
hook.Add("OnReloaded", "MilBase.RequestCrateDefinitionsReload", function()
	timer.Simple(0.5, function() net.Start(NET_REQUEST); net.SendToServer() end)
end)
