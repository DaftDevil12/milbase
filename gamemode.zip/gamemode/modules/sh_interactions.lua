--[[
	Contextual player interactions.

	One menu, two entry points:
	  - Hold C and right-click a soldier -> "Interact"
	  - Click a row on the TAB scoreboard

	Actions self-filter by who YOU are: officers see regiment management
	(recruit, discharge, promote, demote, certifications), staff see admin
	actions by level (1+ goto/bring/freeze, 2+ kick, 4+ staff ranks).
	The client menu is only a view - everything is validated server-side.

	Add your own from any module:
	MilBase.RegisterPlayerAction("slap", {
		name = "Slap", order = 55,
		visible = function(lp, target) return lp:MBStaffLevel() >= 1 end, -- CLIENT
		run = function(ply, target, extra) ... end,                       -- SERVER
	})
	Optional: prompt = "Reason:" (asks for text), or
	options = function(lp, target) return { {label=..., value=...} } end (submenu).
]]

local cfg = MilBase.Config

-- (The MilBase.RegisterPlayerAction registry lives in core/sh_actions.lua.)

local function isOfficer(ply)
	local rank = ply:MBRank()
	return (rank and rank.canPromote) or false
end

-- Client-side mirror of MilBase.CanManage (the server re-checks for real).
local function canManageView(lp, target)
	if lp:IsAdmin() then return true end
	return isOfficer(lp) and lp:MBFactionID() == target:MBFactionID()
		and lp:MBRankIndex() > target:MBRankIndex()
end

if SERVER then

	util.AddNetworkString("MilBase_PlayerAction")

	net.Receive("MilBase_PlayerAction", function(_, ply)
		local id = net.ReadString()
		local target = net.ReadEntity()
		local extra = net.ReadString()

		if (ply.mb_lastAction or 0) > CurTime() - 0.3 then return end
		ply.mb_lastAction = CurTime()

		local action = MilBase.PlayerActions[id]
		if not action or not action.run then return end
		if not IsValid(target) or not target:IsPlayer() then return end

		action.run(ply, target, extra)
	end)

	-- Permission helper for staff actions.
	function MilBase.StaffActionAllowed(ply, target, level, needOutrank)
		if ply:MBStaffLevel() < level then
			MilBase.Notify(ply, "You don't have the staff authority for that.")
			return false
		end
		if needOutrank and IsValid(target) and target:MBStaffLevel() >= ply:MBStaffLevel() then
			MilBase.Notify(ply, "They hold an equal or higher staff rank.")
			return false
		end
		return true
	end

else

	function MilBase.RunPlayerAction(id, target, extra)
		net.Start("MilBase_PlayerAction")
			net.WriteString(id)
			net.WriteEntity(target)
			net.WriteString(extra or "")
		net.SendToServer()
	end

	function MilBase.OpenPlayerMenu(target)
		if not IsValid(target) or not target:IsPlayer() then return end

		local lp = LocalPlayer()
		local menu = DermaMenu()

		local rank = target:MBRank()
		local title = menu:AddOption(target:MBName()
			.. (rank and ("  —  " .. rank.name) or ""))
		title:SetEnabled(false)
		menu:AddSpacer()

		local added = false
		for _, id in ipairs(MilBase.PlayerActionOrder) do
			local action = MilBase.PlayerActions[id]

			if not action.visible or action.visible(lp, target) then
				added = true

				if action.prompt then
					local opt = menu:AddOption(action.name, function()
						Derma_StringRequest(action.name, action.prompt, "", function(text)
							MilBase.RunPlayerAction(id, target, text)
						end)
					end)
					if action.icon then opt:SetIcon(action.icon) end
				elseif action.options then
					local sub = menu:AddSubMenu(action.name)
					for _, choice in ipairs(action.options(lp, target)) do
						sub:AddOption(choice.label, function()
							MilBase.RunPlayerAction(id, target, choice.value)
						end)
					end
				else
					local opt = menu:AddOption(action.name, function()
						MilBase.RunPlayerAction(id, target, "")
					end)
					if action.icon then opt:SetIcon(action.icon) end
				end
			end
		end

		if not added then
			menu:AddOption("No actions available"):SetEnabled(false)
		end

		menu:Open()
	end

	-- Hold C, right-click a soldier -> Interact.
	properties.Add("milbase_interact", {
		MenuLabel = "Interact",
		Order = 400,
		MenuIcon = "icon16/user_comment.png",
		Filter = function(self, ent, ply)
			return IsValid(ent) and ent:IsPlayer() and ent ~= ply
		end,
		Action = function(self, ent)
			MilBase.OpenPlayerMenu(ent)
		end,
	})

end

--------------------------------------------------------------------------
-- Regiment management (officers / admins)
--------------------------------------------------------------------------

MilBase.RegisterPlayerAction("recruit", {
	name = "Recruit Into My Regiment",
	icon = "icon16/user_add.png",
	order = 10,
	visible = function(lp, target)
		return target ~= lp and isOfficer(lp)
			and target:MBFactionID() == cfg.DefaultFaction
			and lp:MBFactionID() ~= cfg.DefaultFaction
	end,
	run = function(ply, target)
		local faction = ply:MBFaction()
		if faction then MilBase.TryAssignFaction(ply, target, faction) end
	end,
})

MilBase.RegisterPlayerAction("discharge", {
	name = "Discharge To Recruits",
	icon = "icon16/user_delete.png",
	order = 11,
	visible = function(lp, target)
		return target ~= lp and isOfficer(lp)
			and lp:MBFactionID() ~= cfg.DefaultFaction
			and target:MBFactionID() == lp:MBFactionID()
			and lp:MBRankIndex() > target:MBRankIndex()
	end,
	run = function(ply, target)
		local faction = MilBase.GetFaction(cfg.DefaultFaction)
		if faction then MilBase.TryAssignFaction(ply, target, faction) end
	end,
})

MilBase.RegisterPlayerAction("promote", {
	name = "Promote",
	icon = "icon16/arrow_up.png",
	order = 12,
	visible = function(lp, target) return target ~= lp and canManageView(lp, target) end,
	run = function(ply, target) MilBase.ChangeRank(ply, target, 1) end,
})

MilBase.RegisterPlayerAction("demote", {
	name = "Demote",
	icon = "icon16/arrow_down.png",
	order = 13,
	visible = function(lp, target) return target ~= lp and canManageView(lp, target) end,
	run = function(ply, target) MilBase.ChangeRank(ply, target, -1) end,
})

MilBase.RegisterPlayerAction("certifications", {
	name = "Certifications",
	order = 20,
	visible = function(lp, target) return target ~= lp and canManageView(lp, target) end,
	options = function(lp, target)
		local out = {}
		for _, id in ipairs(MilBase.CertOrder) do
			local cert = MilBase.Certs[id]
			local persistent = target:MBHasPersistentCert(id)
			local temporary = target:MBHasTemporaryCert(id)
			local restricted = cert and not MilBase.CertAllowedForFaction(cert, target)
			table.insert(out, {
				label = (persistent and "✔  " or temporary and "TEMP  " or restricted and "LOCKED  " or "")
					.. cert.name,
				value = id,
			})
		end
		return out
	end,
	run = function(ply, target, extra)
		if not MilBase.Certs[extra] then return end
		MilBase.SetCertification(ply, target, extra, not target:MBHasPersistentCert(extra))
	end,
})

--------------------------------------------------------------------------
-- Social
--------------------------------------------------------------------------

MilBase.RegisterPlayerAction("pm", {
	name = "Private Message",
	icon = "icon16/email.png",
	order = 30,
	prompt = "Message:",
	visible = function(lp, target) return target ~= lp end,
	run = function(ply, target, text)
		text = string.Trim(text or "")
		if text == "" then return end

		local COL = Color(220, 160, 220)
		MilBase.ChatMsg(target, COL, "[PM from " .. ply:MBName() .. "] ", color_white, text)
		MilBase.ChatMsg(ply, COL, "[PM to " .. target:MBName() .. "] ", color_white, text)
	end,
})

--------------------------------------------------------------------------
-- Staff (levels from config/sh_staff.lua)
--------------------------------------------------------------------------

MilBase.RegisterPlayerAction("goto", {
	name = "Go To  (staff)",
	icon = "icon16/arrow_right.png",
	order = 50,
	visible = function(lp, target) return target ~= lp and lp:MBStaffLevel() >= 1 end,
	run = function(ply, target)
		if not MilBase.StaffActionAllowed(ply, target, 1, false) then return end
		ply:SetPos(target:GetPos() + target:GetForward() * 50 + Vector(0, 0, 8))
		MilBase.Notify(ply, "Teleported to " .. target:MBName() .. ".")
	end,
})

MilBase.RegisterPlayerAction("bring", {
	name = "Bring  (staff)",
	icon = "icon16/arrow_left.png",
	order = 51,
	visible = function(lp, target) return target ~= lp and lp:MBStaffLevel() >= 1 end,
	run = function(ply, target)
		if not MilBase.StaffActionAllowed(ply, target, 1, true) then return end
		target:SetPos(ply:GetPos() + ply:GetForward() * 50 + Vector(0, 0, 8))
		MilBase.Notify(ply, "Brought " .. target:MBName() .. ".")
		MilBase.Notify(target, "You were teleported by " .. ply:MBName() .. ".")
	end,
})

MilBase.RegisterPlayerAction("freeze", {
	name = "Freeze / Unfreeze  (staff)",
	icon = "icon16/lock.png",
	order = 52,
	visible = function(lp, target) return target ~= lp and lp:MBStaffLevel() >= 1 end,
	run = function(ply, target)
		if not MilBase.StaffActionAllowed(ply, target, 1, true) then return end

		local freeze = not target:IsFlagSet(FL_FROZEN)
		target:Freeze(freeze)
		MilBase.Notify(ply, (freeze and "Froze " or "Unfroze ") .. target:MBName() .. ".")
		MilBase.Notify(target, freeze and ("You were frozen by " .. ply:MBName() .. ".")
			or "You were unfrozen.")
	end,
})

MilBase.RegisterPlayerAction("kick", {
	name = "Kick  (staff)",
	icon = "icon16/door_out.png",
	order = 60,
	prompt = "Reason:",
	visible = function(lp, target) return target ~= lp and lp:MBStaffLevel() >= 2 end,
	run = function(ply, target, reason)
		if not MilBase.StaffActionAllowed(ply, target, 2, true) then return end

		reason = string.Trim(reason or "")
		if reason == "" then reason = "No reason given" end

		MilBase.ChatMsg(nil, Color(200, 160, 80), "[STAFF] ", color_white,
			target:MBName() .. " was kicked by " .. ply:MBName() .. " (" .. reason .. ").")
		target:Kick("Kicked by " .. ply:MBName() .. ": " .. reason)
	end,
})

MilBase.RegisterPlayerAction("setstaff", {
	name = "Set Staff Rank",
	order = 70,
	visible = function(lp, target) return target ~= lp and lp:MBStaffLevel() >= 4 end,
	options = function(lp, target)
		local out = { { label = "Remove Staff Rank", value = "user" } }
		for _, id in ipairs(MilBase.StaffOrder) do
			local rank = MilBase.StaffRanks[id]
			if rank.level < lp:MBStaffLevel() then
				table.insert(out, { label = rank.name, value = id })
			end
		end
		return out
	end,
	run = function(ply, target, extra)
		if not MilBase.StaffActionAllowed(ply, target, 4, true) then return end

		local def = MilBase.StaffRanks[extra]
		if def and def.level >= ply:MBStaffLevel() then
			MilBase.Notify(ply, "You can only assign ranks below your own.")
			return
		end

		MilBase.SetStaffRank(target:SteamID64(), extra, ply)
	end,
})
