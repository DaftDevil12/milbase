--[[
	Medical module: EFT-style limb damage + Tarkov injuries on top of
	the milsim wounded state.

	LIMBS (see the MEDICAL tab in the F4 menu):
	  Seven body parts with their own HP (cfg.LimbHealth). Bullets damage
	  the part they hit; falls damage the legs; explosions spread.
	  A part at 0 HP is "destroyed" (blacked):
	    legs    -> you limp            arms    -> your aim sways
	    stomach -> slow stamina regen  head/thorax -> you're going down anyway
	  Blacked parts take extra damage (passed to your body) and can only
	  be restored with a Surgical Kit. Medkits heal the limb you target.

	INJURIES:
	  Bleeding  - bandage it or bleed out.  Fracture - splint it or limp.
	  Painkillers - suppress pain for a while.  Timed channels; real
	  damage interrupts them.

	WOUNDED: a killing blow downs you at 1 HP. Teammates hold [E] to
	stabilize you (consumes THEIR bandage). Medics are faster. A second
	hit finishes you. SPACE gives up.
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Limb definitions (shared: the body screen uses the same table)
-- px/py are fractions of the standing playermodel view, used to place
-- the HP chips on the model (mirrored: their left = your screen right).
--------------------------------------------------------------------------

MilBase.Limbs = {
	{ id = "head",      name = "HEAD",    px = 0.50, py = 0.08 },
	{ id = "thorax",    name = "THORAX",  px = 0.50, py = 0.28 },
	{ id = "stomach",   name = "STOMACH", px = 0.50, py = 0.44 },
	{ id = "left_arm",  name = "L. ARM",  px = 0.78, py = 0.34 },
	{ id = "right_arm", name = "R. ARM",  px = 0.22, py = 0.34 },
	{ id = "left_leg",  name = "L. LEG",  px = 0.64, py = 0.75 },
	{ id = "right_leg", name = "R. LEG",  px = 0.36, py = 0.75 },
}

function MilBase.LimbMax(id)
	return (cfg.LimbHealth and cfg.LimbHealth[id]) or 60
end

function MilBase.GetLimb(ply, id)
	return ply:GetNWInt("mb_limb_" .. id, MilBase.LimbMax(id))
end

local function limbName(id)
	return string.upper(string.gsub(id, "_", " "))
end

if SERVER then

	local HITGROUP_LIMB = {
		[HITGROUP_HEAD] = "head",
		[HITGROUP_CHEST] = "thorax",
		[HITGROUP_STOMACH] = "stomach",
		[HITGROUP_LEFTARM] = "left_arm",
		[HITGROUP_RIGHTARM] = "right_arm",
		[HITGROUP_LEFTLEG] = "left_leg",
		[HITGROUP_RIGHTLEG] = "right_leg",
	}

	function MilBase.SetLimb(ply, id, value)
		ply:SetNWInt("mb_limb_" .. id, math.Clamp(value, 0, MilBase.LimbMax(id)))
	end

	local function damageLimb(ply, id, amount)
		local cur = MilBase.GetLimb(ply, id)
		if cur <= 0 then return end

		local new = math.max(0, cur - math.ceil(amount))
		MilBase.SetLimb(ply, id, new)

		if new <= 0 then
			ply:EmitSound("physics/body/body_medium_break3.wav")
			MilBase.Notify(ply, limbName(id) .. " destroyed!")
		end
	end

	local function isMedic(ply)
		local rank = ply:MBRank()
		local faction = ply:MBFaction()
		if (rank and rank.medic) or (faction and faction.medic) then return true end

		for _, certID in ipairs(ply:MBCertList()) do
			local cert = MilBase.Certs[certID]
			if cert and (cert.medic or cert.medicOthers) then return true end
		end
		return false
	end

	-- Certification perks: treatment speed, effectiveness, treating others.
	local function certMedSpeed(ply)
		local mult = 1
		for _, certID in ipairs(ply:MBCertList()) do
			local cert = MilBase.Certs[certID]
			if cert and cert.medSpeed then mult = math.min(mult, cert.medSpeed) end
		end
		return mult
	end

	local function certMedEfficiency(ply)
		local mult = 1
		for _, certID in ipairs(ply:MBCertList()) do
			local cert = MilBase.Certs[certID]
			if cert and cert.medEfficiency then mult = math.max(mult, cert.medEfficiency) end
		end
		return mult
	end

	local function canTreatOthers(ply)
		for _, certID in ipairs(ply:MBCertList()) do
			local cert = MilBase.Certs[certID]
			if cert and cert.medicOthers then return true end
		end
		return false
	end

	local function cancelChannel(ply, notify)
		if not ply.mb_med then return end
		ply.mb_med = nil
		ply:SetNWFloat("mb_medprog", 0)
		if notify then MilBase.Notify(ply, "First aid interrupted!") end
	end

	local function setWounded(ply)
		cancelChannel(ply)
		MilBase.DropActiveWeapon(ply)

		ply:SetNWBool("mb_wounded", true)
		ply:SetNWFloat("mb_bleedout", CurTime() + cfg.BleedoutTime)
		ply:SetHealth(1)
		ply:StripWeapons()
		ply:SetJumpPower(0)
		MilBase.UpdateMoveSpeed(ply)

		MilBase.TalkRanged(ply, cfg.YellRange, Color(220, 90, 90),
			"** " .. ply:MBName() .. " goes down, badly wounded!")
	end

	local function setFractured(ply)
		ply:SetNWBool("mb_fractured", true)
		ply:EmitSound("physics/body/body_medium_break2.wav")
		MilBase.Notify(ply, "Your leg is fractured! Apply a splint.")
	end

	function MilBase.ReviveWounded(ply, healer)
		ply:SetNWBool("mb_wounded", false)
		ply:SetHealth(cfg.ReviveHealth)
		ply:SetJumpPower(200)

		-- Field stabilization gets your vitals barely functional again.
		for _, id in ipairs({ "head", "thorax" }) do
			if MilBase.GetLimb(ply, id) <= 0 then
				MilBase.SetLimb(ply, id, math.ceil(MilBase.LimbMax(id) * 0.15))
			end
		end

		MilBase.UpdateMoveSpeed(ply)
		hook.Run("PlayerLoadout", ply)

		MilBase.Notify(ply, "You were stabilized by " .. healer:MBName() .. ".")
		MilBase.Notify(healer, "You stabilized " .. ply:MBName() .. ".")
	end

	-- Record where bullets land (runs before EntityTakeDamage).
	hook.Add("ScalePlayerDamage", "MilBase.MedicalHitGroups", function(ply, hitgroup)
		ply.mb_lastHitGroup = hitgroup
	end)

	hook.Add("EntityTakeDamage", "MilBase.Medical", function(ent, dmg)
		if not cfg.MedicalEnabled then return end
		if not ent:IsPlayer() or not ent:Alive() then return end
		if dmg:GetAttacker() == ent then return end -- suicides skip all of this

		-- Event enemies die outright (no downed/revive) so their lives tick.
		if MilBase.IsEventEnemy and MilBase.IsEventEnemy(ent) then return end

		if dmg:GetDamage() >= 5 then
			cancelChannel(ent, true) -- real damage interrupts first aid
		end

		-- Already wounded at 1 HP: any further hit kills normally.
		if ent:GetNWBool("mb_wounded", false) then return end

		-- Route damage to body parts.
		local hitgroup = ent.mb_lastHitGroup
		ent.mb_lastHitGroup = nil

		local damage = dmg:GetDamage()
		local isBullet = dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT)
			or dmg:IsDamageType(DMG_SLASH)

		if dmg:IsFallDamage() then
			damageLimb(ent, "left_leg", damage / 2)
			damageLimb(ent, "right_leg", damage / 2)
		elseif dmg:IsExplosionDamage() then
			damageLimb(ent, "thorax", damage * 0.5)
			damageLimb(ent, "stomach", damage * 0.4)
			damageLimb(ent, "left_leg", damage * 0.25)
			damageLimb(ent, "right_leg", damage * 0.25)
		else
			local limb = HITGROUP_LIMB[hitgroup] or "thorax"
			if MilBase.GetLimb(ent, limb) <= 0 then
				-- Hits to destroyed parts pass more damage into your body.
				dmg:ScaleDamage(cfg.BlackedDamageScale)
				damage = dmg:GetDamage()
			end
			damageLimb(ent, limb, damage)
		end

		if damage < ent:Health() then
			-- Survivable hit: roll for injuries.
			if isBullet then
				if damage >= cfg.BleedDamageThreshold
				and not ent:GetNWBool("mb_bleeding", false)
				and math.random() < cfg.BleedChance then
					ent:SetNWBool("mb_bleeding", true)
					MilBase.Notify(ent, "You are bleeding! Apply a bandage.")
				end

				if (hitgroup == HITGROUP_LEFTLEG or hitgroup == HITGROUP_RIGHTLEG)
				and not ent:GetNWBool("mb_fractured", false)
				and math.random() < cfg.FractureChance then
					setFractured(ent)
				end
			elseif dmg:IsFallDamage() and damage >= 20
			and not ent:GetNWBool("mb_fractured", false)
			and math.random() < cfg.FractureChance * 2 then
				setFractured(ent)
			end
			return
		end

		-- Killing blow: go down wounded instead.
		setWounded(ent)
		return true
	end)

	-- SPACE while wounded = give up.
	hook.Add("KeyPress", "MilBase.MedicalGiveUp", function(ply, key)
		if key == IN_JUMP and ply:Alive() and ply:GetNWBool("mb_wounded", false) then
			ply:SetNWBool("mb_wounded", false)
			ply:Kill()
		end
	end)

	-- Fresh body on respawn; death clears everything.
	local function clearInjuries(ply)
		cancelChannel(ply)
		ply:SetNWBool("mb_bleeding", false)
		ply:SetNWBool("mb_fractured", false)
		ply:SetNWFloat("mb_painkillers", 0)
		ply:SetNWFloat("mb_reviveprog", 0)
		for _, limb in ipairs(MilBase.Limbs) do
			MilBase.SetLimb(ply, limb.id, MilBase.LimbMax(limb.id))
		end
	end

	hook.Add("PlayerDeath", "MilBase.MedicalReset", clearInjuries)
	hook.Add("PlayerSpawn", "MilBase.MedicalReset", clearInjuries)

	--------------------------------------------------------------------------
	-- Using medical items (limb = optional target from the body screen)
	--------------------------------------------------------------------------

	local function isLimbID(id)
		return cfg.LimbHealth and cfg.LimbHealth[id] ~= nil
	end

	-- target: another player to treat (requires a medicOthers certification).
	function MilBase.UseMedicalItem(ply, item, limb, target)
		local def = MilBase.Items[item.id]
		local med = def and def.med
		if not med then return end

		if limb and not isLimbID(limb) then limb = nil end

		if ply.mb_med or ply.mb_eng then
			MilBase.Notify(ply, "Your hands are already busy.")
			return
		end

		-- Treating someone else
		local patient = ply
		if IsValid(target) and target ~= ply then
			if not target:IsPlayer() or not target:Alive() then
				MilBase.Notify(ply, "No patient in front of you.")
				return
			end
			if not canTreatOthers(ply) then
				MilBase.Notify(ply, "You are not certified to treat other soldiers.")
				return
			end
			if target:GetNWBool("mb_wounded", false) then
				MilBase.Notify(ply, "They're down - hold [E] on them to stabilize first.")
				return
			end
			if target:GetPos():DistToSqr(ply:GetPos()) > 130 * 130 then
				MilBase.Notify(ply, "Get closer to your patient.")
				return
			end
			patient = target
		end

		if med.action == "bandage" and not patient:GetNWBool("mb_bleeding", false) then
			MilBase.Notify(ply, patient == ply and "You are not bleeding."
				or patient:MBName() .. " is not bleeding.")
			return

		elseif med.action == "splint" and not patient:GetNWBool("mb_fractured", false) then
			MilBase.Notify(ply, "Nothing is fractured.")
			return

		elseif med.action == "heal" then
			if limb and MilBase.GetLimb(patient, limb) <= 0 then
				MilBase.Notify(ply, limbName(limb) .. " is destroyed - it needs surgery, not a medkit.")
				return
			end
			if not limb then
				-- Auto-target the most damaged working limb.
				local worst = 0
				for _, l in ipairs(MilBase.Limbs) do
					local cur = MilBase.GetLimb(patient, l.id)
					local missing = MilBase.LimbMax(l.id) - cur
					if cur > 0 and missing > worst then
						worst = missing
						limb = l.id
					end
				end
			end
			if patient:Health() >= patient:GetMaxHealth()
			and (not limb or MilBase.GetLimb(patient, limb) >= MilBase.LimbMax(limb)) then
				MilBase.Notify(ply, patient == ply and "You are at full health."
					or patient:MBName() .. " is at full health.")
				return
			end

		elseif med.action == "surgery" then
			if limb and MilBase.GetLimb(patient, limb) > 0 then
				MilBase.Notify(ply, limbName(limb) .. " doesn't need surgery.")
				return
			end
			if not limb then
				for _, l in ipairs(MilBase.Limbs) do
					if MilBase.GetLimb(patient, l.id) <= 0 then
						limb = l.id
						break
					end
				end
			end
			if not limb then
				MilBase.Notify(ply, "No destroyed body parts.")
				return
			end
		end

		local duration = med.time * certMedSpeed(ply)

		ply.mb_med = {
			uid = item.uid,
			action = med.action,
			limb = limb,
			target = patient ~= ply and patient or nil,
			finish = CurTime() + duration,
			duration = duration,
		}
		ply:SetNWString("mb_medaction", string.upper(def.name)
			.. (limb and (" — " .. limbName(limb)) or "")
			.. (patient ~= ply and ("  →  " .. string.upper(patient:MBName())) or ""))
		ply:SetNWFloat("mb_medprog", 0.01)

		if patient ~= ply then
			MilBase.Notify(patient, ply:MBName() .. " is treating you...")
		end
	end

	local function finishChannel(ply, item, med, ch)
		-- Someone slipped out of range mid-treatment: don't apply anything.
		local patient = ch.target or ply
		if patient ~= ply and (not IsValid(patient) or not patient:Alive()) then return end

		if med.action == "bandage" then
			patient:SetNWBool("mb_bleeding", false)
			if not isMedic then
			MilBase.RemoveItemUID(ply, item.uid, 1)
			end
			MilBase.Notify(patient, "Bleeding stopped.")

		elseif med.action == "splint" then
			patient:SetNWBool("mb_fractured", false)
			if not isMedic then
			MilBase.RemoveItemUID(ply, item.uid, 1)
			end
			MilBase.Notify(patient, "Fracture splinted.")

		elseif med.action == "painkillers" then
			patient:SetNWFloat("mb_painkillers", CurTime() + cfg.PainkillerDuration)
			if not isMedic then
			MilBase.RemoveItemUID(ply, item.uid, 1)
			end
			MilBase.Notify(patient, "Painkillers kick in.")

		elseif med.action == "heal" then
			-- Certified medics get more out of every use.
			local amount = math.ceil((med.heal or 30) * certMedEfficiency(ply))
			local pool = item.charges or amount
			local heal = math.min(amount, pool)

			local limbHeal = 0
			if ch.limb and MilBase.GetLimb(patient, ch.limb) > 0 then
				limbHeal = math.min(heal, MilBase.LimbMax(ch.limb) - MilBase.GetLimb(patient, ch.limb))
				MilBase.SetLimb(patient, ch.limb, MilBase.GetLimb(patient, ch.limb) + limbHeal)
			end

			local bodyHeal = math.min(heal, patient:GetMaxHealth() - patient:Health())
			patient:SetHealth(patient:Health() + bodyHeal)

			local used = math.max(limbHeal, bodyHeal)
			if item.charges then
				item.charges = item.charges - used
				if item.charges <= 0 then
					MilBase.RemoveItemUID(ply, item.uid)
				else
					MilBase.MarkInvDirty(ply)
				end
			else
				MilBase.RemoveItemUID(ply, item.uid, 1)
			end

		elseif med.action == "surgery" then
			if ch.limb then
				MilBase.SetLimb(patient, ch.limb,
					math.ceil(MilBase.LimbMax(ch.limb) * cfg.SurgeryRestoreFraction))
				MilBase.Notify(patient, limbName(ch.limb) .. " is functional again.")
			end
			if item.charges then
				item.charges = item.charges - 1
				if isMedic and item.charges <= 0 then
					item.charges = item.charges + 1000
				else
					MilBase.RemoveItemUID(ply, item.uid)
				end
			else
				MilBase.RemoveItemUID(ply, item.uid, 1)
			end
		end

		if patient ~= ply then
			MilBase.Notify(ply, "Treatment on " .. patient:MBName() .. " complete.")
		end
		patient:EmitSound("items/medshot4.wav")
	end

	--------------------------------------------------------------------------
	-- The medical tick
	--------------------------------------------------------------------------

	local TICK = 0.2
	local nextTick = 0

	hook.Add("Think", "MilBase.MedicalThink", function()
		if not cfg.MedicalEnabled or CurTime() < nextTick then return end
		nextTick = CurTime() + TICK

		for _, ply in ipairs(player.GetAll()) do
			if not ply:Alive() then continue end

			-- Bleedout while wounded
			if ply:GetNWBool("mb_wounded", false) then
				if CurTime() > ply:GetNWFloat("mb_bleedout", 0) then
					ply:SetNWBool("mb_wounded", false)
					ply:Kill()
				end
				continue
			end

			-- Bleeding drains HP until bandaged
			if ply:GetNWBool("mb_bleeding", false) and CurTime() > (ply.mb_nextBleed or 0) then
				ply.mb_nextBleed = CurTime() + cfg.BleedInterval
				local d = DamageInfo()
				d:SetDamage(1)
				d:SetAttacker(game.GetWorld())
				d:SetInflictor(game.GetWorld())
				d:SetDamageType(DMG_GENERIC)
				ply:TakeDamageInfo(d)
				if not ply:Alive() then continue end
			end

			-- Limping: fracture, destroyed leg, or low HP - unless painkillers
			local pain = ply:GetNWFloat("mb_painkillers", 0) > CurTime()
			local legsOut = MilBase.GetLimb(ply, "left_leg") <= 0
				or MilBase.GetLimb(ply, "right_leg") <= 0
			local limping = (ply:GetNWBool("mb_fractured", false) or legsOut
				or ply:Health() <= cfg.LimpHealth) and not pain
			if limping ~= (ply.mb_limping or false) then
				ply.mb_limping = limping
				MilBase.UpdateMoveSpeed(ply)
			end

			-- First aid channel
			if ply.mb_med then
				local ch = ply.mb_med
				local item = MilBase.InvFindAny(MilBase.GetInventory(ply), ch.uid)
				local def = item and MilBase.Items[item.id]

				-- Treating someone else: they must stay close, alive, and up.
				if ch.target and (not IsValid(ch.target) or not ch.target:Alive()
				or ch.target:GetNWBool("mb_wounded", false)
				or ch.target:GetPos():DistToSqr(ply:GetPos()) > 150 * 150) then
					cancelChannel(ply, true)
				elseif not def or not def.med then
					cancelChannel(ply)
				elseif CurTime() >= ch.finish then
					ply.mb_med = nil
					ply:SetNWFloat("mb_medprog", 0)
					finishChannel(ply, item, def.med, ch)
				else
					ply:SetNWFloat("mb_medprog", 1 - (ch.finish - CurTime()) / ch.duration)
				end
			end

			-- Reviving: hold E while looking at a wounded soldier up close
			local progress = 0
			if ply:KeyDown(IN_USE) then
				local target = ply:GetEyeTrace().Entity

				if IsValid(target) and target:IsPlayer()
				and target:GetNWBool("mb_wounded", false)
				and target:GetPos():DistToSqr(ply:GetPos()) < 120 * 120 then
					if cfg.ReviveRequiresMedical and MilBase.CountItem(ply, "bandage") < 1 then
						if ply.mb_reviveDenied ~= target then
							ply.mb_reviveDenied = target
							MilBase.Notify(ply, "You need a bandage to stabilize them.")
						end
					else
						if ply.mb_reviveTarget ~= target then
							ply.mb_reviveTarget = target
							ply.mb_reviveTime = 0
						end

						local needed = isMedic(ply) and cfg.MedicReviveTime or cfg.ReviveTime
						ply.mb_reviveTime = ply.mb_reviveTime + TICK
						progress = ply.mb_reviveTime / needed

						if progress >= 1 then
							if cfg.ReviveRequiresMedical then
								MilBase.TakeItem(ply, "bandage", 1)
							end
							MilBase.ReviveWounded(target, ply)
							ply.mb_reviveTarget = nil
							progress = 0
						end
					end
				else
					ply.mb_reviveTarget = nil
					ply.mb_reviveDenied = nil
				end
			else
				ply.mb_reviveTarget = nil
				ply.mb_reviveDenied = nil
			end

			ply:SetNWFloat("mb_reviveprog", progress)
		end
	end)

else -- CLIENT

	-- Destroyed arms make your aim wander.
	local lastSwayP, lastSwayY = 0, 0

	hook.Add("CreateMove", "MilBase.ArmSway", function(cmd)
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() then return end

		local arms = 0
		if ply:GetNWInt("mb_limb_left_arm", 1) <= 0 then arms = arms + 1 end
		if ply:GetNWInt("mb_limb_right_arm", 1) <= 0 then arms = arms + 1 end

		if arms == 0 then
			lastSwayP, lastSwayY = 0, 0
			return
		end

		local t = RealTime()
		local mag = 0.35 * arms
		local p = math.sin(t * 1.9) * mag
		local y = math.cos(t * 1.3) * mag

		local ang = cmd:GetViewAngles()
		ang.p = ang.p + (p - lastSwayP)
		ang.y = ang.y + (y - lastSwayY)
		cmd:SetViewAngles(ang)

		lastSwayP, lastSwayY = p, y
	end)

	local function channelBar(label, progress, color)
		local w, h = 300, 26
		local x, y = ScrW() / 2 - w / 2, math.floor(ScrH() * 0.62)

		MilBase.DrawPanelBF2(x, y, w, h, { cut = 7 })
		MilBase.DrawBar(x + 5, y + h - 8, w - 10, 4, math.min(progress, 1), color)
		MilBase.DrawBrackets(x, y, w, h, Color(color.r, color.g, color.b, 190), 7)

		draw.SimpleText(label, "MB.Tiny", ScrW() / 2, y + 9,
			color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	hook.Add("HUDPaint", "MilBase.MedicalHUD", function()
		if MilBase.InEventView() then return end
		local ply = LocalPlayer()
		if not IsValid(ply) or not ply:Alive() then return end

		if ply:GetNWBool("mb_wounded", false) then
			surface.SetDrawColor(110, 0, 0, 80)
			surface.DrawRect(0, 0, ScrW(), ScrH())

			draw.SimpleText("WOUNDED", "MB.Huge", ScrW() / 2, ScrH() * 0.35,
				Color(220, 70, 70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			local remaining = math.max(0, ply:GetNWFloat("mb_bleedout", 0) - CurTime())
			draw.SimpleText("Bleeding out in " .. math.ceil(remaining) .. "s", "MB.Med",
				ScrW() / 2, ScrH() * 0.35 + 48, color_white,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("A soldier can hold [E] on you to stabilize you  •  SPACE to give up",
				"MB.Small", ScrW() / 2, ScrH() * 0.35 + 76, Color(200, 200, 200),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		local reviveProg = ply:GetNWFloat("mb_reviveprog", 0)
		if reviveProg > 0 then
			channelBar("STABILIZING...", reviveProg, Color(110, 190, 110))
			return
		end

		local medProg = ply:GetNWFloat("mb_medprog", 0)
		if medProg > 0 then
			channelBar(ply:GetNWString("mb_medaction", "FIRST AID"), medProg, Color(220, 165, 70))
		end
	end)

end
