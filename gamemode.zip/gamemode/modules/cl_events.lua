--[[
	Event system (client): a Zeus-style game-master view.

	  WASD            - fly (view-relative)   SPACE / CTRL - up / down
	  hold SHIFT      - fly faster            mouse wheel  - fly speed
	  hold MIDDLE MSE - look around           left-drag    - box select
	  left-drag a unit- reposition it         right-click  - context menu
	  DELETE          - delete selection       ENTER        - commit waypoints

	Right-click opens a Zeus context menu: Create (units / vehicles /
	effects / objects), and for selected units Move/Attack/Patrol here,
	Behavior, Heal, Invincible and Delete.
]]

if SERVER then return end

local ui = MilBase.UI

local active = false
local panel, contextMenu

-- Free-fly camera
local camPos = Vector(0, 0, 0)
local camAng = Angle(0, 0, 0)
local flySpeed = 900
local freeLook = nil

-- Interaction state
local selected = {}          -- set of entities
local placing = nil          -- a spawn def armed for placement
local pendingPath = {}       -- waypoints being placed
local boxStart = nil         -- box-select anchor {x,y}
local dragging = nil         -- entity being dragged to a new position
local buildMode = false      -- sandbox build sub-mode (toolgun + spawn menu)
local nextDragSend, nextCamSend = 0, 0
local deleteHeld, enterHeld, bHeld = false, false, false

-- Spawn settings applied to every placement (team / squad size / health /
-- starting stance). Cycled from the SPAWN SETTINGS panel.
local spawnOpts = { team = "enemy", count = 1, hp = 1, stance = "" }

--------------------------------------------------------------------------
-- Camera / cursor math
--------------------------------------------------------------------------

local function cursorWorld()
	local dir = gui.ScreenToVector(gui.MouseX(), gui.MouseY())
	local tr = util.TraceLine({
		start = camPos,
		endpos = camPos + dir * 100000,
		mask = MASK_SOLID_BRUSHONLY,
	})
	return tr.HitPos, tr
end

--------------------------------------------------------------------------
-- Selection helpers
--------------------------------------------------------------------------

local function eventUnits()
	local out = {}
	for _, ent in ipairs(ents.GetAll()) do
		if ent:GetNWBool("mb_event", false) then out[#out + 1] = ent end
	end
	return out
end

local function unitUnderCursor()
	local mx, my = gui.MouseX(), gui.MouseY()
	local best, bestDist
	for _, ent in ipairs(eventUnits()) do
		local s = ent:GetPos():ToScreen()
		if s.visible then
			local d = math.sqrt((s.x - mx) ^ 2 + (s.y - my) ^ 2)
			if d < 45 and (not bestDist or d < bestDist) then best, bestDist = ent, d end
		end
	end
	return best
end

local function selectionList()
	local out = {}
	for ent in pairs(selected) do
		if IsValid(ent) then out[#out + 1] = ent end
	end
	return out
end

-- Nearest living player to the cursor (for attack / follow orders).
local function playerUnderCursor()
	local mx, my = gui.MouseX(), gui.MouseY()
	local best, bestDist
	for _, p in ipairs(player.GetAll()) do
		if p == LocalPlayer() or not p:Alive() or p:GetNWBool("mb_eventmode", false) then continue end
		local s = p:EyePos():ToScreen()
		if s.visible then
			local d = math.sqrt((s.x - mx) ^ 2 + (s.y - my) ^ 2)
			if d < 48 and (not bestDist or d < bestDist) then best, bestDist = p, d end
		end
	end
	return best
end

local function hasLVSSelected()
	for ent in pairs(selected) do
		if IsValid(ent) and ent.LVS then return true end
	end
	return false
end

--------------------------------------------------------------------------
-- Net senders
--------------------------------------------------------------------------

local function sendSpawn(def, pos)
	net.Start("MilBase_EventSpawn")
		net.WriteString(def.id)
		net.WriteVector(pos)
		net.WriteFloat(camAng.y + 180)
		net.WriteString(spawnOpts.team)
		net.WriteUInt(spawnOpts.count, 4)
		net.WriteFloat(spawnOpts.hp)
		net.WriteString(spawnOpts.stance)
	net.SendToServer()
end

local function sendOrder(id, pos, target, points, str)
	local list = selectionList()
	if #list == 0 then return end

	net.Start("MilBase_EventOrder")
		net.WriteString(id)
		net.WriteUInt(#list, 10)
		for _, ent in ipairs(list) do net.WriteUInt(ent:EntIndex(), 16) end
		net.WriteVector(pos or Vector(0, 0, 0))
		net.WriteBool(IsValid(target))
		if IsValid(target) then net.WriteEntity(target) end
		net.WriteUInt(points and #points or 0, 6)
		for _, p in ipairs(points or {}) do net.WriteVector(p) end
		net.WriteString(str or "")
	net.SendToServer()
end

local function sendTeleport(ent, pos)
	net.Start("MilBase_EventOrder")
		net.WriteString("teleport")
		net.WriteUInt(1, 10)
		net.WriteUInt(ent:EntIndex(), 16)
		net.WriteVector(pos)
		net.WriteBool(false)
		net.WriteUInt(0, 6)
		net.WriteString("")
	net.SendToServer()
end

--------------------------------------------------------------------------
-- Enter / exit
--------------------------------------------------------------------------

local buildUI, finishBoxSelect, openContextMenu

-- Toggle the sandbox build sub-mode: fly around as an invisible god with
-- the toolgun / physgun / spawn menu (all native, spawns at your aim).
local function setBuildMode(on)
	buildMode = on
	net.Start("MilBase_EventBuild")
		net.WriteBool(on)
	net.SendToServer()

	if on then
		if IsValid(contextMenu) then contextMenu:Remove() end
		if IsValid(panel) then panel:Remove() panel = nil end
		gui.EnableScreenClicker(false) -- free the native crosshair / spawn menu
	else
		-- Pick the free-cam up from wherever you flew to in build mode.
		local lp = LocalPlayer()
		if IsValid(lp) then
			camPos = lp:EyePos()
			camAng = lp:EyeAngles()
		end
		gui.EnableScreenClicker(true)
		buildUI()
	end
end

local function enter()
	active = true
	buildMode = false
	selected, placing, pendingPath, dragging = {}, nil, {}, nil

	local lp = LocalPlayer()
	camAng = Angle(35, lp:EyeAngles().y, 0)
	camPos = lp:EyePos() + Vector(0, 0, 260) - camAng:Forward() * 380
	flySpeed = 900

	gui.EnableScreenClicker(true)
	buildUI()
end

local function exit()
	active = false
	buildMode = false
	MilBase.EventModal = false
	gui.EnableScreenClicker(false)
	if IsValid(contextMenu) then contextMenu:Remove() end
	if IsValid(MilBase.TriggerBuilderFrame) then MilBase.TriggerBuilderFrame:Remove() end
	if IsValid(MilBase.EnemyManagerFrame) then MilBase.EnemyManagerFrame:Remove() end
	if IsValid(panel) then panel:Remove() end
	panel = nil
end

-- The world point the game-master camera is looking at (used by the
-- event-enemy manager's "set respawn point").
function MilBase.EventAimPos()
	local tr = util.TraceLine({
		start = camPos,
		endpos = camPos + camAng:Forward() * 100000,
		mask = MASK_SOLID_BRUSHONLY,
	})
	return tr.HitPos
end

net.Receive("MilBase_EventState", function()
	if net.ReadBool() then enter() else exit() end
end)

--------------------------------------------------------------------------
-- Per-frame: camera, drag, hotkeys, PVS ping
--------------------------------------------------------------------------

hook.Add("Think", "MilBase.EventThink", function()
	if not active then return end

	-- [B] toggles the sandbox build mode (guarded so it doesn't fire while
	-- typing in the spawn-menu search etc.).
	if not IsValid(vgui.GetKeyboardFocus()) then
		if input.IsKeyDown(KEY_B) then
			if not bHeld then setBuildMode(not buildMode) end
			bHeld = true
		else
			bHeld = false
		end
	end

	if buildMode then return end -- native sandbox controls take over
	if not IsValid(panel) then buildUI() end

	local ft = FrameTime()

	-- Free-fly movement (paused while a menu, text prompt or modal builder
	-- is up, so typing an announcement/objective name doesn't fly the camera).
	if not IsValid(contextMenu) and not IsValid(vgui.GetKeyboardFocus()) and not MilBase.EventModal then
		local spd = flySpeed * (input.IsKeyDown(KEY_LSHIFT) and 3.5 or 1) * ft
		local f, r = camAng:Forward(), camAng:Right()

		if input.IsKeyDown(KEY_W) then camPos = camPos + f * spd end
		if input.IsKeyDown(KEY_S) then camPos = camPos - f * spd end
		if input.IsKeyDown(KEY_D) then camPos = camPos + r * spd end
		if input.IsKeyDown(KEY_A) then camPos = camPos - r * spd end
		if input.IsKeyDown(KEY_SPACE) then camPos = camPos + Vector(0, 0, spd) end
		if input.IsKeyDown(KEY_LCONTROL) then camPos = camPos - Vector(0, 0, spd) end

		if input.IsMouseDown(MOUSE_MIDDLE) then
			if freeLook then
				camAng.y = camAng.y - (gui.MouseX() - freeLook.x) * 0.3
				camAng.p = math.Clamp(camAng.p + (gui.MouseY() - freeLook.y) * 0.3, -89, 89)
			end
			freeLook = { x = gui.MouseX(), y = gui.MouseY() }
		else
			freeLook = nil
		end
	end

	-- Drag-to-reposition: stream the grabbed unit to the cursor.
	if dragging then
		if IsValid(dragging) and input.IsMouseDown(MOUSE_LEFT) then
			if CurTime() > nextDragSend then
				nextDragSend = CurTime() + 0.06
				sendTeleport(dragging, (cursorWorld()))
			end
		else
			dragging = nil
		end
	end

	-- DELETE removes the selection.
	if input.IsKeyDown(KEY_DELETE) then
		if not deleteHeld and #selectionList() > 0 then
			sendOrder("delete")
			selected = {}
			surface.PlaySound("buttons/button10.wav")
		end
		deleteHeld = true
	else
		deleteHeld = false
	end

	-- ENTER commits a waypoint chain (flight path if an LVS is selected).
	if input.IsKeyDown(KEY_ENTER) then
		if not enterHeld and #pendingPath > 0 then
			sendOrder(hasLVSSelected() and "flightpath" or "patrol", pendingPath[1], nil, pendingPath)
			pendingPath = {}
			surface.PlaySound("ui/buttonclickrelease.wav")
		end
		enterHeld = true
	else
		enterHeld = false
	end

	if CurTime() > nextCamSend then
		nextCamSend = CurTime() + 0.25
		net.Start("MilBase_EventCam")
			net.WriteVector(camPos)
		net.SendToServer()
	end
end)

hook.Add("CalcView", "MilBase.EventCamView", function()
	if not active or buildMode then return end
	return { origin = camPos, angles = camAng, fov = 75, drawviewer = false }
end)

hook.Add("HUDShouldDraw", "MilBase.EventHideHUD", function(name)
	if active and not buildMode and name ~= "CHudGMod" then return false end
end)
hook.Add("PreDrawViewModel", "MilBase.EventHideVM", function()
	if active and not buildMode then return true end
end)
hook.Add("CreateMove", "MilBase.EventFreeze", function(cmd)
	-- Command mode freezes the body; build mode flies natively (noclip).
	if active and not buildMode then cmd:ClearMovement() cmd:ClearButtons() end
end)

-- Build-mode banner (the command UI panel is hidden in build mode).
hook.Add("HUDPaint", "MilBase.EventBuildHint", function()
	if not active or not buildMode then return end
	surface.SetDrawColor(0, 0, 0, 190)
	surface.DrawRect(0, 0, ScrW(), 30)
	surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 140)
	surface.DrawRect(0, 30, ScrW(), 2)
	draw.SimpleText("GAME MASTER — BUILD MODE", "MB.Small", 16, 15, ui.accent,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText("Q spawn menu  •  toolgun & physgun  •  noclip fly  •  [B] back to command",
		"MB.Tiny", ScrW() / 2, 15, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

--------------------------------------------------------------------------
-- World markers
--------------------------------------------------------------------------

local function ring(pos, radius, color)
	render.SetColorMaterial()
	render.DrawSphere(pos + Vector(0, 0, 6), radius, 16, 16, ColorAlpha(color, 45))
end

hook.Add("PostDrawTranslucentRenderables", "MilBase.EventWorld", function(_, sky)
	if not active or sky or buildMode then return end

	for ent in pairs(selected) do
		if IsValid(ent) then ring(ent:GetPos(), 34, ui.accent) end
	end

	local hover = unitUnderCursor()
	if IsValid(hover) and not selected[hover] then
		ring(hover:GetPos(), 30, Color(200, 200, 200))
	end

	for _, p in ipairs(pendingPath) do
		ring(p, 22, Color(120, 200, 140))
	end
end)

-- Team colours for unit status readouts.
local TEAM_COLOR = {
	enemy = Color(215, 90, 80),
	friendly = Color(120, 200, 140),
	neutral = Color(190, 190, 190),
}

-- Health + team status floating over selected (and hovered) units.
hook.Add("HUDPaint", "MilBase.EventUnitStatus", function()
	if not active or buildMode then return end

	local shown = {}
	local function drawStatus(ent, selectedUnit)
		if not IsValid(ent) or shown[ent] then return end
		if not (ent:IsNPC() or ent.LVS) then return end -- props have no health bar
		shown[ent] = true

		local top = ent:IsNPC() and (ent:OBBMaxs().z + 14) or 62
		local scr = (ent:GetPos() + Vector(0, 0, top)):ToScreen()
		if not scr.visible then return end

		local tc = TEAM_COLOR[ent:GetNWString("mb_team", "enemy")] or TEAM_COLOR.enemy

		local hp, maxhp = 1, 1
		if ent:IsNPC() then
			hp, maxhp = ent:Health(), ent:GetMaxHealth()
		elseif ent.LVS and ent.GetHP then
			hp = ent:GetHP()
			maxhp = (ent.GetMaxHP and ent:GetMaxHP()) or math.max(hp, 1)
		end
		local frac = maxhp > 0 and math.Clamp(hp / maxhp, 0, 1) or 0

		local w, h = 92, 6
		local x, y = math.Round(scr.x - w / 2), math.Round(scr.y)

		if selectedUnit then
			local def = MilBase.EventSpawns[ent:GetClass()]
			local name = (def and def.name) or ent.PrintName or ent:GetClass()
			draw.SimpleTextOutlined(string.upper(name), "MB.Tiny", scr.x, y - 11,
				ui.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end

		surface.SetDrawColor(0, 0, 0, 190)
		surface.DrawRect(x - 1, y - 1, w + 2, h + 2)
		surface.SetDrawColor(tc)
		surface.DrawRect(x, y, w * frac, h)
		if selectedUnit then
			MilBase.DrawBrackets(x - 2, y - 2, w + 4, h + 4, ui.accent, 4)
		end
	end

	for ent in pairs(selected) do drawStatus(ent, true) end
	local hover = unitUnderCursor()
	if IsValid(hover) then drawStatus(hover, false) end
end)

--------------------------------------------------------------------------
-- Context menu (Zeus radial)
--------------------------------------------------------------------------

openContextMenu = function(worldPos, cursorEnt)
	if IsValid(contextMenu) then contextMenu:Remove() end

	-- Right-clicking a unit with nothing selected picks it.
	if IsValid(cursorEnt) and next(selected) == nil then
		selected = { [cursorEnt] = true }
	end
	local sel = selectionList()

	local menu = DermaMenu()
	contextMenu = menu

	-- CREATE (categories -> spawnables) at the click position.
	local create = menu:AddSubMenu("Create")
	local cats = {}
	for _, id in ipairs(MilBase.EventSpawnOrder) do
		local def = MilBase.EventSpawns[id]
		cats[def.category] = cats[def.category] or {}
		table.insert(cats[def.category], def)
	end
	for cat, defs in SortedPairs(cats) do
		local catSub = create:AddSubMenu(cat)
		for _, def in ipairs(defs) do
			catSub:AddOption(def.name, function() sendSpawn(def, worldPos) end)
		end
	end

	-- OBJECTIVES & NARRATION (always available to the game master).
	local obj = menu:AddSubMenu("Place Objective")
	for _, ot in ipairs(MilBase.ObjectiveOrder) do
		local t = MilBase.ObjectiveTypes[ot]
		obj:AddOption(t.name, function()
			Derma_StringRequest("New Objective", "Objective label:", t.name, function(name)
				net.Start("MilBase_ObjPlace")
					net.WriteVector(worldPos)
					net.WriteString(name)
					net.WriteString(ot)
					net.WriteString("") -- "" = visible to all factions
				net.SendToServer()
			end)
		end)
	end
	menu:AddOption("Announce...", function()
		Derma_StringRequest("Announcement", "Center-screen message:", "", function(text)
			if text ~= "" then RunConsoleCommand("say", "/announce " .. text) end
		end)
	end):SetIcon("icon16/sound.png")

	local jump = menu:AddSubMenu("Jump Camera To")
	local anyPlayers = false
	for _, p in ipairs(player.GetAll()) do
		if p:Alive() and not p:GetNWBool("mb_eventmode", false) then
			anyPlayers = true
			jump:AddOption(p:MBName(), function()
				camPos = p:EyePos() + Vector(0, 0, 220) - camAng:Forward() * 260
			end)
		end
	end
	if not anyPlayers then
		jump:AddOption("(no players)", function() end):SetEnabled(false)
	end

	-- Invite the player under the cursor to play as an event enemy.
	local invitee = playerUnderCursor()
	if IsValid(invitee) and MilBase.EventEnemyOrder and #MilBase.EventEnemyOrder > 0 then
		local inv = menu:AddSubMenu("Invite " .. invitee:MBName() .. " as Enemy")
		for _, id in ipairs(MilBase.EventEnemyOrder) do
			local class = MilBase.EventEnemyClasses[id]
			if not class or class.enabled == false then continue end
			inv:AddOption(class.name, function()
				net.Start("MilBase_EnemyInvite")
					net.WriteEntity(invitee)
					net.WriteString(id)
				net.SendToServer()
			end)
		end
	end

	-- TRIGGERS & LINKED ACTIONS.
	menu:AddSpacer()
	if IsValid(cursorEnt) then
		menu:AddOption("Link Trigger to this Entity...", function()
			MilBase.OpenTriggerBuilder(worldPos, cursorEnt)
		end):SetIcon("icon16/lightning.png")
	end
	menu:AddOption("New Trigger Here...", function()
		MilBase.OpenTriggerBuilder(worldPos, IsValid(cursorEnt) and cursorEnt or nil)
	end):SetIcon("icon16/lightning_add.png")

	-- Delete the nearest trigger zone to the click, if any.
	local nearest, nd
	for _, t in ipairs(MilBase.TriggerSummaries or {}) do
		local d = worldPos:Distance(t.pos)
		if d <= math.max(t.radius, 300) and (not nd or d < nd) then nearest, nd = t, d end
	end
	if nearest then
		menu:AddOption("Delete Trigger Here", function()
			net.Start("MilBase_TriggerDelete")
				net.WriteUInt(nearest.id, 16)
			net.SendToServer()
		end):SetIcon("icon16/lightning_delete.png")
	end

	-- Complete / remove the nearest objective marker to the click.
	local nearObj, nod
	for _, o in pairs(MilBase.Objectives or {}) do
		local d = worldPos:Distance(o.pos)
		if d <= 500 and (not nod or d < nod) then nearObj, nod = o, d end
	end
	if nearObj then
		local function objEdit(complete)
			net.Start("MilBase_ObjEdit")
				net.WriteUInt(nearObj.id, 16)
				net.WriteBool(complete)
			net.SendToServer()
		end
		menu:AddOption("Complete Objective: " .. nearObj.name, function() objEdit(true) end)
			:SetIcon("icon16/flag_green.png")
		menu:AddOption("Remove Objective", function() objEdit(false) end)
			:SetIcon("icon16/flag_delete.png")
	end

	if #sel > 0 then
		menu:AddSpacer()
		menu:AddOption(#sel .. " selected  —  Move Here", function()
			sendOrder("move", worldPos)
		end):SetIcon("icon16/arrow_right.png")
		menu:AddOption("Attack-Move Here", function() sendOrder("attack", worldPos) end)
		menu:AddOption("Add Waypoint Here", function()
			table.insert(pendingPath, worldPos)
			MilBase.PlayUISound("select")
		end)
		if #pendingPath > 0 then
			menu:AddOption("Finish Patrol (" .. #pendingPath .. " pts)", function()
				sendOrder("patrol", pendingPath[1], nil, pendingPath)
				pendingPath = {}
			end)
		end

		-- Target orders: attack / follow the player or enemy under the cursor.
		local tgtPlayer = playerUnderCursor()
		if IsValid(tgtPlayer) then
			menu:AddOption("Attack " .. tgtPlayer:MBName(), function()
				sendOrder("attackentity", worldPos, tgtPlayer)
			end):SetIcon("icon16/bomb.png")
			menu:AddOption("Follow " .. tgtPlayer:MBName(), function()
				sendOrder("follow", worldPos, tgtPlayer)
			end):SetIcon("icon16/user_go.png")
		end
		if IsValid(cursorEnt) and not selected[cursorEnt] then
			menu:AddOption("Attack This Unit", function()
				sendOrder("attackentity", worldPos, cursorEnt)
			end):SetIcon("icon16/bomb.png")
		end

		if hasLVSSelected() then
			menu:AddOption("Gun Run Here", function()
				local tgt = IsValid(cursorEnt) and cursorEnt:IsPlayer() and cursorEnt or nil
				sendOrder("gunrun", worldPos, tgt)
			end)
			if #pendingPath > 0 then
				menu:AddOption("Finish Flight Path", function()
					sendOrder("flightpath", pendingPath[1], nil, pendingPath)
					pendingPath = {}
				end)
			end
		end

		local beh = menu:AddSubMenu("Behavior")
		beh:AddOption("Hold Position", function() sendOrder("behavior", nil, nil, nil, "hold") end)
		beh:AddOption("Aggressive", function() sendOrder("behavior", nil, nil, nil, "aggressive") end)
		beh:AddOption("Patrol / Wander", function() sendOrder("behavior", nil, nil, nil, "patrol") end)
		beh:AddOption("Careless (ignore)", function() sendOrder("behavior", nil, nil, nil, "careless") end)

		menu:AddOption("Toggle Hold Fire", function() sendOrder("holdfire") end)
			:SetIcon("icon16/control_pause_blue.png")
		menu:AddOption("Retreat", function() sendOrder("retreat", worldPos) end)
			:SetIcon("icon16/arrow_turn_left.png")

		menu:AddOption("Heal / Repair", function() sendOrder("heal") end):SetIcon("icon16/heart.png")
		menu:AddOption("Toggle Invincible", function() sendOrder("invincible") end):SetIcon("icon16/shield.png")
		menu:AddSpacer()
		menu:AddOption("Delete", function()
			sendOrder("delete")
			selected = {}
		end):SetIcon("icon16/cross.png")
		menu:AddOption("Deselect All", function() selected = {} end)
	end

	menu:Open()
end

--------------------------------------------------------------------------
-- UI
--------------------------------------------------------------------------

buildUI = function()
	if IsValid(panel) then panel:Remove() end

	panel = vgui.Create("DPanel")
	panel:SetSize(ScrW(), ScrH())
	panel:MakePopup()
	panel:SetKeyboardInputEnabled(false)
	panel.Paint = function() end

	-- Header
	local header = vgui.Create("DPanel", panel)
	header:SetSize(ScrW(), 40)
	header.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 200)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 140)
		surface.DrawRect(0, h - 2, w, 2)
		draw.SimpleText("GAME MASTER", "MB.Tab", 16, h / 2, ui.accent,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("WASD fly  •  MMB look  •  right-click menu  •  drag units  •  DEL delete  •  [B] toolgun & spawn menu",
			"MB.Tiny", ScrW() / 2, h / 2, ui.dim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- Spawn settings (team / squad size / health / stance) applied to every
	-- placement. Left-click a row to cycle forward, right-click to go back.
	local setBG = vgui.Create("DPanel", panel)
	setBG:SetPos(8, 48)
	setBG:SetSize(190, 118)
	setBG.Paint = function(_, w, h)
		MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8 })
		draw.SimpleText("SPAWN SETTINGS", "MB.Tiny", 9, 7, ui.dim, TEXT_ALIGN_LEFT)
	end

	local settingDefs = {
		{ key = "team", label = "TEAM", list = { "enemy", "friendly", "neutral" },
			text = { enemy = "ENEMY", friendly = "FRIENDLY", neutral = "NEUTRAL" },
			color = { enemy = Color(215, 90, 80), friendly = Color(120, 200, 140),
				neutral = Color(190, 190, 190) } },
		{ key = "count", label = "SQUAD", list = { 1, 2, 3, 4, 6, 8, 12 } },
		{ key = "hp", label = "HEALTH", list = { 0.5, 1, 2, 3, 5 },
			text = { [0.5] = "50%", [1] = "100%", [2] = "200%", [3] = "300%", [5] = "500%" } },
		{ key = "stance", label = "STANCE", list = { "", "defend", "patrol" },
			text = { [""] = "DEFAULT", defend = "HOLD", patrol = "PATROL" } },
	}

	for i, s in ipairs(settingDefs) do
		local btn = vgui.Create("DButton", setBG)
		btn:SetPos(6, 22 + (i - 1) * 24)
		btn:SetSize(178, 22)
		btn:SetText("")
		btn.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and ui.hover or Color(0, 0, 0, 120))
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 198, 60, 30)
			surface.DrawOutlinedRect(0, 0, w, h)
			local val = spawnOpts[s.key]
			local vt = (s.text and s.text[val]) or tostring(val)
			local vc = (s.color and s.color[val]) or ui.text
			draw.SimpleText(s.label, "MB.Tiny", 8, h / 2, ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(vt, "MB.Small", w - 8, h / 2, vc, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		local function cycle(dir)
			local idx = 1
			for k, v in ipairs(s.list) do if v == spawnOpts[s.key] then idx = k break end end
			spawnOpts[s.key] = s.list[((idx - 1 + dir) % #s.list) + 1]
			MilBase.PlayUISound("select")
		end
		btn.DoClick = function() cycle(1) end
		btn.DoRightClick = function() cycle(-1) end
	end

	-- Palette (left content browser)
	local palBG = vgui.Create("DPanel", panel)
	palBG:SetPos(8, 172)
	palBG:SetSize(190, ScrH() - 244)
	palBG.Paint = function(_, w, h) MilBase.DrawPanelBF2(0, 0, w, h, { cut = 8 }) end

	local pal = vgui.Create("DScrollPanel", palBG)
	pal:Dock(FILL)
	pal:DockMargin(2, 2, 2, 2)

	local cats = {}
	for _, id in ipairs(MilBase.EventSpawnOrder) do
		local def = MilBase.EventSpawns[id]
		cats[def.category] = cats[def.category] or {}
		table.insert(cats[def.category], def)
	end
	for cat, defs in SortedPairs(cats) do
		local lbl = vgui.Create("DLabel", pal)
		lbl:Dock(TOP)
		lbl:DockMargin(6, 8, 0, 2)
		lbl:SetFont("MB.Tiny")
		lbl:SetText(string.upper(cat))
		lbl:SetTextColor(ui.dim)
		lbl:SizeToContents()

		for _, def in ipairs(defs) do
			local btn = vgui.Create("DButton", pal)
			btn:Dock(TOP)
			btn:DockMargin(4, 0, 6, 3)
			btn:SetTall(26)
			btn:SetText("")
			btn.Paint = function(self, w, h)
				local armed = placing == def
				surface.SetDrawColor(armed and Color(ui.accent.r, ui.accent.g, ui.accent.b, 55)
					or (self:IsHovered() and ui.hover or Color(0, 0, 0, 120)))
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 198, 60, armed and 120 or 30)
				surface.DrawOutlinedRect(0, 0, w, h)
				draw.SimpleText(def.name, "MB.Small", 8, h / 2,
					armed and ui.text or ui.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			btn.DoClick = function()
				placing = (placing == def) and nil or def
				MilBase.PlayUISound("select")
			end
		end
	end

	-- Command bar
	local bar = vgui.Create("DPanel", panel)
	bar:SetSize(ScrW(), 52)
	bar:SetPos(0, ScrH() - 52)
	bar.Paint = function(_, w, h)
		surface.SetDrawColor(0, 0, 0, 210)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 140)
		surface.DrawRect(0, 0, w, 2)

		draw.SimpleText(#selectionList() .. " UNIT(S) SELECTED", "MB.Small", 16, h / 2,
			ui.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		if placing then
			draw.SimpleText("PLACING: " .. placing.name .. "  (click to place, right-click to cancel)",
				"MB.Tiny", 240, h / 2, Color(120, 200, 140), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		elseif #pendingPath > 0 then
			draw.SimpleText(#pendingPath .. " waypoint(s) — ENTER to commit",
				"MB.Tiny", 240, h / 2, Color(120, 200, 140), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	local function barButton(label, wide, x, onClick)
		local btn = vgui.Create("DButton", bar)
		btn:SetSize(wide, 36)
		btn:SetPos(x, 8)
		btn:SetText("")
		btn.Paint = function(self, w, h)
			surface.SetDrawColor(self:IsHovered() and Color(ui.accent.r, ui.accent.g, ui.accent.b, 55)
				or Color(0, 0, 0, 120))
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 198, 60, 40)
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.SimpleText(label, "MB.Small", w / 2, h / 2, ui.text,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		btn.DoClick = onClick
	end

	barButton("EXIT", 80, ScrW() - 96, function() RunConsoleCommand("say", "/event") end)
	barButton("CLEAR ALL", 110, ScrW() - 214, function()
		net.Start("MilBase_EventClear") net.SendToServer()
	end)
	barButton("BUILD  [B]", 110, ScrW() - 332, function() setBuildMode(true) end)
	barButton("ENEMIES", 110, ScrW() - 450, function()
		if MilBase.OpenEnemyManager then MilBase.OpenEnemyManager() end
	end)

	-- Mouse
	panel.OnMousePressed = function(_, code)
		if code == MOUSE_LEFT then
			if placing then
				sendSpawn(placing, (cursorWorld()))
				if not input.IsKeyDown(KEY_LSHIFT) then placing = nil end -- shift = keep placing
				return
			end
			local u = unitUnderCursor()
			if IsValid(u) then
				if not input.IsKeyDown(KEY_LSHIFT) then selected = {} end
				selected[u] = true
				dragging = u
			else
				boxStart = { x = gui.MouseX(), y = gui.MouseY() }
			end
		elseif code == MOUSE_RIGHT then
			if placing then placing = nil return end
			local pos = cursorWorld()
			openContextMenu(pos, unitUnderCursor())
		end
	end

	panel.OnMouseReleased = function(_, code)
		if code ~= MOUSE_LEFT then return end
		if dragging then
			sendTeleport(dragging, (cursorWorld()))
			dragging = nil
		elseif boxStart then
			finishBoxSelect()
			boxStart = nil
		end
	end

	panel.OnMouseWheeled = function(_, delta)
		flySpeed = math.Clamp(flySpeed + delta * 150, 200, 5000)
	end

	panel.PaintOver = function()
		if not boxStart then return end
		local x0, y0 = boxStart.x, boxStart.y
		local x1, y1 = gui.MouseX(), gui.MouseY()
		surface.SetDrawColor(ui.accent.r, ui.accent.g, ui.accent.b, 30)
		surface.DrawRect(math.min(x0, x1), math.min(y0, y1), math.abs(x1 - x0), math.abs(y1 - y0))
		surface.SetDrawColor(ui.accent)
		surface.DrawOutlinedRect(math.min(x0, x1), math.min(y0, y1), math.abs(x1 - x0), math.abs(y1 - y0))
	end
end

--------------------------------------------------------------------------
-- Box select
--------------------------------------------------------------------------

finishBoxSelect = function()
	local x0, y0 = boxStart.x, boxStart.y
	local x1, y1 = gui.MouseX(), gui.MouseY()

	if math.abs(x1 - x0) < 6 and math.abs(y1 - y0) < 6 then
		if not input.IsKeyDown(KEY_LSHIFT) then selected = {} end
		return -- a plain click on empty ground deselects
	end

	if not input.IsKeyDown(KEY_LSHIFT) then selected = {} end
	local minx, maxx = math.min(x0, x1), math.max(x0, x1)
	local miny, maxy = math.min(y0, y1), math.max(y0, y1)

	for _, ent in ipairs(eventUnits()) do
		local s = ent:GetPos():ToScreen()
		if s.visible and s.x >= minx and s.x <= maxx and s.y >= miny and s.y <= maxy then
			selected[ent] = true
		end
	end
end
