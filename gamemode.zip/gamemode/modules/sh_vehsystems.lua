--[[
	LVS vehicle subsystems.

	Combat damage can knock out a vehicle's Shields, Engines or Weapons
	(Hull is the LVS HP itself). Each knocked-out system has a real effect
	the pilot feels, and only a Combat Engineer with a Repair Kit can fix
	it - giving pilots and engineers a reason to work together:

	  Hull     - LVS HP. Repaired with the Repair Kit (existing behaviour).
	  Shields  - collapse to 0 and stay down until the generator is repaired.
	  Engines  - shut off and can't be restarted until repaired.
	  Weapons  - can't fire until repaired.

	Add more later (hyperdrive, navigation, ...) by registering another
	subsystem + effect below. Everything is guarded, so this module is
	inert without lvs_base.
]]

local cfg = MilBase.Config

-- The subsystem catalogue. "hull" is special (mapped to LVS HP); the rest
-- are tracked as a 0-100 condition on the vehicle (mb_sys_<id>).
MilBase.VehSubsystems = {
	{ id = "hull",    name = "Hull" },
	{ id = "shields", name = "Shields" },
	{ id = "engines", name = "Engines" },
	{ id = "weapons", name = "Weapons" },
	-- Later, e.g.:
	-- { id = "hyperdrive", name = "Hyperdrive" },
	-- { id = "navigation", name = "Navigation" },
}

-- Does this subsystem exist on this vehicle?
function MilBase.VehSysApplies(veh, id)
	if not IsValid(veh) or not veh.LVS then return false end
	if id == "hull" then return veh.GetHP ~= nil end
	if id == "shields" then return veh.GetMaxShield and veh:GetMaxShield() > 0 end
	if id == "engines" then return veh.GetEngineActive ~= nil end
	if id == "weapons" then return veh.WeaponsShouldFire ~= nil end
	return veh:GetNWInt("mb_sys_" .. id, -1) >= 0
end

-- Condition 0-100 (hull reads live LVS HP; others read the tracked value).
function MilBase.GetVehSysCondition(veh, id)
	if id == "hull" then
		if not veh.GetHP or not veh.GetMaxHP then return 100 end
		return math.Clamp(veh:GetHP() / math.max(veh:GetMaxHP(), 1) * 100, 0, 100)
	end
	return veh:GetNWInt("mb_sys_" .. id, 100)
end

--------------------------------------------------------------------------
-- Per-subsystem repair (hold [G] self-menu near / aimed at a vehicle). One
-- self action per non-hull subsystem; hull is handled by the engineering
-- module. Registered on both realms so `visible` (client) and `run`
-- (server) both resolve.
--------------------------------------------------------------------------

do
	local function isEngineer(ply)
		return ply:MBHasCert("engineer") or ply:IsAdmin()
	end

	for i, s in ipairs(MilBase.VehSubsystems) do
		if s.id ~= "hull" then
			MilBase.RegisterSelfAction("veh_repair_" .. s.id, {
				name = "Repair " .. s.name,
				order = 44 + i,
				visible = function(lp)
					local veh = MilBase.ServiceableLVS and MilBase.ServiceableLVS(lp)
					return IsValid(veh) and isEngineer(lp) and MilBase.VehSysApplies(veh, s.id)
						and MilBase.GetVehSysCondition(veh, s.id) < 100
				end,
				run = function(ply)
					local veh = MilBase.ServiceableLVS and MilBase.ServiceableLVS(ply)
					if not IsValid(veh) then return end
					local item = MilBase.FindEngItem and MilBase.FindEngItem(ply, "repair")
					if not item then
						MilBase.Notify(ply, "You need a Repair Kit.")
						return
					end
					MilBase.UseEngineeringItem(ply, item, veh, s.id)
				end,
			})
		end
	end
end

if not SERVER then return end

--------------------------------------------------------------------------
-- Server: init, damage, effects, repair
--------------------------------------------------------------------------

-- Every non-hull subsystem is tracked (so adding one to the list above
-- automatically gives it condition, damage and repair - you only add an
-- effect below if it needs a mechanical consequence).
local TRACKED = {}
for _, s in ipairs(MilBase.VehSubsystems) do
	if s.id ~= "hull" then table.insert(TRACKED, s.id) end
end

local function occupants(veh)
	if veh.GetEveryone then return veh:GetEveryone() end
	local d = veh.GetDriver and veh:GetDriver()
	return IsValid(d) and { d } or {}
end

local function notifyOccupants(veh, text)
	for _, ply in ipairs(occupants(veh)) do
		if IsValid(ply) and ply:IsPlayer() then MilBase.Notify(ply, text) end
	end
end

local function initVeh(veh)
	veh.mb_sysInit = true

	for _, id in ipairs(TRACKED) do
		if veh:GetNWInt("mb_sys_" .. id, -1) < 0 then
			veh:SetNWInt("mb_sys_" .. id, 100)
		end
	end

	-- Gate weapon firing through the vehicle's own fire check.
	if veh.WeaponsShouldFire and not veh.mb_wsfWrapped then
		veh.mb_wsfWrapped = true
		local orig = veh.WeaponsShouldFire
		veh.WeaponsShouldFire = function(self)
			if self:GetNWInt("mb_sys_weapons", 100) <= 0 then return false end
			return orig(self)
		end
	end
end

-- Restore a subsystem. Returns how much condition/HP was actually restored.
function MilBase.RepairVehSubsystem(veh, id, amount)
	if not IsValid(veh) then return 0 end

	if id == "hull" then
		if not veh.GetHP or not veh.SetHP then return 0 end
		local before = veh:GetHP()
		veh:SetHP(math.min(veh:GetMaxHP(), before + amount))
		return veh:GetHP() - before
	end

	local before = veh:GetNWInt("mb_sys_" .. id, 100)
	local after = math.min(100, before + amount)
	veh:SetNWInt("mb_sys_" .. id, after)

	-- Bringing the shield generator back online refills the shield pool.
	if id == "shields" and after > 0 and veh.SetShield and veh.GetMaxShield then
		veh:SetShield(veh:GetMaxShield())
	end

	return after - before
end

--------------------------------------------------------------------------
-- Combat damage knocks systems out
--------------------------------------------------------------------------

hook.Add("EntityTakeDamage", "MilBase.VehSysDamage", function(ent, dmg)
	if not cfg.VehicleSubsystemsEnabled then return end
	if not (IsValid(ent) and ent.LVS) then return end
	if dmg:GetDamage() < (cfg.SubsystemDamageThreshold or 20) then return end
	if math.random() > (cfg.SubsystemDamageChance or 0.2) then return end

	if not ent.mb_sysInit then initVeh(ent) end

	-- Pick a working, applicable system to damage.
	local pool = {}
	for _, id in ipairs(TRACKED) do
		if MilBase.VehSysApplies(ent, id) and ent:GetNWInt("mb_sys_" .. id, 100) > 0 then
			table.insert(pool, id)
		end
	end
	if #pool == 0 then return end

	local id = pool[math.random(#pool)]
	local new = math.max(0, ent:GetNWInt("mb_sys_" .. id, 100) - math.random(40, 75))
	ent:SetNWInt("mb_sys_" .. id, new)

	if new <= 0 then
		local name = id == "engines" and "Engines" or (id == "weapons" and "Weapons" or "Shields")
		notifyOccupants(ent, name .. " OFFLINE — engineer required!")
		ent:EmitSound("ambient/energy/spark" .. math.random(1, 6) .. ".wav", 70)
	end
end)

--------------------------------------------------------------------------
-- Enforce effects
--------------------------------------------------------------------------

-- Disabled engines can't be started.
hook.Add("LVS.IsEngineStartAllowed", "MilBase.VehSysEngine", function(veh)
	if IsValid(veh) and veh:GetNWInt("mb_sys_engines", 100) <= 0 then
		return false
	end
end)

local nextTick = 0
hook.Add("Think", "MilBase.VehSysThink", function()
	if not cfg.VehicleSubsystemsEnabled or not LVS or not LVS.GetVehicles then return end
	if CurTime() < nextTick then return end
	nextTick = CurTime() + 0.25

	for _, veh in ipairs(LVS:GetVehicles()) do
		if not IsValid(veh) then continue end
		if not veh.mb_sysInit then initVeh(veh) end

		-- Engines out: force the engine off.
		if veh:GetNWInt("mb_sys_engines", 100) <= 0
		and veh.GetEngineActive and veh:GetEngineActive() and veh.SetEngineActive then
			veh:SetEngineActive(false)
		end

		-- Shields out: hold the shield collapsed (suppresses LVS regen).
		if veh:GetNWInt("mb_sys_shields", 100) <= 0
		and veh.SetShield and veh.GetShield and veh:GetShield() > 0 then
			veh:SetShield(0)
		end
	end
end)
