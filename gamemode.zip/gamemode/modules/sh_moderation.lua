--[[
	Moderation toolkit — the ULX/SAM essentials as chat commands.

	Discipline (persisted): bans, warnings, staff notes.
	Punishments (session): mute, gag, silence, jail.
	Direct control: kick, slay, respawn, strip, freeze, hp, armor, god, cloak,
	                speed, jump.
	Teleport: goto, bring, return, send, bringall, returnall, tp.
	Staff: staffchat, adminchat, staffduty, stafflist, staffplaytime.

	Commands are registered SHARED (so they appear in the F4 STAFF/HELP command
	list) but their logic lives in MilBase.ModActions server-side and is
	re-validated on level there.
]]

local cfg = MilBase.Config

--------------------------------------------------------------------------
-- Shared: register every command, routed to MilBase.ModActions on the server
--------------------------------------------------------------------------

local function reg(name, level, help)
	MilBase.RegisterChatCommand(name, {
		help = "(Staff " .. level .. "+) " .. help,
		func = function(ply, args, raw)
			if ply:MBStaffLevel() < level then
				MilBase.Notify(ply, "Requires staff level " .. level .. "+.")
				return
			end
			local fn = MilBase.ModActions and MilBase.ModActions[name]
			if fn then fn(ply, args, raw) end
		end,
	})
end

reg("ban",         3, "Ban an online player: /ban <player> <minutes|0=perm> <reason>")
reg("banid",       3, "Ban by SteamID: /banid <steamid> <minutes|0=perm> <reason>")
reg("unban",       3, "Lift a ban: /unban <steamid>")
reg("baninfo",     1, "Show a player's/SteamID's ban: /baninfo <steamid|player>")
reg("warn",        1, "Warn a player: /warn <player> <reason>")
reg("warnings",    1, "List a player's warnings: /warnings <player>")
reg("unwarn",      2, "Remove a warning: /unwarn <player> <warn id>")
reg("clearwarns",  3, "Clear all of a player's warnings: /clearwarns <player>")
reg("kick",        2, "Kick a player: /kick <player> <reason>")
reg("mute",        2, "Text-mute: /mute <player> <minutes> [reason]")
reg("unmute",      2, "Remove a text mute: /unmute <player>")
reg("gag",         2, "Voice-mute: /gag <player> <minutes> [reason]")
reg("ungag",       2, "Remove a voice mute: /ungag <player>")
reg("silence",     2, "Mute + gag: /silence <player> <minutes> [reason]")
reg("unsilence",   2, "Remove mute + gag: /unsilence <player>")
reg("jail",        2, "Jail (freeze + strip): /jail <player> <minutes>")
reg("unjail",      2, "Release from jail: /unjail <player>")
reg("slay",        2, "Kill a player: /slay <player>")
reg("respawn",     2, "Respawn a player: /respawn <player>")
reg("strip",       2, "Strip weapons: /strip <player>")
reg("freeze",      2, "Freeze/unfreeze: /freeze <player>")
reg("hp",          3, "Set health: /hp <player> <amount>")
reg("armor",       3, "Set armor: /armor <player> <amount>")
reg("god",         3, "Toggle god mode: /god <player>")
reg("cloak",       2, "Toggle your own cloak: /cloak")
reg("speed",       3, "Set run speed: /speed <player> <amount>")
reg("jump",        3, "Set jump power: /jump <player> <amount>")
reg("resetmovement", 3, "Reset speed/jump: /resetmovement <player>")
reg("goto",        1, "Teleport to a player: /goto <player>")
reg("bring",       1, "Bring a player to you: /bring <player>")
reg("return",      1, "Return a player to where they were: /return <player>")
reg("send",        2, "Send a player to another: /send <player> <target>")
reg("bringall",    4, "Bring everyone to you: /bringall")
reg("returnall",   4, "Return everyone brought: /returnall")
reg("tp",          1, "Teleport a player to your crosshair: /tp <player>")
reg("staffchat",   1, "Staff-only chat: /staffchat <message>")
reg("adminchat",   3, "Admin-only chat (level 3+): /adminchat <message>")
reg("staffduty",   1, "Toggle on/off duty (status only): /staffduty")
reg("stafflist",   1, "List online staff and duty status: /stafflist")
reg("staffplaytime", 1, "Show your (or a player's) duty time: /staffplaytime [player]")
reg("staffnotes",  2, "View staff notes on a player: /staffnotes <player>")
reg("addnote",     2, "Add a staff note: /addnote <player> <note>")
reg("removenote",  3, "Remove a staff note: /removenote <player> <note id>")

if CLIENT then
	-- Jail HUD banner.
	hook.Add("HUDPaint", "MilBase.JailHUD", function()
		local lp = LocalPlayer()
		if not IsValid(lp) or not lp:GetNWBool("mb_jailed", false) then return end
		local ui = MilBase.UI
		draw.SimpleTextOutlined("⛓ JAILED", "MB.Big", ScrW() / 2, ScrH() * 0.4,
			ui.danger, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end)
	return
end

--------------------------------------------------------------------------
-- Server
--------------------------------------------------------------------------

-- 'until' and 'by' are reserved in MySQL, so the columns are 'expires'/'staff'.
MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_bans (sid VARCHAR(32) PRIMARY KEY, expires INTEGER, reason TEXT, staff VARCHAR(64))")
MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_warns (id " .. MilBase.DB.AutoIncPK() .. ", sid VARCHAR(32), reason TEXT, staff VARCHAR(64), time INTEGER)")
MilBase.DB.Run("CREATE TABLE IF NOT EXISTS frontier_notes (id " .. MilBase.DB.AutoIncPK() .. ", sid VARCHAR(32), note TEXT, staff VARCHAR(64), time INTEGER)")

-- Bans cached in memory for the connect check (loaded async).
local bans = {}
MilBase.DB.Query("SELECT * FROM frontier_bans", function(rows)
	for _, row in ipairs(rows) do
		bans[row.sid] = { until_ = tonumber(row.expires) or 0, reason = row.reason, by = row.staff }
	end
end)

-- Session punishment state.
local muted, gagged, jailed = {}, {}, {}

--------------------------------------------------------------------------
-- Helpers
--------------------------------------------------------------------------

local function find(ply, name)
	local t = MilBase.FindPlayer(name)
	if not IsValid(t) then MilBase.Notify(ply, "Player not found: " .. tostring(name)) end
	return t
end

-- Parse minutes from args[idx]; 0/blank = permanent (returns 0), else abs time.
local function untilFrom(mins)
	mins = tonumber(mins) or 0
	if mins <= 0 then return 0 end
	return os.time() + mins * 60
end

local function humanLeft(until_)
	if until_ == 0 then return "permanent" end
	local s = until_ - os.time()
	if s <= 0 then return "expired" end
	if s < 3600 then return math.ceil(s / 60) .. " min" end
	return math.ceil(s / 3600) .. " hr"
end

local function log(cat, text, a, b)
	if MilBase.Log then MilBase.Log(cat, text, a, b) end
end
local function ltag(ply) return MilBase.LogTag and MilBase.LogTag(ply) or (IsValid(ply) and ply:Nick() or "?") end

-- Can `ply` act on `target`? (Never on equal/higher staff, never yourself for punishments.)
local function outranks(ply, target)
	if target == ply then return true end
	if target:MBStaffLevel() >= ply:MBStaffLevel() then
		MilBase.Notify(ply, "You can't target equal or higher staff.")
		return false
	end
	return true
end

--------------------------------------------------------------------------
-- Bans
--------------------------------------------------------------------------

local function doBan(actor, sid, mins, reason)
	local until_ = untilFrom(mins)
	reason = reason ~= "" and reason or "No reason given"
	bans[sid] = { until_ = until_, reason = reason, by = actor:Nick() }
	MilBase.DB.Run(string.format("REPLACE INTO frontier_bans (sid, expires, reason, staff) VALUES (%s, %d, %s, %s)",
		MilBase.SQLStr(sid), until_, MilBase.SQLStr(reason), MilBase.SQLStr(actor:Nick())))
	log("staff", ltag(actor) .. " banned " .. sid .. " (" .. humanLeft(until_) .. ") — " .. reason, actor)
end

hook.Add("CheckPassword", "MilBase.BanCheck", function(sid64)
	local sid = util.SteamIDFrom64(sid64)
	local ban = bans[sid]
	if not ban then return end
	if ban.until_ ~= 0 and ban.until_ < os.time() then
		bans[sid] = nil
		MilBase.DB.Run("DELETE FROM frontier_bans WHERE sid = " .. MilBase.SQLStr(sid))
		return
	end
	return false, "Banned (" .. humanLeft(ban.until_) .. "): " .. ban.reason
end)

--------------------------------------------------------------------------
-- Action table
--------------------------------------------------------------------------

MilBase.ModActions = {

	ban = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if not outranks(ply, target) then return end
		doBan(ply, target:SteamID(), args[2], table.concat(args, " ", 3))
		MilBase.Notify(ply, "Banned " .. target:MBName() .. " (" .. humanLeft(bans[target:SteamID()].until_) .. ").")
		target:Kick("Banned: " .. (table.concat(args, " ", 3) ~= "" and table.concat(args, " ", 3) or "No reason"))
	end,

	banid = function(ply, args)
		local sid = args[1] or ""
		if not string.match(sid, "^STEAM_%d:%d:%d+$") then MilBase.Notify(ply, "Give a STEAM_0:0:00000 id.") return end
		doBan(ply, sid, args[2], table.concat(args, " ", 3))
		MilBase.Notify(ply, "Banned " .. sid .. ".")
		for _, p in ipairs(player.GetAll()) do if p:SteamID() == sid then p:Kick("Banned") end end
	end,

	unban = function(ply, args)
		local sid = args[1] or ""
		if not bans[sid] then MilBase.Notify(ply, "No active ban for " .. sid .. ".") return end
		bans[sid] = nil
		MilBase.DB.Run("DELETE FROM frontier_bans WHERE sid = " .. MilBase.SQLStr(sid))
		log("staff", ltag(ply) .. " unbanned " .. sid, ply)
		MilBase.Notify(ply, "Unbanned " .. sid .. ".")
	end,

	baninfo = function(ply, args)
		local sid = args[1] or ""
		local byPly = MilBase.FindPlayer(sid)
		if IsValid(byPly) then sid = byPly:SteamID() end
		local ban = bans[sid]
		MilBase.Notify(ply, ban and (sid .. " — banned by " .. ban.by .. " (" .. humanLeft(ban.until_) .. "): " .. ban.reason)
			or "No active ban for " .. sid .. ".")
	end,

	----------------------------------------------------------------
	-- Warnings & notes
	----------------------------------------------------------------

	warn = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local reason = table.concat(args, " ", 2)
		if reason == "" then MilBase.Notify(ply, "Give a reason.") return end
		local sid = MilBase.SQLStr(target:SteamID())
		MilBase.DB.Run(string.format("INSERT INTO frontier_warns (sid, reason, staff, time) VALUES (%s, %s, %s, %d)",
			sid, MilBase.SQLStr(reason), MilBase.SQLStr(ply:Nick()), os.time()))
		MilBase.DB.Query("SELECT COUNT(*) AS c FROM frontier_warns WHERE sid = " .. sid, function(rows)
			local n = tonumber(rows[1] and rows[1].c) or 1
			if IsValid(target) then
				MilBase.Notify(target, "You were warned by " .. ply:MBName() .. ": " .. reason .. " (warning #" .. n .. ")")
			end
			if IsValid(ply) then MilBase.Notify(ply, "Warned " .. target:MBName() .. " (" .. n .. " total).") end
		end)
		log("staff", ltag(ply) .. " warned " .. ltag(target) .. ": " .. reason, ply, target)
	end,

	warnings = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local name = target:MBName()
		MilBase.DB.Query("SELECT id, reason, staff FROM frontier_warns WHERE sid = " ..
			MilBase.SQLStr(target:SteamID()) .. " ORDER BY id DESC LIMIT 15", function(rows)
			if not IsValid(ply) then return end
			if #rows == 0 then MilBase.Notify(ply, name .. " has no warnings.") return end
			MilBase.Notify(ply, name .. " — " .. #rows .. " warning(s):")
			for _, r in ipairs(rows) do
				MilBase.Notify(ply, "  #" .. r.id .. " by " .. r.staff .. ": " .. r.reason)
			end
		end)
	end,

	unwarn = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local id = tonumber(args[2])
		if not id then MilBase.Notify(ply, "Give the warning id (see /warnings).") return end
		MilBase.DB.Run("DELETE FROM frontier_warns WHERE id = " .. id .. " AND sid = " .. MilBase.SQLStr(target:SteamID()))
		MilBase.Notify(ply, "Removed warning #" .. id .. ".")
		log("staff", ltag(ply) .. " removed warning #" .. id .. " from " .. ltag(target), ply, target)
	end,

	clearwarns = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		MilBase.DB.Run("DELETE FROM frontier_warns WHERE sid = " .. MilBase.SQLStr(target:SteamID()))
		MilBase.Notify(ply, "Cleared " .. target:MBName() .. "'s warnings.")
		log("staff", ltag(ply) .. " cleared warnings for " .. ltag(target), ply, target)
	end,

	staffnotes = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local name = target:MBName()
		MilBase.DB.Query("SELECT id, note, staff FROM frontier_notes WHERE sid = " ..
			MilBase.SQLStr(target:SteamID()) .. " ORDER BY id DESC LIMIT 15", function(rows)
			if not IsValid(ply) then return end
			if #rows == 0 then MilBase.Notify(ply, "No notes on " .. name .. ".") return end
			MilBase.Notify(ply, "Notes on " .. name .. ":")
			for _, r in ipairs(rows) do MilBase.Notify(ply, "  #" .. r.id .. " (" .. r.staff .. "): " .. r.note) end
		end)
	end,

	addnote = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local note = table.concat(args, " ", 2)
		if note == "" then MilBase.Notify(ply, "Give a note.") return end
		MilBase.DB.Run(string.format("INSERT INTO frontier_notes (sid, note, staff, time) VALUES (%s, %s, %s, %d)",
			MilBase.SQLStr(target:SteamID()), MilBase.SQLStr(note), MilBase.SQLStr(ply:Nick()), os.time()))
		MilBase.Notify(ply, "Note added to " .. target:MBName() .. ".")
	end,

	removenote = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local id = tonumber(args[2])
		if not id then MilBase.Notify(ply, "Give the note id (see /staffnotes).") return end
		MilBase.DB.Run("DELETE FROM frontier_notes WHERE id = " .. id .. " AND sid = " .. MilBase.SQLStr(target:SteamID()))
		MilBase.Notify(ply, "Removed note #" .. id .. ".")
	end,

	----------------------------------------------------------------
	-- Session punishments
	----------------------------------------------------------------

	kick = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if not outranks(ply, target) then return end
		local reason = table.concat(args, " ", 2)
		log("staff", ltag(ply) .. " kicked " .. ltag(target) .. " (" .. reason .. ")", ply, target)
		target:Kick(reason ~= "" and reason or "Kicked by staff")
	end,

	mute = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		muted[target] = untilFrom(args[2]) == 0 and math.huge or untilFrom(args[2])
		MilBase.Notify(target, "You have been text-muted by staff.")
		MilBase.Notify(ply, "Muted " .. target:MBName() .. ".")
		log("staff", ltag(ply) .. " muted " .. ltag(target), ply, target)
	end,
	unmute = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		muted[target] = nil MilBase.Notify(ply, "Unmuted " .. target:MBName() .. ".")
	end,
	gag = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		gagged[target] = untilFrom(args[2]) == 0 and math.huge or untilFrom(args[2])
		MilBase.Notify(target, "You have been voice-gagged by staff.")
		MilBase.Notify(ply, "Gagged " .. target:MBName() .. ".")
		log("staff", ltag(ply) .. " gagged " .. ltag(target), ply, target)
	end,
	ungag = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		gagged[target] = nil MilBase.Notify(ply, "Ungagged " .. target:MBName() .. ".")
	end,
	silence = function(ply, args)
		MilBase.ModActions.mute(ply, args) MilBase.ModActions.gag(ply, args)
	end,
	unsilence = function(ply, args)
		MilBase.ModActions.unmute(ply, args) MilBase.ModActions.ungag(ply, args)
	end,

	jail = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if not outranks(ply, target) then return end
		if not target:Alive() then MilBase.Notify(ply, "They're dead.") return end
		target:Freeze(true)
		target:StripWeapons()
		target:SetNWBool("mb_jailed", true)
		if MilBase.CloseCharacterSwitchMenu then
			MilBase.CloseCharacterSwitchMenu(target)
		end
		jailed[target] = untilFrom(args[2]) == 0 and math.huge or untilFrom(args[2])
		MilBase.Notify(target, "You've been jailed by staff.")
		MilBase.Notify(ply, "Jailed " .. target:MBName() .. ".")
		log("staff", ltag(ply) .. " jailed " .. ltag(target), ply, target)
	end,
	unjail = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		jailed[target] = nil
		target:Freeze(false)
		target:SetNWBool("mb_jailed", false)
		if target:Alive() then hook.Run("PlayerLoadout", target) end
		MilBase.Notify(ply, "Released " .. target:MBName() .. ".")
	end,

	----------------------------------------------------------------
	-- Direct control
	----------------------------------------------------------------

	slay = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if target:Alive() then target:Kill() end
		MilBase.Notify(ply, "Slayed " .. target:MBName() .. ".")
		log("staff", ltag(ply) .. " slayed " .. ltag(target), ply, target)
	end,
	respawn = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target:Spawn()
		MilBase.Notify(ply, "Respawned " .. target:MBName() .. ".")
	end,
	strip = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target:StripWeapons()
		MilBase.Notify(ply, "Stripped " .. target:MBName() .. ".")
	end,
	freeze = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local f = not target:IsFlagSet(FL_FROZEN)
		target:Freeze(f)
		MilBase.Notify(ply, (f and "Froze " or "Unfroze ") .. target:MBName() .. ".")
	end,
	hp = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target:SetHealth(math.max(1, tonumber(args[2]) or target:Health()))
		MilBase.Notify(ply, "Set " .. target:MBName() .. "'s HP to " .. target:Health() .. ".")
	end,
	armor = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target:SetArmor(math.Clamp(tonumber(args[2]) or 0, 0, 255))
		MilBase.Notify(ply, "Set " .. target:MBName() .. "'s armor to " .. target:Armor() .. ".")
	end,
	god = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if target:HasGodMode() then target:GodDisable() else target:GodEnable() end
		MilBase.Notify(ply, (target:HasGodMode() and "God ON for " or "God OFF for ") .. target:MBName() .. ".")
	end,
	cloak = function(ply)
		local on = not ply:GetNWBool("mb_cloaked", false)
		ply:SetNWBool("mb_cloaked", on)
		ply:SetNoDraw(on) ply:DrawShadow(not on) ply:SetNoTarget(on)
		MilBase.Notify(ply, on and "Cloaked." or "Uncloaked.")
	end,
	speed = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local s = math.max(1, tonumber(args[2]) or 260)
		target:SetRunSpeed(s) target:SetWalkSpeed(math.min(s, target:GetWalkSpeed()))
		MilBase.Notify(ply, "Set " .. target:MBName() .. "'s run speed to " .. s .. ".")
	end,
	jump = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target:SetJumpPower(math.max(1, tonumber(args[2]) or 200))
		MilBase.Notify(ply, "Set " .. target:MBName() .. "'s jump power.")
	end,
	resetmovement = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if MilBase.UpdateMoveSpeed then MilBase.UpdateMoveSpeed(target) end
		target:SetJumpPower(200)
		MilBase.Notify(ply, "Reset " .. target:MBName() .. "'s movement.")
	end,

	----------------------------------------------------------------
	-- Teleport
	----------------------------------------------------------------

	goto = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		ply:SetPos(target:GetPos() + target:GetForward() * 48 + Vector(0, 0, 4))
	end,
	bring = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		target.mb_returnPos = target:GetPos()
		target:SetPos(ply:GetPos() + ply:GetForward() * 64 + Vector(0, 0, 4))
		MilBase.Notify(target, "You were teleported by " .. ply:MBName() .. ".")
	end,
	["return"] = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		if target.mb_returnPos then target:SetPos(target.mb_returnPos) target.mb_returnPos = nil
			MilBase.Notify(ply, "Returned " .. target:MBName() .. ".")
		else MilBase.Notify(ply, "No saved position for them.") end
	end,
	send = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local dest = find(ply, args[2]) if not dest then return end
		target.mb_returnPos = target:GetPos()
		target:SetPos(dest:GetPos() + dest:GetForward() * 64 + Vector(0, 0, 4))
		MilBase.Notify(ply, "Sent " .. target:MBName() .. " to " .. dest:MBName() .. ".")
	end,
	bringall = function(ply)
		for _, p in ipairs(player.GetAll()) do
			if p ~= ply then
				p.mb_returnPos = p:GetPos()
				p:SetPos(ply:GetPos() + Vector(math.Rand(-80, 80), math.Rand(-80, 80), 8))
			end
		end
		MilBase.Notify(ply, "Brought everyone.")
		log("staff", ltag(ply) .. " brought all players", ply)
	end,
	returnall = function(ply)
		for _, p in ipairs(player.GetAll()) do
			if p.mb_returnPos then p:SetPos(p.mb_returnPos) p.mb_returnPos = nil end
		end
		MilBase.Notify(ply, "Returned everyone.")
	end,
	tp = function(ply, args)
		local target = find(ply, args[1]) if not target then return end
		local hit = ply:GetEyeTrace().HitPos
		target.mb_returnPos = target:GetPos()
		target:SetPos(hit + Vector(0, 0, 8))
		MilBase.Notify(ply, "Teleported " .. target:MBName() .. " to your crosshair.")
	end,

	----------------------------------------------------------------
	-- Staff utility
	----------------------------------------------------------------

	staffchat = function(ply, args, raw)
		if raw == "" then return end
		for _, p in ipairs(player.GetAll()) do
			if p:MBStaffLevel() >= 1 then
				MilBase.ChatMsg(p, Color(120, 200, 140), "[STAFF] ", Color(200, 220, 200),
					ply:Nick() .. ": " .. raw)
			end
		end
	end,
	adminchat = function(ply, args, raw)
		if raw == "" then return end
		for _, p in ipairs(player.GetAll()) do
			if p:MBStaffLevel() >= 3 then
				MilBase.ChatMsg(p, Color(210, 140, 60), "[ADMIN] ", Color(230, 210, 190),
					ply:Nick() .. ": " .. raw)
			end
		end
	end,
	staffduty = function(ply)
		local on = not ply:GetNWBool("mb_onduty", false)
		ply:SetNWBool("mb_onduty", on)
		if on then ply.mb_dutyStart = CurTime() end
		MilBase.Notify(ply, on and "You are now ON duty." or "You are now OFF duty.")
	end,
	stafflist = function(ply)
		MilBase.Notify(ply, "Online staff:")
		for _, p in ipairs(player.GetAll()) do
			local rank = p.MBStaffRank and p:MBStaffRank()
			if rank then
				MilBase.Notify(ply, "  " .. p:Nick() .. " — " .. rank.name
					.. (p:GetNWBool("mb_onduty", false) and " (on duty)" or "")
					.. (p:GetNWBool("mb_staffmode", false) and " (staff mode)" or ""))
			end
		end
	end,
	staffplaytime = function(ply, args)
		local target = (args[1] and args[1] ~= "") and find(ply, args[1]) or ply
		if not IsValid(target) then return end
		local dur = target:GetNWBool("mb_onduty", false) and (CurTime() - (target.mb_dutyStart or CurTime())) or 0
		MilBase.Notify(ply, target:Nick() .. " — " .. (target:GetNWBool("mb_onduty", false)
			and ("on duty for " .. math.floor(dur / 60) .. "m") or "off duty"))
	end,
}

--------------------------------------------------------------------------
-- Enforcement hooks
--------------------------------------------------------------------------

hook.Add("PlayerSay", "MilBase.ModMute", function(ply, text)
	if string.sub(text, 1, 1) == "/" then return end -- let commands through
	local m = muted[ply]
	if m and m > os.time() then
		MilBase.Notify(ply, "You are muted.")
		return ""
	elseif m then muted[ply] = nil end
end)

hook.Add("PlayerCanHearPlayersVoice", "MilBase.ModGag", function(listener, talker)
	local g = gagged[talker]
	if g and g > os.time() then return false end
	if g then gagged[talker] = nil end
end)

-- Auto-expire jail; keep jailed players frozen.
timer.Create("MilBase.ModTick", 2, 0, function()
	for ply, until_ in pairs(jailed) do
		if not IsValid(ply) then jailed[ply] = nil
		elseif until_ <= os.time() then
			jailed[ply] = nil
			ply:Freeze(false) ply:SetNWBool("mb_jailed", false)
			if ply:Alive() then hook.Run("PlayerLoadout", ply) end
			MilBase.Notify(ply, "You've been released from jail.")
		elseif not ply:IsFlagSet(FL_FROZEN) and ply:Alive() then
			ply:Freeze(true) -- re-freeze if they respawned out
		end
	end
end)

-- Clean session state on leave.
hook.Add("PlayerDisconnected", "MilBase.ModCleanup", function(ply)
	muted[ply], gagged[ply], jailed[ply] = nil, nil, nil
end)
